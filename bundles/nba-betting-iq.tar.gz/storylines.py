#!/usr/bin/env python3
"""NBA Storylines, Revenge Games (戰舊主), Rivalries & Locker-Room Gossip Engine.

Combines:
1. Roster-verified Star/Starter Revenge Games ("打老東家" — cross-checked against live
   `roster_players` and `injuries` so traded/injured players are always factually accurate).
2. Franchise Rivalries, Superstar Feuds & Public-Betting Narrative Traps.
3. Dynamic Streak / Pressure-Cooker / News Gossip Hooks + Post-Game Revenge Boxscore Recap.
4. Disciplined quantitative signal (`ats_raw_drama`, `ou_raw_drama`) for `model_engine.py`.
"""
from __future__ import annotations

from typing import Any

import teams

# (player_name_exact_or_substr, former_team_abbr, tier, ats_raw_boost, ou_raw_boost, tag_zh, story_template_zh, bet_take_zh)
# Note: Verified at runtime against live `roster_players` so an entry ONLY triggers when the player
# is genuinely on `home_abbr` or `away_abbr` AND the opponent is `former_team_abbr`!
REVENGE_CATALOG: list[tuple[str, str, str, float, float, str, str, str]] = [
    (
        'Ja Morant', 'MEM', 'SUPERSTAR', 0.72, 0.75, '🔥 休賽季重磅交易戰舊主',
        'Ja Morant 在 2026 休賽季結束動盪又輝煌的 7 年曼菲斯灰熊生涯，被交易至波特蘭聯手 Lillard！面對昔日選中並栽培自己的母隊灰熊，Morant 切入侵略性與證明身價的出手慾望勢必拉滿。',
        '球星首度迎戰長年母隊通常伴隨超高球權（Usage%）與轉換快攻節奏，對拓荒者主場士氣與單場得分節奏皆屬正向加溫。',
    ),
    (
        'Jerami Grant', 'POR', 'STARTER', 0.42, 0.35, '🔥 交易籌碼重返老東家',
        '身為今夏「Ja Morant 大交易」被拓荒者送往曼菲斯的核心籌碼，Jerami Grant（偕同前拓荒者前鋒 Kris Murray）身穿灰熊球衣重返熟悉的波特蘭摩達中心踢館舊主，形成罕見的「雙向戰舊主」對決！',
        '被交易老將在熟悉的前主場籃框往往有不錯的外線開局手感，有助受讓方灰熊咬住比分避免早早崩盤。',
    ),
    (
        'Kris Murray', 'POR', 'ROTATION', 0.16, 0.15, '🔄 前拓荒者鋒線反戈',
        'Kris Murray 隨 Ja Morant 交易案轉戰灰熊後重返波特蘭面對前隊友，替補端具備額外拼勁。',
        '替補輪替熟悉對手戰術跑位，微幅支撐灰熊第二陣容銜接段。',
    ),
    (
        'Giannis Antetokounmpo', 'MIL', 'SUPERSTAR', 0.85, 0.80, '💥 字母哥世紀交易復仇戰',
        '震撼全聯盟的「字母哥南灘交易案」主角！曾率密爾瓦基奪冠的公鹿隊史圖騰 Giannis Antetokounmpo 改披熱火戰袍對決老東家公鹿，全美鎂光燈與禁區肉搏強度直逼總冠軍賽。',
        '超級巨星戰舊主具備極強哨音紅利與禁區殺傷力，罰球數與戰意顯著拉升。',
    ),
    (
        'Tyler Herro', 'MIA', 'STAR', 0.58, 0.55, '🔥 前南灘英雄哥反戈熱火',
        '身為換回字母哥的頭號籌碼，「英雄哥」Tyler Herro（與前熱火隊友 Jaime Jaquez Jr.、Kel\'el Ware）轉戰公鹿後迎戰最熟悉的 Spo 教練體系，外線狂轟證明自我的企圖心極強。',
        '熟悉熱火區域聯防弱點的射手群反戈，有利推升外線三分出手量與比賽總分。',
    ),
    (
        'Jaylen Brown', 'BOS', 'SUPERSTAR', 0.76, 0.65, '⚔️ 東區世仇互換·FMVP戰綠衫軍',
        '2026 夏天最狂交易！前綠衫軍奪冠 FMVP Jaylen Brown 竟改披同區死敵 76 人球衣，正面對決昔日雙探花搭檔 Jayson Tatum，場上場下話題與火藥味雙雙破表！',
        '頂級鋒線面對前東家單打強攻比例大增，需特別留意開賽前兩節高強度身體對抗與犯規累積。',
    ),
    (
        'Paul George', 'PHI', 'STAR', 0.55, 0.48, '🔥 PG13 披綠衫反戈費城',
        'Paul George 在休賽季與 Jaylen Brown 互換東家轉投塞爾提克，面對僅短暫合作便分手的費城 76 人與全場費城球迷噓聲，外線冷箭戰意十足。',
        '費城主客場對 PG13 的針對性防守與噓聲往往激化比賽情緒，利於拉鋸戰劇本。',
    ),
    (
        'Paul George', 'LAC', 'STAR', 0.45, 0.40, '🍿 PG13 對決前東家快艇',
        '曾與可愛組建快艇雙星多年的 Paul George 對陣老東家快艇，雙方對彼此單打習慣瞭若指掌。',
        '老東家重逢局，球星個人單打回合數偏高。',
    ),
    (
        'LeBron James', 'LAL', 'SUPERSTAR', 0.70, 0.65, '👑 詹皇轉戰費城對決紫金舊主',
        'LeBron James 休賽季告別洛杉磯轉投 76 人組建豪華巨頭！面對曾攜手奪冠的紫金湖人與接班王牌 Luka Dončić，全美收視與歷史話題感拉滿。',
        '詹皇生涯對陣前東家向來開啟全能控場刷數據模式，但亦須留意全國轉播熱門盤的大眾資金溢價。',
    ),
    (
        'LeBron James', 'CLE', 'SUPERSTAR', 0.52, 0.50, '👑 詹皇對決家鄉騎士',
        'LeBron James 再度面對克里夫蘭家鄉母隊騎士，每次交手皆宛如巡迴致敬與數據里程碑之夜。',
        '家鄉父老面前戰意穩定，進攻效率往往優於賽季均值。',
    ),
    (
        'Luka Doncic', 'DAL', 'SUPERSTAR', 0.88, 0.85, '🔥 Luka 頭號復仇夜·痛打獨行俠舊主',
        '自獨行俠震撼送走當家看板球星後，每一次「Luka Dončić 打達拉斯」都是聯盟最兇狠的個人復仇飆分秀（面對前高層與舊主毫不手軟）！',
        'Luka 戰獨行俠歷史級戰意加成顯著，單場高得分與高罰球極易同步推升湖人讓分與大分動能。',
    ),
    (
        'Kevin Durant', 'OKC', 'SUPERSTAR', 0.65, 0.65, '🐍 KD 迎戰發跡母隊雷霆',
        '休賽季轉戰火箭的 Kevin Durant 對決生涯起點奧克拉荷馬雷霆與新科 MVP 級王牌 SGA！即使多年過去，KD 碰上雷霆依舊自帶世代傳承與全場焦點話題。',
        'KD 面對雷霆年輕鋒線海向來習慣以無解中距離回應，關鍵時刻單打效率極高。',
    ),
    (
        'Kevin Durant', 'PHX', 'SUPERSTAR', 0.66, 0.62, '🔥 KD 披火箭戰袍手刃太陽舊主',
        'Kevin Durant 告別鳳凰城轉投休士頓火箭（太陽換回 Jalen Green 與續留 Dillon Brooks），面對前搭檔 Devin Booker 與太陽舊主，雙方都有「證明誰才是贏家」的輸不起壓力！',
        '前東家對決加上 Dillon Brooks 貼身垃圾話伺候，KD 出手侵略性與買犯規頻率預期雙雙走高。',
    ),
    (
        'Kevin Durant', 'GSW', 'SUPERSTAR', 0.52, 0.55, '🍿 KD 再戰灣區老戰友 Curry',
        'Kevin Durant 率火箭年輕大軍交手前冠軍搭檔 Stephen Curry 與勇士，昔日宇宙勇情懷與當今西區卡位戰交織。',
        '巨星對飆三分與中距離的觀賞性極高，末節關鍵球把握度左右盤口。',
    ),
    (
        'Kevin Durant', 'BKN', 'STAR', 0.48, 0.45, '🍿 KD 對決布魯克林前東家',
        'Kevin Durant 對陣昔日籃網舊主，過往布魯克林三巨頭風暴至今仍是紐約媒體熱議八卦。',
        '面對重建鋒線群，KD 錯位單打優勢明顯。',
    ),
    (
        'Jimmy Butler', 'MIA', 'STAR', 0.70, 0.55, '☕ 士官長 Butler 恩怨局戰熱火',
        '當年與熱火總裁 Pat Riley 為續約公開互嗆後離隊的「士官長」Jimmy Butler，身穿勇士球衣碰上邁阿密老東家，堪稱聯盟最帶種的硬漢恩怨局！',
        '士官長逢恩怨局必切換「季後賽吉米」強攻造犯規模式，防守端身體對抗極度激烈。',
    ),
    (
        'Jimmy Butler', 'MIN', 'STAR', 0.54, 0.45, '🍿 士官長對決灰狼舊主',
        '曾上演「帶第三陣容打爆先發」經典訓練營八卦的 Jimmy Butler 面對明尼蘇達灰狼，至今每次作客仍伴隨漫天噓聲。',
        '噓聲催化士官長買犯規與強硬防守，比賽肢體火藥味濃。',
    ),
    (
        'Jimmy Butler', 'PHI', 'STAR', 0.48, 0.40, '🍿 士官長戰費城前東家',
        '當年留下名言「Tobias Harris over me?!」的 Jimmy Butler 對決 76 人老東家，話題性十足。',
        '關鍵時刻強打意願高，利於咬緊淺盤。',
    ),
    (
        'LaMelo Ball', 'CHA', 'STAR', 0.64, 0.70, '🛸 三球 LaMelo 轉戰灰狼反戈黃蜂',
        '休賽季被夏洛特送往明尼蘇達的「三球」LaMelo Ball 迎戰待了六年的老東家黃蜂（而前灰狼最佳第六人 Naz Reid 則披黃蜂戰袍反戈），雙方互換核心正面驗貨！',
        'LaMelo 面對老東家開放式轉換快攻與超遠三分出手慾望極強，節奏明顯偏快偏大。',
    ),
    (
        'Naz Reid', 'MIN', 'STARTER', 0.46, 0.40, '🔥 Naz Reid 反戈北大荒前東家',
        '昔日深受明尼蘇達球迷高喊「Naz Reid!」愛戴的最佳第六人轉披黃蜂戰袍，對決前東家灰狼禁區知根知底。',
        '空間型內線外拆三分熟悉前隊友協防習慣，具備冷箭咬盤潛力。',
    ),
    (
        'Karl-Anthony Towns', 'MIN', 'STAR', 0.62, 0.55, '🐺 KAT 對決九年母隊灰狼',
        '曾效力明尼蘇達長達九年的狀元郎 Karl-Anthony Towns 身穿尼克球衣迎戰灰狼老東家，內外線強攻證明身價意味濃厚。',
        'KAT 面對前東家外線與低位進攻慾望強烈，但亦須留意情緒亢奮下的早期犯規麻煩。',
    ),
    (
        'Julius Randle', 'NYK', 'STAR', 0.58, 0.50, '🗽 Randle 紐約德比反戈尼克',
        '曾扛起麥迪遜花園復興的 Julius Randle 如今披上同城死敵布魯克林籃網戰袍對決老東家尼克，紐約同城恩怨＋戰舊主雙重加持！',
        '低位強鑿與身體對抗強度拉滿，籃板爭搶極為關鍵。',
    ),
    (
        'Julius Randle', 'MIN', 'STAR', 0.48, 0.42, '🔄 Randle 對決前東家灰狼',
        '轉戰籃網的 Julius Randle 交手前東家灰狼，熟悉對手鋒線協防輪轉。',
        '持球強攻比重提高，微幅支撐籃網進攻下限。',
    ),
    (
        'Michael Porter Jr.', 'DEN', 'STAR', 0.60, 0.65, '🔥 MPJ 轉戰籃網無限開火迎戰金塊舊主',
        '昔日金塊奪冠高砲塔 Michael Porter Jr. 轉投籃網躍升頭號得分點（場均逾 22 分），首度以對手身分面對前搭檔 Jokić 與丹佛老東家！',
        'MPJ 脫離體系束縛後面對老東家瘋狂出手三分機率極高，顯著推升外線變異與大分潛力。',
    ),
    (
        'Cameron Johnson', 'PHX', 'STARTER', 0.42, 0.40, '☀️ Cam Johnson 重返鳳凰城戰太陽',
        '曾深受太陽球迷喜愛的「雙胞胎鋒線」Cameron Johnson 如今身穿金塊球衣重返鳳凰城對決前隊友 Devin Booker，熟悉太陽主場視野與戰術。',
        '定點三分射手回到熟悉球館往往有穩定外線輸出。',
    ),
    (
        'Cameron Johnson', 'BKN', 'STARTER', 0.40, 0.38, '🔄 Cam Johnson 對決前東家籃網',
        'Cameron Johnson 隨金塊迎戰前東家布魯克林籃網（與互換對象 MPJ 正面交鋒）！',
        '鋒線互換直接對位，外線把握度成勝負分水嶺。',
    ),
    (
        'Darius Garland', 'CLE', 'STAR', 0.62, 0.55, '🔥 Garland 對決互換東家騎士＆哈登',
        '快艇與騎士全明星控衛大互換！曾效力克里夫蘭多年的 Darius Garland 披快艇戰袍對撞前隊友 Donovan Mitchell 與換來自己的 James Harden！',
        '後場雙槍互爆劇本明確，擋拆針對性極強。',
    ),
    (
        'James Harden', 'LAC', 'STAR', 0.60, 0.55, '🧔 大鬍子 Harden 反戈前東家快艇',
        '生涯轉隊話題不斷的 James Harden 改披騎士戰袍迎戰前東家快艇！每逢「哈登打前東家」向來是媒體與球迷津津樂道的吃瓜大戲。',
        '哈登面對前東家組織串聯與後撤步三分專注度通常明顯提升。',
    ),
    (
        'James Harden', 'PHI', 'STAR', 0.58, 0.52, '🍿 哈登再戰費城「Morey 恩怨局」',
        '當年公開痛批 76 人總管「Daryl Morey 是騙子」震撼全聯盟的 James Harden，每次對決費城 76 人都是漫天噓聲與滿滿八卦恩怨！',
        '恩怨情緒局帶動高強度造犯規與關鍵球對決。',
    ),
    (
        'James Harden', 'HOU', 'STAR', 0.45, 0.45, '🚀 哈登重逢休士頓火箭舊主',
        '昔日火箭得分王 James Harden 對決休士頓老東家，情懷與戰術博弈兼具。',
        '熟悉球館節奏，控場穩定度佳。',
    ),
    (
        'Kawhi Leonard', 'LAC', 'STAR', 0.62, 0.45, '🦖 可愛鳳還巢暴龍後迎戰快艇舊主',
        '2019 率暴龍奪冠的 FMVP Kawhi Leonard 戲劇性重返多倫多後，正面交手前東家洛杉磯快艇，健康出賽時攻防壓迫感十足！',
        '可愛若正常出賽且無上場時間限制，中距離單打對老東家殺傷力極強。',
    ),
    (
        'Anthony Davis', 'LAL', 'STAR', 0.58, 0.45, '🔥 一眉道人 AD 迎戰紫金湖人舊主',
        '曾為湖人奪下 2020 總冠軍的 Anthony Davis 如今坐鎮巫師禁區，面對前東家湖人，禁區護框與強打證明身價的戰意拉滿。',
        'AD 打前東家籃板與阻攻侵略性極強，有助受讓方鞏固禁區。',
    ),
    (
        'Trae Young', 'ATL', 'STAR', 0.70, 0.75, '❄️ Ice Trae 吹楊反戈老鷹舊主',
        '曾擔任亞特蘭大絕對看板多年的「吹楊」Trae Young 轉戰華盛頓巫師後對決老東家老鷹！以他愛當反派英雄的個性，Logo Shot 與比「冷血發抖」手勢的戲碼隨時上演。',
        '吹楊戰老鷹球權與超遠三分出手必暴增，且雙方防守皆非強項，極利大分節奏。',
    ),
    (
        'Jaren Jackson Jr.', 'MEM', 'STAR', 0.60, 0.45, '🛡️ 前 DPOY JJJ 披爵士戰袍對決灰熊母隊',
        '昔日曼菲斯防守大鎖 Jaren Jackson Jr. 轉戰猶他爵士後迎戰效力多年的灰熊母隊，禁區火鍋與外拆三分戰意高昂。',
        '熟悉灰熊內線掩護習慣，護框威懾力顯著。',
    ),
    (
        'Desmond Bane', 'MEM', 'STAR', 0.60, 0.55, '🎯 貝恩 Bane 轉戰魔術反戈灰熊舊主',
        '灰熊昔日外線神射 Desmond Bane 改披奧蘭多魔術戰袍對決曼菲斯老東家，面對老隊友毫不手軟。',
        '外線跑動三分出手果決，為魔術半場進攻注入關鍵火力。',
    ),
    (
        'De\'Aaron Fox', 'SAC', 'STAR', 0.65, 0.60, '🦊 狐狸 Fox 聯手斑馬迎戰國王舊主',
        '曾點亮沙加緬度「勝利光束 Light the Beam」的 De\'Aaron Fox 轉投馬刺輔佐 Wembanyama，面對老東家國王速度快攻與末節關鍵球企圖心十足！',
        '速度型控衛打前東家轉換節奏極快，第四節單打價值高。',
    ),
    (
        'Zach LaVine', 'CHI', 'STAR', 0.56, 0.55, '🔥 LaVine 披國王球衣對決公牛舊主',
        '曾擔任芝加哥當家得分手多年的 Zach LaVine 迎戰老東家公牛，外線拔起與切入爆扣表現慾極強。',
        '得分爆發力強但防守端偶有漏人，偏大分劇本。',
    ),
    (
        'Klay Thompson', 'GSW', 'STARTER', 0.52, 0.55, '🌊 浪花情懷局·K湯披熱火戰袍對決 Curry',
        '四冠功臣 Klay Thompson（與前勇士狀元 Andrew Wiggins）身穿邁阿密熱火球衣面對老東家金州勇士與好兄弟 Stephen Curry，每次三分出手都牽動全場歡呼與感嘆！',
        'K湯面對勇士往往急於用三分證明油箱還有油，外線出手頻率顯著高於平日。',
    ),
    (
        'Jonathan Kuminga', 'GSW', 'STARTER', 0.54, 0.50, '⚡ 庫明加 Kuminga 解放球權痛擊勇士舊主',
        '過去在勇士體系苦等上場時間、多次傳出休息室摩擦八卦的 Jonathan Kuminga，轉戰灰狼獲得重用後面對前教頭 Steve Kerr，衝擊籃框證明「當初少用我是錯的」戰意爆棚！',
        '年輕體能鋒線急欲在老教練面前刷存在感，切入衝框與快攻得分積極度極高。',
    ),
    (
        'Norman Powell', 'LAC', 'STAR', 0.52, 0.50, '🔥 鮑威爾轉扛公牛一哥反戈快艇',
        '休賽季以 2 年 4500 萬轉投芝加哥並扛起公牛頭號得分手（場均逾 21 分）的 Norman Powell，迎戰前東家快艇火力全開。',
        '砍分型後衛面對前東家外線果決度高。',
    ),
    (
        'Jalen Green', 'HOU', 'STARTER', 0.50, 0.52, '🚀 杰倫格林披太陽戰袍對決火箭母隊',
        '曾是休士頓重建榜眼招牌的 Jalen Green 隨 KD 交易案轉戰鳳凰城太陽，面對昔日隊友 Sengun 與 Amen Thompson 勢必想用飆分證明自己！',
        '高變異砍分後衛戰舊主，手感順時易帶動單節大分高潮。',
    ),
    (
        'Dillon Brooks', 'MEM', 'STARTER', 0.38, 0.42, '😈 惡漢 Dillon Brooks 再槓前東家灰熊',
        '當年因季後賽嗆聲詹皇後被灰熊高層公開放話「任何情況都不續約」的 Dillon Brooks，每次碰上曼菲斯舊主都像打總冠軍賽一樣拼命貼防噴垃圾話！',
        '肢體接觸與技術犯規高風險場次，吹判尺度易拉高罰球數。',
    ),
    (
        'Dillon Brooks', 'HOU', 'STARTER', 0.35, 0.35, '😈 Dillon Brooks 反戈火箭舊主',
        '離開休士頓轉戰太陽並簽下肥約的 Dillon Brooks 對決前東家火箭，與昔日年輕隊友互噴垃圾話看點十足。',
        '防守身體對抗強度拉升。',
    ),
    (
        'RJ Barrett', 'NYK', 'STAR', 0.52, 0.48, '🍁 楓葉曼巴 Barrett 偕 Quickley 戰尼克舊主',
        '當年被尼克打包送回家鄉多倫多的 RJ Barrett 與 Immanuel Quickley，每次碰上紐約老東家都卯足全力證明暴龍沒換虧！',
        '雙雙具備強烈證明動機，切入造犯規積極。',
    ),
    (
        'Myles Turner', 'IND', 'STARTER', 0.48, 0.40, '🛡️ 十年溜馬老臣 Turner 披公鹿戰袍反戈',
        '曾在印第安納苦守禁區十年、年年捲入交易傳聞的 Myles Turner 轉投同區宿敵公鹿後面對溜馬舊主（加乘公鹿溜馬近年搶球樑子），話題張力十足！',
        '外拆三分與護框熟悉前搭檔 Haliburton 傳球路線。',
    ),
    (
        'Damian Lillard', 'MIL', 'STAR', 0.55, 0.55, '⌚ 小李飛刀 Lillard 鳳還巢拓荒者後戰公鹿',
        '經歷密爾瓦基風雨後重返最熟悉波特蘭的 Damian Lillard（偕同前公鹿奪冠後衛 Jrue Holiday）迎戰前東家公鹿，關鍵時刻「Dame Time」看點滿滿！',
        '雙後衛皆曾效力公鹿，對前東家防守策略極為熟悉。',
    ),
]


# Franchise Rivalries & Superstar Gossip Hooks: keyed by frozenset({abbr1, abbr2})
RIVALRY_CATALOG: dict[frozenset[str], tuple[str, str, str, float]] = {
    frozenset({'LAL', 'GSW'}): (
        '🌟 全美流量之王·新世代湖勇大戰',
        '詹皇遠走費城後，「湖勇大戰」迎來全新劇本！場均狂轟 36 分的湖人單核 Luka Dončić 率隊踢館灣區 Stephen Curry 與士官長 Jimmy Butler。這組對決永遠是全美收視與散戶投注量冠軍！',
        '💡 運彩防呆提醒：湖勇大戰常有大量「球迷信仰資金（Public Money）」湧入熱門方或無腦追大分，務必以每日 23:00 鎖定盤與模型合理盤乖離為準，切忌憑名氣盲追深盤。',
        0.35,
    ),
    frozenset({'NYK', 'PHI'}): (
        '⚔️ I-95 走廊東區世仇·豪華巨頭火併',
        '自季後賽「紐約球迷買爆費城主場門票」讓 Embiid 氣到公開抱怨後，尼克與 76 人樑子越結越深！本季 76 人更湊齊 Embiid、Maxey、Jaylen Brown、LeBron 世紀陣容硬剛尼克 Brunson 與 KAT，開幕週交手才剛創下 2012 年以來收視新高！',
        '💡 盤口影響解讀：東區頂級世仇二番戰防守針對性極強、末節分差緊咬機率高，需留意第四節故意犯規戰術對大小分的拉抬。',
        0.30,
    ),
    frozenset({'HOU', 'DAL'}): (
        '🤠 德州內戰 I-45 Rivalry·KD 過招狀元 Flagg 與前搭檔 Kyrie',
        '德州宿敵正面交鋒！除了休士頓與達拉斯長年世仇外，場外最大八卦莫過於昔日籃網「7-11 組合」Kevin Durant 與 Kyrie Irving 各為其主隔網單挑，同場還有獨行俠超級狀元 Cooper Flagg 迎戰火箭雙星 Sengun！',
        '💡 盤口影響解讀：前隊友球星互別苗頭＋德州內戰主場哨音張力大，受讓方韌性通常優於一般例行賽。',
        0.30,
    ),
    frozenset({'BOS', 'PHI'}): (
        '☘️ 大西洋組百年世仇＋世紀互換驗貨局',
        'NBA 季後賽歷史交手次數最多的東區死敵，今年更因「Jaylen Brown 互換 Paul George」震撼交易把恩怨推向最高潮！誰在交易中當冤大頭，這場就是全聯盟名嘴放大鏡檢驗的修羅場。',
        '💡 盤口影響解讀：季後賽等級防守肉搏戰，半場陣地戰比例高，球星單打效率決定讓分盤走向。',
        0.20,
    ),
    frozenset({'BOS', 'LAL'}): (
        '🏆 黃綠豪門百年世仇（聯盟最多冠雙雄）',
        '塞爾提克與湖人的紫金綠衫世仇從不需動員！雙方無論戰績高低，碰頭時主力上場時間與防守輪轉強度皆直接拉到季後賽規格。',
        '💡 盤口影響解讀：豪門世仇戰少見提早放棄進入垃圾時間，深盤受讓方往往具備末節咬盤韌性。',
        0.15,
    ),
    frozenset({'BOS', 'MIA'}): (
        '🔥 東決宿命冤家＋字母哥空降南灘新戰局',
        '近年東區冠軍賽屢屢死磕的老冤家，如今熱火更迎來公鹿前王牌 Giannis Antetokounmpo 坐鎮禁區，繼續與綠衫軍 Tatum 上演東區霸權爭奪戰！',
        '💡 盤口影響解讀：Spo 教練針對性防守體系極擅長限制對手三分出手品質，防守焦土戰機率高。',
        -0.25,
    ),
    frozenset({'POR', 'UTA'}): (
        '🐻 昔日灰熊雙子星重逢·Morant 隔網對決 JJJ',
        '滿滿回憶殺與八卦看點！過去七年並肩扛起曼菲斯灰熊招牌的雙子星 Ja Morant（今夏轉戰拓荒者）與前最佳防守球員 Jaren Jackson Jr.（轉投爵士），休賽季雙雙離開灰熊後首度以西區對手身分正面交鋒！',
        '💡 盤口影響解讀：昔日老搭檔最懂彼此切入習慣與封阻時機，Morant 挑戰 JJJ 禁區的戲碼將直接左右禁區犯規麻煩。',
        0.25,
    ),
    frozenset({'DEN', 'LAL'}): (
        '🏔️ 西區宿命天敵局·Luka 助湖人挑戰金塊心魔',
        '過去幾年季後賽金塊 Jokić 堪稱湖人頭號苦主（連教練都曾被金塊打到下課）；如今紫金軍團改由 Luka Dončić 掌舵並補進護框中鋒 Walker Kessler，能否討回顏面備受洛城媒體關注！',
        '💡 盤口影響解讀：湖人面對金塊戰意永遠拉滿，但高原主客場體能與末節 Jokić 控場仍是盤口關鍵分水嶺。',
        0.25,
    ),
    frozenset({'MEM', 'GSW'}): (
        '💥 西區嘴砲火藥庫·灰熊勇士宿怨局',
        '自季後賽「Draymond Green 與灰熊打破潛規則風波」結下樑子後，兩隊每次碰面肢體動作與垃圾話從沒少過！',
        '💡 盤口影響解讀：情緒張力大、技術犯規與轉換快攻回合多，比賽節奏易突然加速。',
        0.35,
    ),
    frozenset({'IND', 'MIL'}): (
        '🏀 中央組「搶比賽用球」死敵恩怨局',
        '自「字母哥衝進溜馬球員通道搶比賽用球」事件與季後賽淘汰樑子後，公鹿與溜馬已成東區最火爆的新世仇（加上長人 Myles Turner 轉投公鹿反戈）！',
        '💡 盤口影響解讀：兩隊近年交手屢屢上演不設防飆分大戰與垃圾話互噴，歷史大分傾向顯著。',
        0.55,
    ),
    frozenset({'MIN', 'DEN'}): (
        '🐺 西區搶七宿敵強強對話',
        '自季後賽經典搶七大戰結下深仇，灰狼與金塊每次碰頭皆是肌肉棒子級別的針對性防守大戰。',
        '💡 盤口影響解讀：雙方先發主力纏鬥時間長，半場進攻空間緊縮。',
        -0.20,
    ),
    frozenset({'SAS', 'OKC'}): (
        '🦄 新世代獨角獸宿命對決·斑馬 Wembanyama vs Chet',
        '從新秀年一路被拿來比較的兩大七呎獨角獸神獸 Victor Wembanyama（馬刺）與 Chet Holmgren（雷霆）正面交鋒，兩人每次對位火鍋與外線顏射都火花四射！',
        '💡 盤口影響解讀：兩名頂級護框長人同時鎮守油漆區，禁區命中率受壓抑，外線三分手感將決定勝負。',
        -0.15,
    ),
}


def _match_roster_player(
    needle: str,
    team_roster: list[dict[str, Any]],
) -> dict[str, Any] | None:
  nl = needle.lower()
  # Handle accents like Dončić -> Doncic
  norm = lambda s: (
      str(s or '')
      .lower()
      .replace('č', 'c')
      .replace('ć', 'c')
      .replace('š', 's')
      .replace('ž', 'z')
      .replace('ö', 'o')
      .replace('ū', 'u')
  )
  nn = norm(nl)
  for p in team_roster:
    raw_name = p.get('player_name') if isinstance(p, dict) else p
    pn = norm(raw_name or '')
    if nn == pn or nn in pn:
      return p if isinstance(p, dict) else {'player_name': str(raw_name)}
  return None


def _player_injury_state(
    needle: str,
    team_injuries: list[dict[str, Any]],
) -> dict[str, Any] | None:
  nl = needle.lower().split()[0] + ' ' + needle.lower().split()[-1] if ' ' in needle else needle.lower()
  for inj in team_injuries:
    pn = str(inj.get('player_name') or '').lower()
    if needle.lower() in pn or nl in pn:
      return inj
  return None


def _find_boxscore_stat_line(
    needle: str,
    side_rows: list[list[Any]] | None,
) -> str:
  """Extracts post-game/in-game stat line from compact `game_boxscores[gid][side]` if available."""
  if not side_rows:
    return ''
  nl = needle.lower().replace('č', 'c').replace('ć', 'c')
  last_tok = nl.split()[-1]
  for r in side_rows:
    # [0:pid, 1:name, 2:pos, 3:jersey, 4:starter, 5:dnp, 6:dnp_reason, 7:min_str, 8:min, 9:pts, ... 18:reb, 19:ast]
    rname = str(r[1] or '').lower().replace('č', 'c').replace('ć', 'c')
    if nl in rname or (len(last_tok) >= 5 and last_tok in rname and nl[0] == rname[0]):
      if r[5]:
        return f'本場未上陣（{r[6] or "DNP"}）'
      return f'本場實戰繳出 {r[9]} 分 · {r[18]} 籃板 · {r[19]} 助攻（上場 {r[7] or r[8]} 分鐘）'
  return ''


def evaluate_game_storylines(
    away_abbr: str,
    home_abbr: str,
    roster_by_team: dict[str, list[dict[str, Any]]] | None = None,
    injuries_by_team: dict[str, list[dict[str, Any]]] | None = None,
    away_record: str = '',
    home_record: str = '',
    news_items: list[dict[str, Any]] | None = None,
    game_boxscore: dict[str, list[list[Any]]] | None = None,
    game_status: str = 'SCHEDULED',
) -> dict[str, Any]:
  """Returns structured storylines/gossip items AND disciplined quantitative factor signals."""
  roster_map = roster_by_team or {}
  inj_map = injuries_by_team or {}
  a_roster = roster_map.get(away_abbr) or []
  h_roster = roster_map.get(home_abbr) or []
  a_inj = inj_map.get(away_abbr) or []
  h_inj = inj_map.get(home_abbr) or []
  a_zh = teams.team_info(away_abbr)['zh']
  h_zh = teams.team_info(home_abbr)['zh']

  items: list[dict[str, Any]] = []
  ats_home_raw = 0.0
  ou_over_raw = 0.0

  # 1. Roster-verified Revenge Games ("打老東家")
  for p_name, ex_abbr, tier, ats_b, ou_b, badge_zh, story_zh, take_zh in REVENGE_CATALOG:
    on_home = (ex_abbr == away_abbr) and (not h_roster or _match_roster_player(p_name, h_roster) is not None)
    on_away = (ex_abbr == home_abbr) and (not a_roster or _match_roster_player(p_name, a_roster) is not None)
    # Require positive roster confirmation when roster_map is populated!
    if roster_map:
      on_home = (ex_abbr == away_abbr) and (_match_roster_player(p_name, h_roster) is not None)
      on_away = (ex_abbr == home_abbr) and (_match_roster_player(p_name, a_roster) is not None)
    if not (on_home or on_away):
      continue

    cur_abbr = home_abbr if on_home else away_abbr
    cur_zh = h_zh if on_home else a_zh
    ex_zh = a_zh if on_home else h_zh
    side_inj = h_inj if on_home else a_inj
    inj_st = _player_injury_state(p_name, side_inj) if game_status != 'FINAL' else None

    avail_mult = 1.0
    inj_note = ''
    if inj_st:
      prob = int(inj_st.get('play_prob_next') or 0)
      if prob == 0:
        avail_mult = 0.0
        inj_note = f'（⚠️ 賽前傷兵快報：{p_name} 目前因傷列為 Out 確定缺陣，本戰只能在場邊西裝觀戰、無緣親自上場手刃舊主！）'
      elif prob <= 60:
        avail_mult = 0.55
        inj_note = f'（⚠️ 賽前傷兵快報：{p_name} 列為 {inj_st.get("status") or "GTD"}，預計上場機率 {prob}%，請留意開賽前最終名單）'

    eff_ats = round(ats_b * avail_mult, 2)
    eff_ou = round(ou_b * avail_mult, 2)
    if on_home:
      ats_home_raw += eff_ats
    else:
      ats_home_raw -= eff_ats
    ou_over_raw += eff_ou

    stat_recap = ''
    if game_boxscore and game_status in ('IN_PROGRESS', 'FINAL'):
      side_key = 'home' if on_home else 'away'
      stat_recap = _find_boxscore_stat_line(p_name, game_boxscore.get(side_key))

    items.append({
        'kind': 'REVENGE',
        'tier': tier,
        'badge_zh': badge_zh,
        'player': p_name,
        'team_abbr': cur_abbr,
        'former_abbr': ex_abbr,
        'title_zh': f'{p_name}（現效{cur_zh}）正面迎戰老東家{ex_zh}！',
        'body_zh': story_zh + inj_note,
        'betting_take_zh': take_zh if avail_mult > 0 else '因當事球星確定缺陣，模型已自動歸零「戰舊主」戰意加分，回歸純戰力評估。',
        'stat_recap_zh': stat_recap,
        'ats_impact_pts': eff_ats if on_home else -eff_ats,
        'ou_impact_pts': eff_ou,
    })

  # 2. Classic Franchise Rivalries & Superstar Gossip
  pair_key = frozenset({away_abbr, home_abbr})
  if pair_key in RIVALRY_CATALOG:
    r_badge, r_body, r_take, r_ou = RIVALRY_CATALOG[pair_key]
    ou_over_raw += r_ou
    items.append({
        'kind': 'RIVALRY',
        'tier': 'HIGHLIGHT',
        'badge_zh': r_badge,
        'player': '',
        'team_abbr': '',
        'former_abbr': '',
        'title_zh': f'{a_zh} vs {h_zh} 宿敵焦點話題戰',
        'body_zh': r_body,
        'betting_take_zh': r_take,
        'stat_recap_zh': '',
        'ats_impact_pts': 0.0,
        'ou_impact_pts': r_ou,
    })

  # 3. Dynamic Undefeated / Winless Pressure-Cooker & Beat-Writer Gossip Hooks
  def _parse_rec(rec: str) -> tuple[int, int]:
    if not rec or '-' not in rec:
      return 0, 0
    try:
      w_s, l_s = rec.split('-', 1)
      return int(w_s.strip()), int(l_s.strip())
    except ValueError:
      return 0, 0

  aw, al = _parse_rec(away_record)
  hw, hl = _parse_rec(home_record)
  if game_status != 'FINAL':
    if hw >= 3 and hl == 0:
      items.append({
          'kind': 'STREAK_GOSSIP',
          'tier': 'TREND',
          'badge_zh': f'👑 開季 {hw}-{hl} 不敗金身話題',
          'player': '',
          'team_abbr': home_abbr,
          'former_abbr': '',
          'title_zh': f'{h_zh}開季 {hw} 連勝全勝不敗，成全聯盟狙擊標靶！',
          'body_zh': f'{h_zh}目前維持 {hw} 勝 0 敗完美開局，休息室氣氛極佳，但也開始吸引大量散戶追捧與對手「破不敗金身」的高強度針對性備戰。',
          'betting_take_zh': '不敗強隊在主場容易被莊家多開 1～1.5 分「公眾信仰稅」，若讓分過深反需提防贏球輸盤。',
          'stat_recap_zh': '',
          'ats_impact_pts': 0.0,
          'ou_impact_pts': 0.0,
      })
    elif aw >= 3 and al == 0:
      items.append({
          'kind': 'STREAK_GOSSIP',
          'tier': 'TREND',
          'badge_zh': f'👑 客場挑戰開季 {aw}-{al} 連勝紀錄',
          'player': '',
          'team_abbr': away_abbr,
          'former_abbr': '',
          'title_zh': f'{a_zh}開季 {aw} 勝 0 敗氣勢如虹，作客踢館考驗成色',
          'body_zh': f'{a_zh}開季至今未嚐敗績（{aw}-{al}），客場作戰將面臨主隊球迷與裁判尺度的雙重壓力測試。',
          'betting_take_zh': '連勝球隊作客若遇淺盤或受讓反而具備不錯的抗壓韌性。',
          'stat_recap_zh': '',
          'ats_impact_pts': 0.0,
          'ou_impact_pts': 0.0,
      })
    if (hw == 0 and hl >= 4) or (aw == 0 and al >= 4):
      cold_zh = h_zh if (hw == 0 and hl >= 4) else a_zh
      cold_l = hl if (hw == 0 and hl >= 4) else al
      items.append({
          'kind': 'STREAK_GOSSIP',
          'tier': 'TREND',
          'badge_zh': f'🚨 開季 0-{cold_l} 休息室壓力鍋',
          'player': '',
          'team_abbr': home_abbr if (hw == 0 and hl >= 4) else away_abbr,
          'former_abbr': '',
          'title_zh': f'{cold_zh}開季苦吞 {cold_l} 連敗一勝難求，總教練與主將面臨媒體拷問！',
          'body_zh': f'開季連敗未開胡讓{cold_zh}休息室低氣壓籠罩、當地媒體交易流言四起，此戰勢必縮短輪替全力求止血首勝。',
          'betting_take_zh': '急欲開胡止敗的球隊開賽專注度通常拉滿，受讓時具備「哀兵必勝」反彈咬盤價值。',
          'stat_recap_zh': '',
          'ats_impact_pts': 0.18 if (hw == 0 and hl >= 4) else -0.18,
          'ou_impact_pts': 0.0,
      })

  # Attach up to 1 genuine drama/shock news item (exclude multi-team roundups & routine previews)
  _DRAMA_NEWS_KEYWORDS = (
      '交易', '恩怨', '不合', '開砲', '衝突', '禁賽', '手術', '報銷', '炸鍋', '復仇', '老東家',
      'Revenge', 'Feud', 'Suspend', 'Trade', 'Surgery', 'Locker Room',
  )
  if news_items and len(items) < 2:
    for nw in news_items:
      n_teams = nw.get('teams') or []
      if not n_teams or len(n_teams) > 2:
        continue
      if len(n_teams) == 2 and set(n_teams) != {away_abbr, home_abbr}:
        continue
      if len(n_teams) == 1 and n_teams[0] not in (away_abbr, home_abbr):
        continue
      title = str(nw.get('title') or '')
      if any(k in title for k in _DRAMA_NEWS_KEYWORDS) and not (len(n_teams) == 1 and ('老東家' in title or '復仇' in title or 'Revenge' in title)):
        items.append({
            'kind': 'NEWS_BUZZ',
            'tier': 'BUZZ',
            'badge_zh': '📰 場外重磅話題快訊',
            'player': '',
            'team_abbr': away_abbr if away_abbr in n_teams else home_abbr,
            'former_abbr': '',
            'title_zh': title,
            'body_zh': str(nw.get('summary') or title)[:160],
            'betting_take_zh': f"來源：{nw.get('source') or 'NBA 即時快訊'}（{nw.get('published_tw') or ''}）— 重大傷病或休息室風暴往往牽動臨場散戶資金流向。",
            'stat_recap_zh': '',
            'ats_impact_pts': 0.0,
            'ou_impact_pts': 0.0,
        })
        break

  # Clamp quantitative signals so narrative drama refines edges sensibly (±1.2 raw -> ~±0.50 weighted pts)
  ats_home_raw = max(-1.25, min(1.25, round(ats_home_raw, 2)))
  ou_over_raw = max(-1.10, min(1.35, round(ou_over_raw, 2)))

  has_revenge = any(x['kind'] == 'REVENGE' for x in items)
  has_rivalry = any(x['kind'] == 'RIVALRY' for x in items)
  headline_zh = items[0]['title_zh'] if items else ''
  short_badge_zh = items[0]['badge_zh'] if items else ''

  return {
      'has_drama': bool(items),
      'has_revenge': has_revenge,
      'has_rivalry': has_rivalry,
      'count': len(items),
      'short_badge_zh': short_badge_zh,
      'headline_zh': headline_zh,
      'ats_raw_home': ats_home_raw,
      'ou_raw_over': ou_over_raw,
      'items': items[:4],
  }
