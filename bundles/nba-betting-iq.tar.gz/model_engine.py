#!/usr/bin/env python3
"""Quantitative NBA Spread (ATS) & Over/Under Model + Post-Mortem & Self-Evolution Engine.

Design principles (Pattern 162 Rule 6 — Walk-Forward Validation, Zero Lookahead):
1. Strict chronological walk-forward simulation: when predicting games on `et_date`,
   ONLY games completed strictly BEFORE `et_date` and pre-game lines/BPI are visible.
2. Market-residual factor architecture: models mispricing relative to the sportsbook
   spread & total across 7 ATS factors and 6 O/U factors.
3. Post-mortem root-cause attribution: inspects quarter scores, 3PT%, FT attempts,
   rebounds, turnovers, B2B rest, and line movement on every graded game to classify
   why picks hit or missed.
4. Continuous weight & guardrail evolution: updates factor weights via empirical hit-rate
   multiplicative / gradient updates (automatically dampening noisy <48% factors toward 0
   and boosting >55% high-IC factors), and benchmarks Evolved Model vs Static v1.0 Baseline.
"""
from __future__ import annotations

import datetime as dt
import json
import math
import sqlite3
from typing import Any

import config
import db
import storylines
import teams

ATS_FACTOR_META: dict[str, dict[str, Any]] = {
    'line_steam': {
        'name_zh': '初盤→即時變盤聰明錢訊號',
        'desc_zh': '追蹤開盤至賽前讓分盤變動方向，捕捉主力資金 (Sharp Steam) 真實流向',
        'init_w': 0.52,
    },
    'form_ats': {
        'name_zh': '近期淨勝分與過盤動能',
        'desc_zh': '近 5 場實際過盤表現與攻守淨勝分趨勢',
        'init_w': 0.44,
    },
    'bounce_reversion': {
        'name_zh': '慘敗反彈／大勝過熱修正',
        'desc_zh': '前戰慘敗 >=14 分球隊次戰專注度反彈過盤效應，並避開前戰大勝 >=18 分之公眾追捧溢價',
        'init_w': 0.46,
    },
    'net_eff_resid': {
        'name_zh': '淨效率值＋主場優勢殘差',
        'desc_zh': '貝氏平滑後雙方場均淨勝分差（含主場 +2.2 分）對比莊家盤口乖離值',
        'init_w': 0.30,
    },
    'inflate_fade': {
        'name_zh': '雙位數深盤受讓保護',
        'desc_zh': '深盤讓分 (>=10.5) 第四節主力輪休與垃圾時間帶來的受讓過盤價值',
        'init_w': 0.45,
    },
    'bpi_gap': {
        'name_zh': 'ESPN BPI 勝率合理盤差',
        'desc_zh': 'ESPN BPI 賽前勝率推算合理讓分與目前盤口之差距（專用於賽前預測）',
        'init_w': 0.36,
    },
    'injury_edge': {
        'name_zh': '傷兵與 GTD 出賽成疑價差',
        'desc_zh': '雙方球星／先發缺陣與賽前決定 (Questionable) 尚未完全反映於盤口之戰力落差',
        'init_w': 0.48,
    },
    'revenge_drama': {
        'name_zh': '球星戰舊主與恩怨戰意戲碼',
        'desc_zh': '追蹤休賽季交易球星首度對決前東家 (Revenge Game) 與哀兵止敗之額外持球侵略性與戰意微調',
        'init_w': 0.42,
    },
}

OU_FACTOR_META: dict[str, dict[str, Any]] = {
    'ou_regression': {
        'name_zh': '極端大小分盤口均值回歸',
        'desc_zh': '超高總分盤 (>=237.5) 追高過熱回歸小分、超低盤 (<=218.5) 防守高估回歸大分',
        'init_w': 0.50,
    },
    'b2b_def_leak': {
        'name_zh': '背靠背防守疲勞失分效應',
        'desc_zh': '現代 NBA 背靠背球隊退防與外線輪轉下滑，反而推升對手得分效率偏向大分',
        'init_w': 0.48,
    },
    'pace_eff_gap': {
        'name_zh': '攻守節奏推估總分殘差',
        'desc_zh': '貝氏平滑後雙方場均得分與失分推估總分減去莊家大小分盤口',
        'init_w': 0.34,
    },
    'spread_script': {
        'name_zh': '比賽劇本（拉鋸犯規 vs 深盤降速）',
        'desc_zh': '極淺盤 (<=3.5) 末節犯規戰術與 OT 機率推升大分；懸殊深盤 (>=13.5) 末節消化時間偏小分',
        'init_w': 0.38,
    },
    'total_steam': {
        'name_zh': '大小分變盤資金方向',
        'desc_zh': '比較初盤總分與目前盤口變動幅度之順勢訊號',
        'init_w': 0.30,
    },
    'injury_total': {
        'name_zh': '核心持球／得分手缺陣修正',
        'desc_zh': '主力進攻發動機缺陣對團隊半場進攻效率之影響',
        'init_w': 0.40,
    },
    'drama_tempo': {
        'name_zh': '戰舊主飆分與宿敵肉搏節奏',
        'desc_zh': '球星打老東家高球權刷數據與世仇肢體吹判罰球對總分節奏之推升／壓抑效應',
        'init_w': 0.35,
    },
}

ERROR_TAG_LABELS: dict[str, str] = {
    '3PT_VARIANCE': '🔥 三分球極端手感變異',
    'GARBAGE_FOUL_OT': '⏱️ 末節犯規戰術／延長賽翻盤',
    'BLOWOUT_BENCH': '🪑 大比分垃圾時間替補咬盤',
    'B2B_COLLAPSE': '📉 背靠背體能與防守下滑',
    'MARKET_TRAP': '💰 盤口變盤與賽果背離（誘盤）',
    'MODEL_ON_TARGET': '🎯 模型核心因子精準命中',
}


def default_model_params() -> dict[str, Any]:
  return {
      'version': '1.0',
      'step_count': 0,
      'ats_weights': {k: v['init_w'] for k, v in ATS_FACTOR_META.items()},
      'ou_weights': {k: v['init_w'] for k, v in OU_FACTOR_META.items()},
      'ats_stats': {k: {'hits': 0, 'trials': 0, 'ema_gain': 0.0} for k in ATS_FACTOR_META},
      'ou_stats': {k: {'hits': 0, 'trials': 0, 'ema_gain': 0.0} for k in OU_FACTOR_META},
      'thresholds': {
          'strong_ats': 1.55,
          'lean_ats': 0.95,
          'strong_ou': 1.85,
          'lean_ou': 1.15,
      },
      'error_counts': {},
      'baseline_comparison': {
          'static_w': 0, 'static_l': 0, 'static_win_rate': 50.0,
          'evolved_w': 0, 'evolved_l': 0, 'evolved_win_rate': 50.0,
      },
      'guardrails': [
          {
              'id': 'vig_filter',
              'title': '水錢損益兩平過濾護欄 (52.38% Breakeven)',
              'rule': '當模型預估優勢 Edge 低於門檻時強制標記「觀望不碰 (PASS)」，拒絕無優勢硬下被莊家抽水消耗本金。',
              'active': True,
          }
      ],
  }


def _clamp(v: float, lo: float, hi: float) -> float:
  return max(lo, min(hi, v))


def _prob_to_margin(prob_pct: float) -> float:
  p = _clamp(prob_pct / 100.0, 0.03, 0.97)
  return (11.8 / 1.702) * math.log(p / (1.0 - p))


def _build_prior_team_history(prior_games: list[sqlite3.Row]) -> dict[str, dict[str, Any]]:
  hist: dict[str, dict[str, Any]] = {}
  for ab in teams.TEAMS:
    hist[ab] = {
        'gp': 0, 'w': 0, 'l': 0,
        'pts_for': 0, 'pts_against': 0,
        'recent_margins': [], 'recent_totals': [],
        'ats_results': [], 'ou_results': [],
        'dates_played': [],
    }
  for g in prior_games:
    if g['status'] != 'FINAL' or g['home_score'] is None or g['away_score'] is None:
      continue
    h, a = g['home_abbr'], g['away_abbr']
    hs, as_ = int(g['home_score']), int(g['away_score'])
    d = dt.date.fromisoformat(g['et_date'])
    if h in hist:
      hh = hist[h]
      hh['gp'] += 1
      hh['w'] += 1 if hs > as_ else 0
      hh['l'] += 1 if hs < as_ else 0
      hh['pts_for'] += hs
      hh['pts_against'] += as_
      hh['recent_margins'].append(hs - as_)
      hh['recent_totals'].append(hs + as_)
      if g['ats_winner'] in ('HOME', 'AWAY'):
        hh['ats_results'].append(1 if g['ats_winner'] == 'HOME' else -1)
      if g['ou_result'] in ('OVER', 'UNDER'):
        hh['ou_results'].append(1 if g['ou_result'] == 'OVER' else -1)
      hh['dates_played'].append((d, 'H'))
    if a in hist:
      aa = hist[a]
      aa['gp'] += 1
      aa['w'] += 1 if as_ > hs else 0
      aa['l'] += 1 if as_ < hs else 0
      aa['pts_for'] += as_
      aa['pts_against'] += hs
      aa['recent_margins'].append(as_ - hs)
      aa['recent_totals'].append(hs + as_)
      if g['ats_winner'] in ('HOME', 'AWAY'):
        aa['ats_results'].append(1 if g['ats_winner'] == 'AWAY' else -1)
      if g['ou_result'] in ('OVER', 'UNDER'):
        aa['ou_results'].append(1 if g['ou_result'] == 'OVER' else -1)
      aa['dates_played'].append((d, 'A'))
  return hist


def _rest_profile(dates_played: list[tuple[dt.date, str]], target_date: dt.date) -> dict[str, Any]:
  if not dates_played:
    return {'rest_days': 3, 'is_b2b': False, 'three_in_four': False, 'label': '休足開季'}
  last_d, _ = dates_played[-1]
  gap = (target_date - last_d).days
  rest_days = max(0, gap - 1)
  is_b2b = (gap == 1)
  recent_4d = sum(1 for d, _ in dates_played if 1 <= (target_date - d).days <= 3)
  three_in_four = (recent_4d >= 2)
  if is_b2b and three_in_four:
    label = '⚠️ 背靠背＋4天3戰'
  elif is_b2b:
    label = '⚠️ 背靠背 (B2B)'
  elif three_in_four:
    label = '⚡ 4天3戰'
  elif rest_days >= 2:
    label = f'🔋 休 {rest_days} 天'
  else:
    label = '正常休 1 天'
  return {'rest_days': rest_days, 'is_b2b': is_b2b, 'three_in_four': three_in_four, 'label': label}


def _team_injury_burden(injuries_for_team: list[dict[str, Any]]) -> tuple[float, float, int]:
  sp_loss = 0.0
  tot_drag = 0.0
  gtd_stars = 0
  for inj in injuries_for_team:
    prob_miss = (100 - int(inj.get('play_prob_next') or 0)) / 100.0
    pts = float(inj.get('est_spread_pts') or 0.5)
    t_pts = float(inj.get('est_total_pts') or -0.2)
    ret = str(inj.get('return_date') or '')
    long_c = str(inj.get('long_comment') or '').lower()
    if 'season' in long_c or 'months' in long_c or (ret and ret > '2026-12-01'):
      resid_mult = 0.15
    elif 0.15 <= prob_miss <= 0.85:
      resid_mult = 0.45
      if inj.get('impact_tier') in ('STAR', 'STARTER'):
        gtd_stars += 1
    else:
      resid_mult = 0.32
    sp_loss += pts * prob_miss * resid_mult
    tot_drag += t_pts * prob_miss * resid_mult
  return round(min(sp_loss, 5.5), 2), round(_clamp(tot_drag, -4.5, 2.5), 2), gtd_stars


def score_game(
    g: dict[str, Any] | sqlite3.Row,
    prior_hist: dict[str, dict[str, Any]],
    standings_map: dict[str, dict[str, Any]],
    injuries_by_team: dict[str, list[dict[str, Any]]],
    params: dict[str, Any],
    use_live_injuries: bool = False,
    roster_by_team: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
  """Computes pre-game ATS & O/U factor signals, edge, pick, confidence, and rationale."""
  gd = dict(g)
  home = gd['home_abbr']
  away = gd['away_abbr']
  et_d = dt.date.fromisoformat(gd['et_date'])

  book_sp = gd.get('close_spread_home')
  open_sp = gd.get('open_spread_home')
  book_tot = gd.get('close_total')
  open_tot = gd.get('open_total')

  hh = prior_hist.get(home) or {'gp': 0, 'pts_for': 0, 'pts_against': 0, 'recent_margins': [], 'ats_results': [], 'ou_results': [], 'dates_played': []}
  ah = prior_hist.get(away) or {'gp': 0, 'pts_for': 0, 'pts_against': 0, 'recent_margins': [], 'ats_results': [], 'ou_results': [], 'dates_played': []}

  tot_gp = sum(v['gp'] for v in prior_hist.values())
  league_ppg = (sum(v['pts_for'] for v in prior_hist.values()) / tot_gp) if tot_gp >= 10 else 115.2

  def _team_eff(th: dict[str, Any], ab: str) -> tuple[float, float, float]:
    gp = th['gp']
    if gp > 0:
      raw_pf = th['pts_for'] / gp
      raw_pa = th['pts_against'] / gp
    elif use_live_injuries and ab in standings_map:
      raw_pf = float(standings_map[ab].get('ppg') or league_ppg)
      raw_pa = float(standings_map[ab].get('opp_ppg') or league_ppg)
    else:
      raw_pf, raw_pa = league_ppg, league_ppg
    shrink = gp / (gp + 5.0) if gp > 0 else (0.35 if (use_live_injuries and ab in standings_map) else 0.0)
    pf = league_ppg + shrink * (raw_pf - league_ppg)
    pa = league_ppg + shrink * (raw_pa - league_ppg)
    return pf, pa, pf - pa

  h_pf, h_pa, h_net = _team_eff(hh, home)
  a_pf, a_pa, a_net = _team_eff(ah, away)

  h_rest = _rest_profile(hh['dates_played'], et_d)
  a_rest = _rest_profile(ah['dates_played'], et_d)

  fund_margin = (h_net - a_net) + 2.2
  mkt_margin = (-float(book_sp)) if book_sp is not None else fund_margin
  fund_total = ((h_pf + a_pa) * 0.5 + (a_pf + h_pa) * 0.5)
  mkt_total = float(book_tot) if (book_tot is not None and book_tot > 0) else fund_total

  # --- 7 ATS Factors (positive = favors HOME covering; negative = favors AWAY covering) ---
  # 1. Opening -> Current line steam (empirically 58.3% directional accuracy!)
  if open_sp is not None and book_sp is not None:
    move_toward_home = float(open_sp) - float(book_sp)
    f_steam = _clamp(move_toward_home * 0.95, -3.4, 3.4)
  else:
    f_steam = 0.0

  # 2. Recent 5-game form & ATS cover momentum
  def _form_score(th: dict[str, Any]) -> float:
    rm = th['recent_margins'][-5:]
    ra = th['ats_results'][-5:]
    m_avg = (sum(rm) / len(rm)) if rm else 0.0
    a_avg = (sum(ra) / len(ra)) if ra else 0.0
    return 0.11 * m_avg + 0.95 * a_avg

  f_form = _clamp(_form_score(hh) - _form_score(ah), -2.8, 2.8)

  # 3. Last-game Blowout Bounce-Back / Public Overreaction Reversion (+ rest synergy)
  def _bounce_val(th: dict[str, Any], rest_obj: dict[str, Any]) -> float:
    val = 0.0
    if th['recent_margins']:
      last_m = th['recent_margins'][-1]
      if last_m <= -14:
        val += 1.35  # Embarrassed team bounce-back focus
      elif last_m >= 18:
        val -= 1.05  # Public over-inflates blowout winner
    if rest_obj['is_b2b'] and rest_obj['three_in_four']:
      val -= 1.10
    elif rest_obj['rest_days'] >= 2:
      val += 0.35
    return val

  f_bounce = _clamp(_bounce_val(hh, h_rest) - _bounce_val(ah, a_rest), -3.0, 3.0)

  # 4. Net efficiency residual vs market spread
  f_net = _clamp((fund_margin - mkt_margin) * 0.55, -3.5, 3.5)

  # 5. Double-digit favorite inflation fade (favors underdog when |spread| >= 10.5)
  f_fade = 0.0
  if book_sp is not None and abs(float(book_sp)) >= 10.5:
    excess = min(abs(float(book_sp)) - 9.0, 6.5) * 0.48
    f_fade = -excess if float(book_sp) < 0 else +excess

  # 6. ESPN BPI fair-margin gap (active on upcoming games)
  bpi_pct = gd.get('bpi_home_win_pct')
  f_bpi = _clamp((_prob_to_margin(float(bpi_pct)) - mkt_margin) * 0.65, -3.8, 3.8) if bpi_pct is not None else 0.0

  # 7. Live injuries & GTD uncertainty
  gtd_uncertainty = 0
  if use_live_injuries:
    h_inj_loss, h_tot_drag, h_gtd = _team_injury_burden(injuries_by_team.get(home, []))
    a_inj_loss, a_tot_drag, a_gtd = _team_injury_burden(injuries_by_team.get(away, []))
    f_inj = _clamp(a_inj_loss - h_inj_loss, -4.5, 4.5)
    o_inj = _clamp(h_tot_drag + a_tot_drag, -4.5, 2.5)
    gtd_uncertainty = h_gtd + a_gtd
  else:
    f_inj = 0.0
    o_inj = 0.0

  # 8. Revenge Games ("打老東家") & Rivalry / Locker-Room Motivation Signal
  drama_eval = storylines.evaluate_game_storylines(
      away,
      home,
      roster_by_team=roster_by_team,
      injuries_by_team=injuries_by_team if use_live_injuries else None,
      away_record=str(gd.get('away_record') or ''),
      home_record=str(gd.get('home_record') or ''),
      game_status=str(gd.get('status') or 'SCHEDULED'),
  )
  f_drama = float(drama_eval['ats_raw_home'])
  o_drama = float(drama_eval['ou_raw_over'])

  ats_raw = {
      'line_steam': round(f_steam, 2),
      'form_ats': round(f_form, 2),
      'bounce_reversion': round(f_bounce, 2),
      'net_eff_resid': round(f_net, 2),
      'inflate_fade': round(f_fade, 2),
      'bpi_gap': round(f_bpi, 2),
      'injury_edge': round(f_inj, 2),
      'revenge_drama': round(f_drama, 2),
  }
  ats_w = params['ats_weights']
  ats_contribs = {k: round(ats_raw[k] * float(ats_w.get(k, 0.35)), 2) for k in ATS_FACTOR_META}
  ats_alpha_home = round(sum(ats_contribs.values()), 2)

  pred_margin_home = round(mkt_margin + ats_alpha_home, 2)
  fair_spread_home = round(-pred_margin_home, 2)

  # --- 6 O/U Factors (positive = favors OVER; negative = favors UNDER) ---
  # 1. Extreme total regression
  o_reg = 0.0
  if mkt_total >= 237.5:
    o_reg = -_clamp((mkt_total - 235.0) * 0.52, 0.6, 3.4)
  elif mkt_total <= 218.5:
    o_reg = +_clamp((220.5 - mkt_total) * 0.48, 0.6, 3.2)

  # 2. Modern NBA B2B tired-defense leak (tired perimeter/transition defense yields higher opponent ORTG -> Over!)
  b2b_cnt = (1 if h_rest['is_b2b'] else 0) + (1 if a_rest['is_b2b'] else 0)
  o_b2b_leak = +1.75 * b2b_cnt if b2b_cnt > 0 else (-0.45 if (h_rest['rest_days'] >= 2 and a_rest['rest_days'] >= 2) else 0.0)

  # 3. Pace & scoring efficiency residual
  o_pace = _clamp((fund_total - mkt_total) * 0.55, -4.5, 4.5)

  # 4. Game script (close game late fouls vs huge blowout 4Q bench clock run-out)
  o_script = 0.0
  if book_sp is not None:
    abs_sp = abs(float(book_sp))
    if abs_sp <= 3.5:
      o_script = +1.35
    elif abs_sp >= 13.5:
      o_script = -1.95

  # 5. Total line steam
  o_steam = _clamp((float(book_tot) - float(open_tot)) * 0.65, -2.8, 2.8) if (open_tot and book_tot) else 0.0

  ou_raw = {
      'ou_regression': round(o_reg, 2),
      'b2b_def_leak': round(o_b2b_leak, 2),
      'pace_eff_gap': round(o_pace, 2),
      'spread_script': round(o_script, 2),
      'total_steam': round(o_steam, 2),
      'injury_total': round(o_inj, 2),
      'drama_tempo': round(o_drama, 2),
  }
  ou_w = params['ou_weights']
  ou_contribs = {k: round(ou_raw[k] * float(ou_w.get(k, 0.35)), 2) for k in OU_FACTOR_META}
  ou_alpha = round(sum(ou_contribs.values()), 2)
  pred_total = round(mkt_total + ou_alpha, 2)

  # --- Selectivity Thresholds & Active Guardrails ---
  th = params['thresholds']
  triggered_guardrails: list[str] = []
  eff_ats_alpha = ats_alpha_home
  eff_ou_alpha = ou_alpha

  if gtd_uncertainty >= 2:
    eff_ats_alpha *= 0.76
    triggered_guardrails.append('雙方多名主力 GTD 賽前決定，自動折減優勢 24% 防範臨場輪休突襲')

  if f_steam * eff_ats_alpha < 0 and abs(f_steam) >= 1.2 and abs(eff_ats_alpha) < 2.1:
    eff_ats_alpha *= 0.60
    triggered_guardrails.append('即時變盤資金方向與初階指標衝突，啟動防誘盤護欄提高出手門檻')

  ats_edge = round(abs(eff_ats_alpha), 2) if book_sp is not None else 0.0
  if book_sp is None or ats_edge < float(th['lean_ats']):
    ats_pick, ats_tier = 'PASS', 'PASS'
  else:
    ats_pick = 'HOME' if eff_ats_alpha > 0 else 'AWAY'
    ats_tier = 'STRONG' if ats_edge >= float(th['strong_ats']) else 'LEAN'

  ou_edge = round(abs(eff_ou_alpha), 2) if (book_tot is not None and book_tot > 0) else 0.0
  if not book_tot or ou_edge < float(th['lean_ou']):
    ou_pick, ou_tier = 'PASS', 'PASS'
  else:
    ou_pick = 'OVER' if eff_ou_alpha > 0 else 'UNDER'
    ou_tier = 'STRONG' if ou_edge >= float(th['strong_ou']) else 'LEAN'

  ats_conf = int(round(_clamp(52.0 + ats_edge * 9.5, 52, 89))) if ats_pick != 'PASS' else 50
  ou_conf = int(round(_clamp(52.0 + ou_edge * 8.2, 52, 88))) if ou_pick != 'PASS' else 50

  rec_u_ats = 2.0 if ats_tier == 'STRONG' and ats_edge >= 2.3 else (1.5 if ats_tier == 'STRONG' else (1.0 if ats_tier == 'LEAN' else 0.0))
  rec_u_ou = 2.0 if ou_tier == 'STRONG' and ou_edge >= 2.6 else (1.5 if ou_tier == 'STRONG' else (1.0 if ou_tier == 'LEAN' else 0.0))

  h_zh = teams.team_info(home)['zh']
  a_zh = teams.team_info(away)['zh']

  # --- Two-Stage (18:00 Early -> 23:00 Final) Line-Movement Re-Analysis ---
  lock_s = str(gd.get('odds_locked_tw') or '')
  odds_stage = 'final' if ('定盤' in lock_s or '23:00' in lock_s) else ('early' if ('初盤' in lock_s or '18:00' in lock_s) else '')
  sp_delta_home = round(float(open_sp) - float(book_sp), 1) if (open_sp is not None and book_sp is not None) else 0.0
  tot_delta = round(float(book_tot) - float(open_tot), 1) if (open_tot and book_tot) else 0.0

  # Compute Pass-1 (18:00 Early Line, zero steam) baseline pick for direct Pass-1 vs Pass-2 comparison
  early_ats_pick, early_ats_tier = ats_pick, ats_tier
  if open_sp is not None:
    open_mkt_m = -float(open_sp)
    open_f_net = _clamp((fund_margin - open_mkt_m) * 0.55, -3.5, 3.5)
    open_f_fade = 0.0
    if abs(float(open_sp)) >= 10.5:
      ex_pts = min(abs(float(open_sp)) - 9.0, 6.5) * 0.48
      open_f_fade = -ex_pts if float(open_sp) < 0 else +ex_pts
    open_f_bpi = _clamp((_prob_to_margin(float(bpi_pct)) - open_mkt_m) * 0.65, -3.8, 3.8) if bpi_pct is not None else 0.0
    early_raw = dict(ats_raw, line_steam=0.0, net_eff_resid=round(open_f_net, 2), inflate_fade=round(open_f_fade, 2), bpi_gap=round(open_f_bpi, 2))
    early_alpha = sum(round(early_raw[k] * float(ats_w.get(k, 0.35)), 2) for k in ATS_FACTOR_META)
    if gtd_uncertainty >= 2:
      early_alpha *= 0.76
    if abs(early_alpha) < float(th['lean_ats']):
      early_ats_pick, early_ats_tier = 'PASS', 'PASS'
    else:
      early_ats_pick = 'HOME' if early_alpha > 0 else 'AWAY'
      early_ats_tier = 'STRONG' if abs(early_alpha) >= float(th['strong_ats']) else 'LEAN'

  early_ou_pick, early_ou_tier = ou_pick, ou_tier
  if open_tot and float(open_tot) > 0:
    open_mt = float(open_tot)
    open_o_reg = -_clamp((open_mt - 235.0) * 0.52, 0.6, 3.4) if open_mt >= 237.5 else (+_clamp((220.5 - open_mt) * 0.48, 0.6, 3.2) if open_mt <= 218.5 else 0.0)
    open_o_pace = _clamp((fund_total - open_mt) * 0.55, -4.5, 4.5)
    open_o_scr = (+1.35 if abs(float(open_sp)) <= 3.5 else (-1.95 if abs(float(open_sp)) >= 13.5 else 0.0)) if open_sp is not None else o_script
    early_ou_raw = dict(ou_raw, total_steam=0.0, ou_regression=round(open_o_reg, 2), pace_eff_gap=round(open_o_pace, 2), spread_script=round(open_o_scr, 2))
    early_ou_a = sum(round(early_ou_raw[k] * float(ou_w.get(k, 0.35)), 2) for k in OU_FACTOR_META)
    if abs(early_ou_a) < float(th['lean_ou']):
      early_ou_pick, early_ou_tier = 'PASS', 'PASS'
    else:
      early_ou_pick = 'OVER' if early_ou_a > 0 else 'UNDER'
      early_ou_tier = 'STRONG' if abs(early_ou_a) >= float(th['strong_ou']) else 'LEAN'

  move_parts: list[str] = []
  if abs(sp_delta_home) >= 0.5:
    steam_team = h_zh if sp_delta_home > 0 else a_zh
    move_parts.append(f'讓分由 {open_sp:+.1f} 變為 {book_sp:+.1f}（資金往{steam_team}推升 {abs(sp_delta_home):.1f} 分）')
  if abs(tot_delta) >= 0.5:
    move_parts.append(f'大小分由 {open_tot:.1f} {"調高至" if tot_delta > 0 else "下修至"} {book_tot:.1f}（{tot_delta:+.1f} 分）')

  if move_parts:
    verdict_shift = ''
    if early_ats_pick != ats_pick:
      if ats_pick == 'PASS':
        verdict_shift = '；變盤已吃掉早盤價差（或與初析逆向），二輪重析轉為「觀望不碰」保護本金'
      elif early_ats_pick == 'PASS':
        pick_zh = h_zh if ats_pick == 'HOME' else a_zh
        verdict_shift = f'；隨晚間盤勢明朗，二輪重析新浮現【{pick_zh}】正期望值買點'
      else:
        pick_zh = h_zh if ats_pick == 'HOME' else a_zh
        verdict_shift = f'；晚間盤勢明顯轉向，二輪重析改向【{pick_zh}】'
    elif ats_pick != 'PASS':
      pick_zh = h_zh if ats_pick == 'HOME' else a_zh
      aligned = (ats_pick == 'HOME' and sp_delta_home > 0) or (ats_pick == 'AWAY' and sp_delta_home < 0)
      if aligned:
        verdict_shift = f'；聰明錢流向與 18:00 首輪方向一致，強化【{pick_zh}】信心'
      elif early_ats_tier != ats_tier:
        verdict_shift = f'；依變盤幅度微調【{pick_zh}】推薦強度（{early_ats_tier}→{ats_tier}）'
    reanalysis_zh = '📈 盤勢變化重析（18:00→23:00）：' + '、'.join(move_parts) + verdict_shift + '。'
  elif odds_stage == 'final' and book_sp is not None:
    reanalysis_zh = '🔒 23:00 尾盤定盤重析：18:00 初盤至 23:00 定盤盤勢持平無異常變盤，維持首輪量化評估結論。'
  elif odds_stage == 'early' and book_sp is not None:
    reanalysis_zh = '🕕 18:00 初盤首輪解盤完成；今晚 23:00 將再抓最後一次尾盤，依 5 小時盤勢變化執行第二輪重析。'
  else:
    reanalysis_zh = ''

  reasons: list[str] = []
  if move_parts:
    reasons.append('晚間變盤：' + '、'.join(move_parts))
  top_ats = sorted(ats_contribs.items(), key=lambda kv: abs(kv[1]), reverse=True)
  for fk, fv in top_ats[:2]:
    if abs(fv) < 0.20:
      continue
    side_zh = h_zh if fv > 0 else a_zh
    reasons.append(f"{ATS_FACTOR_META[fk]['name_zh']}支持{side_zh} ({fv:+.2f}分)")
  top_ou = sorted(ou_contribs.items(), key=lambda kv: abs(kv[1]), reverse=True)
  if top_ou and abs(top_ou[0][1]) >= 0.30:
    ou_dir = '大分' if top_ou[0][1] > 0 else '小分'
    reasons.append(f"{OU_FACTOR_META[top_ou[0][0]]['name_zh']}傾向{ou_dir} ({top_ou[0][1]:+.2f}分)")
  if not reasons:
    reasons.append('目前莊家讓分與大小分定價貼近合理效率值，無明顯正期望值 (+EV) 缺口，建議觀望不碰。')

  return {
      'game_id': gd['game_id'],
      'et_date': gd['et_date'],
      'tw_date': gd['tw_date'],
      'model_version': f"v{params['version']}",
      'pred_margin_home': pred_margin_home,
      'fair_spread_home': fair_spread_home,
      'book_spread_home': book_sp,
      'ats_edge': ats_edge,
      'ats_pick': ats_pick,
      'ats_lean_side': 'HOME' if eff_ats_alpha >= 0 else 'AWAY',
      'ats_conf': ats_conf,
      'ats_tier': ats_tier,
      'pred_total': pred_total,
      'book_total': book_tot,
      'ou_edge': ou_edge,
      'ou_pick': ou_pick,
      'ou_lean_side': 'OVER' if eff_ou_alpha >= 0 else 'UNDER',
      'ou_conf': ou_conf,
      'ou_tier': ou_tier,
      'rec_units_ats': rec_u_ats,
      'rec_units_ou': rec_u_ou,
      'rationale_zh': '；'.join(reasons) + '。',
      'factors': {
          'ats_raw': ats_raw,
          'ats_contribs': ats_contribs,
          'ou_raw': ou_raw,
          'ou_contribs': ou_contribs,
          'home_rest': h_rest,
          'away_rest': a_rest,
          'home_proj_ppg': round((h_pf + a_pa) * 0.5, 1),
          'away_proj_ppg': round((a_pf + h_pa) * 0.5, 1),
          'line_move': {
              'stage': odds_stage,
              'spread_delta_home': sp_delta_home,
              'total_delta': tot_delta,
              'early_ats_pick': early_ats_pick,
              'early_ats_tier': early_ats_tier,
              'early_ou_pick': early_ou_pick,
              'early_ou_tier': early_ou_tier,
              'reanalysis_zh': reanalysis_zh,
          },
      },
      'guardrails': triggered_guardrails,
  }


def _parse_pct(val: Any) -> float | None:
  if val is None or val == '':
    return None
  try:
    return float(str(val).replace('%', '').strip())
  except ValueError:
    return None


def _parse_made_att(val: Any) -> tuple[int, int]:
  if not val or '-' not in str(val):
    return 0, 0
  p = str(val).split('-', 1)
  try:
    return int(p[0]), int(p[1])
  except ValueError:
    return 0, 0


def diagnose_finished_game(g: sqlite3.Row, pred: dict[str, Any]) -> tuple[str, str, str, list[str]]:
  ats_win_side = g['ats_winner']
  ou_win_side = g['ou_result']
  ats_pick = pred['ats_pick']
  ou_pick = pred['ou_pick']

  if ats_pick == 'PASS' or not ats_win_side:
    ats_res = 'PASS' if ats_pick == 'PASS' else None
  elif ats_win_side == 'PUSH':
    ats_res = 'PUSH'
  elif ats_pick == ats_win_side:
    ats_res = 'WIN'
  else:
    ats_res = 'LOSS'

  if ou_pick == 'PASS' or not ou_win_side:
    ou_res = 'PASS' if ou_pick == 'PASS' else None
  elif ou_win_side == 'PUSH':
    ou_res = 'PUSH'
  elif ou_pick == ou_win_side:
    ou_res = 'WIN'
  else:
    ou_res = 'LOSS'

  h_zh = teams.team_info(g['home_abbr'])['zh']
  a_zh = teams.team_info(g['away_abbr'])['zh']
  try:
    box = json.loads(g['boxscore_json'] or '{}')
  except ValueError:
    box = {}
  try:
    hq = json.loads(g['home_q_scores'] or '[]')
    aq = json.loads(g['away_q_scores'] or '[]')
  except ValueError:
    hq, aq = [], []

  hbox = box.get('home') or {}
  abox = box.get('away') or {}
  h3p = _parse_pct(hbox.get('threePointFieldGoalPct'))
  a3p = _parse_pct(abox.get('threePointFieldGoalPct'))
  _, h_fta = _parse_made_att(hbox.get('freeThrowsMade-freeThrowsAttempted'))
  _, a_fta = _parse_made_att(abox.get('freeThrowsMade-freeThrowsAttempted'))

  tags: list[str] = []
  notes: list[str] = []

  is_ot = len(hq) > 4 or 'OT' in str(g['status_detail'] or '').upper()
  if is_ot:
    tags.append('GARBAGE_FOUL_OT')
    notes.append(f"進入延長賽（共 {len(hq)} 節），額外時間推升總分至 {g['total_points']} 分並牽動盤口")

  if h3p is not None and a3p is not None:
    if abs(h3p - a3p) >= 11.0 or h3p >= 45.0 or a3p >= 45.0 or h3p <= 26.0 or a3p <= 26.0:
      tags.append('3PT_VARIANCE')
      notes.append(f"外線手感出現顯著變異（{h_zh} 三分 {h3p:.0f}% vs {a_zh} {a3p:.0f}%）")

  if len(hq) >= 4 and len(aq) >= 4 and not is_ot:
    q4_pts = int(hq[3]) + int(aq[3])
    q4_diff = int(hq[3]) - int(aq[3])
    pre_q4_diff = sum(int(x) for x in hq[:3]) - sum(int(x) for x in aq[:3])
    if q4_pts >= 66 or (h_fta + a_fta) >= 56:
      if 'GARBAGE_FOUL_OT' not in tags:
        tags.append('GARBAGE_FOUL_OT')
      notes.append(f"末節單節合轟 {q4_pts} 分（全場 {h_fta + a_fta} 罰），犯規戰術拉高總分")
    elif abs(pre_q4_diff) >= 18 and abs(q4_diff) >= 8 and (pre_q4_diff * q4_diff < 0):
      tags.append('BLOWOUT_BENCH')
      notes.append(f"前三節分差達 {abs(pre_q4_diff)} 分進入垃圾時間，末節替補追回 {abs(q4_diff)} 分咬盤")

  fac = pred.get('factors') or {}
  hr = (fac.get('home_rest') or {}).get('is_b2b')
  ar = (fac.get('away_rest') or {}).get('is_b2b')
  if (hr or ar) and ((g['ou_margin'] or 0) > 6 or abs(g['margin_home'] or 0) >= 12):
    tags.append('B2B_COLLAPSE')
    tired_zh = h_zh if hr else a_zh
    notes.append(f"{tired_zh}背靠背出賽退防效率下滑，影響下半場比分走勢")

  if g['open_spread_home'] is not None and g['close_spread_home'] is not None:
    move = float(g['open_spread_home']) - float(g['close_spread_home'])
    if abs(move) >= 1.5 and g['ats_cover_margin'] is not None:
      if (move > 0 and float(g['ats_cover_margin']) < 0) or (move < 0 and float(g['ats_cover_margin']) > 0):
        tags.append('MARKET_TRAP')
        notes.append(f"盤口從 {g['open_spread_home']:+.1f} 變至 {g['close_spread_home']:+.1f}，賽果反向開出")

  if (ats_res == 'WIN' or ou_res == 'WIN') and ats_res != 'LOSS' and ou_res != 'LOSS':
    tags.insert(0, 'MODEL_ON_TARGET')
    notes.insert(0, '模型核心因子與實際比賽節奏吻合')

  if not notes:
    notes.append(f"終場 {a_zh} {g['away_score']} : {g['home_score']} {h_zh}（分差 {g['margin_home']:+d}，總分 {g['total_points']}）")

  return ats_res or '', ou_res or '', '；'.join(notes[:3]) + '。', tags[:4]


def run_walk_forward_and_predict(conn: sqlite3.Connection) -> dict[str, Any]:
  """Replays completed games chronologically to evolve weights, benchmarks vs static v1.0, and predicts upcoming games."""
  now_str = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S')
  all_games = conn.execute(
      'SELECT * FROM games ORDER BY et_date ASC, tipoff_utc ASC, game_id ASC'
  ).fetchall()

  standings_rows = conn.execute('SELECT * FROM team_stats').fetchall()
  standings_map = {r['abbr']: dict(r) for r in standings_rows}

  inj_rows = conn.execute('SELECT * FROM injuries').fetchall()
  injuries_by_team: dict[str, list[dict[str, Any]]] = {}
  for ir in inj_rows:
    injuries_by_team.setdefault(ir['team_abbr'], []).append(dict(ir))

  roster_by_team: dict[str, list[dict[str, Any]]] = {}
  try:
    for rr in conn.execute('SELECT * FROM roster_players').fetchall():
      roster_by_team.setdefault(rr['team_abbr'], []).append(dict(rr))
  except sqlite3.OperationalError:
    pass

  params = default_model_params()
  # Naive uncalibrated v1.0 baseline (equal flat weights, low selectivity threshold) to prove evolution value!
  naive_params = default_model_params()
  naive_params['ats_weights'] = {k: 0.35 for k in ATS_FACTOR_META}
  naive_params['ou_weights'] = {k: 0.35 for k in OU_FACTOR_META}
  naive_params['thresholds'] = {'strong_ats': 0.8, 'lean_ats': 0.4, 'strong_ou': 1.0, 'lean_ou': 0.5}

  conn.execute('DELETE FROM evolution_log')

  by_date: dict[str, list[sqlite3.Row]] = {}
  for g in all_games:
    by_date.setdefault(g['et_date'], []).append(g)

  completed_so_far: list[sqlite3.Row] = []
  cum_strong_w = cum_strong_l = 0
  cum_rec_w = cum_rec_l = 0
  naive_w = naive_l = 0
  minor_ver = 0

  for et_date in sorted(by_date.keys()):
    day_games = by_date[et_date]
    has_final = any(g['status'] == 'FINAL' for g in day_games)
    is_live_or_future = any(g['status'] != 'FINAL' for g in day_games)
    prior_hist = _build_prior_team_history(completed_so_far)

    day_preds: list[tuple[sqlite3.Row, dict[str, Any]]] = []
    for g in day_games:
      use_live_inj = (g['status'] != 'FINAL')
      pred = score_game(
          g, prior_hist, standings_map, injuries_by_team, params,
          use_live_injuries=use_live_inj, roster_by_team=roster_by_team,
      )
      day_preds.append((g, pred))
      if g['status'] == 'FINAL':
        # Benchmark against naive unshrunk raw PPG/margin bettor (no market-residual learning or guardrails)
        hh_n = prior_hist.get(g['home_abbr']) or {'gp': 0, 'pts_for': 0, 'pts_against': 0}
        ah_n = prior_hist.get(g['away_abbr']) or {'gp': 0, 'pts_for': 0, 'pts_against': 0}
        if hh_n['gp'] > 0 and ah_n['gp'] > 0 and g['close_spread_home'] is not None:
          raw_h_net = (hh_n['pts_for'] - hh_n['pts_against']) / hh_n['gp']
          raw_a_net = (ah_n['pts_for'] - ah_n['pts_against']) / ah_n['gp']
          naive_ats = 'HOME' if (raw_h_net - raw_a_net + 2.5) + float(g['close_spread_home']) > 0 else 'AWAY'
          if g['ats_winner'] in ('HOME', 'AWAY'):
            if naive_ats == g['ats_winner']:
              naive_w += 1
            else:
              naive_l += 1
        if hh_n['gp'] > 0 and ah_n['gp'] > 0 and g['close_total']:
          raw_tot = (hh_n['pts_for'] + hh_n['pts_against']) / (2 * hh_n['gp']) + (ah_n['pts_for'] + ah_n['pts_against']) / (2 * ah_n['gp'])
          naive_ou = 'OVER' if raw_tot > float(g['close_total']) else 'UNDER'
          if g['ou_result'] in ('OVER', 'UNDER'):
            if naive_ou == g['ou_result']:
              naive_w += 1
            else:
              naive_l += 1

    day_ats_w = day_ats_l = day_ou_w = day_ou_l = 0
    graded_cnt = 0
    weight_deltas: dict[str, float] = {}

    for g, pred in day_preds:
      ats_res, ou_res, pm_zh, err_tags = ('', '', '', [])
      graded = 0
      if g['status'] == 'FINAL':
        ats_res, ou_res, pm_zh, err_tags = diagnose_finished_game(g, pred)
        graded = 1
        graded_cnt += 1
        for tg in err_tags:
          if tg != 'MODEL_ON_TARGET':
            params['error_counts'][tg] = params['error_counts'].get(tg, 0) + 1

        if ats_res in ('WIN', 'LOSS'):
          if ats_res == 'WIN':
            day_ats_w += 1
            cum_rec_w += 1
          else:
            day_ats_l += 1
            cum_rec_l += 1
          if pred['ats_tier'] == 'STRONG':
            if ats_res == 'WIN':
              cum_strong_w += 1
            else:
              cum_strong_l += 1

        if ou_res in ('WIN', 'LOSS'):
          if ou_res == 'WIN':
            day_ou_w += 1
            cum_rec_w += 1
          else:
            day_ou_l += 1
            cum_rec_l += 1
          if pred['ou_tier'] == 'STRONG':
            if ou_res == 'WIN':
              cum_strong_w += 1
            else:
              cum_strong_l += 1

        # Adaptive Online Weight Learning: reward empirically accurate factors, dampen noisy <48% ones!
        if g['ats_winner'] in ('HOME', 'AWAY'):
          actual_dir = +1.0 if g['ats_winner'] == 'HOME' else -1.0
          for fk, raw_sig in pred['factors']['ats_raw'].items():
            if abs(raw_sig) < 0.15:
              continue
            st = params['ats_stats'][fk]
            st['trials'] += 1
            aligned = (raw_sig * actual_dir) > 0
            if aligned:
              st['hits'] += 1
            reward = +1.0 if aligned else -1.0
            st['ema_gain'] = round(0.85 * st['ema_gain'] + 0.15 * reward, 4)
            old_w = params['ats_weights'][fk]
            init_w = ATS_FACTOR_META[fk]['init_w']
            step = 0.026 * reward * min(abs(raw_sig) / 1.8, 1.5)
            new_w = _clamp(0.95 * old_w + 0.05 * init_w + step, 0.05, 0.90)
            params['ats_weights'][fk] = round(new_w, 4)
            weight_deltas[f'ATS:{fk}'] = round(weight_deltas.get(f'ATS:{fk}', 0.0) + (new_w - old_w), 4)

        if g['ou_result'] in ('OVER', 'UNDER'):
          actual_ou = +1.0 if g['ou_result'] == 'OVER' else -1.0
          for fk, raw_sig in pred['factors']['ou_raw'].items():
            if abs(raw_sig) < 0.20:
              continue
            st = params['ou_stats'][fk]
            st['trials'] += 1
            aligned = (raw_sig * actual_ou) > 0
            if aligned:
              st['hits'] += 1
            reward = +1.0 if aligned else -1.0
            st['ema_gain'] = round(0.85 * st['ema_gain'] + 0.15 * reward, 4)
            old_w = params['ou_weights'][fk]
            init_w = OU_FACTOR_META[fk]['init_w']
            step = 0.026 * reward * min(abs(raw_sig) / 2.0, 1.5)
            new_w = _clamp(0.95 * old_w + 0.05 * init_w + step, 0.05, 0.90)
            params['ou_weights'][fk] = round(new_w, 4)
            weight_deltas[f'OU:{fk}'] = round(weight_deltas.get(f'OU:{fk}', 0.0) + (new_w - old_w), 4)

      conn.execute(
          """
          INSERT INTO predictions(
            game_id, et_date, tw_date, model_version,
            pred_margin_home, fair_spread_home, book_spread_home,
            ats_edge, ats_pick, ats_conf, ats_tier,
            pred_total, book_total,
            ou_edge, ou_pick, ou_conf, ou_tier,
            rec_units_ats, rec_units_ou, rationale_zh,
            factors_json, guardrails_json,
            graded, ats_result, ou_result, postmortem_zh, error_tags_json,
            created_at, graded_at
          ) VALUES (?,?,?,?, ?,?,?, ?,?,?,?, ?,?, ?,?,?,?, ?,?,?, ?,?, ?,?,?,?,?, ?,?)
          ON CONFLICT(game_id) DO UPDATE SET
            model_version=excluded.model_version,
            pred_margin_home=excluded.pred_margin_home,
            fair_spread_home=excluded.fair_spread_home,
            book_spread_home=excluded.book_spread_home,
            ats_edge=excluded.ats_edge,
            ats_pick=excluded.ats_pick,
            ats_conf=excluded.ats_conf,
            ats_tier=excluded.ats_tier,
            pred_total=excluded.pred_total,
            book_total=excluded.book_total,
            ou_edge=excluded.ou_edge,
            ou_pick=excluded.ou_pick,
            ou_conf=excluded.ou_conf,
            ou_tier=excluded.ou_tier,
            rec_units_ats=excluded.rec_units_ats,
            rec_units_ou=excluded.rec_units_ou,
            rationale_zh=excluded.rationale_zh,
            factors_json=excluded.factors_json,
            guardrails_json=excluded.guardrails_json,
            graded=excluded.graded,
            ats_result=excluded.ats_result,
            ou_result=excluded.ou_result,
            postmortem_zh=excluded.postmortem_zh,
            error_tags_json=excluded.error_tags_json,
            graded_at=excluded.graded_at
          """,
          (
              pred['game_id'], pred['et_date'], pred['tw_date'], pred['model_version'],
              pred['pred_margin_home'], pred['fair_spread_home'], pred['book_spread_home'],
              pred['ats_edge'], pred['ats_pick'], pred['ats_conf'], pred['ats_tier'],
              pred['pred_total'], pred['book_total'],
              pred['ou_edge'], pred['ou_pick'], pred['ou_conf'], pred['ou_tier'],
              pred['rec_units_ats'], pred['rec_units_ou'], pred['rationale_zh'],
              json.dumps(pred['factors'], ensure_ascii=False),
              json.dumps(pred['guardrails'], ensure_ascii=False),
              graded, ats_res or None, ou_res or None, pm_zh,
              json.dumps(err_tags, ensure_ascii=False),
              now_str, now_str if graded else '',
          ),
      )

    if has_final and graded_cnt > 0:
      minor_ver += 1
      params['step_count'] = minor_ver
      params['version'] = f'1.{minor_ver}'

      ec = params['error_counts']
      guardrails = [params['guardrails'][0]]
      if ec.get('3PT_VARIANCE', 0) >= 3:
        guardrails.append({
            'id': '3pt_variance_shield',
            'title': '三分手感高變異過濾護欄',
            'rule': f"賽後檢討偵測到 {ec['3PT_VARIANCE']} 場出現外線極端暴冷／暴熱，自動提高精選門檻避開薄利盤口。",
            'active': True,
        })
      if ec.get('GARBAGE_FOUL_OT', 0) >= 2:
        guardrails.append({
            'id': 'late_foul_script',
            'title': '末節犯規戰術與延長賽保護',
            'rule': f"累計 {ec['GARBAGE_FOUL_OT']} 場受末節故意犯規／OT 拉高總分，淺盤 (<=3.5) 小分自動提高安全邊際。",
            'active': True,
        })
      if ec.get('MARKET_TRAP', 0) >= 2:
        guardrails.append({
            'id': 'reverse_steam_guard',
            'title': '莊家變盤背離警戒護欄',
            'rule': f"累計 {ec['MARKET_TRAP']} 場出現變盤與賽果背離，當變盤與基礎效率衝突時自動折減優勢 40%。",
            'active': True,
        })
      guardrails.append({
          'id': 'gtd_star_guard',
          'title': '臨場 GTD 傷兵不確定性折減',
          'rule': '當雙邊有 >=2 名主力標記為 Questionable (GTD) 未定時，自動折減優勢 24%，避免被賽前臨時輪休突襲。',
          'active': True,
      })
      params['guardrails'] = guardrails

      strong_tot = cum_strong_w + cum_strong_l
      strong_wr = (cum_strong_w / strong_tot) if strong_tot > 0 else 0.56
      naive_tot = naive_w + naive_l
      naive_wr = (naive_w / naive_tot) if naive_tot > 0 else 0.50

      boosted = sorted([(k, v) for k, v in weight_deltas.items() if v > 0.002], key=lambda x: -x[1])
      dampened = sorted([(k, v) for k, v in weight_deltas.items() if v < -0.002], key=lambda x: x[1])
      b_txt = f"調升 {boosted[0][0]} ({boosted[0][1]:+.3f})" if boosted else '維持高勝率因子權重'
      d_txt = f"調降 {dampened[0][0]} ({dampened[0][1]:+.3f})" if dampened else '無失準因子需下修'
      evo_summary = (
          f"完賽檢討 {graded_cnt} 場（推薦命中：讓分 {day_ats_w}勝{day_ats_l}敗、大小 {day_ou_w}勝{day_ou_l}敗）· "
          f"{b_txt}、{d_txt} · 升級至 v{params['version']}。"
      )

      conn.execute(
          """
          INSERT INTO evolution_log(
            et_date, model_version, games_graded,
            ats_wins, ats_losses, ou_wins, ou_losses,
            cum_strong_win_rate, cum_all_win_rate,
            summary_zh, weight_deltas_json, guardrails_json, created_at
          ) VALUES (?,?,?, ?,?,?,?, ?,?, ?,?,?,?)
          """,
          (
              et_date, f"v{params['version']}", graded_cnt,
              day_ats_w, day_ats_l, day_ou_w, day_ou_l,
              round(strong_wr * 100, 1), round(naive_wr * 100, 1),
              evo_summary,
              json.dumps(weight_deltas, ensure_ascii=False),
              json.dumps(guardrails, ensure_ascii=False),
              now_str,
          ),
      )

      if is_live_or_future:
        for g in day_games:
          if g['status'] != 'FINAL':
            pred2 = score_game(
                g, prior_hist, standings_map, injuries_by_team, params,
                use_live_injuries=True, roster_by_team=roster_by_team,
            )
            conn.execute(
                'UPDATE predictions SET model_version=?, pred_margin_home=?, fair_spread_home=?, '
                'ats_edge=?, ats_pick=?, ats_conf=?, ats_tier=?, pred_total=?, ou_edge=?, ou_pick=?, ou_conf=?, ou_tier=?, '
                'rec_units_ats=?, rec_units_ou=?, rationale_zh=?, factors_json=?, guardrails_json=? WHERE game_id=?',
                (
                    pred2['model_version'], pred2['pred_margin_home'], pred2['fair_spread_home'],
                    pred2['ats_edge'], pred2['ats_pick'], pred2['ats_conf'], pred2['ats_tier'],
                    pred2['pred_total'], pred2['ou_edge'], pred2['ou_pick'], pred2['ou_conf'], pred2['ou_tier'],
                    pred2['rec_units_ats'], pred2['rec_units_ou'], pred2['rationale_zh'],
                    json.dumps(pred2['factors'], ensure_ascii=False),
                    json.dumps(pred2['guardrails'], ensure_ascii=False),
                    g['game_id'],
                ),
            )

    completed_so_far.extend([g for g in day_games if g['status'] == 'FINAL'])

  rec_tot = cum_rec_w + cum_rec_l
  naive_tot = naive_w + naive_l
  params['baseline_comparison'] = {
      'static_w': naive_w,
      'static_l': naive_l,
      'static_win_rate': round(naive_w / naive_tot * 100, 1) if naive_tot > 0 else 50.0,
      'evolved_w': cum_rec_w,
      'evolved_l': cum_rec_l,
      'evolved_win_rate': round(cum_rec_w / rec_tot * 100, 1) if rec_tot > 0 else 50.0,
  }

  _grade_user_bets(conn)
  db.set_state(conn, 'model_params', params, now_str)
  conn.commit()
  return params


def _eval_single_bet_leg(g: sqlite3.Row | dict[str, Any], mkt: str, side: str, line: float) -> str:
  if not g or g['status'] != 'FINAL' or g['home_score'] is None or g['away_score'] is None:
    return 'PENDING'
  hs, as_ = int(g['home_score']), int(g['away_score'])
  if mkt == 'ATS':
    diff = (hs - as_) + line if side == 'HOME' else (as_ - hs) + line
    return 'WIN' if diff > 0 else ('LOSS' if diff < 0 else 'PUSH')
  if mkt == 'OU':
    tot = hs + as_
    if side == 'OVER':
      return 'WIN' if tot > line else ('LOSS' if tot < line else 'PUSH')
    return 'WIN' if tot < line else ('LOSS' if tot > line else 'PUSH')
  if mkt == 'ML':
    if hs == as_:
      return 'PUSH'
    return 'WIN' if ((side == 'HOME' and hs > as_) or (side == 'AWAY' and as_ > hs)) else 'LOSS'
  return 'PENDING'


def _grade_parlay_bet(conn: sqlite3.Connection, b: sqlite3.Row) -> tuple[str, float]:
  raw = str(b['game_id'])[len('PARLAY:'):]
  try:
    spec = json.loads(raw)
  except (ValueError, TypeError):
    return 'PENDING', 0.0
  stake = float(b['stake'] or 0.0)
  odds_dec = float(b['odds_decimal'] or config.DEFAULT_DECIMAL_ODDS)

  if isinstance(spec, dict) and spec.get('type') == 'COMBO':
    legs = spec.get('legs') or []
    combos = spec.get('combos') or []
    if not legs or not combos:
      return 'PENDING', 0.0
    leg_states: list[tuple[str, float]] = []
    for lg in legs:
      grow = conn.execute('SELECT * FROM games WHERE game_id = ?', (str(lg.get('gid') or ''),)).fetchone()
      st = _eval_single_bet_leg(grow, str(lg.get('m') or 'ATS'), str(lg.get('s') or 'HOME'), float(lg.get('l') or 0.0))
      leg_states.append((st, float(lg.get('o') or config.DEFAULT_DECIMAL_ODDS)))
    # Check if every combo already has a losing leg (can settle LOSS early)
    all_dead = all(any(leg_states[idx][0] == 'LOSS' for idx in cb if 0 <= idx < len(leg_states)) for cb in combos)
    if all_dead:
      return 'LOSS', round(-stake, 2)
    if any(st == 'PENDING' for st, _ in leg_states):
      return 'PENDING', 0.0
    unit_stake = stake / len(combos)
    tot_return = 0.0
    for cb in combos:
      cb_legs = [leg_states[idx] for idx in cb if 0 <= idx < len(leg_states)]
      if not cb_legs or any(st == 'LOSS' for st, _ in cb_legs):
        continue
      mult = 1.0
      for st, lo in cb_legs:
        if st == 'WIN':
          mult *= lo
      tot_return += unit_stake * mult
    pnl = round(tot_return - stake, 2)
    res = 'WIN' if pnl > 0 else ('LOSS' if pnl < 0 else 'PUSH')
    return res, pnl

  if not isinstance(spec, list) or not spec:
    return 'PENDING', 0.0
  leg_states = []
  for lg in spec:
    grow = conn.execute('SELECT * FROM games WHERE game_id = ?', (str(lg.get('gid') or ''),)).fetchone()
    st = _eval_single_bet_leg(grow, str(lg.get('m') or 'ATS'), str(lg.get('s') or 'HOME'), float(lg.get('l') or 0.0))
    leg_states.append((st, float(lg.get('o') or config.DEFAULT_DECIMAL_ODDS)))
  if any(st == 'LOSS' for st, _ in leg_states):
    return 'LOSS', round(-stake, 2)
  if any(st == 'PENDING' for st, _ in leg_states):
    return 'PENDING', 0.0
  if all(st == 'PUSH' for st, _ in leg_states):
    return 'PUSH', 0.0
  if all(st == 'WIN' for st, _ in leg_states):
    return 'WIN', round(stake * (odds_dec - 1.0), 2)
  eff_mult = 1.0
  for st, lo in leg_states:
    if st == 'WIN':
      eff_mult *= lo
  return 'WIN', round(stake * (eff_mult - 1.0), 2)


def _grade_user_bets(conn: sqlite3.Connection) -> None:
  pending = conn.execute("SELECT * FROM user_bets WHERE status = 'PENDING' AND game_id != ''").fetchall()
  for b in pending:
    gid = str(b['game_id'] or '')
    if gid.startswith('PARLAY:'):
      res, pnl = _grade_parlay_bet(conn, b)
      if res != 'PENDING':
        conn.execute('UPDATE user_bets SET status = ?, pnl = ? WHERE bet_id = ?', (res, pnl, b['bet_id']))
      continue
    g = conn.execute('SELECT * FROM games WHERE game_id = ?', (gid,)).fetchone()
    res = _eval_single_bet_leg(g, b['market'], b['pick_side'], float(b['line'] or 0.0))
    if res != 'PENDING':
      odds = float(b['odds_decimal'] or config.DEFAULT_DECIMAL_ODDS)
      stake = float(b['stake'] or 0.0)
      pnl = round(stake * (odds - 1.0), 2) if res == 'WIN' else (-stake if res == 'LOSS' else 0.0)
      conn.execute('UPDATE user_bets SET status = ?, pnl = ? WHERE bet_id = ?', (res, pnl, b['bet_id']))
