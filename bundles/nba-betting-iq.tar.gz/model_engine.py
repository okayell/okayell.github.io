#!/usr/bin/env python3
"""Quantitative NBA Spread (ATS) & Over/Under Model v2.0 + Post-Mortem & Self-Evolution Engine.

Design principles (Pattern 162 Rule 6 — Walk-Forward Validation, Zero Lookahead):
1. Strict chronological walk-forward simulation: when predicting games on `et_date`,
   ONLY games completed strictly BEFORE `et_date`, pre-game lines/BPI, and pre-game
   `injury_snapshots` are visible.
2. Market-residual v2.0 architecture (Zero-Hindsight Conservative Core):
   - Uses boxscore-derived possessions & opponent-adjusted Ridge Pace / ORtg / DRtg
     plus dynamic Ridge Home Court Advantage (replacing biased raw PPG + fixed +2.2 HCA).
   - Introduces 3PT% Shooting Luck Mean-Reversion (`three_pt_luck_fade`, `ou_3p_luck_fade`)
     to exploit market overreaction to short-term 3PT variance without fighting Vegas injury lines.
   - Enforces a non-linear >=1.5pt steam exhaustion guardrail (stops chasing over-moved lines
     and discounts live `injury_edge` / `injury_total` by 60% to prevent double-counting).
3. Post-mortem root-cause attribution: inspects quarter scores, 3PT%, FT attempts,
   rebounds, turnovers, B2B rest, and line movement on every graded game.
4. Conservative L2-regularized Walk-Forward Ridge learning: smoothly adapts factor weights
   toward empirical cover margins with strong L2 prior shrinkage and non-negative clipping
   (automatically zeroing out negative-IC noise instead of chasing single-game +/-1 variance).
"""
from __future__ import annotations

import datetime as dt
import json
import math
import sqlite3
from typing import Any

import config
import db
import storylines
import teams

ATS_FACTOR_META: dict[str, dict[str, Any]] = {
    'bpi_gap': {
        'name_zh': 'ESPN BPI 勝率合理盤差',
        'desc_zh': 'ESPN BPI 賽前勝率（已含陣容強弱）推算合理讓分與目前盤口之差距',
        'init_w': 0.42,
    },
    'three_pt_luck_fade': {
        'name_zh': '三分球運氣均值回歸',
        'desc_zh': '利用近 6 場實際箱型數據計算己方與對手三分命中率偏離聯盟均值之運氣分差，淡化外線暴熱球隊溢價',
        'init_w': 0.45,
    },
    'inflate_fade': {
        'name_zh': '雙位數深盤受讓保護',
        'desc_zh': '深盤讓分 (>=10.5) 第四節主力輪休與垃圾時間帶來的受讓過盤價值',
        'init_w': 0.50,
    },
    'line_steam': {
        'name_zh': '溫和變盤聰明錢（≥1.5 分防追高）',
        'desc_zh': '僅順勢跟進 0.5–1.25 分溫和變盤；變盤 ≥1.5 分自動啟動不追高護欄歸零，避免買在過度調整高點',
        'init_w': 0.40,
    },
    'injury_edge': {
        'name_zh': '傷兵與 GTD 價差（防重複計價）',
        'desc_zh': '評估球星／先發缺陣與 GTD 影響；若盤口已大幅移動 ≥1.5 分則自動折減 60% 避免與莊家重複計價',
        'init_w': 0.30,
    },
    'revenge_drama': {
        'name_zh': '球星戰舊主與恩怨戰意（觀察指標）',
        'desc_zh': '追蹤休賽季交易球星對決前東家與宿敵戰意；v2.0 預設觀察權重 0，待長期正 IC 驗證後由 L2 學習啟用',
        'init_w': 0.00,
    },
}

OU_FACTOR_META: dict[str, dict[str, Any]] = {
    'ou_regression': {
        'name_zh': '極端大小分盤口均值回歸',
        'desc_zh': '超高總分盤 (>=237.0) 追高過熱回歸小分、超低盤 (<=219.0) 防守高估回歸大分',
        'init_w': 0.50,
    },
    'b2b_def_leak': {
        'name_zh': '背靠背防守疲勞失分效應',
        'desc_zh': '現代 NBA 背靠背球隊退防與外線輪轉下滑，推升對手得分效率偏向大分',
        'init_w': 0.48,
    },
    'total_steam': {
        'name_zh': '大小分變盤資金方向',
        'desc_zh': '比較初盤總分與目前盤口變動幅度之順勢訊號',
        'init_w': 0.38,
    },
    'ou_3p_luck_fade': {
        'name_zh': '雙隊三分手感運氣回歸',
        'desc_zh': '偵測雙方近 5 場比賽累積的極端三分投籃運氣，過度飆分後回歸小分、外線失常後回歸大分',
        'init_w': 0.35,
    },
    'spread_script': {
        'name_zh': '比賽劇本（拉鋸犯規 vs 深盤降速）',
        'desc_zh': '極淺盤 (<=3.5) 末節犯規戰術與 OT 機率推升大分；懸殊深盤 (>=13.0) 末節消化時間偏小分',
        'init_w': 0.36,
    },
    'pace_eff_gap': {
        'name_zh': 'Ridge 對手校正回合×效率總分殘差',
        'desc_zh': '以箱型數據精算回合數 (Pace) 與對手強度校正百回合攻防效率 (ORtg/DRtg) 推估總分對比盤口',
        'init_w': 0.25,
    },
    'injury_total': {
        'name_zh': '核心持球／得分手缺陣修正',
        'desc_zh': '主力進攻發動機缺陣對團隊半場進攻效率之影響（大幅變盤時自動防重複折減）',
        'init_w': 0.25,
    },
    'drama_tempo': {
        'name_zh': '戰舊主飆分與宿敵節奏（觀察指標）',
        'desc_zh': '追蹤場外戲碼對比賽節奏影響；因實測命中率偏低，v2.0 預設權重歸零作為觀察指標',
        'init_w': 0.00,
    },
}

ERROR_TAG_LABELS: dict[str, str] = {
    '3PT_VARIANCE': '🔥 三分球極端手感變異',
    'GARBAGE_FOUL_OT': '⏱️ 末節犯規戰術／延長賽翻盤',
    'BLOWOUT_BENCH': '🪑 大比分垃圾時間替補咬盤',
    'B2B_COLLAPSE': '📉 背靠背體能與防守下滑',
    'MARKET_TRAP': '💰 盤口變盤與賽果背離（誘盤）',
    'MODEL_ON_TARGET': '🎯 模型核心因子精準命中',
}

_MONITOR_ONLY_FACTORS = frozenset({'revenge_drama', 'drama_tempo'})


def default_model_params() -> dict[str, Any]:
  return {
      'version': '2.0',
      'step_count': 0,
      'ats_weights': {k: v['init_w'] for k, v in ATS_FACTOR_META.items()},
      'ou_weights': {k: v['init_w'] for k, v in OU_FACTOR_META.items()},
      'ats_stats': {k: {'hits': 0, 'trials': 0, 'ema_gain': 0.0} for k in ATS_FACTOR_META},
      'ou_stats': {k: {'hits': 0, 'trials': 0, 'ema_gain': 0.0} for k in OU_FACTOR_META},
      'thresholds': {
          'strong_ats': 1.45,
          'lean_ats': 1.10,
          'strong_ou': 1.75,
          'lean_ou': 1.25,
      },
      'error_counts': {},
      'baseline_comparison': {
          'static_w': 0, 'static_l': 0, 'static_win_rate': 50.0,
          'evolved_w': 0, 'evolved_l': 0, 'evolved_win_rate': 50.0,
      },
      'guardrails': [
          {
              'id': 'vig_filter',
              'title': '水錢損益兩平過濾護欄 (52.38% Breakeven)',
              'rule': '當模型預估優勢 Edge 低於門檻（讓分 1.10 / 大小 1.25）時強制標記「觀望不碰 (PASS)」，拒絕薄利弱推被抽水消耗本金。',
              'active': True,
          },
          {
              'id': 'steam_exhaustion_guard',
              'title': 'v2.0 大幅變盤不追高護欄 (≥1.5 分)',
              'rule': '讓分盤移動 ≥1.5 分時自動歸零變盤追價訊號，並折減傷兵價差 60%，避免買在已過度調整的最差價位與重複計價。',
              'active': True,
          },
      ],
  }


def _clamp(v: float, lo: float, hi: float) -> float:
  return max(lo, min(hi, v))


def _mean(xs: list[float]) -> float:
  return sum(xs) / len(xs) if xs else 0.0


def _prob_to_margin(prob_pct: float) -> float:
  p = _clamp(prob_pct / 100.0, 0.03, 0.97)
  return (11.8 / 1.702) * math.log(p / (1.0 - p))


def _parse_pct(val: Any) -> float | None:
  if val is None or val == '':
    return None
  try:
    return float(str(val).replace('%', '').strip())
  except ValueError:
    return None


def _parse_made_att(val: Any) -> tuple[int, int]:
  if not val or '-' not in str(val):
    return 0, 0
  p = str(val).split('-', 1)
  try:
    return int(p[0]), int(p[1])
  except ValueError:
    return 0, 0


def _parse_num(val: Any) -> float:
  if val is None or val == '':
    return 0.0
  try:
    return float(str(val).replace('%', '').strip())
  except ValueError:
    return 0.0


def _solve_linear_system(A: list[list[float]], b: list[float]) -> list[float]:
  """Pure-Python Gaussian elimination with partial pivoting (zero external deps)."""
  n = len(b)
  M = [row[:] + [b[i]] for i, row in enumerate(A)]
  for col in range(n):
    piv = max(range(col, n), key=lambda r: abs(M[r][col]))
    if abs(M[piv][col]) < 1e-12:
      continue
    M[col], M[piv] = M[piv], M[col]
    div = M[col][col]
    for j in range(col, n + 1):
      M[col][j] /= div
    for r in range(n):
      if r != col and abs(M[r][col]) > 1e-15:
        fac = M[r][col]
        for j in range(col, n + 1):
          M[r][j] -= fac * M[col][j]
  return [M[i][n] for i in range(n)]


def _extract_box_metrics(g: sqlite3.Row | dict[str, Any]) -> dict[str, Any] | None:
  """Extracts possessions & 3PT volume/makes from completed game boxscore_json."""
  if g['home_score'] is None or g['away_score'] is None:
    return None
  try:
    box = json.loads(g['boxscore_json'] or '{}')
  except (ValueError, TypeError):
    box = {}
  hb = box.get('home') or {}
  ab = box.get('away') or {}
  if not hb or not ab:
    return None
  _, h_fga = _parse_made_att(hb.get('fieldGoalsMade-fieldGoalsAttempted'))
  _, a_fga = _parse_made_att(ab.get('fieldGoalsMade-fieldGoalsAttempted'))
  h_tpm, h_tpa = _parse_made_att(hb.get('threePointFieldGoalsMade-threePointFieldGoalsAttempted'))
  a_tpm, a_tpa = _parse_made_att(ab.get('threePointFieldGoalsMade-threePointFieldGoalsAttempted'))
  _, h_fta = _parse_made_att(hb.get('freeThrowsMade-freeThrowsAttempted'))
  _, a_fta = _parse_made_att(ab.get('freeThrowsMade-freeThrowsAttempted'))
  h_orb = _parse_num(hb.get('offensiveRebounds'))
  a_orb = _parse_num(ab.get('offensiveRebounds'))
  h_tov = _parse_num(hb.get('totalTurnovers') or hb.get('turnovers'))
  a_tov = _parse_num(ab.get('totalTurnovers') or ab.get('turnovers'))
  if h_fga <= 20 or a_fga <= 20:
    return None
  h_poss = max(60.0, h_fga + 0.44 * h_fta - h_orb + h_tov)
  a_poss = max(60.0, a_fga + 0.44 * a_fta - a_orb + a_tov)
  poss = 0.5 * (h_poss + a_poss)
  hs, as_ = float(g['home_score']), float(g['away_score'])
  return {
      'home': g['home_abbr'],
      'away': g['away_abbr'],
      'poss': poss,
      'hs': hs,
      'as': as_,
      'margin_home': hs - as_,
      'h_ortg': 100.0 * hs / poss,
      'a_ortg': 100.0 * as_ / poss,
      'h_tpm': h_tpm,
      'h_tpa': h_tpa,
      'a_tpm': a_tpm,
      'a_tpa': a_tpa,
  }


def _fit_ridge_league_context(prior_box_records: list[dict[str, Any]]) -> dict[str, Any]:
  """Fits strictly-prior opponent-adjusted Ridge Pace, ORtg, DRtg, and Dynamic HCA."""
  team_list = sorted(teams.TEAMS.keys())
  nt = len(team_list)
  idx = {t: i for i, t in enumerate(team_list)}

  if len(prior_box_records) < 10:
    return {
        'ready': False,
        'pace_r': {t: 0.0 for t in team_list},
        'mu_pace': 99.0,
        'off_r': {t: 0.0 for t in team_list},
        'def_r': {t: 0.0 for t in team_list},
        'mu_eff': 115.0,
        'hca': 1.4,
    }

  # 1. Dynamic Ridge HCA & Margin SRS (hca_prior = 1.4 instead of biased +2.2)
  n_srs = nt + 1
  As = [[0.0] * n_srs for _ in range(n_srs)]
  bs = [0.0] * n_srs
  for i in range(nt):
    As[i][i] = 7.0
  As[nt][nt] = 10.0
  bs[nt] = 10.0 * 1.4
  for rec in prior_box_records:
    hi, ai = idx.get(rec['home']), idx.get(rec['away'])
    if hi is None or ai is None:
      continue
    y = rec['margin_home']
    entries = [(hi, 1.0), (ai, -1.0), (nt, 1.0)]
    for i1, v1 in entries:
      bs[i1] += v1 * y
      for i2, v2 in entries:
        As[i1][i2] += v1 * v2
  srs_sol = _solve_linear_system(As, bs)
  dyn_hca = _clamp(srs_sol[nt], 0.4, 2.8)

  # 2. Opponent-Adjusted Pace: poss ~ mu_pace + pace[h] + pace[a]
  mu_pace = _mean([r['poss'] for r in prior_box_records])
  Ap = [[0.0] * nt for _ in range(nt)]
  bp = [0.0] * nt
  for i in range(nt):
    Ap[i][i] = 6.0
  for rec in prior_box_records:
    hi, ai = idx.get(rec['home']), idx.get(rec['away'])
    if hi is None or ai is None:
      continue
    y = rec['poss'] - mu_pace
    for i1 in (hi, ai):
      bp[i1] += y
      for i2 in (hi, ai):
        Ap[i1][i2] += 1.0
  psol = _solve_linear_system(Ap, bp)
  pm = _mean(psol)
  pace_r = {t: psol[idx[t]] - pm for t in team_list}

  # 3. Opponent-Adjusted ORtg & DRtg: ortg ~ mu_eff + off[team] + def[opp]
  all_ortg = [r['h_ortg'] for r in prior_box_records] + [r['a_ortg'] for r in prior_box_records]
  mu_eff = _mean(all_ortg)
  n_eff = 2 * nt
  Ae = [[0.0] * n_eff for _ in range(n_eff)]
  be = [0.0] * n_eff
  for i in range(n_eff):
    Ae[i][i] = 8.0
  for rec in prior_box_records:
    hi, ai = idx.get(rec['home']), idx.get(rec['away'])
    if hi is None or ai is None:
      continue
    for i1, i2, y in (
        (hi, nt + ai, rec['h_ortg'] - mu_eff),
        (ai, nt + hi, rec['a_ortg'] - mu_eff),
    ):
      for a_i in (i1, i2):
        be[a_i] += y
        for b_i in (i1, i2):
          Ae[a_i][b_i] += 1.0
  esol = _solve_linear_system(Ae, be)
  om = _mean(esol[:nt])
  dm = _mean(esol[nt:])
  return {
      'ready': True,
      'pace_r': pace_r,
      'mu_pace': mu_pace,
      'off_r': {t: esol[idx[t]] - om for t in team_list},
      'def_r': {t: esol[nt + idx[t]] - dm for t in team_list},
      'mu_eff': mu_eff,
      'hca': dyn_hca,
  }


def _fit_shrunk_ridge_weights(
    X_hist: list[list[float]],
    y_hist: list[float],
    keys: list[str],
    meta: dict[str, dict[str, Any]],
    lam: float = 220.0,
    max_w: float = 0.65,
) -> dict[str, float]:
  """Conservative Walk-Forward L2 Ridge shrinking toward domain priors with non-negative clipping."""
  prior_w = [float(meta[k]['init_w']) for k in keys]
  p = len(keys)
  if len(X_hist) < 30:
    return {k: round(w, 4) for k, w in zip(keys, prior_w)}

  # Count active non-zero observations per feature so sparse factors stay at prior until validated
  active_cnt = [sum(1 for x in X_hist if abs(x[i]) >= 0.15) for i in range(p)]

  XtX = [[0.0] * p for _ in range(p)]
  Xty = [0.0] * p
  for i in range(p):
    XtX[i][i] = lam
    Xty[i] = lam * prior_w[i]

  for x, y in zip(X_hist, y_hist):
    # Scale cover margin to alpha scale so L2 shrinkage stays centered near domain priors
    yc = _clamp(y / 3.5, -3.5, 3.5)
    for i in range(p):
      Xty[i] += x[i] * yc
      for j in range(p):
        XtX[i][j] += x[i] * x[j]

  sol = _solve_linear_system(XtX, Xty)
  raw_out: dict[str, float] = {}
  for i, k in enumerate(keys):
    if active_cnt[i] < 20:
      raw_out[k] = prior_w[i]
    elif k in _MONITOR_ONLY_FACTORS:
      # Monitoring-only factors require strong sustained evidence and remain tightly capped
      raw_out[k] = _clamp(sol[i], 0.0, 0.12)
    else:
      raw_out[k] = _clamp(sol[i], 0.0, max_w)

  # Preserve active factor weight budget so OLS attenuation doesn't silently starve fixed edge thresholds
  active_core = [k for i, k in enumerate(keys) if active_cnt[i] >= 20 and k not in _MONITOR_ONLY_FACTORS]
  if active_core:
    prior_sum = sum(float(meta[k]['init_w']) for k in active_core)
    cur_sum = sum(raw_out[k] for k in active_core)
    if cur_sum > 0.15 and prior_sum > 0.0:
      scale = _clamp(prior_sum / cur_sum, 0.80, 1.25)
      for k in active_core:
        raw_out[k] = _clamp(raw_out[k] * scale, 0.0, max_w)

  return {k: round(raw_out[k], 4) for k in keys}


def _build_prior_team_history(prior_games: list[sqlite3.Row]) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
  """Builds strictly-prior per-team stats, 3PT shooting luck logs, and league boxscore records."""
  hist: dict[str, dict[str, Any]] = {}
  for ab in teams.TEAMS:
    hist[ab] = {
        'gp': 0, 'w': 0, 'l': 0,
        'pts_for': 0, 'pts_against': 0,
        'recent_margins': [], 'recent_totals': [],
        'ats_results': [], 'ou_results': [],
        'dates_played': [],
        'net_3p_luck_pts': [],
        'tot_3p_luck_pts': [],
    }

  box_records: list[dict[str, Any]] = []
  cum_3pm = 0
  cum_3pa = 0

  for g in prior_games:
    if g['status'] != 'FINAL' or g['home_score'] is None or g['away_score'] is None:
      continue
    h, a = g['home_abbr'], g['away_abbr']
    hs, as_ = int(g['home_score']), int(g['away_score'])
    d = dt.date.fromisoformat(g['et_date'])

    # Compute 3PT luck points relative to prior-to-game league 3P% (zero lookahead)
    lg_3p = (cum_3pm / cum_3pa) if cum_3pa > 100 else 0.360
    bm = _extract_box_metrics(g)
    h_3p_luck = a_3p_luck = None
    if bm is not None:
      box_records.append(bm)
      h_3p = bm['h_tpm'] / max(1, bm['h_tpa'])
      a_3p = bm['a_tpm'] / max(1, bm['a_tpa'])
      h_3p_luck = 3.0 * bm['h_tpa'] * (h_3p - lg_3p) * 0.70
      a_3p_luck = 3.0 * bm['a_tpa'] * (a_3p - lg_3p) * 0.70
      cum_3pm += bm['h_tpm'] + bm['a_tpm']
      cum_3pa += bm['h_tpa'] + bm['a_tpa']

    if h in hist:
      hh = hist[h]
      hh['gp'] += 1
      hh['w'] += 1 if hs > as_ else 0
      hh['l'] += 1 if hs < as_ else 0
      hh['pts_for'] += hs
      hh['pts_against'] += as_
      hh['recent_margins'].append(hs - as_)
      hh['recent_totals'].append(hs + as_)
      if g['ats_winner'] in ('HOME', 'AWAY'):
        hh['ats_results'].append(1 if g['ats_winner'] == 'HOME' else -1)
      if g['ou_result'] in ('OVER', 'UNDER'):
        hh['ou_results'].append(1 if g['ou_result'] == 'OVER' else -1)
      hh['dates_played'].append((d, 'H'))
      if h_3p_luck is not None and a_3p_luck is not None:
        hh['net_3p_luck_pts'].append(h_3p_luck - a_3p_luck)
        hh['tot_3p_luck_pts'].append(h_3p_luck + a_3p_luck)

    if a in hist:
      aa = hist[a]
      aa['gp'] += 1
      aa['w'] += 1 if as_ > hs else 0
      aa['l'] += 1 if as_ < hs else 0
      aa['pts_for'] += as_
      aa['pts_against'] += hs
      aa['recent_margins'].append(as_ - hs)
      aa['recent_totals'].append(hs + as_)
      if g['ats_winner'] in ('HOME', 'AWAY'):
        aa['ats_results'].append(1 if g['ats_winner'] == 'AWAY' else -1)
      if g['ou_result'] in ('OVER', 'UNDER'):
        aa['ou_results'].append(1 if g['ou_result'] == 'OVER' else -1)
      aa['dates_played'].append((d, 'A'))
      if h_3p_luck is not None and a_3p_luck is not None:
        aa['net_3p_luck_pts'].append(a_3p_luck - h_3p_luck)
        aa['tot_3p_luck_pts'].append(h_3p_luck + a_3p_luck)

  return hist, box_records


def _rest_profile(dates_played: list[tuple[dt.date, str]], target_date: dt.date) -> dict[str, Any]:
  if not dates_played:
    return {'rest_days': 3, 'is_b2b': False, 'three_in_four': False, 'label': '休足開季'}
  last_d, _ = dates_played[-1]
  gap = (target_date - last_d).days
  rest_days = max(0, gap - 1)
  is_b2b = (gap == 1)
  recent_4d = sum(1 for d, _ in dates_played if 1 <= (target_date - d).days <= 3)
  three_in_four = (recent_4d >= 2)
  if is_b2b and three_in_four:
    label = '⚠️ 背靠背＋4天3戰'
  elif is_b2b:
    label = '⚠️ 背靠背 (B2B)'
  elif three_in_four:
    label = '⚡ 4天3戰'
  elif rest_days >= 2:
    label = f'🔋 休 {rest_days} 天'
  else:
    label = '正常休 1 天'
  return {'rest_days': rest_days, 'is_b2b': is_b2b, 'three_in_four': three_in_four, 'label': label}


def _team_injury_burden(injuries_for_team: list[dict[str, Any]]) -> tuple[float, float, int]:
  sp_loss = 0.0
  tot_drag = 0.0
  gtd_stars = 0
  for inj in injuries_for_team:
    prob_miss = (100 - int(inj.get('play_prob_next') or 0)) / 100.0
    pts = float(inj.get('est_spread_pts') or 0.5)
    t_pts = float(inj.get('est_total_pts') or -0.2)
    ret = str(inj.get('return_date') or '')
    long_c = str(inj.get('long_comment') or '').lower()
    if 'season' in long_c or 'months' in long_c or (ret and ret > '2026-12-01'):
      resid_mult = 0.15
    elif 0.15 <= prob_miss <= 0.85:
      resid_mult = 0.45
      if inj.get('impact_tier') in ('STAR', 'STARTER'):
        gtd_stars += 1
    else:
      resid_mult = 0.32
    sp_loss += pts * prob_miss * resid_mult
    tot_drag += t_pts * prob_miss * resid_mult
  return round(min(sp_loss, 5.5), 2), round(_clamp(tot_drag, -4.5, 2.5), 2), gtd_stars


def score_game(
    g: dict[str, Any] | sqlite3.Row,
    prior_hist: dict[str, dict[str, Any]],
    standings_map: dict[str, dict[str, Any]],
    injuries_by_team: dict[str, list[dict[str, Any]]],
    params: dict[str, Any],
    use_live_injuries: bool = False,
    roster_by_team: dict[str, list[dict[str, Any]]] | None = None,
    league_ctx: dict[str, Any] | None = None,
) -> dict[str, Any]:
  """Computes pre-game v2.0 ATS & O/U factor signals, edge, pick, confidence, and rationale."""
  gd = dict(g)
  home = gd['home_abbr']
  away = gd['away_abbr']
  et_d = dt.date.fromisoformat(gd['et_date'])

  book_sp = gd.get('close_spread_home')
  open_sp = gd.get('open_spread_home')
  book_tot = gd.get('close_total')
  open_tot = gd.get('open_total')

  empty_h = {
      'gp': 0, 'pts_for': 0, 'pts_against': 0, 'recent_margins': [],
      'ats_results': [], 'ou_results': [], 'dates_played': [],
      'net_3p_luck_pts': [], 'tot_3p_luck_pts': [],
  }
  hh = prior_hist.get(home) or empty_h
  ah = prior_hist.get(away) or empty_h

  tot_gp = sum(v['gp'] for v in prior_hist.values())
  league_ppg = (sum(v['pts_for'] for v in prior_hist.values()) / tot_gp) if tot_gp >= 10 else 115.2

  def _team_eff(th: dict[str, Any], ab: str) -> tuple[float, float, float]:
    gp = th['gp']
    if gp > 0:
      raw_pf = th['pts_for'] / gp
      raw_pa = th['pts_against'] / gp
    elif use_live_injuries and ab in standings_map:
      raw_pf = float(standings_map[ab].get('ppg') or league_ppg)
      raw_pa = float(standings_map[ab].get('opp_ppg') or league_ppg)
    else:
      raw_pf, raw_pa = league_ppg, league_ppg
    shrink = gp / (gp + 5.0) if gp > 0 else (0.35 if (use_live_injuries and ab in standings_map) else 0.0)
    pf = league_ppg + shrink * (raw_pf - league_ppg)
    pa = league_ppg + shrink * (raw_pa - league_ppg)
    return pf, pa, pf - pa

  h_pf, h_pa, h_net = _team_eff(hh, home)
  a_pf, a_pa, a_net = _team_eff(ah, away)
  dyn_hca = float((league_ctx or {}).get('hca', 1.4))

  h_rest = _rest_profile(hh.get('dates_played') or [], et_d)
  a_rest = _rest_profile(ah.get('dates_played') or [], et_d)

  fund_margin = (h_net - a_net) + dyn_hca
  mkt_margin = (-float(book_sp)) if book_sp is not None else fund_margin

  # Ridge Opponent-Adjusted Pace x (ORtg + DRtg) total projection when prior boxscores ready
  has_box_hist = (len(hh.get('net_3p_luck_pts') or []) >= 3 and len(ah.get('net_3p_luck_pts') or []) >= 3)
  if league_ctx and league_ctx.get('ready') and has_box_hist:
    exp_pace = league_ctx['mu_pace'] + league_ctx['pace_r'].get(home, 0.0) + league_ctx['pace_r'].get(away, 0.0)
    h_proj_pts = (league_ctx['mu_eff'] + league_ctx['off_r'].get(home, 0.0) + league_ctx['def_r'].get(away, 0.0)) * exp_pace / 100.0
    a_proj_pts = (league_ctx['mu_eff'] + league_ctx['off_r'].get(away, 0.0) + league_ctx['def_r'].get(home, 0.0)) * exp_pace / 100.0
    fund_total = h_proj_pts + a_proj_pts
  else:
    h_proj_pts = (h_pf + a_pa) * 0.5
    a_proj_pts = (a_pf + h_pa) * 0.5
    fund_total = h_proj_pts + a_proj_pts

  mkt_total = float(book_tot) if (book_tot is not None and book_tot > 0) else fund_total

  # Line movements
  sp_delta_home = round(float(open_sp) - float(book_sp), 1) if (open_sp is not None and book_sp is not None) else 0.0
  tot_delta = round(float(book_tot) - float(open_tot), 1) if (open_tot and book_tot) else 0.0

  # --- v2.0 ATS Factors (positive = favors HOME covering; negative = favors AWAY covering) ---
  # 1. ESPN BPI fair-margin gap (already incorporates pre-game roster/injury strength)
  bpi_pct = gd.get('bpi_home_win_pct')
  f_bpi = _clamp((_prob_to_margin(float(bpi_pct)) - mkt_margin) * 0.55, -3.0, 3.0) if bpi_pct is not None else 0.0

  # 2. Pure 3PT Shooting Luck Mean-Reversion (L6 net 3PT luck points; orthogonal to injury lines)
  f_3p_luck = 0.0
  if has_box_hist:
    h_l6 = _mean((hh.get('net_3p_luck_pts') or [])[-6:])
    a_l6 = _mean((ah.get('net_3p_luck_pts') or [])[-6:])
    f_3p_luck = _clamp((a_l6 - h_l6) * 0.35, -3.0, 3.0)

  # 3. Double-digit favorite inflation fade (favors underdog when |spread| >= 10.5)
  f_fade = 0.0
  if book_sp is not None and abs(float(book_sp)) >= 10.5:
    excess = min(abs(float(book_sp)) - 9.0, 6.5) * 0.50
    f_fade = -excess if float(book_sp) < 0 else +excess

  # 4. Non-linear Spread Line Steam with >=1.5pt Anti-Chasing Guardrail
  triggered_guardrails: list[str] = []
  f_steam_raw = _clamp(sp_delta_home * 0.95, -3.4, 3.4) if (open_sp is not None and book_sp is not None) else 0.0
  if 0.5 <= abs(sp_delta_home) <= 1.25:
    f_steam_eff = _clamp(sp_delta_home * 1.0, -1.2, 1.2)
  elif abs(sp_delta_home) >= 1.5:
    f_steam_eff = 0.0
    triggered_guardrails.append('讓分盤口已大幅移動 ≥1.5 分，啟動 v2.0 防追高護欄歸零變盤追價並折減傷兵重覆計價')
  else:
    f_steam_eff = 0.0

  # 5. Injuries & GTD uncertainty (uses pre-game snapshots or live injuries; discounted if line already moved >=1.5)
  gtd_uncertainty = 0
  if use_live_injuries:
    h_inj_loss, h_tot_drag, h_gtd = _team_injury_burden(injuries_by_team.get(home, []))
    a_inj_loss, a_tot_drag, a_gtd = _team_injury_burden(injuries_by_team.get(away, []))
    inj_sp_mult = 0.40 if abs(sp_delta_home) >= 1.5 else 1.0
    inj_tot_mult = 0.40 if abs(tot_delta) >= 1.5 else 1.0
    f_inj = _clamp((a_inj_loss - h_inj_loss) * inj_sp_mult, -3.5, 3.5)
    o_inj = _clamp((h_tot_drag + a_tot_drag) * inj_tot_mult, -3.5, 2.0)
    gtd_uncertainty = h_gtd + a_gtd
  else:
    f_inj = 0.0
    o_inj = 0.0

  # 6. Revenge Games & Rivalry Storylines (recorded in raw factors; 0.0 initial weight in v2.0)
  drama_eval = storylines.evaluate_game_storylines(
      away,
      home,
      roster_by_team=roster_by_team,
      injuries_by_team=injuries_by_team if use_live_injuries else None,
      away_record=str(gd.get('away_record') or ''),
      home_record=str(gd.get('home_record') or ''),
      game_status=str(gd.get('status') or 'SCHEDULED'),
  )
  f_drama = float(drama_eval['ats_raw_home'])
  o_drama = float(drama_eval['ou_raw_over'])

  ats_raw = {
      'bpi_gap': round(f_bpi, 2),
      'three_pt_luck_fade': round(f_3p_luck, 2),
      'inflate_fade': round(f_fade, 2),
      'line_steam': round(f_steam_raw, 2),
      'injury_edge': round(f_inj, 2),
      'revenge_drama': round(f_drama, 2),
  }
  ats_eff_raw = dict(ats_raw, line_steam=round(f_steam_eff, 2))

  ats_w = params['ats_weights']
  ats_contribs = {
      k: round(ats_eff_raw[k] * float(ats_w.get(k, ATS_FACTOR_META[k]['init_w'])), 2)
      for k in ATS_FACTOR_META
  }
  ats_alpha_home = round(sum(ats_contribs.values()), 2)

  pred_margin_home = round(mkt_margin + ats_alpha_home, 2)
  fair_spread_home = round(-pred_margin_home, 2)

  # --- v2.0 O/U Factors (positive = favors OVER; negative = favors UNDER) ---
  # 1. Extreme total regression
  o_reg = 0.0
  if mkt_total >= 237.0:
    o_reg = -_clamp((mkt_total - 234.5) * 0.52, 0.6, 3.4)
  elif mkt_total <= 219.0:
    o_reg = +_clamp((221.0 - mkt_total) * 0.48, 0.6, 3.2)

  # 2. Modern NBA B2B tired-defense leak -> OVER
  b2b_cnt = (1 if h_rest['is_b2b'] else 0) + (1 if a_rest['is_b2b'] else 0)
  o_b2b_leak = +1.65 * b2b_cnt if b2b_cnt > 0 else (-0.40 if (h_rest['rest_days'] >= 2 and a_rest['rest_days'] >= 2) else 0.0)

  # 3. Total line steam
  o_steam = _clamp((float(book_tot) - float(open_tot)) * 0.65, -2.6, 2.6) if (open_tot and book_tot) else 0.0

  # 4. Combined recent 3PT shooting luck fade on totals
  o_3p_fade = 0.0
  if has_box_hist:
    h_tl = _mean((hh.get('tot_3p_luck_pts') or [])[-5:])
    a_tl = _mean((ah.get('tot_3p_luck_pts') or [])[-5:])
    o_3p_fade = _clamp(-(h_tl + a_tl) * 0.22, -2.8, 2.8)

  # 5. Game script (close game late fouls/OT vs blowout bench run-out)
  o_script = 0.0
  if book_sp is not None:
    abs_sp = abs(float(book_sp))
    if abs_sp <= 3.5:
      o_script = +1.35
    elif abs_sp >= 13.0:
      o_script = -1.85

  # 6. Opponent-adjusted Ridge Pace x ORtg/DRtg residual
  o_pace = _clamp((fund_total - mkt_total) * 0.45, -3.5, 3.5) if has_box_hist else 0.0

  ou_raw = {
      'ou_regression': round(o_reg, 2),
      'b2b_def_leak': round(o_b2b_leak, 2),
      'total_steam': round(o_steam, 2),
      'ou_3p_luck_fade': round(o_3p_fade, 2),
      'spread_script': round(o_script, 2),
      'pace_eff_gap': round(o_pace, 2),
      'injury_total': round(o_inj, 2),
      'drama_tempo': round(o_drama, 2),
  }
  ou_w = params['ou_weights']
  ou_contribs = {
      k: round(ou_raw[k] * float(ou_w.get(k, OU_FACTOR_META[k]['init_w'])), 2)
      for k in OU_FACTOR_META
  }
  ou_alpha = round(sum(ou_contribs.values()), 2)
  pred_total = round(mkt_total + ou_alpha, 2)

  # --- Selectivity Thresholds & Active Guardrails ---
  th = params['thresholds']
  eff_ats_alpha = ats_alpha_home
  eff_ou_alpha = ou_alpha

  if gtd_uncertainty >= 2:
    eff_ats_alpha *= 0.76
    triggered_guardrails.append('雙方多名主力 GTD 賽前決定，自動折減優勢 24% 防範臨場輪休突襲')

  ats_edge = round(abs(eff_ats_alpha), 2) if book_sp is not None else 0.0
  if book_sp is None or ats_edge < float(th['lean_ats']):
    ats_pick, ats_tier = 'PASS', 'PASS'
  else:
    ats_pick = 'HOME' if eff_ats_alpha > 0 else 'AWAY'
    ats_tier = 'STRONG' if ats_edge >= float(th['strong_ats']) else 'LEAN'

  ou_edge = round(abs(eff_ou_alpha), 2) if (book_tot is not None and book_tot > 0) else 0.0
  if not book_tot or ou_edge < float(th['lean_ou']):
    ou_pick, ou_tier = 'PASS', 'PASS'
  else:
    ou_pick = 'OVER' if eff_ou_alpha > 0 else 'UNDER'
    ou_tier = 'STRONG' if ou_edge >= float(th['strong_ou']) else 'LEAN'

  ats_conf = int(round(_clamp(52.0 + ats_edge * 9.5, 52, 89))) if ats_pick != 'PASS' else 50
  ou_conf = int(round(_clamp(52.0 + ou_edge * 8.2, 52, 88))) if ou_pick != 'PASS' else 50

  # Calibrated staking: 2.0u requires STRONG + edge >= 2.2 + >=2 independent agreeing factors
  ats_agree = sum(1 for v in ats_contribs.values() if v * eff_ats_alpha > 0 and abs(v) >= 0.25)
  ou_agree = sum(1 for v in ou_contribs.values() if v * eff_ou_alpha > 0 and abs(v) >= 0.25)
  rec_u_ats = (
      2.0 if (ats_tier == 'STRONG' and ats_edge >= 2.2 and ats_agree >= 2)
      else (1.5 if ats_tier == 'STRONG' else (1.0 if ats_tier == 'LEAN' else 0.0))
  )
  rec_u_ou = (
      2.0 if (ou_tier == 'STRONG' and ou_edge >= 2.4 and ou_agree >= 2)
      else (1.5 if ou_tier == 'STRONG' else (1.0 if ou_tier == 'LEAN' else 0.0))
  )

  h_zh = teams.team_info(home)['zh']
  a_zh = teams.team_info(away)['zh']

  # --- Two-Stage (18:00 Early -> 23:00 Final) Line-Movement Re-Analysis ---
  lock_s = str(gd.get('odds_locked_tw') or '')
  odds_stage = 'final' if ('定盤' in lock_s or '23:00' in lock_s) else ('early' if ('初盤' in lock_s or '18:00' in lock_s) else '')

  # Compute Pass-1 (18:00 Early Line, zero steam) baseline pick for direct Pass-1 vs Pass-2 comparison
  early_ats_pick, early_ats_tier = ats_pick, ats_tier
  if open_sp is not None:
    open_mkt_m = -float(open_sp)
    open_f_fade = 0.0
    if abs(float(open_sp)) >= 10.5:
      ex_pts = min(abs(float(open_sp)) - 9.0, 6.5) * 0.50
      open_f_fade = -ex_pts if float(open_sp) < 0 else +ex_pts
    open_f_bpi = _clamp((_prob_to_margin(float(bpi_pct)) - open_mkt_m) * 0.55, -3.0, 3.0) if bpi_pct is not None else 0.0
    early_raw = dict(ats_eff_raw, line_steam=0.0, inflate_fade=round(open_f_fade, 2), bpi_gap=round(open_f_bpi, 2))
    early_alpha = sum(
        round(early_raw[k] * float(ats_w.get(k, ATS_FACTOR_META[k]['init_w'])), 2)
        for k in ATS_FACTOR_META
    )
    if gtd_uncertainty >= 2:
      early_alpha *= 0.76
    if abs(early_alpha) < float(th['lean_ats']):
      early_ats_pick, early_ats_tier = 'PASS', 'PASS'
    else:
      early_ats_pick = 'HOME' if early_alpha > 0 else 'AWAY'
      early_ats_tier = 'STRONG' if abs(early_alpha) >= float(th['strong_ats']) else 'LEAN'

  early_ou_pick, early_ou_tier = ou_pick, ou_tier
  if open_tot and float(open_tot) > 0:
    open_mt = float(open_tot)
    open_o_reg = (
        -_clamp((open_mt - 234.5) * 0.52, 0.6, 3.4) if open_mt >= 237.0
        else (+_clamp((221.0 - open_mt) * 0.48, 0.6, 3.2) if open_mt <= 219.0 else 0.0)
    )
    open_o_pace = _clamp((fund_total - open_mt) * 0.45, -3.5, 3.5) if has_box_hist else 0.0
    open_o_scr = (
        +1.35 if abs(float(open_sp)) <= 3.5 else (-1.85 if abs(float(open_sp)) >= 13.0 else 0.0)
    ) if open_sp is not None else o_script
    early_ou_raw = dict(
        ou_raw, total_steam=0.0, ou_regression=round(open_o_reg, 2),
        pace_eff_gap=round(open_o_pace, 2), spread_script=round(open_o_scr, 2),
    )
    early_ou_a = sum(
        round(early_ou_raw[k] * float(ou_w.get(k, OU_FACTOR_META[k]['init_w'])), 2)
        for k in OU_FACTOR_META
    )
    if abs(early_ou_a) < float(th['lean_ou']):
      early_ou_pick, early_ou_tier = 'PASS', 'PASS'
    else:
      early_ou_pick = 'OVER' if early_ou_a > 0 else 'UNDER'
      early_ou_tier = 'STRONG' if abs(early_ou_a) >= float(th['strong_ou']) else 'LEAN'

  move_parts: list[str] = []
  if abs(sp_delta_home) >= 0.5:
    steam_team = h_zh if sp_delta_home > 0 else a_zh
    move_parts.append(f'讓分由 {open_sp:+.1f} 變為 {book_sp:+.1f}（資金往{steam_team}推升 {abs(sp_delta_home):.1f} 分）')
  if abs(tot_delta) >= 0.5:
    move_parts.append(f'大小分由 {open_tot:.1f} {"調高至" if tot_delta > 0 else "下修至"} {book_tot:.1f}（{tot_delta:+.1f} 分）')

  if move_parts:
    verdict_shift = ''
    if early_ats_pick != ats_pick:
      if ats_pick == 'PASS':
        verdict_shift = '；變盤已吃掉早盤價差（或觸發 ≥1.5 分不追高護欄），二輪重析轉為「觀望不碰」保護本金'
      elif early_ats_pick == 'PASS':
        pick_zh = h_zh if ats_pick == 'HOME' else a_zh
        verdict_shift = f'；隨晚間盤勢明朗，二輪重析新浮現【{pick_zh}】正期望值買點'
      else:
        pick_zh = h_zh if ats_pick == 'HOME' else a_zh
        verdict_shift = f'；晚間盤勢明顯轉向，二輪重析改向【{pick_zh}】'
    elif ats_pick != 'PASS':
      pick_zh = h_zh if ats_pick == 'HOME' else a_zh
      aligned = (ats_pick == 'HOME' and sp_delta_home > 0) or (ats_pick == 'AWAY' and sp_delta_home < 0)
      if aligned and abs(sp_delta_home) <= 1.25:
        verdict_shift = f'；溫和聰明錢流向與 18:00 首輪方向一致，強化【{pick_zh}】信心'
      elif early_ats_tier != ats_tier:
        verdict_shift = f'；依變盤幅度微調【{pick_zh}】推薦強度（{early_ats_tier}→{ats_tier}）'
    reanalysis_zh = '📈 盤勢變化重析（18:00→23:00）：' + '、'.join(move_parts) + verdict_shift + '。'
  elif odds_stage == 'final' and book_sp is not None:
    reanalysis_zh = '🔒 23:00 尾盤定盤重析：18:00 初盤至 23:00 定盤盤勢持平無異常變盤，維持首輪量化評估結論。'
  elif odds_stage == 'early' and book_sp is not None:
    reanalysis_zh = '🕕 18:00 初盤首輪解盤完成；今晚 23:00 將再抓最後一次尾盤，依 5 小時盤勢變化執行第二輪重析。'
  else:
    reanalysis_zh = ''

  reasons: list[str] = []
  if move_parts:
    reasons.append('晚間變盤：' + '、'.join(move_parts))
  top_ats = sorted(ats_contribs.items(), key=lambda kv: abs(kv[1]), reverse=True)
  for fk, fv in top_ats[:2]:
    if abs(fv) < 0.20:
      continue
    side_zh = h_zh if fv > 0 else a_zh
    reasons.append(f"{ATS_FACTOR_META[fk]['name_zh']}支持{side_zh} ({fv:+.2f}分)")
  top_ou = sorted(ou_contribs.items(), key=lambda kv: abs(kv[1]), reverse=True)
  if top_ou and abs(top_ou[0][1]) >= 0.30:
    ou_dir = '大分' if top_ou[0][1] > 0 else '小分'
    reasons.append(f"{OU_FACTOR_META[top_ou[0][0]]['name_zh']}傾向{ou_dir} ({top_ou[0][1]:+.2f}分)")
  if not reasons:
    reasons.append('目前莊家讓分與大小分定價貼近合理效率值，無明顯正期望值 (+EV) 缺口，建議觀望不碰。')

  return {
      'game_id': gd['game_id'],
      'et_date': gd['et_date'],
      'tw_date': gd['tw_date'],
      'model_version': f"v{params['version']}",
      'pred_margin_home': pred_margin_home,
      'fair_spread_home': fair_spread_home,
      'book_spread_home': book_sp,
      'ats_edge': ats_edge,
      'ats_pick': ats_pick,
      'ats_lean_side': 'HOME' if eff_ats_alpha >= 0 else 'AWAY',
      'ats_conf': ats_conf,
      'ats_tier': ats_tier,
      'pred_total': pred_total,
      'book_total': book_tot,
      'ou_edge': ou_edge,
      'ou_pick': ou_pick,
      'ou_lean_side': 'OVER' if eff_ou_alpha >= 0 else 'UNDER',
      'ou_conf': ou_conf,
      'ou_tier': ou_tier,
      'rec_units_ats': rec_u_ats,
      'rec_units_ou': rec_u_ou,
      'rationale_zh': '；'.join(reasons) + '。',
      'factors': {
          'ats_raw': ats_raw,
          'ats_eff_raw': ats_eff_raw,
          'ats_contribs': ats_contribs,
          'ou_raw': ou_raw,
          'ou_contribs': ou_contribs,
          'home_rest': h_rest,
          'away_rest': a_rest,
          'home_proj_ppg': round(h_proj_pts, 1),
          'away_proj_ppg': round(a_proj_pts, 1),
          'line_move': {
              'stage': odds_stage,
              'spread_delta_home': sp_delta_home,
              'total_delta': tot_delta,
              'early_ats_pick': early_ats_pick,
              'early_ats_tier': early_ats_tier,
              'early_ou_pick': early_ou_pick,
              'early_ou_tier': early_ou_tier,
              'reanalysis_zh': reanalysis_zh,
          },
      },
      'guardrails': triggered_guardrails,
  }


def diagnose_finished_game(g: sqlite3.Row, pred: dict[str, Any]) -> tuple[str, str, str, list[str]]:
  ats_win_side = g['ats_winner']
  ou_win_side = g['ou_result']
  ats_pick = pred['ats_pick']
  ou_pick = pred['ou_pick']

  if ats_pick == 'PASS' or not ats_win_side:
    ats_res = 'PASS' if ats_pick == 'PASS' else None
  elif ats_win_side == 'PUSH':
    ats_res = 'PUSH'
  elif ats_pick == ats_win_side:
    ats_res = 'WIN'
  else:
    ats_res = 'LOSS'

  if ou_pick == 'PASS' or not ou_win_side:
    ou_res = 'PASS' if ou_pick == 'PASS' else None
  elif ou_win_side == 'PUSH':
    ou_res = 'PUSH'
  elif ou_pick == ou_win_side:
    ou_res = 'WIN'
  else:
    ou_res = 'LOSS'

  h_zh = teams.team_info(g['home_abbr'])['zh']
  a_zh = teams.team_info(g['away_abbr'])['zh']
  try:
    box = json.loads(g['boxscore_json'] or '{}')
  except ValueError:
    box = {}
  try:
    hq = json.loads(g['home_q_scores'] or '[]')
    aq = json.loads(g['away_q_scores'] or '[]')
  except ValueError:
    hq, aq = [], []

  hbox = box.get('home') or {}
  abox = box.get('away') or {}
  h3p = _parse_pct(hbox.get('threePointFieldGoalPct'))
  a3p = _parse_pct(abox.get('threePointFieldGoalPct'))
  _, h_fta = _parse_made_att(hbox.get('freeThrowsMade-freeThrowsAttempted'))
  _, a_fta = _parse_made_att(abox.get('freeThrowsMade-freeThrowsAttempted'))

  tags: list[str] = []
  notes: list[str] = []

  is_ot = len(hq) > 4 or 'OT' in str(g['status_detail'] or '').upper()
  if is_ot:
    tags.append('GARBAGE_FOUL_OT')
    notes.append(f"進入延長賽（共 {len(hq)} 節），額外時間推升總分至 {g['total_points']} 分並牽動盤口")

  if h3p is not None and a3p is not None:
    if abs(h3p - a3p) >= 11.0 or h3p >= 45.0 or a3p >= 45.0 or h3p <= 26.0 or a3p <= 26.0:
      tags.append('3PT_VARIANCE')
      notes.append(f"外線手感出現顯著變異（{h_zh} 三分 {h3p:.0f}% vs {a_zh} {a3p:.0f}%）")

  if len(hq) >= 4 and len(aq) >= 4 and not is_ot:
    q4_pts = int(hq[3]) + int(aq[3])
    q4_diff = int(hq[3]) - int(aq[3])
    pre_q4_diff = sum(int(x) for x in hq[:3]) - sum(int(x) for x in aq[:3])
    if q4_pts >= 66 or (h_fta + a_fta) >= 56:
      if 'GARBAGE_FOUL_OT' not in tags:
        tags.append('GARBAGE_FOUL_OT')
      notes.append(f"末節單節合轟 {q4_pts} 分（全場 {h_fta + a_fta} 罰），犯規戰術拉高總分")
    elif abs(pre_q4_diff) >= 18 and abs(q4_diff) >= 8 and (pre_q4_diff * q4_diff < 0):
      tags.append('BLOWOUT_BENCH')
      notes.append(f"前三節分差達 {abs(pre_q4_diff)} 分進入垃圾時間，末節替補追回 {abs(q4_diff)} 分咬盤")

  fac = pred.get('factors') or {}
  hr = (fac.get('home_rest') or {}).get('is_b2b')
  ar = (fac.get('away_rest') or {}).get('is_b2b')
  if (hr or ar) and ((g['ou_margin'] or 0) > 6 or abs(g['margin_home'] or 0) >= 12):
    tags.append('B2B_COLLAPSE')
    tired_zh = h_zh if hr else a_zh
    notes.append(f"{tired_zh}背靠背出賽退防效率下滑，影響下半場比分走勢")

  if g['open_spread_home'] is not None and g['close_spread_home'] is not None:
    move = float(g['open_spread_home']) - float(g['close_spread_home'])
    if abs(move) >= 1.5 and g['ats_cover_margin'] is not None:
      if (move > 0 and float(g['ats_cover_margin']) < 0) or (move < 0 and float(g['ats_cover_margin']) > 0):
        tags.append('MARKET_TRAP')
        notes.append(f"盤口從 {g['open_spread_home']:+.1f} 變至 {g['close_spread_home']:+.1f}，賽果反向開出")

  if (ats_res == 'WIN' or ou_res == 'WIN') and ats_res != 'LOSS' and ou_res != 'LOSS':
    tags.insert(0, 'MODEL_ON_TARGET')
    notes.insert(0, '模型核心因子與實際比賽節奏吻合')

  if not notes:
    notes.append(f"終場 {a_zh} {g['away_score']} : {g['home_score']} {h_zh}（分差 {g['margin_home']:+d}，總分 {g['total_points']}）")

  return ats_res or '', ou_res or '', '；'.join(notes[:3]) + '。', tags[:4]


def run_walk_forward_and_predict(conn: sqlite3.Connection) -> dict[str, Any]:
  """Replays completed games chronologically to evolve v2.0 L2-Ridge weights and predict upcoming games."""
  now_str = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S')
  all_games = conn.execute(
      'SELECT * FROM games ORDER BY et_date ASC, tipoff_utc ASC, game_id ASC'
  ).fetchall()

  standings_rows = conn.execute('SELECT * FROM team_stats').fetchall()
  standings_map = {r['abbr']: dict(r) for r in standings_rows}

  inj_rows = conn.execute('SELECT * FROM injuries').fetchall()
  live_injuries_by_team: dict[str, list[dict[str, Any]]] = {}
  for ir in inj_rows:
    live_injuries_by_team.setdefault(ir['team_abbr'], []).append(dict(ir))

  # Load immutable pre-game injury snapshots (for zero-lookahead historical validation)
  inj_snapshots: dict[str, dict[str, list[dict[str, Any]]]] = {}
  try:
    for sr in conn.execute('SELECT * FROM injury_snapshots').fetchall():
      try:
        h_list = json.loads(sr['home_injuries_json'] or '[]')
        a_list = json.loads(sr['away_injuries_json'] or '[]')
      except ValueError:
        h_list, a_list = [], []
      inj_snapshots[sr['game_id']] = {sr['home_abbr']: h_list, sr['away_abbr']: a_list}
  except sqlite3.OperationalError:
    pass

  roster_by_team: dict[str, list[dict[str, Any]]] = {}
  try:
    for rr in conn.execute('SELECT * FROM roster_players').fetchall():
      roster_by_team.setdefault(rr['team_abbr'], []).append(dict(rr))
  except sqlite3.OperationalError:
    pass

  params = default_model_params()
  conn.execute('DELETE FROM evolution_log')

  by_date: dict[str, list[sqlite3.Row]] = {}
  for g in all_games:
    by_date.setdefault(g['et_date'], []).append(g)

  ats_keys = list(ATS_FACTOR_META.keys())
  ou_keys = list(OU_FACTOR_META.keys())
  ats_X_hist: list[list[float]] = []
  ats_y_hist: list[float] = []
  ou_X_hist: list[list[float]] = []
  ou_y_hist: list[float] = []

  completed_so_far: list[sqlite3.Row] = []
  cum_strong_w = cum_strong_l = 0
  cum_rec_w = cum_rec_l = 0
  naive_w = naive_l = 0
  minor_ver = 0

  for et_date in sorted(by_date.keys()):
    day_games = by_date[et_date]
    has_final = any(g['status'] == 'FINAL' for g in day_games)
    is_live_or_future = any(g['status'] != 'FINAL' for g in day_games)

    prior_hist, prior_box_records = _build_prior_team_history(completed_so_far)
    league_ctx = _fit_ridge_league_context(prior_box_records)

    day_preds: list[tuple[sqlite3.Row, dict[str, Any]]] = []
    for g in day_games:
      if g['status'] != 'FINAL':
        use_inj = True
        game_inj_map = live_injuries_by_team
      elif g['game_id'] in inj_snapshots:
        use_inj = True
        game_inj_map = inj_snapshots[g['game_id']]
      else:
        use_inj = False
        game_inj_map = {}

      pred = score_game(
          g, prior_hist, standings_map, game_inj_map, params,
          use_live_injuries=use_inj, roster_by_team=roster_by_team,
          league_ctx=league_ctx,
      )
      day_preds.append((g, pred))
      if g['status'] == 'FINAL':
        # Benchmark against naive unshrunk raw PPG/margin bettor
        hh_n = prior_hist.get(g['home_abbr']) or {'gp': 0, 'pts_for': 0, 'pts_against': 0}
        ah_n = prior_hist.get(g['away_abbr']) or {'gp': 0, 'pts_for': 0, 'pts_against': 0}
        if hh_n['gp'] > 0 and ah_n['gp'] > 0 and g['close_spread_home'] is not None:
          raw_h_net = (hh_n['pts_for'] - hh_n['pts_against']) / hh_n['gp']
          raw_a_net = (ah_n['pts_for'] - ah_n['pts_against']) / ah_n['gp']
          naive_ats = 'HOME' if (raw_h_net - raw_a_net + 2.5) + float(g['close_spread_home']) > 0 else 'AWAY'
          if g['ats_winner'] in ('HOME', 'AWAY'):
            if naive_ats == g['ats_winner']:
              naive_w += 1
            else:
              naive_l += 1
        if hh_n['gp'] > 0 and ah_n['gp'] > 0 and g['close_total']:
          raw_tot = (hh_n['pts_for'] + hh_n['pts_against']) / (2 * hh_n['gp']) + (ah_n['pts_for'] + ah_n['pts_against']) / (2 * ah_n['gp'])
          naive_ou = 'OVER' if raw_tot > float(g['close_total']) else 'UNDER'
          if g['ou_result'] in ('OVER', 'UNDER'):
            if naive_ou == g['ou_result']:
              naive_w += 1
            else:
              naive_l += 1

    day_ats_w = day_ats_l = day_ou_w = day_ou_l = 0
    graded_cnt = 0
    weight_deltas: dict[str, float] = {}
    day_ats_obs: list[tuple[list[float], float]] = []
    day_ou_obs: list[tuple[list[float], float]] = []

    for g, pred in day_preds:
      ats_res, ou_res, pm_zh, err_tags = ('', '', '', [])
      graded = 0
      if g['status'] == 'FINAL':
        ats_res, ou_res, pm_zh, err_tags = diagnose_finished_game(g, pred)
        graded = 1
        graded_cnt += 1
        for tg in err_tags:
          if tg != 'MODEL_ON_TARGET':
            params['error_counts'][tg] = params['error_counts'].get(tg, 0) + 1

        if ats_res in ('WIN', 'LOSS'):
          if ats_res == 'WIN':
            day_ats_w += 1
            cum_rec_w += 1
          else:
            day_ats_l += 1
            cum_rec_l += 1
          if pred['ats_tier'] == 'STRONG':
            if ats_res == 'WIN':
              cum_strong_w += 1
            else:
              cum_strong_l += 1

        if ou_res in ('WIN', 'LOSS'):
          if ou_res == 'WIN':
            day_ou_w += 1
            cum_rec_w += 1
          else:
            day_ou_l += 1
            cum_rec_l += 1
          if pred['ou_tier'] == 'STRONG':
            if ou_res == 'WIN':
              cum_strong_w += 1
            else:
              cum_strong_l += 1

        # Record empirical per-factor hit stats (using effective post-guardrail signals)
        eff_ats_map = pred['factors'].get('ats_eff_raw') or pred['factors']['ats_raw']
        if g['ats_winner'] in ('HOME', 'AWAY'):
          actual_dir = +1.0 if g['ats_winner'] == 'HOME' else -1.0
          for fk in ats_keys:
            raw_sig = float(eff_ats_map.get(fk, 0.0))
            if abs(raw_sig) < 0.15:
              continue
            st = params['ats_stats'][fk]
            st['trials'] += 1
            aligned = (raw_sig * actual_dir) > 0
            if aligned:
              st['hits'] += 1
            reward = +1.0 if aligned else -1.0
            st['ema_gain'] = round(0.88 * st['ema_gain'] + 0.12 * reward, 4)

        if g['ats_cover_margin'] is not None:
          day_ats_obs.append(([float(eff_ats_map.get(k, 0.0)) for k in ats_keys], float(g['ats_cover_margin'])))

        ou_map = pred['factors']['ou_raw']
        if g['ou_result'] in ('OVER', 'UNDER'):
          actual_ou = +1.0 if g['ou_result'] == 'OVER' else -1.0
          for fk in ou_keys:
            raw_sig = float(ou_map.get(fk, 0.0))
            if abs(raw_sig) < 0.20:
              continue
            st = params['ou_stats'][fk]
            st['trials'] += 1
            aligned = (raw_sig * actual_ou) > 0
            if aligned:
              st['hits'] += 1
            reward = +1.0 if aligned else -1.0
            st['ema_gain'] = round(0.88 * st['ema_gain'] + 0.12 * reward, 4)

        if g['ou_margin'] is not None:
          day_ou_obs.append(([float(ou_map.get(k, 0.0)) for k in ou_keys], float(g['ou_margin'])))

      conn.execute(
          """
          INSERT INTO predictions(
            game_id, et_date, tw_date, model_version,
            pred_margin_home, fair_spread_home, book_spread_home,
            ats_edge, ats_pick, ats_conf, ats_tier,
            pred_total, book_total,
            ou_edge, ou_pick, ou_conf, ou_tier,
            rec_units_ats, rec_units_ou, rationale_zh,
            factors_json, guardrails_json,
            graded, ats_result, ou_result, postmortem_zh, error_tags_json,
            created_at, graded_at
          ) VALUES (?,?,?,?, ?,?,?, ?,?,?,?, ?,?, ?,?,?,?, ?,?,?, ?,?, ?,?,?,?,?, ?,?)
          ON CONFLICT(game_id) DO UPDATE SET
            model_version=excluded.model_version,
            pred_margin_home=excluded.pred_margin_home,
            fair_spread_home=excluded.fair_spread_home,
            book_spread_home=excluded.book_spread_home,
            ats_edge=excluded.ats_edge,
            ats_pick=excluded.ats_pick,
            ats_conf=excluded.ats_conf,
            ats_tier=excluded.ats_tier,
            pred_total=excluded.pred_total,
            book_total=excluded.book_total,
            ou_edge=excluded.ou_edge,
            ou_pick=excluded.ou_pick,
            ou_conf=excluded.ou_conf,
            ou_tier=excluded.ou_tier,
            rec_units_ats=excluded.rec_units_ats,
            rec_units_ou=excluded.rec_units_ou,
            rationale_zh=excluded.rationale_zh,
            factors_json=excluded.factors_json,
            guardrails_json=excluded.guardrails_json,
            graded=excluded.graded,
            ats_result=excluded.ats_result,
            ou_result=excluded.ou_result,
            postmortem_zh=excluded.postmortem_zh,
            error_tags_json=excluded.error_tags_json,
            graded_at=excluded.graded_at
          """,
          (
              pred['game_id'], pred['et_date'], pred['tw_date'], pred['model_version'],
              pred['pred_margin_home'], pred['fair_spread_home'], pred['book_spread_home'],
              pred['ats_edge'], pred['ats_pick'], pred['ats_conf'], pred['ats_tier'],
              pred['pred_total'], pred['book_total'],
              pred['ou_edge'], pred['ou_pick'], pred['ou_conf'], pred['ou_tier'],
              pred['rec_units_ats'], pred['rec_units_ou'], pred['rationale_zh'],
              json.dumps(pred['factors'], ensure_ascii=False),
              json.dumps(pred['guardrails'], ensure_ascii=False),
              graded, ats_res or None, ou_res or None, pm_zh,
              json.dumps(err_tags, ensure_ascii=False),
              now_str, now_str if graded else '',
          ),
      )

    # Batch L2-Shrunk Ridge weight evolution after the full et_date concludes (strictly zero lookahead)
    if has_final and graded_cnt > 0:
      for xv, yv in day_ats_obs:
        ats_X_hist.append(xv)
        ats_y_hist.append(yv)
      for xv, yv in day_ou_obs:
        ou_X_hist.append(xv)
        ou_y_hist.append(yv)

      new_ats_w = _fit_shrunk_ridge_weights(ats_X_hist, ats_y_hist, ats_keys, ATS_FACTOR_META, lam=220.0, max_w=0.65)
      new_ou_w = _fit_shrunk_ridge_weights(ou_X_hist, ou_y_hist, ou_keys, OU_FACTOR_META, lam=220.0, max_w=0.65)

      for k in ats_keys:
        dw = round(new_ats_w[k] - params['ats_weights'][k], 4)
        if abs(dw) >= 0.0005:
          weight_deltas[f'ATS:{k}'] = dw
        params['ats_weights'][k] = new_ats_w[k]
      for k in ou_keys:
        dw = round(new_ou_w[k] - params['ou_weights'][k], 4)
        if abs(dw) >= 0.0005:
          weight_deltas[f'OU:{k}'] = dw
        params['ou_weights'][k] = new_ou_w[k]

      minor_ver += 1
      params['step_count'] = minor_ver
      params['version'] = f'2.{minor_ver}'

      ec = params['error_counts']
      guardrails = list(default_model_params()['guardrails'])
      if ec.get('3PT_VARIANCE', 0) >= 3:
        guardrails.append({
            'id': '3pt_variance_shield',
            'title': '三分手感運氣均值回歸護欄',
            'rule': f"賽後檢討偵測到 {ec['3PT_VARIANCE']} 場外線極端變異，v2.0 已透過近 5–6 場三分運氣回歸因子自動修正暴熱／暴冷溢價。",
            'active': True,
        })
      if ec.get('GARBAGE_FOUL_OT', 0) >= 2:
        guardrails.append({
            'id': 'late_foul_script',
            'title': '末節犯規戰術與延長賽保護',
            'rule': f"累計 {ec['GARBAGE_FOUL_OT']} 場受末節故意犯規／OT 拉高總分，淺盤 (<=3.5) 劇本因子自動納入大分推升。",
            'active': True,
        })
      if ec.get('MARKET_TRAP', 0) >= 2:
        guardrails.append({
            'id': 'reverse_steam_guard',
            'title': '大幅變盤誘盤隔離護欄',
            'rule': f"累計 {ec['MARKET_TRAP']} 場大變盤反向開出，≥1.5 分變盤不再追價，僅保留 0.5–1.25 分溫和資金流。",
            'active': True,
        })
      guardrails.append({
          'id': 'gtd_star_guard',
          'title': '臨場 GTD 傷兵不確定性折減',
          'rule': '當雙邊有 >=2 名主力標記為 Questionable (GTD) 未定時，自動折減優勢 24%，並以賽前傷兵快照進行歷史校準。',
          'active': True,
      })
      params['guardrails'] = guardrails

      strong_tot = cum_strong_w + cum_strong_l
      strong_wr = (cum_strong_w / strong_tot) if strong_tot > 0 else 0.56
      naive_tot = naive_w + naive_l
      naive_wr = (naive_w / naive_tot) if naive_tot > 0 else 0.50

      boosted = sorted([(k, v) for k, v in weight_deltas.items() if v > 0.001], key=lambda x: -x[1])
      dampened = sorted([(k, v) for k, v in weight_deltas.items() if v < -0.001], key=lambda x: x[1])
      b_txt = f"L2 調升 {boosted[0][0]} ({boosted[0][1]:+.3f})" if boosted else 'L2 維持保守先驗權重'
      d_txt = f"調降 {dampened[0][0]} ({dampened[0][1]:+.3f})" if dampened else '無失準因子需下修'
      evo_summary = (
          f"完賽檢討 {graded_cnt} 場（推薦命中：讓分 {day_ats_w}勝{day_ats_l}敗、大小 {day_ou_w}勝{day_ou_l}敗）· "
          f"{b_txt}、{d_txt} · 升級至 v{params['version']}。"
      )

      conn.execute(
          """
          INSERT INTO evolution_log(
            et_date, model_version, games_graded,
            ats_wins, ats_losses, ou_wins, ou_losses,
            cum_strong_win_rate, cum_all_win_rate,
            summary_zh, weight_deltas_json, guardrails_json, created_at
          ) VALUES (?,?,?, ?,?,?,?, ?,?, ?,?,?,?)
          """,
          (
              et_date, f"v{params['version']}", graded_cnt,
              day_ats_w, day_ats_l, day_ou_w, day_ou_l,
              round(strong_wr * 100, 1), round(naive_wr * 100, 1),
              evo_summary,
              json.dumps(weight_deltas, ensure_ascii=False),
              json.dumps(guardrails, ensure_ascii=False),
              now_str,
          ),
      )

      if is_live_or_future:
        for g in day_games:
          if g['status'] != 'FINAL':
            pred2 = score_game(
                g, prior_hist, standings_map, live_injuries_by_team, params,
                use_live_injuries=True, roster_by_team=roster_by_team,
                league_ctx=league_ctx,
            )
            conn.execute(
                'UPDATE predictions SET model_version=?, pred_margin_home=?, fair_spread_home=?, '
                'ats_edge=?, ats_pick=?, ats_conf=?, ats_tier=?, pred_total=?, ou_edge=?, ou_pick=?, ou_conf=?, ou_tier=?, '
                'rec_units_ats=?, rec_units_ou=?, rationale_zh=?, factors_json=?, guardrails_json=? WHERE game_id=?',
                (
                    pred2['model_version'], pred2['pred_margin_home'], pred2['fair_spread_home'],
                    pred2['ats_edge'], pred2['ats_pick'], pred2['ats_conf'], pred2['ats_tier'],
                    pred2['pred_total'], pred2['ou_edge'], pred2['ou_pick'], pred2['ou_conf'], pred2['ou_tier'],
                    pred2['rec_units_ats'], pred2['rec_units_ou'], pred2['rationale_zh'],
                    json.dumps(pred2['factors'], ensure_ascii=False),
                    json.dumps(pred2['guardrails'], ensure_ascii=False),
                    g['game_id'],
                ),
            )

    completed_so_far.extend([g for g in day_games if g['status'] == 'FINAL'])

  rec_tot = cum_rec_w + cum_rec_l
  naive_tot = naive_w + naive_l
  params['baseline_comparison'] = {
      'static_w': naive_w,
      'static_l': naive_l,
      'static_win_rate': round(naive_w / naive_tot * 100, 1) if naive_tot > 0 else 50.0,
      'evolved_w': cum_rec_w,
      'evolved_l': cum_rec_l,
      'evolved_win_rate': round(cum_rec_w / rec_tot * 100, 1) if rec_tot > 0 else 50.0,
  }

  _grade_user_bets(conn)
  db.set_state(conn, 'model_params', params, now_str)
  conn.commit()
  return params


def _eval_single_bet_leg(g: sqlite3.Row | dict[str, Any], mkt: str, side: str, line: float) -> str:
  if not g or g['status'] != 'FINAL' or g['home_score'] is None or g['away_score'] is None:
    return 'PENDING'
  hs, as_ = int(g['home_score']), int(g['away_score'])
  if mkt == 'ATS':
    diff = (hs - as_) + line if side == 'HOME' else (as_ - hs) + line
    return 'WIN' if diff > 0 else ('LOSS' if diff < 0 else 'PUSH')
  if mkt == 'OU':
    tot = hs + as_
    if side == 'OVER':
      return 'WIN' if tot > line else ('LOSS' if tot < line else 'PUSH')
    return 'WIN' if tot < line else ('LOSS' if tot > line else 'PUSH')
  if mkt == 'ML':
    if hs == as_:
      return 'PUSH'
    return 'WIN' if ((side == 'HOME' and hs > as_) or (side == 'AWAY' and as_ > hs)) else 'LOSS'
  return 'PENDING'


def _grade_parlay_bet(conn: sqlite3.Connection, b: sqlite3.Row) -> tuple[str, float]:
  raw = str(b['game_id'])[len('PARLAY:'):]
  try:
    spec = json.loads(raw)
  except (ValueError, TypeError):
    return 'PENDING', 0.0
  stake = float(b['stake'] or 0.0)
  odds_dec = float(b['odds_decimal'] or config.DEFAULT_DECIMAL_ODDS)

  if isinstance(spec, dict) and spec.get('type') == 'COMBO':
    legs = spec.get('legs') or []
    combos = spec.get('combos') or []
    if not legs or not combos:
      return 'PENDING', 0.0
    leg_states: list[tuple[str, float]] = []
    for lg in legs:
      grow = conn.execute('SELECT * FROM games WHERE game_id = ?', (str(lg.get('gid') or ''),)).fetchone()
      st = _eval_single_bet_leg(grow, str(lg.get('m') or 'ATS'), str(lg.get('s') or 'HOME'), float(lg.get('l') or 0.0))
      leg_states.append((st, float(lg.get('o') or config.DEFAULT_DECIMAL_ODDS)))
    # Check if every combo already has a losing leg (can settle LOSS early)
    all_dead = all(any(leg_states[idx][0] == 'LOSS' for idx in cb if 0 <= idx < len(leg_states)) for cb in combos)
    if all_dead:
      return 'LOSS', round(-stake, 2)
    if any(st == 'PENDING' for st, _ in leg_states):
      return 'PENDING', 0.0
    unit_stake = stake / len(combos)
    tot_return = 0.0
    for cb in combos:
      cb_legs = [leg_states[idx] for idx in cb if 0 <= idx < len(leg_states)]
      if not cb_legs or any(st == 'LOSS' for st, _ in cb_legs):
        continue
      mult = 1.0
      for st, lo in cb_legs:
        if st == 'WIN':
          mult *= lo
      tot_return += unit_stake * mult
    pnl = round(tot_return - stake, 2)
    res = 'WIN' if pnl > 0 else ('LOSS' if pnl < 0 else 'PUSH')
    return res, pnl

  if not isinstance(spec, list) or not spec:
    return 'PENDING', 0.0
  leg_states = []
  for lg in spec:
    grow = conn.execute('SELECT * FROM games WHERE game_id = ?', (str(lg.get('gid') or ''),)).fetchone()
    st = _eval_single_bet_leg(grow, str(lg.get('m') or 'ATS'), str(lg.get('s') or 'HOME'), float(lg.get('l') or 0.0))
    leg_states.append((st, float(lg.get('o') or config.DEFAULT_DECIMAL_ODDS)))
  if any(st == 'LOSS' for st, _ in leg_states):
    return 'LOSS', round(-stake, 2)
  if any(st == 'PENDING' for st, _ in leg_states):
    return 'PENDING', 0.0
  if all(st == 'PUSH' for st, _ in leg_states):
    return 'PUSH', 0.0
  if all(st == 'WIN' for st, _ in leg_states):
    return 'WIN', round(stake * (odds_dec - 1.0), 2)
  eff_mult = 1.0
  for st, lo in leg_states:
    if st == 'WIN':
      eff_mult *= lo
  return 'WIN', round(stake * (eff_mult - 1.0), 2)


def _grade_user_bets(conn: sqlite3.Connection) -> None:
  pending = conn.execute("SELECT * FROM user_bets WHERE status = 'PENDING' AND game_id != ''").fetchall()
  for b in pending:
    gid = str(b['game_id'] or '')
    if gid.startswith('PARLAY:'):
      res, pnl = _grade_parlay_bet(conn, b)
      if res != 'PENDING':
        conn.execute('UPDATE user_bets SET status = ?, pnl = ? WHERE bet_id = ?', (res, pnl, b['bet_id']))
      continue
    g = conn.execute('SELECT * FROM games WHERE game_id = ?', (gid,)).fetchone()
    res = _eval_single_bet_leg(g, b['market'], b['pick_side'], float(b['line'] or 0.0))
    if res != 'PENDING':
      odds = float(b['odds_decimal'] or config.DEFAULT_DECIMAL_ODDS)
      stake = float(b['stake'] or 0.0)
      pnl = round(stake * (odds - 1.0), 2) if res == 'WIN' else (-stake if res == 'LOSS' else 0.0)
      conn.execute('UPDATE user_bets SET status = ?, pnl = ? WHERE bet_id = ?', (res, pnl, b['bet_id']))
