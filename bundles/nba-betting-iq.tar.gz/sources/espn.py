#!/usr/bin/env python3
"""ESPN NBA live & historical collector: Scoreboard, Summary, Opening/Closing Odds, Standings, Injuries."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import re
from typing import Any

import config
import net
import teams

SCOREBOARD_URL = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard?dates={ymd}'
SUMMARY_URL = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/summary?event={gid}'
CORE_ODDS_LIST_URL = 'https://sports.core.api.espn.com/v2/sports/basketball/leagues/nba/events/{gid}/competitions/{gid}/odds?lang=en&region=us'
STANDINGS_URL = 'https://site.api.espn.com/apis/v2/sports/basketball/nba/standings'
INJURIES_URL = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/injuries'
ROSTER_URL = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/teams/{slug}/roster'

# Curated tier of NBA All-NBA / All-Star franchise cornerstones whose absence moves spreads by ~3.0–5.5 pts
STAR_PLAYERS: dict[str, float] = {
    'Nikola Jokic': 5.5, 'Shai Gilgeous-Alexander': 5.0, 'Luka Doncic': 5.0, 'Giannis Antetokounmpo': 5.0,
    'Jayson Tatum': 4.5, 'Joel Embiid': 4.8, 'Stephen Curry': 4.5, 'Anthony Edwards': 4.3,
    'Victor Wembanyama': 4.5, 'Anthony Davis': 4.2, 'LeBron James': 3.8, 'Kevin Durant': 4.2,
    'Devin Booker': 3.8, 'Jalen Brunson': 4.2, 'Donovan Mitchell': 4.0, 'Tyrese Haliburton': 3.8,
    'Ja Morant': 3.8, 'Trae Young': 3.6, 'Kawhi Leonard': 3.8, 'Jimmy Butler': 3.4,
    'Damian Lillard': 3.5, 'Kyrie Irving': 3.5, 'Jaylen Brown': 3.4, 'Paolo Banchero': 3.5,
    'Cade Cunningham': 3.4, 'De\'Aaron Fox': 3.5, 'Domantas Sabonis': 3.5, 'Bam Adebayo': 3.3,
    'Tyrese Maxey': 3.4, 'Zion Williamson': 3.3, 'Chet Holmgren': 3.2, 'Jalen Williams': 3.1,
    'Karl-Anthony Towns': 3.2, 'Evan Mobley': 3.0, 'Darius Garland': 2.8, 'Alperen Sengun': 3.1,
    'LaMelo Ball': 3.2, 'Scottie Barnes': 3.0, 'Franz Wagner': 2.9, 'Pascal Siakam': 2.9,
    'Paul George': 2.9, 'James Harden': 3.0, 'Lauri Markkanen': 3.0, 'Jamal Murray': 2.9,
    'Kristaps Porzingis': 2.7, 'Derrick White': 2.6, 'Jalen Johnson': 2.7, 'Brandon Ingram': 2.6,
    'Jaren Jackson Jr.': 2.8, 'Desmond Bane': 2.6, 'Cooper Flagg': 2.8,
}


def _to_float(val: Any) -> float | None:
  if val is None or val == '':
    return None
  s = str(val).strip().upper()
  if s in ('EVEN', 'PK', 'PICK'):
    return 0.0
  s = s.replace('+', '')
  try:
    return float(s)
  except ValueError:
    return None


def _to_int(val: Any) -> int | None:
  f = _to_float(val)
  return int(round(f)) if f is not None else None


def _parse_spread_from_details(details: str, home_abbr: str, away_abbr: str) -> float | None:
  """Parses ESPN details like 'BOS -13.5' or 'MIA -2.5' into home_spread (- means home favored)."""
  if not details:
    return None
  d = details.strip().upper()
  if d in ('EVEN', 'PK', 'PICK'):
    return 0.0
  parts = d.split()
  if len(parts) >= 2:
    fav = teams.norm_team(parts[0])
    num = _to_float(parts[1])
    if num is not None:
      mag = abs(num)
      if fav == home_abbr:
        return -mag
      if fav == away_abbr:
        return +mag
  return None


def compute_outcomes(
    status: str,
    home_score: int | None,
    away_score: int | None,
    spread_home: float | None,
    total_line: float | None,
) -> dict[str, Any]:
  """Computes margin, total_points, ATS cover winner, and O/U result for FINAL games."""
  if status != 'FINAL' or home_score is None or away_score is None:
    return {
        'margin_home': None,
        'total_points': None,
        'ats_winner': None,
        'ats_cover_margin': None,
        'ou_result': None,
        'ou_margin': None,
    }
  margin_home = int(home_score) - int(away_score)
  total_pts = int(home_score) + int(away_score)
  ats_winner = None
  ats_cover_margin = None
  if spread_home is not None:
    ats_cover_margin = round(margin_home + float(spread_home), 2)
    if ats_cover_margin > 0:
      ats_winner = 'HOME'
    elif ats_cover_margin < 0:
      ats_winner = 'AWAY'
    else:
      ats_winner = 'PUSH'

  ou_result = None
  ou_margin = None
  if total_line is not None and total_line > 0:
    ou_margin = round(total_pts - float(total_line), 2)
    if ou_margin > 0:
      ou_result = 'OVER'
    elif ou_margin < 0:
      ou_result = 'UNDER'
    else:
      ou_result = 'PUSH'

  return {
      'margin_home': margin_home,
      'total_points': total_pts,
      'ats_winner': ats_winner,
      'ats_cover_margin': ats_cover_margin,
      'ou_result': ou_result,
      'ou_margin': ou_margin,
  }


def _map_status(st_obj: dict[str, Any]) -> tuple[str, str]:
  t = (st_obj or {}).get('type') or {}
  state = (t.get('state') or '').lower()
  completed = bool(t.get('completed'))
  detail = str(t.get('shortDetail') or t.get('detail') or '')
  if completed or state == 'post':
    return 'FINAL', detail
  if state == 'in':
    return 'IN_PROGRESS', detail
  return 'SCHEDULED', detail


def fetch_scoreboard_date(et_date: dt.date, include_odds: bool = True) -> list[dict[str, Any]]:
  """Fetches all regular-season/postseason NBA games on a US Eastern date."""
  ymd = et_date.strftime('%Y%m%d')
  data = net.fetch_json(SCOREBOARD_URL.format(ymd=ymd))
  out: list[dict[str, Any]] = []
  for ev in data.get('events') or []:
    stype = int(((ev.get('season') or {}).get('type')) or 2)
    if stype == 1:
      # Skip preseason games so regular-season ATS / team stats stay pure
      continue
    gid = str(ev.get('id') or '').strip()
    comps = ev.get('competitions') or []
    if not gid or not comps:
      continue
    comp = comps[0]
    raw_date = str(comp.get('date') or ev.get('date') or '')
    try:
      dt_utc = dt.datetime.fromisoformat(raw_date.replace('Z', '+00:00')).astimezone(config.TZ_UTC)
    except ValueError:
      dt_utc = dt.datetime.combine(et_date, dt.time(23, 30), tzinfo=config.TZ_UTC)
    dt_tw = dt_utc.astimezone(config.TZ_TW)
    dt_et = dt_utc.astimezone(config.TZ_ET)

    home_c, away_c = None, None
    for c in comp.get('competitors') or []:
      if c.get('homeAway') == 'home':
        home_c = c
      elif c.get('homeAway') == 'away':
        away_c = c
    if not home_c or not away_c:
      continue

    home_abbr = teams.norm_team((home_c.get('team') or {}).get('abbreviation'))
    away_abbr = teams.norm_team((away_c.get('team') or {}).get('abbreviation'))
    status, status_detail = _map_status(comp.get('status') or ev.get('status') or {})

    home_score = _to_int(home_c.get('score')) if status != 'SCHEDULED' else None
    away_score = _to_int(away_c.get('score')) if status != 'SCHEDULED' else None
    home_q = [_to_int(x.get('value')) or 0 for x in (home_c.get('linescores') or [])]
    away_q = [_to_int(x.get('value')) or 0 for x in (away_c.get('linescores') or [])]

    def _rec(comp_item: dict[str, Any]) -> str:
      for r in comp_item.get('records') or []:
        if r.get('type') in ('total', 'overall') or not r.get('type'):
          return str(r.get('summary') or '')
      return ''

    # Scoreboard odds (captured ONLY when include_odds=True, i.e., 23:00 TW daily snapshot)
    open_spread, close_spread, open_tot, close_tot = None, None, None, None
    home_ml, away_ml, h_sp_odds, a_sp_odds, ov_odds, un_odds = None, None, None, None, None, None
    provider = 'DraftKings'
    odds_arr = (comp.get('odds') or []) if include_odds else []
    if odds_arr:
      o0 = odds_arr[0]
      provider = str(((o0.get('provider') or {}).get('name')) or 'DraftKings')
      close_tot = _to_float(o0.get('overUnder'))
      close_spread = _parse_spread_from_details(str(o0.get('details') or ''), home_abbr, away_abbr)
      if close_spread is None and o0.get('spread') is not None:
        # ESPN 'spread' field is signed from home perspective when home is fav, check favorite flag
        ho = o0.get('homeTeamOdds') or {}
        ao = o0.get('awayTeamOdds') or {}
        sp_mag = abs(_to_float(o0.get('spread')) or 0.0)
        if ho.get('favorite'):
          close_spread = -sp_mag
        elif ao.get('favorite'):
          close_spread = +sp_mag
        else:
          close_spread = _to_float(o0.get('spread'))
      ho = o0.get('homeTeamOdds') or {}
      ao = o0.get('awayTeamOdds') or {}
      home_ml = _to_int(ho.get('moneyLine'))
      away_ml = _to_int(ao.get('moneyLine'))
      h_sp_odds = _to_int(ho.get('spreadOdds'))
      a_sp_odds = _to_int(ao.get('spreadOdds'))
      ov_odds = _to_int(o0.get('overOdds'))
      un_odds = _to_int(o0.get('underOdds'))

    # Leaders snippet
    leaders_map: dict[str, list[dict[str, str]]] = {}
    for side_key, c_item in (('home', home_c), ('away', away_c)):
      arr = []
      for ld in (c_item.get('leaders') or [])[:3]:
        l0 = (ld.get('leaders') or [{}])[0]
        ath = (l0.get('athlete') or {}).get('shortName') or (l0.get('athlete') or {}).get('displayName') or ''
        if ath:
          arr.append({'cat': str(ld.get('abbreviation') or ld.get('name') or ''), 'player': ath, 'val': str(l0.get('displayValue') or '')})
      leaders_map[side_key] = arr

    out.append({
        'game_id': gid,
        'season_year': int(((ev.get('season') or {}).get('year')) or config.SEASON_YEAR),
        'et_date': dt_et.strftime('%Y-%m-%d'),
        'tw_date': dt_tw.strftime('%Y-%m-%d'),
        'tipoff_utc': dt_utc.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'tipoff_tw': dt_tw.strftime('%Y-%m-%d %H:%M'),
        'status': status,
        'status_detail': status_detail,
        'away_abbr': away_abbr,
        'home_abbr': home_abbr,
        'away_score': away_score,
        'home_score': home_score,
        'away_q_scores': away_q,
        'home_q_scores': home_q,
        'away_record': _rec(away_c),
        'home_record': _rec(home_c),
        'open_spread_home': open_spread,
        'close_spread_home': close_spread,
        'open_total': open_tot,
        'close_total': close_tot,
        'home_ml': home_ml,
        'away_ml': away_ml,
        'home_spread_odds': h_sp_odds,
        'away_spread_odds': a_sp_odds,
        'over_odds': ov_odds,
        'under_odds': un_odds,
        'odds_provider': provider,
        'bpi_home_win_pct': None,
        'boxscore': {},
        'leaders': leaders_map,
    })
  return out


def enrich_game_detail(g: dict[str, Any], fetch_odds: bool = True) -> dict[str, Any]:
  """Enriches a game dict with ESPN Summary (BPI predictor, boxscore) and optional 23:00 TW Odds."""
  gid = g['game_id']
  home_abbr = g['home_abbr']
  away_abbr = g['away_abbr']

  # 1. Summary endpoint (BPI predictor + boxscore team/player stats; pickcenter ONLY when fetch_odds=True)
  try:
    summ = net.fetch_json(SUMMARY_URL.format(gid=gid))
  except Exception:  # pylint: disable=broad-except
    summ = {}

  pcs = (summ.get('pickcenter') or []) if fetch_odds else []
  if pcs:
    pc = pcs[0]
    g['odds_provider'] = str(((pc.get('provider') or {}).get('name')) or g.get('odds_provider') or 'DraftKings')
    sp = _parse_spread_from_details(str(pc.get('details') or ''), home_abbr, away_abbr)
    if sp is None and pc.get('spread') is not None:
      ho = pc.get('homeTeamOdds') or {}
      ao = pc.get('awayTeamOdds') or {}
      mag = abs(_to_float(pc.get('spread')) or 0.0)
      sp = -mag if ho.get('favorite') else (+mag if ao.get('favorite') else _to_float(pc.get('spread')))
    if sp is not None:
      g['close_spread_home'] = sp
    tot = _to_float(pc.get('overUnder'))
    if tot is not None and tot > 0:
      g['close_total'] = tot
    ho = pc.get('homeTeamOdds') or {}
    ao = pc.get('awayTeamOdds') or {}
    if ho.get('moneyLine') is not None:
      g['home_ml'] = _to_int(ho.get('moneyLine'))
    if ao.get('moneyLine') is not None:
      g['away_ml'] = _to_int(ao.get('moneyLine'))
    if ho.get('spreadOdds') is not None:
      g['home_spread_odds'] = _to_int(ho.get('spreadOdds'))
    if ao.get('spreadOdds') is not None:
      g['away_spread_odds'] = _to_int(ao.get('away_spread_odds') if ao.get('away_spread_odds') is not None else ao.get('spreadOdds'))
    if pc.get('overOdds') is not None:
      g['over_odds'] = _to_int(pc.get('overOdds'))
    if pc.get('underOdds') is not None:
      g['under_odds'] = _to_int(pc.get('underOdds'))

  pred = summ.get('predictor') or {}
  hp = _to_float((pred.get('homeTeam') or {}).get('gameProjection'))
  if hp is not None:
    g['bpi_home_win_pct'] = round(hp, 1)

  # Boxscore team shooting / rebounding / turnover metrics (crucial for post-mortem diagnostics!)
  box_teams = ((summ.get('boxscore') or {}).get('teams')) or []
  if box_teams:
    bmap: dict[str, dict[str, Any]] = {}
    for bt in box_teams:
      ab = teams.norm_team(((bt.get('team') or {}).get('abbreviation')))
      sdict: dict[str, Any] = {}
      for st in bt.get('statistics') or []:
        nm = str(st.get('name') or '')
        dv = str(st.get('displayValue') or '')
        if nm in (
            'fieldGoalPct', 'threePointFieldGoalPct', 'freeThrowPct',
            'totalRebounds', 'offensiveRebounds', 'assists', 'turnovers',
            'totalTurnovers', 'fastBreakPoints', 'pointsInPaint',
            'fieldGoalsMade-fieldGoalsAttempted',
            'threePointFieldGoalsMade-threePointFieldGoalsAttempted',
            'freeThrowsMade-freeThrowsAttempted',
        ):
          sdict[nm] = dv
      bmap['home' if ab == home_abbr else 'away'] = sdict
    g['boxscore'] = bmap

  # 2. Core Odds endpoint for Opening vs 23:00 TW Spread & Total (ONLY fetched when fetch_odds=True)
  if fetch_odds:
    try:
      co = net.fetch_json(CORE_ODDS_LIST_URL.format(gid=gid))
      items = co.get('items') or []
      if items:
        ref = str(items[0].get('$ref') or '').replace('http://', 'https://')
        if ref:
          od = net.fetch_json(ref)
          ho = od.get('homeTeamOdds') or {}
          ho_open = (ho.get('open') or {}).get('pointSpread') or {}
          ho_close = ((ho.get('close') or ho.get('current') or {}).get('pointSpread')) or {}
          open_sp = _to_float(ho_open.get('american') or ho_open.get('alternateDisplayValue'))
          close_sp = _to_float(ho_close.get('american') or ho_close.get('alternateDisplayValue'))
          if open_sp is not None:
            g['open_spread_home'] = open_sp
          if close_sp is not None:
            g['close_spread_home'] = close_sp

          tot_open = ((od.get('open') or {}).get('total')) or {}
          tot_close = (((od.get('close') or od.get('current') or {}).get('total'))) or {}
          open_t = _to_float(tot_open.get('american') or tot_open.get('alternateDisplayValue'))
          close_t = _to_float(tot_close.get('american') or tot_close.get('alternateDisplayValue'))
          if open_t is not None and open_t > 0:
            g['open_total'] = open_t
          if close_t is not None and close_t > 0:
            g['close_total'] = close_t
    except Exception:  # pylint: disable=broad-except
      pass

    if g.get('open_spread_home') is None and g.get('close_spread_home') is not None:
      g['open_spread_home'] = g['close_spread_home']
    if g.get('open_total') is None and g.get('close_total') is not None:
      g['open_total'] = g['close_total']

  outcomes = compute_outcomes(
      g['status'],
      g.get('home_score'),
      g.get('away_score'),
      g.get('close_spread_home'),
      g.get('close_total'),
  )
  g.update(outcomes)
  if summ:
    g['player_logs'] = extract_player_boxscores(summ, g)
  return g


def _parse_made_att(raw: str) -> tuple[int, int]:
  if not raw or '-' not in str(raw):
    return 0, 0
  parts = str(raw).strip().split('-', 1)
  return (_to_int(parts[0]) or 0), (_to_int(parts[1]) or 0)


def _parse_minutes(raw: str) -> float:
  if not raw:
    return 0.0
  s = str(raw).strip()
  if ':' in s:
    mm, ss = s.split(':', 1)
    return round((_to_float(mm) or 0.0) + (_to_float(ss) or 0.0) / 60.0, 2)
  return round(_to_float(s) or 0.0, 2)


def extract_player_boxscores(summ: dict[str, Any], g: dict[str, Any]) -> list[dict[str, Any]]:
  """Extracts per-player boxscore rows (starters, bench, and DNPs) from an ESPN game summary."""
  gid = str(g['game_id'])
  home_abbr = g['home_abbr']
  away_abbr = g['away_abbr']
  h_sc = g.get('home_score')
  a_sc = g.get('away_score')
  bp_list = ((summ.get('boxscore') or {}).get('players')) or []
  rows: list[dict[str, Any]] = []

  for bp in bp_list:
    ab = teams.norm_team(((bp.get('team') or {}).get('abbreviation')))
    if not ab:
      continue
    is_home = 1 if ab == home_abbr else 0
    opp_abbr = away_abbr if is_home else home_abbr
    team_win = 0
    if h_sc is not None and a_sc is not None:
      team_win = 1 if ((is_home and h_sc > a_sc) or (not is_home and a_sc > h_sc)) else 0

    for st_block in bp.get('statistics') or []:
      labels = [str(x).upper() for x in (st_block.get('labels') or [])]
      idx = {lbl: i for i, lbl in enumerate(labels)}

      def _val(arr: list[Any], key: str) -> str:
        pos = idx.get(key)
        return str(arr[pos]) if pos is not None and pos < len(arr) else ''

      for a_entry in st_block.get('athletes') or []:
        ath = a_entry.get('athlete') or {}
        pid = str(ath.get('id') or '').strip()
        pname = net.clean_str(ath.get('displayName') or ath.get('shortName') or '')
        if not pid or not pname:
          continue
        short_nm = net.clean_str(ath.get('shortName') or pname)
        jersey = str(ath.get('jersey') or '')
        pos = str(((ath.get('position') or {}).get('abbreviation')) or '')
        headshot = str(((ath.get('headshot') or {}).get('href')) or f'https://a.espncdn.com/i/headshots/nba/players/full/{pid}.png')
        starter = 1 if a_entry.get('starter') else 0
        raw_stats = a_entry.get('stats') or []
        dnp = 1 if (a_entry.get('didNotPlay') or not raw_stats) else 0
        dnp_reason = net.clean_str(a_entry.get('reason') or ('未上場 DNP' if dnp else ''))

        min_str = '' if dnp else _val(raw_stats, 'MIN')
        minutes = 0.0 if dnp else _parse_minutes(min_str)
        if not dnp and minutes <= 0.0 and _val(raw_stats, 'PTS') == '':
          dnp = 1
          dnp_reason = dnp_reason or '未上場 DNP'

        fgm, fga = (0, 0) if dnp else _parse_made_att(_val(raw_stats, 'FG'))
        tpm, tpa = (0, 0) if dnp else _parse_made_att(_val(raw_stats, '3PT'))
        ftm, fta = (0, 0) if dnp else _parse_made_att(_val(raw_stats, 'FT'))
        pts = 0 if dnp else (_to_int(_val(raw_stats, 'PTS')) or 0)
        reb = 0 if dnp else (_to_int(_val(raw_stats, 'REB')) or 0)
        ast = 0 if dnp else (_to_int(_val(raw_stats, 'AST')) or 0)
        tov = 0 if dnp else (_to_int(_val(raw_stats, 'TO')) or 0)
        stl = 0 if dnp else (_to_int(_val(raw_stats, 'STL')) or 0)
        blk = 0 if dnp else (_to_int(_val(raw_stats, 'BLK')) or 0)
        oreb = 0 if dnp else (_to_int(_val(raw_stats, 'OREB')) or 0)
        dreb = 0 if dnp else (_to_int(_val(raw_stats, 'DREB')) or 0)
        pf = 0 if dnp else (_to_int(_val(raw_stats, 'PF')) or 0)
        pm = 0 if dnp else (_to_int(_val(raw_stats, '+/-')) or 0)

        rows.append({
            'game_id': gid,
            'player_id': pid,
            'player_name': pname,
            'short_name': short_nm,
            'team_abbr': ab,
            'opp_abbr': opp_abbr,
            'et_date': g['et_date'],
            'tw_date': g['tw_date'],
            'is_home': is_home,
            'team_win': team_win,
            'starter': starter,
            'dnp': dnp,
            'dnp_reason': dnp_reason,
            'jersey': jersey,
            'position': pos,
            'headshot': headshot,
            'min_str': min_str,
            'minutes': minutes,
            'pts': pts,
            'fgm': fgm,
            'fga': fga,
            'tpm': tpm,
            'tpa': tpa,
            'ftm': ftm,
            'fta': fta,
            'oreb': oreb,
            'dreb': dreb,
            'reb': reb,
            'ast': ast,
            'tov': tov,
            'stl': stl,
            'blk': blk,
            'pf': pf,
            'plus_minus': pm,
        })
  return rows


def fetch_player_logs_for_game(g: dict[str, Any]) -> list[dict[str, Any]]:
  """Fetches only ESPN summary to backfill per-player boxscores for an already-stored FINAL game."""
  try:
    summ = net.fetch_json(SUMMARY_URL.format(gid=g['game_id']))
  except Exception:  # pylint: disable=broad-except
    return []
  return extract_player_boxscores(summ, g)


def fetch_all_rosters() -> list[dict[str, Any]]:
  """Fetches active rosters (including player age, jersey, position, headshot) across all 30 NBA teams."""
  def _one(item: tuple[str, dict[str, str]]) -> list[dict[str, Any]]:
    abbr, meta = item
    try:
      data = net.fetch_json(ROSTER_URL.format(slug=meta['espn']))
    except Exception:  # pylint: disable=broad-except
      return []
    out: list[dict[str, Any]] = []
    for a in data.get('athletes') or []:
      pid = str(a.get('id') or '').strip()
      pname = net.clean_str(a.get('displayName') or a.get('fullName') or '')
      if not pid or not pname:
        continue
      out.append({
          'player_id': pid,
          'player_name': pname,
          'team_abbr': abbr,
          'age': _to_int(a.get('age')) or 0,
          'position': str(((a.get('position') or {}).get('abbreviation')) or ''),
          'jersey': str(a.get('jersey') or ''),
          'headshot': str(((a.get('headshot') or {}).get('href')) or f'https://a.espncdn.com/i/headshots/nba/players/full/{pid}.png'),
      })
    return out

  merged: list[dict[str, Any]] = []
  with ThreadPoolExecutor(max_workers=10) as pool:
    for sub in pool.map(_one, list(teams.TEAMS.items())):
      merged.extend(sub)
  return merged


def fetch_standings() -> list[dict[str, Any]]:
  """Fetches NBA standings (W-L, PPG, Opp PPG, Diff, Home/Road/L10, Streak) for all 30 teams."""
  data = net.fetch_json(STANDINGS_URL)
  rows: list[dict[str, Any]] = []
  for child in data.get('children') or []:
    entries = ((child.get('standings') or {}).get('entries')) or []
    for ent in entries:
      ab = teams.norm_team(((ent.get('team') or {}).get('abbreviation')))
      if not ab:
        continue
      smap: dict[str, Any] = {}
      for st in ent.get('stats') or []:
        nm = str(st.get('name') or st.get('type') or '')
        smap[nm] = st.get('displayValue') if st.get('displayValue') is not None else st.get('value')
      wins = _to_int(smap.get('wins')) or 0
      losses = _to_int(smap.get('losses')) or 0
      gp = max(1, wins + losses)
      ppg = _to_float(smap.get('avgPointsFor')) or 113.5
      opp_ppg = _to_float(smap.get('avgPointsAgainst')) or 113.5
      diff = round(ppg - opp_ppg, 2)
      rows.append({
          'abbr': ab,
          'wins': wins,
          'losses': losses,
          'win_pct': round(wins / gp, 4) if (wins + losses) > 0 else 0.5,
          'home_record': str(smap.get('Home') or '0-0'),
          'road_record': str(smap.get('Road') or '0-0'),
          'l10_record': str(smap.get('Last Ten Games') or f'{wins}-{losses}'),
          'streak': str(smap.get('streak') or ''),
          'ppg': round(ppg, 1),
          'opp_ppg': round(opp_ppg, 1),
          'diff': diff,
      })
  return rows


def classify_injury_status(raw_status: str, comment: str = '') -> tuple[str, str, int]:
  """Maps raw injury status to (canonical_en, zh_label, play_prob_next_pct)."""
  s = (raw_status or '').strip().lower()
  c = (comment or '').lower()
  if 'season' in c and ('miss the remainder' in c or 'out for season' in c or 'torn acl' in c or 'torn achilles' in c):
    return 'Out', '本季報銷 / 長期缺陣', 0
  if 'out' in s or s == 'ofs' or 'ruled out' in c or 'will not play' in c:
    return 'Out', '確定缺陣 (Out)', 0
  if 'doubt' in s or 'unlikely to play' in c:
    return 'Doubtful', '極可能缺陣 (Doubtful)', 20
  if 'quest' in s or 'gtd' in s:
    return 'Questionable', '出戰成疑 (GTD 50%)', 50
  if 'day-to-day' in s or 'day to day' in s:
    if 'ruled out' in c or 'will not play' in c or 'remains out' in c or 'surgery' in c:
      return 'Out', '確定缺陣 (Out)', 0
    if 'doubtful' in c:
      return 'Doubtful', '極可能缺陣 (Doubtful)', 25
    if 'probable' in c or 'expected to play' in c:
      return 'Probable', '大機率出戰 (Probable)', 85
    return 'Questionable', '每日觀察／賽前決定 (GTD)', 55
  if 'prob' in s:
    return 'Probable', '大機率出戰 (Probable)', 85
  return 'Questionable', '觀察名單 (GTD)', 50


def estimate_player_impact(player_name: str, known_starters: set[str], comment: str = '') -> tuple[str, float, float]:
  """Estimates (impact_tier, est_spread_pts, est_total_pts_when_out)."""
  if player_name in STAR_PLAYERS:
    pts = STAR_PLAYERS[player_name]
    return 'STAR', pts, round(-pts * 0.55, 2)
  # Check normalized last/first match
  p_clean = re.sub(r'[^a-z ]', '', player_name.lower()).strip()
  for star, pts in STAR_PLAYERS.items():
    if re.sub(r'[^a-z ]', '', star.lower()).strip() == p_clean:
      return 'STAR', pts, round(-pts * 0.55, 2)
  if player_name in known_starters or 'starter' in comment.lower() or 'starting' in comment.lower():
    return 'STARTER', 1.8, -0.8
  return 'ROTATION', 0.6, -0.2


def fetch_injuries(known_starters: set[str] | None = None) -> list[dict[str, Any]]:
  """Fetches league-wide NBA player injuries from ESPN."""
  starters = known_starters or set()
  data = net.fetch_json(INJURIES_URL)
  out: list[dict[str, Any]] = []
  for team_block in data.get('injuries') or []:
    t_name = str(team_block.get('displayName') or '')
    ab = teams.norm_team(t_name)
    for item in team_block.get('injuries') or []:
      ath = item.get('athlete') or {}
      pname = net.clean_str(ath.get('displayName') or f"{ath.get('firstName', '')} {ath.get('lastName', '')}")
      if not pname:
        continue
      # Team fallback from athlete links if team_block lacked displayName
      if not ab:
        ab = teams.norm_team(((ath.get('team') or {}).get('abbreviation')))
      pos = str(((ath.get('position') or {}).get('abbreviation')) or '')
      short_c = net.clean_str(item.get('shortComment'))
      long_c = net.clean_str(item.get('longComment'))
      raw_st = str(item.get('status') or '')
      details = item.get('details') or {}
      inj_type = net.clean_str(details.get('type') or details.get('detail') or '')
      ret_date = str(details.get('returnDate') or '')
      st_en, st_zh, prob = classify_injury_status(raw_st, f'{short_c} {long_c}')
      tier, sp_pts, tot_pts = estimate_player_impact(pname, starters, f'{short_c} {long_c}')
      out.append({
          'inj_key': f'{ab}::{pname}',
          'team_abbr': ab,
          'player_name': pname,
          'position': pos,
          'status': st_en,
          'status_zh': st_zh,
          'play_prob_next': prob,
          'impact_tier': tier,
          'est_spread_pts': sp_pts,
          'est_total_pts': tot_pts,
          'injury_type': inj_type,
          'return_date': ret_date,
          'short_comment': short_c,
          'long_comment': long_c,
          'report_date': str(item.get('date') or ''),
          'source': 'ESPN Official Injury Report',
      })
  return out
