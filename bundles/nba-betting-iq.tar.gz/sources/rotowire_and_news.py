#!/usr/bin/env python3
"""RotoWire Starting Lineups / GTD Scraper + Multi-Source NBA News & Injury Feed."""
from __future__ import annotations

import datetime as dt
import email.utils
import hashlib
import re
import xml.etree.ElementTree as ET
from typing import Any

import config
import net
from sources import espn
import teams

ROTOWIRE_LINEUPS_URL = 'https://www.rotowire.com/basketball/nba-lineups.php'
ESPN_NEWS_URL = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/news?limit=35'
GNEWS_INJURY_EN = (
    'https://news.google.com/rss/search?'
    'q=NBA+(injury+report+OR+questionable+OR+doubtful+OR+%22ruled+out%22+OR+%22expected+to+play%22+OR+lineup)+when:2d'
    '&hl=en-US&gl=US&ceid=US:en'
)
GNEWS_NBA_ZH = (
    'https://news.google.com/rss/search?'
    'q=NBA+(%E5%82%B7%E5%85%B5+OR+%E7%BC%BA%E9%99%A3+OR+%E5%87%BA%E6%88%B0+OR+%E5%85%88%E7%99%BC+OR+%E9%81%8B%E5%BD%A9+OR+%E8%AE%93%E5%88%86)+when:3d'
    '&hl=zh-TW&gl=TW&ceid=TW:zh-Hant'
)


def fetch_rotowire_lineups() -> tuple[list[dict[str, Any]], set[str], list[dict[str, Any]]]:
  """Parses RotoWire NBA daily lineups for projected starters & MAY NOT PLAY late GTD updates."""
  try:
    raw = net.fetch_text(ROTOWIRE_LINEUPS_URL, timeout=12.0)
  except Exception:  # pylint: disable=broad-except
    return [], set(), []

  lineups: list[dict[str, Any]] = []
  all_starters: set[str] = set()
  extra_injuries: list[dict[str, Any]] = []

  boxes = re.findall(r'class="lineup__box[^"]*".*?(?=class="lineup__box[^"]*"|</main>)', raw, re.S)
  for box in boxes:
    # Extract away & home team abbreviations
    ab_matches = re.findall(r'class="lineup__abbr"[^>]*>\s*([A-Z]{2,4})\s*<', box)
    if len(ab_matches) < 2:
      continue
    away_abbr = teams.norm_team(ab_matches[0])
    home_abbr = teams.norm_team(ab_matches[1])
    if not away_abbr or not home_abbr:
      continue

    # Split into visit and home lists
    lists = re.findall(r'<ul[^>]*class="lineup__list[^"]*"[^>]*>(.*?)</ul>', box, re.S)
    if len(lists) < 2:
      continue

    parsed_sides = []
    for side_idx, ul_html in enumerate(lists[:2]):
      side_abbr = away_abbr if side_idx == 0 else home_abbr
      confirmed = bool(re.search(r'Confirmed Lineup', ul_html, re.I))
      starters: list[dict[str, str]] = []
      may_not_play: list[dict[str, str]] = []
      in_mnp = False

      for li in re.findall(r'<li[^>]*>(.*?)</li>', ul_html, re.S):
        if 'MAY NOT PLAY' in li.upper():
          in_mnp = True
          continue
        pos_m = re.search(r'class="lineup__pos"[^>]*>\s*([A-Z/]+)\s*<', li)
        name_m = re.search(r'<a[^>]*title="([^"]+)"[^>]*>', li) or re.search(r'<a[^>]*>\s*([^<]+?)\s*</a>', li)
        inj_m = re.search(r'class="lineup__inj"[^>]*>\s*([^<]+?)\s*<', li)
        if not name_m:
          continue
        pname = net.clean_str(name_m.group(1))
        pos = net.clean_str(pos_m.group(1)) if pos_m else ''
        inj_tag = net.clean_str(inj_m.group(1)) if inj_m else ''
        if not in_mnp and len(starters) < 5:
          starters.append({'pos': pos, 'player': pname, 'tag': inj_tag})
          all_starters.add(pname)
        else:
          may_not_play.append({'pos': pos, 'player': pname, 'status': inj_tag or 'GTD'})
        if inj_tag:
          st_en, st_zh, prob = espn.classify_injury_status(inj_tag, '')
          tier, sp_pts, tot_pts = espn.estimate_player_impact(pname, all_starters)
          extra_injuries.append({
              'inj_key': f'{side_abbr}::{pname}',
              'team_abbr': side_abbr,
              'player_name': pname,
              'position': pos,
              'status': st_en,
              'status_zh': st_zh,
              'play_prob_next': prob,
              'impact_tier': tier,
              'est_spread_pts': sp_pts,
              'est_total_pts': tot_pts,
              'injury_type': inj_tag,
              'return_date': '',
              'short_comment': f'RotoWire 即時賽前名單標記：{inj_tag}' + ('（預計先發）' if not in_mnp else '（可能缺陣）'),
              'long_comment': '',
              'report_date': dt.datetime.now(config.TZ_UTC).strftime('%Y-%m-%dT%H:%M:%SZ'),
              'source': 'RotoWire Daily Lineups',
          })
      parsed_sides.append((confirmed, starters, may_not_play))

    lineups.append({
        'matchup_key': f'{away_abbr}@{home_abbr}',
        'away_abbr': away_abbr,
        'home_abbr': home_abbr,
        'away_confirmed': 1 if parsed_sides[0][0] else 0,
        'home_confirmed': 1 if parsed_sides[1][0] else 0,
        'away_starters': parsed_sides[0][1],
        'home_starters': parsed_sides[1][1],
        'away_may_not_play': parsed_sides[0][2],
        'home_may_not_play': parsed_sides[1][2],
    })
  return lineups, all_starters, extra_injuries


def _classify_news(title: str, summary: str, known_players: list[str]) -> dict[str, Any]:
  txt = f'{title} {summary}'
  low = txt.lower()

  # Detect play availability signal
  play_signal = ''
  if re.search(r'\b(ruled out|will not play|out for|sidelined|miss|surgery)\b|確定缺陣|不會上場|報銷|缺席|傷退', low):
    play_signal = 'OUT'
  elif re.search(r'\b(questionable|game-time decision|gtd|doubtful|uncertain)\b|出戰成疑|賽前決定|存疑|觀察名單', low):
    play_signal = 'QUESTIONABLE'
  elif re.search(r'\b(probable|expected to play|likely to play)\b|大機率出戰|預計上場|有望出戰', low):
    play_signal = 'PROBABLE'
  elif re.search(r'\b(available|cleared to play|will play|returns to lineup|returning)\b|復出|歸隊|確定出戰', low):
    play_signal = 'AVAILABLE'

  # Category classification
  if re.search(r'\b(rest|load management|back-to-back)\b|輪休|背靠背', low):
    cat, cat_zh = 'rest', '😴 輪休／背靠背'
  elif play_signal or re.search(r'\b(injur|ankle|knee|hamstring|concussion|sprain|strain|soreness|illness|fracture)\b|傷兵|受傷|扭傷|拉傷', low):
    cat, cat_zh = 'injury', '🏥 傷兵與出賽動態'
  elif re.search(r'\b(starting lineup|starters|bench|promoted)\b|先發|變陣|替補', low):
    cat, cat_zh = 'lineup', '📋 先發與陣容異動'
  elif re.search(r'\b(odds|spread|over/under|picks|betting|ats|underdog|favorite)\b|運彩|讓分|大小分|盤口|賠率|過盤', low):
    cat, cat_zh = 'odds', '💰 盤口與運彩焦點'
  else:
    cat, cat_zh = 'game', '🏀 賽事與戰力情報'

  t_list = teams.detect_teams_in_text(txt)
  p_list: list[str] = []
  for p in known_players:
    if len(p) >= 5 and p.lower() in low and p not in p_list:
      p_list.append(p)
      if len(p_list) >= 4:
        break

  return {
      'category': cat,
      'category_zh': cat_zh,
      'teams': t_list,
      'players': p_list,
      'play_signal': play_signal,
  }


def _parse_pub_time(raw_dt: str) -> tuple[str, str]:
  now_utc = dt.datetime.now(config.TZ_UTC)
  parsed: dt.datetime | None = None
  if raw_dt:
    try:
      parsed = dt.datetime.fromisoformat(raw_dt.replace('Z', '+00:00')).astimezone(config.TZ_UTC)
    except ValueError:
      try:
        parsed = email.utils.parsedate_to_datetime(raw_dt).astimezone(config.TZ_UTC)
      except (TypeError, ValueError):
        parsed = None
  if not parsed:
    parsed = now_utc
  return parsed.strftime('%Y-%m-%dT%H:%M:%SZ'), parsed.astimezone(config.TZ_TW).strftime('%m/%d %H:%M')


def _parse_rss(xml_text: str, lang: str, default_source: str, known_players: list[str]) -> list[dict[str, Any]]:
  items: list[dict[str, Any]] = []
  try:
    root = ET.fromstring(xml_text)
  except ET.ParseError:
    return items
  for item in root.findall('.//item')[:35]:
    title_raw = net.clean_str(item.findtext('title'))
    link = net.clean_str(item.findtext('link'))
    pub = net.clean_str(item.findtext('pubDate'))
    src_el = item.find('source')
    source = net.clean_str(src_el.text if src_el is not None else '') or default_source
    # Strip trailing " - Source Name" from Google News titles
    if ' - ' in title_raw:
      head, tail = title_raw.rsplit(' - ', 1)
      if len(tail) <= 28:
        title_raw = head.strip()
        if source == default_source:
          source = tail.strip()
    desc = net.clean_str(item.findtext('description'))
    if desc and title_raw and desc.startswith(title_raw[:25]):
      desc = ''
    if not title_raw or not link:
      continue
    pub_utc, pub_tw = _parse_pub_time(pub)
    meta = _classify_news(title_raw, desc, known_players)
    nid = hashlib.sha1(f'{title_raw.lower()[:60]}'.encode('utf-8')).hexdigest()[:16]
    items.append({
        'news_id': nid,
        'published_at': pub_utc,
        'published_tw': pub_tw,
        'title': title_raw,
        'summary': desc[:260],
        'url': link,
        'source': source,
        'lang': lang,
        **meta,
    })
  return items


def fetch_all_nba_news(extra_players: set[str] | None = None) -> list[dict[str, Any]]:
  """Collects & deduplicates ESPN NBA News + EN Injury/Lineup RSS + ZH-TW NBA/Betting RSS."""
  player_pool = sorted(set(espn.STAR_PLAYERS.keys()) | (extra_players or set()), key=len, reverse=True)
  collected: list[dict[str, Any]] = []

  # 1. ESPN Official NBA News JSON
  try:
    ej = net.fetch_json(ESPN_NEWS_URL, timeout=10.0)
    for art in ej.get('articles') or []:
      title = net.clean_str(art.get('headline'))
      desc = net.clean_str(art.get('description'))
      url = str((((art.get('links') or {}).get('web') or {}).get('href')) or '')
      if not title or not url:
        continue
      pub_utc, pub_tw = _parse_pub_time(str(art.get('published') or ''))
      meta = _classify_news(title, desc, player_pool)
      # Enrich team tags from ESPN categories if available
      for cat in art.get('categories') or []:
        if cat.get('type') == 'team':
          ab = teams.norm_team(((cat.get('team') or {}).get('abbreviation')) or str(cat.get('description') or ''))
          if ab in teams.TEAMS and ab not in meta['teams']:
            meta['teams'].append(ab)
      nid = hashlib.sha1(f'espn::{title.lower()[:60]}'.encode('utf-8')).hexdigest()[:16]
      collected.append({
          'news_id': nid,
          'published_at': pub_utc,
          'published_tw': pub_tw,
          'title': title,
          'summary': desc[:260],
          'url': url,
          'source': 'ESPN NBA',
          'lang': 'en',
          **meta,
      })
  except Exception:  # pylint: disable=broad-except
    pass

  # 2. Google News EN Injury / Lineup RSS
  try:
    xml_en = net.fetch_text(GNEWS_INJURY_EN, timeout=10.0)
    collected.extend(_parse_rss(xml_en, 'en', 'NBA Injury Wire', player_pool))
  except Exception:  # pylint: disable=broad-except
    pass

  # 3. Google News ZH-TW NBA 傷兵 / 運彩 RSS
  try:
    xml_zh = net.fetch_text(GNEWS_NBA_ZH, timeout=10.0)
    collected.extend(_parse_rss(xml_zh, 'zh', '台灣 NBA 焦點', player_pool))
  except Exception:  # pylint: disable=broad-except
    pass

  # Deduplicate by normalized headline prefix and sort newest first
  seen: set[str] = set()
  unique: list[dict[str, Any]] = []
  for item in sorted(collected, key=lambda x: x['published_at'], reverse=True):
    norm_t = re.sub(r'[^a-z0-9\u4e00-\u9fff]', '', item['title'].lower())[:36]
    if not norm_t or norm_t in seen:
      continue
    seen.add(norm_t)
    unique.append(item)
  return unique[:80]
