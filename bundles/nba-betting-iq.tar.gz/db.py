#!/usr/bin/env python3
"""SQLite database schema & atomic helpers for NBA 運彩智庫."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from typing import Any

import config

_INIT_LOCK = threading.Lock()
_INITIALIZED = False

SCHEMA_SQL = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;

CREATE TABLE IF NOT EXISTS games (
  game_id TEXT PRIMARY KEY,
  season_year INTEGER NOT NULL,
  et_date TEXT NOT NULL,
  tw_date TEXT NOT NULL,
  tipoff_utc TEXT NOT NULL,
  tipoff_tw TEXT NOT NULL,
  status TEXT NOT NULL,           -- SCHEDULED | IN_PROGRESS | FINAL
  status_detail TEXT DEFAULT '',
  away_abbr TEXT NOT NULL,
  home_abbr TEXT NOT NULL,
  away_score INTEGER,
  home_score INTEGER,
  away_q_scores TEXT DEFAULT '[]',
  home_q_scores TEXT DEFAULT '[]',
  away_record TEXT DEFAULT '',
  home_record TEXT DEFAULT '',
  open_spread_home REAL,          -- e.g. -3.5 means home favored by 3.5; +2.5 means home dog +2.5
  close_spread_home REAL,
  open_total REAL,
  close_total REAL,
  home_ml INTEGER,
  away_ml INTEGER,
  home_spread_odds INTEGER,
  away_spread_odds INTEGER,
  over_odds INTEGER,
  under_odds INTEGER,
  odds_provider TEXT DEFAULT 'DraftKings',
  odds_locked_tw TEXT DEFAULT '', -- Taiwan timestamp (e.g. '2026-10-29 23:00') when spread/O/U was locked
  bpi_home_win_pct REAL,          -- 0..100 from ESPN Matchup Predictor
  margin_home INTEGER,            -- home_score - away_score when FINAL
  total_points INTEGER,           -- home_score + away_score when FINAL
  ats_winner TEXT,                -- HOME | AWAY | PUSH | NULL
  ats_cover_margin REAL,          -- (home_score - away_score) + spread_home
  ou_result TEXT,                 -- OVER | UNDER | PUSH | NULL
  ou_margin REAL,                 -- total_points - close_total
  boxscore_json TEXT DEFAULT '{}',
  leaders_json TEXT DEFAULT '{}',
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_games_tw_date ON games(tw_date);
CREATE INDEX IF NOT EXISTS idx_games_et_date ON games(et_date);
CREATE INDEX IF NOT EXISTS idx_games_status ON games(status);

CREATE TABLE IF NOT EXISTS team_stats (
  abbr TEXT PRIMARY KEY,
  wins INTEGER DEFAULT 0,
  losses INTEGER DEFAULT 0,
  win_pct REAL DEFAULT 0.0,
  home_record TEXT DEFAULT '0-0',
  road_record TEXT DEFAULT '0-0',
  l10_record TEXT DEFAULT '0-0',
  streak TEXT DEFAULT '',
  ppg REAL DEFAULT 113.5,
  opp_ppg REAL DEFAULT 113.5,
  diff REAL DEFAULT 0.0,
  ats_w INTEGER DEFAULT 0,
  ats_l INTEGER DEFAULT 0,
  ats_p INTEGER DEFAULT 0,
  ou_over INTEGER DEFAULT 0,
  ou_under INTEGER DEFAULT 0,
  ou_push INTEGER DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS injuries (
  inj_key TEXT PRIMARY KEY,       -- team_abbr::player_name
  team_abbr TEXT NOT NULL,
  player_name TEXT NOT NULL,
  position TEXT DEFAULT '',
  status TEXT NOT NULL,           -- Out | Doubtful | Questionable | Day-To-Day | Probable
  status_zh TEXT NOT NULL,
  play_prob_next INTEGER NOT NULL,-- 0..100 estimated chance to play next game
  impact_tier TEXT NOT NULL,      -- STAR | STARTER | ROTATION
  est_spread_pts REAL NOT NULL,   -- estimated point-spread value when healthy (0.3 .. 5.5)
  est_total_pts REAL NOT NULL,    -- estimated O/U total impact when absent
  injury_type TEXT DEFAULT '',
  return_date TEXT DEFAULT '',
  short_comment TEXT DEFAULT '',
  long_comment TEXT DEFAULT '',
  report_date TEXT DEFAULT '',
  source TEXT DEFAULT 'ESPN',
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_injuries_team ON injuries(team_abbr);

CREATE TABLE IF NOT EXISTS lineups (
  matchup_key TEXT PRIMARY KEY,   -- away_abbr@home_abbr
  away_abbr TEXT NOT NULL,
  home_abbr TEXT NOT NULL,
  away_confirmed INTEGER DEFAULT 0,
  home_confirmed INTEGER DEFAULT 0,
  away_starters_json TEXT DEFAULT '[]',
  home_starters_json TEXT DEFAULT '[]',
  away_may_not_play_json TEXT DEFAULT '[]',
  home_may_not_play_json TEXT DEFAULT '[]',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS news (
  news_id TEXT PRIMARY KEY,
  published_at TEXT NOT NULL,
  published_tw TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT DEFAULT '',
  url TEXT NOT NULL,
  source TEXT NOT NULL,
  lang TEXT DEFAULT 'en',         -- en | zh
  category TEXT NOT NULL,         -- injury | lineup | rest | odds | game
  category_zh TEXT NOT NULL,
  teams_json TEXT DEFAULT '[]',
  players_json TEXT DEFAULT '[]',
  play_signal TEXT DEFAULT '',    -- OUT | QUESTIONABLE | PROBABLE | AVAILABLE | ''
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_news_pub ON news(published_at DESC);

CREATE TABLE IF NOT EXISTS predictions (
  game_id TEXT PRIMARY KEY,
  et_date TEXT NOT NULL,
  tw_date TEXT NOT NULL,
  model_version TEXT NOT NULL,
  pred_margin_home REAL NOT NULL, -- expected (home_score - away_score)
  fair_spread_home REAL NOT NULL, -- -pred_margin_home
  book_spread_home REAL,
  ats_edge REAL DEFAULT 0.0,      -- expected cover margin on chosen side
  ats_pick TEXT DEFAULT 'PASS',   -- HOME | AWAY | PASS
  ats_conf INTEGER DEFAULT 50,    -- 50..95
  ats_tier TEXT DEFAULT 'PASS',   -- STRONG | LEAN | PASS
  pred_total REAL NOT NULL,
  book_total REAL,
  ou_edge REAL DEFAULT 0.0,
  ou_pick TEXT DEFAULT 'PASS',    -- OVER | UNDER | PASS
  ou_conf INTEGER DEFAULT 50,
  ou_tier TEXT DEFAULT 'PASS',    -- STRONG | LEAN | PASS
  rec_units_ats REAL DEFAULT 0.0,
  rec_units_ou REAL DEFAULT 0.0,
  rationale_zh TEXT DEFAULT '',
  factors_json TEXT DEFAULT '{}',
  guardrails_json TEXT DEFAULT '[]',
  graded INTEGER DEFAULT 0,
  ats_result TEXT,                -- WIN | LOSS | PUSH | PASS | NULL
  ou_result TEXT,                 -- WIN | LOSS | PUSH | PASS | NULL
  postmortem_zh TEXT DEFAULT '',
  error_tags_json TEXT DEFAULT '[]',
  created_at TEXT NOT NULL,
  graded_at TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_pred_tw_date ON predictions(tw_date);

CREATE TABLE IF NOT EXISTS model_state (
  state_key TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evolution_log (
  evo_id INTEGER PRIMARY KEY AUTOINCREMENT,
  et_date TEXT NOT NULL,
  model_version TEXT NOT NULL,
  games_graded INTEGER NOT NULL,
  ats_wins INTEGER NOT NULL,
  ats_losses INTEGER NOT NULL,
  ou_wins INTEGER NOT NULL,
  ou_losses INTEGER NOT NULL,
  cum_strong_win_rate REAL NOT NULL,
  cum_all_win_rate REAL NOT NULL,
  summary_zh TEXT NOT NULL,
  weight_deltas_json TEXT NOT NULL,
  guardrails_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_bets (
  bet_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  tw_date TEXT NOT NULL,
  game_id TEXT DEFAULT '',
  matchup TEXT NOT NULL,
  market TEXT NOT NULL,           -- ATS | OU | ML
  pick_side TEXT NOT NULL,        -- HOME | AWAY | OVER | UNDER
  pick_label TEXT NOT NULL,
  line REAL,
  odds_decimal REAL NOT NULL,
  stake REAL NOT NULL,
  status TEXT DEFAULT 'PENDING',  -- PENDING | WIN | LOSS | PUSH
  pnl REAL DEFAULT 0.0,
  note TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS fetch_log (
  source TEXT NOT NULL,
  fetch_key TEXT NOT NULL,
  status TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (source, fetch_key)
);

CREATE TABLE IF NOT EXISTS player_game_logs (
  game_id TEXT NOT NULL,
  player_id TEXT NOT NULL,
  player_name TEXT NOT NULL,
  short_name TEXT DEFAULT '',
  team_abbr TEXT NOT NULL,
  opp_abbr TEXT NOT NULL,
  et_date TEXT NOT NULL,
  tw_date TEXT NOT NULL,
  is_home INTEGER DEFAULT 0,
  team_win INTEGER DEFAULT 0,
  starter INTEGER DEFAULT 0,
  dnp INTEGER DEFAULT 0,
  dnp_reason TEXT DEFAULT '',
  jersey TEXT DEFAULT '',
  position TEXT DEFAULT '',
  headshot TEXT DEFAULT '',
  min_str TEXT DEFAULT '',
  minutes REAL DEFAULT 0.0,
  pts INTEGER DEFAULT 0,
  fgm INTEGER DEFAULT 0,
  fga INTEGER DEFAULT 0,
  tpm INTEGER DEFAULT 0,
  tpa INTEGER DEFAULT 0,
  ftm INTEGER DEFAULT 0,
  fta INTEGER DEFAULT 0,
  oreb INTEGER DEFAULT 0,
  dreb INTEGER DEFAULT 0,
  reb INTEGER DEFAULT 0,
  ast INTEGER DEFAULT 0,
  tov INTEGER DEFAULT 0,
  stl INTEGER DEFAULT 0,
  blk INTEGER DEFAULT 0,
  pf INTEGER DEFAULT 0,
  plus_minus INTEGER DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (game_id, player_id)
);
CREATE INDEX IF NOT EXISTS idx_pgl_team ON player_game_logs(team_abbr, et_date DESC);
CREATE INDEX IF NOT EXISTS idx_pgl_player ON player_game_logs(player_id, et_date DESC);
CREATE INDEX IF NOT EXISTS idx_pgl_game ON player_game_logs(game_id);

CREATE TABLE IF NOT EXISTS roster_players (
  player_id TEXT PRIMARY KEY,
  player_name TEXT NOT NULL,
  team_abbr TEXT NOT NULL,
  age INTEGER DEFAULT 0,
  position TEXT DEFAULT '',
  jersey TEXT DEFAULT '',
  headshot TEXT DEFAULT '',
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_roster_team ON roster_players(team_abbr);
"""


def connect() -> sqlite3.Connection:
  global _INITIALIZED
  os.makedirs(config.DATA_DIR, exist_ok=True)
  conn = sqlite3.connect(config.DB_PATH, timeout=30.0)
  conn.row_factory = sqlite3.Row
  if not _INITIALIZED:
    with _INIT_LOCK:
      if not _INITIALIZED:
        conn.executescript(SCHEMA_SQL)
        try:
          conn.execute("ALTER TABLE games ADD COLUMN odds_locked_tw TEXT DEFAULT ''")
        except sqlite3.OperationalError:
          pass
        # Ensure already-started/completed games keep their historical lines marked locked
        conn.execute(
            """
            UPDATE games
               SET odds_locked_tw = '歷史完賽封存盤'
             WHERE status != 'SCHEDULED'
               AND close_spread_home IS NOT NULL
               AND (odds_locked_tw IS NULL OR odds_locked_tw = '')
            """
        )
        conn.commit()
        _INITIALIZED = True
  return conn


def get_state(conn: sqlite3.Connection, key: str, default: Any = None) -> Any:
  row = conn.execute('SELECT value_json FROM model_state WHERE state_key = ?', (key,)).fetchone()
  if not row:
    return default
  try:
    return json.loads(row['value_json'])
  except ValueError:
    return default


def set_state(conn: sqlite3.Connection, key: str, value: Any, now_str: str) -> None:
  conn.execute(
      'INSERT INTO model_state(state_key, value_json, updated_at) VALUES(?, ?, ?) '
      'ON CONFLICT(state_key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at',
      (key, json.dumps(value, ensure_ascii=False), now_str),
  )
