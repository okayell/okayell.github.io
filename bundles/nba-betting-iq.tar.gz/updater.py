#!/usr/bin/env python3
"""Incremental & full-season NBA data pipeline + walk-forward evolution runner."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import fcntl
import json
import os
import sqlite3
import threading
import time
from typing import Any

import config
import db
import model_engine
import snapshot
from sources import espn
from sources import rotowire_and_news
import teams

_STATUS_LOCK = threading.Lock()
_SYNC_STATE: dict[str, Any] = {
    'running': False,
    'last_sync_tw': '',
    'last_odds_sync_tw': '',
    'last_duration_sec': 0.0,
    'last_error': '',
    'games_synced': 0,
}

_ODDS_KEYS = (
    'open_spread_home',
    'close_spread_home',
    'open_total',
    'close_total',
    'home_ml',
    'away_ml',
    'home_spread_odds',
    'away_spread_odds',
    'over_odds',
    'under_odds',
    'odds_provider',
    'odds_locked_tw',
)


def get_sync_state() -> dict[str, Any]:
  with _STATUS_LOCK:
    return dict(_SYNC_STATE)


def _upsert_game(
    conn: sqlite3.Connection,
    g: dict[str, Any],
    now_str: str,
    allow_odds_overwrite: bool = False,
) -> None:
  odds_update_sql = (
      """
        open_spread_home=COALESCE(games.open_spread_home, excluded.open_spread_home),
        close_spread_home=COALESCE(excluded.close_spread_home, games.close_spread_home),
        open_total=COALESCE(games.open_total, excluded.open_total),
        close_total=COALESCE(excluded.close_total, games.close_total),
        home_ml=COALESCE(excluded.home_ml, games.home_ml),
        away_ml=COALESCE(excluded.away_ml, games.away_ml),
        home_spread_odds=COALESCE(excluded.home_spread_odds, games.home_spread_odds),
        away_spread_odds=COALESCE(excluded.away_spread_odds, games.away_spread_odds),
        over_odds=COALESCE(excluded.over_odds, games.over_odds),
        under_odds=COALESCE(excluded.under_odds, games.under_odds),
        odds_provider=excluded.odds_provider,
        odds_locked_tw=CASE WHEN excluded.odds_locked_tw != '' THEN excluded.odds_locked_tw ELSE games.odds_locked_tw END,
      """
      if allow_odds_overwrite
      else ''
  )
  conn.execute(
      f"""
      INSERT INTO games(
        game_id, season_year, et_date, tw_date, tipoff_utc, tipoff_tw,
        status, status_detail, away_abbr, home_abbr,
        away_score, home_score, away_q_scores, home_q_scores,
        away_record, home_record,
        open_spread_home, close_spread_home, open_total, close_total,
        home_ml, away_ml, home_spread_odds, away_spread_odds, over_odds, under_odds,
        odds_provider, odds_locked_tw, bpi_home_win_pct,
        margin_home, total_points, ats_winner, ats_cover_margin, ou_result, ou_margin,
        boxscore_json, leaders_json, updated_at
      ) VALUES (
        ?,?,?,?,?,?, ?,?,?,?, ?,?,?,?, ?,?, ?,?,?,?, ?,?,?,?,?,?, ?,?,?, ?,?,?,?,?,?, ?,?,?
      )
      ON CONFLICT(game_id) DO UPDATE SET
        et_date=excluded.et_date,
        tw_date=excluded.tw_date,
        tipoff_utc=excluded.tipoff_utc,
        tipoff_tw=excluded.tipoff_tw,
        status=excluded.status,
        status_detail=excluded.status_detail,
        away_score=excluded.away_score,
        home_score=excluded.home_score,
        away_q_scores=excluded.away_q_scores,
        home_q_scores=excluded.home_q_scores,
        away_record=CASE WHEN excluded.away_record != '' THEN excluded.away_record ELSE games.away_record END,
        home_record=CASE WHEN excluded.home_record != '' THEN excluded.home_record ELSE games.home_record END,
        {odds_update_sql}
        bpi_home_win_pct=COALESCE(excluded.bpi_home_win_pct, games.bpi_home_win_pct),
        margin_home=excluded.margin_home,
        total_points=excluded.total_points,
        ats_winner=excluded.ats_winner,
        ats_cover_margin=excluded.ats_cover_margin,
        ou_result=excluded.ou_result,
        ou_margin=excluded.ou_margin,
        boxscore_json=CASE WHEN excluded.boxscore_json != '{{}}' THEN excluded.boxscore_json ELSE games.boxscore_json END,
        leaders_json=CASE WHEN excluded.leaders_json != '{{}}' THEN excluded.leaders_json ELSE games.leaders_json END,
        updated_at=excluded.updated_at
      """,
      (
          g['game_id'], g['season_year'], g['et_date'], g['tw_date'], g['tipoff_utc'], g['tipoff_tw'],
          g['status'], g['status_detail'], g['away_abbr'], g['home_abbr'],
          g.get('away_score'), g.get('home_score'),
          json.dumps(g.get('away_q_scores') or []),
          json.dumps(g.get('home_q_scores') or []),
          g.get('away_record') or '', g.get('home_record') or '',
          g.get('open_spread_home'), g.get('close_spread_home'),
          g.get('open_total'), g.get('close_total'),
          g.get('home_ml'), g.get('away_ml'),
          g.get('home_spread_odds'), g.get('away_spread_odds'),
          g.get('over_odds'), g.get('under_odds'),
          g.get('odds_provider') or 'DraftKings',
          g.get('odds_locked_tw') or '',
          g.get('bpi_home_win_pct'),
          g.get('margin_home'), g.get('total_points'),
          g.get('ats_winner'), g.get('ats_cover_margin'),
          g.get('ou_result'), g.get('ou_margin'),
          json.dumps(g.get('boxscore') or {}, ensure_ascii=False),
          json.dumps(g.get('leaders') or {}, ensure_ascii=False),
          now_str,
      ),
  )
  if g.get('player_logs'):
    _upsert_player_logs(conn, g['player_logs'], now_str)


def _upsert_player_logs(conn: sqlite3.Connection, logs: list[dict[str, Any]], now_str: str) -> None:
  if not logs:
    return
  conn.executemany(
      """
      INSERT INTO player_game_logs(
        game_id, player_id, player_name, short_name, team_abbr, opp_abbr,
        et_date, tw_date, is_home, team_win, starter, dnp, dnp_reason,
        jersey, position, headshot, min_str, minutes,
        pts, fgm, fga, tpm, tpa, ftm, fta, oreb, dreb, reb, ast, tov, stl, blk, pf, plus_minus,
        updated_at
      ) VALUES (
        ?,?,?,?,?,?, ?,?,?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?
      )
      ON CONFLICT(game_id, player_id) DO UPDATE SET
        player_name=excluded.player_name,
        short_name=excluded.short_name,
        team_abbr=excluded.team_abbr,
        opp_abbr=excluded.opp_abbr,
        is_home=excluded.is_home,
        team_win=excluded.team_win,
        starter=excluded.starter,
        dnp=excluded.dnp,
        dnp_reason=excluded.dnp_reason,
        jersey=CASE WHEN excluded.jersey != '' THEN excluded.jersey ELSE player_game_logs.jersey END,
        position=CASE WHEN excluded.position != '' THEN excluded.position ELSE player_game_logs.position END,
        headshot=CASE WHEN excluded.headshot != '' THEN excluded.headshot ELSE player_game_logs.headshot END,
        min_str=excluded.min_str,
        minutes=excluded.minutes,
        pts=excluded.pts, fgm=excluded.fgm, fga=excluded.fga,
        tpm=excluded.tpm, tpa=excluded.tpa, ftm=excluded.ftm, fta=excluded.fta,
        oreb=excluded.oreb, dreb=excluded.dreb, reb=excluded.reb,
        ast=excluded.ast, tov=excluded.tov, stl=excluded.stl, blk=excluded.blk,
        pf=excluded.pf, plus_minus=excluded.plus_minus,
        updated_at=excluded.updated_at
      """,
      [
          (
              r['game_id'], r['player_id'], r['player_name'], r['short_name'],
              r['team_abbr'], r['opp_abbr'], r['et_date'], r['tw_date'],
              r['is_home'], r['team_win'], r['starter'], r['dnp'], r['dnp_reason'],
              r['jersey'], r['position'], r['headshot'], r['min_str'], r['minutes'],
              r['pts'], r['fgm'], r['fga'], r['tpm'], r['tpa'], r['ftm'], r['fta'],
              r['oreb'], r['dreb'], r['reb'], r['ast'], r['tov'], r['stl'], r['blk'],
              r['pf'], r['plus_minus'], now_str,
          )
          for r in logs
      ],
  )


def _recompute_team_ats_ou(conn: sqlite3.Connection, now_str: str) -> None:
  """Computes exact season ATS W-L-P and Over/Under records for all 30 teams from FINAL games."""
  agg: dict[str, dict[str, int]] = {
      ab: {'aw': 0, 'al': 0, 'ap': 0, 'ov': 0, 'un': 0, 'op': 0} for ab in teams.TEAMS
  }
  rows = conn.execute("SELECT home_abbr, away_abbr, ats_winner, ou_result FROM games WHERE status = 'FINAL'").fetchall()
  for r in rows:
    h, a = r['home_abbr'], r['away_abbr']
    aw = r['ats_winner']
    if aw == 'HOME':
      if h in agg:
        agg[h]['aw'] += 1
      if a in agg:
        agg[a]['al'] += 1
    elif aw == 'AWAY':
      if a in agg:
        agg[a]['aw'] += 1
      if h in agg:
        agg[h]['al'] += 1
    elif aw == 'PUSH':
      if h in agg:
        agg[h]['ap'] += 1
      if a in agg:
        agg[a]['ap'] += 1

    ou = r['ou_result']
    for ab in (h, a):
      if ab not in agg:
        continue
      if ou == 'OVER':
        agg[ab]['ov'] += 1
      elif ou == 'UNDER':
        agg[ab]['un'] += 1
      elif ou == 'PUSH':
        agg[ab]['op'] += 1

  for ab, st in agg.items():
    conn.execute(
        """
        INSERT INTO team_stats(abbr, ats_w, ats_l, ats_p, ou_over, ou_under, ou_push, updated_at)
        VALUES(?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(abbr) DO UPDATE SET
          ats_w=excluded.ats_w, ats_l=excluded.ats_l, ats_p=excluded.ats_p,
          ou_over=excluded.ou_over, ou_under=excluded.ou_under, ou_push=excluded.ou_push,
          updated_at=excluded.updated_at
        """,
        (ab, st['aw'], st['al'], st['ap'], st['ov'], st['un'], st['op'], now_str),
    )


def evening_cycle_date(now_tw: dt.datetime) -> str:
  """Maps 05:00..23:59 TW to today and 00:00..04:59 TW to yesterday's 23:00 lock cycle."""
  return (now_tw - dt.timedelta(hours=5)).strftime('%Y-%m-%d')


def is_early_odds_captured(conn: sqlite3.Connection, tw_date_str: str) -> bool:
  row = conn.execute(
      "SELECT 1 FROM fetch_log WHERE source='odds_1800_tw' AND fetch_key=?",
      (tw_date_str,),
  ).fetchone()
  return row is not None


def is_daily_odds_captured(conn: sqlite3.Connection, tw_date_str: str) -> bool:
  row = conn.execute(
      "SELECT 1 FROM fetch_log WHERE source='odds_2300_tw' AND fetch_key=?",
      (tw_date_str,),
  ).fetchone()
  return row is not None


def sync_all(full_backfill: bool = False, update_odds: bool = False, odds_stage: str = 'auto') -> dict[str, Any]:
  """Runs full or incremental sync under cross-process flock, evolves model, and writes snapshot.json.

  Two-Stage Daily Odds & Steam Re-Analysis Workflow:
  - Stage 1 (18:00 TW `early`): Captures early opening spreads & totals (`open_spread_home` / `open_total`
    + initial `close_spread_home` / `close_total`) and runs Pass 1 analysis so users see early lines & picks.
  - Stage 2 (23:00 TW `final`): Captures final pre-game spreads & totals while strictly preserving the
    18:00 baseline, computes 18:00 -> 23:00 line movement (`line_steam` / `total_steam`), runs Pass 2
    re-analysis, and locks lines for post-game settlement.
  """
  os.makedirs(config.DATA_DIR, exist_ok=True)
  lock_fd = open(config.LOCK_FILE, 'w', encoding='utf-8')
  try:
    fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
  except BlockingIOError:
    lock_fd.close()
    return {'ok': True, 'skipped': True, 'reason': 'sync_already_running', **get_sync_state()}

  t0 = time.monotonic()
  with _STATUS_LOCK:
    _SYNC_STATE['running'] = True
    _SYNC_STATE['last_error'] = ''

  try:
    conn = db.connect()
    now_tw = dt.datetime.now(config.TZ_TW)
    now_str = now_tw.strftime('%Y-%m-%d %H:%M:%S')
    today_tw_str = now_tw.strftime('%Y-%m-%d')
    hm_tw = now_tw.strftime('%H:%M')
    today_et = dt.datetime.now(config.TZ_ET).date()

    cycle_date_str = evening_cycle_date(now_tw)
    in_early_window = (config.EARLY_ODDS_CAPTURE_TW_TIME <= hm_tw < '22:30')
    in_final_window = (hm_tw >= '22:30' or hm_tw < '05:00')

    is_1800_catchup = in_early_window and not is_early_odds_captured(conn, today_tw_str)
    is_2300_catchup = (hm_tw >= config.ODDS_CAPTURE_TW_TIME or hm_tw < '05:00') and not is_daily_odds_captured(conn, cycle_date_str)
    effective_update_odds = bool(update_odds or full_backfill or is_1800_catchup or is_2300_catchup)

    if odds_stage in ('early', 'final'):
      eff_stage = odds_stage
    elif in_final_window or is_2300_catchup:
      eff_stage = 'final'
    else:
      eff_stage = 'early'

    # 1. Standings
    try:
      st_rows = espn.fetch_standings()
      for r in st_rows:
        conn.execute(
            """
            INSERT INTO team_stats(
              abbr, wins, losses, win_pct, home_record, road_record, l10_record, streak,
              ppg, opp_ppg, diff, updated_at
            ) VALUES (?,?,?,?,?,?,?,?, ?,?,?,?)
            ON CONFLICT(abbr) DO UPDATE SET
              wins=excluded.wins, losses=excluded.losses, win_pct=excluded.win_pct,
              home_record=excluded.home_record, road_record=excluded.road_record,
              l10_record=excluded.l10_record, streak=excluded.streak,
              ppg=excluded.ppg, opp_ppg=excluded.opp_ppg, diff=excluded.diff,
              updated_at=excluded.updated_at
            """,
            (
                r['abbr'], r['wins'], r['losses'], r['win_pct'],
                r['home_record'], r['road_record'], r['l10_record'], r['streak'],
                r['ppg'], r['opp_ppg'], r['diff'], now_str,
            ),
        )
      conn.commit()
    except Exception:  # pylint: disable=broad-except
      pass

    # 2. RotoWire Lineups + Official ESPN Injuries
    lineups, starters_set, rw_injuries = rotowire_and_news.fetch_rotowire_lineups()
    if lineups:
      conn.execute('DELETE FROM lineups')
      for lu in lineups:
        conn.execute(
            """
            INSERT INTO lineups(
              matchup_key, away_abbr, home_abbr, away_confirmed, home_confirmed,
              away_starters_json, home_starters_json, away_may_not_play_json, home_may_not_play_json, updated_at
            ) VALUES (?,?,?,?,?, ?,?,?,?,?)
            """,
            (
                lu['matchup_key'], lu['away_abbr'], lu['home_abbr'],
                lu['away_confirmed'], lu['home_confirmed'],
                json.dumps(lu['away_starters'], ensure_ascii=False),
                json.dumps(lu['home_starters'], ensure_ascii=False),
                json.dumps(lu['away_may_not_play'], ensure_ascii=False),
                json.dumps(lu['home_may_not_play'], ensure_ascii=False),
                now_str,
            ),
        )
      conn.commit()

    inj_merged: dict[str, dict[str, Any]] = {}
    try:
      for item in espn.fetch_injuries(starters_set):
        inj_merged[item['inj_key']] = item
    except Exception:  # pylint: disable=broad-except
      pass
    for rw_it in rw_injuries:
      k = rw_it['inj_key']
      if k not in inj_merged:
        inj_merged[k] = rw_it
      else:
        # Enrich short comment if RotoWire has live lineup context
        if rw_it.get('short_comment') and rw_it['short_comment'] not in inj_merged[k]['short_comment']:
          inj_merged[k]['short_comment'] = (inj_merged[k]['short_comment'] + ' | ' + rw_it['short_comment']).strip(' |')
    if inj_merged:
      conn.execute('DELETE FROM injuries')
      for it in inj_merged.values():
        conn.execute(
            """
            INSERT INTO injuries(
              inj_key, team_abbr, player_name, position, status, status_zh,
              play_prob_next, impact_tier, est_spread_pts, est_total_pts,
              injury_type, return_date, short_comment, long_comment, report_date, source, updated_at
            ) VALUES (?,?,?,?,?,?, ?,?,?,?, ?,?,?,?,?,?,?)
            """,
            (
                it['inj_key'], it['team_abbr'], it['player_name'], it['position'],
                it['status'], it['status_zh'], it['play_prob_next'],
                it['impact_tier'], it['est_spread_pts'], it['est_total_pts'],
                it['injury_type'], it['return_date'], it['short_comment'],
                it['long_comment'], it['report_date'], it['source'], now_str,
            ),
        )
      conn.commit()

    # 3. Multi-source NBA News
    known_players = starters_set | {it['player_name'] for it in inj_merged.values()}
    news_items = rotowire_and_news.fetch_all_nba_news(known_players)
    for n in news_items:
      conn.execute(
          """
          INSERT INTO news(
            news_id, published_at, published_tw, title, summary, url, source, lang,
            category, category_zh, teams_json, players_json, play_signal, updated_at
          ) VALUES (?,?,?,?,?,?,?,?, ?,?,?,?,?,?)
          ON CONFLICT(news_id) DO UPDATE SET
            published_at=excluded.published_at,
            published_tw=excluded.published_tw,
            category=excluded.category,
            category_zh=excluded.category_zh,
            teams_json=excluded.teams_json,
            players_json=excluded.players_json,
            play_signal=excluded.play_signal,
            updated_at=excluded.updated_at
          """,
          (
              n['news_id'], n['published_at'], n['published_tw'], n['title'], n['summary'],
              n['url'], n['source'], n['lang'], n['category'], n['category_zh'],
              json.dumps(n['teams'], ensure_ascii=False),
              json.dumps(n['players'], ensure_ascii=False),
              n['play_signal'], now_str,
          ),
      )
    conn.commit()

    # 4. Games Backfill & Fixed 23:00 TW Odds Lock (SEASON_START_ET .. today_et + 3 days)
    existing_odds_map: dict[str, dict[str, Any]] = {
        r['game_id']: dict(r)
        for r in conn.execute(
            """
            SELECT game_id, status, open_spread_home, close_spread_home,
                   open_total, close_total, home_ml, away_ml,
                   home_spread_odds, away_spread_odds, over_odds, under_odds,
                   odds_provider, odds_locked_tw
            FROM games
            """
        ).fetchall()
    }

    end_et = today_et + dt.timedelta(days=3)
    done_dates = {
        r['fetch_key']
        for r in conn.execute("SELECT fetch_key FROM fetch_log WHERE source='espn_date' AND status='final_complete'").fetchall()
    }
    dates_to_fetch: list[dt.date] = []
    cur = config.SEASON_START_ET
    while cur <= end_et:
      ds = cur.strftime('%Y-%m-%d')
      if full_backfill or cur >= (today_et - dt.timedelta(days=1)) or ds not in done_dates:
        dates_to_fetch.append(cur)
      cur += dt.timedelta(days=1)

    games_synced = 0
    odds_locked_cnt = 0
    if eff_stage == 'final':
      lock_stamp_tw = f'{cycle_date_str} {config.ODDS_CAPTURE_TW_TIME} 定盤'
    else:
      lock_stamp_tw = f'{today_tw_str} {config.EARLY_ODDS_CAPTURE_TW_TIME} 初盤'

    for d_et in dates_to_fetch:
      ds = d_et.strftime('%Y-%m-%d')
      try:
        sb_games = espn.fetch_scoreboard_date(d_et, include_odds=effective_update_odds)
      except Exception:  # pylint: disable=broad-except
        continue
      if not sb_games:
        if d_et < today_et:
          conn.execute(
              "INSERT OR REPLACE INTO fetch_log(source, fetch_key, status, updated_at) VALUES('espn_date', ?, 'final_complete', ?)",
              (ds, now_str),
          )
        continue

      def _enrich_one(raw_g: dict[str, Any]) -> tuple[dict[str, Any], bool]:
        ex = existing_odds_map.get(raw_g['game_id'])
        has_locked_db_odds = bool(
            ex and (ex.get('close_spread_home') is not None or ex.get('close_total') is not None)
        )
        # Decide whether this game should capture/update odds right now:
        # - Non-23:00 syncs (`not effective_update_odds`): NEVER fetch or overwrite odds.
        # - 23:00 TW sync (`effective_update_odds`): update SCHEDULED games to tonight's 23:00 line;
        #   already-started/completed games with DB odds stay permanently frozen at their locked line!
        if not effective_update_odds:
          want_odds = False
        elif raw_g['status'] == 'SCHEDULED':
          want_odds = True
        elif not has_locked_db_odds and full_backfill:
          want_odds = True
        else:
          want_odds = False

        if not want_odds:
          # Wipe any accidental scoreboard odds and restore existing locked DB odds
          for k in _ODDS_KEYS:
            raw_g[k] = ex.get(k) if ex else None
          if not raw_g.get('odds_provider'):
            raw_g['odds_provider'] = 'DraftKings'
          if not raw_g.get('odds_locked_tw'):
            raw_g['odds_locked_tw'] = ''

        eg = espn.enrich_game_detail(raw_g, fetch_odds=want_odds)

        if want_odds:
          # Preserve 18:00 early baseline in open_spread_home / open_total when 23:00 updates close_*
          if ex and ex.get('open_spread_home') is not None:
            eg['open_spread_home'] = ex['open_spread_home']
          if ex and ex.get('open_total') is not None:
            eg['open_total'] = ex['open_total']
          if eg.get('close_spread_home') is not None or eg.get('close_total') is not None:
            if full_backfill and eg['status'] != 'SCHEDULED':
              eg['odds_locked_tw'] = (ex.get('odds_locked_tw') if ex and ex.get('odds_locked_tw') else '歷史完賽封存盤')
            else:
              eg['odds_locked_tw'] = lock_stamp_tw
        else:
          # Re-enforce locked DB odds & recompute post-game ATS / O/U settlement against locked 23:00 lines
          if ex:
            for k in _ODDS_KEYS:
              eg[k] = ex.get(k)
          eg.update(
              espn.compute_outcomes(
                  eg['status'],
                  eg.get('home_score'),
                  eg.get('away_score'),
                  eg.get('close_spread_home'),
                  eg.get('close_total'),
              )
          )
        return eg, want_odds

      # Enrich all games on this date concurrently (max 5 polite workers)
      with ThreadPoolExecutor(max_workers=5) as pool:
        enriched_pairs = list(pool.map(_enrich_one, sb_games))

      all_final = True
      for eg, did_update_odds in enriched_pairs:
        _upsert_game(conn, eg, now_str, allow_odds_overwrite=did_update_odds)
        games_synced += 1
        if did_update_odds and (eg.get('close_spread_home') is not None or eg.get('close_total') is not None):
          odds_locked_cnt += 1
        if eg['status'] != 'FINAL':
          all_final = False

      if all_final and d_et < today_et:
        conn.execute(
            "INSERT OR REPLACE INTO fetch_log(source, fetch_key, status, updated_at) VALUES('espn_date', ?, 'final_complete', ?)",
            (ds, now_str),
        )
      conn.commit()

    if effective_update_odds and not full_backfill:
      if eff_stage == 'final':
        conn.execute(
            "INSERT OR REPLACE INTO fetch_log(source, fetch_key, status, updated_at) VALUES('odds_2300_tw', ?, 'ok', ?)",
            (cycle_date_str, now_str),
        )
      else:
        conn.execute(
            "INSERT OR REPLACE INTO fetch_log(source, fetch_key, status, updated_at) VALUES('odds_1800_tw', ?, 'ok', ?)",
            (today_tw_str, now_str),
        )
      conn.commit()

    # 4b. Backfill player boxscores for any FINAL games missing player_game_logs + refresh 30-team rosters
    missing_rows = conn.execute(
        """
        SELECT g.game_id, g.et_date, g.tw_date, g.home_abbr, g.away_abbr, g.home_score, g.away_score
        FROM games g
        WHERE g.status = 'FINAL'
          AND NOT EXISTS (SELECT 1 FROM player_game_logs p WHERE p.game_id = g.game_id)
        """
    ).fetchall()
    if missing_rows:
      missing_dicts = [dict(r) for r in missing_rows]
      with ThreadPoolExecutor(max_workers=8) as pool:
        for logs in pool.map(espn.fetch_player_logs_for_game, missing_dicts):
          if logs:
            _upsert_player_logs(conn, logs, now_str)
      conn.commit()

    roster_cnt = conn.execute('SELECT COUNT(*) FROM roster_players').fetchone()[0]
    roster_key = today_et.strftime('%Y-%m-%d')
    roster_done = conn.execute(
        "SELECT 1 FROM fetch_log WHERE source='espn_rosters' AND fetch_key=?",
        (roster_key,),
    ).fetchone()
    if full_backfill or roster_cnt < 300 or not roster_done:
      r_players = espn.fetch_all_rosters()
      if r_players:
        conn.executemany(
            """
            INSERT INTO roster_players(player_id, player_name, team_abbr, age, position, jersey, headshot, updated_at)
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT(player_id) DO UPDATE SET
              player_name=excluded.player_name,
              team_abbr=excluded.team_abbr,
              age=CASE WHEN excluded.age > 0 THEN excluded.age ELSE roster_players.age END,
              position=CASE WHEN excluded.position != '' THEN excluded.position ELSE roster_players.position END,
              jersey=CASE WHEN excluded.jersey != '' THEN excluded.jersey ELSE roster_players.jersey END,
              headshot=CASE WHEN excluded.headshot != '' THEN excluded.headshot ELSE roster_players.headshot END,
              updated_at=excluded.updated_at
            """,
            [
                (p['player_id'], p['player_name'], p['team_abbr'], p['age'], p['position'], p['jersey'], p['headshot'], now_str)
                for p in r_players
            ],
        )
        conn.execute(
            "INSERT OR REPLACE INTO fetch_log(source, fetch_key, status, updated_at) VALUES('espn_rosters', ?, 'ok', ?)",
            (roster_key, now_str),
        )
        conn.commit()

    # 5. Recompute 30-team ATS & O/U standings + Walk-Forward Self-Evolution + Predictions
    _recompute_team_ats_ou(conn, now_str)
    model_engine.run_walk_forward_and_predict(conn)

    # 6. Build fast JSON snapshot for <2ms GETs
    snap = snapshot.build_and_save_snapshot(conn)
    conn.close()

    dur = round(time.monotonic() - t0, 2)
    with _STATUS_LOCK:
      _SYNC_STATE.update({
          'running': False,
          'last_sync_tw': now_str,
          'last_odds_sync_tw': now_str if effective_update_odds else _SYNC_STATE.get('last_odds_sync_tw', ''),
          'last_duration_sec': dur,
          'last_error': '',
          'games_synced': games_synced,
      })
    return {
        'ok': True,
        'games_synced': games_synced,
        'odds_updated': effective_update_odds,
        'odds_locked_cnt': odds_locked_cnt,
        'duration_sec': dur,
        'model_version': snap['meta']['model_version'],
    }
  except Exception as e:  # pylint: disable=broad-except
    dur = round(time.monotonic() - t0, 2)
    with _STATUS_LOCK:
      _SYNC_STATE.update({'running': False, 'last_duration_sec': dur, 'last_error': str(e)})
    raise
  finally:
    try:
      fcntl.flock(lock_fd, fcntl.LOCK_UN)
    except OSError:
      pass
    lock_fd.close()


if __name__ == '__main__':
  import sys
  res = sync_all(
      full_backfill=('--full' in sys.argv),
      update_odds=('--odds' in sys.argv or '--full' in sys.argv),
  )
  print(json.dumps(res, ensure_ascii=False, indent=2))
