#!/usr/bin/env python3
"""Canonical 30 NBA Teams metadata, alias normalization (ESPN/RotoWire/News), and Chinese names."""
from __future__ import annotations

from typing import Any

# Canonical abbreviation -> metadata
TEAMS: dict[str, dict[str, str]] = {
    'BOS': {'zh': '塞爾提克', 'city_zh': '波士頓', 'en': 'Boston Celtics', 'short_en': 'Celtics', 'conf': 'East', 'div': 'Atlantic', 'color': '#007A33', 'espn': 'bos'},
    'BKN': {'zh': '籃網', 'city_zh': '布魯克林', 'en': 'Brooklyn Nets', 'short_en': 'Nets', 'conf': 'East', 'div': 'Atlantic', 'color': '#1D2939', 'espn': 'bkn'},
    'NYK': {'zh': '尼克', 'city_zh': '紐約', 'en': 'New York Knicks', 'short_en': 'Knicks', 'conf': 'East', 'div': 'Atlantic', 'color': '#006BB6', 'espn': 'ny'},
    'PHI': {'zh': '76人', 'city_zh': '費城', 'en': 'Philadelphia 76ers', 'short_en': '76ers', 'conf': 'East', 'div': 'Atlantic', 'color': '#006BB6', 'espn': 'phi'},
    'TOR': {'zh': '暴龍', 'city_zh': '多倫多', 'en': 'Toronto Raptors', 'short_en': 'Raptors', 'conf': 'East', 'div': 'Atlantic', 'color': '#CE1141', 'espn': 'tor'},
    'CHI': {'zh': '公牛', 'city_zh': '芝加哥', 'en': 'Chicago Bulls', 'short_en': 'Bulls', 'conf': 'East', 'div': 'Central', 'color': '#CE1141', 'espn': 'chi'},
    'CLE': {'zh': '騎士', 'city_zh': '克里夫蘭', 'en': 'Cleveland Cavaliers', 'short_en': 'Cavaliers', 'conf': 'East', 'div': 'Central', 'color': '#860038', 'espn': 'cle'},
    'DET': {'zh': '活塞', 'city_zh': '底特律', 'en': 'Detroit Pistons', 'short_en': 'Pistons', 'conf': 'East', 'div': 'Central', 'color': '#C8102E', 'espn': 'det'},
    'IND': {'zh': '溜馬', 'city_zh': '印第安納', 'en': 'Indiana Pacers', 'short_en': 'Pacers', 'conf': 'East', 'div': 'Central', 'color': '#002D62', 'espn': 'ind'},
    'MIL': {'zh': '公鹿', 'city_zh': '密爾瓦基', 'en': 'Milwaukee Bucks', 'short_en': 'Bucks', 'conf': 'East', 'div': 'Central', 'color': '#00471B', 'espn': 'mil'},
    'ATL': {'zh': '老鷹', 'city_zh': '亞特蘭大', 'en': 'Atlanta Hawks', 'short_en': 'Hawks', 'conf': 'East', 'div': 'Southeast', 'color': '#E03A3E', 'espn': 'atl'},
    'CHA': {'zh': '黃蜂', 'city_zh': '夏洛特', 'en': 'Charlotte Hornets', 'short_en': 'Hornets', 'conf': 'East', 'div': 'Southeast', 'color': '#00788C', 'espn': 'cha'},
    'MIA': {'zh': '熱火', 'city_zh': '邁阿密', 'en': 'Miami Heat', 'short_en': 'Heat', 'conf': 'East', 'div': 'Southeast', 'color': '#98002E', 'espn': 'mia'},
    'ORL': {'zh': '魔術', 'city_zh': '奧蘭多', 'en': 'Orlando Magic', 'short_en': 'Magic', 'conf': 'East', 'div': 'Southeast', 'color': '#0077C0', 'espn': 'orl'},
    'WAS': {'zh': '巫師', 'city_zh': '華盛頓', 'en': 'Washington Wizards', 'short_en': 'Wizards', 'conf': 'East', 'div': 'Southeast', 'color': '#002B5C', 'espn': 'wsh'},
    'DEN': {'zh': '金塊', 'city_zh': '丹佛', 'en': 'Denver Nuggets', 'short_en': 'Nuggets', 'conf': 'West', 'div': 'Northwest', 'color': '#0E2240', 'espn': 'den'},
    'MIN': {'zh': '灰狼', 'city_zh': '明尼蘇達', 'en': 'Minnesota Timberwolves', 'short_en': 'Timberwolves', 'conf': 'West', 'div': 'Northwest', 'color': '#0C2340', 'espn': 'min'},
    'OKC': {'zh': '雷霆', 'city_zh': '奧克拉荷馬', 'en': 'Oklahoma City Thunder', 'short_en': 'Thunder', 'conf': 'West', 'div': 'Northwest', 'color': '#007AC1', 'espn': 'okc'},
    'POR': {'zh': '拓荒者', 'city_zh': '波特蘭', 'en': 'Portland Trail Blazers', 'short_en': 'Trail Blazers', 'conf': 'West', 'div': 'Northwest', 'color': '#E03A3E', 'espn': 'por'},
    'UTA': {'zh': '爵士', 'city_zh': '猶他', 'en': 'Utah Jazz', 'short_en': 'Jazz', 'conf': 'West', 'div': 'Northwest', 'color': '#002B5C', 'espn': 'utah'},
    'GSW': {'zh': '勇士', 'city_zh': '金州', 'en': 'Golden State Warriors', 'short_en': 'Warriors', 'conf': 'West', 'div': 'Pacific', 'color': '#1D428A', 'espn': 'gs'},
    'LAC': {'zh': '快艇', 'city_zh': '洛杉磯', 'en': 'LA Clippers', 'short_en': 'Clippers', 'conf': 'West', 'div': 'Pacific', 'color': '#C8102E', 'espn': 'lac'},
    'LAL': {'zh': '湖人', 'city_zh': '洛杉磯', 'en': 'Los Angeles Lakers', 'short_en': 'Lakers', 'conf': 'West', 'div': 'Pacific', 'color': '#552583', 'espn': 'lal'},
    'PHX': {'zh': '太陽', 'city_zh': '鳳凰城', 'en': 'Phoenix Suns', 'short_en': 'Suns', 'conf': 'West', 'div': 'Pacific', 'color': '#1D1160', 'espn': 'phx'},
    'SAC': {'zh': '國王', 'city_zh': '沙加緬度', 'en': 'Sacramento Kings', 'short_en': 'Kings', 'conf': 'West', 'div': 'Pacific', 'color': '#5A2D81', 'espn': 'sac'},
    'DAL': {'zh': '獨行俠', 'city_zh': '達拉斯', 'en': 'Dallas Mavericks', 'short_en': 'Mavericks', 'conf': 'West', 'div': 'Southwest', 'color': '#00538C', 'espn': 'dal'},
    'HOU': {'zh': '火箭', 'city_zh': '休士頓', 'en': 'Houston Rockets', 'short_en': 'Rockets', 'conf': 'West', 'div': 'Southwest', 'color': '#CE1141', 'espn': 'hou'},
    'MEM': {'zh': '灰熊', 'city_zh': '曼斐斯', 'en': 'Memphis Grizzlies', 'short_en': 'Grizzlies', 'conf': 'West', 'div': 'Southwest', 'color': '#5D76A9', 'espn': 'mem'},
    'NOP': {'zh': '鵜鶘', 'city_zh': '紐奧良', 'en': 'New Orleans Pelicans', 'short_en': 'Pelicans', 'conf': 'West', 'div': 'Southwest', 'color': '#0C2340', 'espn': 'no'},
    'SAS': {'zh': '馬刺', 'city_zh': '聖安東尼奧', 'en': 'San Antonio Spurs', 'short_en': 'Spurs', 'conf': 'West', 'div': 'Southwest', 'color': '#344054', 'espn': 'sa'},
}

ALIAS_TO_ABBR: dict[str, str] = {
    'NY': 'NYK', 'NYK': 'NYK', 'NEW YORK KNICKS': 'NYK', 'KNICKS': 'NYK', '尼克': 'NYK',
    'GS': 'GSW', 'GSW': 'GSW', 'GOLDEN STATE WARRIORS': 'GSW', 'WARRIORS': 'GSW', '勇士': 'GSW',
    'NO': 'NOP', 'NOP': 'NOP', 'NOR': 'NOP', 'NEW ORLEANS PELICANS': 'NOP', 'PELICANS': 'NOP', '鵜鶘': 'NOP',
    'SA': 'SAS', 'SAS': 'SAS', 'SAN ANTONIO SPURS': 'SAS', 'SPURS': 'SAS', '馬刺': 'SAS',
    'WSH': 'WAS', 'WAS': 'WAS', 'WASHINGTON WIZARDS': 'WAS', 'WIZARDS': 'WAS', '巫師': 'WAS',
    'UTAH': 'UTA', 'UTA': 'UTA', 'UTAH JAZZ': 'UTA', 'JAZZ': 'UTA', '爵士': 'UTA',
    'BRK': 'BKN', 'BKN': 'BKN', 'NETS': 'BKN', 'BROOKLYN NETS': 'BKN', '籃網': 'BKN',
    'PHO': 'PHX', 'PHX': 'PHX', 'SUNS': 'PHX', 'PHOENIX SUNS': 'PHX', '太陽': 'PHX',
    'CHO': 'CHA', 'CHA': 'CHA', 'HORNETS': 'CHA', 'CHARLOTTE HORNETS': 'CHA', '黃蜂': 'CHA',
    'LA CLIPPERS': 'LAC', 'LOS ANGELES CLIPPERS': 'LAC', 'CLIPPERS': 'LAC', '快艇': 'LAC',
    'LOS ANGELES LAKERS': 'LAL', 'LA LAKERS': 'LAL', 'LAKERS': 'LAL', '湖人': 'LAL',
    '小牛': 'DAL', '塞爾蒂克': 'BOS', '七六人': 'PHI', '拓荒': 'POR', '灰狼': 'MIN',
}
for _abbr, _m in TEAMS.items():
  ALIAS_TO_ABBR[_abbr] = _abbr
  ALIAS_TO_ABBR[_m['en'].upper()] = _abbr
  ALIAS_TO_ABBR[_m['short_en'].upper()] = _abbr
  ALIAS_TO_ABBR[_m['zh']] = _abbr
  ALIAS_TO_ABBR[_m['espn'].upper()] = _abbr


def norm_team(raw: str | None) -> str:
  """Normalizes any ESPN / RotoWire / News team code or name to canonical 3-letter code."""
  if not raw:
    return ''
  s = str(raw).strip()
  up = s.upper()
  if up in ALIAS_TO_ABBR:
    return ALIAS_TO_ABBR[up]
  if s in ALIAS_TO_ABBR:
    return ALIAS_TO_ABBR[s]
  for k, v in ALIAS_TO_ABBR.items():
    if len(k) >= 4 and k in up:
      return v
  return up[:3]


def team_info(abbr: str) -> dict[str, Any]:
  c = norm_team(abbr)
  m = TEAMS.get(c)
  if not m:
    return {'abbr': c, 'zh': c, 'city_zh': '', 'en': c, 'short_en': c, 'conf': '', 'div': '', 'color': '#475569', 'logo': ''}
  return {
      'abbr': c,
      **m,
      'logo': f"https://a.espncdn.com/i/teamlogos/nba/500/{m['espn']}.png",
  }


def detect_teams_in_text(text: str) -> list[str]:
  """Finds all NBA team canonical codes mentioned in English or Chinese news text."""
  if not text:
    return []
  found: list[str] = []
  up = text.upper()
  for abbr, m in TEAMS.items():
    zh = m['zh']
    short_en = m['short_en'].upper()
    en = m['en'].upper()
    hit = False
    if zh in text:
      hit = True
    elif en in up:
      hit = True
    elif short_en in up:
      # Word boundary check for short English nicknames like Heat, Jazz, Nets, Suns, Magic, Kings
      import re  # pylint: disable=import-outside-toplevel
      if re.search(rf'\b{re.escape(short_en)}\b', up):
        hit = True
    if hit and abbr not in found:
      found.append(abbr)
  if '小牛' in text and 'DAL' not in found:
    found.append('DAL')
  if ('塞爾蒂克' in text or '綠衫軍' in text) and 'BOS' not in found:
    found.append('BOS')
  if '七六人' in text and 'PHI' not in found:
    found.append('PHI')
  return found[:6]
