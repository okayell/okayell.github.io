#!/usr/bin/env python3
"""Builds the fast, versioned JSON snapshot served to the SPA (<2ms GET, zero blocking I/O)."""
from __future__ import annotations

import datetime as dt
import json
import os
import sqlite3
from typing import Any

import config
import db
import model_engine
import storylines
import teams


TW_PARLAY_LEG_ODDS = 1.75
_PARLAY_TIER_BONUS = {'STRONG': 2.6, 'LEAN': 1.25, 'PASS': 0.0}


def _safe_json(raw: str | None, default: Any) -> Any:
  if not raw:
    return default
  try:
    return json.loads(raw)
  except ValueError:
    return default


def _american_to_decimal(am: Any, default: float = config.DEFAULT_DECIMAL_ODDS) -> float:
  if am is None or am == '':
    return round(default, 4)
  try:
    v = float(am)
  except (TypeError, ValueError):
    return round(default, 4)
  if v == 0:
    return round(default, 4)
  dec = (1.0 + 100.0 / abs(v)) if v < 0 else (1.0 + v / 100.0)
  return round(max(1.25, min(4.5, dec)), 4)


def _fmt_spread_zh(val: float) -> str:
  if val == 0:
    return 'PK (0.0)'
  return f"{'+' if val > 0 else ''}{val:.1f}"


def _top_factor_reason(contribs: dict[str, Any], meta_map: dict[str, dict[str, Any]], want_pos: bool) -> str:
  best_k, best_v = '', 0.0
  for k, raw_v in (contribs or {}).items():
    try:
      v = float(raw_v)
    except (TypeError, ValueError):
      continue
    aligned = v if want_pos else -v
    if aligned > best_v:
      best_k, best_v = k, aligned
  if best_k and best_v >= 0.08:
    nm = (meta_map.get(best_k) or {}).get('name_zh') or best_k
    return f'{nm} (+{best_v:.2f})'
  return ''


def _eval_direct_parlay(
    key: str,
    badge_zh: str,
    title_zh: str,
    subtitle_zh: str,
    stake_advice_zh: str,
    legs: list[dict[str, Any]],
) -> dict[str, Any]:
  intl_odds = 1.0
  tw_odds = 1.0
  joint_prob = 1.0
  for lg in legs:
    intl_odds *= float(lg['intl_odds'])
    tw_odds *= float(lg['tw_odds'])
    joint_prob *= float(lg['win_prob_pct']) / 100.0

  has_pass = any(lg['tier'] == 'PASS' for lg in legs)
  all_strong = all(lg['tier'] == 'STRONG' for lg in legs)
  if all_strong:
    grade_zh = '🔥 強推精選 S 級'
    grade_cls = 'strong'
  elif not has_pass:
    grade_zh = '✅ 正期望值 A 級'
    grade_cls = 'ok'
  else:
    grade_zh = '⚠️ 含湊關次選 B 級（建議輕注）'
    grade_cls = 'warn'

  results = [lg.get('leg_result') for lg in legs]
  hit_cnt = sum(1 for r in results if r == 'WIN')
  loss_cnt = sum(1 for r in results if r == 'LOSS')
  push_cnt = sum(1 for r in results if r == 'PUSH')

  if loss_cnt > 0:
    status = 'LOSS'
    pnl_intl = -1.0
    pnl_tw = -1.0
    eff_intl = 0.0
    eff_tw = 0.0
  elif any(r is None for r in results):
    status = 'PENDING'
    pnl_intl = 0.0
    pnl_tw = 0.0
    eff_intl = round(intl_odds, 2)
    eff_tw = round(tw_odds, 2)
  elif push_cnt == len(legs):
    status = 'PUSH'
    pnl_intl = 0.0
    pnl_tw = 0.0
    eff_intl = 1.0
    eff_tw = 1.0
  else:
    eff_i = 1.0
    eff_t = 1.0
    for lg in legs:
      if lg.get('leg_result') == 'WIN':
        eff_i *= float(lg['intl_odds'])
        eff_t *= float(lg['tw_odds'])
    status = 'WIN'
    eff_intl = round(eff_i, 2)
    eff_tw = round(eff_t, 2)
    pnl_intl = round(eff_i - 1.0, 2)
    pnl_tw = round(eff_t - 1.0, 2)

  return {
      'key': key,
      'type': 'DIRECT',
      'bets_count': 1,
      'badge_zh': badge_zh,
      'title_zh': title_zh,
      'subtitle_zh': subtitle_zh,
      'stake_advice_zh': stake_advice_zh,
      'grade_zh': grade_zh,
      'grade_cls': grade_cls,
      'has_pass_filler': has_pass,
      'legs_count': len(legs),
      'legs': legs,
      'intl_odds': round(intl_odds, 2),
      'tw_odds': round(tw_odds, 2),
      'eff_intl_odds': eff_intl,
      'eff_tw_odds': eff_tw,
      'joint_prob_pct': round(joint_prob * 100.0, 1),
      'ev_intl_pct': round((joint_prob * intl_odds - 1.0) * 100.0, 1),
      'ev_tw_pct': round((joint_prob * tw_odds - 1.0) * 100.0, 1),
      'status': status,
      'hit_cnt': hit_cnt,
      'loss_cnt': loss_cnt,
      'push_cnt': push_cnt,
      'pnl_unit_intl': pnl_intl,
      'pnl_unit_tw': pnl_tw,
  }


def _eval_combo_3x4(legs3: list[dict[str, Any]]) -> dict[str, Any]:
  combos = [[0, 1], [0, 2], [1, 2], [0, 1, 2]]
  max_ret_intl = 0.0
  max_ret_tw = 0.0
  ev_ret_intl = 0.0
  ev_ret_tw = 0.0
  for cb in combos:
    mi, mt, mp = 1.0, 1.0, 1.0
    for idx in cb:
      mi *= float(legs3[idx]['intl_odds'])
      mt *= float(legs3[idx]['tw_odds'])
      mp *= float(legs3[idx]['win_prob_pct']) / 100.0
    max_ret_intl += mi
    max_ret_tw += mt
    ev_ret_intl += mi * mp
    ev_ret_tw += mt * mp

  # Average 2-of-3 hit return (1 winning 2x1 combo out of 4 units staked)
  pair_intl = sum(float(legs3[a]['intl_odds']) * float(legs3[b]['intl_odds']) for a, b in ((0, 1), (0, 2), (1, 2))) / 3.0
  pair_tw = float(legs3[0]['tw_odds']) * float(legs3[1]['tw_odds'])

  p0, p1, p2 = [float(x['win_prob_pct']) / 100.0 for x in legs3]
  prob_3 = p0 * p1 * p2
  prob_2 = p0 * p1 * (1.0 - p2) + p0 * (1.0 - p1) * p2 + (1.0 - p0) * p1 * p2
  at_least_2_pct = round((prob_3 + prob_2) * 100.0, 1)

  results = [lg.get('leg_result') for lg in legs3]
  hit_cnt = sum(1 for r in results if r == 'WIN')
  loss_cnt = sum(1 for r in results if r == 'LOSS')
  push_cnt = sum(1 for r in results if r == 'PUSH')

  all_dead = all(any(results[i] == 'LOSS' for i in cb) for cb in combos)
  if all_dead:
    status = 'LOSS'
    ret_intl = 0.0
    ret_tw = 0.0
    cashed_combos = 0
  elif any(r is None for r in results):
    status = 'PENDING'
    ret_intl = 0.0
    ret_tw = 0.0
    cashed_combos = 0
  else:
    ret_intl = 0.0
    ret_tw = 0.0
    cashed_combos = 0
    for cb in combos:
      if any(results[i] == 'LOSS' for i in cb):
        continue
      cashed_combos += 1
      mi, mt = 1.0, 1.0
      for i in cb:
        if results[i] == 'WIN':
          mi *= float(legs3[i]['intl_odds'])
          mt *= float(legs3[i]['tw_odds'])
      ret_intl += mi
      ret_tw += mt
    status = 'WIN' if ret_intl > 4.0 else ('PARTIAL' if ret_intl > 0 else 'LOSS')

  has_pass = any(lg['tier'] == 'PASS' for lg in legs3)
  return {
      'key': 'shield_3x4',
      'type': 'COMBO',
      'combos': combos,
      'bets_count': 4,
      'badge_zh': '🛡️ 容錯防爆冷（台灣運彩過兩關／三關）',
      'title_zh': '方案 C：3 串 4 複式保險組合（共 4 注）',
      'subtitle_zh': '含 3 組「2串1」＋ 1 組「3串1」：3 關全過 4 注全收大賺；就算意外倒 1 關（3過2）仍可拿回約 77%~91% 本金回血！',
      'stake_advice_zh': '建議每注 0.35u × 4 注（合 1.4u）',
      'grade_zh': '🛡️ 高容錯護城河' if not has_pass else '⚠️ 含湊關次選（輕注容錯）',
      'grade_cls': 'info' if not has_pass else 'warn',
      'has_pass_filler': has_pass,
      'legs_count': 3,
      'legs': legs3,
      'intl_odds': round(max_ret_intl / 4.0, 2),
      'tw_odds': round(max_ret_tw / 4.0, 2),
      'max_return_mult_intl': round(max_ret_intl, 2),
      'max_return_mult_tw': round(max_ret_tw, 2),
      'hit2_return_mult_intl': round(pair_intl, 2),
      'hit2_return_mult_tw': round(pair_tw, 2),
      'joint_prob_pct': round(prob_3 * 100.0, 1),
      'at_least_2_prob_pct': at_least_2_pct,
      'ev_intl_pct': round((ev_ret_intl / 4.0 - 1.0) * 100.0, 1),
      'ev_tw_pct': round((ev_ret_tw / 4.0 - 1.0) * 100.0, 1),
      'status': status,
      'cashed_combos': cashed_combos,
      'hit_cnt': hit_cnt,
      'loss_cnt': loss_cnt,
      'push_cnt': push_cnt,
      'return_unit_intl': round(ret_intl, 2),
      'return_unit_tw': round(ret_tw, 2),
      'pnl_unit_intl': round(ret_intl - 4.0, 2) if status != 'PENDING' else 0.0,
      'pnl_unit_tw': round(ret_tw - 4.0, 2) if status != 'PENDING' else 0.0,
  }


def _build_daily_parlays(
    games_out: list[dict[str, Any]],
    team_lookup: dict[str, dict[str, Any]],
) -> dict[str, Any]:
  by_date_games: dict[str, list[dict[str, Any]]] = {}
  for g in games_out:
    by_date_games.setdefault(g['tw_date'], []).append(g)

  by_date: dict[str, dict[str, Any]] = {}
  history_rows: list[dict[str, Any]] = []

  kpi = {
      'p2_w': 0, 'p2_l': 0, 'p2_p': 0, 'p2_pnl_intl': 0.0, 'p2_pnl_tw': 0.0,
      'p3_w': 0, 'p3_l': 0, 'p3_p': 0, 'p3_pnl_intl': 0.0, 'p3_pnl_tw': 0.0,
      'c34_full_w': 0, 'c34_partial': 0, 'c34_l': 0, 'c34_pnl_intl': 0.0, 'c34_pnl_tw': 0.0,
  }

  for tw_d in sorted(by_date_games.keys()):
    d_games = by_date_games[tw_d]
    ranked_legs: list[dict[str, Any]] = []
    game_options: list[dict[str, Any]] = []

    for g in d_games:
      p = g.get('pred') or {}
      fac = p.get('factors') or {}
      guards = p.get('guardrails') or []
      a_tm = team_lookup.get(g['away_abbr']) or teams.team_info(g['away_abbr'])
      h_tm = team_lookup.get(g['home_abbr']) or teams.team_info(g['home_abbr'])
      matchup_zh = f"{a_tm['zh']} @ {h_tm['zh']}"

      ats_opt: dict[str, Any] | None = None
      if g.get('close_spread_home') is not None:
        sp_home = float(g['close_spread_home'])
        side = p['ats_pick'] if p.get('ats_pick') != 'PASS' else (p.get('ats_lean_side') or 'HOME')
        line = sp_home if side == 'HOME' else -sp_home
        pick_tm = h_tm if side == 'HOME' else a_tm
        role_zh = '讓分' if line < 0 else ('受讓' if line > 0 else 'PK')
        am_odds = g.get('home_spread_odds') if side == 'HOME' else g.get('away_spread_odds')
        intl_odds = _american_to_decimal(am_odds, config.DEFAULT_DECIMAL_ODDS)
        edge = round(abs(float(p.get('ats_edge') or 0.0)), 2)
        tier = p.get('ats_tier') or 'PASS'
        win_prob = min(64.5, max(51.2, 50.8 + edge * 3.15 - (0.8 if guards else 0.0)))
        leg_res = None
        if g.get('status') == 'FINAL' and g.get('ats_winner'):
          leg_res = 'PUSH' if g['ats_winner'] == 'PUSH' else ('WIN' if g['ats_winner'] == side else 'LOSS')
        top_fac = _top_factor_reason(fac.get('ats_contribs') or {}, model_engine.ATS_FACTOR_META, side == 'HOME')
        fair_sp = p.get('fair_spread_home')
        fair_txt = f"合理盤 主{_fmt_spread_zh(float(fair_sp))}" if fair_sp is not None else ''
        reason_parts = [x for x in (top_fac, fair_txt) if x]
        score = edge * 1.12 + _PARLAY_TIER_BONUS.get(tier, 0.0) - (0.25 if guards else 0.0)
        ats_opt = {
            'game_id': g['game_id'],
            'tw_date': tw_d,
            'tipoff_tw': g['tipoff_tw'],
            'status': g['status'],
            'away_abbr': g['away_abbr'],
            'home_abbr': g['home_abbr'],
            'away_zh': a_tm['zh'],
            'home_zh': h_tm['zh'],
            'away_logo': a_tm.get('logo', ''),
            'home_logo': h_tm.get('logo', ''),
            'away_score': g.get('away_score'),
            'home_score': g.get('home_score'),
            'matchup_zh': matchup_zh,
            'odds_locked_tw': g.get('odds_locked_tw') or '',
            'market': 'ATS',
            'market_zh': '讓分盤',
            'pick_side': side,
            'line': round(line, 1),
            'pick_label_zh': f"{pick_tm['zh']} {_fmt_spread_zh(line)}（{role_zh}）",
            'short_label_zh': f"{pick_tm['zh']} {_fmt_spread_zh(line)}",
            'tier': tier,
            'edge': edge,
            'conf': int(p.get('ats_conf') or 50),
            'win_prob_pct': round(win_prob, 1),
            'intl_odds': intl_odds,
            'tw_odds': TW_PARLAY_LEG_ODDS,
            'reason_zh': ' · '.join(reason_parts) or '綜合淨效率與主客場盤差優勢',
            'drama_badge_zh': (g.get('storylines') or {}).get('short_badge_zh') or '',
            'drama_headline_zh': (g.get('storylines') or {}).get('headline_zh') or '',
            'leg_result': leg_res,
            'score': round(score, 4),
        }

      ou_opt: dict[str, Any] | None = None
      if g.get('close_total'):
        tot_line = float(g['close_total'])
        side = p['ou_pick'] if p.get('ou_pick') != 'PASS' else (p.get('ou_lean_side') or 'OVER')
        side_zh = '大分 OVER' if side == 'OVER' else '小分 UNDER'
        short_side_zh = '大分' if side == 'OVER' else '小分'
        am_odds = g.get('over_odds') if side == 'OVER' else g.get('under_odds')
        intl_odds = _american_to_decimal(am_odds, config.DEFAULT_DECIMAL_ODDS)
        edge = round(abs(float(p.get('ou_edge') or 0.0)), 2)
        tier = p.get('ou_tier') or 'PASS'
        win_prob = min(64.0, max(51.0, 50.6 + edge * 2.55 - (0.8 if guards else 0.0)))
        leg_res = None
        if g.get('status') == 'FINAL' and g.get('ou_result'):
          leg_res = 'PUSH' if g['ou_result'] == 'PUSH' else ('WIN' if g['ou_result'] == side else 'LOSS')
        top_fac = _top_factor_reason(fac.get('ou_contribs') or {}, model_engine.OU_FACTOR_META, side == 'OVER')
        pred_tot = p.get('pred_total')
        pred_txt = f"模型預估總分 {float(pred_tot):.1f}" if pred_tot is not None else ''
        reason_parts = [x for x in (top_fac, pred_txt) if x]
        score = edge * 0.95 + _PARLAY_TIER_BONUS.get(tier, 0.0) - (0.25 if guards else 0.0)
        ou_opt = {
            'game_id': g['game_id'],
            'tw_date': tw_d,
            'tipoff_tw': g['tipoff_tw'],
            'status': g['status'],
            'away_abbr': g['away_abbr'],
            'home_abbr': g['home_abbr'],
            'away_zh': a_tm['zh'],
            'home_zh': h_tm['zh'],
            'away_logo': a_tm.get('logo', ''),
            'home_logo': h_tm.get('logo', ''),
            'away_score': g.get('away_score'),
            'home_score': g.get('home_score'),
            'matchup_zh': matchup_zh,
            'odds_locked_tw': g.get('odds_locked_tw') or '',
            'market': 'OU',
            'market_zh': '大小分',
            'pick_side': side,
            'line': round(tot_line, 1),
            'pick_label_zh': f"{a_tm['zh']}@{h_tm['zh']} {side_zh} {tot_line:.1f}",
            'short_label_zh': f"{a_tm['zh']}@{h_tm['zh']} {short_side_zh} {tot_line:.1f}",
            'tier': tier,
            'edge': edge,
            'conf': int(p.get('ou_conf') or 50),
            'win_prob_pct': round(win_prob, 1),
            'intl_odds': intl_odds,
            'tw_odds': TW_PARLAY_LEG_ODDS,
            'reason_zh': ' · '.join(reason_parts) or '攻守節奏與總分回歸模型推估',
            'drama_badge_zh': (g.get('storylines') or {}).get('short_badge_zh') or '',
            'drama_headline_zh': (g.get('storylines') or {}).get('headline_zh') or '',
            'leg_result': leg_res,
            'score': round(score, 4),
        }

      opts = [x for x in (ats_opt, ou_opt) if x is not None]
      if opts:
        best_leg = max(opts, key=lambda x: x['score'])
        ranked_legs.append(best_leg)
        game_options.append({
            'game_id': g['game_id'],
            'tipoff_tw': g['tipoff_tw'],
            'status': g['status'],
            'away_abbr': g['away_abbr'],
            'home_abbr': g['home_abbr'],
            'away_zh': a_tm['zh'],
            'home_zh': h_tm['zh'],
            'away_logo': a_tm.get('logo', ''),
            'home_logo': h_tm.get('logo', ''),
            'away_score': g.get('away_score'),
            'home_score': g.get('home_score'),
            'odds_locked_tw': g.get('odds_locked_tw') or '',
            'best_market': best_leg['market'],
            'ats': ats_opt,
            'ou': ou_opt,
        })

    ranked_legs.sort(key=lambda x: (-x['score'], -x['edge'], x['game_id']))
    packages: list[dict[str, Any]] = []
    if len(ranked_legs) >= 2:
      p2 = _eval_direct_parlay(
          'anchor_2x1',
          '🥇 穩健首選（期望值最高 · 抽水耗損最低）',
          '方案 A：雙星主推 2 串 1',
          '嚴選當日跨場模型優勢（Edge）最高前 2 關組合，兼顧過關率與賠率放大效益。',
          '建議注碼 1.0u',
          ranked_legs[:2],
      )
      packages.append(p2)
      if p2['status'] in ('WIN', 'LOSS', 'PUSH'):
        if p2['status'] == 'WIN':
          kpi['p2_w'] += 1
        elif p2['status'] == 'LOSS':
          kpi['p2_l'] += 1
        else:
          kpi['p2_p'] += 1
        kpi['p2_pnl_intl'] += p2['pnl_unit_intl']
        kpi['p2_pnl_tw'] += p2['pnl_unit_tw']

    p3 = None
    c34 = None
    if len(ranked_legs) >= 3:
      p3 = _eval_direct_parlay(
          'boost_3x1',
          '🥈 進階高賠（小注博近 7 倍高報酬）',
          '方案 B：黃金三星 3 串 1',
          '集結當日跨場前 3 大優勢盤口直串，適合以小額資金博取約 5.3x～6.9x 高賠回報。',
          '建議注碼 0.5u（小注以小博大）',
          ranked_legs[:3],
      )
      c34 = _eval_combo_3x4(ranked_legs[:3])
      packages.append(p3)
      packages.append(c34)
      if p3['status'] in ('WIN', 'LOSS', 'PUSH'):
        if p3['status'] == 'WIN':
          kpi['p3_w'] += 1
        elif p3['status'] == 'LOSS':
          kpi['p3_l'] += 1
        else:
          kpi['p3_p'] += 1
        kpi['p3_pnl_intl'] += p3['pnl_unit_intl']
        kpi['p3_pnl_tw'] += p3['pnl_unit_tw']
      if c34['status'] in ('WIN', 'PARTIAL', 'LOSS'):
        if c34['status'] == 'WIN':
          kpi['c34_full_w'] += 1
        elif c34['status'] == 'PARTIAL':
          kpi['c34_partial'] += 1
        else:
          kpi['c34_l'] += 1
        kpi['c34_pnl_intl'] += c34['pnl_unit_intl']
        kpi['c34_pnl_tw'] += c34['pnl_unit_tw']

    if len(ranked_legs) >= 4:
      alt2 = _eval_direct_parlay(
          'alt_2x1',
          '💎 大比賽日副推（分散主推單場爆冷風險）',
          '方案 D：次高優勢副推 2 串 1',
          '採用當日第 3、第 4 順位獨立賽事組合，與方案 A 完全不重疊，適合分攤單場冷門風險。',
          '建議注碼 0.5u',
          ranked_legs[2:4],
      )
      packages.append(alt2)

    by_date[tw_d] = {
        'tw_date': tw_d,
        'total_games': len(d_games),
        'games_with_odds': len(ranked_legs),
        'strong_legs_cnt': sum(1 for x in ranked_legs if x['tier'] == 'STRONG'),
        'rec_legs_cnt': sum(1 for x in ranked_legs if x['tier'] in ('STRONG', 'LEAN')),
        'awaiting_odds': len(d_games) >= 2 and len(ranked_legs) < 2 and any(g.get('status') == 'SCHEDULED' for g in d_games),
        'ranked_legs': ranked_legs,
        'packages': packages,
        'game_options': game_options,
    }

    if packages and packages[0]['status'] != 'PENDING':
      p2_pkg = packages[0]
      history_rows.append({
          'tw_date': tw_d,
          'games_cnt': len(d_games),
          'p2_picks_zh': ' ＋ '.join(lg['short_label_zh'] for lg in p2_pkg['legs']),
          'p2_intl_odds': p2_pkg['intl_odds'],
          'p2_tw_odds': p2_pkg['tw_odds'],
          'p2_status': p2_pkg['status'],
          'p2_hit_str': f"{p2_pkg['hit_cnt']}/{p2_pkg['legs_count']}",
          'p2_pnl_intl': p2_pkg['pnl_unit_intl'],
          'p2_pnl_tw': p2_pkg['pnl_unit_tw'],
          'p3_picks_zh': ' ＋ '.join(lg['short_label_zh'] for lg in p3['legs']) if p3 else '—',
          'p3_status': p3['status'] if p3 else 'NONE',
          'p3_hit_str': f"{p3['hit_cnt']}/{p3['legs_count']}" if p3 else '—',
          'p3_pnl_intl': p3['pnl_unit_intl'] if p3 else 0.0,
          'c34_status': c34['status'] if c34 else 'NONE',
          'c34_cashed': c34['cashed_combos'] if c34 else 0,
          'c34_pnl_intl': c34['pnl_unit_intl'] if c34 else 0.0,
      })

  p2_tot = kpi['p2_w'] + kpi['p2_l']
  p3_tot = kpi['p3_w'] + kpi['p3_l']
  c34_tot = kpi['c34_full_w'] + kpi['c34_partial'] + kpi['c34_l']
  return {
      'tw_leg_odds': TW_PARLAY_LEG_ODDS,
      'intl_default_leg_odds': round(config.DEFAULT_DECIMAL_ODDS, 2),
      'kpi': {
          'p2_w': kpi['p2_w'],
          'p2_l': kpi['p2_l'],
          'p2_p': kpi['p2_p'],
          'p2_win_rate': round(kpi['p2_w'] / p2_tot * 100.0, 1) if p2_tot > 0 else 0.0,
          'p2_pnl_intl': round(kpi['p2_pnl_intl'], 2),
          'p2_pnl_tw': round(kpi['p2_pnl_tw'], 2),
          'p3_w': kpi['p3_w'],
          'p3_l': kpi['p3_l'],
          'p3_p': kpi['p3_p'],
          'p3_win_rate': round(kpi['p3_w'] / p3_tot * 100.0, 1) if p3_tot > 0 else 0.0,
          'p3_pnl_intl': round(kpi['p3_pnl_intl'], 2),
          'p3_pnl_tw': round(kpi['p3_pnl_tw'], 2),
          'c34_full_w': kpi['c34_full_w'],
          'c34_partial': kpi['c34_partial'],
          'c34_l': kpi['c34_l'],
          'c34_cash_rate': round((kpi['c34_full_w'] + kpi['c34_partial']) / c34_tot * 100.0, 1) if c34_tot > 0 else 0.0,
          'c34_pnl_intl': round(kpi['c34_pnl_intl'], 2),
          'c34_pnl_tw': round(kpi['c34_pnl_tw'], 2),
      },
      'by_date': by_date,
      'history': list(reversed(history_rows)),
  }


def build_snapshot(conn: sqlite3.Connection) -> dict[str, Any]:
  now_tw = dt.datetime.now(config.TZ_TW)
  today_tw = now_tw.strftime('%Y-%m-%d')
  tomorrow_tw = (now_tw.date() + dt.timedelta(days=1)).strftime('%Y-%m-%d')

  params = db.get_state(conn, 'model_params') or model_engine.default_model_params()

  # Team map
  team_rows = conn.execute('SELECT * FROM team_stats').fetchall()
  team_list: list[dict[str, Any]] = []
  team_lookup: dict[str, dict[str, Any]] = {}
  for ab in sorted(teams.TEAMS.keys()):
    ti = teams.team_info(ab)
    r = next((dict(x) for x in team_rows if x['abbr'] == ab), None) or {}
    aw, al, ap = int(r.get('ats_w') or 0), int(r.get('ats_l') or 0), int(r.get('ats_p') or 0)
    ov, un, op = int(r.get('ou_over') or 0), int(r.get('ou_under') or 0), int(r.get('ou_push') or 0)
    ats_pct = round(aw / (aw + al) * 100, 1) if (aw + al) > 0 else 50.0
    over_pct = round(ov / (ov + un) * 100, 1) if (ov + un) > 0 else 50.0
    obj = {
        **ti,
        'wins': int(r.get('wins') or 0),
        'losses': int(r.get('losses') or 0),
        'record': f"{int(r.get('wins') or 0)}-{int(r.get('losses') or 0)}",
        'home_record': str(r.get('home_record') or '0-0'),
        'road_record': str(r.get('road_record') or '0-0'),
        'l10_record': str(r.get('l10_record') or '0-0'),
        'streak': str(r.get('streak') or ''),
        'ppg': float(r.get('ppg') or 114.0),
        'opp_ppg': float(r.get('opp_ppg') or 114.0),
        'diff': float(r.get('diff') or 0.0),
        'ats_w': aw, 'ats_l': al, 'ats_p': ap, 'ats_pct': ats_pct,
        'ou_over': ov, 'ou_under': un, 'ou_push': op, 'over_pct': over_pct,
    }
    team_list.append(obj)
    team_lookup[ab] = obj

  # Injuries & Lineups
  inj_rows = conn.execute(
      'SELECT * FROM injuries ORDER BY est_spread_pts DESC, play_prob_next ASC, player_name ASC'
  ).fetchall()
  injuries_list = [dict(r) for r in inj_rows]
  inj_by_team: dict[str, list[dict[str, Any]]] = {}
  for it in injuries_list:
    inj_by_team.setdefault(it['team_abbr'], []).append(it)

  lu_rows = conn.execute('SELECT * FROM lineups').fetchall()
  lineups_map: dict[str, dict[str, Any]] = {}
  for lr in lu_rows:
    lineups_map[lr['matchup_key']] = {
        'away_confirmed': bool(lr['away_confirmed']),
        'home_confirmed': bool(lr['home_confirmed']),
        'away_starters': _safe_json(lr['away_starters_json'], []),
        'home_starters': _safe_json(lr['home_starters_json'], []),
        'away_may_not_play': _safe_json(lr['away_may_not_play_json'], []),
        'home_may_not_play': _safe_json(lr['home_may_not_play_json'], []),
    }

  # Games + Predictions joined
  pred_rows = conn.execute('SELECT * FROM predictions').fetchall()
  pred_map = {r['game_id']: dict(r) for r in pred_rows}

  game_rows = conn.execute('SELECT * FROM games ORDER BY tipoff_utc ASC, game_id ASC').fetchall()
  games_out: list[dict[str, Any]] = []
  tw_dates_meta: dict[str, dict[str, Any]] = {}

  # Track overall & strong win rates + ROI (assuming standard -110 / 1.9091 odds)
  stats_acc = {
      'strong_w': 0, 'strong_l': 0, 'strong_p': 0,
      'lean_w': 0, 'lean_l': 0, 'lean_p': 0,
      'ats_w': 0, 'ats_l': 0, 'ou_w': 0, 'ou_l': 0,
      'units_staked': 0.0, 'units_pnl': 0.0,
      'fav_cover': 0, 'dog_cover': 0, 'ats_push': 0,
      'over_cnt': 0, 'under_cnt': 0, 'ou_push': 0,
  }

  for gr in game_rows:
    g = dict(gr)
    gid = g['game_id']
    p = pred_map.get(gid) or {}
    fac = _safe_json(p.get('factors_json'), {})
    err_tags = _safe_json(p.get('error_tags_json'), [])

    # League-wide cover / O/U trends
    if g['status'] == 'FINAL':
      sp = g.get('close_spread_home')
      aw = g.get('ats_winner')
      if sp is not None and aw:
        if aw == 'PUSH':
          stats_acc['ats_push'] += 1
        elif (sp < 0 and aw == 'HOME') or (sp > 0 and aw == 'AWAY'):
          stats_acc['fav_cover'] += 1
        else:
          stats_acc['dog_cover'] += 1
      ou = g.get('ou_result')
      if ou == 'OVER':
        stats_acc['over_cnt'] += 1
      elif ou == 'UNDER':
        stats_acc['under_cnt'] += 1
      elif ou == 'PUSH':
        stats_acc['ou_push'] += 1

      # Model grading stats
      for mkt_tier, mkt_res, u_col in (
          (p.get('ats_tier'), p.get('ats_result'), float(p.get('rec_units_ats') or 0.0)),
          (p.get('ou_tier'), p.get('ou_result'), float(p.get('rec_units_ou') or 0.0)),
      ):
        if mkt_tier in ('STRONG', 'LEAN') and mkt_res in ('WIN', 'LOSS', 'PUSH'):
          prefix = 'strong' if mkt_tier == 'STRONG' else 'lean'
          if mkt_res == 'WIN':
            stats_acc[f'{prefix}_w'] += 1
            stats_acc['units_staked'] += u_col
            stats_acc['units_pnl'] += u_col * (config.DEFAULT_DECIMAL_ODDS - 1.0)
          elif mkt_res == 'LOSS':
            stats_acc[f'{prefix}_l'] += 1
            stats_acc['units_staked'] += u_col
            stats_acc['units_pnl'] -= u_col
          else:
            stats_acc[f'{prefix}_p'] += 1

      if p.get('ats_result') == 'WIN':
        stats_acc['ats_w'] += 1
      elif p.get('ats_result') == 'LOSS':
        stats_acc['ats_l'] += 1
      if p.get('ou_result') == 'WIN':
        stats_acc['ou_w'] += 1
      elif p.get('ou_result') == 'LOSS':
        stats_acc['ou_l'] += 1

    tw_d = g['tw_date']
    dm = tw_dates_meta.setdefault(tw_d, {'tw_date': tw_d, 'et_dates': set(), 'total': 0, 'final': 0, 'upcoming': 0})
    dm['et_dates'].add(g['et_date'])
    dm['total'] += 1
    if g['status'] == 'FINAL':
      dm['final'] += 1
    else:
      dm['upcoming'] += 1

    mkey = f"{g['away_abbr']}@{g['home_abbr']}"
    games_out.append({
        'game_id': gid,
        'et_date': g['et_date'],
        'tw_date': tw_d,
        'tipoff_tw': g['tipoff_tw'],
        'status': g['status'],
        'status_detail': g['status_detail'],
        'away_abbr': g['away_abbr'],
        'home_abbr': g['home_abbr'],
        'away_score': g['away_score'],
        'home_score': g['home_score'],
        'away_q_scores': _safe_json(g['away_q_scores'], []),
        'home_q_scores': _safe_json(g['home_q_scores'], []),
        'away_record': g['away_record'] or team_lookup.get(g['away_abbr'], {}).get('record', ''),
        'home_record': g['home_record'] or team_lookup.get(g['home_abbr'], {}).get('record', ''),
        'open_spread_home': g['open_spread_home'],
        'close_spread_home': g['close_spread_home'],
        'open_total': g['open_total'],
        'close_total': g['close_total'],
        'home_ml': g['home_ml'],
        'away_ml': g['away_ml'],
        'home_spread_odds': g['home_spread_odds'],
        'away_spread_odds': g['away_spread_odds'],
        'over_odds': g['over_odds'],
        'under_odds': g['under_odds'],
        'odds_provider': g['odds_provider'],
        'odds_locked_tw': g.get('odds_locked_tw') or '',
        'bpi_home_win_pct': g['bpi_home_win_pct'],
        'margin_home': g['margin_home'],
        'total_points': g['total_points'],
        'ats_winner': g['ats_winner'],
        'ats_cover_margin': g['ats_cover_margin'],
        'ou_result': g['ou_result'],
        'ou_margin': g['ou_margin'],
        'boxscore': _safe_json(g['boxscore_json'], {}),
        'leaders': _safe_json(g['leaders_json'], {}),
        'lineup': lineups_map.get(mkey),
        'away_injuries': inj_by_team.get(g['away_abbr'], [])[:6],
        'home_injuries': inj_by_team.get(g['home_abbr'], [])[:6],
        'pred': {
            'model_version': p.get('model_version') or f"v{params['version']}",
            'pred_margin_home': p.get('pred_margin_home'),
            'fair_spread_home': p.get('fair_spread_home'),
            'ats_edge': p.get('ats_edge') or 0.0,
            'ats_pick': p.get('ats_pick') or 'PASS',
            'ats_lean_side': 'HOME' if (p.get('pred_margin_home') or 0) + (g.get('close_spread_home') or 0) >= 0 else 'AWAY',
            'ats_conf': p.get('ats_conf') or 50,
            'ats_tier': p.get('ats_tier') or 'PASS',
            'pred_total': p.get('pred_total'),
            'ou_edge': p.get('ou_edge') or 0.0,
            'ou_pick': p.get('ou_pick') or 'PASS',
            'ou_lean_side': 'OVER' if (p.get('pred_total') or 0) >= (g.get('close_total') or 0) else 'UNDER',
            'ou_conf': p.get('ou_conf') or 50,
            'ou_tier': p.get('ou_tier') or 'PASS',
            'rec_units_ats': p.get('rec_units_ats') or 0.0,
            'rec_units_ou': p.get('rec_units_ou') or 0.0,
            'rationale_zh': p.get('rationale_zh') or '',
            'factors': fac,
            'guardrails': _safe_json(p.get('guardrails_json'), []),
            'ats_result': p.get('ats_result'),
            'ou_result': p.get('ou_result'),
            'postmortem_zh': p.get('postmortem_zh') or '',
            'error_tags': [
                {'code': tg, 'label': model_engine.ERROR_TAG_LABELS.get(tg, tg)}
                for tg in err_tags
            ],
        },
    })

  dates_sorted = []
  for k in sorted(tw_dates_meta.keys()):
    d = tw_dates_meta[k]
    dates_sorted.append({
        'tw_date': d['tw_date'],
        'et_dates': sorted(d['et_dates']),
        'total': d['total'],
        'final': d['final'],
        'upcoming': d['upcoming'],
    })

  # Pick default active betting date = tomorrow TW if it has games, else earliest date with SCHEDULED games
  sched_dates = sorted({gm['tw_date'] for gm in games_out if gm['status'] == 'SCHEDULED'})
  if tomorrow_tw in sched_dates:
    default_picks_date = tomorrow_tw
  elif sched_dates:
    default_picks_date = sched_dates[0]
  else:
    upcoming_dates = [d['tw_date'] for d in dates_sorted if d['upcoming'] > 0]
    default_picks_date = upcoming_dates[0] if upcoming_dates else (dates_sorted[-1]['tw_date'] if dates_sorted else tomorrow_tw)
  upcoming_dates = [d['tw_date'] for d in dates_sorted if d['upcoming'] > 0]
  finished_dates = [d['tw_date'] for d in dates_sorted if d['final'] > 0]
  default_results_date = finished_dates[-1] if finished_dates else today_tw

  # Teams playing on active upcoming date(s) for Injury Radar quick filter
  next_slate_teams: set[str] = set()
  for gm in games_out:
    if gm['tw_date'] in upcoming_dates[:2] and gm['status'] != 'FINAL':
      next_slate_teams.add(gm['away_abbr'])
      next_slate_teams.add(gm['home_abbr'])

  # News list
  news_rows = conn.execute('SELECT * FROM news ORDER BY published_at DESC LIMIT 80').fetchall()
  news_out = [
      {
          'news_id': r['news_id'],
          'published_at': r['published_at'],
          'published_tw': r['published_tw'],
          'title': r['title'],
          'summary': r['summary'],
          'url': r['url'],
          'source': r['source'],
          'lang': r['lang'],
          'category': r['category'],
          'category_zh': r['category_zh'],
          'teams': _safe_json(r['teams_json'], []),
          'players': _safe_json(r['players_json'], []),
          'play_signal': r['play_signal'],
      }
      for r in news_rows
  ]

  # Evolution log & factor leaderboard
  evo_rows = conn.execute('SELECT * FROM evolution_log ORDER BY evo_id ASC').fetchall()
  evo_out = [
      {
          'et_date': r['et_date'],
          'model_version': r['model_version'],
          'games_graded': r['games_graded'],
          'ats_wins': r['ats_wins'],
          'ats_losses': r['ats_losses'],
          'ou_wins': r['ou_wins'],
          'ou_losses': r['ou_losses'],
          'cum_strong_win_rate': r['cum_strong_win_rate'],
          'cum_all_win_rate': r['cum_all_win_rate'],
          'summary_zh': r['summary_zh'],
          'weight_deltas': _safe_json(r['weight_deltas_json'], {}),
      }
      for r in evo_rows
  ]

  ats_factors_board = []
  for fk, fm in model_engine.ATS_FACTOR_META.items():
    st = params['ats_stats'].get(fk) or {'hits': 0, 'trials': 0, 'ema_gain': 0.0}
    cur_w = float(params['ats_weights'].get(fk, fm['init_w']))
    hr = round(st['hits'] / st['trials'] * 100, 1) if st['trials'] > 0 else 50.0
    ats_factors_board.append({
        'key': fk,
        'market': 'ATS 讓分',
        'name_zh': fm['name_zh'],
        'desc_zh': fm['desc_zh'],
        'init_w': fm['init_w'],
        'cur_w': round(cur_w, 3),
        'delta_w': round(cur_w - fm['init_w'], 3),
        'hits': st['hits'],
        'trials': st['trials'],
        'hit_rate': hr,
    })

  ou_factors_board = []
  for fk, fm in model_engine.OU_FACTOR_META.items():
    st = params['ou_stats'].get(fk) or {'hits': 0, 'trials': 0, 'ema_gain': 0.0}
    cur_w = float(params['ou_weights'].get(fk, fm['init_w']))
    hr = round(st['hits'] / st['trials'] * 100, 1) if st['trials'] > 0 else 50.0
    ou_factors_board.append({
        'key': fk,
        'market': 'O/U 大小分',
        'name_zh': fm['name_zh'],
        'desc_zh': fm['desc_zh'],
        'init_w': fm['init_w'],
        'cur_w': round(cur_w, 3),
        'delta_w': round(cur_w - fm['init_w'], 3),
        'hits': st['hits'],
        'trials': st['trials'],
        'hit_rate': hr,
    })

  error_breakdown = [
      {
          'code': k,
          'label': model_engine.ERROR_TAG_LABELS.get(k, k),
          'count': v,
      }
      for k, v in sorted((params.get('error_counts') or {}).items(), key=lambda kv: -kv[1])
  ]

  strong_tot = stats_acc['strong_w'] + stats_acc['strong_l']
  all_rec_w = stats_acc['strong_w'] + stats_acc['lean_w']
  all_rec_l = stats_acc['strong_l'] + stats_acc['lean_l']
  all_rec_tot = all_rec_w + all_rec_l
  roi_pct = round(stats_acc['units_pnl'] / stats_acc['units_staked'] * 100, 2) if stats_acc['units_staked'] > 0 else 0.0

  ai_coach_memo = db.get_state(conn, 'latest_ai_coach', None)

  # --- Player Boxscores per Game + NBA.com Traditional Stats & Leaders ---
  roster_map: dict[str, dict[str, Any]] = {}
  try:
    for rr in conn.execute('SELECT * FROM roster_players').fetchall():
      roster_map[rr['player_id']] = dict(rr)
  except sqlite3.OperationalError:
    pass

  boxscore_cols = [
      'pid', 'name', 'pos', 'jersey', 'starter', 'dnp', 'dnp_reason',
      'min_str', 'min', 'pts', 'fgm', 'fga', 'tpm', 'tpa', 'ftm', 'fta',
      'oreb', 'dreb', 'reb', 'ast', 'tov', 'stl', 'blk', 'pf', 'pm',
  ]
  game_home_map = {gm['game_id']: gm['home_abbr'] for gm in games_out}
  game_boxscores: dict[str, dict[str, list[list[Any]]]] = {}
  p_agg: dict[str, dict[str, Any]] = {}
  t_agg: dict[str, dict[str, float]] = {
      ab: {
          'gp_set': set(), 'pts': 0, 'fgm': 0, 'fga': 0, 'tpm': 0, 'tpa': 0,
          'ftm': 0, 'fta': 0, 'oreb': 0, 'dreb': 0, 'reb': 0, 'ast': 0,
          'tov': 0, 'stl': 0, 'blk': 0, 'pf': 0,
      }
      for ab in teams.TEAMS
  }

  try:
    pgl_rows = conn.execute(
        """
        SELECT * FROM player_game_logs
        ORDER BY game_id ASC, dnp ASC, starter DESC, minutes DESC, pts DESC
        """
    ).fetchall()
  except sqlite3.OperationalError:
    pgl_rows = []

  for r in pgl_rows:
    gid = r['game_id']
    pid = r['player_id']
    tabbr = r['team_abbr']
    rmeta = roster_map.get(pid) or {}
    pos = r['position'] or rmeta.get('position') or ''
    jersey = r['jersey'] or rmeta.get('jersey') or ''
    dnp = int(r['dnp'] or 0)
    gb = game_boxscores.setdefault(gid, {'away': [], 'home': []})
    side_key = 'home' if tabbr == game_home_map.get(gid) else 'away'
    gb[side_key].append([
        pid, r['player_name'], pos, jersey, int(r['starter'] or 0), dnp, r['dnp_reason'] or '',
        r['min_str'] or '', round(float(r['minutes'] or 0.0), 1),
        int(r['pts'] or 0), int(r['fgm'] or 0), int(r['fga'] or 0),
        int(r['tpm'] or 0), int(r['tpa'] or 0), int(r['ftm'] or 0), int(r['fta'] or 0),
        int(r['oreb'] or 0), int(r['dreb'] or 0), int(r['reb'] or 0),
        int(r['ast'] or 0), int(r['tov'] or 0), int(r['stl'] or 0),
        int(r['blk'] or 0), int(r['pf'] or 0), int(r['plus_minus'] or 0),
    ])
    if dnp:
      continue

    if tabbr in t_agg:
      ta = t_agg[tabbr]
      ta['gp_set'].add(gid)
      ta['pts'] += int(r['pts'] or 0)
      ta['fgm'] += int(r['fgm'] or 0)
      ta['fga'] += int(r['fga'] or 0)
      ta['tpm'] += int(r['tpm'] or 0)
      ta['tpa'] += int(r['tpa'] or 0)
      ta['ftm'] += int(r['ftm'] or 0)
      ta['fta'] += int(r['fta'] or 0)
      ta['oreb'] += int(r['oreb'] or 0)
      ta['dreb'] += int(r['dreb'] or 0)
      ta['reb'] += int(r['reb'] or 0)
      ta['ast'] += int(r['ast'] or 0)
      ta['tov'] += int(r['tov'] or 0)
      ta['stl'] += int(r['stl'] or 0)
      ta['blk'] += int(r['blk'] or 0)
      ta['pf'] += int(r['pf'] or 0)

    pa = p_agg.get(pid)
    if not pa:
      pa = {
          'pid': pid,
          'name': r['player_name'],
          'short_name': r['short_name'] or r['player_name'],
          'team': rmeta.get('team_abbr') or tabbr,
          'pos': pos,
          'jersey': jersey,
          'age': int(rmeta.get('age') or 0),
          'headshot': rmeta.get('headshot') or r['headshot'] or f'https://a.espncdn.com/i/headshots/nba/players/full/{pid}.png',
          'gp': 0, 'gs': 0, 'w': 0, 'l': 0,
          'min': 0.0, 'pts': 0, 'fgm': 0, 'fga': 0, 'tpm': 0, 'tpa': 0,
          'ftm': 0, 'fta': 0, 'oreb': 0, 'dreb': 0, 'reb': 0,
          'ast': 0, 'tov': 0, 'stl': 0, 'blk': 0, 'pf': 0, 'pm': 0,
          'dd2': 0, 'td3': 0, 'latest_et': '',
      }
      p_agg[pid] = pa
    if r['et_date'] >= pa['latest_et']:
      pa['latest_et'] = r['et_date']
      if not rmeta.get('team_abbr'):
        pa['team'] = tabbr
    pa['gp'] += 1
    pa['gs'] += int(r['starter'] or 0)
    if int(r['team_win'] or 0):
      pa['w'] += 1
    else:
      pa['l'] += 1
    pts_i = int(r['pts'] or 0)
    reb_i = int(r['reb'] or 0)
    ast_i = int(r['ast'] or 0)
    stl_i = int(r['stl'] or 0)
    blk_i = int(r['blk'] or 0)
    tov_i = int(r['tov'] or 0)
    pa['min'] += float(r['minutes'] or 0.0)
    pa['pts'] += pts_i
    pa['fgm'] += int(r['fgm'] or 0)
    pa['fga'] += int(r['fga'] or 0)
    pa['tpm'] += int(r['tpm'] or 0)
    pa['tpa'] += int(r['tpa'] or 0)
    pa['ftm'] += int(r['ftm'] or 0)
    pa['fta'] += int(r['fta'] or 0)
    pa['oreb'] += int(r['oreb'] or 0)
    pa['dreb'] += int(r['dreb'] or 0)
    pa['reb'] += reb_i
    pa['ast'] += ast_i
    pa['tov'] += tov_i
    pa['stl'] += stl_i
    pa['blk'] += blk_i
    pa['pf'] += int(r['pf'] or 0)
    pa['pm'] += int(r['plus_minus'] or 0)
    cnt10 = sum(1 for x in (pts_i, reb_i, ast_i, stl_i, blk_i) if x >= 10)
    if cnt10 >= 2:
      pa['dd2'] += 1
    if cnt10 >= 3:
      pa['td3'] += 1

  max_team_gp = max([len(v['gp_set']) for v in t_agg.values()] + [1])
  min_qual_gp = max(2, int(max_team_gp * 0.5))

  player_stats: list[dict[str, Any]] = []
  for pa in p_agg.values():
    gp = max(1, pa['gp'])
    fp_tot = pa['pts'] + 1.2 * pa['reb'] + 1.5 * pa['ast'] + 3.0 * pa['stl'] + 3.0 * pa['blk'] - 1.0 * pa['tov']
    fg_pct = round(pa['fgm'] / pa['fga'] * 100.0, 1) if pa['fga'] > 0 else 0.0
    tp_pct = round(pa['tpm'] / pa['tpa'] * 100.0, 1) if pa['tpa'] > 0 else 0.0
    ft_pct = round(pa['ftm'] / pa['fta'] * 100.0, 1) if pa['fta'] > 0 else 0.0
    player_stats.append({
        'pid': pa['pid'],
        'name': pa['name'],
        'short_name': pa['short_name'],
        'team': pa['team'],
        'pos': pa['pos'] or 'G/F',
        'jersey': pa['jersey'],
        'age': pa['age'] if pa['age'] > 0 else None,
        'headshot': pa['headshot'],
        'gp': pa['gp'],
        'gs': pa['gs'],
        'w': pa['w'],
        'l': pa['l'],
        'qual': pa['gp'] >= min_qual_gp,
        'min': round(pa['min'] / gp, 1),
        'pts': round(pa['pts'] / gp, 1),
        'fgm': round(pa['fgm'] / gp, 1),
        'fga': round(pa['fga'] / gp, 1),
        'fg_pct': fg_pct,
        'tpm': round(pa['tpm'] / gp, 1),
        'tpa': round(pa['tpa'] / gp, 1),
        'tp_pct': tp_pct,
        'ftm': round(pa['ftm'] / gp, 1),
        'fta': round(pa['fta'] / gp, 1),
        'ft_pct': ft_pct,
        'oreb': round(pa['oreb'] / gp, 1),
        'dreb': round(pa['dreb'] / gp, 1),
        'reb': round(pa['reb'] / gp, 1),
        'ast': round(pa['ast'] / gp, 1),
        'tov': round(pa['tov'] / gp, 1),
        'stl': round(pa['stl'] / gp, 1),
        'blk': round(pa['blk'] / gp, 1),
        'pf': round(pa['pf'] / gp, 1),
        'fp': round(fp_tot / gp, 1),
        'dd2': pa['dd2'],
        'td3': pa['td3'],
        'pm': round(pa['pm'] / gp, 1),
        'tot': {
            'min': round(pa['min'], 1),
            'pts': pa['pts'], 'fgm': pa['fgm'], 'fga': pa['fga'],
            'tpm': pa['tpm'], 'tpa': pa['tpa'], 'ftm': pa['ftm'], 'fta': pa['fta'],
            'oreb': pa['oreb'], 'dreb': pa['dreb'], 'reb': pa['reb'],
            'ast': pa['ast'], 'tov': pa['tov'], 'stl': pa['stl'], 'blk': pa['blk'],
            'pf': pa['pf'], 'fp': round(fp_tot, 1), 'pm': pa['pm'],
        },
    })
  player_stats.sort(key=lambda x: (-x['pts'], -x['fp'], x['name']))

  team_trad_stats: list[dict[str, Any]] = []
  for tm in team_list:
    ab = tm['abbr']
    ta = t_agg[ab]
    gp = max(1, len(ta['gp_set']) or (tm['wins'] + tm['losses']))
    fg_pct = round(ta['fgm'] / ta['fga'] * 100.0, 1) if ta['fga'] > 0 else 0.0
    tp_pct = round(ta['tpm'] / ta['tpa'] * 100.0, 1) if ta['tpa'] > 0 else 0.0
    ft_pct = round(ta['ftm'] / ta['fta'] * 100.0, 1) if ta['fta'] > 0 else 0.0
    pts_pg = round(ta['pts'] / gp, 1) if ta['pts'] > 0 else tm['ppg']
    win_pct = round(tm['wins'] / max(1, tm['wins'] + tm['losses']) * 100.0, 1)
    team_trad_stats.append({
        'abbr': ab,
        'zh': tm['zh'],
        'city_zh': tm['city_zh'],
        'en': tm['en'],
        'conf': tm['conf'],
        'logo': tm['logo'],
        'gp': tm['wins'] + tm['losses'] or len(ta['gp_set']),
        'w': tm['wins'],
        'l': tm['losses'],
        'win_pct': win_pct,
        'pts': pts_pg,
        'opp_pts': tm['opp_ppg'],
        'pm': tm['diff'],
        'fgm': round(ta['fgm'] / gp, 1),
        'fga': round(ta['fga'] / gp, 1),
        'fg_pct': fg_pct,
        'tpm': round(ta['tpm'] / gp, 1),
        'tpa': round(ta['tpa'] / gp, 1),
        'tp_pct': tp_pct,
        'ftm': round(ta['ftm'] / gp, 1),
        'fta': round(ta['fta'] / gp, 1),
        'ft_pct': ft_pct,
        'oreb': round(ta['oreb'] / gp, 1),
        'dreb': round(ta['dreb'] / gp, 1),
        'reb': round(ta['reb'] / gp, 1),
        'ast': round(ta['ast'] / gp, 1),
        'tov': round(ta['tov'] / gp, 1),
        'stl': round(ta['stl'] / gp, 1),
        'blk': round(ta['blk'] / gp, 1),
        'pf': round(ta['pf'] / gp, 1),
        'ats_w': tm['ats_w'],
        'ats_l': tm['ats_l'],
        'ats_pct': tm['ats_pct'],
        'over_pct': tm['over_pct'],
        'tot': {
            'pts': int(ta['pts']), 'fgm': int(ta['fgm']), 'fga': int(ta['fga']),
            'tpm': int(ta['tpm']), 'tpa': int(ta['tpa']), 'ftm': int(ta['ftm']), 'fta': int(ta['fta']),
            'oreb': int(ta['oreb']), 'dreb': int(ta['dreb']), 'reb': int(ta['reb']),
            'ast': int(ta['ast']), 'tov': int(ta['tov']), 'stl': int(ta['stl']),
            'blk': int(ta['blk']), 'pf': int(ta['pf']),
        },
    })
  team_trad_stats.sort(key=lambda x: (-x['win_pct'], -x['pm'], -x['pts']))

  qual_players = [p for p in player_stats if p['qual']] or player_stats

  def _top_p(stat_key: str, pool_list: list[dict[str, Any]], n: int = 5) -> list[dict[str, Any]]:
    arr = sorted(pool_list, key=lambda x: (-float(x.get(stat_key) or 0.0), -float(x.get('pts') or 0.0)))[:n]
    return [
        {
            'pid': x['pid'], 'name': x['name'], 'team': x['team'],
            'pos': x['pos'], 'headshot': x['headshot'], 'gp': x['gp'], 'val': x[stat_key],
        }
        for x in arr
    ]

  fg_pool = [p for p in qual_players if p['fgm'] >= 3.5] or qual_players
  tp_pool = [p for p in qual_players if p['tpm'] >= 1.5] or qual_players
  ft_pool = [p for p in qual_players if p['ftm'] >= 2.0] or qual_players

  stat_leaders = {
      'players': {
          'pts': _top_p('pts', qual_players),
          'reb': _top_p('reb', qual_players),
          'ast': _top_p('ast', qual_players),
          'stl': _top_p('stl', qual_players),
          'blk': _top_p('blk', qual_players),
          'tpm': _top_p('tpm', qual_players),
          'fg_pct': _top_p('fg_pct', fg_pool),
          'tp_pct': _top_p('tp_pct', tp_pool),
          'ft_pct': _top_p('ft_pct', ft_pool),
          'fp': _top_p('fp', qual_players),
          'pm': _top_p('pm', qual_players),
          'dd2': _top_p('dd2', player_stats),
      },
      'teams': {
          'pts': sorted(team_trad_stats, key=lambda x: -x['pts'])[:5],
          'def_pts': sorted(team_trad_stats, key=lambda x: x['opp_pts'])[:5],
          'pm': sorted(team_trad_stats, key=lambda x: -x['pm'])[:5],
          'fg_pct': sorted(team_trad_stats, key=lambda x: -x['fg_pct'])[:5],
          'tp_pct': sorted(team_trad_stats, key=lambda x: -x['tp_pct'])[:5],
          'reb': sorted(team_trad_stats, key=lambda x: -x['reb'])[:5],
          'ast': sorted(team_trad_stats, key=lambda x: -x['ast'])[:5],
          'blk': sorted(team_trad_stats, key=lambda x: -x['blk'])[:5],
      },
  }

  last_odds_row = conn.execute(
      "SELECT fetch_key, updated_at FROM fetch_log WHERE source='odds_2300_tw' ORDER BY fetch_key DESC LIMIT 1"
  ).fetchone()

  roster_by_team: dict[str, list[dict[str, Any]]] = {}
  for rp in roster_map.values():
    if rp.get('team_abbr'):
      roster_by_team.setdefault(rp['team_abbr'], []).append(rp)

  for gm in games_out:
    gm['storylines'] = storylines.evaluate_game_storylines(
        gm['away_abbr'],
        gm['home_abbr'],
        roster_by_team=roster_by_team,
        injuries_by_team=inj_by_team,
        away_record=str(gm.get('away_record') or ''),
        home_record=str(gm.get('home_record') or ''),
        news_items=news_out,
        game_boxscore=game_boxscores.get(gm['game_id']),
        game_status=str(gm.get('status') or 'SCHEDULED'),
    )

  daily_parlays = _build_daily_parlays(games_out, team_lookup)

  return {
      'meta': {
          'generated_at_tw': now_tw.strftime('%Y-%m-%d %H:%M:%S'),
          'today_tw': today_tw,
          'tomorrow_tw': tomorrow_tw,
          'default_picks_date': default_picks_date,
          'default_results_date': default_results_date,
          'season_label': config.SEASON_LABEL,
          'model_version': f"v{params['version']}",
          'evolution_steps': params.get('step_count', 0),
          'breakeven_pct': round(config.BREAKEVEN_WIN_RATE * 100, 2),
          'odds_capture_tw': config.ODDS_CAPTURE_TW_TIME,
          'last_odds_lock_tw': dict(last_odds_row)['updated_at'] if last_odds_row else '',
          'schedules_tw': list(config.SCHEDULE_TW_TIMES),
          'next_slate_teams': sorted(next_slate_teams),
      },
      'kpi': {
          'strong_w': stats_acc['strong_w'],
          'strong_l': stats_acc['strong_l'],
          'strong_win_rate': round(stats_acc['strong_w'] / strong_tot * 100, 1) if strong_tot > 0 else 0.0,
          'rec_w': all_rec_w,
          'rec_l': all_rec_l,
          'rec_win_rate': round(all_rec_w / all_rec_tot * 100, 1) if all_rec_tot > 0 else 0.0,
          'ats_w': stats_acc['ats_w'],
          'ats_l': stats_acc['ats_l'],
          'ou_w': stats_acc['ou_w'],
          'ou_l': stats_acc['ou_l'],
          'units_pnl': round(stats_acc['units_pnl'], 2),
          'units_staked': round(stats_acc['units_staked'], 1),
          'roi_pct': roi_pct,
          'league_fav_cover': stats_acc['fav_cover'],
          'league_dog_cover': stats_acc['dog_cover'],
          'league_over': stats_acc['over_cnt'],
          'league_under': stats_acc['under_cnt'],
      },
      'dates': dates_sorted,
      'games': games_out,
      'daily_parlays': daily_parlays,
      'teams': team_list,
      'boxscore_cols': boxscore_cols,
      'game_boxscores': game_boxscores,
      'player_stats': player_stats,
      'team_trad_stats': team_trad_stats,
      'stat_leaders': stat_leaders,
      'injuries': injuries_list,
      'news': news_out,
      'evolution': {
          'thresholds': params['thresholds'],
          'baseline_comparison': params.get('baseline_comparison') or {},
          'guardrails': params.get('guardrails') or [],
          'ats_factors': ats_factors_board,
          'ou_factors': ou_factors_board,
          'error_breakdown': error_breakdown,
          'timeline': evo_out,
          'ai_coach_memo': ai_coach_memo,
      },
  }


def build_and_save_snapshot(conn: sqlite3.Connection) -> dict[str, Any]:
  snap = build_snapshot(conn)
  os.makedirs(config.DATA_DIR, exist_ok=True)
  tmp = config.SNAPSHOT_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(snap, f, ensure_ascii=False, separators=(',', ':'))
  os.replace(tmp, config.SNAPSHOT_JSON)
  os.chmod(config.SNAPSHOT_JSON, 0o644)
  return snap


def load_cached_snapshot() -> dict[str, Any]:
  if os.path.isfile(config.SNAPSHOT_JSON):
    try:
      with open(config.SNAPSHOT_JSON, encoding='utf-8') as f:
        return json.load(f)
    except (OSError, ValueError):
      pass
  conn = db.connect()
  try:
    return build_and_save_snapshot(conn)
  finally:
    conn.close()
