#!/usr/bin/env python3
"""Configuration constants for NBA 運彩智庫 (NBA Betting Analytics & Self-Evolving Studio)."""
from __future__ import annotations

import datetime as dt
import os
from zoneinfo import ZoneInfo

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')
DB_PATH = os.path.join(DATA_DIR, 'nba_betting.db')
SNAPSHOT_JSON = os.path.join(DATA_DIR, 'snapshot.json')
LOCK_FILE = os.path.join(DATA_DIR, 'updater.lock')

TOOL_NAME = 'NBA 戰情室'
TOOL_SUBTITLE = '每日讓分／大小分盤口分析 · 傷兵出賽雷達 · 賽後自動檢討進化系統'
SERVICE_SLUG = 'nba-betting-studio'
BACKEND_PORT = 8912
PROXY_PORT = 8913

TZ_TW = ZoneInfo('Asia/Taipei')
TZ_ET = ZoneInfo('America/New_York')
TZ_UTC = dt.timezone.utc

# 2026-27 NBA Regular Season Opening Night (US Eastern Time)
SEASON_YEAR = 2027
SEASON_LABEL = '2026-27 例行賽'
SEASON_START_ET = dt.date(2026, 10, 20)

# Two-stage daily Taiwan times (HH:MM) for Point Spread & Over/Under capture and re-analysis:
# - 18:00 (Stage 1 初盤擷取＋首輪解盤): Captures early opening spreads & totals and runs Pass 1 analysis.
# - 23:00 (Stage 2 尾盤鎖定＋盤勢變化二輪重析): Captures final pre-game spreads & totals while preserving
#   the 18:00 baseline, evaluates 18:00 -> 23:00 line movement (盤勢變化), and locks lines for grading.
EARLY_ODDS_CAPTURE_TW_TIME = '18:00'
ODDS_CAPTURE_TW_TIME = '23:00'
ODDS_CAPTURE_SLOTS_TW = (EARLY_ODDS_CAPTURE_TW_TIME, ODDS_CAPTURE_TW_TIME)

# Scheduled daily auto-refresh times in Taiwan time (HH:MM):
# - 06:40: Pre-tipoff final injury / GTD / RotoWire lineup check (does NOT alter locked 23:00 odds)
# - 11:40: Morning post-game score & boxscore grading against locked 23:00 odds
# - 14:15: Full post-game final grading + Walk-Forward Model Self-Evolution against locked 23:00 odds
# - 18:00: Stage 1 early capture of Point Spread & Over/Under + Pass 1 quantitative analysis
# - 23:00: Stage 2 final lock of Point Spread & Over/Under + 18:00->23:00 line-movement Pass 2 re-analysis
SCHEDULE_TW_TIMES = ('06:40', '11:40', '14:15', EARLY_ODDS_CAPTURE_TW_TIME, ODDS_CAPTURE_TW_TIME)

# Standard international sportsbook vig (-110 = 1.9091 decimal -> 52.38% breakeven)
BREAKEVEN_WIN_RATE = 110.0 / 210.0  # 0.5238095
DEFAULT_DECIMAL_ODDS = 1.9091
TW_LOTTERY_DEFAULT_ODDS = 1.75
