/* NBA 運彩智庫 — Core SPA Router, State, IME-Safe Input, Modals & Release Center */
(function () {
  'use strict';

  const _isPublicStaticHost = Boolean(
    window.NBA_STATIC_ONLY ||
    location.protocol === 'file:' ||
    /\.github\.io$|\.pages\.dev$|\.netlify\.app$|\.vercel\.app$/i.test(location.hostname || '')
  );

  const NBA = (window.NBA = {
    isStatic: _isPublicStaticHost,
    snap: window.__STATIC_SNAPSHOT__ || null,
    health: { ok: true, ai: false, version: '1.0.0' },
    bets: [],
    pages: {},
    route: 'picks',
    state: {
      picksDate: '',
      picksFilter: 'ALL',
      picksSearch: '',
      resultsDate: 'ALL',
      resultsFilter: 'ALL',
      resultsTeam: 'ALL',
      resultsTab: 'ledger',
      activeTeam: 'LAL',
      teamTab: 'games',
      teamGameId: '',
      teamBoxSide: 'BOTH',
      teamRosterSort: 'pts',
      statsEntity: 'players',
      statsPerMode: 'per_game',
      statsScope: 'all',
      statsTeam: 'ALL',
      statsPos: 'ALL',
      statsSearch: '',
      statsSort: 'pts',
      statsDir: 'desc',
      statsPage: 1,
      teamStatsSort: 'pts',
      teamStatsDir: 'desc',
      newsTab: 'injuries',
      injSlateOnly: true,
      injTeam: 'ALL',
      injStatus: 'ALL',
      injQuery: '',
      newsCat: 'ALL',
      newsTeam: 'ALL',
      newsQuery: '',
      parlayBook: 'INTL',
      parlayStake: 500,
      customParlayLegs: {},
    },
  });

  // --- IME-Safe Enter Guard (Pattern 9 — Mandatory for Traditional Chinese IMEs) ---
  let _imeComposing = false;
  let _lastImeEndAt = 0;
  document.addEventListener('compositionstart', () => { _imeComposing = true; }, true);
  document.addEventListener('compositionend', () => { _imeComposing = false; _lastImeEndAt = Date.now(); }, true);
  NBA.isEnterSend = function (ev) {
    return (
      ev.key === 'Enter' &&
      !ev.shiftKey &&
      !ev.isComposing &&
      ev.keyCode !== 229 &&
      !_imeComposing &&
      Date.now() - _lastImeEndAt >= 150
    );
  };

  NBA.esc = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  NBA.fmtSpread = function (val) {
    if (val == null || val === '') return '未開盤';
    const n = Number(val);
    if (Number.isNaN(n)) return '未開盤';
    if (n === 0) return 'PK (0.0)';
    return (n > 0 ? '+' : '') + n.toFixed(1);
  };

  NBA.fmtSigned = function (val, digits = 1) {
    if (val == null || val === '') return '—';
    const n = Number(val);
    if (Number.isNaN(n)) return '—';
    return (n > 0 ? '+' : '') + n.toFixed(digits);
  };

  NBA.fmtOdds = function (american) {
    if (american == null || american === '') return '-110';
    const n = Number(american);
    return (n > 0 ? '+' : '') + Math.round(n);
  };

  NBA.teamMap = {};
  NBA.teamOf = function (abbr) {
    return NBA.teamMap[abbr] || { abbr, zh: abbr, en: abbr, logo: '', record: '' };
  };

  NBA.toast = function (msg) {
    const box = document.getElementById('toastBox');
    if (!box) return;
    const el = document.createElement('div');
    el.className = 'toast-msg';
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => { el.remove(); }, 3200);
  };

  NBA.apiGet = async function (path) {
    if (NBA.isStatic) {
      if (path === '/api/snapshot') return NBA.snap;
      if (path === '/api/bets') {
        let list = [];
        try { list = JSON.parse(localStorage.getItem('nba.bets.v1') || '[]'); } catch (_) { list = []; }
        const graded = NBA._gradeStaticBets(list);
        if (graded.changed) {
          try { localStorage.setItem('nba.bets.v1', JSON.stringify(graded.list)); } catch (_) { /* 無痕模式或空間不足：略過 */ }
        }
        return { bets: graded.list };
      }
      if (path === '/api/feedback') {
        try { return { ok: true, items: JSON.parse(localStorage.getItem('nba.feedback.v1') || '[]') }; }
        catch (_) { return { ok: true, items: [] }; }
      }
      if (path === '/api/release_status') {
        const rd = window.NBA_RELEASES || { current_version: '1.0.0', releases: [] };
        return { current_version: rd.current_version, has_changes: false, changed_files: [], releases: rd.releases || [] };
      }
      return {};
    }
    const r = await fetch(path, { headers: { Accept: 'application/json' } });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  };

  NBA.apiPost = async function (path, body) {
    if (NBA.isStatic) {
      if (path.startsWith('/api/bets/')) return NBA._staticBetAction(path, body || {});
      throw new Error('靜態離線版不支援雲端背景操作，請在 Cloudtop 主機操作。');
    }
    const r = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body || {}),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  };

  NBA._staticBetAction = function (path, body) {
    let list = [];
    try { list = JSON.parse(localStorage.getItem('nba.bets.v1') || '[]'); } catch (_) { list = []; }
    if (path === '/api/bets/add') {
      list.unshift({
        bet_id: 'BET-' + Date.now().toString(36).toUpperCase(),
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
        tw_date: body.tw_date || '',
        game_id: body.game_id || '',
        matchup: body.matchup || '',
        market: body.market || 'ATS',
        pick_side: body.pick_side || 'HOME',
        pick_label: body.pick_label || '',
        line: Number(body.line || 0),
        odds_decimal: Number(body.odds_decimal || 1.91),
        stake: Number(body.stake || 1000),
        status: 'PENDING',
        pnl: 0,
        note: body.note || '',
      });
      list = NBA._gradeStaticBets(list).list;
    } else if (path === '/api/bets/settle') {
      list = list.map((b) => {
        if (b.bet_id !== body.bet_id) return b;
        const st = body.status || 'PENDING';
        const pnl = st === 'WIN' ? +(b.stake * (b.odds_decimal - 1)).toFixed(2) : st === 'LOSS' ? -b.stake : 0;
        return { ...b, status: st, pnl };
      });
    } else if (path === '/api/bets/delete') {
      list = list.filter((b) => b.bet_id !== body.bet_id);
    }
    localStorage.setItem('nba.bets.v1', JSON.stringify(list));
    return { ok: true, bets: list };
  };

  // GitHub Pages / offline builds have no backend, so settle PENDING bets in the browser against the
  // bundled snapshot with the same rules as model_engine._eval_single_bet_leg / _grade_parlay_bet.
  const NBA_DEFAULT_ODDS = 1.9091;  // config.DEFAULT_DECIMAL_ODDS
  const round2 = (x) => Math.round(x * 100) / 100;
  NBA._evalLeg = function (g, mkt, side, line) {
    if (!g || g.status !== 'FINAL' || g.home_score == null || g.away_score == null) return 'PENDING';
    const hs = parseInt(g.home_score, 10);
    const as = parseInt(g.away_score, 10);
    if (mkt === 'ATS') {
      const diff = side === 'HOME' ? hs - as + line : as - hs + line;
      return diff > 0 ? 'WIN' : diff < 0 ? 'LOSS' : 'PUSH';
    }
    if (mkt === 'OU') {
      const tot = hs + as;
      if (side === 'OVER') return tot > line ? 'WIN' : tot < line ? 'LOSS' : 'PUSH';
      return tot < line ? 'WIN' : tot > line ? 'LOSS' : 'PUSH';
    }
    if (mkt === 'ML') {
      if (hs === as) return 'PUSH';
      return (side === 'HOME' && hs > as) || (side === 'AWAY' && as > hs) ? 'WIN' : 'LOSS';
    }
    return 'PENDING';
  };
  function gradeStaticParlay(b, byId) {
    let spec;
    try { spec = JSON.parse(String(b.game_id).slice('PARLAY:'.length)); } catch (_) { return ['PENDING', 0]; }
    const stake = Number(b.stake || 0);
    const oddsDec = Number(b.odds_decimal || NBA_DEFAULT_ODDS);
    const legState = (lg) => [
      NBA._evalLeg(byId[String(lg.gid || '')], String(lg.m || 'ATS'), String(lg.s || 'HOME'), Number(lg.l || 0)),
      Number(lg.o || NBA_DEFAULT_ODDS),
    ];
    if (spec && !Array.isArray(spec) && spec.type === 'COMBO') {
      const legs = spec.legs || [];
      const combos = spec.combos || [];
      if (!legs.length || !combos.length) return ['PENDING', 0];
      const states = legs.map(legState);
      const inRange = (idx) => idx >= 0 && idx < states.length;
      if (combos.every((cb) => cb.some((idx) => inRange(idx) && states[idx][0] === 'LOSS'))) return ['LOSS', round2(-stake)];
      if (states.some(([st]) => st === 'PENDING')) return ['PENDING', 0];
      const unit = stake / combos.length;
      let ret = 0;
      for (const cb of combos) {
        const cbLegs = cb.filter(inRange).map((idx) => states[idx]);
        if (!cbLegs.length || cbLegs.some(([st]) => st === 'LOSS')) continue;
        let mult = 1;
        for (const [st, lo] of cbLegs) if (st === 'WIN') mult *= lo;
        ret += unit * mult;
      }
      const pnl = round2(ret - stake);
      return [pnl > 0 ? 'WIN' : pnl < 0 ? 'LOSS' : 'PUSH', pnl];
    }
    if (!Array.isArray(spec) || !spec.length) return ['PENDING', 0];
    const states = spec.map(legState);
    if (states.some(([st]) => st === 'LOSS')) return ['LOSS', round2(-stake)];
    if (states.some(([st]) => st === 'PENDING')) return ['PENDING', 0];
    if (states.every(([st]) => st === 'PUSH')) return ['PUSH', 0];
    if (states.every(([st]) => st === 'WIN')) return ['WIN', round2(stake * (oddsDec - 1))];
    let eff = 1;
    for (const [st, lo] of states) if (st === 'WIN') eff *= lo;
    return ['WIN', round2(stake * (eff - 1))];
  }
  NBA._gradeStaticBets = function (list) {
    const byId = {};
    for (const g of (NBA.snap && NBA.snap.games) || []) byId[g.game_id] = g;
    let changed = false;
    const out = list.map((b) => {
      const gid = String(b.game_id || '');
      if (b.status !== 'PENDING' || !gid) return b;
      let st;
      let pnl = 0;
      if (gid.startsWith('PARLAY:')) {
        [st, pnl] = gradeStaticParlay(b, byId);
      } else {
        st = NBA._evalLeg(byId[gid], b.market, b.pick_side, Number(b.line || 0));
        const stake = Number(b.stake || 0);
        pnl = st === 'WIN' ? round2(stake * (Number(b.odds_decimal || NBA_DEFAULT_ODDS) - 1)) : st === 'LOSS' ? -stake : 0;
      }
      if (st === 'PENDING') return b;
      changed = true;
      return { ...b, status: st, pnl };
    });
    return { list: out, changed };
  };

  // --- Modal Helpers ---
  NBA.openModal = function (title, bodyHtml, sizeCls) {
    const card = document.getElementById('appModalCard');
    if (card) {
      card.className = 'modal-card' + (sizeCls ? ' ' + sizeCls : '');
    }
    document.getElementById('appModalTitle').textContent = title;
    document.getElementById('appModalBody').innerHTML = bodyHtml;
    document.getElementById('appModalBd').classList.remove('hidden');
  };
  NBA.closeModal = function () {
    document.getElementById('appModalBd').classList.add('hidden');
  };

  // --- Shared Single-Game Player Boxscore & Player Game-Log Modals ---
  // boxscore_cols order:
  // [0:pid, 1:name, 2:pos, 3:jersey, 4:starter, 5:dnp, 6:dnp_reason, 7:min_str, 8:minutes,
  //  9:pts, 10:fgm, 11:fga, 12:tpm, 13:tpa, 14:ftm, 15:fta, 16:oreb, 17:dreb, 18:reb,
  //  19:ast, 20:tov, 21:stl, 22:blk, 23:pf, 24:plus_minus]
  function renderSideBoxTable(teamAbbr, rows) {
    const tm = NBA.teamOf(teamAbbr);
    if (!rows || !rows.length) {
      return `<div class="empty-box" style="padding:18px">尚無 ${NBA.esc(tm.zh)} 單場球員統計資料</div>`;
    }
    const active = rows.filter((r) => !r[5]);
    const starters = active.filter((r) => r[4]);
    const bench = active.filter((r) => !r[4]);
    const dnps = rows.filter((r) => r[5]);

    const sum = { pts: 0, fgm: 0, fga: 0, tpm: 0, tpa: 0, ftm: 0, fta: 0, oreb: 0, dreb: 0, reb: 0, ast: 0, stl: 0, blk: 0, tov: 0, pf: 0 };
    active.forEach((r) => {
      sum.pts += r[9]; sum.fgm += r[10]; sum.fga += r[11];
      sum.tpm += r[12]; sum.tpa += r[13]; sum.ftm += r[14]; sum.fta += r[15];
      sum.oreb += r[16]; sum.dreb += r[17]; sum.reb += r[18];
      sum.ast += r[19]; sum.tov += r[20]; sum.stl += r[21]; sum.blk += r[22]; sum.pf += r[23];
    });
    const pct = (m, a) => (a > 0 ? ((m / a) * 100).toFixed(1) + '%' : '—');

    const rowHtml = (r) => {
      const pm = r[24];
      const pmTxt = pm > 0 ? '+' + pm : String(pm);
      const pmColor = pm > 0 ? '#15803d' : pm < 0 ? '#b91c1c' : '#475569';
      return `
        <tr>
          <td class="left sticky-pl" style="left:0;min-width:170px">
            <span class="pl-link" data-player-id="${NBA.esc(r[0])}" style="font-weight:700;color:#1d4ed8">${NBA.esc(r[1])}</span>
            ${r[3] ? `<span style="color:#94a3b8;font-size:11px">#${NBA.esc(r[3])}</span>` : ''}
            ${r[2] ? `<span style="color:#64748b;font-size:11px;margin-left:3px">${NBA.esc(r[2])}</span>` : ''}
          </td>
          <td>${NBA.esc(r[7] || r[8])}</td>
          <td style="font-weight:800;color:#0f172a;background:#fefce8">${r[9]}</td>
          <td>${r[10]}-${r[11]}</td>
          <td>${pct(r[10], r[11])}</td>
          <td>${r[12]}-${r[13]}</td>
          <td>${pct(r[12], r[13])}</td>
          <td>${r[14]}-${r[15]}</td>
          <td>${pct(r[14], r[15])}</td>
          <td>${r[16]}</td>
          <td>${r[17]}</td>
          <td style="font-weight:700">${r[18]}</td>
          <td style="font-weight:700">${r[19]}</td>
          <td>${r[21]}</td>
          <td>${r[22]}</td>
          <td>${r[20]}</td>
          <td>${r[23]}</td>
          <td style="font-weight:700;color:${pmColor}">${pmTxt}</td>
        </tr>`;
    };

    const secRow = (lbl) => `
      <tr>
        <td colspan="18" class="left" style="background:#f1f5f9;font-size:11px;font-weight:800;color:#475569;padding:5px 10px">${lbl}</td>
      </tr>`;

    return `
      <div class="card" style="padding:12px 14px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px">
          <div style="display:flex;align-items:center;gap:8px">
            <img src="${NBA.esc(tm.logo)}" alt="" style="width:28px;height:28px;object-fit:contain">
            <strong class="tm-link" data-team-link="${NBA.esc(teamAbbr)}" style="font-size:15px">${NBA.esc(tm.city_zh || '')} ${NBA.esc(tm.zh)} (${NBA.esc(teamAbbr)})</strong>
          </div>
          <span style="font-size:12px;color:#64748b">點擊球員姓名可查看個人整季逐場明細</span>
        </div>
        <div class="nba-tbl-wrap standalone">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="left no-sort" style="min-width:170px">球員 PLAYER</th>
                <th class="no-sort">MIN</th>
                <th class="no-sort col-active">PTS</th>
                <th class="no-sort">FGM-A</th>
                <th class="no-sort">FG%</th>
                <th class="no-sort">3PM-A</th>
                <th class="no-sort">3P%</th>
                <th class="no-sort">FTM-A</th>
                <th class="no-sort">FT%</th>
                <th class="no-sort">OREB</th>
                <th class="no-sort">DREB</th>
                <th class="no-sort">REB</th>
                <th class="no-sort">AST</th>
                <th class="no-sort">STL</th>
                <th class="no-sort">BLK</th>
                <th class="no-sort">TOV</th>
                <th class="no-sort">PF</th>
                <th class="no-sort">+/-</th>
              </tr>
            </thead>
            <tbody>
              ${starters.length ? secRow('先發五人 STARTERS') + starters.map(rowHtml).join('') : ''}
              ${bench.length ? secRow('替補輪替 BENCH') + bench.map(rowHtml).join('') : ''}
              <tr style="font-weight:800;background:#f8fafc">
                <td class="left" style="background:#f8fafc">全隊總計 TOTALS</td>
                <td>240</td>
                <td style="background:#fef9c3">${sum.pts}</td>
                <td>${sum.fgm}-${sum.fga}</td>
                <td>${pct(sum.fgm, sum.fga)}</td>
                <td>${sum.tpm}-${sum.tpa}</td>
                <td>${pct(sum.tpm, sum.tpa)}</td>
                <td>${sum.ftm}-${sum.fta}</td>
                <td>${pct(sum.ftm, sum.fta)}</td>
                <td>${sum.oreb}</td>
                <td>${sum.dreb}</td>
                <td>${sum.reb}</td>
                <td>${sum.ast}</td>
                <td>${sum.stl}</td>
                <td>${sum.blk}</td>
                <td>${sum.tov}</td>
                <td>${sum.pf}</td>
                <td>—</td>
              </tr>
            </tbody>
          </table>
        </div>
        ${dnps.length ? `
          <div style="margin-top:8px;font-size:12px;color:#64748b">
            <strong>未上場 DNP：</strong>
            ${dnps.map((r) => `<span style="margin-right:10px">${NBA.esc(r[1])}（${NBA.esc(r[6] || '教練團未派上場')}）</span>`).join('')}
          </div>` : ''}
      </div>`;
  }

  NBA.renderGameBoxscoreHtml = function (gid, sideFilter) {
    const g = ((NBA.snap && NBA.snap.games) || []).find((x) => x.game_id === gid);
    if (!g) return '<div class="empty-box">找不到該場賽事紀錄</div>';
    const gb = ((NBA.snap && NBA.snap.game_boxscores) || {})[gid] || { away: [], home: [] };
    const a = NBA.teamOf(g.away_abbr);
    const h = NBA.teamOf(g.home_abbr);
    const aq = g.away_q_scores || [];
    const hq = g.home_q_scores || [];
    const qLen = Math.max(aq.length, hq.length, 4);
    const qHdrs = Array.from({ length: qLen }, (_, i) => (i < 4 ? `Q${i + 1}` : `OT${i - 3}`));

    const sp = g.close_spread_home;
    const atsChip = sp != null && g.ats_winner
      ? (g.ats_winner === 'PUSH'
        ? '<span class="chip warn">讓分走水</span>'
        : `<span class="chip ok">讓分過盤：${NBA.esc((g.ats_winner === 'HOME' ? h : a).zh)} ${NBA.fmtSpread(g.ats_winner === 'HOME' ? sp : -sp)}</span>`)
      : '';
    const ouChip = g.close_total && g.ou_result
      ? `<span class="chip ${g.ou_result === 'OVER' ? 'strong' : 'info'}">大小分：${g.ou_result === 'OVER' ? '大分 OVER' : g.ou_result === 'UNDER' ? '小分 UNDER' : '走水'} (${g.total_points} / 盤 ${g.close_total})</span>`
      : '';

    const sf = sideFilter || 'BOTH';
    return `
      <div style="display:flex;flex-direction:column;gap:12px">
        <div class="card" style="background:#f8fafc;padding:12px 16px">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:8px">
            <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
              <span class="tm-link" data-team-link="${NBA.esc(g.away_abbr)}" style="display:inline-flex;align-items:center;gap:6px;font-weight:800;font-size:16px">
                <img src="${NBA.esc(a.logo)}" alt="" style="width:28px;height:28px;object-fit:contain">
                ${NBA.esc(a.zh)}
              </span>
              <span style="font-size:21px;font-weight:900;background:#fff;padding:2px 12px;border-radius:8px;border:1px solid #cbd5e1">${g.away_score ?? '—'} : ${g.home_score ?? '—'}</span>
              <span class="tm-link" data-team-link="${NBA.esc(g.home_abbr)}" style="display:inline-flex;align-items:center;gap:6px;font-weight:800;font-size:16px">
                ${NBA.esc(h.zh)}
                <img src="${NBA.esc(h.logo)}" alt="" style="width:28px;height:28px;object-fit:contain">
              </span>
              <span style="font-size:12px;color:#64748b">台灣 ${NBA.esc(g.tw_date)}（美東 ${NBA.esc(g.et_date)}）</span>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">${atsChip}${ouChip}</div>
          </div>
          ${aq.length ? `
            <div class="tbl-wrap" style="max-width:520px">
              <table class="data-tbl" style="font-size:12px">
                <thead>
                  <tr>
                    <th>球隊</th>
                    ${qHdrs.map((q) => `<th class="num">${q}</th>`).join('')}
                    <th class="num">總分</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><strong>${NBA.esc(a.zh)} (${NBA.esc(g.away_abbr)})</strong></td>
                    ${qHdrs.map((_, i) => `<td class="num">${aq[i] ?? '—'}</td>`).join('')}
                    <td class="num"><strong>${g.away_score}</strong></td>
                  </tr>
                  <tr>
                    <td><strong>${NBA.esc(h.zh)} (${NBA.esc(g.home_abbr)})</strong></td>
                    ${qHdrs.map((_, i) => `<td class="num">${hq[i] ?? '—'}</td>`).join('')}
                    <td class="num"><strong>${g.home_score}</strong></td>
                  </tr>
                </tbody>
              </table>
            </div>` : ''}
        </div>
        ${sf === 'BOTH' || sf === g.away_abbr ? renderSideBoxTable(g.away_abbr, gb.away) : ''}
        ${sf === 'BOTH' || sf === g.home_abbr ? renderSideBoxTable(g.home_abbr, gb.home) : ''}
      </div>`;
  };

  NBA.openGameBoxscoreModal = function (gid) {
    const g = ((NBA.snap && NBA.snap.games) || []).find((x) => x.game_id === gid);
    if (!g) return;
    const a = NBA.teamOf(g.away_abbr);
    const h = NBA.teamOf(g.home_abbr);
    NBA.openModal(
      `📊 單場球員數據 Boxscore · ${a.zh} ${g.away_score ?? ''} @ ${h.zh} ${g.home_score ?? ''} (${g.tw_date})`,
      NBA.renderGameBoxscoreHtml(gid, 'BOTH'),
      'modal-xl'
    );
  };

  NBA.openPlayerModal = function (pid) {
    const snap = NBA.snap || {};
    const p = (snap.player_stats || []).find((x) => String(x.pid) === String(pid));
    if (!p) {
      NBA.toast('找不到該球員本季出場紀錄');
      return;
    }
    const tm = NBA.teamOf(p.team);
    const gMap = {};
    (snap.games || []).forEach((g) => { gMap[g.game_id] = g; });

    // Collect every game log for this player from game_boxscores
    const logs = [];
    const gbs = snap.game_boxscores || {};
    Object.keys(gbs).forEach((gid) => {
      const g = gMap[gid];
      if (!g) return;
      ['away', 'home'].forEach((side) => {
        const row = (gbs[gid][side] || []).find((r) => String(r[0]) === String(pid));
        if (row && !row[5]) {
          const isHome = side === 'home';
          const myTeam = isHome ? g.home_abbr : g.away_abbr;
          const opp = isHome ? g.away_abbr : g.home_abbr;
          const mySc = isHome ? g.home_score : g.away_score;
          const oppSc = isHome ? g.away_score : g.home_score;
          const win = mySc > oppSc;
          logs.push({ g, row, isHome, myTeam, opp, mySc, oppSc, win });
        }
      });
    });
    logs.sort((a, b) => (b.g.et_date || '').localeCompare(a.g.et_date || ''));

    const pct = (m, a) => (a > 0 ? ((m / a) * 100).toFixed(1) : '0.0');
    const bodyHtml = `
      <div style="display:flex;flex-direction:column;gap:14px">
        <div class="card" style="background:linear-gradient(135deg,#eff6ff 0%,#ffffff 100%);display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:14px">
            <img src="${NBA.esc(p.headshot)}" alt="" style="width:68px;height:68px;border-radius:50%;object-fit:cover;background:#fff;border:2px solid #93c5fd" onerror="this.style.display='none'">
            <div>
              <div style="font-size:20px;font-weight:900;color:#0f172a">
                ${NBA.esc(p.name)}
                ${p.jersey ? `<span style="color:#64748b;font-size:15px">#${NBA.esc(p.jersey)}</span>` : ''}
              </div>
              <div style="font-size:13px;color:#475569;margin-top:3px;display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <span class="tm-link" data-team-link="${NBA.esc(p.team)}" style="font-weight:700;color:#1d4ed8">🏀 ${NBA.esc(tm.zh)} (${NBA.esc(p.team)})</span>
                <span>位置：${NBA.esc(p.pos || '—')}</span>
                ${p.age ? `<span>年齡：${p.age} 歲</span>` : ''}
                <span>出賽 ${p.gp} 場（${p.w}勝-${p.l}敗）</span>
              </div>
            </div>
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap">
            <div class="th-stat"><div class="th-stat-lbl">場均得分 PTS</div><div class="th-stat-val" style="color:#1d4ed8">${p.pts.toFixed(1)}</div></div>
            <div class="th-stat"><div class="th-stat-lbl">場均籃板 REB</div><div class="th-stat-val">${p.reb.toFixed(1)}</div></div>
            <div class="th-stat"><div class="th-stat-lbl">場均助攻 AST</div><div class="th-stat-val">${p.ast.toFixed(1)}</div></div>
            <div class="th-stat"><div class="th-stat-lbl">命中率 FG / 3P / FT</div><div class="th-stat-val" style="font-size:14px">${p.fg_pct.toFixed(1)}% / ${p.tp_pct.toFixed(1)}% / ${p.ft_pct.toFixed(1)}%</div></div>
            <div class="th-stat"><div class="th-stat-lbl">幻想分 FP / 正負值</div><div class="th-stat-val" style="font-size:14px">${p.fp.toFixed(1)} / ${NBA.fmtSigned(p.pm, 1)}</div></div>
          </div>
        </div>

        <div>
          <h4 style="margin:0 0 8px;font-size:14.5px">📅 本季逐場比賽數據明細（共 ${logs.length} 場 · 點擊比數可看該場全隊 Boxscore）</h4>
          <div class="nba-tbl-wrap standalone">
            <table class="nba-stats-tbl">
              <thead>
                <tr>
                  <th class="left no-sort">台灣日期</th>
                  <th class="left no-sort">對戰對手</th>
                  <th class="left no-sort">結果與比數</th>
                  <th class="no-sort">MIN</th>
                  <th class="no-sort col-active">PTS</th>
                  <th class="no-sort">FGM-A</th>
                  <th class="no-sort">FG%</th>
                  <th class="no-sort">3PM-A</th>
                  <th class="no-sort">3P%</th>
                  <th class="no-sort">FTM-A</th>
                  <th class="no-sort">OREB</th>
                  <th class="no-sort">DREB</th>
                  <th class="no-sort">REB</th>
                  <th class="no-sort">AST</th>
                  <th class="no-sort">STL</th>
                  <th class="no-sort">BLK</th>
                  <th class="no-sort">TOV</th>
                  <th class="no-sort">PF</th>
                  <th class="no-sort">+/-</th>
                </tr>
              </thead>
              <tbody>
                ${logs.map(({ g, row, isHome, opp, mySc, oppSc, win }) => {
                  const oppTm = NBA.teamOf(opp);
                  const pm = row[24];
                  return `
                    <tr>
                      <td class="left">${NBA.esc(g.tw_date)}</td>
                      <td class="left">
                        <span class="tm-link" data-team-link="${NBA.esc(opp)}" style="font-weight:700;color:#1d4ed8">
                          ${isHome ? 'vs' : '@'} ${NBA.esc(oppTm.zh)} (${NBA.esc(opp)})
                        </span>
                      </td>
                      <td class="left">
                        <button type="button" class="btn btn-sm" data-boxscore-gid="${NBA.esc(g.game_id)}" style="padding:2px 8px;font-size:11.5px">
                          <span style="color:${win ? '#15803d' : '#b91c1c'};font-weight:800">${win ? 'W' : 'L'}</span> ${mySc}-${oppSc} 📊
                        </button>
                      </td>
                      <td>${NBA.esc(row[7] || row[8])}</td>
                      <td class="col-active">${row[9]}</td>
                      <td>${row[10]}-${row[11]}</td>
                      <td>${pct(row[10], row[11])}%</td>
                      <td>${row[12]}-${row[13]}</td>
                      <td>${pct(row[12], row[13])}%</td>
                      <td>${row[14]}-${row[15]}</td>
                      <td>${row[16]}</td>
                      <td>${row[17]}</td>
                      <td style="font-weight:700">${row[18]}</td>
                      <td style="font-weight:700">${row[19]}</td>
                      <td>${row[21]}</td>
                      <td>${row[22]}</td>
                      <td>${row[20]}</td>
                      <td>${row[23]}</td>
                      <td style="font-weight:700;color:${pm > 0 ? '#15803d' : pm < 0 ? '#b91c1c' : '#475569'}">${pm > 0 ? '+' + pm : pm}</td>
                    </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>`;

    NBA.openModal(`👤 球員個人數據檔案 · ${p.name}`, bodyHtml, 'modal-xl');
  };

  // --- Quick Bet Slip Modal（➕ 記讓分單／記大小單）---
  // Guided form instead of free-text fields: ① tap the side you back (this sets `pick_side`, which
  // auto-settlement grades) → ② line + odds → ③ stake, with a live payout preview. The market is fixed by
  // the button that opened the modal. The spread is kept home-based (`lineBase`) and shown from the picked
  // team's side, which is how model_engine._eval_single_bet_leg grades it.
  NBA.openQuickBetModal = function (gid, market) {
    const g = ((NBA.snap && NBA.snap.games) || []).find((x) => x.game_id === gid);
    if (!g) return;
    const h = NBA.teamOf(g.home_abbr);
    const a = NBA.teamOf(g.away_abbr);
    const p = g.pred || {};
    const isATS = market !== 'OU';
    const matchup = `${a.zh} @ ${h.zh}`;
    const money = (n) => Math.round(n).toLocaleString('en-US');
    const num = (v) => (v == null || v === '' || Number.isNaN(Number(v)) ? null : Number(v));
    let lineBase = isATS ? num(g.close_spread_home) : num(g.close_total);
    let options;
    let recSide;
    let recIsPick;
    let stepTitle;
    if (isATS) {
      options = [
        { side: 'AWAY', team: a, tag: '客' },
        { side: 'HOME', team: h, tag: '主' },
      ];
      recIsPick = Boolean(p.ats_tier) && p.ats_tier !== 'PASS' && (p.ats_pick === 'HOME' || p.ats_pick === 'AWAY');
      recSide = recIsPick ? p.ats_pick : (p.ats_lean_side === 'AWAY' ? 'AWAY' : 'HOME');
      const pm = num(p.pred_margin_home);
      stepTitle = `① 你看好哪一隊過盤？（點一下選擇）${pm != null ? `<span class="qb-step-sub">模型預估：${NBA.esc((pm >= 0 ? h : a).zh)} 贏 ${Math.abs(pm).toFixed(1)} 分</span>` : ''}`;
    } else {
      options = [
        { side: 'OVER', name: '大分 OVER' },
        { side: 'UNDER', name: '小分 UNDER' },
      ];
      recIsPick = Boolean(p.ou_tier) && p.ou_tier !== 'PASS' && (p.ou_pick === 'OVER' || p.ou_pick === 'UNDER');
      recSide = recIsPick ? p.ou_pick : (p.ou_lean_side === 'UNDER' ? 'UNDER' : 'OVER');
      const pt = num(p.pred_total);
      stepTitle = `① 押大分還是小分？（點一下選擇）${pt != null ? `<span class="qb-step-sub">模型預估總分 ${pt.toFixed(1)} 分</span>` : ''}`;
    }
    const recChip = recIsPick ? '<span class="chip strong">👍 模型推薦</span>' : '<span class="chip muted">模型傾向</span>';
    // Spread read from the picked team: it covers when (its margin + L) > 0; a whole-number L can push.
    // NBA games never end level, so a margin of 0 never happens.
    function atsRule(L) {
      const need = -L;
      const isWhole = Number.isInteger(need);
      const minWin = Math.floor(need) + 1;
      const loseMax = isWhole ? need - 1 : minWin - 1;
      return {
        win: minWin >= 2 ? `贏 ${minWin} 分以上` : minWin >= 0 ? '贏球' : `輸 ${-minWin} 分以內或贏球`,
        lose: loseMax >= 1 ? `只贏 ${loseMax} 分以內或輸球` : loseMax >= -1 ? '輸球' : `輸 ${-loseMax} 分以上`,
        push: isWhole && need !== 0 ? (need > 0 ? `剛好贏 ${need} 分` : `剛好輸 ${-need} 分`) : '',
      };
    }
    // Totals: a .5 line never pushes; on a whole-number line an exact hit is a push (stake refunded).
    const ouCut = (ln) => ({ over: Math.floor(ln) + 1, under: Math.ceil(ln) - 1, push: Number.isInteger(ln) ? ln : null });
    const sideLine = (s) => (s === 'HOME' ? lineBase : -lineBase);

    const optHtml = (o) => `
      <label class="qb-opt" data-qb-side="${o.side}">
        <input type="radio" name="qbSide" value="${o.side}">
        <span class="qb-opt-hd">
          <span class="qb-opt-name"><span class="qb-radio" aria-hidden="true"></span>${NBA.esc(isATS ? `${o.team.zh}（${o.tag}）` : o.name)}${isATS ? `<span class="qb-opt-line" data-qb-line="${o.side}"></span>` : ''}</span>
          ${o.side === recSide ? recChip : ''}
        </span>
        <span class="qb-opt-sub" data-qb-desc="${o.side}"></span>
      </label>`;
    const explainHtml = isATS
      ? '🏀 <strong>讓分盤</strong>：把讓分加到你押的那一隊比分上再比輸贏（以含延長賽的最終比分計算）。負數是讓分：押 −5.5 要贏 6 分以上；正數是受讓：押 +5.5 輸 5 分以內也算贏。'
      : '↕️ <strong>大小分</strong>：猜兩隊最終總得分（含延長賽）會大於還是小於盤口線，跟哪一隊贏無關。';
    const lineRowHtml = `
      <div class="qb-line-row">
        <label for="qbLine">${isATS ? '讓分' : '總分盤口'}</label>
        <input type="number" ${isATS ? '' : 'inputmode="decimal"'} step="0.5" class="inp" id="qbLine">
        <span id="qbLineUnit">${isATS ? '' : '分'}</span>
        <span class="qb-hint" id="qbLineHint"></span>
      </div>`;

    NBA.openModal(
      `➕ 加入注單追蹤 · ${matchup}`,
      `<form id="quickBetForm" class="qb-form" novalidate>
        <div class="qb-explain">${explainHtml}</div>
        <div class="qb-step" role="radiogroup" aria-labelledby="qbStepPick">
          <div class="qb-step-title" id="qbStepPick">${stepTitle}</div>
          <div class="qb-opts">${options.map(optHtml).join('')}</div>
          ${lineRowHtml}
        </div>
        <div class="qb-fields">
          <div class="qb-field">
            <label class="qb-step-title" for="qbOdds">② 賠率</label>
            <input type="number" inputmode="decimal" step="0.01" min="1.01" class="inp" id="qbOdds" value="1.91">
            <div class="qb-chips"><button type="button" class="qb-chip" data-qb-odds="1.75">台灣運彩 1.75</button><button type="button" class="qb-chip" data-qb-odds="1.91">國際盤 1.91</button></div>
            <span class="qb-hint">讓分、大小分沒有固定賠率：國際盤常見 1.91、台灣運彩常見 1.75，請改成你實際下注時看到的數字。</span>
          </div>
          <div class="qb-field">
            <label class="qb-step-title" for="qbStake">③ 投注金額（NT$）</label>
            <input type="number" inputmode="numeric" step="100" min="1" class="inp" id="qbStake" value="1000">
            <div class="qb-chips">${[100, 500, 1000, 2000, 5000].map((v) => `<button type="button" class="qb-chip" data-qb-stake="${v}">${money(v)}</button>`).join('')}</div>
          </div>
        </div>
        <div class="qb-preview" id="qbPreview" aria-live="polite"></div>
        <label class="qb-field">
          <span class="qb-step-title">備註（選填）</span>
          <input class="inp" id="qbNote" maxlength="200" placeholder="例如：主將復出、初盤順勢進場">
        </label>
        <div class="qb-foot">📌 這裡只是幫你<strong>記帳</strong>，不會真的下注。比賽結束後系統會依最終比分自動對獎、計算損益，可到「📝 注單追蹤」查看${NBA.isStatic ? '（公開版的注單只存在這台裝置的瀏覽器）' : ''}。</div>
        <div class="qb-actions">
          <button type="button" class="btn" data-qb-cancel>取消</button>
          <button type="submit" class="btn btn-primary" id="qbSubmit">💾 儲存注單</button>
        </div>
      </form>`
    );

    const form = document.getElementById('quickBetForm');
    const lineInp = document.getElementById('qbLine');
    const oddsInp = document.getElementById('qbOdds');
    const stakeInp = document.getElementById('qbStake');
    const preview = document.getElementById('qbPreview');
    const submitBtn = document.getElementById('qbSubmit');
    let side = recSide;
    let saving = false;

    const showLine = () => { lineInp.value = lineBase == null ? '' : String(isATS ? sideLine(side) : lineBase); };
    const lineOk = () => lineBase != null && Number.isInteger(lineBase * 2)
      && (isATS ? Math.abs(lineBase) <= 40 : lineBase >= 100 && lineBase <= 350);

    function refresh() {
      const odds = Number(oddsInp.value);
      const stake = Number(stakeInp.value);
      const lOk = lineOk();
      const oddsOk = oddsInp.value.trim() !== '' && odds >= 1.01;
      const stakeOk = stakeInp.value.trim() !== '' && stake >= 1;
      lineInp.classList.toggle('inp-err', !lOk);
      oddsInp.classList.toggle('inp-err', !oddsOk);
      stakeInp.classList.toggle('inp-err', !stakeOk);
      form.querySelectorAll('[data-qb-stake]').forEach((b) => b.classList.toggle('on', Number(b.getAttribute('data-qb-stake')) === stake));
      form.querySelectorAll('[data-qb-odds]').forEach((b) => b.classList.toggle('on', Number(b.getAttribute('data-qb-odds')) === odds));

      const hint = document.getElementById('qbLineHint');
      if (isATS) {
        document.getElementById('qbLineUnit').textContent = `分（${optOf(side).team.zh}）`;
        hint.textContent = g.close_spread_home == null
          ? '本場還沒抓到盤口，請填你下注時看到的讓分；負數＝讓分、正數＝受讓。'
          : '負數＝讓分、正數＝受讓；已帶入本站每晚 23:00 的盤口，請對照你下注的盤口。';
      }
      if (lOk) {
        options.forEach((o) => {
          const d = form.querySelector(`[data-qb-desc="${o.side}"]`);
          if (isATS) {
            const L = sideLine(o.side);
            const r = atsRule(L);
            form.querySelector(`[data-qb-line="${o.side}"]`).textContent = NBA.fmtSpread(L);
            d.textContent = `${r.win}就算過盤${r.push ? `（${r.push}走水）` : ''}`;
          } else {
            const c = ouCut(lineBase);
            d.textContent = o.side === 'OVER' ? `總分 ${c.over} 分以上` : `總分 ${c.under} 分以下`;
          }
        });
        if (!isATS) {
          const c = ouCut(lineBase);
          hint.textContent = `${lineBase} 代表 ${c.over} 分以上算「大」、${c.under} 分以下算「小」${c.push != null ? `，剛好 ${c.push} 分算走水（退回本金）` : ''}；請對照你下注的盤口。`;
        }
      } else if (!isATS) {
        hint.textContent = g.close_total == null ? '本場還沒抓到盤口，請填你下注時看到的總分線。' : '';
      }

      const errs = [];
      if (!lOk) errs.push(isATS ? '讓分請填 0.5 的倍數，例如 -5.5、+3、0' : '總分盤口請填 0.5 的倍數，例如 223.5');
      if (!oddsOk) errs.push('賠率要大於 1，例如 1.91');
      if (!stakeOk) errs.push('請填投注金額，例如 1000');
      submitBtn.disabled = saving || errs.length > 0;
      if (errs.length) {
        preview.className = 'qb-preview invalid';
        preview.innerHTML = errs.map((e) => `<div>⚠️ ${e}</div>`).join('');
        return;
      }
      const back = stake * odds;
      let win;
      let lose;
      let push = '';
      if (isATS) {
        const nm = `「${optOf(side).team.zh}」`;
        const r = atsRule(sideLine(side));
        win = nm + r.win;
        lose = nm + r.lose;
        push = r.push ? nm + r.push : '';
      } else {
        const c = ouCut(lineBase);
        win = side === 'OVER' ? `總分 ${c.over} 分以上` : `總分 ${c.under} 分以下`;
        lose = side === 'OVER' ? `總分 ${c.under} 分以下` : `總分 ${c.over} 分以上`;
        push = c.push != null ? `總分剛好 ${c.push} 分` : '';
      }
      preview.className = 'qb-preview';
      preview.innerHTML = `
        <div>💰 若${NBA.esc(win)} → 可領回 <strong>NT$${money(back)}</strong>（含本金，淨賺 <strong>+${money(back - stake)}</strong>）</div>
        <div class="loss">若${NBA.esc(lose)} → 損失本金 NT$${money(stake)}</div>
        ${push ? `<div class="push">若${NBA.esc(push)} → 走水，退回本金 NT$${money(stake)}</div>` : ''}`;
    }

    function optOf(s) { return options.find((o) => o.side === s) || options[0]; }
    function selectSide(s) {
      side = s;
      form.querySelectorAll('.qb-opt').forEach((el) => {
        const on = el.getAttribute('data-qb-side') === s;
        el.classList.toggle('selected', on);
        el.querySelector('input').checked = on;
      });
      if (isATS) showLine();  // the spread flips sign with the team you back
      refresh();
    }

    form.querySelectorAll('input[name="qbSide"]').forEach((r) => {
      r.addEventListener('change', () => { if (r.checked) selectSide(r.value); });
    });
    lineInp.addEventListener('input', () => {
      const v = num(lineInp.value);
      lineBase = v == null ? null : (isATS && side === 'AWAY' ? -v : v);
      refresh();
    });
    form.querySelectorAll('[data-qb-stake]').forEach((b) => {
      b.addEventListener('click', () => { stakeInp.value = b.getAttribute('data-qb-stake'); refresh(); });
    });
    form.querySelectorAll('[data-qb-odds]').forEach((b) => {
      b.addEventListener('click', () => { oddsInp.value = b.getAttribute('data-qb-odds'); refresh(); });
    });
    [oddsInp, stakeInp].forEach((inp) => inp.addEventListener('input', refresh));
    // IME-safe: the Enter that confirms a 注音／倉頡 candidate in 備註 must not submit the form.
    form.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' && ev.target.tagName === 'INPUT' && !NBA.isEnterSend(ev)) ev.preventDefault();
    });
    form.querySelector('[data-qb-cancel]').addEventListener('click', NBA.closeModal);
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      refresh();
      if (saving || submitBtn.disabled) return;
      saving = true;
      submitBtn.disabled = true;
      submitBtn.textContent = '⏳ 儲存中…';
      const L = isATS ? sideLine(side) : lineBase;
      try {
        const res = await NBA.apiPost('/api/bets/add', {
          tw_date: g.tw_date,
          game_id: g.game_id,
          matchup,
          market: isATS ? 'ATS' : 'OU',
          pick_side: side,
          pick_label: isATS ? `${optOf(side).team.zh} ${NBA.fmtSpread(L)}` : `${side === 'OVER' ? '大分' : '小分'} ${L}`,
          line: L,
          odds_decimal: Number(oddsInp.value),
          stake: Number(stakeInp.value),
          note: document.getElementById('qbNote').value.trim(),
        });
        NBA.bets = res.bets || [];
        NBA.closeModal();
        NBA.toast('✅ 已加入注單！比賽結束後會自動對獎，可到「📝 注單追蹤」查看');
      } catch (e) {
        saving = false;
        submitBtn.textContent = '💾 儲存注單';
        refresh();
        NBA.toast('⚠️ ' + e.message);
      }
    });
    showLine();
    selectSide(recSide);
  };

  // One-click Add Multi-Leg Parlay / Combo Bet to Bankroll (Auto-settled on Final)
  NBA.addParlayBet = async function (opts) {
    try {
      const book = opts.book || NBA.state.parlayBook || 'INTL';
      const unitStake = Math.max(10, Number(opts.unitStake || NBA.state.parlayStake || 500));
      const legs = opts.legs || [];
      if (legs.length < 2) {
        NBA.toast('⚠️ 串關至少需要選擇 2 場不同賽事');
        return;
      }
      const legSpecs = legs.map((lg) => ({
        gid: lg.game_id,
        m: lg.market,
        s: lg.pick_side,
        l: Number(lg.line || 0),
        o: Number(book === 'TW' ? lg.tw_odds || 1.75 : lg.intl_odds || 1.91),
      }));
      const isCombo = opts.type === 'COMBO' && Array.isArray(opts.combos) && opts.combos.length > 0;
      const encodedGid = 'PARLAY:' + JSON.stringify(
        isCombo ? { type: 'COMBO', combos: opts.combos, legs: legSpecs } : legSpecs
      );
      const betsCnt = isCombo ? opts.combos.length : 1;
      const totalStake = unitStake * betsCnt;
      const combinedOdds = isCombo
        ? Number((opts.combos.reduce((acc, cb) => acc + cb.reduce((m, idx) => m * legSpecs[idx].o, 1), 0) / betsCnt).toFixed(2))
        : Number(legSpecs.reduce((m, x) => m * x.o, 1).toFixed(2));
      const bookZh = book === 'TW' ? '台灣運彩盤' : '國際盤';
      const titleTag = opts.title || (isCombo ? `${legs.length}串${betsCnt} 複式` : `${legs.length}串1`);
      const picksSummary = legs.map((lg) => lg.short_label_zh || lg.pick_label_zh).join(' ＋ ');
      const res = await NBA.apiPost('/api/bets/add', {
        tw_date: opts.tw_date || legs[0].tw_date || '',
        game_id: encodedGid,
        matchup: `🎰 ${titleTag}（${legs.length} 場跨場）`,
        market: 'PARLAY',
        pick_side: isCombo ? `COMBO_${legs.length}x${betsCnt}` : `${legs.length}x1`,
        pick_label: picksSummary,
        line: legs.length,
        odds_decimal: combinedOdds,
        stake: totalStake,
        note: `${bookZh} · ${betsCnt > 1 ? `每注 ${unitStake} × ${betsCnt} 注` : `單注 ${unitStake}`}（完賽自動對獎，走水自動降關）`,
      });
      NBA.bets = res.bets || [];
      NBA.toast(`✅ 已加入「${titleTag}」至注單追蹤！（總本金 NT$ ${totalStake.toLocaleString()}，完賽自動結算）`);
    } catch (e) {
      NBA.toast('⚠️ ' + e.message);
    }
  };

  // AI Single-Game Deep Dive Modal
  NBA.openAiGameDive = async function (gid) {
    const g = (NBA.snap.games || []).find((x) => x.game_id === gid);
    if (!g) return;
    const h = NBA.teamOf(g.home_abbr);
    const a = NBA.teamOf(g.away_abbr);
    NBA.openModal(
      `🤖 AI 單場深度解盤 · ${a.zh} @ ${h.zh}`,
      `<div class="loading-box" style="padding:24px">🧠 正在透過 Jetski 語言伺服器結合即時盤口、傷兵與量化因子撰寫解盤報告（約需 8–18 秒）…</div>`
    );
    try {
      const st = await NBA.apiPost('/api/ai/start', { kind: 'game_deep_dive', game_id: gid });
      const tid = st.task;
      for (let i = 0; i < 55; i++) {
        await new Promise((r) => setTimeout(r, 1200));
        const tk = await NBA.apiGet(`/api/ai/task?id=${encodeURIComponent(tid)}`);
        if (tk.status === 'done' && tk.result) {
          const d = tk.result;
          document.getElementById('appModalBody').innerHTML = `
            <div style="display:flex;flex-direction:column;gap:12px">
              <div class="card" style="background:#f8fbff;border-color:#bfdbfe">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
                  <strong style="font-size:15px;color:#1e40af">📌 ${NBA.esc(d.headline || '單場實戰結論')}</strong>
                  <span class="chip info">${NBA.esc(d.risk_level || '量化評估')}</span>
                </div>
                <div style="font-size:13.5px;color:#1e293b">${NBA.esc(d.summary || '')}</div>
              </div>
              ${d.ats_verdict ? `<div class="card"><strong>🎯 讓分盤 (Spread) 深度分析</strong><p style="margin:6px 0 0;color:#334155">${NBA.esc(d.ats_verdict)}</p></div>` : ''}
              ${d.ou_verdict ? `<div class="card"><strong>↕️ 大小分 (Over/Under) 深度分析</strong><p style="margin:6px 0 0;color:#334155">${NBA.esc(d.ou_verdict)}</p></div>` : ''}
              ${d.gossip_angle ? `<div class="card" style="background:#fdf4ff;border-color:#f0abfc"><strong>🍿 戰舊主／恩怨戲碼與休息室八卦點評</strong><p style="margin:6px 0 0;color:#581c87">${NBA.esc(d.gossip_angle)}</p></div>` : ''}
              ${d.injury_watch ? `<div class="card" style="background:#fffbeb;border-color:#fde68a"><strong>🏥 賽前傷兵與變盤監控重點</strong><p style="margin:6px 0 0;color:#78350f">${NBA.esc(d.injury_watch)}</p></div>` : ''}
            </div>`;
          return;
        }
        if (tk.status === 'error') throw new Error(tk.error || 'AI 解盤失敗');
      }
      throw new Error('AI 回覆逾時，請稍後再試');
    } catch (e) {
      document.getElementById('appModalBody').innerHTML = `<div class="empty-box">⚠️ ${NBA.esc(e.message)}</div>`;
    }
  };

  // --- Release Notes & Smart 1.x.x Publisher Modal (Pattern 164 / 168) ---
  let _publishConfirmArmed = false;
  NBA.openReleaseModal = async function () {
    _publishConfirmArmed = false;
    const bd = document.getElementById('relModal');
    const ttl = document.getElementById('relModalTitle');
    const body = document.getElementById('relModalBody');
    if (ttl) {
      ttl.textContent = NBA.isStatic
        ? '📜 NBA 運彩智庫 · Release Notes'
        : '🚀 NBA 運彩智庫 · 版本紀錄與發布中心';
    }
    bd.classList.remove('hidden');
    body.innerHTML = '<div class="loading-box">讀取版本更新紀錄中…</div>';
    try {
      const st = await NBA.apiGet('/api/release_status');
      renderReleaseModalBody(st);
    } catch (_) {
      const rd = window.NBA_RELEASES || { current_version: '1.0.0', releases: [] };
      renderReleaseModalBody({ static: true, current_version: rd.current_version, has_changes: false, changed_files: [], releases: rd.releases || [] });
    }
  };

  function renderReleaseModalBody(st) {
    const body = document.getElementById('relModalBody');
    const ttl = document.getElementById('relModalTitle');
    const isLocal = !NBA.isStatic && !(st && st.static);
    if (ttl) {
      ttl.textContent = isLocal
        ? '🚀 NBA 運彩智庫 · 版本紀錄與發布中心'
        : '📜 NBA 運彩智庫 · Release Notes';
    }
    const dlHtml = isLocal
      ? `<div class="card" style="background:#f8fafc;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
          <div>
            <strong>📦 GitHub Pages 單一檔案匯出（免安裝靜態版）</strong>
            <div class="sec-sub">將最新盤口快照、賽後紀錄與所有介面打包成單一 <code>index.html</code>，直接拖進 GitHub 即可發布公開網頁。</div>
          </div>
          <a class="btn btn-soft" href="/download/index.html" download="index.html">⬇️ 直接下載最新 index.html</a>
        </div>`
      : '';

    let dirtyHtml = '';
    if (isLocal && st.has_changes) {
      const rec = st.recommended_bump || 'patch';
      const nv = st.next_versions || {};
      dirtyHtml = `
        <div class="card" style="border-color:#fcd34d;background:#fffdf7;margin-bottom:16px">
          <div class="sec-hdr" style="margin-bottom:8px">
            <div>
              <strong style="font-size:15px">🛠️ 偵測到 ${st.changed_files.length} 個未發布檔案變更（+${st.total_added} / -${st.total_removed} 行）</strong>
              <div class="sec-sub">${NBA.esc(st.recommend_reason || '')}</div>
            </div>
            <span class="chip warn">目前 v${NBA.esc(st.current_version)}</span>
          </div>
          <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:10px">
            ${['patch', 'minor', 'major'].map((b) => `
              <label class="card" style="padding:9px 11px;cursor:pointer;background:${rec === b ? '#eff6ff' : '#fff'};border-color:${rec === b ? '#2563eb' : '#cbd5e1'}">
                <input type="radio" name="relBump" value="${b}" ${rec === b ? 'checked' : ''}>
                <strong>v${NBA.esc(nv[b] || '')}</strong>
                <span class="chip ${rec === b ? 'info' : 'muted'}" style="margin-left:4px">${b === 'major' ? '進第1位' : b === 'minor' ? '進第2位' : '進第3位'}</span>
                <div style="font-size:11.5px;color:#475569;margin-top:4px">${NBA.esc((st.bump_descriptions || {})[b] || '')}</div>
              </label>
            `).join('')}
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px">
            <input class="inp" id="relTitleInp" value="${NBA.esc(st.suggested_title || '')}" placeholder="版本標題">
            <textarea class="inp" id="relHlInp" rows="3" placeholder="每行一條更新重點">${NBA.esc((st.suggested_highlights || []).join('\n'))}</textarea>
          </div>
          <details style="margin-bottom:10px;font-size:12px;color:#475569">
            <summary style="cursor:pointer;font-weight:700">查看變更檔案清單（${st.changed_files.length} 個檔案）</summary>
            <ul style="margin:6px 0 0;padding-left:18px">
              ${st.changed_files.map((c) => `<li><code>${NBA.esc(c.path)}</code> (${NBA.esc(c.status)}) <span style="color:#15803d">+${c.added}</span> / <span style="color:#b91c1c">-${c.removed}</span> — ${NBA.esc(c.desc)}</li>`).join('')}
            </ul>
          </details>
          <div style="display:flex;justify-content:flex-end">
            <button type="button" class="btn btn-primary" id="relPublishBtn">🚀 發布新版本並同步重新打包</button>
          </div>
        </div>`;
    } else if (isLocal) {
      dirtyHtml = `<div class="card" style="background:#f0fdf4;border-color:#bbf7d0;margin-bottom:14px;font-size:13px;color:#166534">✅ 目前工作目錄所有程式碼皆與最新發布版 <strong>v${NBA.esc(st.current_version)}</strong> 同步，無待發布修改。</div>`;
    }

    const histHtml = (st.releases || []).map((r) => `
      <div class="card" style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
          <div>
            <span class="chip info">v${NBA.esc(r.version)}</span>
            <strong style="margin-left:6px">${NBA.esc(r.title || '')}</strong>
          </div>
          <span style="font-size:12px;color:#64748b">${NBA.esc(r.date || '')}</span>
        </div>
        <ul style="margin:6px 0 0;padding-left:18px;color:#334155;font-size:13px">
          ${(r.highlights || []).map((h) => `<li style="margin-bottom:3px">${NBA.esc(h)}</li>`).join('')}
        </ul>
      </div>
    `).join('');

    body.innerHTML = dlHtml + dirtyHtml + `<h4 style="margin:8px 0">📜 Release Notes 歷史版本紀錄</h4>` + histHtml;

    const pubBtn = document.getElementById('relPublishBtn');
    if (pubBtn) {
      pubBtn.onclick = async () => {
        const picked = (document.querySelector('input[name="relBump"]:checked') || {}).value || 'patch';
        const targetVer = (st.next_versions || {})[picked] || '';
        if (!_publishConfirmArmed) {
          _publishConfirmArmed = true;
          pubBtn.textContent = `⚠️ 確定發布 v${targetVer}？再按一次確認`;
          return;
        }
        pubBtn.disabled = true;
        pubBtn.textContent = '⏳ 正在寫入版本與打包單一 HTML…';
        try {
          const title = document.getElementById('relTitleInp').value;
          const highlights = document.getElementById('relHlInp').value.split('\n').map((s) => s.trim()).filter(Boolean);
          const nextSt = await NBA.apiPost('/api/release_publish', { bump_type: picked, title, highlights });
          _publishConfirmArmed = false;
          updateHeaderBadges(nextSt.current_version, nextSt.has_changes);
          renderReleaseModalBody(nextSt);
          NBA.toast(`🎉 已發布 v${nextSt.current_version}！`);
        } catch (e) {
          pubBtn.disabled = false;
          _publishConfirmArmed = false;
          NBA.toast('⚠️ ' + e.message);
        }
      };
    }
  }

  function updateHeaderBadges(ver, hasChanges) {
    const vb = document.getElementById('verBadgeBtn');
    if (vb) {
      const showDot = !NBA.isStatic && hasChanges;
      vb.className = 'ver-badge' + (showDot ? ' has-changes' : '');
      vb.title = NBA.isStatic ? `版本 v${ver}（點擊查看 Release Notes）` : '查看版本更新紀錄與發布新版本';
      vb.innerHTML = `v${NBA.esc(ver)}${showDot ? '<span class="ver-dot" title="有尚未發布的修改"></span>' : ''}`;
    }
    const mp = document.getElementById('hdrModelPill');
    if (mp && NBA.snap && NBA.snap.meta) {
      const k = NBA.snap.kpi || {};
      mp.textContent = `Model ${NBA.snap.meta.model_version} · 強推勝率 ${k.strong_win_rate || 0}% (${k.strong_w || 0}W-${k.strong_l || 0}L)`;
    }
  }

  // --- Hydrate & Render Router ---
  function rebuildLookups() {
    NBA.teamMap = {};
    for (const t of (NBA.snap && NBA.snap.teams) || []) {
      NBA.teamMap[t.abbr] = t;
    }
    const meta = (NBA.snap && NBA.snap.meta) || {};
    if (!NBA.state.picksDate) {
      NBA.state.picksDate = meta.default_picks_date || meta.tomorrow_tw || '';
    }
  }

  NBA.render = function () {
    const hash = (window.location.hash || '#/picks').replace(/^#\/?/, '');
    const parts = hash.split('?')[0].split('/').filter(Boolean);
    const route = parts[0] || 'picks';
    const sub = (parts[1] || '').toUpperCase();
    if (route === 'team' && sub && NBA.teamMap[sub]) {
      if (NBA.state.activeTeam !== sub) {
        NBA.state.activeTeam = sub;
        NBA.state.teamGameId = '';
      }
    }
    if (route === 'stats' && parts[1]) {
      const ent = parts[1].toLowerCase();
      if (['players', 'teams', 'leaders'].includes(ent)) {
        NBA.state.statsEntity = ent;
      }
    }
    NBA.route = NBA.pages[route] ? route : 'picks';

    document.querySelectorAll('#mainNav .nav-item').forEach((a) => {
      a.classList.toggle('active', a.getAttribute('data-route') === NBA.route);
    });

    const main = document.getElementById('appMain');
    if (!NBA.snap) {
      main.innerHTML = '<div class="loading-box">載入 NBA 運彩智庫資料中…</div>';
      return;
    }
    const prevScroll = document.documentElement.style.scrollBehavior;
    document.documentElement.style.scrollBehavior = 'auto';
    NBA.pages[NBA.route](main);
    document.documentElement.style.scrollBehavior = prevScroll;
  };

  NBA.refreshAllData = async function () {
    const [snap, betsRes] = await Promise.all([
      NBA.apiGet('/api/snapshot'),
      NBA.apiGet('/api/bets').catch(() => ({ bets: [] })),
    ]);
    NBA.snap = snap;
    NBA.bets = betsRes.bets || [];
    rebuildLookups();
    updateHeaderBadges(NBA.health.version || '1.0.0', Boolean(NBA.relHasChanges));
    NBA.render();
  };

  NBA.openDisclaimerModal = function () {
    NBA.openModal(
      '⚖️ 法律與運動彩券風險免責聲明（Disclaimer）',
      `
        <div style="display:flex;flex-direction:column;gap:12px;font-size:13.5px;line-height:1.7;color:#1e293b">
          <div class="card" style="background:#fffbeb;border-color:#fcd34d;color:#78350f;padding:12px 15px">
            <strong>⚠️ 核心免責原則：</strong>使用本網站（NBA 運彩智庫）即表示您已詳閱並完全同意本聲明。<strong>任何參考本站數據或模型分析所進行之投注行為與資金配置，其一切盈虧結果、本金損失與風險均由使用者自行判斷並完全自負，概與本站及開發者無關。</strong>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">1. 純數據統計與學術研究性質（非投注建議或勸誘）</div>
            <div>本站所有 NBA 讓分／大小分盤口整理、量化因子模型分數、期望值（EV）試算、AI 解盤文字與歷史過盤統計，均由電腦程式依據公開體育數據自動運算產生，純供個人籃球數據研究與觀賽娛樂參考，<strong>絕不構成任何形式之投注建議、明牌報牌、招攬、勸誘或穩贏／獲利保證</strong>。</div>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">2. 比賽高度隨機性與資料延遲誤差免責</div>
            <div>職業運動賽事受球員臨場傷退、教練團輪休調度、裁判吹判尺度、延長賽與單場投籃手感變異影響極大，過去之模型回測命中率絕不代表未來表現；且公開 API 之盤口、比分與傷兵報告可能存在時間延遲、缺漏或與台灣運彩實際開盤數值不同，本站不對任何資訊之即時性、完整性或正確性作任何擔保。</div>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">3. 損益完全自負與無損害賠償責任</div>
            <div>使用者應獨立思考並自行查證官方盤口資訊。<strong>不論獲利或虧損（包含但不限於投注失利、本金虧損、盤口變動誤差或系統異常），一切財務風險與後果皆由使用者個人完全承擔，本站及開發者概不負責，亦不負任何直接、間接或連帶損害賠償責任。</strong></div>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">4. 遵守所在地法令與理性參與</div>
            <div>請務必遵守您所在地之法律規範（於中華民國境內請僅透過合法授權之「台灣運彩」管道參與，未滿 18 歲不得購買或兌領彩券），並嚴格衡量自身財務能力、量力而為，切勿借貸或過度沉迷。</div>
          </div>
        </div>
      `,
      'modal-lg'
    );
  };

  async function boot() {
    document.getElementById('appModalClose').onclick = NBA.closeModal;
    document.getElementById('appModalBd').onclick = (e) => { if (e.target.id === 'appModalBd') NBA.closeModal(); };
    document.getElementById('relModalClose').onclick = () => document.getElementById('relModal').classList.add('hidden');
    document.getElementById('relModal').onclick = (e) => { if (e.target.id === 'relModal') e.target.classList.add('hidden'); };
    document.getElementById('verBadgeBtn').onclick = NBA.openReleaseModal;
    const discBtn = document.getElementById('disclaimerBtn');
    if (discBtn) discBtn.onclick = NBA.openDisclaimerModal;

    const syncBtn = document.getElementById('syncNowBtn');
    NBA.syncStaticLiveEspn = async function (opts) {
      if (!NBA.snap || !Array.isArray(NBA.snap.games)) return { updated: 0 };
      const now = new Date();
      const twNow = new Date(now.getTime() + 8 * 3600 * 1000);
      const pad = (n) => String(n).padStart(2, '0');
      const fmtIso = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
      const fmtCompact = (d) => `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}`;
      const etNow = new Date(now.getTime() - 4 * 3600 * 1000);
      const dates = [-2, -1, 0, 1].map((off) => fmtCompact(new Date(etNow.getTime() + off * 86400000)));
      const byId = {};
      for (const g of NBA.snap.games) byId[String(g.game_id)] = g;

      let touched = 0;
      const responses = await Promise.all(
        dates.map((ds) =>
          fetch(`https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard?dates=${ds}`, { cache: 'no-store' })
            .then((r) => (r.ok ? r.json() : null))
            .catch(() => null)
        )
      );
      if (!responses.some(Boolean)) {
        throw new Error('無法連線至 ESPN 即時比分伺服器');
      }
      for (const payload of responses) {
        for (const ev of (payload && payload.events) || []) {
          const g = byId[String(ev.id || '')];
          if (!g) continue;
          const comp = (ev.competitions && ev.competitions[0]) || {};
          const stType = (comp.status && comp.status.type) || {};
          const state = String(stType.state || '');
          const newStatus = stType.completed || state === 'post' ? 'FINAL' : state === 'in' ? 'LIVE' : 'SCHEDULED';
          let homeC = null;
          let awayC = null;
          for (const c of comp.competitors || []) {
            if (c.homeAway === 'home') homeC = c;
            else if (c.homeAway === 'away') awayC = c;
          }
          if (!homeC || !awayC) continue;
          const hs = newStatus === 'SCHEDULED' ? null : (homeC.score != null ? parseInt(homeC.score, 10) : g.home_score);
          const as = newStatus === 'SCHEDULED' ? null : (awayC.score != null ? parseInt(awayC.score, 10) : g.away_score);
          const prevSig = `${g.status}:${g.away_score}-${g.home_score}:${g.close_spread_home}`;

          g.status = newStatus;
          if (stType.shortDetail || stType.detail) g.status_detail = stType.shortDetail || stType.detail;
          if (hs != null && !Number.isNaN(hs)) g.home_score = hs;
          if (as != null && !Number.isNaN(as)) g.away_score = as;
          if (Array.isArray(homeC.linescores) && homeC.linescores.length) {
            g.home_q_scores = homeC.linescores.map((x) => Number(x.value || 0));
          }
          if (Array.isArray(awayC.linescores) && awayC.linescores.length) {
            g.away_q_scores = awayC.linescores.map((x) => Number(x.value || 0));
          }
          const hRec = (homeC.records && homeC.records[0] && homeC.records[0].summary) || '';
          const aRec = (awayC.records && awayC.records[0] && awayC.records[0].summary) || '';
          if (hRec) g.home_record = hRec;
          if (aRec) g.away_record = aRec;

          // Fill missing pregame odds on SCHEDULED games if ESPN provides DraftKings lines
          const odd = (comp.odds && comp.odds[0]) || null;
          if (newStatus === 'SCHEDULED' && odd) {
            if (g.close_spread_home == null && odd.spread != null && !Number.isNaN(Number(odd.spread))) {
              g.close_spread_home = Number(odd.spread);
              if (g.open_spread_home == null) g.open_spread_home = g.close_spread_home;
            }
            if (g.close_total == null && odd.overUnder != null && !Number.isNaN(Number(odd.overUnder))) {
              g.close_total = Number(odd.overUnder);
              if (g.open_total == null) g.open_total = g.close_total;
            }
          }

          if (newStatus === 'FINAL' && g.home_score != null && g.away_score != null) {
            g.margin_home = g.home_score - g.away_score;
            g.total_points = g.home_score + g.away_score;
            if (g.close_spread_home != null) {
              const cov = +(g.margin_home + Number(g.close_spread_home)).toFixed(1);
              g.ats_cover_margin = cov;
              g.ats_winner = cov > 0 ? 'HOME' : cov < 0 ? 'AWAY' : 'PUSH';
            }
            if (g.close_total != null) {
              const oum = +(g.total_points - Number(g.close_total)).toFixed(1);
              g.ou_margin = oum;
              g.ou_result = oum > 0 ? 'OVER' : oum < 0 ? 'UNDER' : 'PUSH';
            }
            if (g.pred) {
              if (g.pred.ats_pick && g.pred.ats_pick !== 'PASS' && g.ats_winner) {
                g.pred.ats_result = g.ats_winner === 'PUSH' ? 'PUSH' : g.pred.ats_pick === g.ats_winner ? 'WIN' : 'LOSS';
              } else if (g.pred.ats_pick === 'PASS') {
                g.pred.ats_result = 'PASS';
              }
              if (g.pred.ou_pick && g.pred.ou_pick !== 'PASS' && g.ou_result) {
                g.pred.ou_result = g.ou_result === 'PUSH' ? 'PUSH' : g.pred.ou_pick === g.ou_result ? 'WIN' : 'LOSS';
              } else if (g.pred.ou_pick === 'PASS') {
                g.pred.ou_result = 'PASS';
              }
            }
          }
          const nextSig = `${g.status}:${g.away_score}-${g.home_score}:${g.close_spread_home}`;
          if (prevSig !== nextSig) touched++;
        }
      }

      const todayTw = fmtIso(twNow);
      const tomorrowTw = fmtIso(new Date(twNow.getTime() + 86400000));
      const nowStamp = `${todayTw} ${pad(twNow.getUTCHours())}:${pad(twNow.getUTCMinutes())} (ESPN 即時同步)`;
      if (NBA.snap.meta) {
        const oldDef = NBA.snap.meta.default_picks_date;
        NBA.snap.meta.today_tw = todayTw;
        NBA.snap.meta.tomorrow_tw = tomorrowTw;
        NBA.snap.meta.generated_at_tw = nowStamp;
        const upcomingDates = [...new Set(
          NBA.snap.games.filter((g) => g.status !== 'FINAL' && g.tw_date >= todayTw).map((g) => g.tw_date)
        )].sort();
        if (upcomingDates.length) {
          NBA.snap.meta.default_picks_date = upcomingDates[0];
          if (!opts || !opts.keepDate) {
            if (!NBA.state.picksDate || NBA.state.picksDate === oldDef) {
              const oldHasLive = NBA.snap.games.some((g) => g.tw_date === NBA.state.picksDate && g.status !== 'FINAL');
              if (!oldHasLive) NBA.state.picksDate = upcomingDates[0];
            }
          }
        }
      }
      await NBA.refreshAllData();
      return { updated: touched, stamp: nowStamp };
    };

    if (NBA.isStatic) {
      syncBtn.style.display = '';
      syncBtn.textContent = '↻ 即時同步比分';
      syncBtn.onclick = async () => {
        syncBtn.disabled = true;
        syncBtn.textContent = '⏳ 連線 ESPN 同步中…';
        try {
          const r = await NBA.syncStaticLiveEspn({ keepDate: true });
          NBA.toast(`✅ 已即時同步 ESPN 最新 NBA 比分、盤口與注單對獎！（更新 ${r.updated} 場狀態）`);
        } catch (e) {
          NBA.toast('⚠️ 即時同步失敗：' + e.message);
        } finally {
          syncBtn.disabled = false;
          syncBtn.textContent = '↻ 即時同步比分';
        }
      };
    } else {
      syncBtn.onclick = async () => {
        syncBtn.disabled = true;
        syncBtn.textContent = '⏳ 同步對獎中…';
        try {
          await NBA.apiPost('/api/sync', { full: false });
          for (let i = 0; i < 45; i++) {
            await new Promise((r) => setTimeout(r, 1400));
            const st = await NBA.apiGet('/api/sync_status');
            if (!st.running) break;
          }
          await NBA.refreshAllData();
          NBA.toast('✅ 已同步最新比分、傷兵與賽後對獎！（讓分與大小分維持每日 23:00 鎖定盤）');
        } catch (e) {
          NBA.toast('⚠️ ' + e.message);
        } finally {
          syncBtn.disabled = false;
          syncBtn.textContent = '↻ 更新比分與對獎';
        }
      };
    }

    window.addEventListener('hashchange', () => requestAnimationFrame(NBA.render));

    // Global delegated clicks for any Team Link, Player Profile, Single-Game Boxscore, or Disclaimer Modal
    document.addEventListener('click', (ev) => {
      const discTrigger = ev.target.closest('[data-open-disclaimer]');
      if (discTrigger) {
        ev.preventDefault();
        NBA.openDisclaimerModal();
        return;
      }
      const boxBtn = ev.target.closest('[data-boxscore-gid]');
      if (boxBtn) {
        ev.preventDefault();
        ev.stopPropagation();
        NBA.openGameBoxscoreModal(boxBtn.getAttribute('data-boxscore-gid'));
        return;
      }
      const plEl = ev.target.closest('[data-player-id]');
      if (plEl) {
        ev.preventDefault();
        ev.stopPropagation();
        NBA.openPlayerModal(plEl.getAttribute('data-player-id'));
        return;
      }
      const tmEl = ev.target.closest('[data-team-link]');
      if (tmEl) {
        ev.preventDefault();
        ev.stopPropagation();
        const ab = (tmEl.getAttribute('data-team-link') || '').toUpperCase();
        if (ab) {
          NBA.closeModal();
          NBA.state.activeTeam = ab;
          NBA.state.teamGameId = '';
          if (window.location.hash === `#/team/${ab}`) {
            NBA.render();
          } else {
            window.location.hash = `#/team/${ab}`;
          }
        }
      }
    });

    try {
      if (!NBA.isStatic) {
        const [h, relSt] = await Promise.all([
          NBA.apiGet('/api/health').catch(() => ({ version: '1.0.0', ai: false })),
          NBA.apiGet('/api/release_status').catch(() => ({ current_version: '1.0.0', has_changes: false })),
        ]);
        NBA.health = h;
        NBA.relHasChanges = Boolean(relSt.has_changes);
        NBA.health.version = relSt.current_version || h.version || '1.0.0';
      } else if (window.NBA_RELEASES) {
        NBA.health.version = window.NBA_RELEASES.current_version || '1.0.0';
      }
      await NBA.refreshAllData();
      if (NBA.isStatic) {
        NBA.syncStaticLiveEspn().catch(() => {});
        setInterval(() => { if (!document.hidden) NBA.syncStaticLiveEspn({ keepDate: true }).catch(() => {}); }, 90000);
      }
      if (window.location.search.includes('releases=1')) NBA.openReleaseModal();
    } catch (e) {
      document.getElementById('appMain').innerHTML = `<div class="empty-box">⚠️ 資料載入失敗：${NBA.esc(e.message)}</div>`;
    }
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
