/* Page 1: 🎯 隔日／今日運彩盤口分析與下注建議 (#/picks) */
(function () {
  'use strict';
  const NBA = window.NBA;

  function dateRoleLabel(twDate, meta) {
    if (twDate === meta.today_tw) return '今日賽程';
    if (twDate === meta.tomorrow_tw) return '明日賭盤';
    const d1 = new Date(meta.today_tw + 'T00:00:00');
    const d2 = new Date(twDate + 'T00:00:00');
    const diff = Math.round((d2 - d1) / 86400000);
    if (diff === 2) return '後天預告';
    if (diff === -1) return '昨日完賽';
    return diff > 0 ? `+${diff}天` : `${diff}天`;
  }

  function renderSpreadMove(openSp, closeSp, homeZh, awayZh, lockStr) {
    if (closeSp == null) return '<span class="odds-sub">⏳ 每日 18:00 抓初盤首析 · 23:00 抓尾盤二析</span>';
    const isEarly = String(lockStr || '').includes('初盤') || String(lockStr || '').includes('18:00');
    const curFav = closeSp < 0 ? `${homeZh} 主讓 ${Math.abs(closeSp).toFixed(1)}` : closeSp > 0 ? `${awayZh} 客讓 ${Math.abs(closeSp).toFixed(1)}` : 'PK 平手盤';
    if (openSp == null || Number(openSp) === Number(closeSp)) {
      return `<div class="odds-sub">${NBA.esc(curFav)}（${isEarly ? '18:00 初盤基準，23:00 再比對變盤' : `18:00 初盤 ${NBA.fmtSpread(openSp)} → 23:00 持平`}）</div>`;
    }
    const deltaTowardHome = Number(openSp) - Number(closeSp);
    const dirTxt = deltaTowardHome > 0
      ? `▲ 資金往${homeZh}推升 ${Math.abs(deltaTowardHome).toFixed(1)} 分`
      : `▼ 資金往${awayZh}傾斜 ${Math.abs(deltaTowardHome).toFixed(1)} 分`;
    const cls = deltaTowardHome > 0 ? 'move-up' : 'move-dn';
    return `<div class="odds-sub">18:00 初盤 ${NBA.fmtSpread(openSp)} → ${isEarly ? '目前盤' : '23:00 定盤'} ${NBA.fmtSpread(closeSp)} <span class="${cls}">(${NBA.esc(dirTxt)})</span></div>`;
  }

  function renderTotalMove(openTot, closeTot, lockStr) {
    if (!closeTot) return '<span class="odds-sub">⏳ 每日 18:00 抓初盤首析 · 23:00 抓尾盤二析</span>';
    const isEarly = String(lockStr || '').includes('初盤') || String(lockStr || '').includes('18:00');
    if (!openTot || Number(openTot) === Number(closeTot)) {
      return `<div class="odds-sub">${isEarly ? `18:00 初盤 ${closeTot} 分（23:00 再檢視變盤）` : `18:00 初盤 ${closeTot} → 23:00 持平`}</div>`;
    }
    const diff = +(Number(closeTot) - Number(openTot)).toFixed(1);
    const cls = diff > 0 ? 'move-up' : 'move-dn';
    return `<div class="odds-sub">18:00 初盤 ${openTot} → ${isEarly ? '目前盤' : '23:00 定盤'} ${closeTot} <span class="${cls}">(${diff > 0 ? '▲ 調高 +' + diff : '▼ 下修 ' + diff} 分)</span></div>`;
  }

  function tierBadge(tier) {
    if (tier === 'STRONG') return '<span class="chip strong">🔥 強推精選</span>';
    if (tier === 'LEAN') return '<span class="chip info">✅ 順勢推薦</span>';
    return '<span class="chip muted">⚖️ 觀望不碰</span>';
  }

  function resultBadge(res) {
    if (res === 'WIN') return '<span class="chip ok">✅ 命中過盤</span>';
    if (res === 'LOSS') return '<span class="chip bad">❌ 未過盤</span>';
    if (res === 'PUSH') return '<span class="chip warn">➖ 走水退本</span>';
    return '';
  }

  function renderGameCard(g) {
    const h = NBA.teamOf(g.home_abbr);
    const a = NBA.teamOf(g.away_abbr);
    const p = g.pred || {};
    const fac = p.factors || {};
    const hRest = (fac.home_rest && fac.home_rest.label) || '';
    const aRest = (fac.away_rest && fac.away_rest.label) || '';

    const hasStrong = p.ats_tier === 'STRONG' || p.ou_tier === 'STRONG';
    const spHome = g.close_spread_home;
    const spAway = spHome != null ? -Number(spHome) : null;

    // ATS Target Display
    let atsTargetTxt = '等待莊家開盤';
    if (spHome != null) {
      const pickSide = p.ats_pick !== 'PASS' ? p.ats_pick : p.ats_lean_side || 'HOME';
      const pickTeam = pickSide === 'HOME' ? h : a;
      const pickLine = pickSide === 'HOME' ? spHome : spAway;
      const roleWord = pickLine < 0 ? '讓分' : pickLine > 0 ? '受讓' : 'PK';
      atsTargetTxt = p.ats_pick !== 'PASS'
        ? `${pickTeam.zh} ${NBA.fmtSpread(pickLine)}（${roleWord}）`
        : `建議觀望 · 微偏${pickTeam.zh} ${NBA.fmtSpread(pickLine)}`;
    }

    // O/U Target Display
    let ouTargetTxt = '等待莊家開盤';
    if (g.close_total) {
      const ouSide = p.ou_pick !== 'PASS' ? p.ou_pick : p.ou_lean_side || 'OVER';
      const ouWord = ouSide === 'OVER' ? '大分 (OVER)' : '小分 (UNDER)';
      ouTargetTxt = p.ou_pick !== 'PASS'
        ? `${ouWord} ${g.close_total}`
        : `建議觀望 · 微偏${ouSide === 'OVER' ? '大分' : '小分'} ${g.close_total}`;
    }

    // Combine top injuries for both teams
    const allInj = [
      ...(g.away_injuries || []).map((x) => ({ ...x, sideZh: a.zh })),
      ...(g.home_injuries || []).map((x) => ({ ...x, sideZh: h.zh })),
    ].filter((x) => x.impact_tier !== 'ROTATION' || x.play_prob_next <= 55).slice(0, 6);

    const injHtml = allInj.length
      ? `<div class="inj-strip">
          <strong style="color:#475569;font-size:11.5px">🏥 傷兵與明日出賽：</strong>
          ${allInj.map((it) => {
            const cls = it.play_prob_next === 0 ? '' : it.play_prob_next <= 60 ? 'gtd' : 'prob';
            return `<span class="inj-pill ${cls}" title="${NBA.esc(it.short_comment || it.status_zh)}">
              ${NBA.esc(it.sideZh)}·${NBA.esc(it.player_name)} (${it.play_prob_next}% 上場)
            </span>`;
          }).join('')}
        </div>`
      : `<div class="inj-strip" style="color:#16a34a;font-size:12px">✅ 雙方核心主將目前皆無重大傷兵報告</div>`;

    // Projected Starters Drawer
    let lineupHtml = '';
    if (g.lineup && ((g.lineup.away_starters || []).length || (g.lineup.home_starters || []).length)) {
      const lu = g.lineup;
      lineupHtml = `
        <details style="font-size:12px;color:#475569">
          <summary style="cursor:pointer;font-weight:700;color:#2563eb">📋 查看雙方預計先發五人名單 ${lu.away_confirmed || lu.home_confirmed ? '（已確認先發）' : '（RotoWire 預測）'}</summary>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr));gap:10px;margin-top:8px;background:#f8fafc;padding:9px 11px;border-radius:8px;border:1px solid #e2e8f0">
            <div>
              <strong>${NBA.esc(a.zh)} 先發：</strong>
              <div style="margin-top:4px">${(lu.away_starters || []).map((s) => `${NBA.esc(s.pos)} ${NBA.esc(s.player)}${s.tag ? ` <span class="chip warn">${NBA.esc(s.tag)}</span>` : ''}`).join(' · ')}</div>
            </div>
            <div>
              <strong>${NBA.esc(h.zh)} 先發：</strong>
              <div style="margin-top:4px">${(lu.home_starters || []).map((s) => `${NBA.esc(s.pos)} ${NBA.esc(s.player)}${s.tag ? ` <span class="chip warn">${NBA.esc(s.tag)}</span>` : ''}`).join(' · ')}</div>
            </div>
          </div>
        </details>`;
    }

    // Factor Breakdown Drawer
    const atsContribs = Object.entries((fac.ats_contribs || {})).filter(([, v]) => Math.abs(v) >= 0.05);
    const ouContribs = Object.entries((fac.ou_contribs || {})).filter(([, v]) => Math.abs(v) >= 0.05);
    const facLabels = {
      line_steam: '初盤→即時變盤聰明錢',
      form_ats: '近5場過盤與淨勝動能',
      bounce_reversion: '慘敗反彈／大勝過熱修正',
      net_eff_resid: '淨效率＋主場優勢殘差',
      inflate_fade: '雙位數深盤受讓保護',
      bpi_gap: 'ESPN BPI 合理盤差',
      injury_edge: '傷兵與 GTD 未定價差',
      revenge_drama: '球星戰舊主／恩怨戰意',
      ou_regression: '極端大小分均值回歸',
      b2b_def_leak: '背靠背防守疲勞大分效應',
      pace_eff_gap: '攻守節奏總分殘差',
      spread_script: '比賽劇本(拉鋸犯規/垃圾時間)',
      total_steam: '大小分變盤資金方向',
      injury_total: '核心得分手缺陣修正',
      drama_tempo: '戰舊主飆分／宿敵節奏',
    };

    const stObj = g.storylines || {};
    const dramaItems = stObj.items || [];
    const dramaHtml = dramaItems.length
      ? `<div class="drama-box">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;flex-wrap:wrap">
            <strong style="font-size:12.5px;color:#86198f">🍿 場外話題戲碼 ＆ 戰舊主／宿敵八卦看點（已納入戰意因子評估）</strong>
            ${Math.abs(Number(stObj.ats_raw_home || 0)) >= 0.05 || Math.abs(Number(stObj.ou_raw_over || 0)) >= 0.05
              ? `<span style="font-size:11px;font-weight:700;color:#9333ea">量化戰意訊號：${Math.abs(Number(stObj.ats_raw_home || 0)) >= 0.05 ? `${Number(stObj.ats_raw_home) > 0 ? h.zh : a.zh} +${Math.abs(Number(stObj.ats_raw_home)).toFixed(2)}` : ''}${Math.abs(Number(stObj.ou_raw_over || 0)) >= 0.05 ? ` · 總分節奏 ${NBA.fmtSigned(stObj.ou_raw_over, 2)}` : ''}</span>`
              : ''}
          </div>
          ${dramaItems.map((di) => `
            <div class="drama-item">
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                <span class="drama-badge">${NBA.esc(di.badge_zh)}</span>
                <strong style="color:#0f172a;font-size:13px">${NBA.esc(di.title_zh)}</strong>
                ${di.stat_recap_zh ? `<span class="chip ok" style="font-size:11px">📊 ${NBA.esc(di.stat_recap_zh)}</span>` : ''}
              </div>
              <div>${NBA.esc(di.body_zh)}</div>
              ${di.betting_take_zh ? `<div class="drama-take">🎯 <strong>運彩視角：</strong>${NBA.esc(di.betting_take_zh)}</div>` : ''}
            </div>
          `).join('')}
        </div>`
      : '';

    const stChip = g.status === 'FINAL'
      ? `<span class="chip muted">已完賽 Final</span>`
      : (g.status === 'IN_PROGRESS' || g.status === 'LIVE')
      ? `<span class="chip bad">🔴 比賽進行中 · ${NBA.esc(g.status_detail || '')}</span>`
      : `<span class="chip info">🕒 台灣 ${NBA.esc(String(g.tipoff_tw || '').slice(5))} 開打</span>`;

    const lockStr = String(g.odds_locked_tw || '');
    const isEarlyStage = lockStr.includes('初盤') || lockStr.includes('18:00');
    const lm = fac.line_move || {};
    const lockBadge = lockStr
      ? `<span class="chip ${isEarlyStage ? 'warn' : 'info'}" title="每日 18:00 先抓初盤做第一輪分析，23:00 再抓尾盤比對 5 小時盤勢變化做第二輪分析並鎖定對獎">${isEarlyStage ? '🕕' : '🕚'} ${NBA.esc(lockStr)}</span>`
      : spHome != null
      ? `<span class="chip info" title="每日 18:00 初盤首析 → 23:00 尾盤變盤二析">🕕 二階段抓盤（18:00 初盤／23:00 定盤）</span>`
      : `<span class="chip warn" title="將於每日 18:00 先抓初盤首析，23:00 再抓尾盤依變盤重析">⏳ 等待 18:00 初盤／23:00 定盤</span>`;

    return `
      <article class="game-card ${hasStrong ? 'has-strong' : ''}">
        <div class="gc-top">
          <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            ${stChip}
            <span>美東 ${NBA.esc(g.et_date.slice(5))} · 盤口來源：${NBA.esc(g.odds_provider || 'DraftKings')}</span>
            ${lockBadge}
          </div>
          <span style="font-weight:700;color:#475569">${NBA.esc(p.model_version || '')}</span>
        </div>

        <div class="gc-teams">
          <div class="tm-side away tm-link" data-team-link="${NBA.esc(a.abbr)}" title="點擊查看 ${NBA.esc(a.zh)} 過往各場比數與每位球員逐場數據">
            <img class="tm-logo" src="${NBA.esc(a.logo)}" alt="${NBA.esc(a.zh)}" loading="lazy">
            <div style="min-width:0">
              <div class="tm-name">${NBA.esc(a.zh)} <span style="font-weight:600;font-size:12px;color:#64748b">${NBA.esc(a.abbr)} ›</span></div>
              <div class="tm-meta">
                <span>戰績 ${NBA.esc(g.away_record || a.record)} (客 ${NBA.esc(a.road_record || '-')})</span>
                <span>過盤 ${a.ats_w || 0}-${a.ats_l || 0}</span>
                ${aRest ? `<span class="chip ${aRest.includes('⚠️') ? 'warn' : 'muted'}">${NBA.esc(aRest)}</span>` : ''}
              </div>
            </div>
          </div>

          <div class="vs-center">
            ${g.status !== 'SCHEDULED' && g.away_score != null
              ? `<div class="score-big">${g.away_score} : ${g.home_score}</div>`
              : `<div class="vs-tag">客 @ 主</div>`}
          </div>

          <div class="tm-side home tm-link" data-team-link="${NBA.esc(h.abbr)}" title="點擊查看 ${NBA.esc(h.zh)} 過往各場比數與每位球員逐場數據">
            <img class="tm-logo" src="${NBA.esc(h.logo)}" alt="${NBA.esc(h.zh)}" loading="lazy">
            <div style="min-width:0">
              <div class="tm-name"><span style="font-weight:600;font-size:12px;color:#64748b">‹ ${NBA.esc(h.abbr)}</span> ${NBA.esc(h.zh)}</div>
              <div class="tm-meta">
                ${hRest ? `<span class="chip ${hRest.includes('⚠️') ? 'warn' : 'muted'}">${NBA.esc(hRest)}</span>` : ''}
                <span>過盤 ${h.ats_w || 0}-${h.ats_l || 0}</span>
                <span>戰績 ${NBA.esc(g.home_record || h.record)} (主 ${NBA.esc(h.home_record || '-')})</span>
              </div>
            </div>
          </div>
        </div>

        <div class="odds-strip">
          <div class="odds-col">
            <div class="odds-lbl">讓分盤（Spread）· ${isEarlyStage ? '18:00 初盤首析' : '18:00 初盤 → 23:00 定盤'}</div>
            <div class="odds-main">${spHome != null ? `主 ${NBA.esc(h.zh)} ${NBA.fmtSpread(spHome)} / 客 ${NBA.fmtSpread(spAway)}` : '等待 18:00 初盤擷取'}</div>
            ${renderSpreadMove(g.open_spread_home, spHome, h.zh, a.zh, lockStr)}
          </div>
          <div class="odds-col">
            <div class="odds-lbl">大小分（Over/Under）· ${isEarlyStage ? '18:00 初盤首析' : '18:00 初盤 → 23:00 定盤'}</div>
            <div class="odds-main">${g.close_total ? `${g.close_total} 分` : '等待 18:00 初盤擷取'} ${g.over_odds ? `<span style="font-size:11.5px;font-weight:600;color:#64748b">(大${NBA.fmtOdds(g.over_odds)}/小${NBA.fmtOdds(g.under_odds)})</span>` : ''}</div>
            ${renderTotalMove(g.open_total, g.close_total, lockStr)}
          </div>
          <div class="odds-col">
            <div class="odds-lbl">獨贏賠率 ＆ BPI 勝率</div>
            <div class="odds-main">${g.home_ml != null ? `客 ${NBA.fmtOdds(g.away_ml)} / 主 ${NBA.fmtOdds(g.home_ml)}` : '待更新'}</div>
            <div class="odds-sub">${g.bpi_home_win_pct != null ? `ESPN BPI：主勝 ${g.bpi_home_win_pct}% · 客勝 ${(100 - g.bpi_home_win_pct).toFixed(1)}%` : `模型預估比分：${fac.away_proj_ppg || '-'} : ${fac.home_proj_ppg || '-'}`}</div>
          </div>
        </div>

        ${lm.reanalysis_zh ? `<div style="margin:6px 0 8px;padding:8px 11px;border-radius:8px;background:${Math.abs(Number(lm.spread_delta_home || 0)) >= 0.5 || Math.abs(Number(lm.total_delta || 0)) >= 0.5 ? '#eff6ff' : '#f8fafc'};border:1px solid ${Math.abs(Number(lm.spread_delta_home || 0)) >= 0.5 || Math.abs(Number(lm.total_delta || 0)) >= 0.5 ? '#bfdbfe' : '#e2e8f0'};font-size:12px;color:#1e3a8a;line-height:1.55">${NBA.esc(lm.reanalysis_zh)}</div>` : ''}

        <div class="pick-box">
          <div class="pick-cell tier-${p.ats_tier}">
            <div class="pick-hdr">
              <span>🎯 讓分盤建議</span>
              <div style="display:flex;gap:4px">${tierBadge(p.ats_tier)}${g.status === 'FINAL' ? resultBadge(p.ats_result) : ''}</div>
            </div>
            <div class="pick-target">${NBA.esc(atsTargetTxt)}</div>
            <div class="pick-edge">
              模型合理盤：主 ${NBA.fmtSpread(p.fair_spread_home)} · 優勢 Edge：<strong>+${Number(p.ats_edge || 0).toFixed(2)} 分</strong>
              ${p.rec_units_ats > 0 ? ` · 建議注碼 <strong>${p.rec_units_ats}u</strong> (信心 ${p.ats_conf}%)` : ''}
            </div>
          </div>

          <div class="pick-cell tier-${p.ou_tier}">
            <div class="pick-hdr">
              <span>↕️ 大小分建議</span>
              <div style="display:flex;gap:4px">${tierBadge(p.ou_tier)}${g.status === 'FINAL' ? resultBadge(p.ou_result) : ''}</div>
            </div>
            <div class="pick-target">${NBA.esc(ouTargetTxt)}</div>
            <div class="pick-edge">
              模型預估總分：<strong>${p.pred_total != null ? Number(p.pred_total).toFixed(1) : '—'} 分</strong> · 優勢 Edge：<strong>+${Number(p.ou_edge || 0).toFixed(2)} 分</strong>
              ${p.rec_units_ou > 0 ? ` · 建議注碼 <strong>${p.rec_units_ou}u</strong> (信心 ${p.ou_conf}%)` : ''}
            </div>
          </div>
        </div>

        <div class="rationale-bar">
          <strong>💡 關鍵解盤依據：</strong>${NBA.esc(p.rationale_zh || '')}
          ${(p.guardrails || []).length ? `<div style="margin-top:4px;color:#b45309;font-size:11.5px">🛡️ 防呆護欄啟動：${NBA.esc(p.guardrails.join('；'))}</div>` : ''}
        </div>

        ${dramaHtml}
        ${injHtml}
        ${lineupHtml}

        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;padding-top:4px;border-top:1px solid #f1f5f9">
          <details style="flex:1;min-width:220px;font-size:12px">
            <summary style="cursor:pointer;font-weight:700;color:#475569">📊 展開量化模型因子分數拆解</summary>
            <div class="fac-list">
              ${atsContribs.map(([k, v]) => `
                <div class="fac-row">
                  <span>[讓分] ${NBA.esc(facLabels[k] || k)}</span>
                  <div class="fac-bar-track"><div class="fac-bar-fill" style="width:${Math.min(100, Math.abs(v) * 42)}%;background:${v >= 0 ? '#2563eb' : '#ea580c'}"></div></div>
                  <span class="num" style="font-weight:700;color:${v >= 0 ? '#1d4ed8' : '#c2410c'}">${v >= 0 ? '主' : '客'} ${NBA.fmtSigned(v, 2)}</span>
                </div>`).join('')}
              ${ouContribs.map(([k, v]) => `
                <div class="fac-row">
                  <span>[大小] ${NBA.esc(facLabels[k] || k)}</span>
                  <div class="fac-bar-track"><div class="fac-bar-fill" style="width:${Math.min(100, Math.abs(v) * 38)}%;background:${v >= 0 ? '#dc2626' : '#0284c7'}"></div></div>
                  <span class="num" style="font-weight:700;color:${v >= 0 ? '#b91c1c' : '#0369a1'}">${v >= 0 ? '大' : '小'} ${NBA.fmtSigned(v, 2)}</span>
                </div>`).join('')}
            </div>
          </details>

          <div style="display:flex;gap:6px;flex-wrap:wrap">
            ${g.status === 'FINAL' ? `<button type="button" class="btn btn-soft btn-sm" data-boxscore-gid="${NBA.esc(g.game_id)}">📊 單場球員數據</button>` : ''}
            <button type="button" class="btn btn-sm" onclick="NBA.openQuickBetModal('${NBA.esc(g.game_id)}','ATS')">➕ 記讓分單</button>
            <button type="button" class="btn btn-sm" onclick="NBA.openQuickBetModal('${NBA.esc(g.game_id)}','OU')">➕ 記大小單</button>
            ${!NBA.isStatic && NBA.health.ai ? `<button type="button" class="btn btn-soft btn-sm" onclick="NBA.openAiGameDive('${NBA.esc(g.game_id)}')">🤖 AI 深度解盤</button>` : ''}
          </div>
        </div>
      </article>`;
  }

  NBA.pages.picks = function (root) {
    const snap = NBA.snap;
    const meta = snap.meta || {};
    const dates = snap.dates || [];
    const activeDate = NBA.state.picksDate || meta.default_picks_date;

    // Pick recent + upcoming dates for quick pills (last 2 finished + all upcoming)
    const quickDates = dates.slice(-6);
    const dayGames = (snap.games || []).filter((g) => g.tw_date === activeDate);
    const dayParlay = ((snap.daily_parlays || {}).by_date || {})[activeDate] || null;
    const anchor2x1 = dayParlay && (dayParlay.packages || []).find((x) => x.key === 'anchor_2x1');
    const boost3x1 = dayParlay && (dayParlay.packages || []).find((x) => x.key === 'boost_3x1');

    const strongCnt = dayGames.filter((g) => g.pred.ats_tier === 'STRONG' || g.pred.ou_tier === 'STRONG').length;
    const atsRecCnt = dayGames.filter((g) => g.pred.ats_pick !== 'PASS').length;
    const ouRecCnt = dayGames.filter((g) => g.pred.ou_pick !== 'PASS').length;
    const injAlertCnt = dayGames.filter((g) =>
      [...(g.away_injuries || []), ...(g.home_injuries || [])].some((x) => x.impact_tier === 'STAR' || (x.impact_tier === 'STARTER' && x.play_prob_next <= 55))
    ).length;
    const dramaCnt = dayGames.filter((g) => g.storylines && g.storylines.has_drama).length;

    const f = NBA.state.picksFilter;
    const q = (NBA.state.picksSearch || '').trim().toLowerCase();
    const filtered = dayGames.filter((g) => {
      if (f === 'STRONG' && !(g.pred.ats_tier === 'STRONG' || g.pred.ou_tier === 'STRONG')) return false;
      if (f === 'ATS' && g.pred.ats_pick === 'PASS') return false;
      if (f === 'OU' && g.pred.ou_pick === 'PASS') return false;
      if (f === 'INJ' && ![...(g.away_injuries || []), ...(g.home_injuries || [])].some((x) => x.impact_tier === 'STAR' || (x.impact_tier === 'STARTER' && x.play_prob_next <= 55))) return false;
      if (f === 'DRAMA' && !(g.storylines && g.storylines.has_drama)) return false;
      if (q) {
        const h = NBA.teamOf(g.home_abbr);
        const a = NBA.teamOf(g.away_abbr);
        const hay = `${g.home_abbr} ${g.away_abbr} ${h.zh} ${a.zh} ${h.en} ${a.en}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🎯 隔日／今日 NBA 運彩盤口分析與下注指南</h1>
          <div class="sec-sub">
            🔄 二階段抓盤與變盤重析：每日 <strong>18:00 初盤首輪分析</strong> → <strong>23:00 尾盤定盤＋盤勢變化二輪重析</strong> · 資料更新：${NBA.esc(meta.generated_at_tw || '')}（06:40 賽前傷兵 · 11:40 / 14:15 完賽對獎進化）
          </div>
        </div>
        <input class="inp" id="picksSearchInp" placeholder="搜尋球隊（例：塞爾提克 / LAL / 勇士）…" value="${NBA.esc(NBA.state.picksSearch)}" style="min-width:240px">
      </div>

      <div class="odds-rule-bar">
        <span>🕕➡️🕚 <strong>二階段抓盤＆盤勢變化重析機制：</strong>每天晚上 <strong>18:00（台灣時間）</strong>先抓一次早盤（初盤基準）執行<strong>第一輪量化解盤</strong>；晚上 <strong>23:00</strong> 再抓最後一次尾盤並鎖定，自動比對 <code>18:00 → 23:00</code> 五小時讓分／大小分變盤方向（聰明錢順勢推升 vs 逆向誘盤護欄）執行<strong>第二輪重析</strong>，賽後統一依 23:00 定盤結算對獎。</span>
        <span class="odds-rule-pill">🔄 18:00 初盤首析 → 23:00 變盤二析</span>
      </div>

      <div class="inline-disc-bar">
        <span>⚖️ <strong>免責聲明：</strong>本站盤口與量化模型分析純供個人體育數據研究參考，不構成任何投注建議或獲利保證；使用者應獨立判斷，<strong>任何投注損益與失敗風險概由個人完全自負，與本站及開發者無關</strong>。</span>
        <button type="button" class="inline-disc-link" data-open-disclaimer="1">查看完整免責條款 →</button>
      </div>

      <div class="date-bar">
        <span style="font-size:12.5px;font-weight:700;color:#475569">📅 台灣開賽日：</span>
        ${quickDates.map((d) => `
          <button type="button" class="date-pill ${d.tw_date === activeDate ? 'active' : ''}" data-dt="${NBA.esc(d.tw_date)}">
            <span>${NBA.esc(d.tw_date.slice(5))} ${NBA.esc(dateRoleLabel(d.tw_date, meta))}</span>
            <span class="cnt">${d.total}場</span>
          </button>
        `).join('')}
        <select class="inp" id="picksDateSel" style="margin-left:auto;padding:5px 9px;font-size:12.5px">
          ${dates.map((d) => `<option value="${NBA.esc(d.tw_date)}" ${d.tw_date === activeDate ? 'selected' : ''}>${NBA.esc(d.tw_date)}（${d.total} 場 · 完賽 ${d.final}）</option>`).join('')}
        </select>
      </div>

      <div class="kpi-grid">
        <button type="button" class="kpi-card ${f === 'ALL' ? 'active' : ''}" data-pf="ALL">
          <div class="kpi-lbl"><span>當日總場次</span><span>點擊顯示全部</span></div>
          <div class="kpi-val">${dayGames.length} 場</div>
          <div class="kpi-sub">台灣日期 ${NBA.esc(activeDate)}</div>
        </button>
        <button type="button" class="kpi-card ${f === 'STRONG' ? 'active' : ''}" data-pf="STRONG">
          <div class="kpi-lbl"><span>🔥 強推精選 (STRONG)</span><span class="chip strong">首選</span></div>
          <div class="kpi-val">${strongCnt} 場</div>
          <div class="kpi-sub">本季強推累積勝率 ${snap.kpi.strong_win_rate}% (損益線 52.38%)</div>
        </button>
        <button type="button" class="kpi-card ${f === 'ATS' ? 'active' : ''}" data-pf="ATS">
          <div class="kpi-lbl"><span>✅ 讓分／受讓推薦</span><span>Spread</span></div>
          <div class="kpi-val">${atsRecCnt} 場</div>
          <div class="kpi-sub">已過濾水錢無優勢場次</div>
        </button>
        <button type="button" class="kpi-card ${f === 'OU' ? 'active' : ''}" data-pf="OU">
          <div class="kpi-lbl"><span>↕️ 大小分推薦</span><span>Over/Under</span></div>
          <div class="kpi-val">${ouRecCnt} 場</div>
          <div class="kpi-sub">結合背靠背失分與極端總分回歸</div>
        </button>
        <button type="button" class="kpi-card ${f === 'INJ' ? 'active' : ''}" data-pf="INJ">
          <div class="kpi-lbl"><span>⚠️ 主力傷兵警戒場</span><span>GTD / Out</span></div>
          <div class="kpi-val">${injAlertCnt} 場</div>
          <div class="kpi-sub">含球星缺陣或賽前決定 (GTD)</div>
        </button>
        <button type="button" class="kpi-card ${f === 'DRAMA' ? 'active' : ''}" data-pf="DRAMA">
          <div class="kpi-lbl"><span>🍿 話題戲碼與八卦</span><span class="drama-badge" style="padding:1px 6px">戰舊主</span></div>
          <div class="kpi-val">${dramaCnt} 場</div>
          <div class="kpi-sub">球星打老東家、宿敵恩怨與連勝焦點</div>
        </button>
      </div>

      ${anchor2x1
        ? `<div class="parlay-quick-banner">
            <div>
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <strong style="font-size:14px;color:#1e3a8a">🎰 ${NBA.esc(activeDate.slice(5))} 每日跨場串關首選（2串1 雙星主推 · 國際 ${anchor2x1.intl_odds.toFixed(2)}x / 台彩 ${anchor2x1.tw_odds.toFixed(2)}x）</strong>
                <span class="chip ${NBA.esc(anchor2x1.grade_cls || 'info')}">${NBA.esc(anchor2x1.grade_zh)}</span>
                ${anchor2x1.status === 'WIN' ? '<span class="chip ok">🎉 已過關中獎</span>' : anchor2x1.status === 'LOSS' ? '<span class="chip bad">❌ 未過</span>' : ''}
              </div>
              <div class="pq-legs-wrap">
                ${anchor2x1.legs.map((lg, idx) => `<span class="pq-leg-chip">#${idx + 1} ${NBA.esc(lg.pick_label_zh)} (Edge +${Number(lg.edge).toFixed(2)})</span>`).join('<span style="font-weight:800;color:#2563eb">＋</span>')}
                ${boost3x1 ? `<span style="font-size:12px;color:#475569;margin-left:4px">（另有 3串1 黃金三星 ${boost3x1.intl_odds.toFixed(2)}x 與 3串4 防斷龍容錯組合）</span>` : ''}
              </div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <button type="button" class="btn btn-sm" id="quickAdd2x1Btn">➕ 記此 2串1 注單</button>
              <a href="#/parlay" class="btn btn-primary btn-sm">🎰 查看完整串關與 3串4 試算 →</a>
            </div>
          </div>`
        : ''}

      ${dayGames.length && dayGames.every((g) => g.close_spread_home == null)
        ? `<div class="card" style="background:#fffbeb;border-color:#fde68a;margin-bottom:14px;font-size:13px;color:#92400e">
            💡 <strong>每日 23:00（台灣時間）固定抓盤機制：</strong>讓分盤（Spread）與大小分（Over/Under）固定於<strong>每日晚上 11 點（23:00 台灣時間）</strong>統一抓取並鎖定，其餘時段僅同步比分、球員數據與傷兵報告，不更動盤口。此日期賽事將於前一日 23:00 自動抓盤更新！
          </div>`
        : ''}

      ${filtered.length
        ? `<div class="games-grid">${filtered.map(renderGameCard).join('')}</div>`
        : `<div class="empty-box">目前篩選條件下沒有符合的 NBA 賽事，請切換上方日期或點擊「當日總場次」檢視全部。</div>`}
    `;

    root.querySelectorAll('.date-pill').forEach((btn) => {
      btn.onclick = () => {
        NBA.state.picksDate = btn.getAttribute('data-dt');
        NBA.render();
      };
    });
    const dSel = document.getElementById('picksDateSel');
    if (dSel) {
      dSel.onchange = () => {
        NBA.state.picksDate = dSel.value;
        NBA.render();
      };
    }
    root.querySelectorAll('.kpi-card[data-pf]').forEach((btn) => {
      btn.onclick = () => {
        NBA.state.picksFilter = btn.getAttribute('data-pf');
        NBA.render();
      };
    });
    const qAdd2 = document.getElementById('quickAdd2x1Btn');
    if (qAdd2 && anchor2x1) {
      qAdd2.onclick = () => {
        NBA.addParlayBet({
          tw_date: activeDate,
          type: 'DIRECT',
          title: '雙星主推 2 串 1',
          legs: anchor2x1.legs,
        });
      };
    }
    const sInp = document.getElementById('picksSearchInp');
    if (sInp) {
      sInp.oninput = () => {
        NBA.state.picksSearch = sInp.value;
        NBA.render();
        const el = document.getElementById('picksSearchInp');
        if (el) {
          el.focus({ preventScroll: true });
          el.setSelectionRange(el.value.length, el.value.length);
        }
      };
    }
  };
})();
