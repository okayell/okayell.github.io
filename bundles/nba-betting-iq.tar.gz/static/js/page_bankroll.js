/* Page 5: 📝 個人注單追蹤 ＆ 凱利公式／台彩國際盤期望值試算 (#/bankroll) */
(function () {
  'use strict';
  const NBA = window.NBA;

  NBA.pages.bankroll = function (root) {
    const bets = NBA.bets || [];
    const settled = bets.filter((b) => b.status === 'WIN' || b.status === 'LOSS' || b.status === 'PUSH');
    const wins = settled.filter((b) => b.status === 'WIN').length;
    const losses = settled.filter((b) => b.status === 'LOSS').length;
    const totStake = settled.reduce((s, b) => s + Number(b.stake || 0), 0);
    const totPnl = settled.reduce((s, b) => s + Number(b.pnl || 0), 0);
    const wr = wins + losses > 0 ? ((wins / (wins + losses)) * 100).toFixed(1) : '0.0';
    const roi = totStake > 0 ? ((totPnl / totStake) * 100).toFixed(2) : '0.00';

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">📝 我的實戰注單帳本 ＆ 期望值／凱利注碼試算</h1>
          <div class="sec-sub">從「隔日／今日解盤」一鍵匯入或手動新增注單，比賽結束後自動根據最終比分結算損益</div>
        </div>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>已結算戰績</span></div>
          <div class="kpi-val">${wins}勝 ${losses}敗</div>
          <div class="kpi-sub">個人實戰勝率 ${wr}%（待開獎 ${bets.length - settled.length} 筆）</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>累積總損益</span></div>
          <div class="kpi-val" style="color:${totPnl >= 0 ? '#15803d' : '#b91c1c'}">${totPnl >= 0 ? '+' : ''}${totPnl.toFixed(0)}</div>
          <div class="kpi-sub">累積已結算本金 ${totStake.toFixed(0)}</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>實戰投報率 (ROI)</span></div>
          <div class="kpi-val" style="color:${Number(roi) >= 0 ? '#15803d' : '#b91c1c'}">${Number(roi) >= 0 ? '+' : ''}${roi}%</div>
          <div class="kpi-sub">正期望值長期穩定成長指標</div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:14px;margin-bottom:14px">
        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">➕ 手動新增注單紀錄</h3>
          <form id="manualBetForm" class="qb-form" novalidate>
            <div class="qb-explain">✍️ 用來記錄在別處下的注，例如本站沒列出的比賽或自組串關。<strong>手動注單不會自動對獎</strong>，比賽結束後請在下方明細按「贏／輸／走」結算；想自動對獎，請從「🎯 隔日／今日解盤」卡片按「➕ 記讓分單」或「➕ 記大小單」。</div>
            <label class="qb-field">
              <span class="qb-step-title">① 對戰組合</span>
              <input class="inp" id="mbMatchup" maxlength="80" placeholder="例：騎士 @ 老鷹">
            </label>
            <div class="qb-fields">
              <label class="qb-field">
                <span class="qb-step-title">② 玩法</span>
                <select class="inp" id="mbMarket">
                  <option value="ATS">讓分盤 (ATS)</option>
                  <option value="OU">大小分 (O/U)</option>
                  <option value="ML">不讓分獨贏 (ML)</option>
                  <option value="PARLAY">🎰 跨場串關 (Parlay)</option>
                </select>
              </label>
              <label class="qb-field">
                <span class="qb-step-title">③ 下注內容</span>
                <input class="inp" id="mbLabel" maxlength="120">
                <span class="qb-hint" id="mbLabelHint"></span>
              </label>
            </div>
            <div class="qb-fields tight">
              <label class="qb-field" id="mbLineField">
                <span class="qb-step-title">盤口線（選填）</span>
                <input type="number" step="0.5" class="inp" id="mbLine">
                <span class="qb-hint" id="mbLineHint"></span>
              </label>
              <div class="qb-field">
                <label class="qb-step-title" for="mbOdds">④ 賠率</label>
                <input type="number" inputmode="decimal" step="0.01" min="1.01" class="inp" id="mbOdds" value="1.91">
                <div class="qb-chips" id="mbOddsChips"><button type="button" class="qb-chip" data-mb-odds="1.75">台灣運彩 1.75</button><button type="button" class="qb-chip" data-mb-odds="1.91">國際盤 1.91</button></div>
                <span class="qb-hint" id="mbOddsHint"></span>
              </div>
              <div class="qb-field">
                <label class="qb-step-title" for="mbStake">⑤ 投注金額（NT$）</label>
                <input type="number" inputmode="numeric" step="100" min="1" class="inp" id="mbStake" value="1000">
                <div class="qb-chips">${[100, 500, 1000, 2000, 5000].map((v) => `<button type="button" class="qb-chip" data-mb-stake="${v}">${v.toLocaleString('en-US')}</button>`).join('')}</div>
              </div>
            </div>
            <div class="qb-preview" id="mbPreview" aria-live="polite"></div>
            <label class="qb-field">
              <span class="qb-step-title">備註（選填）</span>
              <input class="inp" id="mbNote" maxlength="200" placeholder="例如：朋友報牌、追蹤用">
            </label>
            <div class="qb-err" id="mbErr" role="alert"></div>
            <button type="submit" class="btn btn-primary" id="mbSubmit">💾 新增至注單帳本</button>
          </form>
        </div>

        <div class="card" style="background:#f8fbff;border-color:#bfdbfe">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">🧮 凱利公式 (1/4 Kelly) ＆ 台彩 vs 國際盤期望值試算器</h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(105px,1fr));gap:8px;margin-bottom:10px">
            <label style="font-size:12px">預估過盤勝率 (%)<br>
              <input type="number" step="0.5" class="inp" id="evWinPct" value="56.5" style="width:100%;margin-top:3px">
            </label>
            <label style="font-size:12px">十進位賠率 (台彩1.75 / 國際1.91)<br>
              <input type="number" step="0.01" class="inp" id="evOdds" value="1.91" style="width:100%;margin-top:3px">
            </label>
            <label style="font-size:12px">總資金池 (Bankroll)<br>
              <input type="number" step="1000" class="inp" id="evBankroll" value="50000" style="width:100%;margin-top:3px">
            </label>
          </div>
          <div id="evCalcResult" class="card" style="padding:11px 13px"></div>
        </div>
      </div>

      <div class="card">
        <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">📋 注單歷史明細（共 ${bets.length} 筆）</h3>
        <div class="tbl-wrap">
          <table class="data-tbl">
            <thead>
              <tr>
                <th>日期</th>
                <th>對戰組合</th>
                <th>市場</th>
                <th>下注方向</th>
                <th class="num">賠率</th>
                <th class="num">本金</th>
                <th>狀態</th>
                <th class="num">損益</th>
                <th>手動結算／操作</th>
              </tr>
            </thead>
            <tbody>
              ${bets.map((b) => `
                <tr>
                  <td>${NBA.esc(b.tw_date || (b.created_at || '').slice(0, 10))}</td>
                  <td><strong>${NBA.esc(b.matchup)}</strong>${b.note ? `<div style="font-size:11px;color:#64748b">${NBA.esc(b.note)}</div>` : ''}</td>
                  <td><span class="chip ${b.market === 'PARLAY' ? 'info' : 'muted'}">${b.market === 'PARLAY' ? '🎰 串關' : NBA.esc(b.market)}</span></td>
                  <td><strong>${NBA.esc(b.pick_label)}</strong></td>
                  <td class="num">${Number(b.odds_decimal).toFixed(2)}</td>
                  <td class="num">${Number(b.stake).toFixed(0)}</td>
                  <td>
                    <span class="chip ${b.status === 'WIN' ? 'ok' : b.status === 'LOSS' ? 'bad' : b.status === 'PUSH' ? 'warn' : 'info'}">
                      ${b.status === 'WIN' ? '✅ 過盤贏' : b.status === 'LOSS' ? '❌ 未過輸' : b.status === 'PUSH' ? '➖ 走水' : '⏳ 待開獎'}
                    </span>
                  </td>
                  <td class="num" style="font-weight:700;color:${b.pnl > 0 ? '#15803d' : b.pnl < 0 ? '#b91c1c' : '#64748b'}">
                    ${b.status === 'PENDING' ? '—' : (b.pnl > 0 ? '+' : '') + Number(b.pnl).toFixed(0)}
                  </td>
                  <td>
                    <div style="display:flex;gap:4px">
                      <button type="button" class="btn btn-sm" data-settle="${NBA.esc(b.bet_id)}" data-st="WIN">贏</button>
                      <button type="button" class="btn btn-sm" data-settle="${NBA.esc(b.bet_id)}" data-st="LOSS">輸</button>
                      <button type="button" class="btn btn-sm" data-settle="${NBA.esc(b.bet_id)}" data-st="PUSH">走</button>
                      <button type="button" class="btn btn-sm" data-del="${NBA.esc(b.bet_id)}" style="color:#b91c1c">刪</button>
                    </div>
                  </td>
                </tr>
              `).join('') || '<tr><td colspan="9" style="text-align:center;padding:24px;color:#64748b">尚無注單紀錄，可從「🎯 隔日／今日解盤」卡片點擊「➕ 記讓分單」快速加入！</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    `;

    function updateEv() {
      const p = Math.max(0.01, Math.min(0.99, Number(document.getElementById('evWinPct').value || 55) / 100));
      const odds = Math.max(1.02, Number(document.getElementById('evOdds').value || 1.91));
      const bk = Math.max(100, Number(document.getElementById('evBankroll').value || 50000));
      const b = odds - 1;
      const breakeven = (1 / odds) * 100;
      const evPct = (p * b - (1 - p)) * 100;
      const fullKelly = Math.max(0, (p * b - (1 - p)) / b);
      const quarterKellyAmt = Math.round(bk * fullKelly * 0.25);
      document.getElementById('evCalcResult').innerHTML = `
        <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;font-size:13px">
          <span>損益兩平門檻：<strong>${breakeven.toFixed(2)}%</strong>（台彩1.75需57.14% / 國際1.91需52.36%）</span>
          <span>單注期望值 (EV)：<strong style="color:${evPct >= 0 ? '#15803d' : '#b91c1c'}">${evPct >= 0 ? '+' : ''}${evPct.toFixed(2)}%</strong></span>
        </div>
        <div style="margin-top:6px;font-size:13px;color:#1e293b">
          ${evPct > 0
            ? `✅ <strong>具備正期望值 (+EV)！</strong>穩健 1/4 凱利建議單場注碼：<strong>${quarterKellyAmt.toLocaleString()} 元</strong>（佔總資金 ${(fullKelly * 25).toFixed(2)}%）`
            : `⛔ <strong>負期望值 (-EV) 警告：</strong>此賠率需 ${breakeven.toFixed(1)}% 勝率才不虧錢，建議放棄此注或尋找更高水盤口！`}
        </div>`;
    }
    ['evWinPct', 'evOdds', 'evBankroll'].forEach((id) => {
      document.getElementById(id).oninput = updateEv;
    });
    updateEv();

    // Manual bets carry no game_id, so nothing settles them automatically: the form says so up front,
    // labels every field, adapts the hints to the market and previews the payout before saving.
    const MB_COPY = {
      ATS: { ph: '例：老鷹 -1.5', hint: '寫隊名＋讓分，例如「老鷹 -1.5」、「騎士 +3.5」。', line: '你押那一隊的讓分：負數＝讓分、正數＝受讓。', linePh: '-1.5', push: true },
      OU: { ph: '例：小分 239.5', hint: '寫大分或小分＋總分線，例如「小分 239.5」。', line: '兩隊總分的盤口線，例如 239.5。', linePh: '239.5', push: true },
      ML: { ph: '例：老鷹 獨贏', hint: '不讓分，猜哪一隊贏球。', line: '', push: false },
      PARLAY: { ph: '例：老鷹 -1.5 ＋ 湖人 大分 229.5', hint: '每一關用「＋」隔開。', line: '', push: false },
    };
    const mbForm = document.getElementById('manualBetForm');
    const mbMarket = document.getElementById('mbMarket');
    const mbOdds = document.getElementById('mbOdds');
    const mbStake = document.getElementById('mbStake');
    const mbErr = document.getElementById('mbErr');
    const mbSubmit = document.getElementById('mbSubmit');
    let mbSaving = false;
    const money = (n) => Math.round(n).toLocaleString('en-US');

    function refreshMb() {
      const c = MB_COPY[mbMarket.value] || MB_COPY.ATS;
      const odds = Number(mbOdds.value);
      const stake = Number(mbStake.value);
      const oddsOk = mbOdds.value.trim() !== '' && odds >= 1.01;
      const stakeOk = mbStake.value.trim() !== '' && stake >= 1;
      mbOdds.classList.toggle('inp-err', !oddsOk);
      mbStake.classList.toggle('inp-err', !stakeOk);
      root.querySelectorAll('[data-mb-stake]').forEach((b) => b.classList.toggle('on', Number(b.getAttribute('data-mb-stake')) === stake));
      root.querySelectorAll('[data-mb-odds]').forEach((b) => b.classList.toggle('on', Number(b.getAttribute('data-mb-odds')) === odds));
      const pv = document.getElementById('mbPreview');
      if (!oddsOk || !stakeOk) {
        pv.className = 'qb-preview invalid';
        pv.innerHTML = `${oddsOk ? '' : '<div>⚠️ 賠率要大於 1，例如 1.91</div>'}${stakeOk ? '' : '<div>⚠️ 請填投注金額，例如 1000</div>'}`;
        return false;
      }
      pv.className = 'qb-preview';
      pv.innerHTML = `
        <div>💰 若贏 → 可領回 <strong>NT$${money(stake * odds)}</strong>（含本金，淨賺 <strong>+${money(stake * odds - stake)}</strong>）</div>
        <div class="loss">若輸 → 損失本金 NT$${money(stake)}</div>
        ${c.push ? `<div class="push">若走水 → 退回本金 NT$${money(stake)}</div>` : ''}`;
      return true;
    }
    function applyMarket() {
      const c = MB_COPY[mbMarket.value] || MB_COPY.ATS;
      document.getElementById('mbLabel').placeholder = c.ph;
      document.getElementById('mbLabelHint').textContent = c.hint;
      document.getElementById('mbLineField').hidden = !c.line;
      document.getElementById('mbLine').placeholder = c.linePh || '';
      document.getElementById('mbLineHint').textContent = c.line;
      document.getElementById('mbOddsChips').hidden = mbMarket.value === 'PARLAY';
      document.getElementById('mbOddsHint').textContent = mbMarket.value === 'PARLAY'
        ? '串關請填總賠率（各關賠率相乘，例如 1.91 × 1.91 ≈ 3.65）。'
        : '請填你實際下注時看到的賠率；國際盤常見 1.91、台灣運彩常見 1.75。';
      refreshMb();
    }
    mbMarket.onchange = applyMarket;
    [mbOdds, mbStake].forEach((el) => { el.oninput = refreshMb; });
    root.querySelectorAll('[data-mb-stake]').forEach((b) => {
      b.onclick = () => { mbStake.value = b.getAttribute('data-mb-stake'); refreshMb(); };
    });
    root.querySelectorAll('[data-mb-odds]').forEach((b) => {
      b.onclick = () => { mbOdds.value = b.getAttribute('data-mb-odds'); refreshMb(); };
    });
    ['mbMatchup', 'mbLabel'].forEach((id) => {
      document.getElementById(id).oninput = (ev) => {
        if (ev.target.value.trim()) ev.target.classList.remove('inp-err');
        if (!mbForm.querySelector('#mbMatchup.inp-err, #mbLabel.inp-err')) mbErr.textContent = '';
      };
    });
    // IME-safe: the Enter that confirms a 注音／倉頡 candidate must not submit the form.
    mbForm.onkeydown = (ev) => {
      if (ev.key === 'Enter' && ev.target.tagName === 'INPUT' && !NBA.isEnterSend(ev)) ev.preventDefault();
    };
    applyMarket();

    mbForm.onsubmit = async (ev) => {
      ev.preventDefault();
      if (mbSaving) return;
      const errs = [];
      let firstBad = null;
      [['mbMatchup', '對戰組合'], ['mbLabel', '下注內容']].forEach(([id, name]) => {
        const el = document.getElementById(id);
        const bad = !el.value.trim();
        el.classList.toggle('inp-err', bad);
        if (bad) { errs.push(`請填${name}`); firstBad = firstBad || el; }
      });
      if (!refreshMb()) { errs.push('請確認賠率與投注金額'); firstBad = firstBad || mbOdds; }
      mbErr.textContent = errs.length ? `⚠️ ${errs.join('、')}` : '';
      if (errs.length) { firstBad.focus(); return; }
      const c = MB_COPY[mbMarket.value] || MB_COPY.ATS;
      const lineVal = document.getElementById('mbLine').value.trim();
      mbSaving = true;
      mbSubmit.disabled = true;
      mbSubmit.textContent = '⏳ 儲存中…';
      try {
        const res = await NBA.apiPost('/api/bets/add', {
          matchup: document.getElementById('mbMatchup').value.trim(),
          pick_label: document.getElementById('mbLabel').value.trim(),
          market: mbMarket.value,
          line: c.line && lineVal !== '' ? Number(lineVal) : 0,
          odds_decimal: Number(mbOdds.value),
          stake: Number(mbStake.value),
          note: document.getElementById('mbNote').value.trim(),
        });
        NBA.bets = res.bets || [];
        NBA.render();
        NBA.toast('✅ 注單已儲存！手動注單請在比賽結束後按「贏／輸／走」結算');
      } catch (e) {
        mbSaving = false;
        mbSubmit.disabled = false;
        mbSubmit.textContent = '💾 新增至注單帳本';
        NBA.toast('⚠️ ' + e.message);
      }
    };

    root.querySelectorAll('[data-settle]').forEach((btn) => {
      btn.onclick = async () => {
        const res = await NBA.apiPost('/api/bets/settle', {
          bet_id: btn.getAttribute('data-settle'),
          status: btn.getAttribute('data-st'),
        });
        NBA.bets = res.bets || [];
        NBA.render();
      };
    });
    root.querySelectorAll('[data-del]').forEach((btn) => {
      btn.onclick = async () => {
        const res = await NBA.apiPost('/api/bets/delete', { bet_id: btn.getAttribute('data-del') });
        NBA.bets = res.bets || [];
        NBA.render();
      };
    });
  };
})();
