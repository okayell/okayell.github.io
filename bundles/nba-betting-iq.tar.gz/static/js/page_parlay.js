/* Page: 🎰 每日跨場串關推薦 · 台彩／國際盤試算 ＆ 複式容錯組合 (#/parlay) */
(function () {
  'use strict';
  const NBA = window.NBA;

  function dateRoleLabel(twDate, meta) {
    if (twDate === meta.tomorrow_tw) return '明日賭盤';
    if (twDate === meta.today_tw) return '今日賽程';
    const d1 = new Date(twDate + 'T00:00:00Z');
    const d0 = new Date(meta.today_tw + 'T00:00:00Z');
    const diff = Math.round((d1 - d0) / 86400000);
    if (diff === -1) return '昨日完賽';
    if (diff === 2) return '後天預告';
    if (diff > 2) return `+${diff}天`;
    return '完賽';
  }

  function tierPill(tier) {
    if (tier === 'STRONG') return '<span class="chip strong">🔥 強推精選</span>';
    if (tier === 'LEAN') return '<span class="chip ok">✅ 順勢推薦</span>';
    return '<span class="chip warn" title="此關未達單場強推門檻，係為湊足當日串關場數之相對最佳優勢方向，建議調降注碼">⚠️ 湊關次選</span>';
  }

  function legResultBadge(res) {
    if (res === 'WIN') return '<span class="chip ok">✅ 過關</span>';
    if (res === 'LOSS') return '<span class="chip bad">❌ 倒關</span>';
    if (res === 'PUSH') return '<span class="chip warn">➖ 走水 (1.0x)</span>';
    return '<span class="chip muted">⏳ 待開賽</span>';
  }

  function pkgStatusBanner(pkg, book, unitStake) {
    const st = pkg.status;
    if (st === 'PENDING') return '';
    const isTw = book === 'TW';
    const pnlUnit = isTw ? Number(pkg.pnl_unit_tw || 0) : Number(pkg.pnl_unit_intl || 0);
    const netAmt = Math.round(pnlUnit * unitStake);
    const totalStake = unitStake * (pkg.bets_count || 1);
    const grossAmt = totalStake + netAmt;

    if (pkg.type === 'COMBO') {
      if (st === 'WIN') {
        return `<div style="background:#dcfce7;border:1px solid #86efac;color:#14532d;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">
          🎉 賽後對獎：${pkg.hit_cnt}/${pkg.legs_count} 關過盤（中 ${pkg.cashed_combos}/4 注大滿貫）！總領回 NT$ ${grossAmt.toLocaleString()}（淨賺 +NT$ ${netAmt.toLocaleString()}）
        </div>`;
      }
      if (st === 'PARTIAL') {
        return `<div style="background:#eff6ff;border:1px solid #93c5fd;color:#1e3a8a;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">
          🛡️ 賽後對獎：3 過 2 觸發複式容錯保護（中 ${pkg.cashed_combos}/4 注）！領回 NT$ ${grossAmt.toLocaleString()} 回血保本（損益 ${netAmt >= 0 ? '+' : ''}NT$ ${netAmt.toLocaleString()}）
        </div>`;
      }
      return `<div style="background:#fee2e2;border:1px solid #fca5a5;color:#991b1b;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">
        ❌ 賽後對獎：過關未達 2 關門檻（${pkg.hit_cnt}/${pkg.legs_count} 過），損益 -NT$ ${totalStake.toLocaleString()}
      </div>`;
    }

    if (st === 'WIN') {
      return `<div style="background:#dcfce7;border:1px solid #86efac;color:#14532d;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">
        🎉 賽後對獎：串關全過中獎（${pkg.hit_cnt}勝${pkg.push_cnt ? ` ${pkg.push_cnt}走水` : ''}）！單注領回 NT$ ${grossAmt.toLocaleString()}（淨利 +NT$ ${netAmt.toLocaleString()}）
      </div>`;
    }
    if (st === 'PUSH') {
      return `<div style="background:#fef3c7;border:1px solid #fcd34d;color:#78350f;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">
        ➖ 賽後對獎：全數走水退還本金 NT$ ${totalStake.toLocaleString()}
      </div>`;
    }
    return `<div style="background:#fee2e2;border:1px solid #fca5a5;color:#991b1b;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">
      ❌ 賽後對獎：${pkg.hit_cnt}/${pkg.legs_count} 關過盤（差 ${pkg.loss_cnt} 關斷龍），損益 -NT$ ${totalStake.toLocaleString()}
    </div>`;
  }

  function kCombinations(arr, k) {
    const res = [];
    function helper(start, combo) {
      if (combo.length === k) {
        res.push(combo.slice());
        return;
      }
      for (let i = start; i <= arr.length - (k - combo.length); i++) {
        combo.push(arr[i]);
        helper(i + 1, combo);
        combo.pop();
      }
    }
    helper(0, []);
    return res;
  }

  function renderPackageCard(pkg, book, unitStake) {
    const isTw = book === 'TW';
    const isCombo = pkg.type === 'COMBO';
    const totalBets = pkg.bets_count || 1;
    const totalStake = unitStake * totalBets;
    const combinedOdds = isTw ? Number(pkg.tw_odds || 1) : Number(pkg.intl_odds || 1);
    const evPct = isTw ? Number(pkg.ev_tw_pct || 0) : Number(pkg.ev_intl_pct || 0);

    const maxMult = isCombo
      ? (isTw ? Number(pkg.max_return_mult_tw || 0) : Number(pkg.max_return_mult_intl || 0))
      : combinedOdds;
    const maxGross = Math.round(unitStake * maxMult);
    const maxNet = maxGross - totalStake;

    const hit2Mult = isCombo
      ? (isTw ? Number(pkg.hit2_return_mult_tw || 0) : Number(pkg.hit2_return_mult_intl || 0))
      : 0;
    const hit2Gross = Math.round(unitStake * hit2Mult);

    const cardCls = pkg.key === 'anchor_2x1' ? 'parlay-card anchor' : isCombo ? 'parlay-card combo' : 'parlay-card';

    const legsHtml = (pkg.legs || []).map((lg, idx) => {
      const legOdds = isTw ? Number(lg.tw_odds || 1.75) : Number(lg.intl_odds || 1.91);
      const rowCls = lg.leg_result === 'WIN' ? 'leg-win' : lg.leg_result === 'LOSS' ? 'leg-loss' : '';
      const scoreTxt = lg.status === 'FINAL' && lg.away_score != null
        ? `終場 ${lg.away_score}:${lg.home_score}`
        : `台灣 ${(lg.tipoff_tw || '').slice(5)} 開打`;
      return `
        <div class="parlay-leg-row ${rowCls}">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
              <span class="chip info" style="font-weight:800">第 ${idx + 1} 關</span>
              <span style="display:inline-flex;align-items:center;gap:4px;font-size:12.5px;font-weight:700">
                ${lg.away_logo ? `<img loading="lazy" decoding="async" src="${NBA.esc(lg.away_logo)}" alt="" style="width:18px;height:18px;object-fit:contain">` : ''}
                <span class="tm-link" data-team-link="${NBA.esc(lg.away_abbr)}">${NBA.esc(lg.away_zh)}</span>
                <span style="color:#94a3b8">@</span>
                ${lg.home_logo ? `<img loading="lazy" decoding="async" src="${NBA.esc(lg.home_logo)}" alt="" style="width:18px;height:18px;object-fit:contain">` : ''}
                <span class="tm-link" data-team-link="${NBA.esc(lg.home_abbr)}">${NBA.esc(lg.home_zh)}</span>
              </span>
              <span style="font-size:11.5px;color:#64748b">（${NBA.esc(scoreTxt)}）</span>
              ${lg.drama_badge_zh ? `<span class="drama-badge" title="${NBA.esc(lg.drama_headline_zh || '')}">🍿 ${NBA.esc(lg.drama_badge_zh)}</span>` : ''}
            </div>
            <div style="display:flex;align-items:center;gap:5px">
              ${tierPill(lg.tier)}
              ${lg.leg_result ? legResultBadge(lg.leg_result) : ''}
            </div>
          </div>

          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:2px">
            <div>
              <span class="chip muted" style="margin-right:5px">${NBA.esc(lg.market_zh)}</span>
              <strong style="font-size:14px;color:#0f172a">${NBA.esc(lg.pick_label_zh)}</strong>
              <span style="font-size:11.5px;color:#1d4ed8;font-weight:700;margin-left:6px">Edge +${Number(lg.edge).toFixed(2)} 分</span>
            </div>
            <div style="font-size:12px;color:#334155">
              單關賠率 <strong>${legOdds.toFixed(2)}x</strong> · 預估勝率 <strong>${Number(lg.win_prob_pct).toFixed(1)}%</strong>
            </div>
          </div>

          <div style="font-size:11.5px;color:#475569;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
            <span>📌 入選依據：${NBA.esc(lg.reason_zh)}</span>
            <span style="color:#64748b">🔄 18:00 初盤 → 23:00 定盤</span>
          </div>
        </div>`;
    }).join('');

    const payoutHtml = isCombo
      ? `
        <div class="parlay-payout-box">
          <div>
            <div style="color:#64748b;font-size:11px">總投注本金（4 注）</div>
            <div style="font-size:14.5px;font-weight:800;color:#0f172a">NT$ ${totalStake.toLocaleString()}</div>
            <div style="font-size:11px;color:#64748b">每注 NT$ ${unitStake.toLocaleString()} × 4</div>
          </div>
          <div>
            <div style="color:#64748b;font-size:11px">🎉 3 關全過總領回</div>
            <div style="font-size:14.5px;font-weight:800;color:#15803d">NT$ ${maxGross.toLocaleString()}</div>
            <div style="font-size:11px;color:#15803d">淨利 +NT$ ${maxNet.toLocaleString()} (${(maxGross / totalStake).toFixed(2)}x)</div>
          </div>
          <div>
            <div style="color:#64748b;font-size:11px">🛡️ 3 過 2 保本回血</div>
            <div style="font-size:14.5px;font-weight:800;color:#1d4ed8">NT$ ${hit2Gross.toLocaleString()}</div>
            <div style="font-size:11px;color:#475569">拿回 ${Math.round((hit2Gross / totalStake) * 100)}% 本金防斷龍</div>
          </div>
          <div>
            <div style="color:#64748b;font-size:11px">至少過 2 關機率 / EV</div>
            <div style="font-size:14.5px;font-weight:800;color:#0f172a">${pkg.at_least_2_prob_pct}%</div>
            <div style="font-size:11px;font-weight:700;color:${evPct >= 0 ? '#15803d' : '#b45309'}">期望值 ${evPct >= 0 ? '+' : ''}${evPct.toFixed(1)}%</div>
          </div>
        </div>`
      : `
        <div class="parlay-payout-box">
          <div>
            <div style="color:#64748b;font-size:11px">單注本金</div>
            <div style="font-size:14.5px;font-weight:800;color:#0f172a">NT$ ${totalStake.toLocaleString()}</div>
            <div style="font-size:11px;color:#64748b">${NBA.esc(pkg.stake_advice_zh || '')}</div>
          </div>
          <div>
            <div style="color:#64748b;font-size:11px">綜合過關賠率</div>
            <div style="font-size:15px;font-weight:800;color:#1d4ed8">${combinedOdds.toFixed(2)} 倍</div>
            <div style="font-size:11px;color:#64748b">${isTw ? '台彩過關參考盤' : '國際美式換算盤'}</div>
          </div>
          <div>
            <div style="color:#64748b;font-size:11px">過關總領回（含本）</div>
            <div style="font-size:15px;font-weight:800;color:#15803d">NT$ ${maxGross.toLocaleString()}</div>
            <div style="font-size:11px;color:#15803d;font-weight:700">淨利 +NT$ ${maxNet.toLocaleString()}</div>
          </div>
          <div>
            <div style="color:#64748b;font-size:11px">聯立過關率 / 期望值</div>
            <div style="font-size:14.5px;font-weight:800;color:#0f172a">${pkg.joint_prob_pct}%</div>
            <div style="font-size:11px;font-weight:700;color:${evPct >= 0 ? '#15803d' : '#b45309'}">EV ${evPct >= 0 ? '+' : ''}${evPct.toFixed(1)}%</div>
          </div>
        </div>`;

    return `
      <article class="${cardCls}">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;flex-wrap:wrap">
          <div>
            <div style="font-size:11.5px;font-weight:800;color:#2563eb;margin-bottom:2px">${NBA.esc(pkg.badge_zh)}</div>
            <h3 style="margin:0;font-size:16.5px;color:#0f172a">${NBA.esc(pkg.title_zh)}</h3>
          </div>
          <span class="chip ${NBA.esc(pkg.grade_cls || 'info')}">${NBA.esc(pkg.grade_zh)}</span>
        </div>

        <div style="font-size:12.5px;color:#475569;line-height:1.5">${NBA.esc(pkg.subtitle_zh)}</div>

        <div class="parlay-leg-list">${legsHtml}</div>

        ${payoutHtml}
        ${pkgStatusBanner(pkg, book, unitStake)}

        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:auto;padding-top:4px">
          <span style="font-size:11.5px;color:#64748b">✅ 嚴格跨場不重複賽事（符合台灣運彩＆國際盤串關規範）</span>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button type="button" class="btn btn-sm" data-copy-pkg="${NBA.esc(pkg.key)}">📋 複製串關單</button>
            <button type="button" class="btn btn-primary btn-sm" data-save-pkg="${NBA.esc(pkg.key)}">➕ 一鍵加入注單追蹤</button>
          </div>
        </div>
      </article>`;
  }

  NBA.pages.parlay = function (root) {
    const snap = NBA.snap || {};
    const meta = snap.meta || {};
    const dates = snap.dates || [];
    const dp = snap.daily_parlays || { kpi: {}, by_date: {}, history: [] };
    const pkpi = dp.kpi || {};
    const activeDate = NBA.state.picksDate || meta.default_picks_date || meta.tomorrow_tw;
    const book = NBA.state.parlayBook || 'INTL';
    const isTw = book === 'TW';
    const unitStake = Math.max(10, Number(NBA.state.parlayStake || 500));

    const quickDates = dates.slice(-6);
    const dayInfo = (dp.by_date || {})[activeDate] || {
      tw_date: activeDate,
      total_games: 0,
      games_with_odds: 0,
      strong_legs_cnt: 0,
      rec_legs_cnt: 0,
      awaiting_odds: false,
      ranked_legs: [],
      packages: [],
      game_options: [],
    };
    const packages = dayInfo.packages || [];
    const gameOpts = dayInfo.game_options || [];

    // Prune customParlayLegs to games on activeDate (auto-seed top 2 if empty on first visit)
    const validMap = {};
    gameOpts.forEach((go) => { validMap[go.game_id] = go; });
    const curSel = NBA.state.customParlayLegs || {};
    const activeSelIds = Object.keys(curSel).filter((gid) => validMap[gid]);
    if (NBA.state._customParlaySeededDate !== activeDate) {
      const nextSel = {};
      (dayInfo.ranked_legs || []).slice(0, Math.min(2, dayInfo.ranked_legs.length)).forEach((lg) => {
        nextSel[lg.game_id] = lg.market;
      });
      NBA.state.customParlayLegs = nextSel;
      NBA.state._customParlaySeededDate = activeDate;
    } else if (activeSelIds.length !== Object.keys(curSel).length) {
      const cleaned = {};
      activeSelIds.forEach((gid) => { cleaned[gid] = curSel[gid]; });
      NBA.state.customParlayLegs = cleaned;
    }

    const pickedLegs = [];
    gameOpts.forEach((go) => {
      const m = NBA.state.customParlayLegs[go.game_id];
      if (m === 'ATS' && go.ats) pickedLegs.push(go.ats);
      else if (m === 'OU' && go.ou) pickedLegs.push(go.ou);
    });

    // Compute Custom Parlay & Fault-Tolerant Combos
    let customCalcHtml = '';
    if (pickedLegs.length < 2) {
      customCalcHtml = `
        <div class="empty-box" style="padding:26px 16px">
          👈 請從左側點選至少 <strong>2 場不同賽事</strong>的讓分或大小分（同場限選 1 項，最多 6 關），即時試算直串與複式容錯報酬！
        </div>`;
    } else {
      const n = pickedLegs.length;
      const legOddsArr = pickedLegs.map((lg) => (isTw ? Number(lg.tw_odds || 1.75) : Number(lg.intl_odds || 1.91)));
      const legProbArr = pickedLegs.map((lg) => Number(lg.win_prob_pct || 52) / 100);
      const directOdds = legOddsArr.reduce((a, b) => a * b, 1);
      const directProb = legProbArr.reduce((a, b) => a * b, 1);
      const directEv = (directProb * directOdds - 1) * 100;
      const directGross = Math.round(unitStake * directOdds);
      const directNet = directGross - unitStake;

      // Build popular combo options for n >= 3 (e.g. 3串3, 3串4, 4串4, 4串11, N串N)
      const idxArr = Array.from({ length: n }, (_, i) => i);
      const comboSpecs = [];
      if (n >= 3) {
        const cMinus1 = kCombinations(idxArr, n - 1);
        comboSpecs.push({
          id: `${n}x${cMinus1.length}`,
          label: `${n} 串 ${cMinus1.length}（過 ${n - 1} 關複式 · 共 ${cMinus1.length} 注）`,
          desc: `不含 ${n}串1，倒 1 關即穩收 1 組 ${n - 1}串1 保本獲利`,
          combos: cMinus1,
        });
        if (n === 3) {
          const c34 = [...kCombinations(idxArr, 2), idxArr];
          comboSpecs.push({
            id: '3x4',
            label: '3 串 4（3 組 2串1 ＋ 1 組 3串1 · 共 4 注）',
            desc: '台灣運彩熱門容錯買法：3 過 2 回血保本、3 全過 4 注全收',
            combos: c34,
          });
        } else if (n === 4) {
          const c411 = [...kCombinations(idxArr, 2), ...kCombinations(idxArr, 3), idxArr];
          comboSpecs.push({
            id: '4x11',
            label: '4 串 11（6 組 2串1 ＋ 4 組 3串1 ＋ 1 組 4串1 · 共 11 注）',
            desc: '4 過 2 即有獎金回血、4 過 3 穩賺、4 全過 11 注滿貫',
            combos: c411,
          });
        }
      }

      const comboRowsHtml = comboSpecs.map((cs, cIdx) => {
        const bCnt = cs.combos.length;
        const totCost = unitStake * bCnt;
        const sweepMult = cs.combos.reduce((acc, cb) => acc + cb.reduce((m, i) => m * legOddsArr[i], 1), 0);
        const sweepGross = Math.round(unitStake * sweepMult);
        // Simulate missing the last leg (n-1 hit)
        const miss1Mult = cs.combos
          .filter((cb) => !cb.includes(n - 1))
          .reduce((acc, cb) => acc + cb.reduce((m, i) => m * legOddsArr[i], 1), 0);
        const miss1Gross = Math.round(unitStake * miss1Mult);
        return `
          <div style="background:#ffffff;border:1px solid #dbeafe;border-radius:8px;padding:9px 11px;margin-top:8px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
              <strong style="font-size:13px;color:#1e3a8a">🛡️ ${NBA.esc(cs.label)}</strong>
              <button type="button" class="btn btn-soft btn-sm" data-save-custom-combo="${cIdx}">💾 存此複式 (${bCnt}注)</button>
            </div>
            <div style="font-size:11.5px;color:#64748b;margin-top:2px">${NBA.esc(cs.desc)}</div>
            <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-top:6px;font-size:12px">
              <span>總本金：<strong>NT$ ${totCost.toLocaleString()}</strong></span>
              <span style="color:#15803d">全過領回：<strong>NT$ ${sweepGross.toLocaleString()}</strong> (+${(sweepGross - totCost).toLocaleString()})</span>
              <span style="color:#1d4ed8">倒 1 關領回：<strong>NT$ ${miss1Gross.toLocaleString()}</strong></span>
            </div>
          </div>`;
      }).join('');

      NBA.state._renderedComboSpecs = comboSpecs;

      customCalcHtml = `
        <div style="display:flex;flex-direction:column;gap:10px">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <strong style="font-size:14.5px;color:#0f172a">🎯 已選 ${n} 關跨場組合明細</strong>
            <button type="button" class="btn btn-sm" id="clearCustomParlayBtn">清空重選</button>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${pickedLegs.map((lg, i) => `
              <span class="pq-leg-chip">
                <span>#${i + 1} ${NBA.esc(lg.short_label_zh)} (${(isTw ? lg.tw_odds : lg.intl_odds).toFixed(2)}x)</span>
              </span>
            `).join('')}
          </div>

          <div class="parlay-payout-box" style="background:#eff6ff;border-color:#93c5fd">
            <div>
              <div style="font-size:11px;color:#475569">直串買法</div>
              <div style="font-size:15px;font-weight:800;color:#1e3a8a">${n} 串 1（共 1 注）</div>
              <div style="font-size:11px;color:#475569">本金 NT$ ${unitStake.toLocaleString()}</div>
            </div>
            <div>
              <div style="font-size:11px;color:#475569">綜合總賠率</div>
              <div style="font-size:15px;font-weight:800;color:#1d4ed8">${directOdds.toFixed(2)} 倍</div>
              <div style="font-size:11px;color:#475569">聯立勝率 ${(directProb * 100).toFixed(1)}%</div>
            </div>
            <div>
              <div style="font-size:11px;color:#475569">過關總領回</div>
              <div style="font-size:15px;font-weight:800;color:#15803d">NT$ ${directGross.toLocaleString()}</div>
              <div style="font-size:11px;font-weight:700;color:#15803d">淨利 +NT$ ${directNet.toLocaleString()} (EV ${directEv >= 0 ? '+' : ''}${directEv.toFixed(1)}%)</div>
            </div>
          </div>

          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button type="button" class="btn btn-primary btn-sm" id="saveCustomDirectBtn">➕ 存入注單帳本（${n}串1 直串）</button>
            <button type="button" class="btn btn-sm" id="copyCustomParlayBtn">📋 複製自選串關單</button>
          </div>

          ${comboRowsHtml ? `<div style="border-top:1px dashed #cbd5e1;padding-top:8px"><div style="font-size:12.5px;font-weight:800;color:#334155">🛡️ 同組標的「防斷龍複式容錯」對照表</div>${comboRowsHtml}</div>` : ''}
        </div>`;
    }

    const p2Pnl = isTw ? Number(pkpi.p2_pnl_tw || 0) : Number(pkpi.p2_pnl_intl || 0);
    const p3Pnl = isTw ? Number(pkpi.p3_pnl_tw || 0) : Number(pkpi.p3_pnl_intl || 0);
    const c34Pnl = isTw ? Number(pkpi.c34_pnl_tw || 0) : Number(pkpi.c34_pnl_intl || 0);

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🎰 每日 NBA 跨場串關推薦 ＆ 複式過關容錯試算</h1>
          <div class="sec-sub">
            嚴選當日模型優勢（Edge）最高之跨場不重複標的，自動生成<strong>「2串1 雙星主推」</strong>、<strong>「3串1 黃金三星」</strong>與<strong>「3串4 防爆冷回血組合」</strong> · 支援台灣運彩與國際盤切換
          </div>
        </div>
        <a href="#/picks" class="btn btn-soft btn-sm">← 返回單場解盤明細</a>
      </div>

      <div class="odds-rule-bar">
        <span>🕕➡️🕚 <strong>二階段抓盤＆串關重組說明：</strong>每日 <strong>18:00（台灣時間）</strong>先擷取早盤產出首輪串關組合；晚上 <strong>23:00</strong> 再擷取尾盤鎖定，依 <code>18:00 → 23:00</code> 盤勢變化重新篩選最高期望值串關，賽後統一依 23:00 定盤對獎結算（遇走水關卡依規降關以 <code>1.0x</code> 計算）。</span>
        <span class="odds-rule-pill">🔄 18:00 初盤首析 → 23:00 變盤定盤</span>
      </div>

      <div class="inline-disc-bar">
        <span>⚖️ <strong>免責聲明：</strong>串關具乘數波動放大特性，本站量化組合與容錯試算純供個人數據研究參考，不構成任何投注建議或獲利保證；<strong>任何投注損益與失敗風險概由使用者個人完全自負，與本站及開發者無關</strong>。</span>
        <button type="button" class="inline-disc-link" data-open-disclaimer="1">查看完整免責條款 →</button>
      </div>

      <div class="date-bar">
        <span style="font-size:12.5px;font-weight:700;color:#475569">📅 台灣開賽日：</span>
        ${quickDates.map((d) => `
          <button type="button" class="date-pill ${d.tw_date === activeDate ? 'active' : ''}" data-pdt="${NBA.esc(d.tw_date)}">
            <span>${NBA.esc(d.tw_date.slice(5))} ${NBA.esc(dateRoleLabel(d.tw_date, meta))}</span>
            <span class="cnt">${d.total}場</span>
          </button>
        `).join('')}
        <select class="inp" id="parlayDateSel" style="margin-left:auto;padding:5px 9px;font-size:12.5px">
          ${dates.map((d) => `<option value="${NBA.esc(d.tw_date)}" ${d.tw_date === activeDate ? 'selected' : ''}>${NBA.esc(d.tw_date)}（${d.total} 場 · 完賽 ${d.final}）</option>`).join('')}
        </select>
      </div>

      <div class="parlay-ctrl-bar">
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          <span style="font-size:12.5px;font-weight:800;color:#334155">🏦 賠率盤制：</span>
          <div class="seg-group">
            <button type="button" class="seg-btn ${!isTw ? 'active' : ''}" data-book="INTL">🌏 國際盤（-110 / 約 1.91x）</button>
            <button type="button" class="seg-btn ${isTw ? 'active' : ''}" data-book="TW">🇹🇼 台灣運彩盤（參考 1.75x）</button>
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <span style="font-size:12.5px;font-weight:800;color:#334155">💵 每注試算本金 (NT$)：</span>
          ${[100, 500, 1000, 2000].map((amt) => `
            <button type="button" class="btn btn-sm ${unitStake === amt ? 'btn-soft' : ''}" data-stake-preset="${amt}">${amt.toLocaleString()}</button>
          `).join('')}
          <input type="number" min="10" step="100" class="inp" id="parlayStakeInp" value="${unitStake}" style="width:96px;padding:5px 8px;font-weight:700">
        </div>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>🥇 本季 2串1 主推戰績</span><span class="chip ok">首選</span></div>
          <div class="kpi-val">${pkpi.p2_w || 0}勝 ${pkpi.p2_l || 0}敗</div>
          <div class="kpi-sub">過關率 ${pkpi.p2_win_rate || 0}% · 累積損益 <strong style="color:${p2Pnl >= 0 ? '#15803d' : '#b91c1c'}">${p2Pnl >= 0 ? '+' : ''}${p2Pnl.toFixed(2)}u</strong></div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>🥈 本季 3串1 黃金三星</span><span class="chip info">高賠</span></div>
          <div class="kpi-val">${pkpi.p3_w || 0}勝 ${pkpi.p3_l || 0}敗</div>
          <div class="kpi-sub">過關率 ${pkpi.p3_win_rate || 0}% · 累積損益 <strong style="color:${p3Pnl >= 0 ? '#15803d' : '#b91c1c'}">${p3Pnl >= 0 ? '+' : ''}${p3Pnl.toFixed(2)}u</strong></div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>🛡️ 本季 3串4 容錯兌獎率</span><span class="chip info">防斷龍</span></div>
          <div class="kpi-val">${pkpi.c34_cash_rate || 0}%</div>
          <div class="kpi-sub">全過大賺 ${pkpi.c34_full_w || 0} 次 · 3過2回血 ${pkpi.c34_partial || 0} 次（${c34Pnl >= 0 ? '+' : ''}${c34Pnl.toFixed(2)}u）</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>📌 ${NBA.esc(activeDate.slice(5))} 當日可串場數</span><span>跨場獨立</span></div>
          <div class="kpi-val">${dayInfo.games_with_odds} 場</div>
          <div class="kpi-sub">含 🔥 強推 ${dayInfo.strong_legs_cnt} 關 · 推薦級共 ${dayInfo.rec_legs_cnt} 關</div>
        </div>
      </div>

      ${dayInfo.awaiting_odds
        ? `<div class="card" style="background:#fffbeb;border-color:#fde68a;margin-bottom:16px;padding:18px;font-size:13.5px;color:#92400e">
            ⏳ <strong>等待前一日晚上 11 點（23:00 台灣時間）固定抓盤：</strong><br>
            ${NBA.esc(activeDate)} 共有 <strong>${dayInfo.total_games} 場</strong> NBA 賽事，系統將於前一日晚上 11 點自動抓取鎖定讓分盤與大小分後，立即運算出當日「2串1 / 3串1 / 3串4」推薦組合！您可先切換上方已開盤日期查看今日推薦或完賽對獎紀錄。
          </div>`
        : packages.length === 0
        ? `<div class="empty-box" style="margin-bottom:16px">此日期已開盤賽事不足 2 場，無法組成跨場串關；請切換其他比賽日查看。</div>`
        : `<div class="parlay-pkg-grid">${packages.map((p) => renderPackageCard(p, book, unitStake)).join('')}</div>`}

      ${gameOpts.length >= 2 ? `
        <div class="card" style="margin-bottom:18px">
          <div class="sec-hdr" style="margin-bottom:10px">
            <div>
              <h2 class="sec-title" style="font-size:16.5px">🛠️ 自選跨場串關 ＆ 過關組合試算器（${NBA.esc(activeDate)}）</h2>
              <div class="sec-sub">自由點選各場「讓分」或「大小分」（自動限制同場僅選 1 關，最多 6 關），同步比較直串與「過 N-1 關複式容錯」損益</div>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <button type="button" class="btn btn-soft btn-sm" id="fillTop2Btn">⚡ 帶入今日最佳 2 關</button>
              ${gameOpts.length >= 3 ? `<button type="button" class="btn btn-soft btn-sm" id="fillTop3Btn">⚡ 帶入今日最佳 3 關</button>` : ''}
            </div>
          </div>

          <div class="parlay-builder-wrap" style="margin-bottom:0">
            <div style="display:flex;flex-direction:column;gap:7px">
              ${gameOpts.map((go) => {
                const pickedMkt = NBA.state.customParlayLegs[go.game_id] || '';
                const ats = go.ats;
                const ou = go.ou;
                return `
                  <div class="pb-game-row">
                    <div>
                      <div style="font-weight:800;font-size:13px;color:#0f172a">${NBA.esc(go.away_zh)} @ ${NBA.esc(go.home_zh)}</div>
                      <div style="font-size:11px;color:#64748b">${go.status === 'FINAL' && go.away_score != null ? `終場 ${go.away_score}:${go.home_score}` : `台灣 ${(go.tipoff_tw || '').slice(5)}`}</div>
                    </div>
                    ${ats ? `
                      <button type="button" class="pb-pick-btn ${pickedMkt === 'ATS' ? 'selected' : ''}" data-pb-gid="${NBA.esc(go.game_id)}" data-pb-mkt="ATS">
                        <span>🎯 ${NBA.esc(ats.short_label_zh)}${go.best_market === 'ATS' ? ' ★' : ''}</span>
                        <span style="font-size:11px;color:#475569">${(isTw ? ats.tw_odds : ats.intl_odds).toFixed(2)}x</span>
                      </button>` : '<div></div>'}
                    ${ou ? `
                      <button type="button" class="pb-pick-btn ${pickedMkt === 'OU' ? 'selected' : ''}" data-pb-gid="${NBA.esc(go.game_id)}" data-pb-mkt="OU">
                        <span>↕️ ${NBA.esc(ou.short_label_zh.split(' ').slice(1).join(' '))}${go.best_market === 'OU' ? ' ★' : ''}</span>
                        <span style="font-size:11px;color:#475569">${(isTw ? ou.tw_odds : ou.intl_odds).toFixed(2)}x</span>
                      </button>` : '<div></div>'}
                  </div>`;
              }).join('')}
            </div>

            <div class="card" style="background:#f8fafc;border-color:#e2e8f0">
              ${customCalcHtml}
            </div>
          </div>
        </div>` : ''}

      <div class="card">
        <div class="sec-hdr" style="margin-bottom:10px">
          <div>
            <h2 class="sec-title" style="font-size:16.5px">📜 本季每日推薦串關歷史對獎帳本（Walk-Forward 實盤驗證）</h2>
            <div class="sec-sub">點擊任一日期可直接載入當日完整串關卡片與各關比分明細 · 損益依目前所選「${isTw ? '台灣運彩 1.75x' : '國際盤 -110'}」計算</div>
          </div>
        </div>
        <div class="tbl-wrap">
          <table class="data-tbl">
            <thead>
              <tr>
                <th>台灣日期</th>
                <th>場數</th>
                <th>🥇 方案 A（雙星主推 2串1）</th>
                <th>2串1 結果</th>
                <th class="num">2串1 損益</th>
                <th>🥈 方案 B（黃金三星 3串1）</th>
                <th>3串1 結果</th>
                <th>🛡️ 方案 C（3串4 容錯）</th>
              </tr>
            </thead>
            <tbody>
              ${(dp.history || []).map((h) => {
                const p2u = isTw ? (h.p2_status === 'WIN' ? +(h.p2_tw_odds - 1).toFixed(2) : h.p2_status === 'LOSS' ? -1 : 0) : Number(h.p2_pnl_intl || 0);
                return `
                  <tr>
                    <td>
                      <button type="button" class="btn btn-sm" data-jump-pdt="${NBA.esc(h.tw_date)}" style="font-weight:800;color:#1d4ed8">
                        ${NBA.esc(h.tw_date)}
                      </button>
                    </td>
                    <td>${h.games_cnt} 場</td>
                    <td><strong>${NBA.esc(h.p2_picks_zh)}</strong></td>
                    <td>
                      <span class="chip ${h.p2_status === 'WIN' ? 'ok' : h.p2_status === 'LOSS' ? 'bad' : 'warn'}">
                        ${h.p2_status === 'WIN' ? `✅ 過關 (${h.p2_hit_str})` : h.p2_status === 'LOSS' ? `❌ 未過 (${h.p2_hit_str})` : '➖ 走水'}
                      </span>
                    </td>
                    <td class="num" style="font-weight:800;color:${p2u > 0 ? '#15803d' : p2u < 0 ? '#b91c1c' : '#64748b'}">
                      ${p2u > 0 ? '+' : ''}${p2u.toFixed(2)}u
                    </td>
                    <td style="font-size:12px">${NBA.esc(h.p3_picks_zh)}</td>
                    <td>
                      ${h.p3_status === 'NONE'
                        ? '<span class="chip muted">—</span>'
                        : `<span class="chip ${h.p3_status === 'WIN' ? 'ok' : h.p3_status === 'LOSS' ? 'bad' : 'warn'}">${h.p3_status === 'WIN' ? `🎉 全過 (${h.p3_hit_str})` : `❌ ${h.p3_hit_str}`}</span>`}
                    </td>
                    <td>
                      ${h.c34_status === 'NONE'
                        ? '<span class="chip muted">—</span>'
                        : h.c34_status === 'WIN'
                        ? `<span class="chip ok">🎉 中 ${h.c34_cashed}/4 注大賺</span>`
                        : h.c34_status === 'PARTIAL'
                        ? `<span class="chip info">🛡️ 中 ${h.c34_cashed}/4 注回血</span>`
                        : `<span class="chip bad">❌ 0/4 注</span>`}
                    </td>
                  </tr>`;
              }).join('') || '<tr><td colspan="8" style="text-align:center;padding:20px;color:#64748b">尚無已完賽之歷史串關紀錄</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    `;

    // Bind events (date pills and book toggles are handled by the delegated handler in app.js)
    const dSel = document.getElementById('parlayDateSel');
    if (dSel) {
      dSel.onchange = () => {
        NBA.state.picksDate = dSel.value;
        NBA.render();
      };
    }
    root.querySelectorAll('[data-stake-preset]').forEach((btn) => {
      btn.onclick = () => {
        NBA.state.parlayStake = Number(btn.getAttribute('data-stake-preset'));
        NBA.render();
      };
    });
    const stakeInp = document.getElementById('parlayStakeInp');
    if (stakeInp) {
      stakeInp.onchange = () => {
        NBA.state.parlayStake = Math.max(10, Number(stakeInp.value || 500));
        NBA.render();
      };
    }

    // Package Copy & Save
    root.querySelectorAll('[data-save-pkg]').forEach((btn) => {
      btn.onclick = () => {
        const key = btn.getAttribute('data-save-pkg');
        const pkg = packages.find((x) => x.key === key);
        if (!pkg) return;
        NBA.addParlayBet({
          tw_date: activeDate,
          type: pkg.type,
          combos: pkg.combos,
          title: pkg.title_zh.replace(/^方案\s*[A-D]：/, ''),
          legs: pkg.legs,
          book,
          unitStake,
        });
      };
    });
    root.querySelectorAll('[data-copy-pkg]').forEach((btn) => {
      btn.onclick = async () => {
        const key = btn.getAttribute('data-copy-pkg');
        const pkg = packages.find((x) => x.key === key);
        if (!pkg) return;
        const lines = [
          `🏀 NBA 運彩智庫 · ${activeDate} ${pkg.title_zh}（${isTw ? '台灣運彩盤' : '國際盤'}）`,
          ...pkg.legs.map((lg, i) => `  第${i + 1}關：${lg.matchup_zh} → ${lg.pick_label_zh} (Edge +${lg.edge})`),
          pkg.type === 'COMBO'
            ? `  買法：3串4 複式共 4 注（每注 NT$${unitStake}，合 NT$${unitStake * 4}）`
            : `  綜合賠率：${(isTw ? pkg.tw_odds : pkg.intl_odds).toFixed(2)}x（單注 NT$${unitStake}）`,
        ];
        try {
          await navigator.clipboard.writeText(lines.join('\n'));
          NBA.toast('📋 已複製串關單文字！');
        } catch (_) {
          NBA.toast('⚠️ 瀏覽器不支援自動剪貼簿複製');
        }
      };
    });

    // Custom Parlay Builder clicks
    root.querySelectorAll('[data-pb-gid]').forEach((btn) => {
      btn.onclick = () => {
        const gid = btn.getAttribute('data-pb-gid');
        const mkt = btn.getAttribute('data-pb-mkt');
        const cur = { ...(NBA.state.customParlayLegs || {}) };
        if (cur[gid] === mkt) {
          delete cur[gid];
        } else {
          if (!cur[gid] && Object.keys(cur).length >= 6) {
            NBA.toast('⚠️ 串關試算最多選取 6 場不同賽事（避免水錢乘數過度耗損）');
            return;
          }
          cur[gid] = mkt;
        }
        NBA.state.customParlayLegs = cur;
        NBA.render();
      };
    });

    const fillTop = (cnt) => {
      const next = {};
      (dayInfo.ranked_legs || []).slice(0, cnt).forEach((lg) => {
        next[lg.game_id] = lg.market;
      });
      NBA.state.customParlayLegs = next;
      NBA.render();
    };
    const f2 = document.getElementById('fillTop2Btn');
    if (f2) f2.onclick = () => fillTop(2);
    const f3 = document.getElementById('fillTop3Btn');
    if (f3) f3.onclick = () => fillTop(3);
    const clr = document.getElementById('clearCustomParlayBtn');
    if (clr) {
      clr.onclick = () => {
        NBA.state.customParlayLegs = {};
        NBA.render();
      };
    }
    const saveDirect = document.getElementById('saveCustomDirectBtn');
    if (saveDirect) {
      saveDirect.onclick = () => {
        NBA.addParlayBet({
          tw_date: activeDate,
          type: 'DIRECT',
          title: `自選 ${pickedLegs.length} 串 1`,
          legs: pickedLegs,
          book,
          unitStake,
        });
      };
    }
    const copyCustom = document.getElementById('copyCustomParlayBtn');
    if (copyCustom) {
      copyCustom.onclick = async () => {
        const totOdds = pickedLegs.reduce((m, lg) => m * (isTw ? lg.tw_odds : lg.intl_odds), 1);
        const lines = [
          `🏀 NBA 自選跨場 ${pickedLegs.length} 串 1（${activeDate} · ${isTw ? '台彩盤' : '國際盤'}）`,
          ...pickedLegs.map((lg, i) => `  第${i + 1}關：${lg.pick_label_zh}`),
          `  綜合賠率：${totOdds.toFixed(2)}x（單注 NT$${unitStake} → 預估領回 NT$${Math.round(unitStake * totOdds).toLocaleString()}）`,
        ];
        try {
          await navigator.clipboard.writeText(lines.join('\n'));
          NBA.toast('📋 已複製自選串關單！');
        } catch (_) {
          NBA.toast('⚠️ 複製失敗');
        }
      };
    }
    root.querySelectorAll('[data-save-custom-combo]').forEach((btn) => {
      btn.onclick = () => {
        const idx = Number(btn.getAttribute('data-save-custom-combo'));
        const cs = (NBA.state._renderedComboSpecs || [])[idx];
        if (!cs) return;
        NBA.addParlayBet({
          tw_date: activeDate,
          type: 'COMBO',
          combos: cs.combos,
          title: `自選 ${cs.id.replace('x', '串')} 複式`,
          legs: pickedLegs,
          book,
          unitStake,
        });
      };
    });
  };
})();
