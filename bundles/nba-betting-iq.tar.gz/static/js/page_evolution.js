/* Page 4: 🧠 模型賽後檢討 ＆ 自我進化中心 (#/evolution) */
(function () {
  'use strict';
  const NBA = window.NBA;

  function renderEvoSvg(timeline) {
    if (!timeline || !timeline.length) return '<div class="empty-box">尚無完賽進化紀錄</div>';
    const W = 760;
    const H = 220;
    const padL = 46;
    const padR = 24;
    const padT = 22;
    const padB = 34;
    const plotW = W - padL - padR;
    const plotH = H - padT - padB;
    const yMin = 35;
    const yMax = 75;
    const yOf = (pct) => padT + plotH - ((Math.max(yMin, Math.min(yMax, pct)) - yMin) / (yMax - yMin)) * plotH;
    const xOf = (i) => padL + (timeline.length === 1 ? plotW / 2 : (i / (timeline.length - 1)) * plotW);

    const beY = yOf(52.38);
    const strongPts = timeline.map((t, i) => `${xOf(i).toFixed(1)},${yOf(t.cum_strong_win_rate).toFixed(1)}`).join(' ');
    const basePts = timeline.map((t, i) => `${xOf(i).toFixed(1)},${yOf(t.cum_all_win_rate).toFixed(1)}`).join(' ');

    return `
      <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;display:block">
        ${[40, 50, 60, 70].map((v) => `
          <line x1="${padL}" y1="${yOf(v)}" x2="${W - padR}" y2="${yOf(v)}" stroke="#e2e8f0" stroke-width="1"/>
          <text x="${padL - 8}" y="${yOf(v) + 4}" text-anchor="end" font-size="11" fill="#64748b">${v}%</text>
        `).join('')}
        <!-- 52.38% Sportsbook Vig Breakeven Line -->
        <line x1="${padL}" y1="${beY}" x2="${W - padR}" y2="${beY}" stroke="#dc2626" stroke-dasharray="5,4" stroke-width="1.5"/>
        <text x="${W - padR - 4}" y="${beY - 5}" text-anchor="end" font-size="11" font-weight="700" fill="#dc2626">52.38% 運彩損益兩平線 (-110 水錢)</text>

        <!-- Naive Baseline Polyline -->
        <polyline fill="none" stroke="#94a3b8" stroke-width="2" stroke-dasharray="3,3" points="${basePts}"/>
        <!-- Evolved Strong Win Rate Polyline -->
        <polyline fill="none" stroke="#2563eb" stroke-width="3" points="${strongPts}"/>

        ${timeline.map((t, i) => `
          <circle cx="${xOf(i)}" cy="${yOf(t.cum_strong_win_rate)}" r="4.5" fill="#2563eb" stroke="#fff" stroke-width="1.5">
            <title>${t.et_date} (${t.model_version})：強推累積勝率 ${t.cum_strong_win_rate}%</title>
          </circle>
          <text x="${xOf(i)}" y="${H - 10}" text-anchor="middle" font-size="10.5" fill="#475569">${NBA.esc(t.model_version)}</text>
        `).join('')}
      </svg>`;
  }

  function renderFactorRows(list) {
    return list.map((f) => {
      const delta = Number(f.delta_w || 0);
      const dChip = delta > 0.005
        ? `<span class="chip ok">▲ +${delta.toFixed(3)} 調升</span>`
        : delta < -0.005
        ? `<span class="chip warn">▼ ${delta.toFixed(3)} 調降</span>`
        : `<span class="chip muted">持平</span>`;
      const hrColor = f.trials === 0 ? '#64748b' : f.hit_rate >= 54 ? '#15803d' : f.hit_rate < 49 ? '#b45309' : '#334155';
      return `
        <tr>
          <td><span class="chip ${f.market.includes('ATS') ? 'info' : 'strong'}">${NBA.esc(f.market)}</span></td>
          <td>
            <strong>${NBA.esc(f.name_zh)}</strong>
            <div style="font-size:11.5px;color:#64748b">${NBA.esc(f.desc_zh)}</div>
          </td>
          <td class="num">${f.init_w.toFixed(3)}</td>
          <td class="num"><strong>${f.cur_w.toFixed(3)}</strong></td>
          <td>${dChip}</td>
          <td class="num">${f.trials > 0 ? `${f.hits}/${f.trials}` : '待賽前觸發'}</td>
          <td class="num"><strong style="color:${hrColor}">${f.trials > 0 ? f.hit_rate.toFixed(1) + '%' : '—'}</strong></td>
        </tr>`;
    }).join('');
  }

  NBA.pages.evolution = function (root) {
    const snap = NBA.snap;
    const evo = snap.evolution || {};
    const k = snap.kpi || {};
    const bc = evo.baseline_comparison || {};
    const allFactors = [...(evo.ats_factors || []), ...(evo.ou_factors || [])];
    const memo = evo.ai_coach_memo;

    const memoHtml = memo
      ? `
        <div class="card" style="background:#f8fbff;border-color:#bfdbfe;margin-bottom:14px">
          <div class="sec-hdr" style="margin-bottom:8px">
            <div>
              <strong style="font-size:15px;color:#1e40af">🤖 AI 進化教練最新檢討報告：${NBA.esc(memo.headline || '')}</strong>
              <div class="sec-sub">產生時間：${NBA.esc(memo.generated_at || '')}</div>
            </div>
            ${!NBA.isStatic && NBA.health.ai ? `<button type="button" class="btn btn-soft btn-sm" id="runAiCoachBtn">↻ 重新執行 AI 賽後深度檢討</button>` : ''}
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;font-size:13px">
            <div>
              <strong>🔍 近期敗因與優勢歸納：</strong>
              <ul style="margin:6px 0 0;padding-left:18px;color:#334155">
                ${(memo.reflection_points || []).map((x) => `<li>${NBA.esc(x)}</li>`).join('')}
              </ul>
            </div>
            <div>
              <strong>⚙️ 下注紀律與權重優化策略：</strong>
              <ul style="margin:6px 0 0;padding-left:18px;color:#334155">
                ${(memo.strategy_upgrades || []).map((x) => `<li>${NBA.esc(x)}</li>`).join('')}
              </ul>
            </div>
            <div>
              <strong>🎯 隔日最值得鎖定切入點：</strong>
              <ul style="margin:6px 0 0;padding-left:18px;color:#334155">
                ${(memo.tomorrow_best_angles || []).map((x) => `<li>${NBA.esc(x)}</li>`).join('')}
              </ul>
            </div>
          </div>
        </div>`
      : (!NBA.isStatic && NBA.health.ai
        ? `<div class="card" style="background:#f8fbff;border-color:#bfdbfe;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <div>
              <strong style="color:#1e40af">🤖 AI 賽後檢討與進化教練（Jetski Connect-RPC）</strong>
              <div class="sec-sub">讓 AI 深度檢視近期過盤失誤場次、各因子命中率高低，產出明日具體進場與避雷策略並永久保存。</div>
            </div>
            <button type="button" class="btn btn-primary btn-sm" id="runAiCoachBtn">🤖 立即執行 AI 賽後深度檢討</button>
          </div>`
        : '');

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🧠 賭盤模型賽後檢討 ＆ 自我進化中心 (${NBA.esc(snap.meta.model_version)})</h1>
          <div class="sec-sub">每日 14:15 完賽後自動逐場復盤對獎：調升實戰高勝率因子權重、調降失準雜訊因子，並啟動防呆護欄持續拉高精選勝率</div>
        </div>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>① 未進化初階基準（場均分差全買）</span></div>
          <div class="kpi-val" style="color:#64748b">${bc.static_win_rate || 50.0}%</div>
          <div class="kpi-sub">${bc.static_w || 0}勝 ${bc.static_l || 0}敗（低於水錢線，長期必虧）</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>② 進化模型全推薦（含順勢 LEAN）</span></div>
          <div class="kpi-val" style="color:#2563eb">${k.rec_win_rate}%</div>
          <div class="kpi-sub">${k.rec_w}勝 ${k.rec_l}敗（站上 52.38% 損益兩平線）</div>
        </div>
        <div class="kpi-card static-kpi" style="border-color:#86efac;background:#f0fdf4">
          <div class="kpi-lbl"><span>③ 🔥 進化模型強推精選 (STRONG)</span><span class="chip ok">主力獲利</span></div>
          <div class="kpi-val" style="color:#15803d">${k.strong_win_rate}%</div>
          <div class="kpi-sub">${k.strong_w}勝 ${k.strong_l}敗 · 累積淨利 ${NBA.fmtSigned(k.units_pnl, 2)}u (ROI ${NBA.fmtSigned(k.roi_pct, 2)}%)</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>已完成自我進化輪數</span></div>
          <div class="kpi-val">${snap.meta.evolution_steps} 次升級</div>
          <div class="kpi-sub">強推門檻：讓分 ≥${evo.thresholds.strong_ats} / 大小 ≥${evo.thresholds.strong_ou}</div>
        </div>
      </div>

      ${memoHtml}

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:14px;margin-bottom:14px">
        <div class="card">
          <div class="sec-hdr" style="margin-bottom:6px">
            <div>
              <h3 class="sec-title" style="font-size:15px">📈 Walk-Forward 累積勝率演進曲線（零未來函數回測）</h3>
              <div class="sec-sub">藍實線：🔥 強推精選累積勝率 ｜ 灰虛線：初階基準 ｜ 紅虛線：52.38% 運彩損益兩平門檻</div>
            </div>
          </div>
          ${renderEvoSvg(evo.timeline || [])}
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:8px">🛡️ 失誤歸因統計 ＆ 已自動啟動防呆護欄</h3>
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
            ${(evo.error_breakdown || []).map((e) => `<span class="chip warn">${NBA.esc(e.label)} · ${e.count} 場</span>`).join('')}
          </div>
          <div style="display:flex;flex-direction:column;gap:8px">
            ${(evo.guardrails || []).map((g) => `
              <div style="background:#f8fafc;border:1px solid #e2e8f0;border-left:3px solid #16a34a;border-radius:7px;padding:8px 10px">
                <div style="font-weight:700;font-size:12.5px;color:#0f172a">✅ ${NBA.esc(g.title)}</div>
                <div style="font-size:12px;color:#475569;margin-top:2px">${NBA.esc(g.rule)}</div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <div class="card" style="margin-bottom:14px">
        <div class="sec-hdr">
          <div>
            <h3 class="sec-title" style="font-size:15px">⚖️ 13 大量化解盤因子 · 實戰命中率與自我進化權重表</h3>
            <div class="sec-sub">系統於每個比賽日完賽後自動檢驗各因子方向是否與真實過盤一致，自動調升 >54% 高準度因子並壓低雜訊因子權重</div>
          </div>
        </div>
        <div class="tbl-wrap">
          <table class="data-tbl">
            <thead>
              <tr>
                <th>市場</th>
                <th>量化因子名稱 ＆ 邏輯說明</th>
                <th class="num">初始權重</th>
                <th class="num">進化後權重</th>
                <th>進化調整幅度</th>
                <th class="num">觸發命中 / 總場數</th>
                <th class="num">單因子實戰命中率</th>
              </tr>
            </thead>
            <tbody>${renderFactorRows(allFactors)}</tbody>
          </table>
        </div>
      </div>

      <div class="card">
        <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">📜 每日賽後檢討與版本升級日誌 (Evolution Log)</h3>
        <div class="tbl-wrap">
          <table class="data-tbl">
            <thead>
              <tr>
                <th>美東比賽日</th>
                <th>升級版本</th>
                <th class="num">對獎場數</th>
                <th class="num">當日推薦戰績</th>
                <th class="num">累積強推勝率</th>
                <th>自動檢討與權重修正摘要</th>
              </tr>
            </thead>
            <tbody>
              ${(evo.timeline || []).slice().reverse().map((t) => `
                <tr>
                  <td><strong>${NBA.esc(t.et_date)}</strong></td>
                  <td><span class="chip info">${NBA.esc(t.model_version)}</span></td>
                  <td class="num">${t.games_graded} 場</td>
                  <td class="num">讓分 ${t.ats_wins}-${t.ats_losses} · 大小 ${t.ou_wins}-${t.ou_losses}</td>
                  <td class="num"><strong style="color:${t.cum_strong_win_rate >= 52.4 ? '#15803d' : '#b45309'}">${t.cum_strong_win_rate}%</strong></td>
                  <td style="font-size:12.5px;color:#334155">${NBA.esc(t.summary_zh)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    const coachBtn = document.getElementById('runAiCoachBtn');
    if (coachBtn) {
      coachBtn.onclick = async () => {
        coachBtn.disabled = true;
        coachBtn.textContent = '⏳ AI 教練深度復盤中（約 12–20 秒）…';
        try {
          const st = await NBA.apiPost('/api/ai/start', { kind: 'coach_postmortem' });
          for (let i = 0; i < 55; i++) {
            await new Promise((r) => setTimeout(r, 1300));
            const tk = await NBA.apiGet(`/api/ai/task?id=${encodeURIComponent(st.task)}`);
            if (tk.status === 'done') {
              await NBA.refreshAllData();
              NBA.toast('✅ AI 進化教練已完成最新賽後檢討與策略更新！');
              return;
            }
            if (tk.status === 'error') throw new Error(tk.error || 'AI 執行失敗');
          }
          throw new Error('AI 回覆逾時');
        } catch (e) {
          coachBtn.disabled = false;
          coachBtn.textContent = '🤖 立即執行 AI 賽後深度檢討';
          NBA.toast('⚠️ ' + e.message);
        }
      };
    }
  };
})();
