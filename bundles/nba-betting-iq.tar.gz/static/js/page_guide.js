/* Page 6: 📖 NBA 運彩盤口百科 ＆ 自動進化架構說明 (#/guide) */
(function () {
  'use strict';
  const NBA = window.NBA;

  NBA.pages.guide = function (root) {
    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">📖 NBA 運彩盤口實戰百科 ＆ 系統自動進化說明</h1>
          <div class="sec-sub">從基礎讓分／大小分規則到莊家變盤訊號 (CLV)、水錢數學與本系統每日自動檢討進化機制</div>
        </div>
        ${!NBA.isStatic ? `<a class="btn btn-soft" href="/download/index.html" download="index.html">⬇️ 下載單一 index.html (GitHub Pages)</a>` : ''}
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,410px),1fr));gap:14px">
        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:8px">1️⃣ 讓分／受讓盤 (Point Spread / ATS) 怎麼看？</h3>
          <ul style="margin:0;padding-left:18px;color:#334155;display:flex;flex-direction:column;gap:6px">
            <li><strong>讓分方（負號 <code>-</code>，Favorite）：</strong>例如 <code>塞爾提克 -6.5</code>，代表塞爾提克終場必須<strong>贏超過 7 分（含）以上</strong>才算「讓分過盤」；若只贏 1～6 分或輸球，則算「輸盤」。</li>
            <li><strong>受讓方（正號 <code>+</code>，Underdog）：</strong>例如 <code>老鷹 +6.5</code>，代表老鷹只要<strong>直接贏球，或輸在 6 分（含）以內</strong>，都算「受讓過盤（咬盤）」。</li>
            <li><strong>整數盤走水（Push）：</strong>若盤口為 <code>-5.0</code> 而主隊剛好贏 5 分，加總為 <code>0</code>，稱為「走水／洞」，退還本金不計輸贏。</li>
          </ul>
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:8px">2️⃣ 大小分 (Over / Under) ＆ 延長賽規則</h3>
          <ul style="margin:0;padding-left:18px;color:#334155;display:flex;flex-direction:column;gap:6px">
            <li><strong>全場總得分（含延長賽 OT）：</strong>無論誰輸誰贏，將「客隊得分 ＋ 主隊得分」相加對比盤口（例如 <code>233.5</code>）。超過即為<strong>大分 (OVER)</strong>，低於即為<strong>小分 (UNDER)</strong>。</li>
            <li><strong>現代 NBA 兩大大小分陷阱：</strong>
              <br>① <strong>背靠背 (B2B) 疲勞其實偏大分：</strong>本季實證數據顯示背靠背球隊退防與外線輪轉速度大幅下降，對手輕鬆得分，開出大分比例高達 ~59%！
              <br>② <strong>淺盤 (≤3.5分) 末節犯規戰術：</strong>最後 1 分鐘落後 3–6 分時的故意犯規與延長賽常在 40 秒內灌進 14+ 分，買淺盤小分風險極高。
            </li>
          </ul>
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:8px">3️⃣ 每日晚上 23:00（台灣時間）固定抓盤鎖定 ＆ 變盤訊號</h3>
          <ul style="margin:0;padding-left:18px;color:#334155;display:flex;flex-direction:column;gap:6px">
            <li><strong>為什麼固定抓每天晚上 23:00 的盤口？</strong>統一於每晚 <code>23:00（台灣時間）</code> 抓取隔日讓分盤（Spread）與大小分（Over/Under）並永久鎖定，避免開賽前臨場盤口跳動導致下注參考標準與賽後對獎帳本不一致。</li>
            <li><strong>初盤 vs 23:00 鎖定盤順勢訊號：</strong>本季實測「初盤→賽前讓分移動方向」單因子命中率達 <strong>58.3%</strong>！當初盤 <code>-1.5</code> 於 <code>23:00</code> 推升至 <code>-3.5</code> 時，往往代表國際職業資金站在讓分方。</li>
            <li><strong>賽前傷兵獨立監控：</strong>盤口於 <code>23:00</code> 鎖定後不再更動，但隔日早上 <code>06:40</code> 仍會更新最新 GTD 出賽成疑與先發名單供臨場風險確認。</li>
          </ul>
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:8px">4️⃣ 本系統如何每天自動檢討並提升勝率？</h3>
          <ul style="margin:0;padding-left:18px;color:#334155;display:flex;flex-direction:column;gap:6px">
            <li><strong>每日 4 時段分工排程（台灣時間）：</strong><code>23:00</code> <strong>固定抓取並鎖定隔日讓分盤與大小分盤口</strong> → <code>06:40</code> 賽前傷兵與先發確認（不更動盤口） → <code>11:40</code> 東岸完賽結算 → <code>14:15</code> 全數完賽依前晚 <code>23:00</code> 鎖定盤對獎並執行模型權重進化。</li>
            <li><strong>零未來函數 Walk-Forward 權重學習：</strong>每場完賽後自動核對 13 項量化因子各自預測方向是否正確，自動調升命中率 >54% 之有效因子權重、調降失準因子權重。</li>
            <li><strong>水錢過濾紀律（52.38% 護欄）：</strong>國際盤 <code>-110 (1.91)</code> 需 <code>52.38%</code> 勝率才回本（台灣運彩 <code>1.75</code> 更需 <code>57.14%</code>！）。因此「不勉強每場都下、只鎖定 🔥 強推精選高 Edge 場次」才是長期穩定獲利的核心關鍵。</li>
          </ul>
        </div>
      </div>

      <div class="card" style="margin-top:14px;background:#fffbeb;border-color:#fde68a;font-size:12.5px;color:#78350f;line-height:1.7">
        <strong>⚖️ 法律與運動彩券風險免責聲明：</strong>本站所有 NBA 盤口整理、量化模型預測與傷兵分析均由程式依公開數據自動產生，純供個人體育數據研究與觀賽參考，<strong>絕不構成任何投注建議、勸誘或獲利保證</strong>。運動賽事受臨場傷退、裁判尺度與單場手感變異影響極大，過去命中率不代表未來表現；請遵守所在地法令並量力而為，<strong>任何參考本站資訊所進行之投注行為，其一切盈虧結果與財務損失均由使用者自行完全承擔，概與本站及開發者無關</strong>。
      </div>
    `;
  };
})();
