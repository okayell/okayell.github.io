/* Page 3: 🏥 NBA 球員傷兵隔日上場機率雷達 ＆ 新聞專區 (#/news) */
(function () {
  'use strict';
  const NBA = window.NBA;

  function renderInjuriesPane(snap) {
    const slateSet = new Set((snap.meta && snap.meta.next_slate_teams) || []);
    const q = (NBA.state.injQuery || '').trim().toLowerCase();
    const list = (snap.injuries || []).filter((it) => {
      if (NBA.state.injSlateOnly && slateSet.size && !slateSet.has(it.team_abbr)) return false;
      if (NBA.state.injTeam !== 'ALL' && it.team_abbr !== NBA.state.injTeam) return false;
      if (NBA.state.injStatus !== 'ALL' && it.status !== NBA.state.injStatus) return false;
      if (q) {
        const tm = NBA.teamOf(it.team_abbr);
        const hay = `${it.player_name} ${it.team_abbr} ${tm.zh} ${it.injury_type} ${it.short_comment}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    return `
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px">
        <label class="btn btn-sm ${NBA.state.injSlateOnly ? 'btn-soft' : ''}" style="cursor:pointer">
          <input type="checkbox" id="injSlateChk" ${NBA.state.injSlateOnly ? 'checked' : ''} style="margin:0">
          🔥 僅顯示今明兩日有比賽球隊（${slateSet.size} 隊）
        </label>
        <select class="inp" id="injTeamSel">
          <option value="ALL">🏀 全部球隊</option>
          ${(snap.teams || []).map((t) => `<option value="${NBA.esc(t.abbr)}" ${NBA.state.injTeam === t.abbr ? 'selected' : ''}>${NBA.esc(t.zh)} (${NBA.esc(t.abbr)})</option>`).join('')}
        </select>
        <select class="inp" id="injStatusSel">
          <option value="ALL" ${NBA.state.injStatus === 'ALL' ? 'selected' : ''}>全部傷兵狀態</option>
          <option value="Questionable" ${NBA.state.injStatus === 'Questionable' ? 'selected' : ''}>❓ 出戰成疑 / GTD 賽前決定 (~50%)</option>
          <option value="Doubtful" ${NBA.state.injStatus === 'Doubtful' ? 'selected' : ''}>🟠 極可能缺陣 Doubtful (~20%)</option>
          <option value="Out" ${NBA.state.injStatus === 'Out' ? 'selected' : ''}>🚫 確定缺陣 Out (0%)</option>
          <option value="Probable" ${NBA.state.injStatus === 'Probable' ? 'selected' : ''}>🟢 大機率上場 Probable (~85%)</option>
        </select>
        <input class="inp" id="injSearchInp" placeholder="搜尋球員姓名或傷勢（例：Ankle / Curry）…" value="${NBA.esc(NBA.state.injQuery)}" style="min-width:230px;margin-left:auto">
      </div>

      <div class="tbl-wrap">
        <table class="data-tbl">
          <thead>
            <tr>
              <th>球隊</th>
              <th>球員 ＆ 位置</th>
              <th>戰力層級</th>
              <th>官方狀態 ＆ 傷勢部位</th>
              <th>隔日上場機率預估</th>
              <th class="num">對讓分影響估計</th>
              <th>最新傷情說明 ＆ 預計歸隊日</th>
            </tr>
          </thead>
          <tbody>
            ${list.map((it) => {
              const tm = NBA.teamOf(it.team_abbr);
              const prob = Number(it.play_prob_next || 0);
              const stCls = prob === 0 ? 'bad' : prob <= 55 ? 'warn' : 'ok';
              const tierChip = it.impact_tier === 'STAR'
                ? '<span class="chip strong">⭐ 當家球星</span>'
                : it.impact_tier === 'STARTER'
                ? '<span class="chip info">先發主力</span>'
                : '<span class="chip muted">輪替球員</span>';
              return `
                <tr>
                  <td style="white-space:nowrap">
                    <div class="tm-link" data-team-link="${NBA.esc(it.team_abbr)}" style="display:flex;align-items:center;gap:6px;color:#1d4ed8">
                      <img src="${NBA.esc(tm.logo)}" alt="" style="width:22px;height:22px;object-fit:contain">
                      <strong>${NBA.esc(tm.zh)}</strong>
                    </div>
                  </td>
                  <td style="white-space:nowrap">
                    <strong>${NBA.esc(it.player_name)}</strong>
                    <span style="color:#64748b;font-size:12px">${NBA.esc(it.position || '')}</span>
                  </td>
                  <td>${tierChip}</td>
                  <td>
                    <span class="chip ${stCls}">${NBA.esc(it.status_zh)}</span>
                    ${it.injury_type ? `<div style="font-size:11.5px;color:#64748b;margin-top:2px">傷勢：${NBA.esc(it.injury_type)}</div>` : ''}
                  </td>
                  <td style="min-width:130px">
                    <div style="display:flex;align-items:center;gap:7px">
                      <div class="fac-bar-track" style="flex:1"><div class="fac-bar-fill" style="width:${prob}%;background:${prob === 0 ? '#ef4444' : prob <= 55 ? '#f59e0b' : '#22c55e'}"></div></div>
                      <strong style="font-size:12px">${prob}%</strong>
                    </div>
                  </td>
                  <td class="num"><strong style="color:#c2410c">-${Number(it.est_spread_pts || 0).toFixed(1)} 分</strong></td>
                  <td style="max-width:410px;font-size:12.5px;color:#334155">
                    ${NBA.esc(it.short_comment || it.long_comment || '待球隊賽前傷兵報告更新')}
                    ${it.return_date ? `<span class="chip muted" style="margin-left:6px">預計復出：${NBA.esc(it.return_date)}</span>` : ''}
                  </td>
                </tr>`;
            }).join('') || '<tr><td colspan="7" style="text-align:center;padding:24px;color:#64748b">目前篩選條件下無傷兵名單（可取消勾選「僅顯示今明兩日有比賽球隊」查看全聯盟 30 隊）</td></tr>'}
          </tbody>
        </table>
      </div>`;
  }

  function playSignalChip(sig) {
    if (sig === 'OUT') return '<span class="chip bad">🚫 缺陣警訊</span>';
    if (sig === 'QUESTIONABLE') return '<span class="chip warn">❓ 賽前決定 GTD</span>';
    if (sig === 'PROBABLE') return '<span class="chip ok">🟢 大機率出賽</span>';
    if (sig === 'AVAILABLE') return '<span class="chip ok">✅ 復出上場</span>';
    return '';
  }

  function renderNewsPane(snap) {
    const cat = NBA.state.newsCat;
    const tm = NBA.state.newsTeam;
    const q = (NBA.state.newsQuery || '').trim().toLowerCase();

    const items = (snap.news || []).filter((n) => {
      if (cat !== 'ALL' && n.category !== cat) return false;
      if (tm !== 'ALL' && !(n.teams || []).includes(tm)) return false;
      if (q && !`${n.title} ${n.summary} ${(n.players || []).join(' ')}`.toLowerCase().includes(q)) return false;
      return true;
    });

    const cats = [
      ['ALL', '全部情報'],
      ['injury', '🏥 傷兵與出賽動態'],
      ['lineup', '📋 先發與陣容異動'],
      ['rest', '😴 輪休／背靠背'],
      ['odds', '💰 盤口與運彩焦點'],
      ['game', '🏀 賽事與戰力情報'],
    ];

    return `
      <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:12px">
        ${cats.map(([k, lbl]) => `
          <button type="button" class="date-pill ${cat === k ? 'active' : ''}" data-ncat="${k}">${lbl}</button>
        `).join('')}
        <select class="inp" id="newsTeamSel">
          <option value="ALL">🏀 全部球隊</option>
          ${(snap.teams || []).map((t) => `<option value="${NBA.esc(t.abbr)}" ${tm === t.abbr ? 'selected' : ''}>${NBA.esc(t.zh)} (${NBA.esc(t.abbr)})</option>`).join('')}
        </select>
        <input class="inp" id="newsSearchInp" placeholder="搜尋球員或關鍵字…" value="${NBA.esc(NBA.state.newsQuery)}" style="min-width:200px;margin-left:auto">
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,420px),1fr));gap:12px">
        ${items.map((n) => `
          <article class="card" style="display:flex;flex-direction:column;justify-content:space-between;gap:8px">
            <div>
              <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;flex-wrap:wrap;margin-bottom:6px">
                <div style="display:flex;gap:5px;flex-wrap:wrap">
                  <span class="chip info">${NBA.esc(n.category_zh)}</span>
                  ${playSignalChip(n.play_signal)}
                  ${(n.teams || []).map((ab) => `<span class="chip muted tm-link" data-team-link="${NBA.esc(ab)}">${NBA.esc(NBA.teamOf(ab).zh)}</span>`).join('')}
                </div>
                <span style="font-size:11.5px;color:#64748b">${NBA.esc(n.published_tw)} · ${NBA.esc(n.source)}</span>
              </div>
              <a href="${NBA.esc(n.url)}" target="_blank" rel="noopener noreferrer" style="font-size:14.5px;font-weight:800;color:#0f172a;line-height:1.45;display:block">
                ${NBA.esc(n.title)} ↗
              </a>
              ${n.summary ? `<p style="margin:6px 0 0;font-size:12.5px;color:#475569">${NBA.esc(n.summary)}</p>` : ''}
            </div>
            ${(n.players || []).length ? `<div style="font-size:11.5px;color:#2563eb;font-weight:700">👤 關聯焦點球員：${NBA.esc(n.players.join('、'))}</div>` : ''}
          </article>
        `).join('') || '<div class="empty-box" style="grid-column:1/-1">目前沒有符合條件的新聞項目</div>'}
      </div>`;
  }

  function renderDramaPane(snap) {
    const todayTw = (snap.meta && snap.meta.today_tw) || '';
    const dramaGames = (snap.games || []).filter((g) => g.storylines && g.storylines.has_drama);
    const sorted = dramaGames.slice().sort((a, b) => {
      const aUp = a.tw_date >= todayTw ? 0 : 1;
      const bUp = b.tw_date >= todayTw ? 0 : 1;
      if (aUp !== bUp) return aUp - bUp;
      if (aUp === 0) return String(a.tipoff_tw || '').localeCompare(String(b.tipoff_tw || ''));
      return String(b.tipoff_tw || '').localeCompare(String(a.tipoff_tw || ''));
    });

    if (!sorted.length) {
      return '<div class="empty-box">目前賽程暫無球星戰舊主或特殊世仇話題場次</div>';
    }

    return `
      <div class="info-banner" style="margin-bottom:12px;background:linear-gradient(90deg,#fffbeb,#fdf4ff);border-color:#f5d0fe;color:#581c87">
        🍿 <strong>球星戰舊主（Revenge Game）· 交易籌碼反戈 · 宿敵恩怨雷達：</strong>系統自動比對全聯盟 30 隊最新陣容與休賽季重磅交易（如 <strong>Ja Morant 轉披拓荒者對決灰熊母隊、Jerami Grant 重返波特蘭雙向戰舊主、字母哥轉戰熱火、Jaylen Brown 轉戰 76 人、Luka 打獨行俠</strong>等），並將球星證明身價的戰意與轉換節奏納入量化模型（若該球星傷退 Out 則自動歸零加成）。
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,460px),1fr));gap:12px">
        ${sorted.map((g) => {
          const st = g.storylines;
          const statusBadge = g.status === 'FINAL'
            ? `<span class="chip muted">終場 ${g.away_score}:${g.home_score}</span>`
            : g.status === 'IN_PROGRESS'
            ? `<span class="chip bad">🔴 進行中 ${g.away_score}:${g.home_score}</span>`
            : `<span class="chip info">台灣 ${NBA.esc((g.tipoff_tw || '').slice(5))} 開打</span>`;
          return `
            <article class="card" style="border-color:#fde68a;background:linear-gradient(180deg,#fffef7,#ffffff)">
              <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:8px;padding-bottom:8px;border-bottom:1px dashed #fde68a">
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                  ${g.away.logo ? `<img src="${NBA.esc(g.away.logo)}" alt="" style="width:22px;height:22px;object-fit:contain">` : ''}
                  <strong class="tm-link" data-team-link="${NBA.esc(g.away_abbr)}" style="font-size:14.5px">${NBA.esc(g.away.zh)}</strong>
                  <span style="color:#94a3b8;font-size:12px">@</span>
                  ${g.home.logo ? `<img src="${NBA.esc(g.home.logo)}" alt="" style="width:22px;height:22px;object-fit:contain">` : ''}
                  <strong class="tm-link" data-team-link="${NBA.esc(g.home_abbr)}" style="font-size:14.5px">${NBA.esc(g.home.zh)}</strong>
                  ${statusBadge}
                </div>
                <button type="button" class="btn btn-soft btn-sm" data-jump-picks-date="${NBA.esc(g.tw_date)}">🎯 前往該日解盤</button>
              </div>
              <div style="display:flex;flex-direction:column;gap:8px">
                ${(st.items || []).map((it) => `
                  <div class="drama-item">
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;flex-wrap:wrap">
                      <span class="drama-badge">${NBA.esc(it.badge_zh)}</span>
                      <span style="font-size:11px;color:#92400e;font-weight:700">
                        ${Math.abs(Number(it.ats_impact_pts || 0)) >= 0.05 ? `讓分戰意 ${Number(it.ats_impact_pts) > 0 ? '主+' : '客+'}${Math.abs(Number(it.ats_impact_pts)).toFixed(2)}` : ''}
                        ${Math.abs(Number(it.ou_impact_pts || 0)) >= 0.05 ? ` · 節奏 ${Number(it.ou_impact_pts) > 0 ? '偏大+' : '偏小-'}${Math.abs(Number(it.ou_impact_pts)).toFixed(2)}` : ''}
                      </span>
                    </div>
                    <div style="font-size:13px;font-weight:800;color:#0f172a;margin-top:3px">${NBA.esc(it.title_zh)}</div>
                    <div style="font-size:12px;color:#334155;margin-top:2px;line-height:1.5">${NBA.esc(it.body_zh)}</div>
                    ${it.stat_recap_zh ? `<div style="font-size:11.5px;color:#15803d;font-weight:700;margin-top:3px">📊 ${NBA.esc(it.stat_recap_zh)}</div>` : ''}
                    ${it.betting_take_zh ? `<div class="drama-take">💡 盤口視角：${NBA.esc(it.betting_take_zh)}</div>` : ''}
                  </div>
                `).join('')}
              </div>
            </article>
          `;
        }).join('')}
      </div>
    `;
  }

  NBA.pages.news = function (root) {
    const snap = NBA.snap;
    const tab = NBA.state.newsTab;
    const gtdCount = (snap.injuries || []).filter((x) => x.status === 'Questionable' || x.status === 'Doubtful').length;
    const starOutCount = (snap.injuries || []).filter((x) => x.impact_tier === 'STAR' && x.play_prob_next <= 55).length;
    const dramaCount = (snap.games || []).filter((g) => g.storylines && g.storylines.has_drama).length;

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🏥 NBA 傷兵隔日出賽雷達 · 即時新聞 ＆ 場外話題八卦</h1>
          <div class="sec-sub">即時追蹤 ESPN 官方傷兵報告、RotoWire 賽前 GTD 異動、球星戰舊主（打老東家）與宿敵恩怨看點</div>
        </div>
        <div class="sub-tabs" style="margin-bottom:0">
          <button type="button" class="sub-tab ${tab === 'injuries' ? 'active' : ''}" data-ntab="injuries">🚑 各隊傷兵與上場機率 (${(snap.injuries || []).length})</button>
          <button type="button" class="sub-tab ${tab === 'drama' ? 'active' : ''}" data-ntab="drama">🍿 戰舊主與話題八卦 (${dramaCount})</button>
          <button type="button" class="sub-tab ${tab === 'feed' ? 'active' : ''}" data-ntab="feed">📰 傷兵／運彩新聞串流 (${(snap.news || []).length})</button>
        </div>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>全聯盟列管傷兵總數</span></div>
          <div class="kpi-val">${(snap.injuries || []).length} 人</div>
          <div class="kpi-sub">涵蓋 Out / Doubtful / Questionable / Probable</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>❓ 賽前決定 (GTD / Doubtful)</span></div>
          <div class="kpi-val" style="color:#b45309">${gtdCount} 人</div>
          <div class="kpi-sub">最容易引發開賽前 1 小時急遽變盤</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>⭐ 當家球星缺陣／存疑</span></div>
          <div class="kpi-val" style="color:#b91c1c">${starOutCount} 人</div>
          <div class="kpi-sub">單一球星缺陣平均牽動讓分 3.0–5.5 分</div>
        </div>
        <div class="kpi-card" id="kpiJumpDrama" style="cursor:pointer">
          <div class="kpi-lbl"><span>🍿 戰舊主／恩怨八卦場次</span><span class="chip warn">點此查看</span></div>
          <div class="kpi-val" style="color:#9333ea">${dramaCount} 場</div>
          <div class="kpi-sub">打老東家、交易反戈與世仇對決看點</div>
        </div>
      </div>

      ${tab === 'injuries' ? renderInjuriesPane(snap) : tab === 'drama' ? renderDramaPane(snap) : renderNewsPane(snap)}
    `;

    root.querySelectorAll('[data-ntab]').forEach((b) => {
      b.onclick = () => { NBA.state.newsTab = b.getAttribute('data-ntab'); NBA.render(); };
    });
    const kpiDrama = document.getElementById('kpiJumpDrama');
    if (kpiDrama) {
      kpiDrama.onclick = () => { NBA.state.newsTab = 'drama'; NBA.render(); };
    }
    root.querySelectorAll('[data-jump-picks-date]').forEach((b) => {
      b.onclick = () => {
        NBA.state.picksDate = b.getAttribute('data-jump-picks-date');
        NBA.state.picksFilter = 'DRAMA';
        location.hash = '#/picks';
      };
    });
    const chk = document.getElementById('injSlateChk');
    if (chk) chk.onchange = () => { NBA.state.injSlateOnly = chk.checked; NBA.render(); };
    const itSel = document.getElementById('injTeamSel');
    if (itSel) itSel.onchange = () => { NBA.state.injTeam = itSel.value; NBA.render(); };
    const isSel = document.getElementById('injStatusSel');
    if (isSel) isSel.onchange = () => { NBA.state.injStatus = isSel.value; NBA.render(); };
    const iq = document.getElementById('injSearchInp');
    if (iq) {
      iq.oninput = () => {
        NBA.state.injQuery = iq.value;
        NBA.render();
        const el = document.getElementById('injSearchInp');
        if (el) { el.focus({ preventScroll: true }); el.setSelectionRange(el.value.length, el.value.length); }
      };
    }

    root.querySelectorAll('[data-ncat]').forEach((b) => {
      b.onclick = () => { NBA.state.newsCat = b.getAttribute('data-ncat'); NBA.render(); };
    });
    const ntSel = document.getElementById('newsTeamSel');
    if (ntSel) ntSel.onchange = () => { NBA.state.newsTeam = ntSel.value; NBA.render(); };
    const nq = document.getElementById('newsSearchInp');
    if (nq) {
      nq.oninput = () => {
        NBA.state.newsQuery = nq.value;
        NBA.render();
        const el = document.getElementById('newsSearchInp');
        if (el) { el.focus({ preventScroll: true }); el.setSelectionRange(el.value.length, el.value.length); }
      };
    }
  };
})();
