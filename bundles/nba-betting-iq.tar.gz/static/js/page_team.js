/* Page: 🏀 30 支 NBA 球隊專區 — 過往各場比數、連續過讓／大小分趨勢標示與每位球員逐場數據 (#/team/<ABBR>) */
(function () {
  'use strict';
  const NBA = window.NBA;

  function sortGamesAsc(games) {
    return games.slice().sort((a, b) => {
      const ka = `${a.et_date || ''}|${a.tipoff_tw || ''}|${a.game_id || ''}`;
      const kb = `${b.et_date || ''}|${b.tipoff_tw || ''}|${b.game_id || ''}`;
      return ka.localeCompare(kb);
    });
  }

  function countLeadingStreak(arr) {
    if (!arr.length) return { type: '', count: 0 };
    const first = arr[0];
    if (!first || first === 'P') return { type: first || '', count: first ? 1 : 0 };
    let count = 0;
    for (let i = 0; i < arr.length; i += 1) {
      if (arr[i] === first) count += 1;
      else break;
    }
    return { type: first, count };
  }

  // Compute full ATS / O-U / W-L streaks, role/venue splits & per-game running streak numbers
  NBA.computeTeamStreaks = function (snap, abbr) {
    const rawFinals = ((snap && snap.games) || []).filter(
      (g) => g.status === 'FINAL' && (g.home_abbr === abbr || g.away_abbr === abbr)
    );
    const asc = sortGamesAsc(rawFinals);

    let runAtsType = '';
    let runAtsCnt = 0;
    let runOuType = '';
    let runOuCnt = 0;
    const runByGameId = {};

    const itemsAsc = asc.map((g) => {
      const isHome = g.home_abbr === abbr;
      const oppAbbr = isHome ? g.away_abbr : g.home_abbr;
      const mySc = isHome ? g.home_score : g.away_score;
      const oppSc = isHome ? g.away_score : g.home_score;
      const wl = mySc > oppSc ? 'W' : 'L';

      let ats = null;
      let myLine = null;
      let role = 'PK';
      if (g.close_spread_home != null && g.ats_winner) {
        myLine = isHome ? Number(g.close_spread_home) : -Number(g.close_spread_home);
        role = myLine < 0 ? 'FAV' : myLine > 0 ? 'DOG' : 'PK';
        if (g.ats_winner === 'PUSH') {
          ats = 'P';
          runAtsType = '';
          runAtsCnt = 0;
        } else {
          const covered = (isHome && g.ats_winner === 'HOME') || (!isHome && g.ats_winner === 'AWAY');
          ats = covered ? 'W' : 'L';
          if (ats === runAtsType) runAtsCnt += 1;
          else { runAtsType = ats; runAtsCnt = 1; }
        }
      }

      let ou = null;
      if (g.close_total && g.ou_result) {
        if (g.ou_result === 'PUSH') {
          ou = 'P';
          runOuType = '';
          runOuCnt = 0;
        } else {
          ou = g.ou_result === 'OVER' ? 'O' : 'U';
          if (ou === runOuType) runOuCnt += 1;
          else { runOuType = ou; runOuCnt = 1; }
        }
      }

      runByGameId[g.game_id] = {
        ats,
        atsRun: ats && ats !== 'P' ? runAtsCnt : 0,
        ou,
        ouRun: ou && ou !== 'P' ? runOuCnt : 0,
        myLine,
        role,
      };

      return { g, isHome, oppAbbr, mySc, oppSc, wl, ats, myLine, role, ou };
    });

    const desc = itemsAsc.slice().reverse();
    const wlSeq = desc.map((x) => x.wl);
    const atsSeq = desc.filter((x) => x.ats).map((x) => x.ats);
    const ouSeq = desc.filter((x) => x.ou).map((x) => x.ou);

    const wlStreak = countLeadingStreak(wlSeq);
    const atsStreak = countLeadingStreak(atsSeq);
    const ouStreak = countLeadingStreak(ouSeq);

    // Role / Venue notable streaks (>= 3 games)
    const homeAts = countLeadingStreak(desc.filter((x) => x.isHome && x.ats).map((x) => x.ats));
    const roadAts = countLeadingStreak(desc.filter((x) => !x.isHome && x.ats).map((x) => x.ats));
    const homeOu = countLeadingStreak(desc.filter((x) => x.isHome && x.ou).map((x) => x.ou));
    const roadOu = countLeadingStreak(desc.filter((x) => !x.isHome && x.ou).map((x) => x.ou));
    const favAts = countLeadingStreak(desc.filter((x) => x.role === 'FAV' && x.ats).map((x) => x.ats));
    const dogAts = countLeadingStreak(desc.filter((x) => x.role === 'DOG' && x.ats).map((x) => x.ats));

    const badges = [];
    if (atsStreak.count >= 2 && atsStreak.type === 'W') {
      badges.push({
        cls: 'hot-cover',
        major: atsStreak.count >= 3,
        text: `${atsStreak.count >= 3 ? '🔥' : '✅'} 連續 ${atsStreak.count} 場過讓`,
      });
    } else if (atsStreak.count >= 2 && atsStreak.type === 'L') {
      badges.push({
        cls: 'cold-loss',
        major: atsStreak.count >= 3,
        text: `${atsStreak.count >= 3 ? '❄️' : '⚠️'} 連續 ${atsStreak.count} 場輸盤`,
      });
    }

    if (ouStreak.count >= 2 && ouStreak.type === 'U') {
      badges.push({
        cls: 'hot-under',
        major: ouStreak.count >= 3,
        text: `${ouStreak.count >= 3 ? '🔵' : '🔹'} 連續 ${ouStreak.count} 場開小分`,
      });
    } else if (ouStreak.count >= 2 && ouStreak.type === 'O') {
      badges.push({
        cls: 'hot-over',
        major: ouStreak.count >= 3,
        text: `${ouStreak.count >= 3 ? '🔴' : '🔸'} 連續 ${ouStreak.count} 場開大分`,
      });
    }

    if (wlStreak.count >= 3 && wlStreak.type === 'W') {
      badges.push({ cls: 'su-win', major: true, text: `🏆 近期 ${wlStreak.count} 連勝` });
    } else if (wlStreak.count >= 3 && wlStreak.type === 'L') {
      badges.push({ cls: 'su-loss', major: true, text: `📉 近期 ${wlStreak.count} 連敗` });
    }

    // Split sub-badges (>= 3) when they add extra context beyond overall streak
    const splitBadges = [];
    if (favAts.count >= 3) {
      splitBadges.push(`⚔️ 讓分盤連 ${favAts.count} 場${favAts.type === 'W' ? '過盤' : '輸盤'}`);
    }
    if (dogAts.count >= 3) {
      splitBadges.push(`🛡️ 受讓盤連 ${dogAts.count} 場${dogAts.type === 'W' ? '過盤' : '輸盤'}`);
    }
    if (homeAts.count >= 3) {
      splitBadges.push(`🏠 主場連 ${homeAts.count} 場${homeAts.type === 'W' ? '過讓' : '輸盤'}`);
    }
    if (roadAts.count >= 3) {
      splitBadges.push(`✈️ 客場連 ${roadAts.count} 場${roadAts.type === 'W' ? '過讓' : '輸盤'}`);
    }
    if (homeOu.count >= 3) {
      splitBadges.push(`🏠 主場連開 ${homeOu.count} 場${homeOu.type === 'U' ? '小分' : '大分'}`);
    }
    if (roadOu.count >= 3) {
      splitBadges.push(`✈️ 客場連開 ${roadOu.count} 場${roadOu.type === 'U' ? '小分' : '大分'}`);
    }

    // Last 5 summary counts
    const l5Ats = atsSeq.slice(0, 5);
    const l5Ou = ouSeq.slice(0, 5);
    const l5Wl = wlSeq.slice(0, 5);

    return {
      finalsDesc: desc.map((x) => x.g),
      itemsDesc: desc,
      runByGameId,
      wlStreak,
      atsStreak,
      ouStreak,
      badges,
      splitBadges,
      l5Summary: {
        atsW: l5Ats.filter((x) => x === 'W').length,
        atsL: l5Ats.filter((x) => x === 'L').length,
        ouO: l5Ou.filter((x) => x === 'O').length,
        ouU: l5Ou.filter((x) => x === 'U').length,
        wlW: l5Wl.filter((x) => x === 'W').length,
        wlL: l5Wl.filter((x) => x === 'L').length,
      },
    };
  };

  function renderConfPills(teams, activeAbbr, streakMap) {
    const east = teams.filter((t) => t.conf === 'East');
    const west = teams.filter((t) => t.conf === 'West');
    const miniTag = (abbr) => {
      const st = streakMap[abbr];
      if (!st) return '';
      const tags = [];
      if (st.atsStreak.count >= 3) {
        tags.push(
          st.atsStreak.type === 'W'
            ? `<span class="tm-mini-stk ats-w">過${st.atsStreak.count}</span>`
            : `<span class="tm-mini-stk ats-l">輸${st.atsStreak.count}</span>`
        );
      }
      if (st.ouStreak.count >= 3) {
        tags.push(
          st.ouStreak.type === 'U'
            ? `<span class="tm-mini-stk ou-u">小${st.ouStreak.count}</span>`
            : `<span class="tm-mini-stk ou-o">大${st.ouStreak.count}</span>`
        );
      }
      return tags.join('');
    };
    const row = (lbl, arr) => `
      <div class="conf-row">
        <span class="conf-tag">${lbl}</span>
        ${arr.map((t) => `
          <a href="#/team/${NBA.esc(t.abbr)}" class="tm-pill ${t.abbr === activeAbbr ? 'active' : ''}" title="${NBA.esc(t.city_zh)} ${NBA.esc(t.zh)} (${NBA.esc(t.record)})">
            <img src="${NBA.esc(t.logo)}" alt="" loading="lazy">
            <span>${NBA.esc(t.zh)}</span>
            ${miniTag(t.abbr)}
          </a>`).join('')}
      </div>`;
    return `<div class="team-conf-strip">${row('東區 15', east)}${row('西區 15', west)}</div>`;
  }

  function renderLeagueStreakRadar(teams, activeAbbr, streakMap) {
    const coverHot = [];
    const coverCold = [];
    const underHot = [];
    const overHot = [];

    teams.forEach((t) => {
      const st = streakMap[t.abbr];
      if (!st) return;
      if (st.atsStreak.count >= 3 && st.atsStreak.type === 'W') coverHot.push({ t, n: st.atsStreak.count });
      if (st.atsStreak.count >= 3 && st.atsStreak.type === 'L') coverCold.push({ t, n: st.atsStreak.count });
      if (st.ouStreak.count >= 3 && st.ouStreak.type === 'U') underHot.push({ t, n: st.ouStreak.count });
      if (st.ouStreak.count >= 3 && st.ouStreak.type === 'O') overHot.push({ t, n: st.ouStreak.count });
    });

    coverHot.sort((a, b) => b.n - a.n);
    coverCold.sort((a, b) => b.n - a.n);
    underHot.sort((a, b) => b.n - a.n);
    overHot.sort((a, b) => b.n - a.n);

    if (!coverHot.length && !coverCold.length && !underHot.length && !overHot.length) return '';

    const chipList = (arr, suffix) => (arr.length
      ? `<div style="display:flex;gap:6px;flex-wrap:wrap">${arr.map(({ t, n }) => `
          <a href="#/team/${NBA.esc(t.abbr)}" class="streak-team-chip ${t.abbr === activeAbbr ? 'is-cur' : ''}">
            <img src="${NBA.esc(t.logo)}" alt="">
            <span>${NBA.esc(t.zh)}</span>
            <strong>連${n}${suffix}</strong>
          </a>`).join('')}</div>`
      : '<div style="font-size:12px;color:#94a3b8">目前無連 3 場以上球隊</div>');

    return `
      <div class="streak-radar-card">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
          <div style="font-size:13.5px;font-weight:800;color:#0f172a">🚨 全聯盟連續盤路雷達（自動標示連續 3 場以上過讓／輸盤／大分／小分球隊，點擊直接切換）</div>
          <span style="font-size:11.5px;color:#64748b">走水 (Push) 自動中斷重新計算</span>
        </div>
        <div class="streak-radar-grid">
          <div class="streak-radar-col">
            <div class="streak-radar-lbl" style="color:#15803d"><span>🔥 連續過讓 (≥3場)</span><span>${coverHot.length} 隊</span></div>
            ${chipList(coverHot, '過')}
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl" style="color:#be123c"><span>❄️ 連續輸盤 (≥3場)</span><span>${coverCold.length} 隊</span></div>
            ${chipList(coverCold, '輸')}
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl" style="color:#1d4ed8"><span>🔵 連續開小分 (≥3場)</span><span>${underHot.length} 隊</span></div>
            ${chipList(underHot, '小')}
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl" style="color:#c2410c"><span>🔴 連續開大分 (≥3場)</span><span>${overHot.length} 隊</span></div>
            ${chipList(overHot, '大')}
          </div>
        </div>
      </div>`;
  }

  function renderTeamTrendStrip(tm, st) {
    const recent10 = st.itemsDesc.slice(0, 10);

    // 1) ATS Box
    let atsAlertCls = '';
    let atsHeadline = '尚無完賽讓分盤紀錄';
    if (st.atsStreak.count >= 3 && st.atsStreak.type === 'W') {
      atsAlertCls = 'alert-cover';
      atsHeadline = `🔥 連續 ${st.atsStreak.count} 場過讓`;
    } else if (st.atsStreak.count >= 3 && st.atsStreak.type === 'L') {
      atsAlertCls = 'alert-loss';
      atsHeadline = `❄️ 連續 ${st.atsStreak.count} 場輸盤`;
    } else if (st.atsStreak.count === 2) {
      atsHeadline = st.atsStreak.type === 'W' ? '✅ 連續 2 場過讓' : '⚠️ 連續 2 場輸盤';
    } else if (st.atsStreak.count === 1) {
      atsHeadline = st.atsStreak.type === 'W' ? '近 1 場過讓（無連莊）' : st.atsStreak.type === 'L' ? '近 1 場輸盤（無連莊）' : '最新一場讓分走水';
    }

    // 2) O/U Box
    let ouAlertCls = '';
    let ouHeadline = '尚無完賽大小分紀錄';
    if (st.ouStreak.count >= 3 && st.ouStreak.type === 'U') {
      ouAlertCls = 'alert-under';
      ouHeadline = `🔵 連續 ${st.ouStreak.count} 場開小分`;
    } else if (st.ouStreak.count >= 3 && st.ouStreak.type === 'O') {
      ouAlertCls = 'alert-over';
      ouHeadline = `🔴 連續 ${st.ouStreak.count} 場開大分`;
    } else if (st.ouStreak.count === 2) {
      ouHeadline = st.ouStreak.type === 'U' ? '🔹 連續 2 場開小分' : '🔸 連續 2 場開大分';
    } else if (st.ouStreak.count === 1) {
      ouHeadline = st.ouStreak.type === 'U' ? '近 1 場開小分（無連莊）' : st.ouStreak.type === 'O' ? '近 1 場開大分（無連莊）' : '最新一場大小走水';
    }

    // 3) W/L Box
    let wlHeadline = '尚無完賽紀錄';
    if (st.wlStreak.count >= 2) {
      wlHeadline = st.wlStreak.type === 'W' ? `🏆 近期 ${st.wlStreak.count} 連勝` : `📉 近期 ${st.wlStreak.count} 連敗`;
    } else if (st.wlStreak.count === 1) {
      wlHeadline = st.wlStreak.type === 'W' ? '近 1 場獲勝' : '近 1 場落敗';
    }

    const atsDots = recent10.filter((x) => x.ats).map((x) => {
      const opp = NBA.teamOf(x.oppAbbr).zh;
      const tip = `${x.g.tw_date} ${x.isHome ? 'vs' : '@'} ${opp} (${x.mySc}:${x.oppSc}) · 盤口 ${NBA.fmtSpread(x.myLine)}`;
      const cls = x.ats === 'W' ? 'w' : x.ats === 'L' ? 'l' : 'p';
      const ch = x.ats === 'W' ? '過' : x.ats === 'L' ? '輸' : '走';
      return `<span class="t-dot ${cls}" data-pick-gid="${NBA.esc(x.g.game_id)}" title="${NBA.esc(tip)}">${ch}</span>`;
    }).join('');

    const ouDots = recent10.filter((x) => x.ou).map((x) => {
      const opp = NBA.teamOf(x.oppAbbr).zh;
      const tip = `${x.g.tw_date} ${x.isHome ? 'vs' : '@'} ${opp} · 總分 ${x.g.total_points} / 盤口 ${x.g.close_total}`;
      const cls = x.ou === 'U' ? 'u' : x.ou === 'O' ? 'o' : 'p';
      const ch = x.ou === 'U' ? '小' : x.ou === 'O' ? '大' : '走';
      return `<span class="t-dot ${cls}" data-pick-gid="${NBA.esc(x.g.game_id)}" title="${NBA.esc(tip)}">${ch}</span>`;
    }).join('');

    const wlDots = recent10.map((x) => {
      const opp = NBA.teamOf(x.oppAbbr).zh;
      const tip = `${x.g.tw_date} ${x.isHome ? 'vs' : '@'} ${opp} · ${x.mySc}:${x.oppSc}`;
      const cls = x.wl === 'W' ? 'w' : 'l';
      const ch = x.wl === 'W' ? '勝' : '敗';
      return `<span class="t-dot ${cls}" data-pick-gid="${NBA.esc(x.g.game_id)}" title="${NBA.esc(tip)}">${ch}</span>`;
    }).join('');

    return `
      <div class="trend-strip-grid">
        <div class="trend-box ${atsAlertCls}">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <span style="font-size:12px;font-weight:800;color:#475569">🎯 讓分盤連續走勢 (ATS)</span>
            <span style="font-size:11.5px;color:#64748b">近5場 ${st.l5Summary.atsW}過-${st.l5Summary.atsL}輸</span>
          </div>
          <div style="font-size:16px;font-weight:900;color:#0f172a">${atsHeadline}</div>
          <div class="trend-dots">
            <span style="font-size:11px;color:#64748b;font-weight:700">最新←</span>
            ${atsDots || '<span style="font-size:12px;color:#94a3b8">無資料</span>'}
          </div>
        </div>

        <div class="trend-box ${ouAlertCls}">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <span style="font-size:12px;font-weight:800;color:#475569">⚖️ 大小分連續走勢 (O/U)</span>
            <span style="font-size:11.5px;color:#64748b">近5場 ${st.l5Summary.ouO}大-${st.l5Summary.ouU}小</span>
          </div>
          <div style="font-size:16px;font-weight:900;color:#0f172a">${ouHeadline}</div>
          <div class="trend-dots">
            <span style="font-size:11px;color:#64748b;font-weight:700">最新←</span>
            ${ouDots || '<span style="font-size:12px;color:#94a3b8">無資料</span>'}
          </div>
        </div>

        <div class="trend-box">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <span style="font-size:12px;font-weight:800;color:#475569">🏀 勝負連勝連敗走勢</span>
            <span style="font-size:11.5px;color:#64748b">近5場 ${st.l5Summary.wlW}勝-${st.l5Summary.wlL}敗</span>
          </div>
          <div style="font-size:16px;font-weight:900;color:#0f172a">${wlHeadline}</div>
          <div class="trend-dots">
            <span style="font-size:11px;color:#64748b;font-weight:700">最新←</span>
            ${wlDots || '<span style="font-size:12px;color:#94a3b8">無資料</span>'}
          </div>
        </div>
      </div>`;
  }

  function renderGamesAndBoxscoreTab(snap, tm, teamGames, st) {
    const finals = st.finalsDesc;
    const upcoming = teamGames.filter((g) => g.status !== 'FINAL');

    if (finals.length && (!NBA.state.teamGameId || !finals.some((g) => g.game_id === NBA.state.teamGameId))) {
      NBA.state.teamGameId = finals[0].game_id;
    }
    const selGid = NBA.state.teamGameId;
    const selGame = finals.find((g) => g.game_id === selGid) || null;

    const upcomingHtml = upcoming.length ? `
      <div class="card" style="margin-bottom:14px;background:#f8fbff;border-color:#bfdbfe;padding:11px 15px">
        <div style="font-size:12.5px;font-weight:800;color:#1e40af;margin-bottom:6px">⏭️ 近期即將開打賽程（共 ${upcoming.length} 場）</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          ${upcoming.map((g) => {
            const isHome = g.home_abbr === tm.abbr;
            const opp = NBA.teamOf(isHome ? g.away_abbr : g.home_abbr);
            const mySp = g.close_spread_home != null ? (isHome ? g.close_spread_home : -g.close_spread_home) : null;
            return `
              <div class="card" style="padding:7px 11px;display:inline-flex;align-items:center;gap:8px;font-size:12.5px">
                <span class="chip info">${NBA.esc(g.tipoff_tw.slice(5))}</span>
                <span>${isHome ? '主場 vs' : '客場 @'} <strong class="tm-link" data-team-link="${NBA.esc(opp.abbr)}">${NBA.esc(opp.zh)}</strong></span>
                <span style="color:#64748b">${mySp != null ? `讓分 ${NBA.fmtSpread(mySp)}` : '待開盤'}${g.close_total ? ` · 大小 ${g.close_total}` : ''}</span>
              </div>`;
          }).join('')}
        </div>
      </div>` : '';

    const pastTableHtml = `
      <div class="card" style="margin-bottom:14px">
        <div class="sec-hdr" style="margin-bottom:10px">
          <div>
            <h2 class="sec-title" style="font-size:15.5px">📅 ${NBA.esc(tm.zh)} 過往完賽比數 ＆ 連續盤路紀錄（共 ${finals.length} 場）</h2>
            <div class="sec-sub">由新到舊排列；每列自動標記當下累計「連 N 場過讓／輸盤」與「連 N 場大分／小分」，點選任一場次列即可在下方檢視雙方球員單場數據</div>
          </div>
          <span class="odds-rule-pill">🕚 讓分盤（Spread）與大小分（O/U）固定抓每天晚上 11 點資訊</span>
        </div>
        <div class="tbl-wrap">
          <table class="data-tbl">
            <thead>
              <tr>
                <th>台灣完賽日</th>
                <th>主客 ＆ 對戰對手</th>
                <th>勝負 ＆ 最終比數</th>
                <th>各節比分 (Q1-Q4)</th>
                <th>本隊讓分盤結果（連續場次）</th>
                <th>大小分結果（連續場次）</th>
                <th class="num">單場球員數據</th>
              </tr>
            </thead>
            <tbody>
              ${finals.map((g) => {
                const isHome = g.home_abbr === tm.abbr;
                const oppAbbr = isHome ? g.away_abbr : g.home_abbr;
                const opp = NBA.teamOf(oppAbbr);
                const mySc = isHome ? g.home_score : g.away_score;
                const oppSc = isHome ? g.away_score : g.home_score;
                const win = mySc > oppSc;
                const myQ = (isHome ? g.home_q_scores : g.away_q_scores) || [];
                const oppQ = (isHome ? g.away_q_scores : g.home_q_scores) || [];
                const rInfo = st.runByGameId[g.game_id] || {};

                let myAtsHtml = '<span class="chip muted">無盤口</span>';
                if (g.close_spread_home != null && g.ats_winner) {
                  const myLine = isHome ? g.close_spread_home : -g.close_spread_home;
                  const roleLbl = myLine < 0 ? '讓' : myLine > 0 ? '受讓' : 'PK';
                  const covered = (isHome && g.ats_winner === 'HOME') || (!isHome && g.ats_winner === 'AWAY');
                  if (g.ats_winner === 'PUSH') {
                    myAtsHtml = `<span class="chip warn">➖ 走水 (${roleLbl} ${NBA.fmtSpread(myLine)})</span>`;
                  } else {
                    let stkTag = '';
                    if (rInfo.atsRun >= 3) {
                      stkTag = covered
                        ? `<span class="row-stk-tag s3-cover">🔥連${rInfo.atsRun}過讓</span>`
                        : `<span class="row-stk-tag s3-loss">❄️連${rInfo.atsRun}輸盤</span>`;
                    } else if (rInfo.atsRun === 2) {
                      stkTag = covered
                        ? '<span class="row-stk-tag s2-cover">連2過</span>'
                        : '<span class="row-stk-tag s2-loss">連2輸</span>';
                    }
                    myAtsHtml = `<span class="chip ${covered ? 'ok' : 'bad'}">${covered ? '✅ 過盤' : '❌ 輸盤'} (${roleLbl} ${NBA.fmtSpread(myLine)})</span>${stkTag}`;
                  }
                }

                let ouHtml = '<span class="chip muted">無盤口</span>';
                if (g.close_total && g.ou_result) {
                  let ouStkTag = '';
                  if (rInfo.ouRun >= 3) {
                    ouStkTag = g.ou_result === 'UNDER'
                      ? `<span class="row-stk-tag s3-under">🔵連${rInfo.ouRun}小分</span>`
                      : `<span class="row-stk-tag s3-over">🔴連${rInfo.ouRun}大分</span>`;
                  } else if (rInfo.ouRun === 2) {
                    ouStkTag = g.ou_result === 'UNDER'
                      ? '<span class="row-stk-tag s2-under">連2小</span>'
                      : '<span class="row-stk-tag s2-over">連2大</span>';
                  }
                  ouHtml = `<span class="chip ${g.ou_result === 'OVER' ? 'strong' : 'info'}">${g.ou_result === 'OVER' ? '🔴 大分' : g.ou_result === 'UNDER' ? '🔵 小分' : '➖ 走水'} (${g.total_points}/${g.close_total})</span>${ouStkTag}`;
                }

                const isSel = g.game_id === selGid;
                return `
                  <tr class="${isSel ? 'game-row-sel' : ''}" data-sel-gid="${NBA.esc(g.game_id)}" style="cursor:pointer">
                    <td style="white-space:nowrap">
                      <strong>${NBA.esc(g.tw_date)}</strong>
                      <div style="font-size:11px;color:#64748b">美東 ${NBA.esc(g.et_date.slice(5))}</div>
                    </td>
                    <td>
                      <div style="display:flex;align-items:center;gap:7px">
                        <span class="chip muted">${isHome ? '主場 vs' : '客場 @'}</span>
                        <img src="${NBA.esc(opp.logo)}" alt="" style="width:22px;height:22px;object-fit:contain">
                        <strong class="tm-link" data-team-link="${NBA.esc(oppAbbr)}">${NBA.esc(opp.zh)} (${NBA.esc(oppAbbr)})</strong>
                      </div>
                    </td>
                    <td>
                      <span class="chip ${win ? 'ok' : 'bad'}" style="font-size:12.5px">
                        ${win ? '勝 W' : '敗 L'} · ${mySc} : ${oppSc}
                      </span>
                      <span style="font-size:11.5px;color:#64748b;margin-left:4px">(${mySc - oppSc > 0 ? '+' + (mySc - oppSc) : (mySc - oppSc)} 分)</span>
                    </td>
                    <td style="font-size:12px;color:#334155">
                      <div>${NBA.esc(tm.zh)}：${myQ.join(' - ') || '—'}</div>
                      <div style="color:#64748b">${NBA.esc(opp.zh)}：${oppQ.join(' - ') || '—'}</div>
                    </td>
                    <td style="white-space:nowrap">${myAtsHtml}</td>
                    <td style="white-space:nowrap">${ouHtml}</td>
                    <td class="num">
                      <button type="button" class="btn btn-sm ${isSel ? 'btn-primary' : 'btn-soft'}" data-pick-gid="${NBA.esc(g.game_id)}">
                        ${isSel ? '👇 顯示中' : '📊 看球員數據'}
                      </button>
                    </td>
                  </tr>`;
              }).join('') || '<tr><td colspan="7" style="text-align:center;padding:24px;color:#64748b">尚無本季完賽紀錄</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>`;

    let boxPaneHtml = '';
    if (selGame) {
      const oppAbbr = selGame.home_abbr === tm.abbr ? selGame.away_abbr : selGame.home_abbr;
      const oppTm = NBA.teamOf(oppAbbr);
      const side = NBA.state.teamBoxSide || 'BOTH';
      boxPaneHtml = `
        <div id="teamBoxAnchor">
          <div class="sec-hdr" style="margin-bottom:8px">
            <div>
              <h2 class="sec-title" style="font-size:16px">📊 單場每位球員數據 Boxscore · ${NBA.esc(NBA.teamOf(selGame.away_abbr).zh)} @ ${NBA.esc(NBA.teamOf(selGame.home_abbr).zh)} (${NBA.esc(selGame.tw_date)})</h2>
            </div>
            <div class="sub-tabs" style="margin-bottom:0">
              <button type="button" class="sub-tab ${side === 'BOTH' ? 'active' : ''}" data-bside="BOTH">雙方球員並列</button>
              <button type="button" class="sub-tab ${side === tm.abbr ? 'active' : ''}" data-bside="${NBA.esc(tm.abbr)}">僅看 ${NBA.esc(tm.zh)}</button>
              <button type="button" class="sub-tab ${side === oppAbbr ? 'active' : ''}" data-bside="${NBA.esc(oppAbbr)}">僅看 ${NBA.esc(oppTm.zh)}</button>
            </div>
          </div>
          ${NBA.renderGameBoxscoreHtml(selGame.game_id, side)}
        </div>`;
    }

    return upcomingHtml + pastTableHtml + boxPaneHtml;
  }

  function renderTeamRosterTab(snap, tm) {
    const sortKey = NBA.state.teamRosterSort || 'pts';
    const roster = (snap.player_stats || [])
      .filter((p) => p.team === tm.abbr)
      .slice()
      .sort((a, b) => Number(b[sortKey] ?? 0) - Number(a[sortKey] ?? 0));

    const cols = [
      ['gp', 'GP'], ['gs', 'GS'], ['min', 'MIN'], ['pts', 'PTS'],
      ['fgm', 'FGM'], ['fga', 'FGA'], ['fg_pct', 'FG%'],
      ['tpm', '3PM'], ['tpa', '3PA'], ['tp_pct', '3P%'],
      ['ftm', 'FTM'], ['fta', 'FTA'], ['ft_pct', 'FT%'],
      ['oreb', 'OREB'], ['dreb', 'DREB'], ['reb', 'REB'],
      ['ast', 'AST'], ['tov', 'TOV'], ['stl', 'STL'], ['blk', 'BLK'],
      ['pf', 'PF'], ['fp', 'FP'], ['dd2', 'DD2'], ['td3', 'TD3'], ['pm', '+/-'],
    ];

    return `
      <div class="card">
        <div class="sec-hdr" style="margin-bottom:10px">
          <div>
            <h2 class="sec-title" style="font-size:15.5px">👥 ${NBA.esc(tm.zh)} 全隊球員本季場均數據（共 ${roster.length} 人）</h2>
            <div class="sec-sub">點擊任一欄位標題可重新排序；點擊「球員姓名」可彈出該球員本季每一場比賽的逐場數據明細</div>
          </div>
        </div>
        <div class="nba-tbl-wrap standalone">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="sticky-rk no-sort">#</th>
                <th class="left sticky-pl no-sort">PLAYER 球員</th>
                <th class="no-sort">POS</th>
                <th class="no-sort">AGE</th>
                ${cols.map(([k, lbl]) => `<th class="${sortKey === k ? 'col-active' : ''}" data-rsort="${k}">${lbl}${sortKey === k ? ' ▼' : ''}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${roster.map((p, idx) => `
                <tr>
                  <td class="sticky-rk">${idx + 1}</td>
                  <td class="left sticky-pl">
                    <div style="display:flex;align-items:center;gap:7px">
                      <img class="pl-head-sm" src="${NBA.esc(p.headshot)}" alt="" loading="lazy" onerror="this.style.display='none'">
                      <span class="pl-link" data-player-id="${NBA.esc(p.pid)}" style="font-weight:700;color:#1d4ed8">${NBA.esc(p.name)}</span>
                      ${p.jersey ? `<span style="color:#94a3b8;font-size:11px">#${NBA.esc(p.jersey)}</span>` : ''}
                    </div>
                  </td>
                  <td>${NBA.esc(p.pos || '—')}</td>
                  <td>${p.age || '—'}</td>
                  ${cols.map(([k]) => {
                    const v = p[k];
                    const isInt = ['gp', 'gs', 'dd2', 'td3'].includes(k);
                    const txt = v == null ? '—' : isInt ? v : Number(v).toFixed(1);
                    return `<td class="${sortKey === k ? 'col-active' : ''}">${k === 'pm' && v > 0 ? '+' + txt : txt}</td>`;
                  }).join('')}
                </tr>`).join('') || '<tr><td colspan="29" style="text-align:center;padding:24px;color:#64748b">尚無球員出場統計</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>`;
  }

  NBA.pages.team = function (root) {
    const snap = NBA.snap;
    const teams = snap.teams || [];
    const activeAbbr = NBA.teamMap[NBA.state.activeTeam] ? NBA.state.activeTeam : (teams[0] && teams[0].abbr) || 'LAL';
    NBA.state.activeTeam = activeAbbr;
    const tm = NBA.teamOf(activeAbbr);
    const tab = NBA.state.teamTab || 'games';

    const streakMap = {};
    teams.forEach((t) => {
      streakMap[t.abbr] = NBA.computeTeamStreaks(snap, t.abbr);
    });
    const st = streakMap[activeAbbr] || NBA.computeTeamStreaks(snap, activeAbbr);

    const teamGames = (snap.games || []).filter((g) => g.home_abbr === activeAbbr || g.away_abbr === activeAbbr);
    const teamInj = (snap.injuries || []).filter((x) => x.team_abbr === activeAbbr);

    const heroBadgesHtml = (st.badges.length || st.splitBadges.length) ? `
      <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:8px">
        ${st.badges.map((b) => `<span class="stk-badge ${b.cls}">${NBA.esc(b.text)}</span>`).join('')}
        ${st.splitBadges.map((txt) => `<span class="stk-badge sub-split">${NBA.esc(txt)}</span>`).join('')}
      </div>` : '';

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🏀 NBA 30 隊球隊專區 · 過往比數、連續盤路標示與球員逐場數據</h1>
          <div class="sec-sub">自動偵測並標示「連續過讓／輸盤」與「連續開大分／小分」趨勢，並可展開每一場比賽每位球員的完整數據</div>
        </div>
        <select class="inp" id="teamQuickSel" style="font-weight:700">
          ${teams.map((t) => `<option value="${NBA.esc(t.abbr)}" ${t.abbr === activeAbbr ? 'selected' : ''}>${NBA.esc(t.city_zh)} ${NBA.esc(t.zh)} (${NBA.esc(t.abbr)}) · ${NBA.esc(t.record)}</option>`).join('')}
        </select>
      </div>

      ${renderConfPills(teams, activeAbbr, streakMap)}
      ${renderLeagueStreakRadar(teams, activeAbbr, streakMap)}

      <div class="team-hero">
        <div class="team-hero-left">
          <img class="team-hero-logo" src="${NBA.esc(tm.logo)}" alt="${NBA.esc(tm.zh)}">
          <div>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <h2 style="margin:0;font-size:22px;font-weight:900">${NBA.esc(tm.city_zh || '')} ${NBA.esc(tm.zh)}</h2>
              <span class="chip info">${NBA.esc(tm.en)} · ${NBA.esc(tm.abbr)}</span>
              <span class="chip muted">${tm.conf === 'East' ? '東區聯盟' : '西區聯盟'}</span>
            </div>
            <div style="font-size:13px;color:#475569;margin-top:5px;display:flex;gap:12px;flex-wrap:wrap">
              <span>主場戰績：<strong>${NBA.esc(tm.home_record || '-')}</strong></span>
              <span>客場戰績：<strong>${NBA.esc(tm.road_record || '-')}</strong></span>
              <span>近10場：<strong>${NBA.esc(tm.l10 || '-')}</strong></span>
              <span>近況連勝敗：<strong>${NBA.esc(tm.streak || '-')}</strong></span>
            </div>
            ${heroBadgesHtml}
            ${teamInj.length ? `
              <div class="inj-strip" style="margin-top:8px">
                <strong style="font-size:11.5px;color:#475569">🚑 目前傷兵名單：</strong>
                ${teamInj.map((it) => `<span class="inj-pill ${it.play_prob_next === 0 ? '' : it.play_prob_next <= 60 ? 'gtd' : 'prob'}">${NBA.esc(it.player_name)} (${NBA.esc(it.status_zh)} · ${it.play_prob_next}%)</span>`).join('')}
              </div>` : ''}
          </div>
        </div>

        <div class="team-hero-stats">
          <div class="th-stat">
            <div class="th-stat-lbl">例行賽戰績</div>
            <div class="th-stat-val">${NBA.esc(tm.record)}</div>
          </div>
          <div class="th-stat">
            <div class="th-stat-lbl">場均得分 / 失分</div>
            <div class="th-stat-val">${Number(tm.ppg || 0).toFixed(1)} / ${Number(tm.opp_ppg || 0).toFixed(1)}</div>
          </div>
          <div class="th-stat">
            <div class="th-stat-lbl">場均淨勝分</div>
            <div class="th-stat-val" style="color:${(tm.diff || 0) >= 0 ? '#15803d' : '#b91c1c'}">${NBA.fmtSigned(tm.diff, 1)}</div>
          </div>
          <div class="th-stat">
            <div class="th-stat-lbl">讓分過盤戰績 (ATS)</div>
            <div class="th-stat-val" style="color:#1d4ed8">${tm.ats_w}-${tm.ats_l}${tm.ats_p ? '-' + tm.ats_p : ''} (${Number(tm.ats_pct || 0).toFixed(0)}%)</div>
          </div>
          <div class="th-stat">
            <div class="th-stat-lbl">大小分 (大-小)</div>
            <div class="th-stat-val">${tm.ou_over}大-${tm.ou_under}小 (${Number(tm.over_pct || 0).toFixed(0)}%大)</div>
          </div>
        </div>
      </div>

      ${renderTeamTrendStrip(tm, st)}

      <div class="sub-tabs">
        <button type="button" class="sub-tab ${tab === 'games' ? 'active' : ''}" data-ttab="games">📅 過往比賽比數 ＆ 單場球員數據</button>
        <button type="button" class="sub-tab ${tab === 'roster' ? 'active' : ''}" data-ttab="roster">👥 全隊球員本季場均 ＆ 個人逐場明細</button>
      </div>

      ${tab === 'games' ? renderGamesAndBoxscoreTab(snap, tm, teamGames, st) : renderTeamRosterTab(snap, tm)}
    `;

    const sel = document.getElementById('teamQuickSel');
    if (sel) {
      sel.onchange = () => {
        window.location.hash = `#/team/${sel.value}`;
      };
    }
    root.querySelectorAll('[data-ttab]').forEach((b) => {
      b.onclick = () => {
        NBA.state.teamTab = b.getAttribute('data-ttab');
        NBA.render();
      };
    });
    root.querySelectorAll('[data-sel-gid]').forEach((tr) => {
      tr.onclick = (ev) => {
        if (ev.target.closest('[data-team-link]')) return;
        NBA.state.teamGameId = tr.getAttribute('data-sel-gid');
        NBA.state.teamBoxSide = 'BOTH';
        NBA.render();
      };
    });
    root.querySelectorAll('[data-pick-gid]').forEach((btn) => {
      btn.onclick = (ev) => {
        ev.stopPropagation();
        NBA.state.teamGameId = btn.getAttribute('data-pick-gid');
        NBA.state.teamBoxSide = 'BOTH';
        NBA.state.teamTab = 'games';
        NBA.render();
        const boxEl = document.getElementById('teamBoxAnchor');
        if (boxEl) boxEl.scrollIntoView({ behavior: 'auto', block: 'start' });
      };
    });
    root.querySelectorAll('[data-bside]').forEach((b) => {
      b.onclick = () => {
        NBA.state.teamBoxSide = b.getAttribute('data-bside');
        NBA.render();
      };
    });
    root.querySelectorAll('[data-rsort]').forEach((th) => {
      th.onclick = () => {
        NBA.state.teamRosterSort = th.getAttribute('data-rsort');
        NBA.render();
      };
    });
  };
})();
