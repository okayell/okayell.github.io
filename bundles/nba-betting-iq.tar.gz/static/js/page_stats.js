/* Page: 🏆 NBA.com 風格全聯盟數據排行榜 ＆ 各項數據領先者 (#/stats) */
(function () {
  'use strict';
  const NBA = window.NBA;
  const PAGE_SIZE = 50;

  // Exact 28-column NBA.com Traditional Player Stats layout
  const PLAYER_COLS = [
    { key: 'age', label: 'AGE', tip: '年齡', int: true },
    { key: 'gp', label: 'GP', tip: '出賽場次 Games Played', int: true },
    { key: 'w', label: 'W', tip: '勝場 Wins', int: true },
    { key: 'l', label: 'L', tip: '敗場 Losses', int: true },
    { key: 'min', label: 'MIN', tip: '上場分鐘數 Minutes' },
    { key: 'pts', label: 'PTS', tip: '得分 Points' },
    { key: 'fgm', label: 'FGM', tip: '投籃命中數 Field Goals Made', blue: true },
    { key: 'fga', label: 'FGA', tip: '投籃出手數 Field Goals Attempted', blue: true },
    { key: 'fg_pct', label: 'FG%', tip: '投籃命中率 Field Goal %' },
    { key: 'tpm', label: '3PM', tip: '三分球命中數 3-Pointers Made', blue: true },
    { key: 'tpa', label: '3PA', tip: '三分球出手數 3-Pointers Attempted', blue: true },
    { key: 'tp_pct', label: '3P%', tip: '三分球命中率 3-Point %' },
    { key: 'ftm', label: 'FTM', tip: '罰球命中數 Free Throws Made' },
    { key: 'fta', label: 'FTA', tip: '罰球出手數 Free Throws Attempted' },
    { key: 'ft_pct', label: 'FT%', tip: '罰球命中率 Free Throw %' },
    { key: 'oreb', label: 'OREB', tip: '進攻籃板 Offensive Rebounds' },
    { key: 'dreb', label: 'DREB', tip: '防守籃板 Defensive Rebounds' },
    { key: 'reb', label: 'REB', tip: '總籃板 Rebounds' },
    { key: 'ast', label: 'AST', tip: '助攻 Assists' },
    { key: 'tov', label: 'TOV', tip: '失誤 Turnovers' },
    { key: 'stl', label: 'STL', tip: '抄截 Steals' },
    { key: 'blk', label: 'BLK', tip: '阻攻 Blocks' },
    { key: 'pf', label: 'PF', tip: '犯規 Personal Fouls' },
    { key: 'fp', label: 'FP', tip: 'NBA 官方幻想積分 Fantasy Points (PTS+1.2REB+1.5AST+3STL+3BLK-TOV)' },
    { key: 'dd2', label: 'DD2', tip: '雙十次數 Double-Doubles', dec1: true },
    { key: 'td3', label: 'TD3', tip: '大三元次數 Triple-Doubles', dec1: true },
    { key: 'pm', label: '+/-', tip: '在場正負值 Plus/Minus', signed: true },
  ];

  const TEAM_COLS = [
    { key: 'gp', label: 'GP', tip: '已賽場數', int: true },
    { key: 'w', label: 'W', tip: '勝場', int: true },
    { key: 'l', label: 'L', tip: '敗場', int: true },
    { key: 'win_pct', label: 'WIN%', tip: '勝率 %' },
    { key: 'pts', label: 'PTS', tip: '得分' },
    { key: 'opp_pts', label: 'OPP PTS', tip: '對手得分（防守失分）' },
    { key: 'fgm', label: 'FGM', tip: '投籃命中', blue: true },
    { key: 'fga', label: 'FGA', tip: '投籃出手', blue: true },
    { key: 'fg_pct', label: 'FG%', tip: '投籃命中率 %' },
    { key: 'tpm', label: '3PM', tip: '三分命中', blue: true },
    { key: 'tpa', label: '3PA', tip: '三分出手', blue: true },
    { key: 'tp_pct', label: '3P%', tip: '三分命中率 %' },
    { key: 'ftm', label: 'FTM', tip: '罰球命中' },
    { key: 'fta', label: 'FTA', tip: '罰球出手' },
    { key: 'ft_pct', label: 'FT%', tip: '罰球命中率 %' },
    { key: 'oreb', label: 'OREB', tip: '進攻籃板' },
    { key: 'dreb', label: 'DREB', tip: '防守籃板' },
    { key: 'reb', label: 'REB', tip: '總籃板' },
    { key: 'ast', label: 'AST', tip: '助攻' },
    { key: 'tov', label: 'TOV', tip: '失誤' },
    { key: 'stl', label: 'STL', tip: '抄截' },
    { key: 'blk', label: 'BLK', tip: '阻攻' },
    { key: 'pf', label: 'PF', tip: '犯規' },
    { key: 'pm', label: '+/-', tip: '場均淨勝分差', signed: true },
    { key: 'ats_pct', label: 'ATS%', tip: '本季讓分過盤率 %' },
    { key: 'over_pct', label: 'OVER%', tip: '本季大分開出率 %' },
  ];

  function playerMetricValue(p, key, perMode) {
    if (['age', 'gp', 'w', 'l', 'fg_pct', 'tp_pct', 'ft_pct', 'dd2', 'td3'].includes(key)) {
      return p[key] ?? 0;
    }
    if (perMode === 'totals') {
      return (p.tot && p.tot[key] != null) ? p.tot[key] : p[key];
    }
    if (perMode === 'per36') {
      const totMin = (p.tot && p.tot.min) || 0;
      if (totMin <= 0) return 0;
      if (key === 'min') return 36.0;
      const totVal = (p.tot && p.tot[key] != null) ? p.tot[key] : 0;
      return +((totVal / totMin) * 36.0).toFixed(1);
    }
    return p[key] ?? 0;
  }

  function teamMetricValue(t, key, perMode) {
    if (['gp', 'w', 'l', 'win_pct', 'opp_pts', 'fg_pct', 'tp_pct', 'ft_pct', 'pm', 'ats_pct', 'over_pct'].includes(key)) {
      return t[key] ?? 0;
    }
    if (perMode === 'totals' && t.tot && t.tot[key] != null) {
      return t.tot[key];
    }
    return t[key] ?? 0;
  }

  function fmtCell(val, col, perMode) {
    if (val == null || val === '') return '—';
    const n = Number(val);
    if (Number.isNaN(n)) return '—';
    if (col.int) return String(Math.round(n));
    if (perMode === 'totals' && !['fg_pct', 'tp_pct', 'ft_pct', 'win_pct', 'ats_pct', 'over_pct', 'fp'].includes(col.key)) {
      return col.signed && n > 0 ? '+' + Math.round(n) : String(Math.round(n));
    }
    if (col.dec1) return n.toFixed(1);
    const s = n.toFixed(1);
    return col.signed && n > 0 ? '+' + s : s;
  }

  function renderPlayersTable(snap) {
    const perMode = NBA.state.statsPerMode || 'per_game';
    const scope = NBA.state.statsScope || 'all';
    const tmFilter = NBA.state.statsTeam || 'ALL';
    const posFilter = NBA.state.statsPos || 'ALL';
    const q = (NBA.state.statsSearch || '').trim().toLowerCase();
    const sortKey = NBA.state.statsSort || 'pts';
    const sortDir = NBA.state.statsDir || 'desc';

    const filtered = (snap.player_stats || []).filter((p) => {
      if (scope === 'qual' && !p.qual) return false;
      if (tmFilter !== 'ALL' && p.team !== tmFilter) return false;
      if (posFilter !== 'ALL' && !(p.pos || '').toUpperCase().includes(posFilter)) return false;
      if (q) {
        const tm = NBA.teamOf(p.team);
        const hay = `${p.name} ${p.team} ${tm.zh} ${tm.en}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    filtered.sort((a, b) => {
      const va = Number(playerMetricValue(a, sortKey, perMode) ?? -999);
      const vb = Number(playerMetricValue(b, sortKey, perMode) ?? -999);
      if (va !== vb) return sortDir === 'desc' ? (vb - va) : (va - vb);
      return Number(b.pts || 0) - Number(a.pts || 0);
    });

    const totalRows = filtered.length;
    const totalPages = Math.max(1, Math.ceil(totalRows / PAGE_SIZE));
    const page = Math.min(Math.max(1, NBA.state.statsPage || 1), totalPages);
    NBA.state.statsPage = page;
    const slice = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

    return `
      <div class="stats-filter-grid">
        <div class="sf-field">
          <span class="sf-lbl">SEASON 球季</span>
          <select class="inp" disabled><option>${NBA.esc((snap.meta && snap.meta.season_label) || '2026-27')} Regular Season</option></select>
        </div>
        <div class="sf-field">
          <span class="sf-lbl">PER MODE 統計模式</span>
          <select class="inp" id="stPerModeSel">
            <option value="per_game" ${perMode === 'per_game' ? 'selected' : ''}>Per Game（場均數據）</option>
            <option value="totals" ${perMode === 'totals' ? 'selected' : ''}>Totals（球季總計）</option>
            <option value="per36" ${perMode === 'per36' ? 'selected' : ''}>Per 36 Minutes（每36分鐘）</option>
          </select>
        </div>
        <div class="sf-field">
          <span class="sf-lbl">SCOPE 出賽門檻</span>
          <select class="inp" id="stScopeSel">
            <option value="all" ${scope === 'all' ? 'selected' : ''}>All Players（全部出場球員）</option>
            <option value="qual" ${scope === 'qual' ? 'selected' : ''}>Qualified（符合出賽門檻）</option>
          </select>
        </div>
        <div class="sf-field">
          <span class="sf-lbl">TEAM 所屬球隊</span>
          <select class="inp" id="stTeamSel">
            <option value="ALL">All 30 Teams（全部球隊）</option>
            ${(snap.teams || []).map((t) => `<option value="${NBA.esc(t.abbr)}" ${tmFilter === t.abbr ? 'selected' : ''}>${NBA.esc(t.zh)} (${NBA.esc(t.abbr)})</option>`).join('')}
          </select>
        </div>
        <div class="sf-field">
          <span class="sf-lbl">POSITION 位置</span>
          <select class="inp" id="stPosSel">
            <option value="ALL" ${posFilter === 'ALL' ? 'selected' : ''}>All Positions（全部位置）</option>
            <option value="G" ${posFilter === 'G' ? 'selected' : ''}>Guard 後衛 (G / PG / SG)</option>
            <option value="F" ${posFilter === 'F' ? 'selected' : ''}>Forward 前鋒 (F / SF / PF)</option>
            <option value="C" ${posFilter === 'C' ? 'selected' : ''}>Center 中鋒 (C)</option>
          </select>
        </div>
        <div class="sf-field">
          <span class="sf-lbl">PLAYER SEARCH 搜尋球員</span>
          <input class="inp" id="stSearchInp" placeholder="例：Luka / Curry / 勇士…" value="${NBA.esc(NBA.state.statsSearch || '')}">
        </div>
      </div>

      <div class="nba-pager-bar">
        <div style="font-size:12px;color:#64748b">
          💡 點擊任一欄位標題（如 <strong>PTS / REB / AST / 3PM / FP / +/-</strong>）可即時排序；點擊球員可看逐場數據，點擊球隊可進球隊專區
        </div>
        <div style="display:flex;align-items:center;gap:8px;margin-left:auto">
          <strong>${totalRows} Rows</strong>
          <span>· Page</span>
          <select class="inp" id="stPageSel" style="padding:3px 8px;font-size:12px">
            ${Array.from({ length: totalPages }, (_, i) => `<option value="${i + 1}" ${page === i + 1 ? 'selected' : ''}>${i + 1}</option>`).join('')}
          </select>
          <span>of ${totalPages}</span>
          <button type="button" class="btn btn-sm" id="stPrevBtn" ${page <= 1 ? 'disabled' : ''}>‹</button>
          <button type="button" class="btn btn-sm" id="stNextBtn" ${page >= totalPages ? 'disabled' : ''}>›</button>
        </div>
      </div>

      <div class="nba-tbl-wrap">
        <table class="nba-stats-tbl">
          <thead>
            <tr>
              <th class="sticky-rk no-sort">#</th>
              <th class="left sticky-pl no-sort">PLAYER</th>
              <th class="left no-sort">TEAM</th>
              ${PLAYER_COLS.map((c) => {
                const act = sortKey === c.key;
                const arrow = act ? (sortDir === 'desc' ? ' ▼' : ' ▲') : '';
                return `<th class="${act ? 'col-active' : ''}" data-psort="${c.key}" title="${NBA.esc(c.tip)}">${c.label}${arrow}</th>`;
              }).join('')}
            </tr>
          </thead>
          <tbody>
            ${slice.map((p, idx) => {
              const rank = (page - 1) * PAGE_SIZE + idx + 1;
              const tm = NBA.teamOf(p.team);
              return `
                <tr>
                  <td class="sticky-rk">${rank}</td>
                  <td class="left sticky-pl">
                    <div style="display:flex;align-items:center;gap:7px">
                      <img decoding="async" class="pl-head-sm" src="${NBA.esc(p.headshot)}" alt="" loading="lazy" onerror="this.style.display='none'">
                      <span class="pl-link" data-player-id="${NBA.esc(p.pid)}" style="color:#1d4ed8;font-weight:700">${NBA.esc(p.name)}</span>
                    </div>
                  </td>
                  <td class="left">
                    <span class="tm-link" data-team-link="${NBA.esc(p.team)}" style="color:#1d4ed8;font-weight:700" title="${NBA.esc(tm.zh)}">${NBA.esc(p.team)}</span>
                  </td>
                  ${PLAYER_COLS.map((c) => {
                    const val = playerMetricValue(p, c.key, perMode);
                    const act = sortKey === c.key;
                    const cls = [act ? 'col-active' : '', c.blue && !act ? 'nba-blue-num' : ''].filter(Boolean).join(' ');
                    return `<td class="${cls}">${fmtCell(val, c, perMode)}</td>`;
                  }).join('')}
                </tr>`;
            }).join('') || '<tr><td colspan="30" style="text-align:center;padding:28px;color:#64748b">沒有符合篩選條件的球員</td></tr>'}
          </tbody>
        </table>
      </div>`;
  }

  function renderTeamsTable(snap) {
    const perMode = NBA.state.statsPerMode === 'totals' ? 'totals' : 'per_game';
    const sortKey = NBA.state.teamStatsSort || 'pts';
    const sortDir = NBA.state.teamStatsDir || 'desc';
    const q = (NBA.state.statsSearch || '').trim().toLowerCase();

    const rows = (snap.team_trad_stats || []).filter((t) => {
      if (!q) return true;
      return `${t.abbr} ${t.zh} ${t.city_zh} ${t.en}`.toLowerCase().includes(q);
    }).slice();

    rows.sort((a, b) => {
      const va = Number(teamMetricValue(a, sortKey, perMode) ?? -999);
      const vb = Number(teamMetricValue(b, sortKey, perMode) ?? -999);
      return sortDir === 'desc' ? (vb - va) : (va - vb);
    });

    return `
      <div class="stats-filter-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
        <div class="sf-field">
          <span class="sf-lbl">SEASON 球季</span>
          <select class="inp" disabled><option>${NBA.esc((snap.meta && snap.meta.season_label) || '2026-27')} Regular Season</option></select>
        </div>
        <div class="sf-field">
          <span class="sf-lbl">PER MODE 統計模式</span>
          <select class="inp" id="tmPerModeSel">
            <option value="per_game" ${perMode === 'per_game' ? 'selected' : ''}>Per Game（場均數據）</option>
            <option value="totals" ${perMode === 'totals' ? 'selected' : ''}>Totals（球季總計）</option>
          </select>
        </div>
        <div class="sf-field">
          <span class="sf-lbl">TEAM SEARCH 搜尋球隊</span>
          <input class="inp" id="stSearchInp" placeholder="搜尋球隊中文或英文縮寫…" value="${NBA.esc(NBA.state.statsSearch || '')}">
        </div>
      </div>

      <div class="nba-tbl-wrap standalone">
        <table class="nba-stats-tbl">
          <thead>
            <tr>
              <th class="sticky-rk no-sort">#</th>
              <th class="left sticky-pl no-sort" style="min-width:190px">TEAM 球隊</th>
              ${TEAM_COLS.map((c) => {
                const act = sortKey === c.key;
                const arrow = act ? (sortDir === 'desc' ? ' ▼' : ' ▲') : '';
                return `<th class="${act ? 'col-active' : ''}" data-tsort="${c.key}" title="${NBA.esc(c.tip)}">${c.label}${arrow}</th>`;
              }).join('')}
            </tr>
          </thead>
          <tbody>
            ${rows.map((t, idx) => `
              <tr>
                <td class="sticky-rk">${idx + 1}</td>
                <td class="left sticky-pl" style="min-width:190px">
                  <div style="display:flex;align-items:center;gap:8px">
                    <img loading="lazy" decoding="async" src="${NBA.esc(t.logo)}" alt="" style="width:22px;height:22px;object-fit:contain">
                    <span class="tm-link" data-team-link="${NBA.esc(t.abbr)}" style="color:#1d4ed8;font-weight:800">${NBA.esc(t.city_zh)} ${NBA.esc(t.zh)}</span>
                    <span style="color:#64748b;font-size:11px">${NBA.esc(t.abbr)}</span>
                  </div>
                </td>
                ${TEAM_COLS.map((c) => {
                  const val = teamMetricValue(t, c.key, perMode);
                  const act = sortKey === c.key;
                  const cls = [act ? 'col-active' : '', c.blue && !act ? 'nba-blue-num' : ''].filter(Boolean).join(' ');
                  return `<td class="${cls}">${fmtCell(val, c, perMode)}</td>`;
                }).join('')}
              </tr>`).join('')}
          </tbody>
        </table>
      </div>`;
  }

  function renderLeadersBoard(snap) {
    const pl = (snap.stat_leaders && snap.stat_leaders.players) || {};
    const tl = (snap.stat_leaders && snap.stat_leaders.teams) || {};

    const pCats = [
      { key: 'pts', title: '🔥 場均得分王 (PTS)', unit: 'PPG', dec: 1 },
      { key: 'reb', title: '💪 場均籃板王 (REB)', unit: 'RPG', dec: 1 },
      { key: 'ast', title: '🎯 場均助攻王 (AST)', unit: 'APG', dec: 1 },
      { key: 'stl', title: '⚡ 場均抄截王 (STL)', unit: 'SPG', dec: 1 },
      { key: 'blk', title: '🛡️ 場均阻攻王 (BLK)', unit: 'BPG', dec: 1 },
      { key: 'tpm', title: '🏹 場均三分命中 (3PM)', unit: '3PM', dec: 1 },
      { key: 'fg_pct', title: '🎖️ 投籃命中率王 (FG%)', unit: '%', dec: 1 },
      { key: 'tp_pct', title: '🎯 三分命中率王 (3P%)', unit: '%', dec: 1 },
      { key: 'ft_pct', title: '🧊 罰球命中率王 (FT%)', unit: '%', dec: 1 },
      { key: 'fp', title: '👑 NBA 幻想積分王 (FP)', unit: 'FP', dec: 1 },
      { key: 'pm', title: '📈 場均正負值王 (+/-)', unit: '+/-', dec: 1, signed: true },
      { key: 'dd2', title: '💎 雙十累積次數 (DD2)', unit: '次', dec: 0 },
    ];

    const tCats = [
      { key: 'pts', valKey: 'pts', title: '🏀 團隊場均得分最高', suffix: ' 分' },
      { key: 'def_pts', valKey: 'opp_pts', title: '🔒 團隊防守失分最低', suffix: ' 分' },
      { key: 'pm', valKey: 'pm', title: '⚔️ 團隊場均淨勝分差', suffix: ' 分', signed: true },
      { key: 'fg_pct', valKey: 'fg_pct', title: '🎯 團隊投籃命中率 (FG%)', suffix: '%' },
      { key: 'tp_pct', valKey: 'tp_pct', title: '🏹 團隊三分命中率 (3P%)', suffix: '%' },
      { key: 'reb', valKey: 'reb', title: '💪 團隊場均總籃板 (REB)', suffix: ' 個' },
      { key: 'ast', valKey: 'ast', title: '🤝 團隊場均助攻 (AST)', suffix: ' 次' },
      { key: 'blk', valKey: 'blk', title: '🛡️ 團隊場均阻攻 (BLK)', suffix: ' 次' },
    ];

    const pCards = pCats.map((cat) => {
      const list = pl[cat.key] || [];
      if (!list.length) return '';
      const top = list[0];
      const topTm = NBA.teamOf(top.team);
      const fmtV = (v) => {
        const n = Number(v || 0);
        const s = cat.dec === 0 ? String(Math.round(n)) : n.toFixed(cat.dec);
        return (cat.signed && n > 0 ? '+' : '') + s + (cat.unit === '%' ? '%' : '');
      };
      return `
        <div class="leader-card">
          <div class="leader-hdr">
            <span>${cat.title}</span>
            <button type="button" class="btn btn-sm btn-ghost" data-jump-psort="${cat.key}" style="padding:2px 8px;font-size:11px">完整排行 ›</button>
          </div>
          <div class="leader-top1">
            <div style="display:flex;align-items:center;gap:10px;min-width:0">
              <img decoding="async" class="leader-avatar" src="${NBA.esc(top.headshot)}" alt="" loading="lazy" onerror="this.style.display='none'">
              <div style="min-width:0">
                <div style="font-size:11px;font-weight:800;color:#2563eb">#1 LEADER</div>
                <div class="pl-link" data-player-id="${NBA.esc(top.pid)}" style="font-size:15px;font-weight:900;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${NBA.esc(top.name)}</div>
                <div style="font-size:12px;color:#64748b">
                  <span class="tm-link" data-team-link="${NBA.esc(top.team)}" style="color:#1d4ed8;font-weight:700">${NBA.esc(topTm.zh)} (${NBA.esc(top.team)})</span>
                  · ${NBA.esc(top.pos || '')} · ${top.gp} GP
                </div>
              </div>
            </div>
            <div class="leader-val-big">${fmtV(top.val)}</div>
          </div>
          <div>
            ${list.slice(1).map((x, i) => `
              <div class="leader-row">
                <div style="display:flex;align-items:center;gap:8px;min-width:0">
                  <span style="color:#64748b;font-weight:700;width:18px">${i + 2}</span>
                  <span class="pl-link" data-player-id="${NBA.esc(x.pid)}" style="font-weight:700;color:#1e293b">${NBA.esc(x.name)}</span>
                  <span class="tm-link" data-team-link="${NBA.esc(x.team)}" style="font-size:11.5px;color:#1d4ed8;font-weight:700">${NBA.esc(x.team)}</span>
                </div>
                <strong style="font-variant-numeric:tabular-nums">${fmtV(x.val)}</strong>
              </div>`).join('')}
          </div>
        </div>`;
    }).join('');

    const tCards = tCats.map((cat) => {
      const list = tl[cat.key] || [];
      if (!list.length) return '';
      const top = list[0];
      const fmtV = (v) => {
        const n = Number(v || 0);
        return (cat.signed && n > 0 ? '+' : '') + n.toFixed(1) + cat.suffix;
      };
      return `
        <div class="leader-card">
          <div class="leader-hdr">
            <span>${cat.title}</span>
            <button type="button" class="btn btn-sm btn-ghost" data-jump-tsort="${cat.valKey}" style="padding:2px 8px;font-size:11px">30 隊完整榜 ›</button>
          </div>
          <div class="leader-top1">
            <div style="display:flex;align-items:center;gap:10px">
              <img loading="lazy" decoding="async" src="${NBA.esc(top.logo)}" alt="" style="width:46px;height:46px;object-fit:contain">
              <div>
                <div style="font-size:11px;font-weight:800;color:#2563eb">#1 TEAM</div>
                <div class="tm-link" data-team-link="${NBA.esc(top.abbr)}" style="font-size:15.5px;font-weight:900;color:#0f172a">${NBA.esc(top.city_zh)} ${NBA.esc(top.zh)}</div>
                <div style="font-size:12px;color:#64748b">${NBA.esc(top.abbr)} · 戰績 ${top.w}-${top.l}</div>
              </div>
            </div>
            <div class="leader-val-big" style="font-size:21px">${fmtV(top[cat.valKey])}</div>
          </div>
          <div>
            ${list.slice(1).map((x, i) => `
              <div class="leader-row">
                <div style="display:flex;align-items:center;gap:8px">
                  <span style="color:#64748b;font-weight:700;width:18px">${i + 2}</span>
                  <img loading="lazy" decoding="async" src="${NBA.esc(x.logo)}" alt="" style="width:18px;height:18px;object-fit:contain">
                  <span class="tm-link" data-team-link="${NBA.esc(x.abbr)}" style="font-weight:700">${NBA.esc(x.city_zh)} ${NBA.esc(x.zh)} (${NBA.esc(x.abbr)})</span>
                </div>
                <strong style="font-variant-numeric:tabular-nums">${fmtV(x[cat.valKey])}</strong>
              </div>`).join('')}
          </div>
        </div>`;
    }).join('');

    return `
      <h2 class="sec-title" style="margin:4px 0 10px">👤 全聯盟球員單項數據領先者 Top 5 (Season Leaders)</h2>
      <div class="leader-grid" style="margin-bottom:22px">${pCards}</div>
      <h2 class="sec-title" style="margin:4px 0 10px">🏀 全聯盟球隊單項數據領先者 Top 5 (Team Leaders)</h2>
      <div class="leader-grid">${tCards}</div>
    `;
  }

  NBA.pages.stats = function (root) {
    const snap = NBA.snap;
    const ent = NBA.state.statsEntity || 'players';

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🏆 NBA 全聯盟數據排行榜 ＆ 各項數據領先者</h1>
          <div class="sec-sub">對齊 NBA.com 官方 Traditional Stats 完整 28 項傳統數據、幻想積分 (FP)、雙十／大三元與單項數據王排行</div>
        </div>
      </div>

      <div class="stats-nav-strip">
        <div class="stats-entity-links">
          <button type="button" class="stats-entity-btn ${ent === 'players' ? 'active' : ''}" data-sent="players">👤 Players 球員數據排行 (${(snap.player_stats || []).length})</button>
          <span class="stats-sep">|</span>
          <button type="button" class="stats-entity-btn ${ent === 'teams' ? 'active' : ''}" data-sent="teams">🏀 Teams 球隊數據排行 (30)</button>
          <span class="stats-sep">|</span>
          <button type="button" class="stats-entity-btn ${ent === 'leaders' ? 'active' : ''}" data-sent="leaders">👑 Leaders 各項數據領先者</button>
        </div>
        <span style="font-size:12px;color:#64748b">General · Traditional · ${NBA.esc((snap.meta && snap.meta.season_label) || '2026-27')} Regular Season</span>
      </div>

      ${ent === 'players' ? renderPlayersTable(snap) : ent === 'teams' ? renderTeamsTable(snap) : renderLeadersBoard(snap)}
    `;

    const pmSel = document.getElementById('stPerModeSel');
    if (pmSel) pmSel.onchange = () => { NBA.state.statsPerMode = pmSel.value; NBA.state.statsPage = 1; NBA.render(); };
    const tpmSel = document.getElementById('tmPerModeSel');
    if (tpmSel) tpmSel.onchange = () => { NBA.state.statsPerMode = tpmSel.value; NBA.render(); };
    const scSel = document.getElementById('stScopeSel');
    if (scSel) scSel.onchange = () => { NBA.state.statsScope = scSel.value; NBA.state.statsPage = 1; NBA.render(); };
    const tmSel = document.getElementById('stTeamSel');
    if (tmSel) tmSel.onchange = () => { NBA.state.statsTeam = tmSel.value; NBA.state.statsPage = 1; NBA.render(); };
    const posSel = document.getElementById('stPosSel');
    if (posSel) posSel.onchange = () => { NBA.state.statsPos = posSel.value; NBA.state.statsPage = 1; NBA.render(); };

    NBA.bindLiveSearch('stSearchInp', (v) => { NBA.state.statsSearch = v; NBA.state.statsPage = 1; });

    const pgSel = document.getElementById('stPageSel');
    if (pgSel) pgSel.onchange = () => { NBA.state.statsPage = Number(pgSel.value); NBA.render(); };
    const prevBtn = document.getElementById('stPrevBtn');
    if (prevBtn) prevBtn.onclick = () => { NBA.state.statsPage = Math.max(1, (NBA.state.statsPage || 1) - 1); NBA.render(); };
    const nextBtn = document.getElementById('stNextBtn');
    if (nextBtn) nextBtn.onclick = () => { NBA.state.statsPage = (NBA.state.statsPage || 1) + 1; NBA.render(); };

    root.querySelectorAll('[data-psort]').forEach((th) => {
      th.onclick = () => {
        const k = th.getAttribute('data-psort');
        if (NBA.state.statsSort === k) {
          NBA.state.statsDir = NBA.state.statsDir === 'desc' ? 'asc' : 'desc';
        } else {
          NBA.state.statsSort = k;
          NBA.state.statsDir = 'desc';
        }
        NBA.state.statsPage = 1;
        NBA.render();
      };
    });

    root.querySelectorAll('[data-tsort]').forEach((th) => {
      th.onclick = () => {
        const k = th.getAttribute('data-tsort');
        if (NBA.state.teamStatsSort === k) {
          NBA.state.teamStatsDir = NBA.state.teamStatsDir === 'desc' ? 'asc' : 'desc';
        } else {
          NBA.state.teamStatsSort = k;
          NBA.state.teamStatsDir = k === 'opp_pts' ? 'asc' : 'desc';
        }
        NBA.render();
      };
    });

    root.querySelectorAll('[data-jump-psort]').forEach((btn) => {
      btn.onclick = () => {
        NBA.state.statsEntity = 'players';
        NBA.state.statsSort = btn.getAttribute('data-jump-psort');
        NBA.state.statsDir = 'desc';
        NBA.state.statsScope = 'qual';
        NBA.state.statsPage = 1;
        NBA.render();
      };
    });

    root.querySelectorAll('[data-jump-tsort]').forEach((btn) => {
      btn.onclick = () => {
        const k = btn.getAttribute('data-jump-tsort');
        NBA.state.statsEntity = 'teams';
        NBA.state.teamStatsSort = k;
        NBA.state.teamStatsDir = k === 'opp_pts' ? 'asc' : 'desc';
        NBA.render();
      };
    });
  };
})();
