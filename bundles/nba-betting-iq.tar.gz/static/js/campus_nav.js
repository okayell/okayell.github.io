/* 開心學園 · 校園導覽與跨學院成就系統（共用片段 campus_nav.js）
 *
 * 唯一來源：~/campus_map_platform/shared/campus_nav.js
 *   各工具 static/ 裡的副本請勿直接修改 —— 改這裡，再跑 python3 ~/campus_map_platform/tools/sync_campus_nav.py 同步。
 *
 * 用法（每個學院／實戰工具）：
 *   1. 在 header 品牌區最前面放 placeholder（工具 id 見 ~/campus_map_platform/registry.json）：
 *        <a class="campus-home" data-campus-home="english" href="https://okayell.github.io/">🏫 校園</a>
 *      深色 header 加 data-campus-theme="dark"。
 *   2. 用一般的 <script src="…/campus_nav.js"></script> 載入（各工具的 build_dist 會把它內嵌進單一 index.html）。
 *   沒有 placeholder 時，會在畫面左上角產生浮動的「🏫 校園」按鈕。
 *
 * 連結目標：
 *   - GitHub Pages（*.github.io）            → 同網域根目錄 /（= https://okayell.github.io/ 校園地圖）
 *   - Cloudtop 本機（已知工具 port，非 localhost）→ 同主機 :8919 的本機校園地圖
 *   - file:// 單一檔、localhost、其他網域        → https://okayell.github.io/
 *   連結會帶 ?from=<工具 id>，校園地圖會標示「你剛剛在這裡」；同網域與跨 port 另透過 Cookie 與 localStorage 同步學習時數與學院成就。
 */
(function () {
  'use strict';
  if (window.CampusNav) return;

  var PUBLIC_CAMPUS = 'https://okayell.github.io/';
  var LOCAL_CAMPUS_PORT = '8919';
  var LOCAL_PORTS = ['8919', '8918', '8911', '8910', '8923', '8922', '8925', '8924', '8927', '8926', '8929', '8928', '8931', '8930', '8933', '8932', '8935', '8934', '8937', '8936', '8939', '8938', '8941', '8940', '8899', '8898',
    '8905', '8904', '8913', '8912', '8915', '8914', '8917', '8916', '8943', '8942'];
  var TOOL_MAP = {
    english: { port: '8919', mount: true, path: 'english-speak-listen/', name: '英語學院', icon: '🇬🇧' },
    japanese: { port: '8919', mount: true, path: 'japanese/', name: '日語學院', icon: '🇯🇵' },
    korean: { port: '8919', mount: true, path: 'korean/', name: '韓語學院', icon: '🇰🇷' },
    finance: { port: '8919', mount: true, path: 'finance/', name: '財經學院', icon: '🏛️' },
    'addiction-cm': { port: '8919', mount: true, path: 'addiction-cm/', name: '藥癮個管師學院', icon: '💚' },
    'health-care': { port: '8919', mount: true, path: 'health-care/', name: '醫療保健學院', icon: '🩺' },
    coding: { port: '8919', mount: true, path: 'coding/', name: '程式語言學院', icon: '💻' },
    'smart-iot': { port: '8919', mount: true, path: 'smart-iot/', name: '智慧生活與物聯網學院', icon: '🏡' },
    music: { port: '8919', mount: true, path: 'music/', name: '音樂學院', icon: '🎵' },
    cooking: { port: '8919', mount: true, path: 'cooking/', name: '烹飪學院', icon: '🍳' },
    trivia: { port: '8919', mount: true, path: 'trivia/', name: '冷知識學院', icon: '💡' },
    'home-repair': { port: '8919', mount: true, path: 'home-repair/', name: '居家水電修繕學院', icon: '🔧' },
    fitness: { port: '8919', mount: true, path: 'fitness/', name: '健身學院', icon: '💪' },
    stock: { port: '8919', mount: true, path: 'tw-stock-insight/', name: '台股智慧選股', icon: '📈' },
    poker: { port: '8919', mount: true, path: 'poker-gto/', name: 'GTO 賽局策略學院', icon: '♠️' },
    nba: { port: '8919', mount: true, path: 'nba-betting-iq/', name: 'NBA 數據智庫', icon: '🏀' },
    epl: { port: '8919', mount: true, path: 'epl-odds-iq/', name: '英超數據智庫', icon: '⚽' },
    f1: { port: '8919', mount: true, path: 'f1-odds-iq/', name: 'F1 數據智庫', icon: '🏎️' },
    baseball: { port: '8919', mount: true, path: 'baseball/', name: 'MLB 戰情室', icon: '⚾' },
    twbasket: { port: '8919', mount: true, path: 'tw-basketball/', name: '台籃戰情室', icon: '⛹️' }
  };
  var ACADEMY_CRESTS = {"english": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-english\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#1e3a8a\"/><stop offset=\"100%\" stop-color=\"#1d4ed8\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-english)\"/><path d=\"M8 8 L56 56 M56 8 L8 56\" stroke=\"#ffffff\" stroke-width=\"5\" opacity=\".22\"/><path d=\"M32 6 V58 M6 32 H58\" stroke=\"#ef4444\" stroke-width=\"4\" opacity=\".32\"/><rect x=\"11\" y=\"13\" width=\"42\" height=\"31\" rx=\"9\" fill=\"#ffffff\" stroke=\"#bfdbfe\" stroke-width=\"1.5\"/><path d=\"M22 43 L18 52 L30 43 Z\" fill=\"#ffffff\"/><text x=\"32\" y=\"35\" text-anchor=\"middle\" font-family=\"Arial,Helvetica,sans-serif\" font-size=\"19\" font-weight=\"900\" fill=\"#1e3a8a\" letter-spacing=\".5\">EN</text><rect x=\"39\" y=\"10\" width=\"16\" height=\"10\" rx=\"5\" fill=\"#ef4444\"/><circle cx=\"44\" cy=\"15\" r=\"1.4\" fill=\"#fff\"/><circle cx=\"47\" cy=\"15\" r=\"1.4\" fill=\"#fff\"/><circle cx=\"50\" cy=\"15\" r=\"1.4\" fill=\"#fff\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%231e3a8a'/%3E%3Cstop offset='100%25' stop-color='%231d4ed8'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cpath d='M8 8 L56 56 M56 8 L8 56' stroke='%23ffffff' stroke-width='5' opacity='.22'/%3E%3Cpath d='M32 6 V58 M6 32 H58' stroke='%23ef4444' stroke-width='4' opacity='.32'/%3E%3Crect x='11' y='13' width='42' height='31' rx='9' fill='%23ffffff' stroke='%23bfdbfe' stroke-width='1.5'/%3E%3Cpath d='M22 43 L18 52 L30 43 Z' fill='%23ffffff'/%3E%3Ctext x='32' y='35' text-anchor='middle' font-family='Arial,Helvetica,sans-serif' font-size='19' font-weight='900' fill='%231e3a8a' letter-spacing='.5'%3EEN%3C/text%3E%3Crect x='39' y='10' width='16' height='10' rx='5' fill='%23ef4444'/%3E%3Ccircle cx='44' cy='15' r='1.4' fill='%23fff'/%3E%3Ccircle cx='47' cy='15' r='1.4' fill='%23fff'/%3E%3Ccircle cx='50' cy='15' r='1.4' fill='%23fff'/%3E%3C/svg%3E"}, "japanese": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-japanese\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#fff1f2\"/><stop offset=\"100%\" stop-color=\"#ffe4e6\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-japanese)\" stroke=\"#fda4af\" stroke-width=\"2\"/><circle cx=\"32\" cy=\"31\" r=\"15\" fill=\"#e11d48\" opacity=\".18\"/><path d=\"M11 21 Q32 15 53 21 L51 26 Q32 21 13 26 Z\" fill=\"#dc2626\"/><rect x=\"15\" y=\"29\" width=\"34\" height=\"4.5\" rx=\"2\" fill=\"#dc2626\"/><rect x=\"29.5\" y=\"22\" width=\"5\" height=\"11\" fill=\"#b91c1c\"/><path d=\"M20 24 L18 52 M44 24 L46 52\" stroke=\"#dc2626\" stroke-width=\"5.2\" stroke-linecap=\"round\"/><circle cx=\"49\" cy=\"14\" r=\"4\" fill=\"#fb7185\"/><circle cx=\"49\" cy=\"14\" r=\"1.5\" fill=\"#fef08a\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23fff1f2'/%3E%3Cstop offset='100%25' stop-color='%23ffe4e6'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)' stroke='%23fda4af' stroke-width='2'/%3E%3Ccircle cx='32' cy='31' r='15' fill='%23e11d48' opacity='.18'/%3E%3Cpath d='M11 21 Q32 15 53 21 L51 26 Q32 21 13 26 Z' fill='%23dc2626'/%3E%3Crect x='15' y='29' width='34' height='4.5' rx='2' fill='%23dc2626'/%3E%3Crect x='29.5' y='22' width='5' height='11' fill='%23b91c1c'/%3E%3Cpath d='M20 24 L18 52 M44 24 L46 52' stroke='%23dc2626' stroke-width='5.2' stroke-linecap='round'/%3E%3Ccircle cx='49' cy='14' r='4' fill='%23fb7185'/%3E%3Ccircle cx='49' cy='14' r='1.5' fill='%23fef08a'/%3E%3C/svg%3E"}, "korean": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-korean\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#1e1b4b\"/><stop offset=\"100%\" stop-color=\"#312e81\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-korean)\"/><circle cx=\"32\" cy=\"32\" r=\"19\" fill=\"#ffffff\" opacity=\".12\"/><circle cx=\"32\" cy=\"32\" r=\"16\" fill=\"#2563eb\"/><path d=\"M16 32 A16 16 0 0 1 48 32 A8 8 0 0 1 32 32 A8 8 0 0 0 16 32 Z\" fill=\"#e11d48\"/><circle cx=\"24\" cy=\"32\" r=\"8\" fill=\"#e11d48\"/><circle cx=\"40\" cy=\"32\" r=\"8\" fill=\"#2563eb\"/><rect x=\"11\" y=\"11\" width=\"11\" height=\"3\" rx=\"1.5\" fill=\"#e0e7ff\" transform=\"rotate(-38 16 12)\"/><rect x=\"42\" y=\"49\" width=\"11\" height=\"3\" rx=\"1.5\" fill=\"#e0e7ff\" transform=\"rotate(-38 47 50)\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%231e1b4b'/%3E%3Cstop offset='100%25' stop-color='%23312e81'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Ccircle cx='32' cy='32' r='19' fill='%23ffffff' opacity='.12'/%3E%3Ccircle cx='32' cy='32' r='16' fill='%232563eb'/%3E%3Cpath d='M16 32 A16 16 0 0 1 48 32 A8 8 0 0 1 32 32 A8 8 0 0 0 16 32 Z' fill='%23e11d48'/%3E%3Ccircle cx='24' cy='32' r='8' fill='%23e11d48'/%3E%3Ccircle cx='40' cy='32' r='8' fill='%232563eb'/%3E%3Crect x='11' y='11' width='11' height='3' rx='1.5' fill='%23e0e7ff' transform='rotate(-38 16 12)'/%3E%3Crect x='42' y='49' width='11' height='3' rx='1.5' fill='%23e0e7ff' transform='rotate(-38 47 50)'/%3E%3C/svg%3E"}, "finance": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-finance\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#065f46\"/><stop offset=\"100%\" stop-color=\"#022c22\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-finance)\"/><path d=\"M12 24 L32 11 L52 24 Z\" fill=\"#fbbf24\"/><rect x=\"14\" y=\"24\" width=\"36\" height=\"3.5\" rx=\"1.5\" fill=\"#fde68a\"/><rect x=\"17\" y=\"28\" width=\"4.5\" height=\"19\" rx=\"1.5\" fill=\"#fef3c7\"/><rect x=\"26.5\" y=\"28\" width=\"4.5\" height=\"19\" rx=\"1.5\" fill=\"#fef3c7\"/><rect x=\"36\" y=\"28\" width=\"4.5\" height=\"19\" rx=\"1.5\" fill=\"#fef3c7\"/><rect x=\"45\" y=\"28\" width=\"4.5\" height=\"19\" rx=\"1.5\" fill=\"#fef3c7\"/><rect x=\"12\" y=\"48\" width=\"40\" height=\"5\" rx=\"2\" fill=\"#fbbf24\"/><path d=\"M15 44 L27 35 L35 39 L50 23\" fill=\"none\" stroke=\"#34d399\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M42 23 H50 V31\" fill=\"none\" stroke=\"#34d399\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23065f46'/%3E%3Cstop offset='100%25' stop-color='%23022c22'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cpath d='M12 24 L32 11 L52 24 Z' fill='%23fbbf24'/%3E%3Crect x='14' y='24' width='36' height='3.5' rx='1.5' fill='%23fde68a'/%3E%3Crect x='17' y='28' width='4.5' height='19' rx='1.5' fill='%23fef3c7'/%3E%3Crect x='26.5' y='28' width='4.5' height='19' rx='1.5' fill='%23fef3c7'/%3E%3Crect x='36' y='28' width='4.5' height='19' rx='1.5' fill='%23fef3c7'/%3E%3Crect x='45' y='28' width='4.5' height='19' rx='1.5' fill='%23fef3c7'/%3E%3Crect x='12' y='48' width='40' height='5' rx='2' fill='%23fbbf24'/%3E%3Cpath d='M15 44 L27 35 L35 39 L50 23' fill='none' stroke='%2334d399' stroke-width='4' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M42 23 H50 V31' fill='none' stroke='%2334d399' stroke-width='4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E"}, "addiction-cm": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-addictioncm\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#10b981\"/><stop offset=\"100%\" stop-color=\"#047857\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-addictioncm)\"/><path d=\"M32 51 C32 51 12 38 12 24 C12 16.5 18 12 24.5 12 C28.5 12 31 14.5 32 17 C33 14.5 35.5 12 39.5 12 C46 12 52 16.5 52 24 C52 38 32 51 32 51 Z\" fill=\"#ffffff\"/><rect x=\"29\" y=\"21\" width=\"6\" height=\"18\" rx=\"2\" fill=\"#059669\"/><rect x=\"23\" y=\"27\" width=\"18\" height=\"6\" rx=\"2\" fill=\"#059669\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%2310b981'/%3E%3Cstop offset='100%25' stop-color='%23047857'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cpath d='M32 51 C32 51 12 38 12 24 C12 16.5 18 12 24.5 12 C28.5 12 31 14.5 32 17 C33 14.5 35.5 12 39.5 12 C46 12 52 16.5 52 24 C52 38 32 51 32 51 Z' fill='%23ffffff'/%3E%3Crect x='29' y='21' width='6' height='18' rx='2' fill='%23059669'/%3E%3Crect x='23' y='27' width='18' height='6' rx='2' fill='%23059669'/%3E%3C/svg%3E"}, "health-care": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-healthcare\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#0d9488\"/><stop offset=\"100%\" stop-color=\"#047857\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-healthcare)\"/><circle cx=\"32\" cy=\"28\" r=\"17\" fill=\"#ffffff\"/><rect x=\"28.5\" y=\"17\" width=\"7\" height=\"22\" rx=\"2\" fill=\"#e11d48\"/><rect x=\"21\" y=\"24.5\" width=\"22\" height=\"7\" rx=\"2\" fill=\"#e11d48\"/><path d=\"M11 52 H23 L27 45 L32 57 L36 49 L39 52 H53\" fill=\"none\" stroke=\"#99f6e4\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%230d9488'/%3E%3Cstop offset='100%25' stop-color='%23047857'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Ccircle cx='32' cy='28' r='17' fill='%23ffffff'/%3E%3Crect x='28.5' y='17' width='7' height='22' rx='2' fill='%23e11d48'/%3E%3Crect x='21' y='24.5' width='22' height='7' rx='2' fill='%23e11d48'/%3E%3Cpath d='M11 52 H23 L27 45 L32 57 L36 49 L39 52 H53' fill='none' stroke='%2399f6e4' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E"}, "coding": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-coding\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#0f172a\"/><stop offset=\"100%\" stop-color=\"#1e3a8a\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-coding)\"/><rect x=\"8\" y=\"11\" width=\"48\" height=\"42\" rx=\"9\" fill=\"#1e293b\" stroke=\"#38bdf8\" stroke-width=\"2\"/><circle cx=\"15\" cy=\"17.5\" r=\"2.2\" fill=\"#fb7185\"/><circle cx=\"22\" cy=\"17.5\" r=\"2.2\" fill=\"#fbbf24\"/><circle cx=\"29\" cy=\"17.5\" r=\"2.2\" fill=\"#34d399\"/><path d=\"M16 29 L26 36 L16 43\" fill=\"none\" stroke=\"#38bdf8\" stroke-width=\"4.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"31\" y1=\"43\" x2=\"47\" y2=\"43\" stroke=\"#fbbf24\" stroke-width=\"4.2\" stroke-linecap=\"round\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%230f172a'/%3E%3Cstop offset='100%25' stop-color='%231e3a8a'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Crect x='8' y='11' width='48' height='42' rx='9' fill='%231e293b' stroke='%2338bdf8' stroke-width='2'/%3E%3Ccircle cx='15' cy='17.5' r='2.2' fill='%23fb7185'/%3E%3Ccircle cx='22' cy='17.5' r='2.2' fill='%23fbbf24'/%3E%3Ccircle cx='29' cy='17.5' r='2.2' fill='%2334d399'/%3E%3Cpath d='M16 29 L26 36 L16 43' fill='none' stroke='%2338bdf8' stroke-width='4.2' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cline x1='31' y1='43' x2='47' y2='43' stroke='%23fbbf24' stroke-width='4.2' stroke-linecap='round'/%3E%3C/svg%3E"}, "smart-iot": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-smartiot\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#0891b2\"/><stop offset=\"100%\" stop-color=\"#0f766e\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-smartiot)\"/><path d=\"M12 33 L32 16 L52 33\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"4.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M18 30 V50 H46 V30\" fill=\"#ecfeff\" opacity=\".95\"/><path d=\"M23 36 A13 13 0 0 1 41 36\" fill=\"none\" stroke=\"#0891b2\" stroke-width=\"3.2\" stroke-linecap=\"round\"/><path d=\"M26.5 41 A7.5 7.5 0 0 1 37.5 41\" fill=\"none\" stroke=\"#0891b2\" stroke-width=\"3.2\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"45.5\" r=\"3\" fill=\"#f59e0b\"/><circle cx=\"32\" cy=\"11\" r=\"2.5\" fill=\"#fde047\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%230891b2'/%3E%3Cstop offset='100%25' stop-color='%230f766e'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cpath d='M12 33 L32 16 L52 33' fill='none' stroke='%23ffffff' stroke-width='4.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M18 30 V50 H46 V30' fill='%23ecfeff' opacity='.95'/%3E%3Cpath d='M23 36 A13 13 0 0 1 41 36' fill='none' stroke='%230891b2' stroke-width='3.2' stroke-linecap='round'/%3E%3Cpath d='M26.5 41 A7.5 7.5 0 0 1 37.5 41' fill='none' stroke='%230891b2' stroke-width='3.2' stroke-linecap='round'/%3E%3Ccircle cx='32' cy='45.5' r='3' fill='%23f59e0b'/%3E%3Ccircle cx='32' cy='11' r='2.5' fill='%23fde047'/%3E%3C/svg%3E"}, "music": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-music\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#6d28d9\"/><stop offset=\"100%\" stop-color=\"#be185d\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-music)\"/><path d=\"M25 43 V18 L47 13 V39\" fill=\"none\" stroke=\"#fde68a\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M25 25 L47 20\" stroke=\"#fbbf24\" stroke-width=\"4.2\"/><ellipse cx=\"20\" cy=\"45\" rx=\"7.5\" ry=\"5.5\" transform=\"rotate(-18 20 45)\" fill=\"#fef3c7\"/><ellipse cx=\"42\" cy=\"41\" rx=\"7.5\" ry=\"5.5\" transform=\"rotate(-18 42 41)\" fill=\"#fef3c7\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%236d28d9'/%3E%3Cstop offset='100%25' stop-color='%23be185d'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cpath d='M25 43 V18 L47 13 V39' fill='none' stroke='%23fde68a' stroke-width='4.8' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M25 25 L47 20' stroke='%23fbbf24' stroke-width='4.2'/%3E%3Cellipse cx='20' cy='45' rx='7.5' ry='5.5' transform='rotate(-18 20 45)' fill='%23fef3c7'/%3E%3Cellipse cx='42' cy='41' rx='7.5' ry='5.5' transform='rotate(-18 42 41)' fill='%23fef3c7'/%3E%3C/svg%3E"}, "trivia": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-trivia\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#f59e0b\"/><stop offset=\"100%\" stop-color=\"#d97706\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-trivia)\"/><path d=\"M32 7 V11 M12 27 H8 M56 27 H52 M17 13 L20 16 M47 13 L44 16\" stroke=\"#fef9c3\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M22 36 C18 32 17 24 22 18.5 C27 13 37 13 42 18.5 C47 24 46 32 42 36 C39.5 38.5 38.5 41 38.5 44 H25.5 C25.5 41 24.5 38.5 22 36 Z\" fill=\"#ffffff\"/><path d=\"M28 33 L32 26 L36 33\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"26\" y=\"46\" width=\"12\" height=\"4\" rx=\"2\" fill=\"#1e293b\"/><rect x=\"28\" y=\"51.5\" width=\"8\" height=\"3.5\" rx=\"1.7\" fill=\"#334155\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23f59e0b'/%3E%3Cstop offset='100%25' stop-color='%23d97706'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cpath d='M32 7 V11 M12 27 H8 M56 27 H52 M17 13 L20 16 M47 13 L44 16' stroke='%23fef9c3' stroke-width='3' stroke-linecap='round'/%3E%3Cpath d='M22 36 C18 32 17 24 22 18.5 C27 13 37 13 42 18.5 C47 24 46 32 42 36 C39.5 38.5 38.5 41 38.5 44 H25.5 C25.5 41 24.5 38.5 22 36 Z' fill='%23ffffff'/%3E%3Cpath d='M28 33 L32 26 L36 33' fill='none' stroke='%23f59e0b' stroke-width='2.8' stroke-linecap='round' stroke-linejoin='round'/%3E%3Crect x='26' y='46' width='12' height='4' rx='2' fill='%231e293b'/%3E%3Crect x='28' y='51.5' width='8' height='3.5' rx='1.7' fill='%23334155'/%3E%3C/svg%3E"}, "fitness": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-fitness\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#ea580c\"/><stop offset=\"100%\" stop-color=\"#991b1b\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-fitness)\"/><g transform=\"rotate(-28 32 32)\"><rect x=\"16\" y=\"29\" width=\"32\" height=\"6\" rx=\"2.5\" fill=\"#e2e8f0\"/><rect x=\"11\" y=\"18\" width=\"7\" height=\"28\" rx=\"3\" fill=\"#ffffff\"/><rect x=\"6\" y=\"22\" width=\"5\" height=\"20\" rx=\"2.2\" fill=\"#fde047\"/><rect x=\"46\" y=\"18\" width=\"7\" height=\"28\" rx=\"3\" fill=\"#ffffff\"/><rect x=\"53\" y=\"22\" width=\"5\" height=\"20\" rx=\"2.2\" fill=\"#fde047\"/></g></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23ea580c'/%3E%3Cstop offset='100%25' stop-color='%23991b1b'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cg transform='rotate(-28 32 32)'%3E%3Crect x='16' y='29' width='32' height='6' rx='2.5' fill='%23e2e8f0'/%3E%3Crect x='11' y='18' width='7' height='28' rx='3' fill='%23ffffff'/%3E%3Crect x='6' y='22' width='5' height='20' rx='2.2' fill='%23fde047'/%3E%3Crect x='46' y='18' width='7' height='28' rx='3' fill='%23ffffff'/%3E%3Crect x='53' y='22' width='5' height='20' rx='2.2' fill='%23fde047'/%3E%3C/g%3E%3C/svg%3E"}, "poker": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-poker\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#065f46\"/><stop offset=\"100%\" stop-color=\"#0f172a\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-poker)\"/><circle cx=\"32\" cy=\"32\" r=\"23\" fill=\"none\" stroke=\"#fbbf24\" stroke-width=\"3\" stroke-dasharray=\"6 4\"/><path d=\"M32 13 C23 24 16 29 16 36.5 C16 42 20.5 45.5 25.5 45.5 C28.5 45.5 30.5 44 32 42 C33.5 44 35.5 45.5 38.5 45.5 C43.5 45.5 48 42 48 36.5 C48 29 41 24 32 13 Z\" fill=\"#ffffff\"/><path d=\"M30 41 L26 51 H38 L34 41 Z\" fill=\"#ffffff\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23065f46'/%3E%3Cstop offset='100%25' stop-color='%230f172a'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Ccircle cx='32' cy='32' r='23' fill='none' stroke='%23fbbf24' stroke-width='3' stroke-dasharray='6 4'/%3E%3Cpath d='M32 13 C23 24 16 29 16 36.5 C16 42 20.5 45.5 25.5 45.5 C28.5 45.5 30.5 44 32 42 C33.5 44 35.5 45.5 38.5 45.5 C43.5 45.5 48 42 48 36.5 C48 29 41 24 32 13 Z' fill='%23ffffff'/%3E%3Cpath d='M30 41 L26 51 H38 L34 41 Z' fill='%23ffffff'/%3E%3C/svg%3E"}, "stock": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-stock\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#0f172a\"/><stop offset=\"100%\" stop-color=\"#1e293b\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-stock)\"/><line x1=\"16\" y1=\"24\" x2=\"16\" y2=\"50\" stroke=\"#22c55e\" stroke-width=\"2.5\" stroke-linecap=\"round\"/><rect x=\"12\" y=\"30\" width=\"8\" height=\"14\" rx=\"2\" fill=\"#22c55e\"/><line x1=\"32\" y1=\"18\" x2=\"32\" y2=\"46\" stroke=\"#ef4444\" stroke-width=\"2.5\" stroke-linecap=\"round\"/><rect x=\"28\" y=\"23\" width=\"8\" height=\"16\" rx=\"2\" fill=\"#ef4444\"/><line x1=\"48\" y1=\"11\" x2=\"48\" y2=\"39\" stroke=\"#ef4444\" stroke-width=\"2.5\" stroke-linecap=\"round\"/><rect x=\"44\" y=\"15\" width=\"8\" height=\"18\" rx=\"2\" fill=\"#ef4444\"/><path d=\"M11 47 Q28 42 53 16\" fill=\"none\" stroke=\"#fbbf24\" stroke-width=\"3.2\" stroke-linecap=\"round\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%230f172a'/%3E%3Cstop offset='100%25' stop-color='%231e293b'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cline x1='16' y1='24' x2='16' y2='50' stroke='%2322c55e' stroke-width='2.5' stroke-linecap='round'/%3E%3Crect x='12' y='30' width='8' height='14' rx='2' fill='%2322c55e'/%3E%3Cline x1='32' y1='18' x2='32' y2='46' stroke='%23ef4444' stroke-width='2.5' stroke-linecap='round'/%3E%3Crect x='28' y='23' width='8' height='16' rx='2' fill='%23ef4444'/%3E%3Cline x1='48' y1='11' x2='48' y2='39' stroke='%23ef4444' stroke-width='2.5' stroke-linecap='round'/%3E%3Crect x='44' y='15' width='8' height='18' rx='2' fill='%23ef4444'/%3E%3Cpath d='M11 47 Q28 42 53 16' fill='none' stroke='%23fbbf24' stroke-width='3.2' stroke-linecap='round'/%3E%3C/svg%3E"}, "nba": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><radialGradient id=\"cn-g-nba\" cx=\"35%\" cy=\"30%\" r=\"70%\"><stop offset=\"0%\" stop-color=\"#fb923c\"/><stop offset=\"100%\" stop-color=\"#c2410c\"/></radialGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"#1e293b\"/><circle cx=\"32\" cy=\"32\" r=\"22\" fill=\"url(#cn-g-nba)\" stroke=\"#fed7aa\" stroke-width=\"1.6\"/><path d=\"M10 32 H54 M32 10 V54\" stroke=\"#1e293b\" stroke-width=\"2.8\"/><path d=\"M16 16 Q30 32 16 48 M48 16 Q34 32 48 48\" fill=\"none\" stroke=\"#1e293b\" stroke-width=\"2.8\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3CradialGradient id='g' cx='35%25' cy='30%25' r='70%25'%3E%3Cstop offset='0%25' stop-color='%23fb923c'/%3E%3Cstop offset='100%25' stop-color='%23c2410c'/%3E%3C/radialGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='%231e293b'/%3E%3Ccircle cx='32' cy='32' r='22' fill='url(%23g)' stroke='%23fed7aa' stroke-width='1.6'/%3E%3Cpath d='M10 32 H54 M32 10 V54' stroke='%231e293b' stroke-width='2.8'/%3E%3Cpath d='M16 16 Q30 32 16 48 M48 16 Q34 32 48 48' fill='none' stroke='%231e293b' stroke-width='2.8'/%3E%3C/svg%3E"}, "epl": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-epl\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#3b0764\"/><stop offset=\"100%\" stop-color=\"#6d28d9\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-epl)\"/><circle cx=\"32\" cy=\"34\" r=\"19\" fill=\"#ffffff\"/><polygon points=\"32,25 40,31 37,40 27,40 24,31\" fill=\"#1e1b4b\"/><path d=\"M32 15 V25 M40 31 L49 28 M37 40 L43 48 M27 40 L21 48 M24 31 L15 28\" stroke=\"#1e1b4b\" stroke-width=\"2.5\"/><path d=\"M23 12 L27 7 L32 11 L37 7 L41 12 Z\" fill=\"#fbbf24\"/></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%233b0764'/%3E%3Cstop offset='100%25' stop-color='%236d28d9'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Ccircle cx='32' cy='34' r='19' fill='%23ffffff'/%3E%3Cpolygon points='32,25 40,31 37,40 27,40 24,31' fill='%231e1b4b'/%3E%3Cpath d='M32 15 V25 M40 31 L49 28 M37 40 L43 48 M27 40 L21 48 M24 31 L15 28' stroke='%231e1b4b' stroke-width='2.5'/%3E%3Cpath d='M23 12 L27 7 L32 11 L37 7 L41 12 Z' fill='%23fbbf24'/%3E%3C/svg%3E"}, "f1": {"svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><defs><linearGradient id=\"cn-g-f1\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stop-color=\"#dc2626\"/><stop offset=\"100%\" stop-color=\"#7f1d1d\"/></linearGradient></defs><rect width=\"64\" height=\"64\" rx=\"15\" fill=\"url(#cn-g-f1)\"/><g transform=\"rotate(-24 32 33)\"><rect x=\"11\" y=\"21\" width=\"9\" height=\"5\" rx=\"2\" fill=\"#0f172a\"/><rect x=\"11\" y=\"38\" width=\"9\" height=\"5\" rx=\"2\" fill=\"#0f172a\"/><rect x=\"43\" y=\"22\" width=\"8\" height=\"4.5\" rx=\"1.8\" fill=\"#0f172a\"/><rect x=\"43\" y=\"37.5\" width=\"8\" height=\"4.5\" rx=\"1.8\" fill=\"#0f172a\"/><path d=\"M9 26 H16 L24 27 L42 29 L55 31 L55 33 L42 35 L24 37 L16 38 H9 Z\" fill=\"#ffffff\"/><ellipse cx=\"31\" cy=\"32\" rx=\"6\" ry=\"3.4\" fill=\"#0f172a\"/><circle cx=\"32\" cy=\"32\" r=\"2.2\" fill=\"#fde047\"/><rect x=\"7\" y=\"24\" width=\"3.5\" height=\"16\" rx=\"1\" fill=\"#fde047\"/><rect x=\"52\" y=\"25\" width=\"3\" height=\"14\" rx=\"1\" fill=\"#ffffff\"/></g></svg>", "url": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23dc2626'/%3E%3Cstop offset='100%25' stop-color='%237f1d1d'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cg transform='rotate(-24 32 33)'%3E%3Crect x='11' y='21' width='9' height='5' rx='2' fill='%230f172a'/%3E%3Crect x='11' y='38' width='9' height='5' rx='2' fill='%230f172a'/%3E%3Crect x='43' y='22' width='8' height='4.5' rx='1.8' fill='%230f172a'/%3E%3Crect x='43' y='37.5' width='8' height='4.5' rx='1.8' fill='%230f172a'/%3E%3Cpath d='M9 26 H16 L24 27 L42 29 L55 31 L55 33 L42 35 L24 37 L16 38 H9 Z' fill='%23ffffff'/%3E%3Cellipse cx='31' cy='32' rx='6' ry='3.4' fill='%230f172a'/%3E%3Ccircle cx='32' cy='32' r='2.2' fill='%23fde047'/%3E%3Crect x='7' y='24' width='3.5' height='16' rx='1' fill='%23fde047'/%3E%3Crect x='52' y='25' width='3' height='14' rx='1' fill='%23ffffff'/%3E%3C/g%3E%3C/svg%3E"}};
  ACADEMY_CRESTS.twbasket = {
    svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="cn-g-twb" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1e3a8a"/><stop offset="100%" stop-color="#dc2626"/></linearGradient></defs><rect width="64" height="64" rx="15" fill="url(#cn-g-twb)"/><rect x="12" y="13" width="40" height="24" rx="4" fill="#ffffff" opacity=".95"/><rect x="23" y="21" width="18" height="12" fill="none" stroke="#dc2626" stroke-width="2.6"/><line x1="18" y1="36" x2="46" y2="36" stroke="#ea580c" stroke-width="4" stroke-linecap="round"/><path d="M22 36 L25 50 M32 36 V51 M42 36 L39 50 M23 43 H41" stroke="#fde68a" stroke-width="2.2" stroke-linecap="round"/></svg>',
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%231e3a8a'/%3E%3Cstop offset='100%25' stop-color='%23dc2626'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Crect x='12' y='13' width='40' height='24' rx='4' fill='%23ffffff' opacity='.95'/%3E%3Crect x='23' y='21' width='18' height='12' fill='none' stroke='%23dc2626' stroke-width='2.6'/%3E%3Cline x1='18' y1='36' x2='46' y2='36' stroke='%23ea580c' stroke-width='4' stroke-linecap='round'/%3E%3Cpath d='M22 36 L25 50 M32 36 V51 M42 36 L39 50 M23 43 H41' stroke='%23fde68a' stroke-width='2.2' stroke-linecap='round'/%3E%3C/svg%3E"
  };
  ACADEMY_CRESTS.cooking = {
    svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="cn-g-cook" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#ea580c"/><stop offset="100%" stop-color="#b91c1c"/></linearGradient></defs><rect width="64" height="64" rx="15" fill="url(#cn-g-cook)"/><path d="M18 30c-5 0-8-4-8-8s4-8 9-7c1-5 6-8 13-8s12 3 13 8c5-1 9 3 9 7s-3 8-8 8z" fill="#fff7ed"/><rect x="19" y="29" width="26" height="12" rx="2" fill="#fff7ed"/><path d="M12 47h40" stroke="#fde68a" stroke-width="5" stroke-linecap="round"/></svg>',
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23ea580c'/%3E%3Cstop offset='100%25' stop-color='%23b91c1c'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cpath d='M18 30c-5 0-8-4-8-8s4-8 9-7c1-5 6-8 13-8s12 3 13 8c5-1 9 3 9 7s-3 8-8 8z' fill='%23fff7ed'/%3E%3Crect x='19' y='29' width='26' height='12' rx='2' fill='%23fff7ed'/%3E%3Cpath d='M12 47h40' stroke='%23fde68a' stroke-width='5' stroke-linecap='round'/%3E%3C/svg%3E"
  };
  ACADEMY_CRESTS['home-repair'] = {
    svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="cn-g-hr" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#0f766e"/><stop offset="100%" stop-color="#115e59"/></linearGradient></defs><rect width="64" height="64" rx="15" fill="url(#cn-g-hr)"/><path d="M43 14a11 11 0 0 0-10.2 14.8L15.5 46a4.5 4.5 0 0 0 6.4 6.4l17.3-17.3A11 11 0 0 0 53 23l-6.2 6.2-4.8-1.2-1.2-4.8L47 17a11 11 0 0 0-4-3z" fill="#ffffff"/><path d="M21 12 L13 25 H20 L17 35 L27 21 H20 Z" fill="#fde047"/><path d="M48 40 C48 40 42 47.5 42 51.5 A6 6 0 0 0 54 51.5 C54 47.5 48 40 48 40 Z" fill="#38bdf8"/></svg>',
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%230f766e'/%3E%3Cstop offset='100%25' stop-color='%23115e59'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Cpath d='M43 14a11 11 0 0 0-10.2 14.8L15.5 46a4.5 4.5 0 0 0 6.4 6.4l17.3-17.3A11 11 0 0 0 53 23l-6.2 6.2-4.8-1.2-1.2-4.8L47 17a11 11 0 0 0-4-3z' fill='%23ffffff'/%3E%3Cpath d='M21 12 L13 25 H20 L17 35 L27 21 H20 Z' fill='%23fde047'/%3E%3Cpath d='M48 40 C48 40 42 47.5 42 51.5 A6 6 0 0 0 54 51.5 C54 47.5 48 40 48 40 Z' fill='%2338bdf8'/%3E%3C/svg%3E"
  };
  ACADEMY_CRESTS.baseball = {
    svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="cn-g-bb" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1e3a8a"/><stop offset="100%" stop-color="#991b1b"/></linearGradient></defs><rect width="64" height="64" rx="15" fill="url(#cn-g-bb)"/><circle cx="32" cy="32" r="20" fill="#ffffff"/><path d="M19 18 Q28 32 19 46 M45 18 Q36 32 45 46" fill="none" stroke="#dc2626" stroke-width="2.6" stroke-dasharray="3 2"/></svg>',
    url: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%231e3a8a'/%3E%3Cstop offset='100%25' stop-color='%23991b1b'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='64' height='64' rx='15' fill='url(%23g)'/%3E%3Ccircle cx='32' cy='32' r='20' fill='%23ffffff'/%3E%3Cpath d='M19 18 Q28 32 19 46 M45 18 Q36 32 45 46' fill='none' stroke='%23dc2626' stroke-width='2.6' stroke-dasharray='3 2'/%3E%3C/svg%3E"
  };
  var VISITS_KEY = 'okayell.campus.visits.v1';
  var STU_KEY = 'okayell.campus.student.v1';
  var STU_COOKIE = 'okayell_campus_stu_v1';
  var FUN_KEY = 'okayell.campus.fun.v1';
  var FUN_COOKIE = 'okayell_campus_fun_v1';
  var NTFY_TOPIC = 'okayell_happy_campus_v4';
  var MQTT_BROKERS = [
    'wss://broker.emqx.io:8084/mqtt',
    'wss://broker.hivemq.com:8884/mqtt'
  ];
  var MQTT_PEER_PREFIX = 'okayell/happy_campus/v5/peers/';
  var MQTT_LIVE_TOPIC = 'okayell/happy_campus/v5/live';
  var MQTT_CTL_TOPIC = 'okayell/happy_campus/v5/ctl';
  var BC_NAME = 'okayell.campus.presence.v1';
  var TABS_KEY = 'okayell.campus.tabs.v1';
  var NAV_TS_KEY = 'okayell.campus.nav_ts.v1';
  var TAB_LEASE_MS = 28000;
  var TAB_ID = 't_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
  var TEST_UID_RE = /^(u-verify|stu_test|test_|bot_|e2e_|headless_)/i;
  var TEST_NAMES = { '學員': 1, '開心學員': 1, '測試學員': 1, 'TestUser': 1 };

  /* ------------------------------------------------------------ 🏅 各學院專屬成就與學習時數定義 */
  var ACAD_ACH = {
    acad_en_1: { icon: '🇬🇧', name: '英語開口說', tier: 't1', pts: 8, title: '🇬🇧 英語留學生' },
    acad_en_2: { icon: '🎙️', name: '英語實戰達人', tier: 't2', pts: 20, title: '🎙️ 雙語溝通王' },
    acad_en_3: { icon: '🗣️', name: '英語母語級演說家', tier: 't4', pts: 35, title: '🗣️ 英語流利演說家' },
    acad_jp_1: { icon: '🇯🇵', name: '五十音初心者', tier: 't1', pts: 8, title: '🇯🇵 日語研修生' },
    acad_jp_2: { icon: '⛩️', name: '日語會話達人', tier: 't2', pts: 20, title: '⛩️ 東京自由行達人' },
    acad_jp_3: { icon: '🏯', name: '日檢 N1 語感制霸', tier: 't4', pts: 35, title: '🏯 日語商務達人' },
    acad_kr_1: { icon: '🇰🇷', name: '四十音初心者', tier: 't1', pts: 8, title: '🇰🇷 韓語語學堂新生' },
    acad_kr_2: { icon: '🎎', name: '韓語會話達人', tier: 't2', pts: 20, title: '🎎 首爾自由行達人' },
    acad_kr_3: { icon: '🎤', name: '韓流語感自由行', tier: 't4', pts: 35, title: '🎤 韓語會話特派員' },
    acad_fin_1: { icon: '🏛️', name: '財經必修課', tier: 't1', pts: 8, title: '🏛️ 財經研究員' },
    acad_fin_2: { icon: '📊', name: '華爾街特訓生', tier: 't2', pts: 20, title: '📊 華爾街分析師' },
    acad_fin_3: { icon: '🏦', name: '華爾街宏觀策略師', tier: 't4', pts: 35, title: '🏦 宏觀資產配置家' },
    acad_stk_1: { icon: '📈', name: '台股觀測員', tier: 't1', pts: 8, title: '📈 台股觀察家' },
    acad_stk_2: { icon: '🕯️', name: 'K 線選股達人', tier: 't2', pts: 20, title: '🕯️ 台股波段領航員' },
    acad_stk_3: { icon: '📊', name: '台股多因子操盤手', tier: 't4', pts: 35, title: '📊 台股量化投資長' },
    acad_cm_1: { icon: '💚', name: '暖心陪伴者', tier: 't1', pts: 8, title: '💚 暖心實習個管師' },
    acad_cm_2: { icon: '🩺', name: '資深個管專家', tier: 't2', pts: 20, title: '🩺 專業藥癮個管師' },
    acad_cm_3: { icon: '🕊️', name: '成癮復原督導專家', tier: 't4', pts: 35, title: '🕊️ 資深臨床個管督導' },
    acad_hc_1: { icon: '🩺', name: '保健室見習生', tier: 't1', pts: 8, title: '🩺 校園保健守護員' },
    acad_hc_2: { icon: '🚑', name: '急救守護達人', tier: 't2', pts: 20, title: '🚑 急救黃金救援王' },
    acad_hc_3: { icon: '🏥', name: '全人健康照護顧問', tier: 't4', pts: 35, title: '🏥 全人健康總顧問' },
    acad_mus_1: { icon: '🎵', name: '樂理初體驗', tier: 't1', pts: 8, title: '🎵 樂理練習生' },
    acad_mus_2: { icon: '🎹', name: '絕對音感大師', tier: 't2', pts: 20, title: '🎹 校園鋼琴家' },
    acad_mus_3: { icon: '🎻', name: '皇家樂團交響指揮', tier: 't4', pts: 35, title: '🎻 皇家樂團首席指揮' },
    acad_cook_1: { icon: '🍳', name: '廚房初試啼聲', tier: 't1', pts: 8, title: '🍳 見習小當家' },
    acad_cook_2: { icon: '👨‍🍳', name: '世界料理主廚', tier: 't2', pts: 20, title: '👨‍🍳 特級行政主廚' },
    acad_cook_3: { icon: '🍾', name: '米其林三星行政主廚', tier: 't4', pts: 35, title: '🍾 米其林三星主廚' },
    acad_trv_1: { icon: '💡', name: '冷知識好奇寶寶', tier: 't1', pts: 8, title: '💡 冷知識蒐集家' },
    acad_trv_2: { icon: '🎰', name: '冷知識轉蛋王', tier: 't2', pts: 20, title: '🧠 行走百科全書' },
    acad_trv_3: { icon: '🦉', name: '跨領域百科博學者', tier: 't4', pts: 35, title: '🦉 皇家百科博學者' },
    acad_trv_sub: { icon: '📮', name: '冷知識專欄作家', tier: 't3', pts: 35, title: '📮 冷知識專欄作家' },
    acad_hr_1: { icon: '🔧', name: '水電修繕學徒', tier: 't1', pts: 8, title: '🔧 居家水電學徒' },
    acad_hr_2: { icon: '⚡', name: '全能修繕達人', tier: 't2', pts: 20, title: '⚡ 居家修繕達人' },
    acad_hr_3: { icon: '🧰', name: '甲種水電與全屋修繕顧問', tier: 't4', pts: 35, title: '🧰 全屋修繕首席技師' },
    acad_fit_1: { icon: '💪', name: '鐵館初登場', tier: 't1', pts: 8, title: '💪 健身房新秀' },
    acad_fit_2: { icon: '🏋️', name: '肌力解剖達人', tier: 't2', pts: 20, title: '🏋️ 鋼鐵肌力王' },
    acad_fit_3: { icon: '🏆', name: '運動科學首席教練', tier: 't4', pts: 35, title: '🏆 運動科學總教練' },
    acad_py_1: { icon: '🐍', name: 'Python 初探', tier: 't1', pts: 8, title: '🐍 Python 見習工程師' },
    acad_py_2: { icon: '🤖', name: 'Python 自動化大師', tier: 't2', pts: 20, title: '🤖 Python 自動化架構師' },
    acad_py_3: { icon: '🚀', name: '首席測試與全端架構師', tier: 't4', pts: 40, title: '🚀 首席測試架構師' },
    acad_iot_1: { icon: '🏡', name: '智慧家庭初探', tier: 't1', pts: 8, title: '🏡 智慧家庭設計師' },
    acad_iot_2: { icon: '📡', name: 'Matter 物聯網達人', tier: 't2', pts: 20, title: '📡 全屋自動化架構師' },
    acad_iot_3: { icon: '🌐', name: 'Matter 跨生態系宗師', tier: 't4', pts: 35, title: '🌐 智慧家庭首席架構師' },
    acad_pkr_1: { icon: '♠️', name: '賽局理論入門', tier: 't1', pts: 8, title: '♠️ 賽局策略研修生' },
    acad_pkr_2: { icon: '👑', name: 'GTO 決策大師', tier: 't2', pts: 20, title: '👑 GTO 決策大師' },
    acad_pkr_3: { icon: '🃏', name: 'GTO 混合策略傳奇', tier: 't4', pts: 35, title: '🃏 高額桌 GTO 傳奇' },
    acad_nba_1: { icon: '🏀', name: 'NBA 數據球探', tier: 't1', pts: 8, title: '🏀 NBA 數據球探' },
    acad_nba_2: { icon: '🔥', name: '籃球數據分析師', tier: 't2', pts: 20, title: '🔥 籃壇數據精算師' },
    acad_nba_3: { icon: '🏀', name: 'NBA 冠軍球隊數據總管', tier: 't4', pts: 35, title: '🏀 冠軍球隊數據總管' },
    acad_epl_1: { icon: '⚽', name: '英超戰術觀察員', tier: 't1', pts: 8, title: '⚽ 英超觀察員' },
    acad_epl_2: { icon: '🦁', name: '英超戰術分析師', tier: 't2', pts: 20, title: '🦁 英超戰術大師' },
    acad_epl_3: { icon: '⚽', name: '英超豪門戰術總教練', tier: 't4', pts: 35, title: '⚽ 英超戰術分析總監' },
    acad_f1_1: { icon: '🏎️', name: 'F1 維修區工程師', tier: 't1', pts: 8, title: '🏎️ 賽道策略師' },
    acad_f1_2: { icon: '🏁', name: '桿位策略總監', tier: 't2', pts: 20, title: '🏁 桿位策略總監' },
    acad_f1_3: { icon: '🏎️', name: 'F1 圍場首席策略長', tier: 't4', pts: 35, title: '🏎️ 圍場首席賽事策略長' },
    acad_bb_1: { icon: '⚾', name: 'MLB 數據紀錄員', tier: 't1', pts: 8, title: '⚾ MLB 數據觀察員' },
    acad_bb_2: { icon: '⚾', name: 'MLB 球探分析師', tier: 't2', pts: 20, title: '⚾ 大聯盟球探分析師' },
    acad_bb_3: { icon: '⚾', name: 'MLB 大聯盟魔球總管', tier: 't4', pts: 35, title: '⚾ 大聯盟魔球數據總管' },
    acad_twb_1: { icon: '⛹️', name: '台籃球探報到', tier: 't1', pts: 8, title: '⛹️ 台籃觀察員' },
    acad_twb_2: { icon: '🏀', name: '台籃數據分析師', tier: 't2', pts: 20, title: '🏀 台籃數據精算師' },
    acad_twb_3: { icon: '🏆', name: '台灣職籃戰術總管', tier: 't4', pts: 35, title: '🏆 台灣職籃冠軍總管' },
    acad_deep20: { icon: '🎓', name: '單科精修筆記王', tier: 't4', pts: 55, title: '🎓 首席模範生' },
    acad_acts50: { icon: '📚', name: '百煉成鋼大學霸', tier: 't5', pts: 100, title: '📚 百煉成鋼大學霸' },
    acad_acts100: { icon: '🔥', name: '千錘百鍊實作王（100 次）', tier: 't5', pts: 130, title: '🔥 千錘百鍊實作王' },
    time_3m: { icon: '🌱', name: '初來乍到（3 分鐘）', tier: 't1', pts: 8, title: '🌱 初心學員' },
    time_5m: { icon: '⏱️', name: '專注五分鐘（5 分鐘）', tier: 't1', pts: 10, title: '⏱️ 五分鐘專注達人' },
    time_10m: { icon: '⏳', name: '專注一刻（10 分鐘）', tier: 't2', pts: 15, title: '⏳ 專注學習者' },
    time_30m: { icon: '🕯️', name: '半小時學霸（30 分鐘）', tier: 't3', pts: 30, title: '🕯️ 半小時學霸' },
    time_60m: { icon: '🔥', name: '一小時苦讀（60 分鐘）', tier: 't4', pts: 55, title: '🔥 黃金苦讀生' },
    time_120m: { icon: '📚', name: '兩小時沉浸（2 小時）', tier: 't4', pts: 75, title: '📚 兩小時沉浸學者' },
    time_180m: { icon: '🏛️', name: '學園常駐生（3 小時）', tier: 't5', pts: 110, title: '🏛️ 學園榮譽院士' },
    time_360m: { icon: '🌟', name: '六小時博學者（6 小時）', tier: 't6', pts: 200, title: '🌟 終身榮譽講座教授' },
    time_600m: { icon: '🌌', name: '十小時神話大學士（10 小時）', tier: 't7', pts: 320, title: '🌌 開心學園十小時傳奇大學士' },
    time_acad10m: { icon: '🔬', name: '單科深造（同院 10 分鐘）', tier: 't2', pts: 18, title: '🔬 專科研究員' },
    time_acad30m: { icon: '🪑', name: '把學院板凳坐穿（同院 30 分鐘）', tier: 't4', pts: 50, title: '🪑 院長室特聘助教' },
    night_owl: { icon: '🦉', name: '深夜暗光鳥', tier: 't3', pts: 25, title: '🦉 深夜暗光鳥' },
    early_bird: { icon: '🌅', name: '晨光早鳥王', tier: 't3', pts: 25, title: '🌅 晨光早鳥王' },
    wacky_lunch: { icon: '🍱', name: '便當配K線', tier: 't1', pts: 10, title: '🍱 午休也在捲' },
    streak_3d: { icon: '📅', name: '三日連學', tier: 't3', pts: 35, title: '📅 持之以恆獎' },
    streak_7d: { icon: '🏅', name: '七日全勤榮譽生', tier: 't5', pts: 100, title: '🏅 七日全勤模範生' },
    streak_14d: { icon: '🔥', name: '雙週連學毅力王', tier: 't5', pts: 130, title: '🔥 雙週不輟學習家' },
    streak_30d: { icon: '👑', name: '三十日終身學習傳奇', tier: 't6', pts: 220, title: '👑 月度全勤榮譽學長' },
  };
  var TOOL_ACH_MAP = {
    english: ['acad_en_1', 'acad_en_2', 'acad_en_3'],
    japanese: ['acad_jp_1', 'acad_jp_2', 'acad_jp_3'],
    korean: ['acad_kr_1', 'acad_kr_2', 'acad_kr_3'],
    finance: ['acad_fin_1', 'acad_fin_2', 'acad_fin_3'],
    stock: ['acad_stk_1', 'acad_stk_2', 'acad_stk_3'],
    'addiction-cm': ['acad_cm_1', 'acad_cm_2', 'acad_cm_3'],
    'health-care': ['acad_hc_1', 'acad_hc_2', 'acad_hc_3'],
    music: ['acad_mus_1', 'acad_mus_2', 'acad_mus_3'],
    cooking: ['acad_cook_1', 'acad_cook_2', 'acad_cook_3'],
    trivia: ['acad_trv_1', 'acad_trv_2', 'acad_trv_3'],
    'home-repair': ['acad_hr_1', 'acad_hr_2', 'acad_hr_3'],
    fitness: ['acad_fit_1', 'acad_fit_2', 'acad_fit_3'],
    coding: ['acad_py_1', 'acad_py_2', 'acad_py_3'],
    'smart-iot': ['acad_iot_1', 'acad_iot_2', 'acad_iot_3'],
    poker: ['acad_pkr_1', 'acad_pkr_2', 'acad_pkr_3'],
    nba: ['acad_nba_1', 'acad_nba_2', 'acad_nba_3'],
    epl: ['acad_epl_1', 'acad_epl_2', 'acad_epl_3'],
    f1: ['acad_f1_1', 'acad_f1_2', 'acad_f1_3'],
    baseball: ['acad_bb_1', 'acad_bb_2', 'acad_bb_3'],
    twbasket: ['acad_twb_1', 'acad_twb_2', 'acad_twb_3'],
  };

  function setCookieBoth(name, val) {
    if (window.location && window.location.protocol === 'file:') return;
    try {
      document.cookie = name + '=' + val + '; path=/; max-age=31536000; SameSite=Lax';
      var hParts = String(window.location.hostname || '').split('.');
      if (hParts.length >= 4 && /^[ab][0-9a-f]{20,}$/i.test(hParts[0])) {
        document.cookie = name + '=' + val + '; domain=.' + hParts.slice(1).join('.') + '; path=/; max-age=31536000; SameSite=Lax';
      }
    } catch (e) { /* ignore */ }
  }

  function readCookieJson(name) {
    if (window.location && window.location.protocol === 'file:') return null;
    try {
      var parts = (document.cookie || '').split(';');
      for (var i = 0; i < parts.length; i++) {
        var kv = parts[i].trim();
        if (kv.indexOf(name + '=') === 0) {
          var obj = JSON.parse(decodeURIComponent(kv.slice(name.length + 1)));
          return obj && typeof obj === 'object' ? obj : null;
        }
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  function readStuCookie() { return readCookieJson(STU_COOKIE); }
  function writeStuCookie(obj) {
    try { setCookieBoth(STU_COOKIE, encodeURIComponent(JSON.stringify(obj))); } catch (e) { /* ignore */ }
  }

  function todayStr() {
    var d = new Date();
    return '' + (d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate());
  }

  function isPlainObj(v) { return !!(v && typeof v === 'object' && !Array.isArray(v)); }

  function mergeDailyRecord(a, b, tDay) {
    var da = isPlainObj(a) && (a.date === tDay || a.day === tDay) ? a : null;
    var db = isPlainObj(b) && (b.date === tDay || b.day === tDay) ? b : null;
    if (!da && !db) {
      return {
        date: tDay, day: tDay, checkin: 0, visit: 0, study: 0, studySec: 0, sport: 0, eco: 0,
        claimed: {}, bonusClaimed: false, fullClaimed: false
      };
    }
    var srcA = da || {}, srcB = db || {};
    var claimed = Object.assign({}, isPlainObj(srcA.claimed) ? srcA.claimed : {}, isPlainObj(srcB.claimed) ? srcB.claimed : {});
    var studyVal = Math.max(+srcA.study || 0, +srcA.studySec || 0, +srcB.study || 0, +srcB.studySec || 0);
    var bonus = !!(srcA.bonusClaimed || srcA.fullClaimed || srcB.bonusClaimed || srcB.fullClaimed);
    var out = Object.assign({}, srcA, srcB, {
      date: tDay,
      day: tDay,
      checkin: Math.max(+srcA.checkin || 0, +srcB.checkin || 0),
      visit: Math.max(+srcA.visit || 0, +srcB.visit || 0),
      study: studyVal,
      studySec: studyVal,
      sport: Math.max(+srcA.sport || 0, +srcB.sport || 0),
      eco: Math.max(+srcA.eco || 0, +srcB.eco || 0),
      claimed: claimed,
      bonusClaimed: bonus,
      fullClaimed: bonus,
    });
    return out;
  }

  function loadFunState() {
    var ls = {}, ck = readCookieJson(FUN_COOKIE) || {};
    try { ls = JSON.parse(window.localStorage.getItem(FUN_KEY) || '{}') || {}; } catch (e) { ls = {}; }
    var badges = Object.assign({}, isPlainObj(ls.ach) ? ls.ach : {}, isPlainObj(ls.badges) ? ls.badges : {});
    if (Array.isArray(ck.ach)) {
      ck.ach.forEach(function (id) { if (id && !badges[id]) badges[id] = Date.now(); });
    }
    var academyActs = Object.assign({}, isPlainObj(ck.aact) ? ck.aact : {});
    if (isPlainObj(ls.academyActs)) {
      Object.keys(ls.academyActs).forEach(function (k) {
        academyActs[k] = Math.max(+academyActs[k] || 0, +ls.academyActs[k] || 0);
      });
    }
    var academySec = Object.assign({}, isPlainObj(ck.asec) ? ck.asec : {});
    if (isPlainObj(ls.academySec)) {
      Object.keys(ls.academySec).forEach(function (k) {
        academySec[k] = Math.max(+academySec[k] || 0, +ls.academySec[k] || 0);
      });
    }
    var days = Object.assign({}, isPlainObj(ls.studyDays) ? ls.studyDays : {});
    if (Array.isArray(ck.days)) {
      ck.days.forEach(function (d) { if (d) days[d] = 1; });
    }
    var tDay = todayStr();
    days[tDay] = 1;
    var daily = mergeDailyRecord(ck.dl, ls.daily, tDay);
    return {
      raw: ls,
      badges: badges,
      academyActs: academyActs,
      academySec: academySec,
      days: days,
      studySec: Math.max(+ls.studySec || 0, +ck.sec || 0),
      dailyPts: Math.max(+ls.dailyPts || 0, +ck.dpts || 0),
      dailyFullDays: Math.max(+ls.dailyFullDays || 0, +ck.dfull || 0),
      triviaSubmitted: !!(ls.triviaSubmitted || badges.acad_trv_sub),
      daily: daily,
    };
  }

  function saveFunState(st) {
    var tDay = todayStr();
    try {
      var latest = {};
      try { latest = JSON.parse(window.localStorage.getItem(FUN_KEY) || '{}') || {}; } catch (e0) { latest = {}; }
      var mergedAch = Object.assign({}, isPlainObj(latest.ach) ? latest.ach : {}, st.badges || {});
      var mergedActs = Object.assign({}, isPlainObj(latest.academyActs) ? latest.academyActs : {});
      Object.keys(st.academyActs || {}).forEach(function (k) {
        mergedActs[k] = Math.max(+mergedActs[k] || 0, +st.academyActs[k] || 0);
      });
      var mergedSec = Object.assign({}, isPlainObj(latest.academySec) ? latest.academySec : {});
      Object.keys(st.academySec || {}).forEach(function (k) {
        mergedSec[k] = Math.max(+mergedSec[k] || 0, +st.academySec[k] || 0);
      });
      var mergedDays = Object.assign({}, isPlainObj(latest.studyDays) ? latest.studyDays : {}, st.days || {});
      var mergedDaily = mergeDailyRecord(latest.daily, st.daily, tDay);
      st.badges = mergedAch;
      st.academyActs = mergedActs;
      st.academySec = mergedSec;
      st.days = mergedDays;
      st.daily = mergedDaily;
      st.studySec = Math.max(+latest.studySec || 0, +st.studySec || 0);
      st.dailyPts = Math.max(+latest.dailyPts || 0, +st.dailyPts || 0);
      st.dailyFullDays = Math.max(+latest.dailyFullDays || 0, +st.dailyFullDays || 0);

      var merged = Object.assign({}, st.raw || {}, latest, {
        ach: mergedAch,
        academyActs: mergedActs,
        academySec: mergedSec,
        studyDays: mergedDays,
        studySec: st.studySec,
        dailyPts: st.dailyPts,
        dailyFullDays: st.dailyFullDays,
        triviaSubmitted: !!(latest.triviaSubmitted || st.triviaSubmitted),
        daily: mergedDaily,
      });
      window.localStorage.setItem(FUN_KEY, JSON.stringify(merged));
    } catch (e) { /* ignore */ }
    try {
      var prevCk = readCookieJson(FUN_COOKIE) || {};
      var dayKeys = Object.keys(st.days || {}).sort().slice(-30);
      var min = Object.assign({}, prevCk, {
        ach: Object.keys(st.badges || {}),
        sec: +st.studySec || 0,
        asec: st.academySec || {},
        aact: st.academyActs || {},
        days: dayKeys,
        dpts: +st.dailyPts || 0,
        dfull: +st.dailyFullDays || 0,
        dl: st.daily || null,
      });
      var enc = encodeURIComponent(JSON.stringify(min));
      if (enc.length > 3600) {
        delete min.pkmn;
        delete min.cars;
        enc = encodeURIComponent(JSON.stringify(min));
      }
      if (enc.length <= 3900) {
        setCookieBoth(FUN_COOKIE, enc);
      }
    } catch (e) { /* ignore */ }
  }

  function showAchToast(a) {
    if (!a || !document.body) return;
    var el = document.getElementById('campusAchToast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'campusAchToast';
      el.className = 'campus-ach-toast';
      document.body.appendChild(el);
    }
    el.innerHTML = '<span class="cat-ic">' + fbEsc(a.icon) + '</span>' +
      '<div class="cat-body"><b>🏅 解鎖學園成就：' + fbEsc(a.name) + '（+' + a.pts + ' 點）</b>' +
      (a.title ? '<span>👑 獲得榮譽稱號「' + fbEsc(a.title) + '」— 可回校園學生證穿戴！</span>' : '') + '</div>';
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(function () { el.classList.remove('show'); }, 4500);
  }

  function unlockInAcademy(st, achId) {
    var a = ACAD_ACH[achId];
    if (!a || st.badges[achId]) return false;
    st.badges[achId] = Date.now();
    saveFunState(st);
    showAchToast(a);
    return true;
  }

  function evaluateDailyInAcademy(st) {
    if (!st || !st.daily) return;
    var d = st.daily;
    d.claimed = isPlainObj(d.claimed) ? d.claimed : {};
    var changed = false;
    var toastItem = null;
    if ((+d.visit || 0) >= 1 && !d.claimed.visit) {
      d.claimed.visit = Date.now();
      st.dailyPts = (+st.dailyPts || 0) + 5;
      changed = true;
    }
    var sSec = Math.max(+d.study || 0, +d.studySec || 0);
    d.study = sSec;
    d.studySec = sSec;
    if (sSec >= 300 && !d.claimed.study) {
      d.claimed.study = Date.now();
      st.dailyPts = (+st.dailyPts || 0) + 6;
      changed = true;
      toastItem = { icon: '⏱️', name: '每日任務達成：每日專注 5 分鐘', pts: 6, title: '' };
    }
    var allFive = !!(d.claimed.checkin && d.claimed.visit && d.claimed.study && d.claimed.sport && d.claimed.eco);
    if (allFive && !d.bonusClaimed) {
      d.bonusClaimed = true;
      d.fullClaimed = true;
      st.dailyPts = (+st.dailyPts || 0) + 5;
      st.dailyFullDays = (+st.dailyFullDays || 0) + 1;
      changed = true;
      toastItem = { icon: '🎁', name: '今日 5 項每日任務全勤達成！', pts: 5, title: '' };
    }
    if (changed) {
      saveFunState(st);
      if (toastItem) showAchToast(toastItem);
    }
  }

  function checkAcademyProgress(st, toolId) {
    evaluateDailyInAcademy(st);
    var trio = TOOL_ACH_MAP[toolId];
    var acts = +(st.academyActs[toolId] || 0);
    var aSec = +(st.academySec[toolId] || 0);
    if (trio) {
      if (acts >= 1 || aSec >= 5) unlockInAcademy(st, trio[0]);
      if (acts >= 5 || aSec >= 300) unlockInAcademy(st, trio[1]);
      if (trio[2] && (acts >= 15 || aSec >= 900)) unlockInAcademy(st, trio[2]);
    }
    if (acts >= 20 || aSec >= 1200) unlockInAcademy(st, 'acad_deep20');
    var totalActs = Object.keys(st.academyActs || {}).reduce(function (s, k) { return s + (+st.academyActs[k] || 0); }, 0);
    if (totalActs >= 50) unlockInAcademy(st, 'acad_acts50');
    if (totalActs >= 100) unlockInAcademy(st, 'acad_acts100');
    if (aSec >= 600) unlockInAcademy(st, 'time_acad10m');
    if (aSec >= 1800) unlockInAcademy(st, 'time_acad30m');
    if (st.studySec >= 180) unlockInAcademy(st, 'time_3m');
    if (st.studySec >= 300) unlockInAcademy(st, 'time_5m');
    if (st.studySec >= 600) unlockInAcademy(st, 'time_10m');
    if (st.studySec >= 1800) unlockInAcademy(st, 'time_30m');
    if (st.studySec >= 3600) unlockInAcademy(st, 'time_60m');
    if (st.studySec >= 7200) unlockInAcademy(st, 'time_120m');
    if (st.studySec >= 10800) unlockInAcademy(st, 'time_180m');
    if (st.studySec >= 21600) unlockInAcademy(st, 'time_360m');
    if (st.studySec >= 36000) unlockInAcademy(st, 'time_600m');
    if (st.triviaSubmitted) unlockInAcademy(st, 'acad_trv_sub');
    var now = new Date(), hr = now.getHours(), mn = now.getMinutes();
    if (hr >= 0 && hr < 5) unlockInAcademy(st, 'night_owl');
    if (hr >= 5 && hr < 8) unlockInAcademy(st, 'early_bird');
    if ((hr === 11 && mn >= 30) || hr === 12 || (hr === 13 && mn <= 30)) unlockInAcademy(st, 'wacky_lunch');
    var dayCnt = Object.keys(st.days || {}).length;
    if (dayCnt >= 3) unlockInAcademy(st, 'streak_3d');
    if (dayCnt >= 7) unlockInAcademy(st, 'streak_7d');
    if (dayCnt >= 14) unlockInAcademy(st, 'streak_14d');
    if (dayCnt >= 30) unlockInAcademy(st, 'streak_30d');
  }

  function localOrigin(loc, port) {
    var p = parseInt(port, 10);
    var host = loc.hostname || '';
    var dot = host.indexOf('.');
    if (dot > 0) {
      var label = host.slice(0, dot);
      var pHex = ('0000' + p.toString(16)).slice(-4).toLowerCase();
      if (label.length === 31 && /^a[0-9a-f]{30}$/i.test(label)) {
        return loc.protocol + '//' + (label.slice(0, 9) + pHex + label.slice(13)).toLowerCase() + host.slice(dot);
      }
      if (label.length === 55 && /^b[0-9a-f]{54}$/i.test(label)) {
        return loc.protocol + '//' + (label.slice(0, 33) + pHex + label.slice(37)).toLowerCase() + host.slice(dot);
      }
    }
    return loc.protocol + '//' + host + ':' + p;
  }

  function campusBase() {
    var loc = window.location;
    if (loc.protocol === 'http:' || loc.protocol === 'https:') {
      var host = loc.hostname || '';
      if (/(^|\.)github\.io$/i.test(host)) return loc.origin + '/';
      return localOrigin(loc, LOCAL_CAMPUS_PORT) + '/';
    }
    return PUBLIC_CAMPUS;
  }

  function campusUrl(toolId) {
    var base = campusBase();
    return toolId ? base + '?from=' + encodeURIComponent(toolId) : base;
  }

  function toolUrl(targetId, hash) {
    var t = TOOL_MAP[targetId];
    var h = String(hash || '').trim();
    if (h && h.charAt(0) !== '#') h = '#' + (h.charAt(0) === '/' ? '' : '/') + h;
    if (!t) return campusUrl(targetId);
    var loc = window.location;
    if (loc.protocol === 'http:' || loc.protocol === 'https:') {
      var host = loc.hostname || '';
      if (/(^|\.)github\.io$/i.test(host)) return loc.origin + '/' + t.path + h;
      // mount：已併入開心學園 server → :8919/<path>/；其餘學院仍是各自的 port
      if (t.mount) return localOrigin(loc, LOCAL_CAMPUS_PORT) + '/' + t.path + h;
      return localOrigin(loc, t.port) + '/' + h;
    }
    return PUBLIC_CAMPUS + t.path + h;
  }

  var _navBc = null;
  var _navEs = null;
  var _navEsRetryT = 0;
  var _navEsBackoff = 2000;
  var _navMqttClients = [];
  var _lastActMs = Date.now();
  var _lastMqttSendMs = 0;
  var _lastNtfySendMs = 0;
  var _lastApiSendMs = 0;
  var _lastPongSentMs = 0;
  var _clockOffsetSec = 0;
  var _internalNav = false;
  var _leftSent = false;
  var _presenceLoopBound = false;

  /* ------------------------------------------------------------ 輕量級原生 MQTT 3.1.1 over WebSocket 編解碼 */
  var _utf8Enc = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null;
  var _utf8Dec = typeof TextDecoder !== 'undefined' ? new TextDecoder() : null;
  function mqttUtf8Encode(str) {
    var s = String(str || '');
    if (_utf8Enc) return _utf8Enc.encode(s);
    var out = [], i = 0;
    for (; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f));
      else out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
    }
    return new Uint8Array(out);
  }
  function mqttUtf8Decode(u8) {
    if (_utf8Dec) return _utf8Dec.decode(u8);
    try { return decodeURIComponent(escape(String.fromCharCode.apply(null, u8))); } catch (e) { return ''; }
  }
  function mqttVarLen(len) {
    var out = [];
    do {
      var d = len % 128;
      len = Math.floor(len / 128);
      if (len > 0) d |= 0x80;
      out.push(d);
    } while (len > 0);
    return out;
  }
  function mqttConnectPkt(clientId) {
    var cid = mqttUtf8Encode(clientId);
    var remLen = 10 + 2 + cid.length;
    var rl = mqttVarLen(remLen);
    var pkt = new Uint8Array(1 + rl.length + remLen);
    var p = 0;
    pkt[p++] = 0x10;
    for (var i = 0; i < rl.length; i++) pkt[p++] = rl[i];
    pkt[p++] = 0x00; pkt[p++] = 0x04;
    pkt[p++] = 77; pkt[p++] = 81; pkt[p++] = 84; pkt[p++] = 84;
    pkt[p++] = 0x04;
    pkt[p++] = 0x02;
    pkt[p++] = 0x00; pkt[p++] = 45;
    pkt[p++] = (cid.length >> 8) & 0xff;
    pkt[p++] = cid.length & 0xff;
    pkt.set(cid, p);
    return pkt;
  }
  function mqttSubscribePkt(pktId, topics) {
    var parts = [], remLen = 2;
    for (var i = 0; i < topics.length; i++) {
      var tb = mqttUtf8Encode(topics[i]);
      parts.push(tb);
      remLen += 2 + tb.length + 1;
    }
    var rl = mqttVarLen(remLen);
    var pkt = new Uint8Array(1 + rl.length + remLen);
    var p = 0;
    pkt[p++] = 0x82;
    for (var j = 0; j < rl.length; j++) pkt[p++] = rl[j];
    pkt[p++] = (pktId >> 8) & 0xff;
    pkt[p++] = pktId & 0xff;
    for (var k = 0; k < parts.length; k++) {
      var t = parts[k];
      pkt[p++] = (t.length >> 8) & 0xff;
      pkt[p++] = t.length & 0xff;
      pkt.set(t, p);
      p += t.length;
      pkt[p++] = 0x00;
    }
    return pkt;
  }
  function mqttPublishPkt(topic, payloadStr, retain) {
    var tb = mqttUtf8Encode(topic);
    var pb = mqttUtf8Encode(payloadStr);
    var remLen = 2 + tb.length + pb.length;
    var rl = mqttVarLen(remLen);
    var pkt = new Uint8Array(1 + rl.length + remLen);
    var p = 0;
    pkt[p++] = 0x30 | (retain ? 0x01 : 0x00);
    for (var i = 0; i < rl.length; i++) pkt[p++] = rl[i];
    pkt[p++] = (tb.length >> 8) & 0xff;
    pkt[p++] = tb.length & 0xff;
    pkt.set(tb, p);
    p += tb.length;
    pkt.set(pb, p);
    return pkt;
  }
  function mqttPingReqPkt() {
    return new Uint8Array([0xc0, 0x00]);
  }
  function navMqttPublish(topic, payloadStr, retain) {
    var sent = 0;
    var pkt = null;
    for (var i = 0; i < _navMqttClients.length; i++) {
      var c = _navMqttClients[i];
      if (c && c.ready && c.ws && c.ws.readyState === 1) {
        try {
          if (!pkt) pkt = mqttPublishPkt(topic, payloadStr, retain);
          c.ws.send(pkt);
          sent++;
        } catch (e) { /* ignore */ }
      }
    }
    return sent;
  }

  function navNowSec() {
    return Math.floor(Date.now() / 1000) + _clockOffsetSec;
  }

  function syncNavClock(srvSec) {
    if (srvSec > 2e10) srvSec = Math.floor(srvSec / 1000);
    if (srvSec > 1700000000) {
      _clockOffsetSec = Math.floor(srvSec) - Math.floor(Date.now() / 1000);
    }
  }

  function isNavBot() {
    if (typeof navigator !== 'undefined' && (navigator.webdriver || /HeadlessChrome|PhantomJS|Playwright|Puppeteer|SlimerJS/i.test(navigator.userAgent || ''))) return true;
    if (window.location && window.location.protocol === 'file:') return true;
    return false;
  }

  function markInternalNav() {
    _internalNav = true;
    try { window.localStorage.setItem(NAV_TS_KEY, String(Date.now())); } catch (e) { /* ignore */ }
  }

  function isInternalHref(href) {
    if (!href) return false;
    try {
      var u = new URL(href, window.location.href);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
      if (u.hostname === window.location.hostname) return true;
      if (/(^|\.)okayell\.github\.io$/i.test(u.hostname)) return true;
    } catch (e) { /* ignore */ }
    return false;
  }

  function touchTabLease(locId) {
    var otherAlive = 0;
    try {
      var now = Date.now();
      var map = JSON.parse(window.localStorage.getItem(TABS_KEY) || '{}') || {};
      var next = {};
      Object.keys(map).forEach(function (k) {
        var it = map[k];
        if (!it || now - (+it.ts || 0) > TAB_LEASE_MS) return;
        next[k] = it;
        if (k !== TAB_ID) otherAlive += 1;
      });
      next[TAB_ID] = { ts: now, loc: locId || '', vis: !document.hidden };
      window.localStorage.setItem(TABS_KEY, JSON.stringify(next));
    } catch (e) { /* ignore */ }
    return otherAlive;
  }

  function removeTabLease() {
    var otherAlive = 0;
    try {
      var now = Date.now();
      var map = JSON.parse(window.localStorage.getItem(TABS_KEY) || '{}') || {};
      var next = {};
      Object.keys(map).forEach(function (k) {
        if (k === TAB_ID) return;
        var it = map[k];
        if (!it || now - (+it.ts || 0) > TAB_LEASE_MS) return;
        next[k] = it;
        otherAlive += 1;
      });
      window.localStorage.setItem(TABS_KEY, JSON.stringify(next));
    } catch (e) { /* ignore */ }
    return otherAlive;
  }

  function recordVisit(toolId) {
    if (!toolId) return;
    try {
      var raw = window.localStorage.getItem(VISITS_KEY);
      var visits = raw ? JSON.parse(raw) : {};
      if (!visits || typeof visits !== 'object' || Array.isArray(visits)) visits = {};
      visits[toolId] = Date.now();
      window.localStorage.setItem(VISITS_KEY, JSON.stringify(visits));
    } catch (e) { /* 無痕模式或空間不足：略過 */ }
    sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'join' });
  }

  function sendBeaconSafe(url, bodyStr, jsonHeaders) {
    try {
      if (navigator.sendBeacon && navigator.sendBeacon(url, bodyStr)) return;
    } catch (e) { /* fallback to fetch keepalive */ }
    try {
      var opts = { method: 'POST', body: bodyStr, keepalive: true };
      if (jsonHeaders) opts.headers = { 'Content-Type': 'application/json' };
      fetch(url, opts).catch(function () {});
    } catch (e) { /* ignore */ }
  }

  function sendPresenceHeartbeat(toolId, opts) {
    opts = opts || {};
    if (!toolId || !TOOL_MAP[toolId]) return;
    if (isNavBot()) return;
    try {
      var t = TOOL_MAP[toolId];
      var lsStu = JSON.parse(window.localStorage.getItem(STU_KEY) || '{}') || {};
      var ckStu = readStuCookie() || {};
      var stu = (lsStu && lsStu.confirmed && lsStu.name) ? lsStu : (ckStu && ckStu.confirmed && ckStu.name) ? ckStu : lsStu;
      if (!stu.uid) {
        stu.uid = (ckStu && ckStu.uid) || ('stu_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7));
      }
      if (!stu.stuNo) {
        stu.stuNo = (ckStu && ckStu.stuNo) || String(1000 + Math.floor(Math.random() * 9000));
      }
      stu.renameCount = Math.max(+lsStu.renameCount || 0, +ckStu.renameCount || 0);
      stu.carId = stu.carId || (ckStu && ckStu.carId) || 'campus-bike';
      stu.carIdx = 0;
      stu.carColor = stu.carColor || '#10b981';
      stu.carName = stu.carName || '🚲 輕快校園單車';
      var carsArr = Array.isArray(lsStu.cars) && lsStu.cars.length ? lsStu.cars
        : Array.isArray(ckStu.cars) && ckStu.cars.length ? ckStu.cars
        : ['campus-bike', stu.carId || 'campus-bike'];
      stu.cars = carsArr.slice(0, 60);
      stu.buildingId = toolId;
      stu.buildingName = t.name;
      stu.buildingIcon = t.icon;
      stu.activity = '正在「' + t.name + '」進修中';
      try {
        var funSt = loadFunState();
        var mergedBadges = {};
        (Array.isArray(stu.badges) ? stu.badges : []).forEach(function (b) { if (b) mergedBadges[b] = 1; });
        (Array.isArray(ckStu.badges) ? ckStu.badges : []).forEach(function (b) { if (b) mergedBadges[b] = 1; });
        Object.keys(funSt.badges || {}).forEach(function (b) { if (b) mergedBadges[b] = 1; });
        stu.badges = Object.keys(mergedBadges).slice(0, 200);
      } catch (e) { /* ignore */ }
      var minBadgeScore = 0;
      (stu.badges || []).forEach(function (bid) {
        if (bid === 'acad_welcome') minBadgeScore += 15;
        else if (ACAD_ACH[bid]) minBadgeScore += (+ACAD_ACH[bid].pts || 0);
      });
      stu.score = Math.max(+stu.score || 0, +lsStu.score || 0, +ckStu.score || 0, minBadgeScore);

      var isLeave = !!opts.leave;
      var curState = isLeave ? 'offline' : ((!document.hidden && (Date.now() - _lastActMs < 90000)) ? 'active' : 'away');
      stu.state = curState;
      stu.ts = navNowSec();
      if (!isLeave) {
        var persisted = Object.assign({}, stu);
        delete persisted.action;
        delete persisted.event;
        window.localStorage.setItem(STU_KEY, JSON.stringify(persisted));
        writeStuCookie(persisted);
      }
      var isConfirmed = !!(stu.confirmed === true && stu.name);
      var dispName = isConfirmed ? String(stu.name).trim() : ('訪客 #' + String(stu.stuNo || stu.uid).slice(-4).toUpperCase());
      if (TEST_UID_RE.test(String(stu.uid)) || (isConfirmed && TEST_NAMES[dispName])) return;
      if (!isConfirmed) return; // 🪪 未在校園地圖取名的訪客不對外廣播（取名後才會出現在在線名單與排行榜）

      var wireMsg = Object.assign({}, stu, {
        name: dispName,
        avatar: stu.avatar || '🧑‍🎓',
        title: stu.title || (isConfirmed ? '🌱 開心學園新生' : '🌱 校園訪客'),
        confirmed: isConfirmed,
        guest: !isConfirmed,
      });
      if (isLeave) {
        wireMsg.action = 'leave';
        wireMsg.event = 'leave';
      } else if (opts.event) {
        wireMsg.event = opts.event;
      }

      if (_navBc) {
        try { _navBc.postMessage(wireMsg); } catch (e) { /* ignore */ }
      } else if (window.BroadcastChannel) {
        try {
          var tmpBc = new BroadcastChannel(BC_NAME);
          tmpBc.postMessage(wireMsg);
          tmpBc.close();
        } catch (e) { /* ignore */ }
      }

      var loc = window.location;
      if (loc.protocol !== 'http:' && loc.protocol !== 'https:') return;
      var host = loc.hostname || '';
      var isGhPages = /(^|\.)github\.io$/i.test(host);
      var bodyStr = JSON.stringify(wireMsg);
      var nowMs = Date.now();

      if (isLeave) {
        navMqttPublish(MQTT_LIVE_TOPIC, bodyStr, false);
        navMqttPublish(MQTT_PEER_PREFIX + stu.uid, bodyStr, true);
        if (!isGhPages) sendBeaconSafe(campusBase() + 'api/presence', bodyStr, true);
        sendBeaconSafe('https://ntfy.sh/' + NTFY_TOPIC, bodyStr, false);
        return;
      }

      var mqttGap = document.hidden ? 28000 : 18000;
      var mqttSent = 0;
      if (opts.forceRemote || nowMs - _lastMqttSendMs >= mqttGap) {
        _lastMqttSendMs = nowMs;
        mqttSent = navMqttPublish(MQTT_LIVE_TOPIC, bodyStr, false);
        navMqttPublish(MQTT_PEER_PREFIX + stu.uid, bodyStr, true);
      }

      if (!isGhPages && (opts.forceRemote || nowMs - _lastApiSendMs >= 14000)) {
        _lastApiSendMs = nowMs;
        fetch(campusBase() + 'api/presence', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: bodyStr,
          keepalive: true
        }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
          if (j && (j.now_sec || j.now)) syncNavClock(j.now_sec || j.now);
        }).catch(function () {});
      }

      // ntfy.sh 每日每 IP 僅 250 則配額：當 MQTT 已連線時由 MQTT 負責即時同步，僅在 MQTT 未就緒或每 180 秒低頻備援
      var ntfyGap = mqttSent > 0 ? 180000 : (document.hidden ? 60000 : 35000);
      if ((opts.forceRemote && mqttSent === 0) || nowMs - _lastNtfySendMs >= ntfyGap) {
        _lastNtfySendMs = nowMs;
        fetch('https://ntfy.sh/' + NTFY_TOPIC, { method: 'POST', body: bodyStr, keepalive: true }).catch(function () {});
      }
    } catch (e) { /* ignore */ }
  }

  function connectSingleAcademyMqtt(url, idx, toolId) {
    if (!window.WebSocket || isNavBot()) return;
    var existing = _navMqttClients[idx];
    if (existing && existing.ws && (existing.ws.readyState === 0 || existing.ws.readyState === 1)) return;
    if (existing && existing.pingT) { clearInterval(existing.pingT); existing.pingT = 0; }
    if (existing && existing.retryT) { clearTimeout(existing.retryT); existing.retryT = 0; }

    var entry = existing || { url: url, ws: null, ready: false, backoff: 1500, pingT: 0, retryT: 0, pktId: 1 };
    entry.ready = false;
    _navMqttClients[idx] = entry;

    var ws;
    try {
      ws = new WebSocket(url, 'mqtt');
      ws.binaryType = 'arraybuffer';
    } catch (e) {
      return;
    }
    entry.ws = ws;
    var rxBuf = new Uint8Array(0);

    ws.onopen = function () {
      if (entry.ws !== ws) return;
      var cid = 'hc_ac_' + TAB_ID.replace(/[^a-zA-Z0-9]/g, '').slice(-10) + '_' + idx + '_' + (Date.now() % 10000);
      try { ws.send(mqttConnectPkt(cid)); } catch (e) { /* ignore */ }
    };

    ws.onmessage = function (ev) {
      if (entry.ws !== ws || !ev || !ev.data) return;
      var chunk = new Uint8Array(ev.data);
      var merged = new Uint8Array(rxBuf.length + chunk.length);
      merged.set(rxBuf, 0);
      merged.set(chunk, rxBuf.length);
      rxBuf = merged;

      while (rxBuf.length >= 2) {
        var byte0 = rxBuf[0];
        var pktType = byte0 >> 4;
        var flags = byte0 & 0x0f;
        var mult = 1, remLen = 0, pos = 1, b;
        do {
          if (pos >= rxBuf.length) return;
          b = rxBuf[pos++];
          remLen += (b & 0x7f) * mult;
          mult *= 128;
        } while ((b & 0x80) !== 0 && pos < 5);

        var totalLen = pos + remLen;
        if (rxBuf.length < totalLen) return;

        var body = rxBuf.subarray(pos, totalLen);
        rxBuf = rxBuf.subarray(totalLen);

        if (pktType === 2) { // CONNACK
          entry.ready = true;
          entry.backoff = 1500;
          try {
            ws.send(mqttSubscribePkt(entry.pktId++, [MQTT_CTL_TOPIC]));
          } catch (e) { /* ignore */ }
          if (entry.pingT) clearInterval(entry.pingT);
          entry.pingT = setInterval(function () {
            if (entry.ws === ws && ws.readyState === 1 && entry.ready) {
              try { ws.send(mqttPingReqPkt()); } catch (e) { /* ignore */ }
            }
          }, 25000);
          // 連上後立即廣播一次目前在該學院的狀態
          if (!_leftSent) {
            sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'join' });
          }
        } else if (pktType === 3 && body.length >= 2) { // PUBLISH
          var tLen = (body[0] << 8) | body[1];
          var pStart = 2 + tLen;
          var qos = (flags >> 1) & 0x03;
          if (qos > 0) pStart += 2;
          if (pStart <= body.length) {
            var topicStr = mqttUtf8Decode(body.subarray(2, 2 + tLen));
            var payloadStr = mqttUtf8Decode(body.subarray(pStart));
            if (topicStr === MQTT_CTL_TOPIC && payloadStr) {
              try {
                var d = JSON.parse(payloadStr);
                if (d && (d.event === 'ping' || d.action === 'ping')) {
                  if (Date.now() - _lastPongSentMs >= 3500) {
                    _lastPongSentMs = Date.now();
                    setTimeout(function () {
                      if (!_leftSent) sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'pong' });
                    }, 80 + Math.floor(Math.random() * 280));
                  }
                }
              } catch (e) { /* ignore */ }
            }
          }
        }
      }
    };

    var onDisconnect = function () {
      if (entry.ws !== ws) return;
      entry.ready = false;
      entry.ws = null;
      if (entry.pingT) { clearInterval(entry.pingT); entry.pingT = 0; }
      if (entry.retryT) clearTimeout(entry.retryT);
      var wait = entry.backoff + Math.floor(Math.random() * 600);
      entry.backoff = Math.min(18000, Math.round(entry.backoff * 1.7));
      entry.retryT = setTimeout(function () {
        entry.retryT = 0;
        connectSingleAcademyMqtt(url, idx, toolId);
      }, wait);
    };
    ws.onerror = onDisconnect;
    ws.onclose = onDisconnect;
  }

  function connectAcademyMqtt(toolId) {
    if (!window.WebSocket || isNavBot()) return;
    MQTT_BROKERS.forEach(function (url, idx) {
      connectSingleAcademyMqtt(url, idx, toolId);
    });
  }

  function connectAcademyRollCall(toolId) {
    connectAcademyMqtt(toolId);
    if (!window.EventSource || isNavBot()) return;
    if (_navEs) {
      try { _navEs.close(); } catch (e) { /* ignore */ }
      _navEs = null;
    }
    try {
      var es = new EventSource('https://ntfy.sh/' + NTFY_TOPIC + '/sse');
      _navEs = es;
      es.onopen = function () { _navEsBackoff = 2000; };
      es.onmessage = function (ev) {
        try {
          var m = JSON.parse(ev.data);
          if (m && m.time) syncNavClock(+m.time);
          if (!m || m.event !== 'message' || !m.message) return;
          var d = JSON.parse(m.message);
          if (d && (d.event === 'ping' || d.action === 'ping')) {
            if (Date.now() - _lastPongSentMs >= 3500) {
              _lastPongSentMs = Date.now();
              setTimeout(function () {
                if (!_leftSent) sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'pong' });
              }, 100 + Math.floor(Math.random() * 350));
            }
          }
        } catch (e) { /* ignore */ }
      };
      es.onerror = function () {
        try { es.close(); } catch (e) { /* ignore */ }
        if (_navEs === es) _navEs = null;
        if (_navEsRetryT) clearTimeout(_navEsRetryT);
        var wait = _navEsBackoff + Math.floor(Math.random() * 800);
        _navEsBackoff = Math.min(20000, Math.floor(_navEsBackoff * 1.8));
        _navEsRetryT = setTimeout(function () {
          _navEsRetryT = 0;
          connectAcademyRollCall(toolId);
        }, wait);
      };
    } catch (e) { /* ignore */ }
  }

  function startAcademyPresenceLoop(toolId) {
    if (!toolId || !TOOL_MAP[toolId] || _presenceLoopBound || isNavBot()) return;
    _presenceLoopBound = true;
    touchTabLease(toolId);

    window.addEventListener('keydown', function (e) {
      if (!e) return;
      if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && (e.key === 'r' || e.key === 'R'))) {
        markInternalNav();
      }
    }, true);

    if (window.BroadcastChannel) {
      try {
        _navBc = new BroadcastChannel(BC_NAME);
        _navBc.onmessage = function (ev) {
          var d = ev && ev.data;
          if (!d) return;
          if (d.event === 'tab_closed' && d.tabId !== TAB_ID && !document.hidden) {
            sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'join' });
          } else if (d.event === 'ping' && Date.now() - _lastPongSentMs >= 3000) {
            _lastPongSentMs = Date.now();
            sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'pong' });
          }
        };
      } catch (e) { _navBc = null; }
    }

    var onUserAct = function () {
      var wasAway = (Date.now() - _lastActMs) >= 90000;
      _lastActMs = Date.now();
      _leftSent = false;
      if (wasAway && !document.hidden) {
        sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'active' });
      }
    };
    ['pointerdown', 'keydown', 'touchstart'].forEach(function (evName) {
      window.addEventListener(evName, onUserAct, { passive: true });
    });

    setInterval(function () {
      touchTabLease(toolId);
      sendPresenceHeartbeat(toolId, { forceRemote: false });
    }, 10000);

    document.addEventListener('visibilitychange', function () {
      touchTabLease(toolId);
      if (!document.hidden) {
        _leftSent = false;
        _lastActMs = Date.now();
        connectAcademyMqtt(toolId);
        if (!_navEs) connectAcademyRollCall(toolId);
        sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'active' });
      } else {
        sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'away' });
      }
    });
    window.addEventListener('online', function () {
      _leftSent = false;
      connectAcademyRollCall(toolId);
      sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'join' });
    });
    window.addEventListener('pageshow', function () {
      _leftSent = false;
      _internalNav = false;
      touchTabLease(toolId);
      connectAcademyRollCall(toolId);
      sendPresenceHeartbeat(toolId, { forceRemote: true, event: 'join' });
    });

    function onUnload() {
      if (_leftSent) return;
      _leftSent = true;
      var otherTabs = removeTabLease();
      var recentNavTs = 0;
      try { recentNavTs = +window.localStorage.getItem(NAV_TS_KEY) || 0; } catch (e) { /* ignore */ }
      var isInternal = _internalNav || (Date.now() - recentNavTs < 5000);
      if (otherTabs > 0) {
        if (_navBc) {
          try { _navBc.postMessage({ event: 'tab_closed', tabId: TAB_ID }); } catch (e) { /* ignore */ }
        }
        return;
      }
      if (!isInternal) {
        sendPresenceHeartbeat(toolId, { leave: true });
      }
    }
    window.addEventListener('pagehide', onUnload);
    window.addEventListener('beforeunload', onUnload);

    connectAcademyRollCall(toolId);
  }

  var CSS = [
    '.campus-home{display:inline-flex;align-items:center;gap:5px;flex:none;box-sizing:border-box;height:30px;',
    'padding:0 11px 0 9px;margin:0 6px 0 0;border-radius:999px;border:1px solid #c7d2fe;background:#eef2ff;',
    'color:#3730a3;font:600 13px/1 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans TC","PingFang TC",',
    '"Microsoft JhengHei",sans-serif;letter-spacing:0;text-decoration:none!important;white-space:nowrap;',
    'cursor:pointer;vertical-align:middle;transition:background .15s,box-shadow .15s,transform .15s}',
    '.campus-home:hover{background:#e0e7ff;box-shadow:0 2px 8px rgba(55,48,163,.18);transform:translateY(-1px)}',
    '.campus-home:focus-visible{outline:2px solid #6366f1;outline-offset:2px}',
    '.campus-home .ch-ic{font-size:15px;line-height:1}',
    '.campus-crest-host{background:none!important;border:0!important;padding:0!important;box-shadow:none!important;width:34px!important;height:34px!important;display:inline-flex!important;align-items:center;justify-content:center;flex:none;vertical-align:middle}',
    '.campus-crest-host svg,.campus-brand-crest svg{width:34px;height:34px;display:block;border-radius:9px;box-shadow:0 2px 6px rgba(15,23,42,.18)}',
    '.campus-brand-crest{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;flex:none;vertical-align:middle}',
    '.campus-brand-crest svg{width:32px;height:32px}',
    '.campus-home.campus-sibling{background:#fffbeb;border-color:#fcd34d;color:#92400e;margin-right:10px}',
    '.campus-home.campus-sibling:hover{background:#fef3c7;box-shadow:0 2px 8px rgba(180,83,9,.16)}',
    '.campus-home[data-campus-theme="dark"]{background:rgba(255,255,255,.10);border-color:rgba(255,255,255,.30);color:#f8fafc}',
    '.campus-home[data-campus-theme="dark"]:hover{background:rgba(255,255,255,.18)}',
    '.campus-home.floating{position:fixed;left:12px;top:12px;z-index:2147483000;margin:0;',
    'box-shadow:0 4px 14px rgba(15,23,42,.18)}',
    '.campus-acad-bar{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;padding:8px 12px;margin:8px 0 12px;',
    'border-radius:12px;background:linear-gradient(90deg,#fffbeb,#fef3c7);border:1px solid #fcd34d;font-size:13px;color:#78350f}',
    '.campus-acad-bar b{font-weight:800;color:#92400e;display:inline-flex;align-items:center;gap:4px}',
    '.campus-acad-pill{display:inline-flex;align-items:center;gap:4px;height:26px;padding:0 10px;border-radius:999px;',
    'background:#fff;border:1px solid #f59e0b;color:#92400e;font-size:12.5px;font-weight:700;text-decoration:none!important;',
    'white-space:nowrap;transition:background .15s,transform .15s}',
    '.campus-acad-pill:hover{background:#fef3c7;transform:translateY(-1px)}',
    '.cfb-box{margin-top:8px;padding:12px 14px;border-radius:12px;background:#fffbeb;border:1.5px solid #fcd34d;color:#78350f;font-size:13px;line-height:1.55;text-align:left}',
    '.cfb-hd{font-weight:700;color:#92400e;margin-bottom:3px}.cfb-hd code{background:#fef3c7;border:1px solid #fde68a;border-radius:5px;padding:1px 5px;font-size:12px}',
    '.cfb-sub{font-size:12px;color:#92400e;opacity:.92;margin-bottom:9px}',
    '.cfb-btns{display:flex;flex-wrap:wrap;gap:7px}',
    '.cfb-btn{display:inline-flex;align-items:center;justify-content:center;gap:5px;min-height:34px;padding:5px 11px;border-radius:9px;',
    'border:1px solid #f59e0b;background:#fff;color:#92400e!important;font:700 12.5px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans TC",sans-serif;',
    'text-decoration:none!important;cursor:pointer;transition:background .15s,transform .12s}',
    '.cfb-btn:hover{background:#fef3c7;transform:translateY(-1px)}',
    '.cfb-btn.primary{background:#059669;border-color:#059669;color:#fff!important}',
    '.cfb-btn.primary:hover{background:#047857;border-color:#047857}',
    '.campus-ach-toast{position:fixed;right:18px;bottom:18px;z-index:2147483600;display:flex;align-items:center;gap:10px;',
    'max-width:380px;padding:12px 16px;border-radius:14px;background:linear-gradient(135deg,#0f172a,#1e293b);',
    'border:1.5px solid #fbbf24;color:#f8fafc;box-shadow:0 10px 28px rgba(15,23,42,.35);',
    'font:600 13px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans TC",sans-serif;',
    'opacity:0;transform:translateY(16px);pointer-events:none;transition:opacity .25s,transform .25s}',
    '.campus-ach-toast.show{opacity:1;transform:translateY(0)}',
    '.campus-ach-toast .cat-ic{font-size:26px;line-height:1}',
    '.campus-ach-toast .cat-body{display:flex;flex-direction:column;gap:2px}',
    '.campus-ach-toast .cat-body b{color:#fde68a;font-size:13.5px}',
    '.campus-ach-toast .cat-body span{color:#cbd5e1;font-size:12px}',
    '@media (max-width:640px){.campus-home{padding:0 8px;margin-right:5px}.campus-home:not(.campus-sibling) .ch-txt{display:none}.cfb-btns{display:grid;grid-template-columns:1fr 1fr}.cfb-btn.primary{grid-column:1/-1}}',
    '@media print{.campus-home,.campus-acad-bar,.cfb-box,.campus-ach-toast{display:none!important}}',
  ].join('');

  var DEFAULT_FB_EMAIL = 'okayell@hotmail.com';
  var GH_ISSUES_URL = 'https://github.com/okayell/okayell.github.io/issues/new';

  function fbEsc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function fbCopyText(text) {
    function fallback() {
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
        document.body.appendChild(ta);
        ta.select();
        var ok = document.execCommand('copy');
        document.body.removeChild(ta);
        return Promise.resolve(ok);
      } catch (e) { return Promise.resolve(false); }
    }
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, fallback);
    }
    return fallback();
  }

  // ---------- 意見回饋：靜態網頁（GitHub Pages／file://）按下送出就直接寄出，不讓使用者挑管道 ----------
  // 1) ntfy.sh 中轉頻道（免帳號、CORS 開放）：Cloudtop 校園後端每分鐘收件、存檔並寄信給站長；
  //    站長也可以用 ntfy App 訂閱同一個頻道，收到即時推播。
  // 2) ntfy 連不上時改走 FormSubmit（站長點過一次 FormSubmit 啟用信後即可直接寄信）。
  // 3) 兩條都失敗（例如離線）→ 存進本機佇列，恢復連線或下次開啟開心學園任一頁面時自動補寄。
  var FB_NTFY_TOPIC = 'okayell_campus_fb_0f3731b06b';
  var FB_QUEUE_KEY = 'okayell.campus.fbqueue.v1';
  var FB_MARK = '#開心學園意見回饋';

  function fbHashStr(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    return Math.abs(h);
  }

  function detectDeviceInfo() {
    var ua = (typeof navigator !== 'undefined' && navigator.userAgent) ? String(navigator.userAgent) : '';
    var touch = (typeof navigator !== 'undefined' && navigator.maxTouchPoints) ? +navigator.maxTouchPoints : 0;
    var os = '未知系統';
    var m;
    if (/iPhone/i.test(ua)) {
      m = ua.match(/OS (\d+[._]\d+)/);
      os = 'iPhone' + (m ? ' (iOS ' + m[1].replace('_', '.') + ')' : '');
    } else if (/iPad/i.test(ua) || (/Macintosh/i.test(ua) && touch > 1)) {
      m = ua.match(/OS (\d+[._]\d+)/);
      os = 'iPad' + (m ? ' (iPadOS ' + m[1].replace('_', '.') + ')' : '');
    } else if (/Android/i.test(ua)) {
      m = ua.match(/Android (\d+(?:\.\d+)?)/i);
      os = 'Android' + (m ? ' ' + m[1] : '') + (/Mobile/i.test(ua) ? ' 手機' : ' 平板');
    } else if (/Windows NT/i.test(ua)) {
      os = 'Windows 桌機/筆電';
    } else if (/Macintosh|Mac OS X/i.test(ua)) {
      os = 'Mac 桌機/筆電';
    } else if (/CrOS/i.test(ua)) {
      os = 'Chromebook';
    } else if (/Linux/i.test(ua)) {
      os = 'Linux 桌機';
    }
    var br = '';
    if (/Line\//i.test(ua)) br = 'LINE 內建瀏覽器';
    else if (/Instagram/i.test(ua)) br = 'IG 內建瀏覽器';
    else if (/FBAN|FBAV/i.test(ua)) br = 'FB 內建瀏覽器';
    else if (/EdgA?\//i.test(ua)) br = 'Edge';
    else if (/CriOS\//i.test(ua) || (/Chrome\//i.test(ua) && !/Edg/i.test(ua))) br = 'Chrome';
    else if (/FxiOS\//i.test(ua) || /Firefox\//i.test(ua)) br = 'Firefox';
    else if (/Safari\//i.test(ua)) br = 'Safari';
    var vp = (typeof window !== 'undefined' && window.innerWidth && window.innerHeight)
      ? (window.innerWidth + '×' + window.innerHeight)
      : '';
    return [os, br, vp].filter(Boolean).join(' · ');
  }

  function formatAvatarLabel(av) {
    if (!av) return '';
    var s = String(av);
    if (s.indexOf('pkmn:') === 0) {
      var pid = parseInt(s.slice(5), 10);
      var pk = pid && window.CAMPUS_POKEDEX_GEN1 && window.CAMPUS_POKEDEX_GEN1.BY_ID && window.CAMPUS_POKEDEX_GEN1.BY_ID[pid];
      return pk && pk.name ? ('🦋 ' + pk.name) : ('🦋#' + (pid || ''));
    }
    return s;
  }

  function getReporterInfo() {
    var lsRaw = {}, ckRaw = readStuCookie() || {};
    try { lsRaw = JSON.parse(window.localStorage.getItem(STU_KEY) || '{}') || {}; } catch (e) { lsRaw = {}; }
    var raw = Object.assign({}, ckRaw, lsRaw);
    var uid = String(raw.uid || ckRaw.uid || '').trim();
    var createdNew = false;
    if (!uid) {
      uid = 'stu_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
      createdNew = true;
    }
    var stuNo = String(raw.stuNo || ckRaw.stuNo || '').trim() || ('HC-' + (1000 + (fbHashStr(uid) % 9000)));
    if (createdNew || (!lsRaw.uid && !ckRaw.uid)) {
      var seed = Object.assign({}, lsRaw, { uid: uid, stuNo: stuNo, confirmed: !!raw.confirmed });
      try { window.localStorage.setItem(STU_KEY, JSON.stringify(seed)); } catch (e2) { /* ignore */ }
      if (!ckRaw.uid) writeStuCookie({ uid: uid, stuNo: stuNo, confirmed: !!raw.confirmed, name: raw.name || '' });
    }
    var rawName = String(raw.name || ckRaw.name || '').trim().slice(0, 20);
    var confirmed = !!((raw.confirmed === true || ckRaw.confirmed === true) && rawName && !TEST_NAMES[rawName]);
    var name = confirmed ? rawName : '';
    var av = formatAvatarLabel(raw.avatar || ckRaw.avatar || '');
    var title = String(raw.title || ckRaw.title || '').trim().slice(0, 32);
    var device = detectDeviceInfo();
    var shortTag = name ? (name + ' · ' + stuNo) : ('未命名 · ' + stuNo);
    var summary = name
      ? ((av ? av + ' ' : '') + name + '（學號 ' + stuNo + (title ? ' · 稱號：' + title : '') + ' · UID: ' + uid + '）')
      : ('未命名學員（學號 ' + stuNo + ' · UID: ' + uid + '）');
    return {
      confirmed: confirmed,
      name: name,
      avatar: av,
      stuNo: stuNo,
      uid: uid,
      title: title,
      device: device,
      shortTag: shortTag,
      summary: summary
    };
  }

  function wrapFeedbackFetch() {
    if (!window.fetch || window.fetch._campusFbWrapped) return;
    var origFetch = window.fetch;
    var wrapped = function (input, init) {
      try {
        var urlStr = typeof input === 'string' ? input : (input && input.url ? String(input.url) : '');
        var method = (init && init.method ? String(init.method) : (input && input.method ? String(input.method) : 'GET')).toUpperCase();
        if (method === 'POST' && /(^|\/)api\/feedback(\?|$)/i.test(urlStr) && init && typeof init.body === 'string') {
          var parsed = JSON.parse(init.body);
          if (parsed && typeof parsed === 'object' && !parsed.reporter) {
            var rep = getReporterInfo();
            parsed.reporter = rep.summary;
            parsed.stu_name = rep.name;
            parsed.stu_no = rep.stuNo;
            parsed.stu_uid = rep.uid;
            parsed.stu_title = rep.title;
            parsed.device = rep.device;
            if (!parsed.page && window.location) {
              parsed.page = window.location.protocol === 'file:' ? '離線單一檔' : String(window.location.href).slice(0, 300);
            }
            init = Object.assign({}, init, { body: JSON.stringify(parsed) });
          }
        }
      } catch (e) { /* ignore non-JSON body */ }
      return origFetch.call(this, input, init);
    };
    wrapped._campusFbWrapped = true;
    window.fetch = wrapped;
  }

  /** Accepts sendStaticFeedback(opts) and the legacy sendStaticFeedback('工具名', payload) form. */
  function normalizeFeedback(opts, extra) {
    var o = {};
    var src = typeof opts === 'string' ? (extra || {}) : (opts || {});
    for (var k in src) if (Object.prototype.hasOwnProperty.call(src, k)) o[k] = src[k];
    var tool = typeof opts === 'string' ? opts : (o.toolTitle || o.toolName || o.tool);
    tool = String(tool || '開心學園');
    if (TOOL_MAP[tool] && TOOL_MAP[tool].name) tool = TOOL_MAP[tool].name;
    o.tool = tool;
    o.kindLabel = String(o.kindLabel || o.kind_label || o.categoryLabel || o.category || o.kind || '💬 意見回饋');
    o.title = String(o.title || o.subject || o.name || '').trim();
    o.description = String(o.description || o.message || o.content || o.desc || o.body || '').trim();
    return o;
  }

  function deliveryLinks(opts, extra) {
    var o = normalizeFeedback(opts, extra);
    var rep = o._rep || getReporterInfo();
    var email = o.email || DEFAULT_FB_EMAIL;
    var subject = '[' + o.tool + ' 意見回饋] ' + o.kindLabel + ' — ' + o.title + '（' + rep.shortTag + '）';
    var body = '工具名稱：' + o.tool + '\n回饋類型：' + o.kindLabel + '\n回饋學員：' + rep.summary + '\n使用裝置：' + rep.device + '\n標題：' + o.title + '\n\n內容描述：\n' + o.description + '\n';
    var copyPayload = '收件信箱：' + email + '\n主旨：' + subject + '\n\n' + body;
    return {
      email: email,
      subject: subject,
      body: body,
      copyPayload: copyPayload,
      mailto: 'mailto:' + email + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body),
      gmail: 'https://mail.google.com/mail/?view=cm&fs=1&to=' + encodeURIComponent(email) + '&su=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body),
      outlook: 'https://outlook.live.com/mail/0/deeplink/compose?to=' + encodeURIComponent(email) + '&subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body),
      github: (o.repoIssues || GH_ISSUES_URL) + '?title=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body)
    };
  }

  function twNowText() {
    return new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 19).replace('T', ' ');
  }

  function fetchWithTimeout(url, init, ms) {
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (e) { /* ignore */ } }, ms) : 0;
    if (ctrl) init.signal = ctrl.signal;
    return fetch(url, init).then(function (r) { clearTimeout(timer); return r; },
      function (err) { clearTimeout(timer); throw err; });
  }

  function utf8Len(s) {
    return typeof TextEncoder !== 'undefined' ? new TextEncoder().encode(String(s)).length : String(s).length * 3;
  }

  /** ntfy.sh keeps messages ≤ 4096 bytes inline; clip long descriptions instead of turning them into attachments. */
  function utf8Clip(text, maxBytes) {
    var s = String(text || '');
    if (typeof TextEncoder === 'undefined') return s.length > maxBytes / 3 ? s.slice(0, Math.floor(maxBytes / 3)) + '…（內容過長已截斷）' : s;
    var enc = new TextEncoder();
    if (enc.encode(s).length <= maxBytes) return s;
    var lo = 0, hi = s.length;
    while (lo < hi) {
      var mid = (lo + hi + 1) >> 1;
      if (enc.encode(s.slice(0, mid)).length <= maxBytes - 48) lo = mid; else hi = mid - 1;
    }
    return s.slice(0, lo) + '…（內容過長已截斷）';
  }

  function fbViaNtfy(item) {
    var url = 'https://ntfy.sh/' + FB_NTFY_TOPIC + '?title=' + encodeURIComponent(String(item.subject).slice(0, 180)) + '&tags=speech_balloon';
    // text/plain body + query params = CORS "simple request" (no preflight); ntfy.sh answers with ACAO *.
    return fetchWithTimeout(url, { method: 'POST', body: item.message }, 8000)
      .then(function (r) { return !!(r && r.ok); }, function () { return false; });
  }

  function fbViaFormSubmit(item) {
    return fetchWithTimeout('https://formsubmit.co/ajax/' + item.email, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        _subject: item.subject,
        _template: 'table',
        _captcha: 'false',
        '工具名稱': item.tool,
        '回饋類型': item.kindLabel,
        '回饋學員': item.reporter || '未命名學員',
        '使用裝置': item.device || '',
        '標題': item.title,
        '內容描述': item.description,
        '送出時間': item.createdAt,
        '來源頁面': item.page
      })
    }, 10000).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        return !!(r.ok && (d.success === true || String(d.success).toLowerCase() === 'true'));
      });
    }, function () { return false; });
  }

  /** Resolves to the channel that accepted the item ('relay' | 'ntfy' | 'formsubmit'), or '' if none did. */
  function fbDeliver(item) {
    var relay = window.CAMPUS_FEEDBACK_RELAY || '';
    var first = relay
      ? fetchWithTimeout(relay, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(item) }, 8000)
        .then(function (r) { return !!(r && r.ok); }, function () { return false; })
      : Promise.resolve(false);
    return first.then(function (ok0) {
      if (ok0) return 'relay';
      return fbViaNtfy(item).then(function (ok) {
        if (ok) return 'ntfy';
        return fbViaFormSubmit(item).then(function (ok2) { return ok2 ? 'formsubmit' : ''; });
      });
    });
  }

  function fbQueueLoad() {
    try {
      var q = JSON.parse(localStorage.getItem(FB_QUEUE_KEY) || '[]');
      return Array.isArray(q) ? q : [];
    } catch (e) { return []; }
  }

  function fbQueueSave(q) {
    try {
      if (q.length) localStorage.setItem(FB_QUEUE_KEY, JSON.stringify(q.slice(-30)));
      else localStorage.removeItem(FB_QUEUE_KEY);
    } catch (e) { /* storage full or disabled */ }
  }

  var fbFlushing = null;
  /** Re-sends feedback queued while offline; runs on every page load and on the `online` event. */
  function flushFeedbackQueue() {
    if (fbFlushing) return fbFlushing;
    var q = fbQueueLoad();
    if (!q.length || (typeof navigator !== 'undefined' && navigator.onLine === false)) return Promise.resolve(0);
    var done = {}, sent = 0;
    fbFlushing = q.reduce(function (p, item) {
      return p.then(function () {
        return fbDeliver(item).then(function (ch) { if (ch) { done[item.qid] = 1; sent++; } });
      });
    }, Promise.resolve()).then(function () {
      fbQueueSave(fbQueueLoad().filter(function (x) { return !done[x.qid]; }));
      fbFlushing = null;
      return sent;
    }, function () { fbFlushing = null; return sent; });
    return fbFlushing;
  }

  var fbHandled = {};  // feedback content key → time handed to sendStaticFeedback (fallback de-duplication)
  function fbKey(o) { return [o.tool, o.kindLabel, o.title, o.description].join('\u0001'); }

  function sendStaticFeedback(opts, extra) {
    var o = normalizeFeedback(opts, extra);
    var rep = getReporterInfo();
    o._rep = rep;
    fbHandled[fbKey(o)] = Date.now();
    var links = deliveryLinks(o);
    var loc = window.location;
    var item = {
      qid: 'fb' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      email: links.email,
      subject: links.subject,
      tool: o.tool,
      kindLabel: o.kindLabel,
      reporter: rep.summary,
      stuName: rep.name,
      stuNo: rep.stuNo,
      stuUid: rep.uid,
      stuTitle: rep.title,
      device: rep.device,
      title: o.title,
      description: o.description,
      createdAt: o.createdAt || twNowText(),
      page: loc.protocol === 'file:' ? '離線單一檔' : String(loc.origin + loc.pathname).slice(0, 300)
    };
    // Header + trailer always survive; only the description is clipped to keep the whole message ≤ 3,800 bytes.
    var head = '工具名稱：' + o.tool + '\n回饋類型：' + o.kindLabel + '\n回饋學員：' + rep.summary + '\n使用裝置：' + rep.device + '\n標題：' + o.title + '\n\n內容描述：\n';
    var tail = '\n送出時間：' + item.createdAt + '\n來源頁面：' + item.page +
      '\n學員UID：' + rep.uid + '\n學員學號：' + rep.stuNo +
      (rep.name ? '\n學員暱稱：' + rep.name : '') + '\n' + FB_MARK;
    item.message = head + utf8Clip(o.description, 3800 - utf8Len(head + tail)) + tail;
    return fbDeliver(item).then(function (ch) {
      if (ch) {
        flushFeedbackQueue();
        return { sent: true, channel: ch, links: links };
      }
      var q = fbQueueLoad();
      q.push(item);
      fbQueueSave(q);
      return { sent: false, queued: true, channel: 'queued', links: links };
    });
  }

  /**
   * Shown whenever a page's own sending failed (static send queued, or the local server could not mail):
   * no channel picker. If this exact feedback has not gone through sendStaticFeedback in the last 10 minutes,
   * deliver it now in the background, so 「會自動寄給站長」 is always true.
   */
  function fallbackHtml(opts) {
    if (opts && (opts.title || opts.description || opts.message || opts.content)) {
      var t = fbHandled[fbKey(normalizeFeedback(opts))];
      if (!t || Date.now() - t > 600000) sendStaticFeedback(opts);
    }
    return '<div class="cfb-box cfb-queued">' +
      '<div class="cfb-hd">✅ <b>已收到你的回饋！</b></div>' +
      '<div class="cfb-sub">系統會自動轉寄給站長；若目前網路不穩，會在恢復連線或下次開啟開心學園時自動補寄，不需要任何操作。</div>' +
      '</div>';
  }


  function injectCss() {
    if (document.getElementById('campusNavCss')) return;
    var st = document.createElement('style');
    st.id = 'campusNavCss';
    st.textContent = CSS;
    (document.head || document.documentElement).appendChild(st);
  }

  function decorate(a, toolId) {
    a.href = campusUrl(toolId);
    a.classList.add('campus-home');
    a.removeAttribute('target');
    a.setAttribute('title', '回到開心學園 · 校園地圖');
    a.setAttribute('aria-label', '回到開心學園校園地圖');
    a.innerHTML = '<span class="ch-ic" aria-hidden="true">🏫</span><span class="ch-txt">校園</span>';
  }

  function wireGoLinks(root) {
    var scope = root && root.querySelectorAll ? root : document;
    var links = scope.querySelectorAll('[data-campus-go]');
    for (var i = 0; i < links.length; i++) {
      var el = links[i];
      var tid = el.getAttribute('data-campus-go');
      var h = el.getAttribute('data-campus-hash') || '';
      if (tid) {
        el.href = toolUrl(tid, h);
        el.removeAttribute('target');
      }
    }
  }

  function initAcademyAchievements(toolId) {
    if (!toolId || !TOOL_MAP[toolId]) return;
    var st = loadFunState();
    st.academyActs[toolId] = (st.academyActs[toolId] || 0) + 1;
    if (st.daily) st.daily.visit = (+st.daily.visit || 0) + 1;
    saveFunState(st);
    setTimeout(function () { checkAcademyProgress(st, toolId); }, 600);

    // 每 5 秒累計該學院與全校學習時數（含今日學習任務秒數，同步寫入 study 與 studySec）
    setInterval(function () {
      if (document.hidden) return;
      var cur = loadFunState();
      cur.studySec = (cur.studySec || 0) + 5;
      cur.academySec[toolId] = (cur.academySec[toolId] || 0) + 5;
      if (cur.daily) {
        var nextDailySec = Math.max(+cur.daily.study || 0, +cur.daily.studySec || 0) + 5;
        cur.daily.studySec = nextDailySec;
        cur.daily.study = nextDailySec;
      }
      saveFunState(cur);
      checkAcademyProgress(cur, toolId);
    }, 5000);

    // 在學院內每次互動點擊（練習題、播放音訊、切換篩選、送出表單）累積實作次數
    document.addEventListener('click', function (e) {
      var t = e.target && e.target.closest
        ? e.target.closest('button, .btn, [role="button"], .quiz-opt, .opt-btn, .card, .tab, [data-act]')
        : null;
      if (!t || t.classList.contains('campus-home')) return;
      var cur = loadFunState();
      cur.academyActs[toolId] = (cur.academyActs[toolId] || 0) + 1;
      if (toolId === 'trivia' && (t.id === 'subSubmitBtn' || /投稿/.test(t.textContent || ''))) {
        var form = t.closest ? t.closest('form') : null;
        if (form || t.type === 'submit') cur.triviaSubmitted = true;
      }
      saveFunState(cur);
      checkAcademyProgress(cur, toolId);
    }, true);
  }


  function ensureAcademyIcon(toolId) {
    var cr = toolId && ACADEMY_CRESTS[toolId];
    if (!cr) return;
    try {
      var head = document.head || document.getElementsByTagName('head')[0];
      if (head && !head.querySelector('link[rel="icon"]')) {
        var lk = document.createElement('link');
        lk.rel = 'icon';
        lk.type = 'image/svg+xml';
        lk.href = cr.url;
        head.appendChild(lk);
      }
    } catch (e) { /* ignore */ }
    try {
      var hdr = document.querySelector('header, .topbar, .top-hdr, .site-header, .app-header, .top-header');
      if (!hdr) return;
      var logoEl = hdr.querySelector('.brand-logo, .brand-icon');
      if (logoEl && !logoEl.getAttribute('data-campus-crest')) {
        logoEl.setAttribute('data-campus-crest', toolId);
        logoEl.classList.add('campus-crest-host');
        logoEl.innerHTML = cr.svg;
        return;
      }
      var brandLink = hdr.querySelector('a.brand');
      if (brandLink && !brandLink.querySelector('.campus-brand-crest, .brand-logo, .brand-icon')) {
        var txt = (brandLink.textContent || '').replace(/^[\s\uD800-\uDBFF\uDC00-\uDFFF\u2600-\u27BF\uFE0F]+/, '').trim();
        brandLink.innerHTML = '<span class="campus-brand-crest" aria-hidden="true">' + cr.svg + '</span><span>' + fbEsc(txt || TOOL_MAP[toolId].name) + '</span>';
      }
    } catch (e) { /* ignore */ }
  }

  function init() {
    injectCss();
    var toolId = window.CAMPUS_TOOL_ID || '';
    var nodes = document.querySelectorAll('[data-campus-home]');
    if (nodes.length) {
      for (var i = 0; i < nodes.length; i++) {
        var id = nodes[i].getAttribute('data-campus-home') || toolId;
        if (!toolId) toolId = id;
        decorate(nodes[i], id);
      }
    } else if (document.body) {
      var a = document.createElement('a');
      a.className = 'campus-home floating';
      document.body.appendChild(a);
      decorate(a, toolId);
    }
    wireGoLinks(document);
    if (window.MutationObserver && document.body) {
      var mo = new MutationObserver(function () { wireGoLinks(document); });
      mo.observe(document.body, { childList: true, subtree: true });
    }
    document.addEventListener('click', function (e) {
      var cp = e.target && e.target.closest ? e.target.closest('[data-campus-fb-copy]') : null;
      if (cp) {
        e.preventDefault();
        var txt = cp.getAttribute('data-campus-fb-copy') || '';
        var em = cp.getAttribute('data-campus-fb-email') || DEFAULT_FB_EMAIL;
        fbCopyText(txt).then(function (ok) {
          var orig = cp.getAttribute('data-orig-label') || cp.textContent;
          cp.setAttribute('data-orig-label', orig);
          cp.textContent = ok ? ('✅ 已複製！可貼到信箱寄至 ' + em) : ('信箱：' + em);
          setTimeout(function () { cp.textContent = orig; }, 3800);
        });
        return;
      }
      var anyLink = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      if (anyLink && !e.metaKey && !e.ctrlKey && !e.shiftKey && anyLink.getAttribute('target') !== '_blank') {
        if (anyLink.classList.contains('campus-home') || anyLink.hasAttribute('data-campus-go') || isInternalHref(anyLink.getAttribute('href'))) {
          markInternalNav();
        }
      }
      var a = e.target && e.target.closest ? e.target.closest('[data-campus-go]') : null;
      if (!a) return;
      var tid = a.getAttribute('data-campus-go');
      var h = a.getAttribute('data-campus-hash') || '';
      if (tid) {
        markInternalNav();
        recordVisit(tid);
        a.href = toolUrl(tid, h);
      }
    }, true);
    ensureAcademyIcon(toolId);
    wrapFeedbackFetch();
    recordVisit(toolId);
    startAcademyPresenceLoop(toolId);
    initAcademyAchievements(toolId);
    setTimeout(flushFeedbackQueue, 3000);
    window.addEventListener('online', function () { flushFeedbackQueue(); });
  }

  wrapFeedbackFetch();
  window.CampusNav = {
    base: campusBase,
    url: campusUrl,
    toolUrl: toolUrl,
    wire: wireGoLinks,
    init: init,
    markInternalNav: markInternalNav,
    visitsKey: VISITS_KEY,
    getReporterInfo: getReporterInfo,
    detectDeviceInfo: detectDeviceInfo,
    deliveryLinks: deliveryLinks,
    sendStaticFeedback: sendStaticFeedback,
    flushFeedbackQueue: flushFeedbackQueue,
    fallbackHtml: fallbackHtml
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
