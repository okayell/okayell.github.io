/* Page 2: 📊 完賽讓分過盤／大小分紀錄 ＆ 全聯盟 30 隊過盤排行榜 (#/results) */
(function () {
  'use strict';
  const NBA = window.NBA;

  function renderLedger(snap) {
    const finals = (snap.games || []).filter((g) => g.status === 'FINAL').slice().reverse();
    const dtSel = NBA.state.resultsDate;
    const fSel = NBA.state.resultsFilter;
    const tmSel = NBA.state.resultsTeam;

    const finDates = [...new Set(finals.map((g) => g.tw_date))];
    const filtered = finals.filter((g) => {
      if (dtSel !== 'ALL' && g.tw_date !== dtSel) return false;
      if (tmSel !== 'ALL' && g.home_abbr !== tmSel && g.away_abbr !== tmSel) return false;
      const sp = g.close_spread_home;
      const isFavCover = sp != null && ((sp < 0 && g.ats_winner === 'HOME') || (sp > 0 && g.ats_winner === 'AWAY'));
      const isDogCover = sp != null && ((sp < 0 && g.ats_winner === 'AWAY') || (sp > 0 && g.ats_winner === 'HOME'));
      if (fSel === 'FAV_COVER' && !isFavCover) return false;
      if (fSel === 'DOG_COVER' && !isDogCover) return false;
      if (fSel === 'OVER' && g.ou_result !== 'OVER') return false;
      if (fSel === 'UNDER' && g.ou_result !== 'UNDER') return false;
      if (fSel === 'MODEL_WIN' && !(g.pred.ats_result === 'WIN' || g.pred.ou_result === 'WIN')) return false;
      if (fSel === 'MODEL_LOSS' && !(g.pred.ats_result === 'LOSS' || g.pred.ou_result === 'LOSS')) return false;
      return true;
    });

    const rowsHtml = filtered.map((g) => {
      const h = NBA.teamOf(g.home_abbr);
      const a = NBA.teamOf(g.away_abbr);
      const sp = g.close_spread_home;
      const openSp = g.open_spread_home;
      const p = g.pred || {};

      let atsOutcomeHtml = '<span class="chip muted">無盤口</span>';
      if (sp != null && g.ats_winner) {
        if (g.ats_winner === 'PUSH') {
          atsOutcomeHtml = '<span class="chip warn">➖ 讓分走水 (Push)</span>';
        } else {
          const winTeam = g.ats_winner === 'HOME' ? h : a;
          const winLine = g.ats_winner === 'HOME' ? sp : -sp;
          const isFav = winLine < 0;
          atsOutcomeHtml = `
            <span class="chip ${isFav ? 'info' : 'ok'}">
              ${isFav ? '🗡️ 讓分過盤' : '🛡️ 受讓過盤'} · ${NBA.esc(winTeam.zh)} ${NBA.fmtSpread(winLine)}
            </span>
            <div style="font-size:11px;color:#64748b;margin-top:2px">贏盤差距 ${Math.abs(g.ats_cover_margin || 0).toFixed(1)} 分</div>`;
        }
      }

      let ouOutcomeHtml = '<span class="chip muted">無盤口</span>';
      if (g.close_total && g.ou_result) {
        if (g.ou_result === 'PUSH') {
          ouOutcomeHtml = '<span class="chip warn">➖ 大小走水</span>';
        } else {
          const isOver = g.ou_result === 'OVER';
          ouOutcomeHtml = `
            <span class="chip ${isOver ? 'strong' : 'info'}">
              ${isOver ? '🔴 大分 OVER' : '🔵 小分 UNDER'} (${g.total_points} vs ${g.close_total})
            </span>
            <div style="font-size:11px;color:#64748b;margin-top:2px">${isOver ? '高出' : '低於'}盤口 ${Math.abs(g.ou_margin || 0).toFixed(1)} 分</div>`;
        }
      }

      const mBadges = [];
      if (p.ats_pick !== 'PASS' && p.ats_result) {
        const pickZh = p.ats_pick === 'HOME' ? h.zh : a.zh;
        mBadges.push(`<span class="chip ${p.ats_result === 'WIN' ? 'ok' : p.ats_result === 'LOSS' ? 'bad' : 'warn'}">${p.ats_result === 'WIN' ? '✅' : '❌'} 讓分推${NBA.esc(pickZh)}</span>`);
      }
      if (p.ou_pick !== 'PASS' && p.ou_result) {
        const ouZh = p.ou_pick === 'OVER' ? '大分' : '小分';
        mBadges.push(`<span class="chip ${p.ou_result === 'WIN' ? 'ok' : p.ou_result === 'LOSS' ? 'bad' : 'warn'}">${p.ou_result === 'WIN' ? '✅' : '❌'} 推${ouZh}</span>`);
      }
      if (!mBadges.length) mBadges.push('<span class="chip muted">⚖️ 觀望未出手</span>');

      return `
        <tr>
          <td style="white-space:nowrap">
            <strong>${NBA.esc(g.tw_date || '')}</strong>
            <div style="font-size:11px;color:#64748b">美東 ${NBA.esc(String(g.et_date || '').slice(5))}</div>
          </td>
          <td>
            <div style="display:flex;align-items:center;gap:6px;font-weight:700;flex-wrap:wrap">
              <span class="tm-link" data-team-link="${NBA.esc(a.abbr)}" style="color:#1d4ed8">${NBA.esc(a.zh)}</span>
              <span style="color:#0f172a;background:#f1f5f9;padding:2px 7px;border-radius:6px">${g.away_score} : ${g.home_score}</span>
              <span class="tm-link" data-team-link="${NBA.esc(h.abbr)}" style="color:#1d4ed8">${NBA.esc(h.zh)}</span>
              <button type="button" class="btn btn-soft btn-sm" data-boxscore-gid="${NBA.esc(g.game_id)}" style="padding:2px 7px;font-size:11.5px">📊 球員數據</button>
            </div>
            <div style="font-size:11px;color:#64748b;margin-top:2px">
              各節：客 ${(g.away_q_scores || []).join('-')} ｜ 主 ${(g.home_q_scores || []).join('-')}（主分差 ${Number(g.margin_home || 0) >= 0 ? '+' + Number(g.margin_home || 0) : Number(g.margin_home || 0)}，總分 ${g.total_points || 0}）
            </div>
          </td>
          <td>
            <div style="font-weight:700">主 ${NBA.esc(h.zh)} ${NBA.fmtSpread(sp)}</div>
            <div style="font-size:11px;color:#64748b">初盤 ${NBA.fmtSpread(openSp)} → 晚上11點盤 ${NBA.fmtSpread(sp)}</div>
          </td>
          <td>${atsOutcomeHtml}</td>
          <td>
            <div style="font-weight:700">${g.close_total || '—'} 分</div>
            <div style="font-size:11px;color:#64748b">初盤 ${g.open_total || '—'} → 晚上11點盤 ${g.close_total || '—'}</div>
          </td>
          <td>${ouOutcomeHtml}</td>
          <td>
            <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:4px">${mBadges.join('')}</div>
            <div style="font-size:11.5px;color:#475569;max-width:300px">${NBA.esc(p.postmortem_zh || '')}</div>
          </td>
        </tr>`;
    }).join('');

    return `
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
        <select class="inp" id="resDateSel">
          <option value="ALL">📅 全部完賽日期（共 ${finals.length} 場）</option>
          ${finDates.map((d) => `<option value="${NBA.esc(d)}" ${dtSel === d ? 'selected' : ''}>台灣 ${NBA.esc(d)}</option>`).join('')}
        </select>
        <select class="inp" id="resTeamSel">
          <option value="ALL">🏀 全部 30 支球隊</option>
          ${(snap.teams || []).map((t) => `<option value="${NBA.esc(t.abbr)}" ${tmSel === t.abbr ? 'selected' : ''}>${NBA.esc(t.zh)} (${NBA.esc(t.abbr)}) · 過盤 ${t.ats_w}-${t.ats_l}</option>`).join('')}
        </select>
        <select class="inp" id="resFilterSel">
          <option value="ALL" ${fSel === 'ALL' ? 'selected' : ''}>🔍 全部盤口結果</option>
          <option value="FAV_COVER" ${fSel === 'FAV_COVER' ? 'selected' : ''}>🗡️ 讓分方過盤</option>
          <option value="DOG_COVER" ${fSel === 'DOG_COVER' ? 'selected' : ''}>🛡️ 受讓方過盤（咬盤／爆冷）</option>
          <option value="OVER" ${fSel === 'OVER' ? 'selected' : ''}>🔴 開出大分 (OVER)</option>
          <option value="UNDER" ${fSel === 'UNDER' ? 'selected' : ''}>🔵 開出小分 (UNDER)</option>
          <option value="MODEL_WIN" ${fSel === 'MODEL_WIN' ? 'selected' : ''}>✅ 模型推薦命中場次</option>
          <option value="MODEL_LOSS" ${fSel === 'MODEL_LOSS' ? 'selected' : ''}>❌ 模型失誤檢討場次</option>
        </select>
      </div>

      <div class="tbl-wrap">
        <table class="data-tbl">
          <thead>
            <tr>
              <th>完賽日期</th>
              <th>對戰組合 ＆ 各節比分</th>
              <th>讓分盤（每晚 11 點資訊）</th>
              <th>讓分／受讓過盤結果</th>
              <th>大小分（每晚 11 點資訊）</th>
              <th>大小分結果</th>
              <th>模型對獎 ＆ 賽後檢討歸因</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml || '<tr><td colspan="7" style="text-align:center;padding:24px;color:#64748b">沒有符合篩選條件的完賽紀錄</td></tr>'}
          </tbody>
        </table>
      </div>`;
  }

  function renderTeamAtsBoard(snap) {
    const sk = NBA.state.resultsTeamSort || 'ats_pct';
    const dir = NBA.state.resultsTeamDir === 'asc' ? 1 : -1;
    const conf = NBA.state.resultsTeamConf || 'ALL';

    const valOf = (t, key) => {
      if (key === 'win_pct') {
        const gp = (Number(t.wins) || 0) + (Number(t.losses) || 0);
        return gp > 0 ? Number(t.wins || 0) / gp : Number(t.win_pct || 0);
      }
      if (key === 'under_pct') return 100 - Number(t.over_pct || 50);
      return Number(t[key] != null ? t[key] : 0);
    };

    const sorted = (snap.teams || [])
      .filter((t) => conf === 'ALL' || t.conf === conf)
      .slice()
      .sort((a, b) => {
        const d = (valOf(a, sk) - valOf(b, sk)) * dir;
        if (Math.abs(d) > 1e-6) return d;
        return (Number(b.ats_pct || 0) - Number(a.ats_pct || 0)) || (Number(b.ats_w || 0) - Number(a.ats_w || 0));
      });

    const arrow = (key) => (sk === key ? (dir === -1 ? ' ▼' : ' ▲') : ' ↕');
    const thCls = (key) => `num ${sk === key ? 'th-active' : ''}`;

    return `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px">
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <span style="font-size:12px;font-weight:700;color:#475569">⚡ 排行切換：</span>
          <button type="button" class="date-pill ${sk === 'ats_pct' ? 'active' : ''}" data-rkesort="ats_pct" data-rkedir="desc">🏆 讓分過盤率排行</button>
          <button type="button" class="date-pill ${sk === 'over_pct' ? 'active' : ''}" data-rkesort="over_pct" data-rkedir="desc">🔴 大分開出率排行</button>
          <button type="button" class="date-pill ${sk === 'under_pct' ? 'active' : ''}" data-rkesort="under_pct" data-rkedir="desc">🔵 小分開出率排行</button>
          <button type="button" class="date-pill ${sk === 'win_pct' ? 'active' : ''}" data-rkesort="win_pct" data-rkedir="desc">📈 例行賽勝率排行</button>
          <button type="button" class="date-pill ${sk === 'diff' ? 'active' : ''}" data-rkesort="diff" data-rkedir="desc">⚡ 場均淨勝分排行</button>
        </div>
        <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap">
          <button type="button" class="date-pill ${conf === 'ALL' ? 'active' : ''}" data-rkeconf="ALL">全部 30 隊</button>
          <button type="button" class="date-pill ${conf === 'East' ? 'active' : ''}" data-rkeconf="East">東區 15 隊</button>
          <button type="button" class="date-pill ${conf === 'West' ? 'active' : ''}" data-rkeconf="West">西區 15 隊</button>
        </div>
      </div>

      <div class="tbl-wrap">
        <table class="data-tbl">
          <thead>
            <tr>
              <th>排名</th>
              <th>球隊（點擊看逐場過盤＆球員數據）</th>
              <th>分區</th>
              <th class="${thCls('win_pct')}" data-rkesort="win_pct" title="點擊依例行賽勝率排序">例行賽戰績${arrow('win_pct')}</th>
              <th class="${thCls('diff')}" data-rkesort="diff" title="點擊依場均淨勝分排序">場均得分 / 失分 (淨勝)${arrow('diff')}</th>
              <th class="${thCls('ats_w')}" data-rkesort="ats_w" title="點擊依過盤勝場數排序">讓分過盤戰績 (ATS)${arrow('ats_w')}</th>
              <th class="${thCls('ats_pct')}" data-rkesort="ats_pct" title="點擊依讓分過盤率排序">讓分過盤率${arrow('ats_pct')}</th>
              <th class="${thCls('ou_over')}" data-rkesort="ou_over" title="點擊依大分場次排序">大小分戰績 (大-小-走)${arrow('ou_over')}</th>
              <th class="${thCls('over_pct')}" data-rkesort="over_pct" title="點擊依大分開出率排序">大分開出率 / 小分率${arrow('over_pct')}</th>
            </tr>
          </thead>
          <tbody>
            ${sorted.map((t, i) => {
              const ppg = Number(t.ppg || 0);
              const oppPpg = Number(t.opp_ppg || 0);
              const diff = Number(t.diff || 0);
              const atsPct = Number(t.ats_pct || 0);
              const overPct = Number(t.over_pct || 0);
              const underPct = Math.max(0, 100 - overPct);
              return `
              <tr>
                <td><strong>#${i + 1}</strong></td>
                <td>
                  <div class="tm-link" data-team-link="${NBA.esc(t.abbr)}" style="display:flex;align-items:center;gap:8px;color:#1d4ed8">
                    <img loading="lazy" decoding="async" src="${NBA.esc(t.logo)}" alt="" style="width:24px;height:24px;object-fit:contain">
                    <strong>${NBA.esc(t.zh)}</strong>
                    <span style="color:#64748b;font-size:12px">${NBA.esc(t.abbr)} ›</span>
                  </div>
                </td>
                <td>${t.conf === 'East' ? '東區' : '西區'}</td>
                <td class="num">${NBA.esc(t.record || `${t.wins || 0}-${t.losses || 0}`)} (${NBA.esc(t.streak || '-')})</td>
                <td class="num">${ppg.toFixed(1)} / ${oppPpg.toFixed(1)} <span style="color:${diff >= 0 ? '#15803d' : '#b91c1c'};font-weight:700">(${NBA.fmtSigned(diff, 1)})</span></td>
                <td class="num"><strong>${t.ats_w || 0}勝 - ${t.ats_l || 0}敗${t.ats_p ? ` - ${t.ats_p}走` : ''}</strong></td>
                <td class="num"><span class="chip ${atsPct >= 58 ? 'ok' : atsPct <= 42 ? 'bad' : 'muted'}">${atsPct.toFixed(1)}%</span></td>
                <td class="num"><strong>${t.ou_over || 0}大 - ${t.ou_under || 0}小${t.ou_push ? ` - ${t.ou_push}走` : ''}</strong></td>
                <td class="num">
                  <span class="chip ${overPct >= 58 ? 'strong' : overPct <= 42 ? 'info' : 'muted'}">大 ${overPct.toFixed(1)}%</span>
                  <span style="font-size:11.5px;color:#64748b;margin-left:4px">小 ${underPct.toFixed(1)}%</span>
                </td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>`;
  }

  NBA.pages.results = function (root) {
    const snap = NBA.snap;
    const k = snap.kpi || {};
    const tab = NBA.state.resultsTab;
    const fSel = NBA.state.resultsFilter;
    const favTot = (k.league_fav_cover || 0) + (k.league_dog_cover || 0);
    const ouTot = (k.league_over || 0) + (k.league_under || 0);

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">📊 NBA 完賽讓分過盤 ＆ 大小分完整紀錄帳本</h1>
          <div class="sec-sub">依每日台灣時間 23:00 固定抓取鎖定之讓分盤與大小分核對每場是否過盤、開大或開小，並統計全聯盟 30 隊過盤王與大分隊</div>
        </div>
        <div class="sub-tabs" style="margin-bottom:0">
          <button type="button" class="sub-tab ${tab === 'ledger' ? 'active' : ''}" data-rtab="ledger">📋 逐場完賽過盤帳本</button>
          <button type="button" class="sub-tab ${tab === 'teams' ? 'active' : ''}" data-rtab="teams">🏆 30 隊過盤率＆大小分排行</button>
        </div>
      </div>

      <div class="odds-rule-bar">
        <span>🕚 <strong>盤口對獎基準說明：</strong>本站之<strong>讓分盤（Spread）</strong>與<strong>大小分（Over/Under）</strong>固定抓取<strong>每天晚上 11 點（台灣時間 23:00）</strong>的資訊並鎖定，完賽後一律依此晚上 11 點盤口核對過盤與大小分結果。</span>
        <span class="odds-rule-pill">🔒 固定每天晚上 11:00（台灣時間）資訊</span>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card ${tab === 'ledger' && fSel === 'DOG_COVER' ? 'active' : ''}" data-rkefilter="DOG_COVER" title="點擊篩選受讓方咬盤／爆冷完賽場次">
          <div class="kpi-lbl"><span>聯盟讓分方 vs 受讓方過盤</span><span class="chip ok">點此篩選受讓</span></div>
          <div class="kpi-val">${k.league_fav_cover} : ${k.league_dog_cover}</div>
          <div class="kpi-sub">受讓咬盤率 ${favTot ? ((k.league_dog_cover / favTot) * 100).toFixed(1) : '50.0'}%</div>
        </div>
        <div class="kpi-card ${tab === 'ledger' && fSel === 'OVER' ? 'active' : ''}" data-rkefilter="OVER" title="點擊篩選開出大分 (OVER) 完賽場次">
          <div class="kpi-lbl"><span>聯盟大分 vs 小分場次</span><span class="chip strong">點此篩選大分</span></div>
          <div class="kpi-val">${k.league_over}大 : ${k.league_under}小</div>
          <div class="kpi-sub">大分率 ${ouTot ? ((k.league_over / ouTot) * 100).toFixed(1) : '50.0'}%</div>
        </div>
        <div class="kpi-card ${tab === 'ledger' && fSel === 'MODEL_WIN' ? 'active' : ''}" data-rkefilter="MODEL_WIN" title="點擊篩選模型推薦命中場次">
          <div class="kpi-lbl"><span>🔥 模型強推精選戰績</span><span class="chip info">點此看命中</span></div>
          <div class="kpi-val" style="color:#15803d">${k.strong_w}勝 ${k.strong_l}敗 (${k.strong_win_rate}%)</div>
          <div class="kpi-sub">超越 52.38% 水錢損益兩平線</div>
        </div>
        <div class="kpi-card ${tab === 'teams' ? 'active' : ''}" data-rkefilter="TEAMS" title="點擊切換至 30 隊過盤率＆大小分排行榜">
          <div class="kpi-lbl"><span>🏆 30 隊過盤率＆大小分排行</span><span class="chip warn">點此看排行</span></div>
          <div class="kpi-val" style="color:${k.units_pnl >= 0 ? '#15803d' : '#b91c1c'}">${NBA.fmtSigned(k.units_pnl, 2)}u</div>
          <div class="kpi-sub">投報率 ROI ${NBA.fmtSigned(k.roi_pct, 2)}% · 點擊查看 30 隊過盤榜</div>
        </div>
      </div>

      ${tab === 'ledger' ? renderLedger(snap) : renderTeamAtsBoard(snap)}
    `;

    const dSel = document.getElementById('resDateSel');
    if (dSel) dSel.onchange = () => { NBA.state.resultsDate = dSel.value; NBA.render(); };
    const tSel = document.getElementById('resTeamSel');
    if (tSel) tSel.onchange = () => { NBA.state.resultsTeam = tSel.value; NBA.render(); };
    const fSelEl = document.getElementById('resFilterSel');
    if (fSelEl) fSelEl.onchange = () => { NBA.state.resultsFilter = fSelEl.value; NBA.render(); };
  };
})();
