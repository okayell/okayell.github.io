/* Page: 💬 意見回饋、問題回報與功能許願 (#/feedback) — 送出後寄信至 okayell@hotmail.com */
(function () {
  'use strict';
  const NBA = window.NBA;
  const TARGET_EMAIL = 'okayell@hotmail.com';
  const LS_KEY = 'nba.feedback.v1';

  const KINDS = [
    { id: 'feature', label: '✨ 功能許願' },
    { id: 'bug', label: '🐞 問題回報 (Bug)' },
    { id: 'ux', label: '🎨 介面與體驗建議' },
    { id: 'other', label: '💬 其他意見' },
  ];

  let _fbItems = null;
  let _selKind = 'feature';
  let _sending = false;

  function loadLocalHistory() {
    try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); }
    catch (_) { return []; }
  }

  function saveLocalHistory(items) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(items.slice(0, 50))); }
    catch (_) { /* ignore */ }
  }

  function renderFallbackBox(kindLabel, title, desc, note) {
    if (window.CampusNav && CampusNav.fallbackHtml) {
      return CampusNav.fallbackHtml({
        email: TARGET_EMAIL,
        tool: 'NBA 運彩智庫',
        kindLabel,
        title,
        description: desc,
        note,
      });
    }
    const mailtoUrl = buildMailtoHref(kindLabel, title, desc);
    return `<div class="card" style="background:#fffbeb;border-color:#fcd34d;color:#92400e;padding:10px 13px;font-size:13px">${NBA.esc(note || '請點此寄信：')} <a href="${NBA.esc(mailtoUrl)}" style="font-weight:800;text-decoration:underline">📩 直接以郵件寄送至 ${TARGET_EMAIL}</a></div>`;
  }

  async function sendStaticEmail(item) {
    if (window.CampusNav && CampusNav.sendStaticFeedback) {
      return CampusNav.sendStaticFeedback({
        email: TARGET_EMAIL,
        tool: 'NBA 運彩智庫',
        kindLabel: item.kind_label,
        title: item.title,
        description: item.description,
        createdAt: item.created_at,
      });
    }
    const subject = `[NBA 運彩智庫 意見回饋] ${item.kind_label} — ${item.title}`;
    try {
      const resp = await fetch(`https://formsubmit.co/ajax/${TARGET_EMAIL}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          _subject: subject,
          _template: 'table',
          _captcha: 'false',
          工具名稱: 'NBA 運彩智庫',
          回饋類型: item.kind_label,
          標題: item.title,
          內容描述: item.description,
          送出時間: item.created_at,
        }),
      });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok && (data.success === 'true' || data.success === true)) {
        return { sent: true, channel: 'formsubmit' };
      }
    } catch (_) { /* fallback below */ }
    return { sent: false, channel: 'mailto_ready', subject };
  }

  function buildMailtoHref(kindLabel, title, desc) {
    const subject = `[NBA 運彩智庫 意見回饋] ${kindLabel} — ${title}`;
    const body = `工具名稱：NBA 運彩智庫\n回饋類型：${kindLabel}\n標題：${title}\n\n內容描述：\n${desc}\n`;
    return `mailto:${TARGET_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }

  NBA.pages.feedback = function (root) {
    if (_fbItems === null) {
      _fbItems = loadLocalHistory();
      if (!NBA.isStatic) {
        NBA.apiGet('/api/feedback').then((res) => {
          if (res && Array.isArray(res.items)) {
            _fbItems = res.items;
            if (NBA.route === 'feedback') NBA.render();
          }
        }).catch(() => {});
      }
    }

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">💬 意見回饋・問題回報・功能許願</h1>
          <div class="sec-sub">有任何想法、盤口數據建議、Bug 回報或想新增的功能，歡迎隨時告訴我們！送出後將直接寄送通知信至站長信箱。</div>
        </div>
      </div>

      <div class="fb-layout">
        <form class="card" id="nbaFeedbackForm" style="display:flex;flex-direction:column;gap:14px">
          <div>
            <label style="font-weight:800;font-size:13.5px;display:block">1. 回饋類型</label>
            <div class="fb-type-pills" id="fbKindPills">
              ${KINDS.map((k) => `
                <button type="button" class="fb-type-pill ${_selKind === k.id ? 'active' : ''}" data-fb-kind="${k.id}">${k.label}</button>
              `).join('')}
            </div>
          </div>

          <div>
            <label for="fbTitleInp" style="font-weight:800;font-size:13.5px;display:block;margin-bottom:5px">2. 標題</label>
            <input class="inp" id="fbTitleInp" required maxlength="150" placeholder="簡短說明您的建議、許願功能或遇到的問題…" style="width:100%">
          </div>

          <div>
            <label for="fbDescInp" style="font-weight:800;font-size:13.5px;display:block;margin-bottom:5px">3. 內容描述</label>
            <textarea class="inp" id="fbDescInp" required rows="6" maxlength="4000" placeholder="請描述詳細情境、希望增加的數據指標，或操作上遇到的異常狀況…" style="width:100%;min-height:130px;resize:vertical"></textarea>
          </div>

          <div id="fbStatusBanner" class="hidden"></div>

          <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
            <span style="font-size:12px;color:#64748b">📩 送出後會自動通知站長</span>
            <button type="submit" class="btn btn-primary" id="fbSubmitBtn">📨 送出回饋</button>
          </div>
        </form>

        <div class="card">
          <div class="sec-hdr" style="margin-bottom:10px">
            <h2 class="sec-title" style="font-size:15px">🗂️ 已送出的回饋紀錄（${(_fbItems || []).length}）</h2>
          </div>
          <div style="display:flex;flex-direction:column;gap:10px;max-height:520px;overflow-y:auto">
            ${(_fbItems || []).map((it) => `
              <div class="card" style="padding:11px 13px;background:#f8fafc">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:4px">
                  <span class="chip info">${NBA.esc(it.kind_label || it.kind)}</span>
                  <span style="font-size:11.5px;color:#64748b">${NBA.esc(it.created_at || '')}</span>
                </div>
                <div style="font-weight:800;font-size:14px;color:#0f172a">${NBA.esc(it.title)}</div>
                <div style="font-size:12.5px;color:#334155;margin-top:4px;white-space:pre-wrap">${NBA.esc(it.description)}</div>
              </div>
            `).join('') || '<div class="empty-box" style="padding:26px">目前尚無回饋紀錄，歡迎留下您的第一則建議！</div>'}
          </div>
        </div>
      </div>
    `;

    root.querySelectorAll('[data-fb-kind]').forEach((btn) => {
      btn.onclick = () => {
        _selKind = btn.getAttribute('data-fb-kind');
        root.querySelectorAll('[data-fb-kind]').forEach((b) => b.classList.toggle('active', b === btn));
      };
    });

    const titleInp = document.getElementById('fbTitleInp');
    if (titleInp) {
      titleInp.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter' && !NBA.isEnterSend(ev)) ev.preventDefault();
      });
    }

    const form = document.getElementById('nbaFeedbackForm');
    form.onsubmit = async (ev) => {
      ev.preventDefault();
      if (_sending) return;
      const title = (document.getElementById('fbTitleInp').value || '').trim();
      const description = (document.getElementById('fbDescInp').value || '').trim();
      if (!title || !description) {
        NBA.toast('⚠️ 請填寫標題與內容描述');
        return;
      }
      _sending = true;
      const btn = document.getElementById('fbSubmitBtn');
      const banner = document.getElementById('fbStatusBanner');
      btn.disabled = true;
      btn.textContent = '⏳ 寄送意見回饋中…';

      const kindObj = KINDS.find((k) => k.id === _selKind) || KINDS[0];
      try {
        if (!NBA.isStatic) {
          const res = await NBA.apiPost('/api/feedback', { kind: _selKind, title, description });
          _fbItems = res.items || [res.item, ...(_fbItems || [])];
          saveLocalHistory(_fbItems);
          const sentOk = !res.item || res.item.mail_sent !== false;
          document.getElementById('fbTitleInp').value = '';
          document.getElementById('fbDescInp').value = '';
          if (sentOk) NBA.toast('✅ 感謝您的回饋！已寄送至站長信箱');
          NBA.render();
          const b2 = document.getElementById('fbStatusBanner');
          if (b2) {
            if (sentOk) {
              b2.className = 'card';
              b2.style.cssText = 'background:#f0fdf4;border-color:#86efac;color:#166534;padding:10px 13px;font-size:13px';
              b2.innerHTML = `✅ 已成功收到並寄送通知信給站長！感謝您的寶貴建議。`;
            } else {
              b2.className = '';
              b2.style.cssText = '';
              b2.innerHTML = renderFallbackBox(kindObj.label, title, description, '✅ 回饋已儲存至伺服器紀錄；但自動寄信暫時忙碌，請任選下方一種方式一鍵寄達站長：');
            }
          }
        } else {
          const item = {
            id: 'FB-' + Date.now().toString(36).toUpperCase(),
            kind: _selKind,
            kind_label: kindObj.label,
            title,
            description,
            created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
          };
          const mailRes = await sendStaticEmail(item);
          _fbItems = [item, ...(_fbItems || [])];
          saveLocalHistory(_fbItems);
          document.getElementById('fbTitleInp').value = '';
          document.getElementById('fbDescInp').value = '';
          NBA.render();
          const b2 = document.getElementById('fbStatusBanner');
          if (b2) {
            if (mailRes.sent) {
              b2.className = 'card';
              b2.style.cssText = 'background:#f0fdf4;border-color:#86efac;color:#166534;padding:10px 13px;font-size:13px';
              b2.innerHTML = `✅ 感謝回饋！意見已成功寄送給站長。`;
            } else {
              b2.className = '';
              b2.style.cssText = '';
              b2.innerHTML = renderFallbackBox(kindObj.label, title, description);
            }
          }
        }
      } catch (e) {
        if (banner) {
          banner.className = '';
          banner.style.cssText = '';
          banner.innerHTML = renderFallbackBox(kindObj.label, title, description, `⚠️ 伺服器寄信暫時無法連線（${e.message || '連線忙碌'}），請任選下方一種方式一鍵寄達站長：`);
        }
      } finally {
        _sending = false;
        if (btn) {
          btn.disabled = false;
          btn.textContent = '📨 送出回饋';
        }
      }
    };
  };
})();
