#!/usr/bin/env python3
"""Version, Release Notes & Smart SemVer (1.x.x) Publisher for NBA 運彩智庫 (Pattern 164 / 168)."""
from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import json
import os
import sys
import threading
from typing import Any

import config

ROOT_DIR = config.ROOT_DIR
RELEASES_JSON = os.path.join(ROOT_DIR, 'releases.json')
BASELINE_JSON = os.path.join(config.DATA_DIR, 'release_baseline.json')
RELEASES_JS = os.path.join(config.STATIC_DIR, 'js', 'releases.js')
_LOCK = threading.RLock()

FILE_META: dict[str, tuple[str, str]] = {
    'server.py': ('後端服務', 'HTTP 伺服器、JSON API、每日 5 時段排程與下載端點'),
    'config.py': ('系統設定', '埠號、排程時間與損益兩平水錢參數'),
    'teams.py': ('球隊字典', '30 支 NBA 球隊中英文名稱、縮寫正規化與配色'),
    'net.py': ('網路抓取', '具備限速、Gzip 與指數退避重試之 HTTP 客戶端'),
    'db.py': ('資料庫', 'SQLite 賽事、盤口、傷兵、新聞、模型預測與進化紀錄結構'),
    'updater.py': ('資料管線', '增量與全季賽事盤口回補、過盤統計與自動對獎排程'),
    'model_engine.py': ('量化進化引擎', '8 大讓分因子＋7 大大小分因子（含球星戰舊主戲碼）、賽後檢討與權重自我進化'),
    'storylines.py': ('話題八卦引擎', '球星打老東家 (Revenge Game)、宿敵恩怨、休息室壓力鍋與場外八卦量化模組'),
    'snapshot.py': ('快取彙整', '毫秒級全站 API 快照編譯器'),
    'ai.py': ('AI 解盤教練', 'Jetski Direct Connect-RPC 單場深度解盤與敗因檢討'),
    'feedback_mailer.py': ('意見回饋寄信', '使用者意見回饋儲存與寄送私人信箱 okayell@hotmail.com 模組'),
    'release_mgr.py': ('版本發布', '版號偵測、1.x.x 進位判斷與 Release Notes 管理'),
    'install.sh': ('部署腳本', 'systemd 雙服務安裝與啟動腳本'),
    'README.md': ('文件', '架構與操作說明文件'),
    'sources/espn.py': ('資料來源', 'ESPN 比分、初盤／收盤讓分與大小分、球員單場 Boxscore 與 30 隊名單'),
    'sources/rotowire_and_news.py': ('資料來源', 'RotoWire 預計先發與 GTD 名單、中英文 NBA 傷兵與運彩新聞聚合'),
    'tools/build_dist.py': ('打包匯出', 'GitHub Pages 單一 index.html 離線靜態版建置器'),
    'static/index.html': ('頁面骨架', 'SPA 導覽列、版號徽章與模態視窗骨架'),
    'static/app.css': ('視覺樣式', '清爽亮色高密度運彩數據卡片、NBA.com 排行表格與圖表樣式'),
    'static/js/app.js': ('前端核心', '路由、快取載入、IME 安全輸入、單場 Boxscore 與球員明細彈窗'),
    'static/js/page_picks.js': ('頁面', '隔日／今日運彩盤口分析與下注建議頁'),
    'static/js/page_parlay.js': ('頁面', '每日跨場串關推薦（2串1／3串1／3串4 複式容錯）、台彩與國際盤試算器及本季對獎帳本'),
    'static/js/page_results.js': ('頁面', '完賽讓分過盤／大小分紀錄與 30 隊過盤榜'),
    'static/js/page_team.js': ('頁面', '30 隊球隊專區：過往各場比數、各節比分與每位球員逐場數據'),
    'static/js/page_stats.js': ('頁面', 'NBA.com 風格全聯盟球員／球隊數據排行與各項數據領先者'),
    'static/js/page_news.js': ('頁面', 'NBA 球員傷兵隔日出賽雷達與即時新聞專區'),
    'static/js/page_evolution.js': ('頁面', '模型賽後檢討、因子權重演進與勝率提升中心'),
    'static/js/page_bankroll.js': ('頁面', '個人注單追蹤、凱利注碼與台彩／國際盤期望值試算'),
    'static/js/page_guide.js': ('頁面', 'NBA 運彩讓分／大小分／水錢百科與系統說明'),
    'static/js/page_feedback.js': ('頁面', '意見回饋、Bug 回報與功能許願頁'),
}

DEV_IGNORE_PREFIXES = ('tests/', 'tools/')
EXCLUDED_TRACK = {'static/js/releases.js', 'release_mgr.py'}

INITIAL_RELEASE: dict[str, Any] = {
    'version': '1.0.0',
    'date': '2026-10-29',
    'bump': 'major',
    'title': 'NBA 運彩智庫 v1.0.0 初版發布',
    'notes': '整合每日 NBA 開盤／即時讓分受讓與大小分盤口分析、完賽過盤紀錄、30 隊傷兵隔日出賽雷達、新聞專區與自我檢討進化模型。',
    'highlights': [
        '每日盤口解盤（隔日／今日推薦）：完整對照初盤與即時讓分／受讓、大小分變盤方向、ESPN BPI 勝率、背靠背體能與先發傷兵，給出分級推薦（🔥 強推精選／✅ 順勢推薦／⚖️ 觀望不碰）與建議注碼。',
        '完賽過盤紀錄與 30 隊排行榜：自動結算每場最終比分、讓分盤過盤／輸盤／走水、大小分開大／開小，並統計全聯盟 30 隊本季過盤率與大分率排行。',
        '傷兵出賽雷達與新聞專區：整合 ESPN 官方傷兵報告、RotoWire 即時預計先發與 GTD 名單、以及中英文 NBA 傷兵新聞，標示每位傷兵隔日上場機率與預估影響分數。',
        '自我檢討與勝率進化中心：嚴格依時間序（Walk-Forward）逐場賽後對獎，自動歸納失誤原因（三分極端變異、末節犯規／OT、背靠背崩盤、變盤誘盤），動態調整 13 項量化因子權重與防呆護欄。',
    ],
    'files_count': 0,
}

BUMP_TEXT = {
    'major': '進第 1 位數（X.0.0）：全站架構大改版或大規模核心重構',
    'minor': '進第 2 位數（1.X.0）：新增功能頁面、資料來源或量化模型因子升級',
    'patch': '進第 3 位數（1.x.X）：介面微調、文字修正或小幅參數優化',
}


def tracked_paths() -> list[str]:
  out: list[str] = []
  for name in sorted(os.listdir(ROOT_DIR)):
    if name in EXCLUDED_TRACK:
      continue
    if name.endswith(('.py', '.sh', '.md')) and os.path.isfile(os.path.join(ROOT_DIR, name)):
      out.append(name)
  for folder, exts in (
      ('sources', ('.py',)),
      ('static', ('.html', '.css')),
      ('static/js', ('.js',)),
      ('tools', ('.py', '.mjs', '.js')),
      ('tests', ('.py',)),
  ):
    d = os.path.join(ROOT_DIR, folder)
    if not os.path.isdir(d):
      continue
    for name in sorted(os.listdir(d)):
      rel = f'{folder}/{name}'
      if rel in EXCLUDED_TRACK or name == '__init__.py':
        continue
      if os.path.isfile(os.path.join(ROOT_DIR, rel)) and name.endswith(exts):
        out.append(rel)
  return out


def _read(rel: str) -> str:
  with open(os.path.join(ROOT_DIR, rel), encoding='utf-8', errors='replace') as f:
    return f.read()


def _sha(text: str) -> str:
  return hashlib.sha256(text.encode('utf-8')).hexdigest()


def load_releases() -> dict[str, Any]:
  with _LOCK:
    if os.path.isfile(RELEASES_JSON):
      try:
        with open(RELEASES_JSON, encoding='utf-8') as f:
          data = json.load(f)
        if isinstance(data, dict) and data.get('releases'):
          return data
      except (OSError, ValueError):
        pass
    data = {'current_version': INITIAL_RELEASE['version'], 'releases': [dict(INITIAL_RELEASE)]}
    save_releases(data)
    return data


def save_releases(data: dict[str, Any]) -> None:
  tmp = RELEASES_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
  os.replace(tmp, RELEASES_JSON)
  write_releases_js(data)


def write_releases_js(data: dict[str, Any] | None = None) -> None:
  rel_data = data or load_releases()
  os.makedirs(os.path.dirname(RELEASES_JS), exist_ok=True)
  js = 'window.NBA_RELEASES = ' + json.dumps(rel_data, ensure_ascii=False, separators=(',', ':')) + ';\n'
  tmp = RELEASES_JS + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    f.write(js)
  os.replace(tmp, RELEASES_JS)


def current_version() -> str:
  return str(load_releases().get('current_version') or INITIAL_RELEASE['version'])


def snapshot_baseline(exclude: set[str] | None = None) -> dict[str, Any]:
  ex = exclude or set()
  files: dict[str, dict[str, str]] = {}
  for rel in tracked_paths():
    if rel in ex:
      continue
    txt = _read(rel)
    files[rel] = {'sha': _sha(txt), 'content': txt}
  os.makedirs(config.DATA_DIR, exist_ok=True)
  payload = {
      'version': current_version(),
      'snapshotted_at': dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S'),
      'files': files,
  }
  tmp = BASELINE_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(payload, f, ensure_ascii=False)
  os.replace(tmp, BASELINE_JSON)
  return payload


def _line_diff(old_txt: str, new_txt: str) -> tuple[int, int]:
  old_lines = old_txt.splitlines()
  new_lines = new_txt.splitlines()
  sm = difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False)
  added = removed = 0
  for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag == 'insert':
      added += (j2 - j1)
    elif tag == 'delete':
      removed += (i2 - i1)
    elif tag == 'replace':
      removed += (i2 - i1)
      added += (j2 - j1)
  return added, removed


def _bump_ver(ver: str, bump_type: str) -> str:
  parts = [int(x) for x in ver.lstrip('v').split('.')[:3]]
  while len(parts) < 3:
    parts.append(0)
  if bump_type == 'major':
    return f'{parts[0] + 1}.0.0'
  if bump_type == 'minor':
    return f'{parts[0]}.{parts[1] + 1}.0'
  return f'{parts[0]}.{parts[1]}.{parts[2] + 1}'


def get_release_status() -> dict[str, Any]:
  with _LOCK:
    rel_data = load_releases()
    cur_ver = rel_data['current_version']
    base_files: dict[str, dict[str, str]] = {}
    if os.path.isfile(BASELINE_JSON):
      try:
        with open(BASELINE_JSON, encoding='utf-8') as f:
          base_files = (json.load(f) or {}).get('files') or {}
      except (OSError, ValueError):
        base_files = {}

    cur_paths = tracked_paths()
    cur_set = set(cur_paths)
    changed: list[dict[str, Any]] = []
    prod_added = prod_removed = prod_files = 0
    has_new_prod_file = False

    for rel in cur_paths:
      txt = _read(rel)
      sha = _sha(txt)
      cat, desc = FILE_META.get(rel, ('專案檔案', rel))
      is_prod = not rel.startswith(DEV_IGNORE_PREFIXES) and not rel.endswith('.md')
      if rel not in base_files:
        lines = len(txt.splitlines())
        changed.append({'path': rel, 'status': 'added', 'added': lines, 'removed': 0, 'category': cat, 'desc': desc})
        if is_prod:
          has_new_prod_file = True
          prod_added += lines
          prod_files += 1
      elif base_files[rel].get('sha') != sha:
        ad, rm = _line_diff(base_files[rel].get('content', ''), txt)
        changed.append({'path': rel, 'status': 'modified', 'added': ad, 'removed': rm, 'category': cat, 'desc': desc})
        if is_prod:
          prod_added += ad
          prod_removed += rm
          prod_files += 1

    for old_rel in sorted(set(base_files.keys()) - cur_set):
      rm = len((base_files[old_rel].get('content') or '').splitlines())
      cat, desc = FILE_META.get(old_rel, ('專案檔案', old_rel))
      changed.append({'path': old_rel, 'status': 'deleted', 'added': 0, 'removed': rm, 'category': cat, 'desc': desc})

    churn = prod_added + prod_removed
    if (prod_removed >= 400 and churn >= 1200) or prod_files >= 14 or churn >= 3500:
      rec_bump = 'major'
      reason = f'核心程式碼大幅重構（{prod_files} 個產品檔案、共變動 {churn} 行），建議進第 1 位數。'
    elif has_new_prod_file or prod_files >= 3 or churn >= 110:
      rec_bump = 'minor'
      reason = f'新增或擴充功能模組（{prod_files} 個產品檔案、+{prod_added}/-{prod_removed} 行），建議進第 2 位數。'
    else:
      rec_bump = 'patch'
      reason = f'局部介面、文案或參數微調（+{prod_added}/-{prod_removed} 行），建議進第 3 位數。'

    next_versions = {b: _bump_ver(cur_ver, b) for b in ('patch', 'minor', 'major')}
    suggested_highlights = [
        f"【{c['category']}】{c['desc']}（{c['path']} +{c['added']}/-{c['removed']}）"
        for c in changed[:6]
    ]

    return {
        'current_version': cur_ver,
        'has_changes': bool(changed),
        'changed_files': changed,
        'total_added': sum(c['added'] for c in changed),
        'total_removed': sum(c['removed'] for c in changed),
        'recommended_bump': rec_bump,
        'recommend_reason': reason,
        'bump_descriptions': BUMP_TEXT,
        'next_versions': next_versions,
        'suggested_title': f"NBA 運彩智庫 v{next_versions[rec_bump]} 功能更新",
        'suggested_highlights': suggested_highlights,
        'releases': rel_data['releases'],
    }


def publish_release(bump_type: str, title: str, highlights: list[str]) -> dict[str, Any]:
  with _LOCK:
    st = get_release_status()
    btype = bump_type if bump_type in ('patch', 'minor', 'major') else st['recommended_bump']
    new_ver = _bump_ver(st['current_version'], btype)
    clean_hl = [h.strip() for h in (highlights or []) if str(h).strip()] or st['suggested_highlights'] or ['例行系統優化與資料更新']
    entry = {
        'version': new_ver,
        'date': dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d'),
        'bump': btype,
        'title': (title or '').strip() or f'NBA 運彩智庫 v{new_ver} 更新',
        'notes': clean_hl[0],
        'highlights': clean_hl,
        'files_count': len(st['changed_files']),
    }
    rel_data = load_releases()
    rel_data['current_version'] = new_ver
    rel_data['releases'].insert(0, entry)
    save_releases(rel_data)
    snapshot_baseline()
    try:
      from tools import build_dist  # pylint: disable=import-outside-toplevel
      build_dist.build_all()
    except Exception:  # pylint: disable=broad-except
      pass
    return get_release_status()


if __name__ == '__main__':
  cmd = sys.argv[1] if len(sys.argv) > 1 else 'status'
  if cmd == 'init':
    load_releases()
    write_releases_js()
    snapshot_baseline()
    print('Initialized baseline at', current_version())
  else:
    print(json.dumps(get_release_status(), ensure_ascii=False, indent=2))
