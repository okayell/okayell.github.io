#!/usr/bin/env python3
"""Polite HTTP client with per-host rate limiting, gzip, retries, and clean text utilities."""
from __future__ import annotations

import gzip
import html
import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

USER_AGENT = (
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
)

_HOST_MIN_INTERVAL: dict[str, float] = {
    'site.api.espn.com': 0.12,
    'sports.core.api.espn.com': 0.12,
    'www.rotowire.com': 1.2,
    'www.cbssports.com': 1.2,
    'news.google.com': 0.8,
}
_HOST_LAST_TS: dict[str, float] = {}
_HOST_LOCK = threading.Lock()


def _throttle(url: str) -> None:
  host = urllib.parse.urlparse(url).netloc.lower()
  min_iv = _HOST_MIN_INTERVAL.get(host, 0.25)
  with _HOST_LOCK:
    now = time.monotonic()
    wait = (_HOST_LAST_TS.get(host, 0.0) + min_iv) - now
    if wait > 0:
      time.sleep(wait)
    _HOST_LAST_TS[host] = time.monotonic()


def fetch_bytes(url: str, timeout: float = 12.0, retries: int = 3) -> bytes:
  last_err: Exception | None = None
  for attempt in range(retries):
    _throttle(url)
    req = urllib.request.Request(
        url,
        headers={
            'User-Agent': USER_AGENT,
            'Accept-Encoding': 'gzip',
            'Accept': 'application/json,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
    )
    try:
      with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        if (resp.headers.get('Content-Encoding') or '').lower() == 'gzip' or raw[:2] == b'\x1f\x8b':
          try:
            raw = gzip.decompress(raw)
          except OSError:
            pass
        return raw
    except urllib.error.HTTPError as e:
      last_err = e
      if 400 <= e.code < 500 and e.code != 429:
        break
    except (urllib.error.URLError, TimeoutError, OSError) as e:
      last_err = e
    if attempt + 1 < retries:
      time.sleep(0.5 * (2 ** attempt))
  raise RuntimeError(f'GET {url} failed: {last_err}')


def fetch_text(url: str, timeout: float = 12.0, retries: int = 3) -> str:
  return fetch_bytes(url, timeout=timeout, retries=retries).decode('utf-8', errors='replace')


def fetch_json(url: str, timeout: float = 12.0, retries: int = 3) -> Any:
  return json.loads(fetch_text(url, timeout=timeout, retries=retries))


def clean_str(s: str | None) -> str:
  if not s:
    return ''
  t = html.unescape(str(s))
  t = re.sub(r'[\ufeff\u200b-\u200f\u2060-\u2064]', '', t)
  t = t.replace('\xa0', ' ').replace('\u3000', ' ')
  t = re.sub(r'<[^>]+>', ' ', t)
  return re.sub(r'\s+', ' ', t).strip()
