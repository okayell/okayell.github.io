#!/usr/bin/env python3
"""SQLite schema & helpers for 台籃戰情室 (parsed rows only — no raw HTML/JSON blobs)."""
from __future__ import annotations

import json
import os
import sqlite3
from typing import Any, Iterable

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS seasons (
  league TEXT NOT NULL, season TEXT NOT NULL, name TEXT, src_id TEXT, status TEXT,
  start_date TEXT, end_date TEXT, ord INTEGER DEFAULT 0, updated_at TEXT,
  PRIMARY KEY (league, season)
);
CREATE TABLE IF NOT EXISTS teams (
  league TEXT NOT NULL, team_id TEXT NOT NULL, name TEXT, short TEXT, en TEXT, logo TEXT,
  color TEXT, last_season TEXT,
  PRIMARY KEY (league, team_id)
);
CREATE TABLE IF NOT EXISTS games (
  league TEXT NOT NULL, game_id TEXT NOT NULL, season TEXT, stage TEXT, code TEXT,
  game_date TEXT, game_time TEXT, tip_ts TEXT, home_id TEXT, away_id TEXT,
  home_score INTEGER, away_score INTEGER, status TEXT, period TEXT, venue TEXT,
  attendance INTEGER, capacity INTEGER, quarters TEXT, has_box INTEGER DEFAULT 0, updated_at TEXT,
  PRIMARY KEY (league, game_id)
);
CREATE INDEX IF NOT EXISTS idx_games_season ON games(league, season, game_date);
CREATE TABLE IF NOT EXISTS team_box (
  league TEXT NOT NULL, game_id TEXT NOT NULL, team_id TEXT NOT NULL, is_home INTEGER,
  pts INTEGER, fgm INTEGER, fga INTEGER, tpm INTEGER, tpa INTEGER, ftm INTEGER, fta INTEGER,
  oreb INTEGER, dreb INTEGER, reb INTEGER, ast INTEGER, stl INTEGER, blk INTEGER, tov INTEGER, pf INTEGER,
  PRIMARY KEY (league, game_id, team_id)
);
CREATE TABLE IF NOT EXISTS player_box (
  league TEXT NOT NULL, game_id TEXT NOT NULL, team_id TEXT NOT NULL, player_id TEXT NOT NULL,
  name TEXT, number TEXT, pos TEXT, starter INTEGER, sec INTEGER,
  pts INTEGER, fgm INTEGER, fga INTEGER, tpm INTEGER, tpa INTEGER, ftm INTEGER, fta INTEGER,
  oreb INTEGER, dreb INTEGER, reb INTEGER, ast INTEGER, stl INTEGER, blk INTEGER, tov INTEGER, pf INTEGER,
  pm INTEGER, eff INTEGER,
  PRIMARY KEY (league, game_id, player_id)
);
CREATE INDEX IF NOT EXISTS idx_pbox_player ON player_box(league, player_id);
CREATE TABLE IF NOT EXISTS predictions (
  league TEXT NOT NULL, game_id TEXT NOT NULL, frozen_at TEXT, model_ver TEXT,
  p_home REAL, pred_margin REAL, pred_total REAL, pred_home_pts REAL, pred_away_pts REAL,
  elo_home REAL, elo_away REAL, confidence TEXT, factors TEXT,
  PRIMARY KEY (league, game_id)
);
CREATE TABLE IF NOT EXISTS tune_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, league TEXT, run_at TEXT, games INTEGER,
  params TEXT, prev_params TEXT, metrics TEXT, prev_metrics TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
"""


def connect(path: str | None = None) -> sqlite3.Connection:
  p = path or config.DB_PATH
  os.makedirs(os.path.dirname(p), exist_ok=True)
  conn = sqlite3.connect(p, timeout=30)
  conn.row_factory = sqlite3.Row
  conn.execute('PRAGMA journal_mode=WAL')
  conn.execute('PRAGMA synchronous=NORMAL')
  conn.executescript(SCHEMA)
  return conn


def get_kv(conn: sqlite3.Connection, key: str, default: Any = None) -> Any:
  row = conn.execute('SELECT v FROM kv WHERE k = ?', (key,)).fetchone()
  if not row:
    return default
  try:
    return json.loads(row['v'])
  except (TypeError, ValueError):
    return default


def set_kv(conn: sqlite3.Connection, key: str, value: Any) -> None:
  conn.execute('INSERT INTO kv(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v',
               (key, json.dumps(value, ensure_ascii=False, separators=(',', ':'))))


def upsert(conn: sqlite3.Connection, table: str, row: dict[str, Any], keys: Iterable[str],
           keep_existing: Iterable[str] = ()) -> None:
  """INSERT … ON CONFLICT DO UPDATE. Columns in `keep_existing` keep their old non-NULL value."""
  cols = list(row.keys())
  keys = list(keys)
  keep = set(keep_existing)
  sets = []
  for c in cols:
    if c in keys:
      continue
    if c in keep:
      sets.append(f'{c} = COALESCE(excluded.{c}, {table}.{c})')
    else:
      sets.append(f'{c} = excluded.{c}')
  sql = (f'INSERT INTO {table}({", ".join(cols)}) VALUES({", ".join("?" for _ in cols)}) '
         f'ON CONFLICT({", ".join(keys)}) DO ' + (f'UPDATE SET {", ".join(sets)}' if sets else 'NOTHING'))
  conn.execute(sql, [row[c] for c in cols])


def rows(conn: sqlite3.Connection, sql: str, params: Iterable[Any] = ()) -> list[dict[str, Any]]:
  return [dict(r) for r in conn.execute(sql, tuple(params)).fetchall()]
