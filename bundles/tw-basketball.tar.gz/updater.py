#!/usr/bin/env python3
"""Data pipeline for 台籃戰情室: TPBL JSON API + P. LEAGUE+ HTML -> SQLite -> model -> snapshot.json.

Public entry points (the GitHub Actions runner `ci_update.py` relies on these names):
  sync_all(full_backfill=False, update_odds=False) -> dict   (update_odds is accepted and ignored)
  refresh_live() -> dict                                     (light live-score refresh, every 2 min)
"""
from __future__ import annotations

import datetime as dt
import fcntl
import json
import os
import threading
import time
import traceback
from typing import Any

import config
import db
import model_engine
import net
import snapshot
from sources import plg, tpbl

_STATE: dict[str, Any] = {'running': False, 'step': '', 'started_at': None, 'finished_at': None,
                          'last_result': None, 'errors': [], 'last_live': None}
_STATE_LOCK = threading.Lock()
_PLG_PAGE_CHECK: dict[str, float] = {}
MAX_BOX_PER_SYNC = 400


def _now() -> dt.datetime:
  return dt.datetime.now(config.TZ_TW)


def _iso(t: dt.datetime | None = None) -> str:
  return (t or _now()).isoformat(timespec='seconds')


def _set(**kw: Any) -> None:
  with _STATE_LOCK:
    _STATE.update(kw)


def get_sync_state() -> dict[str, Any]:
  with _STATE_LOCK:
    return json.loads(json.dumps(_STATE, ensure_ascii=False, default=str))


class _FileLock:
  """Non-blocking inter-process lock (server scheduler, manual sync and CI never run twice)."""

  def __init__(self, path: str = config.LOCK_FILE) -> None:
    self.path = path
    self.fd: int | None = None
    self.acquired = False

  def __enter__(self) -> '_FileLock':
    os.makedirs(os.path.dirname(self.path), exist_ok=True)
    self.fd = os.open(self.path, os.O_CREAT | os.O_RDWR, 0o644)
    try:
      fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
      self.acquired = True
    except OSError:
      self.acquired = False
    return self

  def __exit__(self, *exc: Any) -> None:
    if self.fd is not None:
      if self.acquired:
        fcntl.flock(self.fd, fcntl.LOCK_UN)
      os.close(self.fd)


def _box_seasons(conn) -> dict[str, set[str]]:
  return {lg: set(snapshot.box_seasons(conn, lg)) for lg in config.LEAGUES}


def _pending_box(conn, league: str, seasons: set[str], limit: int = MAX_BOX_PER_SYNC) -> list[dict[str, Any]]:
  if not seasons:
    return []
  ph = ','.join('?' for _ in seasons)
  return db.rows(conn, f"""SELECT * FROM games WHERE league = ? AND season IN ({ph}) AND status = 'final'
                           AND COALESCE(has_box, 0) = 0 AND stage != 'pre' ORDER BY tip_ts DESC LIMIT ?""",
                 (league, *sorted(seasons), limit))


def _store_box(conn, league: str, game_id: str, team_rows: list[dict], player_rows: list[dict],
               quarters: list[list[int]]) -> bool:
  if len(team_rows) != 2 or not player_rows:
    return False
  conn.execute('DELETE FROM player_box WHERE league = ? AND game_id = ?', (league, game_id))
  for r in team_rows:
    db.upsert(conn, 'team_box', r, keys=('league', 'game_id', 'team_id'))
  for r in player_rows:
    db.upsert(conn, 'player_box', r, keys=('league', 'game_id', 'player_id'))
  conn.execute('UPDATE games SET has_box = 1, quarters = ? WHERE league = ? AND game_id = ?',
               (json.dumps(quarters, separators=(',', ':')) if quarters else None, league, game_id))
  return True


def _box_failed(conn, league: str, game_id: str) -> None:
  fails = db.get_kv(conn, f'box_fail:{league}', {}) or {}
  fails[game_id] = int(fails.get(game_id, 0)) + 1
  if fails[game_id] >= 3:  # give up: never hammer a source for a box score that does not exist
    conn.execute('UPDATE games SET has_box = -1 WHERE league = ? AND game_id = ?', (league, game_id))
  db.set_kv(conn, f'box_fail:{league}', fails)


def _upsert_teams(conn, teams: dict[str, dict[str, Any]], season: str) -> None:
  for t in teams.values():
    row = dict(t)
    row['last_season'] = season
    cur = conn.execute('SELECT last_season, name FROM teams WHERE league = ? AND team_id = ?',
                       (row['league'], row['team_id'])).fetchone()
    if cur and (cur['last_season'] or '') > season:
      continue  # keep the newest season's names / logos
    if cur and row['league'] == 'plg' and cur['name'] and cur['name'] != row.get('short') \
        and str(cur['name']).endswith(str(row.get('short') or '#')):
      row['name'] = cur['name']  # keep the full name learned from a game page
    db.upsert(conn, 'teams', row, keys=('league', 'team_id'), keep_existing=('color', 'logo'))


def _upsert_games(conn, games: list[dict[str, Any]]) -> int:
  n = 0
  now = _iso()
  for g in games:
    row = dict(g)
    row['updated_at'] = now
    prev = conn.execute('SELECT status, home_score, away_score FROM games WHERE league = ? AND game_id = ?',
                        (row['league'], row['game_id'])).fetchone()
    if prev and prev['status'] == 'final' and row['status'] != 'final' and row['league'] == 'plg':
      row['status'] = 'final'  # a page cached mid-game must never "un-finish" a game
      row['home_score'], row['away_score'] = prev['home_score'], prev['away_score']
    db.upsert(conn, 'games', row, keys=('league', 'game_id'), keep_existing=('attendance', 'capacity'))
    n += 1
  return n


# --------------------------------------------------------------------------- TPBL
def _tpbl_season_games(conn, s: dict[str, Any]) -> tuple[int, list[str]]:
  div_map = tpbl.parse_divisions(tpbl.fetch_divisions(s['src_id']))
  db.set_kv(conn, f'tpbl_div:{s["src_id"]}', div_map)
  raw = tpbl.fetch_games(s['src_id'])
  games, teams = tpbl.parse_games(raw, s['season'], div_map)
  logos = db.get_kv(conn, 'tpbl_logos') or {}
  for t in teams.values():
    t['logo'] = logos.get(t.get('en') or '') or None
  periods = {str(g.get('id')): g.get('round') for g in raw or []}
  for g in games:
    r = periods.get(g['game_id'])
    if isinstance(r, int) and r > 0 and g['status'] in ('live', 'final'):
      g['period'] = f'Q{r}' if r <= 4 else f'OT{r - 4}'
  before = {r['game_id']: r['status'] for r in db.rows(
      conn, 'SELECT game_id, status FROM games WHERE league = ? AND season = ?', ('tpbl', s['season']))}
  _upsert_teams(conn, teams, s['season'])
  n = _upsert_games(conn, games)
  newly_final = [g['game_id'] for g in games if g['status'] == 'final' and before.get(g['game_id']) != 'final']
  return n, newly_final


def _tpbl_boxes(conn, games: list[dict[str, Any]]) -> int:
  n = 0
  for g in games:
    try:
      tr, pr, q = tpbl.parse_box(tpbl.fetch_box(g['game_id']), g['game_id'])
    except Exception:  # pylint: disable=broad-except
      _box_failed(conn, 'tpbl', g['game_id'])
      continue
    if _store_box(conn, 'tpbl', g['game_id'], tr, pr, q):
      n += 1
    else:
      _box_failed(conn, 'tpbl', g['game_id'])
    conn.commit()
  return n


def sync_tpbl(conn, full: bool) -> dict[str, Any]:
  seasons = tpbl.parse_seasons(tpbl.fetch_seasons())
  for s in seasons:
    db.upsert(conn, 'seasons', dict(s, updated_at=_iso()), keys=('league', 'season'))
  last_logo = db.get_kv(conn, 'tpbl_logos_at')
  if not last_logo or (_now() - dt.datetime.fromisoformat(last_logo)).total_seconds() > 86400:
    try:  # team logos are hashed Nuxt assets that change on redeploys -> re-read once a day
      logos = tpbl.parse_logo_map(tpbl.fetch_home())
      if logos:
        db.set_kv(conn, 'tpbl_logos', logos)
        db.set_kv(conn, 'tpbl_logos_at', _iso())
        for alt, url in logos.items():
          conn.execute('UPDATE teams SET logo = ? WHERE league = ? AND en = ?', (url, 'tpbl', alt))
    except Exception:  # pylint: disable=broad-except
      pass
  have = {r['season'] for r in db.rows(conn, 'SELECT DISTINCT season FROM games WHERE league = ?', ('tpbl',))}
  today = _now().date().isoformat()
  pending = {r['season'] for r in db.rows(conn, """SELECT DISTINCT season FROM games WHERE league = 'tpbl'
             AND status IN ('scheduled', 'live') AND game_date <= ? AND stage != 'pre'""", (today,))}
  latest = max(seasons, key=lambda s: s['ord'])['season'] if seasons else None
  targets = [s for s in seasons if full or s['season'] not in have or s['status'] == 'IN_PROGRESS'
             or s['season'] in pending or s['season'] == latest]
  n_games = 0
  for s in sorted(targets, key=lambda s: s['ord']):
    _set(step=f'TPBL {s["season"]} 賽程比分')
    n, _ = _tpbl_season_games(conn, s)
    n_games += n
    conn.commit()
  _set(step='TPBL 逐場數據')
  n_box = _tpbl_boxes(conn, _pending_box(conn, 'tpbl', _box_seasons(conn)['tpbl']))
  return {'seasons': len(seasons), 'refreshed': [s['season'] for s in targets], 'games': n_games, 'box': n_box}


# --------------------------------------------------------------------------- P. LEAGUE+
def _plg_page_status(conn, g: dict[str, Any]) -> str | None:
  try:
    info = plg.parse_game_page(plg.fetch_game_page(g['game_id']))
  except Exception:  # pylint: disable=broad-except
    return None
  _PLG_PAGE_CHECK[g['game_id']] = time.time()
  for tid, full in ((g['home_id'], info.get('home_name')), (g['away_id'], info.get('away_name'))):
    if not full:
      continue
    row = conn.execute('SELECT short FROM teams WHERE league = ? AND team_id = ?', ('plg', tid)).fetchone()
    if row and row['short'] and full.endswith(row['short']):
      conn.execute('UPDATE teams SET name = ? WHERE league = ? AND team_id = ?', (full, 'plg', tid))
  st = info.get('status')
  if st and st != g['status']:
    conn.execute('UPDATE games SET status = ? WHERE league = ? AND game_id = ?', (st, 'plg', g['game_id']))
  return st


def _plg_boxes(conn, games: list[dict[str, Any]]) -> int:
  n = 0
  for g in games:
    try:
      tr, pr, q, sc = plg.parse_box(plg.fetch_box(g['game_id']), g['game_id'], g['home_id'], g['away_id'])
    except Exception:  # pylint: disable=broad-except
      _box_failed(conn, 'plg', g['game_id'])
      continue
    if _store_box(conn, 'plg', g['game_id'], tr, pr, q):
      n += 1
    else:
      _box_failed(conn, 'plg', g['game_id'])
    conn.commit()
  return n


def sync_plg(conn, full: bool) -> dict[str, Any]:
  _set(step='P. LEAGUE+ 賽季清單')
  html_cur = plg.fetch_schedule(None, 'regular')
  all_seasons, cur = plg.parse_season_nav(html_cur)
  seasons = [s for s in all_seasons if s >= config.PLG_FIRST_SEASON]
  if not seasons or not cur:
    raise RuntimeError('P. LEAGUE+ 賽程頁格式改變，找不到賽季清單')
  for i, s in enumerate(seasons):
    db.upsert(conn, 'seasons', {'league': 'plg', 'season': s, 'name': f'{s} 賽季', 'src_id': s,
                                'status': 'IN_PROGRESS' if s == cur else 'COMPLETED', 'ord': i + 1,
                                'updated_at': _iso()}, keys=('league', 'season'))
  have = {r['season'] for r in db.rows(conn, 'SELECT DISTINCT season FROM games WHERE league = ?', ('plg',))}
  now = _now()
  today = now.date().isoformat()
  recent = set(seasons[-2:])
  pending = {r['season'] for r in db.rows(conn, """SELECT DISTINCT season FROM games WHERE league = 'plg'
             AND status IN ('scheduled', 'live', 'postponed') AND game_date < ?""", (today,))} & recent
  targets = [s for s in seasons if full or s not in have or s == cur or s in pending]
  n_games = 0
  for s in targets:
    for stage in ('regular', 'playoffs', 'finals'):
      if s == cur and stage != 'regular':
        reg = db.rows(conn, """SELECT MAX(game_date) AS last, SUM(status != 'final') AS left FROM games
                               WHERE league = 'plg' AND season = ? AND stage = 'regular'""", (s,))
        has_stage = conn.execute('SELECT 1 FROM games WHERE league = ? AND season = ? AND stage = ? LIMIT 1',
                                 ('plg', s, stage)).fetchone()
        last = (reg[0]['last'] if reg else None) or '9999'
        near_end = last <= (now.date() + dt.timedelta(days=10)).isoformat()
        if not has_stage and not near_end:
          continue
      _set(step=f'P. LEAGUE+ {s} {stage}')
      html = html_cur if (s == cur and stage == 'regular') else plg.fetch_schedule(s, stage)
      games, teams = plg.parse_schedule(html, s, stage)
      if s == cur and stage == 'regular' and not games:
        raise RuntimeError('P. LEAGUE+ 賽程頁解析不到任何場次（版面可能改了）')
      _upsert_teams(conn, teams, s)
      n_games += _upsert_games(conn, games)
      conn.commit()
  # Today's games: the schedule page cannot tell "live" from "final" -> read the game page badge.
  _set(step='P. LEAGUE+ 今日賽況')
  for g in db.rows(conn, """SELECT * FROM games WHERE league = 'plg' AND status != 'final' AND game_date >= ?
                            AND game_date <= ?""", ((now.date() - dt.timedelta(days=1)).isoformat(), today)):
    if g['tip_ts'] and dt.datetime.fromisoformat(g['tip_ts']) <= now:
      _plg_page_status(conn, g)
  conn.commit()
  # Official team colours / full names (only when missing).
  missing = db.rows(conn, """SELECT team_id FROM teams WHERE league = 'plg' AND last_season = ?
                             AND (color IS NULL OR color = '')""", (cur,))
  if missing:
    try:
      done_season = cur if conn.execute("""SELECT 1 FROM games WHERE league = 'plg' AND season = ? AND
                                           status = 'final' LIMIT 1""", (cur,)).fetchone() else seasons[-2]
      colors = plg.parse_standings_colors(plg.fetch_standings(done_season))
      for tid, col in colors.items():
        conn.execute('UPDATE teams SET color = ? WHERE league = ? AND team_id = ?', (col, 'plg', tid))
      conn.commit()
    except Exception:  # pylint: disable=broad-except
      pass
  nameless = db.rows(conn, """SELECT team_id, short FROM teams WHERE league = 'plg' AND last_season = ?
                              AND (name IS NULL OR name = short)""", (cur,))
  if nameless:
    try:
      fulls = plg.parse_team_full_names(plg.fetch_stat_player())
      for t in nameless:
        hit = [f for f in fulls if t['short'] and f.endswith(t['short'])]
        if len(hit) == 1:
          conn.execute('UPDATE teams SET name = ? WHERE league = ? AND team_id = ?', (hit[0], 'plg', t['team_id']))
      conn.commit()
    except Exception:  # pylint: disable=broad-except
      pass
  _set(step='P. LEAGUE+ 逐場數據')
  n_box = _plg_boxes(conn, _pending_box(conn, 'plg', _box_seasons(conn)['plg']))
  left = conn.execute("""SELECT COUNT(*) AS n, SUM(status = 'final') AS f, MIN(game_date) AS first FROM games
                         WHERE league = 'plg' AND season = ?""", (cur,)).fetchone()
  status = 'IN_PROGRESS'
  if left and left['n']:
    if (left['f'] or 0) == 0 and (left['first'] or '') > today:
      status = 'NOT_STARTED'
    elif (left['f'] or 0) == left['n']:
      status = 'COMPLETED'
  conn.execute('UPDATE seasons SET status = ? WHERE league = ? AND season = ?', (status, 'plg', cur))
  return {'seasons': len(seasons), 'current': cur, 'refreshed': targets, 'games': n_games, 'box': n_box}


# --------------------------------------------------------------------------- orchestration
def sync_all(full_backfill: bool = False, update_odds: bool = False) -> dict[str, Any]:  # noqa: ARG001
  """Full refresh of both leagues + model + snapshot. `update_odds` exists only for the shared CI runner."""
  del update_odds
  with _FileLock() as lk:
    if not lk.acquired:
      return {'ok': False, 'skipped': '另一個更新正在進行'}
    t0 = time.time()
    _set(running=True, step='開始更新', started_at=_iso(), errors=[])
    conn = db.connect()
    result: dict[str, Any] = {'ok': True}
    errors: list[str] = []
    try:
      for lg, fn in (('tpbl', sync_tpbl), ('plg', sync_plg)):
        has = conn.execute('SELECT 1 FROM games WHERE league = ? LIMIT 1', (lg,)).fetchone()
        try:
          result[lg] = fn(conn, bool(full_backfill or not has))
          db.set_kv(conn, f'fetched:{lg}', _iso())
          db.set_kv(conn, f'fetch_error:{lg}', None)
        except Exception as e:  # pylint: disable=broad-except
          traceback.print_exc()
          msg = f'{config.LEAGUE_META[lg]["name"]}：{str(e)[:200]}'
          errors.append(msg)
          db.set_kv(conn, f'fetch_error:{lg}', msg)
          result[lg] = {'error': str(e)[:300]}
        conn.commit()
      _set(step='模型計算與賽前預測')
      result['model'] = model_engine.run(conn, allow_tune=True)
      _set(step='產生資料快照')
      snap = snapshot.write(conn)
      result['generated_at'] = snap['generated_at']
      db.set_kv(conn, 'last_sync', {'at': snap['generated_at'], 'errors': errors})
      conn.commit()
    except Exception as e:  # pylint: disable=broad-except
      traceback.print_exc()
      errors.append(str(e)[:300])
      result['ok'] = False
    finally:
      conn.close()
    result['errors'] = errors
    result['seconds'] = round(time.time() - t0, 1)
    result['net'] = dict(net.STATS)
    _set(running=False, step='', finished_at=_iso(), last_result=result, errors=errors)
    return result


def live_candidates(conn, now: dt.datetime | None = None) -> list[dict[str, Any]]:
  """Games that are live, or past tip-off within the live window and not final yet."""
  now = now or _now()
  lo = (now - dt.timedelta(hours=config.LIVE_WINDOW_HOURS)).isoformat(timespec='seconds')
  hi = now.isoformat(timespec='seconds')
  return db.rows(conn, """SELECT * FROM games WHERE status = 'live' OR (status = 'scheduled' AND tip_ts <= ?
                          AND tip_ts >= ? AND stage != 'other')""", (hi, lo))


def refresh_live() -> dict[str, Any]:
  with _FileLock() as lk:
    if not lk.acquired:
      return {'ok': False, 'skipped': 'busy'}
    conn = db.connect()
    out: dict[str, Any] = {'ok': True, 'tpbl': 0, 'plg': 0, 'final': 0}
    try:
      cands = live_candidates(conn)
      seasons = {g['season'] for g in cands if g['league'] == 'tpbl'}
      for season in seasons:
        s = conn.execute('SELECT * FROM seasons WHERE league = ? AND season = ?', ('tpbl', season)).fetchone()
        if not s:
          continue
        try:
          _, newly_final = _tpbl_season_games(conn, dict(s))
          out['tpbl'] += 1
          if newly_final:
            out['final'] += len(newly_final)
            rows = db.rows(conn, f"SELECT * FROM games WHERE league = 'tpbl' AND game_id IN "
                                 f"({','.join('?' for _ in newly_final)})", newly_final)
            _tpbl_boxes(conn, [r for r in rows if r['stage'] != 'pre'])
        except Exception as e:  # pylint: disable=broad-except
          out.setdefault('errors', []).append(f'TPBL: {str(e)[:160]}')
      for g in (x for x in cands if x['league'] == 'plg'):
        try:
          tr, pr, q, sc = plg.parse_box(plg.fetch_box(g['game_id']), g['game_id'], g['home_id'], g['away_id'])
        except Exception as e:  # pylint: disable=broad-except
          out.setdefault('errors', []).append(f'P+: {str(e)[:160]}')
          continue
        out['plg'] += 1
        if sc.get('home') or sc.get('away') or pr:
          conn.execute("""UPDATE games SET home_score = ?, away_score = ?, quarters = ?, period = ?,
                          status = CASE WHEN status = 'scheduled' THEN 'live' ELSE status END
                          WHERE league = 'plg' AND game_id = ?""",
                       (sc.get('home'), sc.get('away'), json.dumps(q, separators=(',', ':')) if q else None,
                        f'Q{len(q)}' if 0 < len(q) <= 4 else (f'OT{len(q) - 4}' if q else None), g['game_id']))
        last = _PLG_PAGE_CHECK.get(g['game_id'], 0)
        if len(q) >= 4 or time.time() - last >= 600:
          st = _plg_page_status(conn, dict(g, status='live'))
          if st == 'final' and _store_box(conn, 'plg', g['game_id'], tr, pr, q):
            out['final'] += 1
      conn.commit()
      if out['tpbl'] or out['plg']:
        if out['final']:
          model_engine.run(conn, allow_tune=False)
        snap = snapshot.write(conn)
        out['generated_at'] = snap['generated_at']
    finally:
      conn.close()
    _set(last_live=_iso())
    return out


if __name__ == '__main__':
  import sys
  r = sync_all(full_backfill='--full' in sys.argv)
  print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
