#!/usr/bin/env python3
"""Builds the GitHub Pages / offline single-file HTML of 台籃戰情室.

Output: dist/tw_basketball_single.html — CSS + every page script + the data snapshot of BOTH leagues
inlined into one file that works from file:// or any static host. Never contacts the local backend.
CLI: python3 tools/build_dist.py
"""
from __future__ import annotations

import base64
import json
import os
import re
import sys

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

import config  # noqa: E402  pylint: disable=wrong-import-position
import release_mgr  # noqa: E402  pylint: disable=wrong-import-position
import snapshot  # noqa: E402  pylint: disable=wrong-import-position

OUT_HTML = os.path.join(config.DIST_DIR, 'tw_basketball_single.html')
STATIC_FLAG = '<script>window.TWB_STATIC_ONLY = true;</script>'
# Leak guard (tokens kept base64-encoded so this file itself passes the scan).
_FORBIDDEN = re.compile('|'.join(re.escape(base64.b64decode(b).decode()) for b in (
    b'Z29vZ2xlcnMuY29t', b'Y29ycC5nb29nbGUuY29t', b'Z29vZ2xlcGxleA==',
    b'aHVhbmd5aWNoYW8=', b'L2dvb2dsZS9zcmMv', b'QGdvb2dsZS5jb20=')), re.I)


def _static_files() -> list[str]:
  out = []
  for base, _, files in os.walk(config.STATIC_DIR):
    out += [os.path.join(base, f) for f in files if f.endswith(('.html', '.css', '.js'))]
  return out


def is_stale() -> bool:
  if not os.path.isfile(OUT_HTML):
    return True
  out_m = os.path.getmtime(OUT_HTML)
  watch = _static_files() + [config.SNAPSHOT_JSON, release_mgr.RELEASES_JSON, os.path.abspath(__file__)]
  return any(os.path.isfile(fp) and os.path.getmtime(fp) > out_m for fp in watch)


def _js_json(obj) -> str:
  text = json.dumps(obj, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
  return text.replace('</', '<\\/').replace('<!--', '<\\!--').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


def _js_code(code: str) -> str:
  return code.replace('</script', '<\\/script').replace('<!--', '<\\!--')


def assemble(snap: dict) -> str:
  with open(os.path.join(config.STATIC_DIR, 'index.html'), encoding='utf-8') as f:
    html = f.read()
  with open(os.path.join(config.STATIC_DIR, 'app.css'), encoding='utf-8') as f:
    css = f.read()
  html = re.sub(r'<link[^>]+href="[^"]*app\.css[^"]*"[^>]*>', lambda _: f'<style>\n{css}\n</style>', html, count=1)
  tags = list(re.finditer(r'<script\s+src="([^"]+)"\s*>\s*</script>', html))
  blocks = ['<script>window.__TWB_SNAPSHOT__ = ' + _js_json(snap) + ';</script>']
  for m in tags:
    rel = m.group(1).split('?', 1)[0].lstrip('/')
    rel = rel[len('static/'):] if rel.startswith('static/') else rel
    with open(os.path.join(config.STATIC_DIR, rel), encoding='utf-8') as f:
      blocks.append(f'<script>/* {rel} */\n{_js_code(f.read())}\n</script>')
  if tags:
    html = html[:tags[0].start()] + '\n'.join(blocks) + html[tags[-1].end():]
  html = html.replace('<head>', '<head>\n  ' + STATIC_FLAG, 1)
  return html


def build_all() -> str:
  os.makedirs(config.DIST_DIR, exist_ok=True)
  release_mgr.write_releases_js()
  snap = snapshot.load_cached()
  html = assemble(snap)
  leak = _FORBIDDEN.search(html)
  if leak:
    raise RuntimeError(f'靜態檔含有內部網址或帳號字串：{leak.group(0)}，已停止打包')
  tmp = OUT_HTML + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    f.write(html)
  os.replace(tmp, OUT_HTML)
  return OUT_HTML


if __name__ == '__main__':
  p = build_all()
  print(f'Built {p} ({os.path.getsize(p):,} bytes)')
