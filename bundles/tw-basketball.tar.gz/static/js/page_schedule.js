/* Page: 📅 賽程與比分 (#/schedule) — filters: season / stage / team / month / status. */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;
  var STATUS = [['', '全部狀態'], ['final', '已完賽'], ['live', '進行中'], ['scheduled', '未開賽'], ['other', '延賽／未進行']];

  function predCell(g) {
    var p = T.pred(g.id);
    if (g.st === 'pre' || !p) return '';
    var favH = p.p >= 0.5, prob = Math.round((favH ? p.p : 1 - p.p) * 100);
    var fav = T.team(favH ? g.h : g.a).short;
    if (T.isFinal(g)) {
      var gr = T.grade(g, p);
      return '<span class="' + (gr.hit ? 'hit' : 'miss') + '" data-tip="' + esc(T.predKind(p) + '：看好' + fav + ' ' + prob + '%') + '">' +
        (gr.hit ? '✔' : '✘') + '</span> <span class="muted">看好' + esc(fav) + ' ' + prob + '%</span>';
    }
    return '<span data-tip="' + esc(T.predKind(p)) + '">看好 <b>' + esc(fav) + '</b> ' + prob + '%</span>';
  }

  function row(g) {
    var fin = T.isFinal(g), live = g.status === 'live';
    var sc;
    if ((fin || live) && g.hs !== null) {
      sc = '<span class="' + (fin && g.as < g.hs ? 'l' : '') + '">' + g.as + '</span> : <span class="' + (fin && g.hs < g.as ? 'l' : '') + '">' + g.hs + '</span>';
    } else if (g.status === 'postponed') {
      sc = '<span class="chip warn">延賽</span>';
    } else if (g.status === 'cancelled') {
      sc = '<span class="chip muted" data-tip="系列賽已分出勝負，這場沒有進行">未進行</span>';
    } else {
      sc = '<span class="muted">VS</span>';
    }
    var stage = '<span class="chip stage">' + esc(T.stageLabel(g.st)) + '</span>' + (g.c ? ' <span class="muted small">' + esc(g.c) + '</span>' : '');
    return '<div class="srow"><span class="s-time">' + esc(g.t || '—') + '</span><span class="s-stage">' + stage +
      (live ? ' ' + T.statusChip(g) : '') + '</span>' +
      '<span class="s-match"><span class="away">' + T.teamLink(g.a) + '</span><a class="s-sc" href="' + T.href('game/' + g.id) + '">' + sc + '</a>' +
      '<span class="home">' + T.teamLink(g.h) + '</span></span>' +
      '<span class="s-venue" title="' + esc(g.v) + '">' + esc(g.v) + (fin && g.att ? ' · ' + Number(g.att).toLocaleString() + ' 人' : '') + '</span>' +
      '<span class="s-pred">' + predCell(g) + '</span></div>';
  }

  T.pages.schedule = function (root, ctx) {
    var L = ctx.L, q = ctx.query;
    T.pageTitle = '賽程與比分';
    var seasons = T.seasonOptions();
    var season = seasons.some(function (s) { return s.season === q.season; }) ? q.season : T.displaySeason();
    var all = T.games(season);
    var teams = {};
    all.forEach(function (g) { teams[g.h] = 1; teams[g.a] = 1; });
    var months = [];
    all.forEach(function (g) { var m = g.d.slice(0, 7); if (months.indexOf(m) < 0) months.push(m); });
    months.sort();
    var stages = [];
    all.forEach(function (g) { if (stages.indexOf(g.st) < 0) stages.push(g.st); });
    var order = ['pre', 'regular', 'playin', 'playoffs', 'finals', 'other'];
    stages.sort(function (a, b) { return order.indexOf(a) - order.indexOf(b); });
    var month = q.month || '';
    if (!month) {
      var tm = T.today().slice(0, 7);
      month = months.indexOf(tm) >= 0 && season === L.current_season ? tm : 'all';
    }
    var team = teams[q.team] ? q.team : '';
    var status = q.status || '';
    var stage = stages.indexOf(q.stage) >= 0 ? q.stage : '';
    var list = all.filter(function (g) {
      if (month !== 'all' && g.d.slice(0, 7) !== month) return false;
      if (team && g.h !== team && g.a !== team) return false;
      if (stage && g.st !== stage) return false;
      if (status === 'other') return g.status === 'postponed' || g.status === 'cancelled';
      if (status && g.status !== status) return false;
      return true;
    });
    var fin = list.filter(T.isFinal);
    var graded = fin.map(function (g) { return T.grade(g, T.pred(g.id)); }).filter(Boolean);
    var hits = graded.filter(function (x) { return x.hit; }).length;

    var html = '<div class="sec-hdr"><div><h1 class="sec-title">📅 ' + esc(L.name) + ' 賽程與比分</h1>' +
      '<div class="sub">' + esc(season) + ' 賽季 · 共 ' + list.length + ' 場（已完賽 ' + fin.length + '）' +
      (graded.length ? ' · 模型命中 ' + hits + '/' + graded.length + '（' + Math.round(100 * hits / graded.length) + '%）' : '') + '</div></div></div>';
    html += '<div class="filters">' + T.seasonSelect(season) +
      '<select class="inp sel" id="stageSel" aria-label="賽事類型"><option value="">全部賽事</option>' + stages.map(function (s) {
        return '<option value="' + s + '"' + (s === stage ? ' selected' : '') + '>' + esc(T.stageLabel(s)) + '</option>';
      }).join('') + '</select>' +
      '<select class="inp sel" id="teamSel" aria-label="球隊"><option value="">全部球隊</option>' + Object.keys(teams).sort(function (a, b) {
        return T.team(a).short.localeCompare(T.team(b).short, 'zh-Hant');
      }).map(function (t) {
        return '<option value="' + esc(t) + '"' + (t === team ? ' selected' : '') + '>' + esc(T.team(t).short) + '</option>';
      }).join('') + '</select>' +
      '<select class="inp sel" id="monthSel" aria-label="月份"><option value="all"' + (month === 'all' ? ' selected' : '') + '>全部月份</option>' +
      months.map(function (m) { return '<option value="' + m + '"' + (m === month ? ' selected' : '') + '>' + m.slice(0, 4) + ' 年 ' + Number(m.slice(5)) + ' 月</option>'; }).join('') +
      '</select><select class="inp sel" id="statusSel" aria-label="狀態">' + STATUS.map(function (s) {
        return '<option value="' + s[0] + '"' + (s[0] === status ? ' selected' : '') + '>' + s[1] + '</option>';
      }).join('') + '</select></div>';
    if (!list.length) {
      html += '<div class="empty-box">沒有符合條件的比賽。</div>';
    } else {
      var byDay = {}, days = [];
      list.forEach(function (g) { if (!byDay[g.d]) { byDay[g.d] = []; days.push(g.d); } byDay[g.d].push(g); });
      html += days.map(function (d) {
        return '<div class="day-group"><div class="day-hdr">' + esc(T.dayLabel(d)) + '<span class="muted small">' + byDay[d].length + ' 場</span></div>' +
          byDay[d].map(row).join('') + '</div>';
      }).join('');
    }
    html += '<div class="note-line">✔／✘ 代表模型賽前看好的一方是否獲勝；預測種類（賽前凍結／回測）可把滑鼠移到符號上查看。</div>';
    root.innerHTML = html;
    ['stageSel', 'teamSel', 'monthSel', 'statusSel'].forEach(function (id) {
      var key = { stageSel: 'stage', teamSel: 'team', monthSel: 'month', statusSel: 'status' }[id];
      T.bindSelect(root, id, key);
    });
    var ss = root.querySelector('#seasonSel');
    if (ss) ss.addEventListener('change', function () { T.setQuery({ season: ss.value, month: '', team: '', stage: '' }); });
  };
})();
