/* 台籃戰情室 — core: router, league switcher, snapshot store, update strip, shared UI, release modal.
 * Pages live in static/js/page_*.js and register TWB.pages[name] = function (root, ctx) {...}.
 */
(function () {
  'use strict';

  var IS_STATIC = Boolean(
    window.TWB_STATIC_ONLY || location.protocol === 'file:' ||
    /\.github\.io$|\.pages\.dev$|\.netlify\.app$|\.vercel\.app$/i.test(location.hostname || '')
  );
  var LS_LEAGUE = 'twb.league';
  var LEAGUES = ['plg', 'tpbl'];
  var WEEKDAY = '日一二三四五六';

  var TWB = window.TWB = {
    isStatic: IS_STATIC,
    snap: window.__TWB_SNAPSHOT__ || null,
    meta: null,
    pages: {},
    route: 'home',
    params: [],
    query: {},
    league: null,
    version: (window.TWB_RELEASES && window.TWB_RELEASES.current_version) || '1.0.0',
    state: {}
  };

  // ------------------------------------------------------------------ small utils
  TWB.esc = function (s) {
    return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  /** Zero-flicker: only touch innerHTML when the markup actually changed. */
  TWB.setHtml = function (el, html) {
    if (!el) return false;
    if (el.__html === html) return false;
    el.innerHTML = html;
    el.__html = html;
    return true;
  };
  TWB.num = function (v, d) {
    if (v === null || v === undefined || v === '' || !isFinite(v)) return '—';
    return Number(v).toFixed(d === undefined ? 1 : d);
  };
  TWB.signed = function (v, d) {
    if (v === null || v === undefined || !isFinite(v)) return '—';
    var n = Number(v);
    return (n > 0 ? '+' : '') + n.toFixed(d === undefined ? 1 : d);
  };
  TWB.pct = function (m, a, d) {
    if (!a) return '—';
    return (100 * m / a).toFixed(d === undefined ? 1 : d) + '%';
  };
  TWB.fmtMin = function (sec) {
    sec = Math.round(sec || 0);
    return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0');
  };
  function twToday(addDays) {
    return new Date(Date.now() + (8 + 24 * (addDays || 0)) * 3600000).toISOString().slice(0, 10);
  }
  TWB.today = function () { return twToday(0); };
  TWB.md = function (d) { return d && d.length >= 10 ? Number(d.slice(5, 7)) + '/' + Number(d.slice(8, 10)) : (d || '—'); };
  TWB.wd = function (d) { return d ? WEEKDAY.charAt(new Date(d + 'T00:00:00Z').getUTCDay()) : ''; };
  TWB.dayLabel = function (d) {
    if (!d) return '—';
    var base = TWB.md(d) + '（' + TWB.wd(d) + '）';
    if (d === twToday(0)) return '今天 ' + base;
    if (d === twToday(1)) return '明天 ' + base;
    if (d === twToday(-1)) return '昨天 ' + base;
    return base;
  };
  /** Taipei ISO → 16:10 (today) / 昨天 21:30 / 明天 07:45 / 11/02（一）07:45 */
  TWB.whenTw = function (iso) {
    var d = String(iso || '').slice(0, 10), hm = String(iso || '').slice(11, 16);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || !/^\d{2}:\d{2}$/.test(hm)) return '';
    if (d === twToday(0)) return hm;
    if (d === twToday(-1)) return '昨天 ' + hm;
    if (d === twToday(1)) return '明天 ' + hm;
    return TWB.md(d) + '（' + TWB.wd(d) + '）' + hm;
  };

  // IME-safe Enter (注音／倉頡 candidate confirmation must never submit).
  var IME_ON = false, IME_END = 0;
  document.addEventListener('compositionstart', function () { IME_ON = true; }, true);
  document.addEventListener('compositionend', function () { IME_ON = false; IME_END = Date.now(); }, true);
  TWB.isEnterSend = function (ev) {
    return ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing && ev.keyCode !== 229 && !IME_ON &&
      Date.now() - IME_END >= 150;
  };

  TWB.toast = function (msg) {
    var box = document.getElementById('toastBox');
    if (!box) return;
    var el = document.createElement('div');
    el.className = 'toast-msg';
    el.textContent = msg;
    box.appendChild(el);
    while (box.children.length > 3) box.removeChild(box.firstChild);
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 3200);
  };

  // Tooltip for [data-tip] (desktop hover; tap shows native title on mobile).
  (function initTips() {
    var tip = null, target = null;
    document.addEventListener('mouseover', function (ev) {
      tip = tip || document.getElementById('tip');
      if (!tip) return;
      var t = ev.target && ev.target.closest ? ev.target.closest('[data-tip]') : null;
      if (t === target) return;
      target = t;
      var txt = t ? t.getAttribute('data-tip') : '';
      if (!t || !txt) { tip.style.display = 'none'; return; }
      tip.textContent = txt;
      tip.style.display = 'block';
      var r = t.getBoundingClientRect();
      var w = tip.offsetWidth, h = tip.offsetHeight;
      var x = Math.min(Math.max(8, r.left), window.innerWidth - w - 8);
      var y = r.bottom + 6;
      if (y + h > window.innerHeight - 8) y = Math.max(8, r.top - h - 6);
      tip.style.transform = 'translate(' + Math.round(x) + 'px,' + Math.round(y) + 'px)';
    });
    var hide = function () { target = null; if (tip) tip.style.display = 'none'; };
    document.addEventListener('scroll', hide, { passive: true, capture: true });
    window.addEventListener('blur', hide);
  })();

  // ------------------------------------------------------------------ league + data access
  TWB.L = function (lg) {
    var s = TWB.snap;
    return (s && s.leagues && s.leagues[lg || TWB.league]) || null;
  };
  TWB.leagueName = function (lg) {
    var L = TWB.L(lg);
    return (L && L.name) || (lg === 'plg' ? 'P. LEAGUE+' : 'TPBL');
  };
  TWB.team = function (id, lg) {
    var L = TWB.L(lg);
    var t = L && L.teams ? L.teams[id] : null;
    return t || { id: id, name: '球隊 ' + id, short: '球隊 ' + id, en: '', logo: '', color: '#64748b' };
  };
  TWB.logo = function (id, size, lg) {
    var t = TWB.team(id, lg);
    size = size || 22;
    // The wrapper shows the team colour as a dot whenever the logo is missing or fails to load.
    var wrap = '<span class="tm-logo-wrap" style="--tc:' + TWB.esc(t.color) + ';width:' + size + 'px;height:' + size + 'px">';
    if (!t.logo) return wrap + '</span>';
    return wrap + '<img class="tm-logo" src="' + TWB.esc(t.logo) + '" alt="" referrerpolicy="no-referrer" width="' + size +
      '" height="' + size + '" loading="lazy" decoding="async" onload="this.parentNode.classList.add(\'ok\')" onerror="this.remove()"></span>';
  };
  /** Team label: logo + short name, linking to the team page of the current league. */
  TWB.teamLink = function (id, opts) {
    opts = opts || {};
    var t = TWB.team(id);
    var nm = opts.full ? t.name : t.short;
    return '<a class="tm-link" href="' + TWB.href('team/' + id) + '">' + TWB.logo(id, opts.size) +
      '<span class="tm-nm">' + TWB.esc(nm) + '</span></a>';
  };
  TWB.STAGES = { pre: '熱身賽', regular: '例行賽', playin: '季後挑戰賽', playoffs: '季後賽', finals: '總冠軍賽', other: '其他' };
  TWB.stageLabel = function (st) { return TWB.STAGES[st] || st || ''; };
  TWB.games = function (season) {
    var L = TWB.L();
    if (!L) return [];
    return season ? L.games.filter(function (g) { return g.s === season; }) : L.games;
  };
  var GAME_IDX = {};
  TWB.game = function (id) {
    var L = TWB.L();
    if (!L) return null;
    var key = TWB.league + ':' + (TWB.snap && TWB.snap.generated_at);
    if (!GAME_IDX[key]) {
      GAME_IDX = {};
      var m = {};
      L.games.forEach(function (g) { m[g.id] = g; });
      GAME_IDX[key] = m;
    }
    return GAME_IDX[key][id] || null;
  };
  TWB.pred = function (id) {
    var L = TWB.L();
    return (L && L.pred && L.pred[id]) || null;
  };
  TWB.displaySeason = function () {
    var L = TWB.L();
    return (L && (L.display_season || L.current_season)) || '';
  };
  TWB.seasonOptions = function (filterFn) {
    var L = TWB.L();
    return ((L && L.seasons) || []).filter(function (s) { return !filterFn || filterFn(s); });
  };
  TWB.isFinal = function (g) { return g && g.status === 'final' && g.hs !== null && g.as !== null; };
  /** Hit / miss of a prediction against a finished game. */
  TWB.grade = function (g, p) {
    if (!TWB.isFinal(g) || !p || p.p === null || p.p === undefined) return null;
    var homeWon = g.hs > g.as;
    return {
      hit: (p.p >= 0.5) === homeWon,
      marginErr: Math.abs((p.m || 0) - (g.hs - g.as)),
      totalErr: Math.abs((p.tot || 0) - (g.hs + g.as))
    };
  };
  TWB.predKind = function (p) {
    if (!p) return '';
    if (p.kind === 'frozen') return '賽前凍結預測';
    if (p.kind === 'late') return '模型推估（開賽後才建立，不列入凍結統計）';
    return '回測預測（逐場前推）';
  };
  TWB.confChip = function (c) {
    var cls = c === '高' ? 'ok' : (c === '中' ? 'info' : 'muted');
    return '<span class="chip ' + cls + '" data-tip="信心等級依勝率差距與兩隊本季已賽場數判斷">信心 ' + TWB.esc(c || '—') + '</span>';
  };

  // ------------------------------------------------------------------ router (hash + ?lg=)
  function parseHash() {
    var raw = (location.hash || '#/').replace(/^#\/?/, '');
    var qi = raw.indexOf('?');
    var path = qi >= 0 ? raw.slice(0, qi) : raw;
    var qs = qi >= 0 ? raw.slice(qi + 1) : '';
    var query = {};
    qs.split('&').forEach(function (kv) {
      if (!kv) return;
      var i = kv.indexOf('=');
      var k = decodeURIComponent(i >= 0 ? kv.slice(0, i) : kv);
      var v = i >= 0 ? decodeURIComponent(kv.slice(i + 1).replace(/\+/g, ' ')) : '';
      query[k] = v;
    });
    return { parts: path.split('/').filter(Boolean), query: query };
  }
  TWB.href = function (path, extra) {
    var q = ['lg=' + encodeURIComponent(TWB.league || 'tpbl')];
    Object.keys(extra || {}).forEach(function (k) {
      if (extra[k] !== '' && extra[k] !== null && extra[k] !== undefined) q.push(encodeURIComponent(k) + '=' + encodeURIComponent(extra[k]));
    });
    return '#/' + (path || '') + '?' + q.join('&');
  };
  /** Updates query keys of the current route without adding history entries, then re-renders. */
  TWB.setQuery = function (patch) {
    var cur = parseHash();
    var q = Object.assign({}, cur.query, patch || {});
    q.lg = TWB.league;
    var parts = [];
    Object.keys(q).forEach(function (k) {
      if (q[k] !== '' && q[k] !== null && q[k] !== undefined) parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(q[k]));
    });
    var h = '#/' + cur.parts.join('/') + '?' + parts.join('&');
    if (history.replaceState) history.replaceState(null, '', h); else location.hash = h;
    TWB.render(true);
  };
  function pickLeague(query) {
    if (LEAGUES.indexOf(query.lg) >= 0) return query.lg;
    var stored = null;
    try { stored = localStorage.getItem(LS_LEAGUE); } catch (e) { stored = null; }
    if (LEAGUES.indexOf(stored) >= 0) return stored;
    var d = TWB.snap && TWB.snap.meta && TWB.snap.meta.default_league;
    return LEAGUES.indexOf(d) >= 0 ? d : 'tpbl';
  }
  TWB.setLeague = function (lg) {
    if (LEAGUES.indexOf(lg) < 0) return;
    try { localStorage.setItem(LS_LEAGUE, lg); } catch (e) { /* private mode */ }
    var cur = parseHash();
    var route = cur.parts[0] || '';
    // Team / game ids belong to one league: switching league goes back to the list page.
    var parts = route === 'team' ? ['teams'] : (route === 'game' ? ['schedule'] : cur.parts);
    TWB.league = lg;
    location.hash = '#/' + parts.join('/') + '?lg=' + lg;
  };

  var ROUTES = { '': 'home', home: 'home', schedule: 'schedule', standings: 'standings', teams: 'teams', team: 'team',
    players: 'players', game: 'game', model: 'model', about: 'about', feedback: 'feedback' };

  // ------------------------------------------------------------------ 🔄 資料更新頻率 strip (Pattern 205)
  var UPD_EL = null;
  function updStripEl() {
    if (!UPD_EL) {
      UPD_EL = document.createElement('div');
      UPD_EL.className = 'upd-strip';
      UPD_EL.id = 'updStrip';
      UPD_EL.setAttribute('role', 'note');
      UPD_EL.setAttribute('aria-label', '資料更新頻率');
    }
    return UPD_EL;
  }
  function renderUpdStrip() {
    var el = updStripEl();
    var m = TWB.meta || (TWB.snap && TWB.snap.meta) || {};
    var s = m.schedule_slots;
    if (!s) return;
    var notes = s.notes || {};
    var tipSlots = s.sync.map(function (t) { return t + '　' + (notes[t] || ''); }).join('\n');
    var html = '<b class="us-lbl">🔄 資料更新頻率</b>' +
      '<span class="us-main">每天自動更新 ' + s.sync.length + ' 次</span>' +
      '<span class="us-seg" data-tip="' + TWB.esc('大致如下：\n' + tipSlots) + '"><b>🕖 ' + TWB.esc(s.sync.join('、')) + '</b>' +
      '<span class="us-desc">完賽比分、逐場數據、賽前預測</span></span>';
    if (!IS_STATIC) {
      html += '<span class="us-seg"><b>🔴 比賽進行中每 ' + (s.live_every_min || 2) + ' 分鐘</b><span class="us-desc">更新即時比分</span></span>';
    }
    var when = '', whenTip = '';
    var gen = (TWB.snap && TWB.snap.generated_at) || m.updated_at;
    if (IS_STATIC) {
      var built = TWB.whenTw(gen);
      if (location.protocol === 'file:') {
        when = '離線檔案：資料停在' + (built ? ' ' + built : '打包當下') + '，不會自動更新';
      } else {
        when = built ? '本頁資料更新於 ' + built : '';
        whenTip = 'GitHub 版由雲端排程在上述時段自動抓資料、重新發布，上線可能比表定時間晚幾分鐘到半小時；比賽進行中的即時比分請以官網為準';
      }
    } else {
      var last = TWB.whenTw(m.updated_at || gen), next = TWB.whenTw(m.next_update);
      when = [last ? '上次更新 ' + last : '', next ? '下次 ' + next : ''].filter(Boolean).join(' ・ ');
    }
    if (when) html += '<span class="us-when"' + (whenTip ? ' data-tip="' + TWB.esc(whenTip) + '"' : '') + '>' + TWB.esc(when) + '</span>';
    var L = TWB.L();
    if (L && L.fetch_error) {
      html += '<span class="us-warn">⚠️ ' + TWB.esc(L.name) + ' 官網暫時連不上，顯示上次成功抓取' +
        (L.fetched_at ? '（' + TWB.esc(TWB.whenTw(L.fetched_at)) + '）' : '') + '的資料</span>';
    }
    TWB.setHtml(el, html);
  }
  TWB.renderUpdStrip = renderUpdStrip;

  // ------------------------------------------------------------------ header state
  function paintHeader() {
    var lg = TWB.league;
    document.body.setAttribute('data-lg', lg);
    document.querySelectorAll('#lgSwitch .lg-btn').forEach(function (b) {
      var on = b.getAttribute('data-lg') === lg;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    document.querySelectorAll('#mainNav .nav-item').forEach(function (a) {
      var r = a.getAttribute('data-route');
      a.setAttribute('href', TWB.href(r === 'home' ? '' : r));
      var active = r === TWB.route || (r === 'teams' && TWB.route === 'team') || (r === 'schedule' && TWB.route === 'game');
      a.classList.toggle('active', active);
    });
    var brand = document.getElementById('brandLink');
    if (brand) brand.setAttribute('href', TWB.href(''));
    var vb = document.getElementById('verBadgeBtn');
    if (vb) vb.textContent = 'v' + TWB.version;
  }

  // ------------------------------------------------------------------ render
  var lastRouteKey = '';
  TWB.render = function (keepScroll) {
    var ph = parseHash();
    TWB.query = ph.query;
    TWB.league = pickLeague(ph.query);
    try { localStorage.setItem(LS_LEAGUE, TWB.league); } catch (e) { /* ignore */ }
    var name = ROUTES[ph.parts[0] || ''] || 'home';
    TWB.route = name;
    TWB.params = ph.parts.slice(1);
    paintHeader();
    var main = document.getElementById('appMain');
    if (!TWB.snap) {
      TWB.setHtml(main, '<div class="loading-box">載入台灣職籃資料中…</div>');
      return;
    }
    var routeKey = ph.parts.join('/') + '|' + TWB.league;
    if (!keepScroll && routeKey !== lastRouteKey) window.scrollTo(0, 0);
    lastRouteKey = routeKey;
    var page = document.createElement('div');
    page.className = 'page page-' + name;
    main.innerHTML = '';
    main.__html = null;
    main.appendChild(updStripEl());
    renderUpdStrip();
    main.appendChild(page);
    var fn = TWB.pages[name];
    var L = TWB.L();
    try {
      if (!L) {
        page.innerHTML = '<div class="empty-box">這個聯盟目前沒有資料，請稍後再試。</div>';
      } else if (fn) {
        fn(page, { L: L, lg: TWB.league, query: ph.query, params: TWB.params });
      } else {
        page.innerHTML = '<div class="empty-box">找不到這個頁面，<a href="' + TWB.href('') + '">回到今日賽事</a></div>';
      }
    } catch (e) {
      if (window.console) console.error(e);
      page.innerHTML = '<div class="empty-box">⚠️ 頁面發生錯誤：' + TWB.esc(e && e.message) + '</div>';
    }
    document.title = (TWB.pageTitle || '台籃戰情室') + ' · ' + TWB.leagueName() + ' — 台籃戰情室';
    TWB.pageTitle = '';
  };

  // ------------------------------------------------------------------ shared widgets
  /** Season <select> (only seasons that pass filterFn). */
  TWB.seasonSelect = function (cur, filterFn, id) {
    var opts = TWB.seasonOptions(filterFn);
    return '<select class="inp sel" id="' + (id || 'seasonSel') + '" aria-label="賽季">' + opts.map(function (s) {
      return '<option value="' + TWB.esc(s.season) + '"' + (s.season === cur ? ' selected' : '') + '>' + TWB.esc(s.season) +
        ' 賽季' + (s.status === 'IN_PROGRESS' ? '（進行中）' : '') + '</option>';
    }).join('') + '</select>';
  };
  TWB.bindSelect = function (root, id, key) {
    var el = root.querySelector('#' + id);
    if (!el) return;
    el.addEventListener('change', function () { var p = {}; p[key] = el.value; TWB.setQuery(p); });
  };
  /** SVG sparkline / line chart. points: [[label, value], ...] */
  TWB.sparkline = function (points, opts) {
    opts = opts || {};
    var w = opts.w || 140, h = opts.h || 34, color = opts.color || '#2563eb';
    if (!points || points.length < 2) return '<span class="muted small">資料不足</span>';
    var vals = points.map(function (p) { return p[1]; });
    var lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
    if (hi - lo < 1) { hi += 1; lo -= 1; }
    var step = (w - 4) / (points.length - 1);
    var pts = points.map(function (p, i) {
      return (2 + i * step).toFixed(1) + ',' + (h - 3 - (p[1] - lo) / (hi - lo) * (h - 6)).toFixed(1);
    }).join(' ');
    var last = points[points.length - 1];
    return '<svg class="spark" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '" role="img" aria-label="Elo 走勢">' +
      '<polyline fill="none" stroke="' + color + '" stroke-width="1.8" stroke-linejoin="round" points="' + pts + '"/>' +
      '<circle cx="' + (2 + (points.length - 1) * step).toFixed(1) + '" cy="' + (h - 3 - (last[1] - lo) / (hi - lo) * (h - 6)).toFixed(1) +
      '" r="2.6" fill="' + color + '"/></svg>';
  };
  /** Win-probability bar (away left, home right). */
  TWB.probBar = function (pHome, g) {
    if (pHome === null || pHome === undefined) return '';
    var ph = Math.round(pHome * 100), pa = 100 - ph;
    var ca = TWB.team(g.a).color, ch = TWB.team(g.h).color;
    return '<div class="prob">' +
      '<span class="prob-n' + (pa > ph ? ' fav' : '') + '">' + pa + '%</span>' +
      '<div class="prob-bar" role="img" aria-label="模型勝率 客 ' + pa + '% 主 ' + ph + '%"><i style="width:' + pa + '%;background:' + TWB.esc(ca) +
      '"></i><i style="width:' + ph + '%;background:' + TWB.esc(ch) + '"></i></div>' +
      '<span class="prob-n' + (ph > pa ? ' fav' : '') + '">' + ph + '%</span></div>';
  };
  TWB.statusChip = function (g) {
    if (g.status === 'live') return '<span class="chip live"><i class="pulse"></i>進行中' + (g.period ? ' ' + TWB.esc(g.period) : '') + '</span>';
    if (g.status === 'final') return '<span class="chip">已完賽</span>';
    if (g.status === 'postponed') return '<span class="chip warn">延賽／待確認</span>';
    return '<span class="chip info">' + TWB.esc(g.t || '未開賽') + '</span>';
  };

  /** Season player lines (regular season) -> objects with per-game numbers and shooting splits. */
  TWB.playerRows = function (season, lg) {
    var L = TWB.L(lg);
    var F = (TWB.snap && TWB.snap.meta && TWB.snap.meta.player_fields) || [];
    var rows = ((L && L.players) || {})[season] || [];
    return rows.map(function (r) {
      var o = {};
      F.forEach(function (f, i) { o[f] = r[i]; });
      var gp = o.gp || 1;
      o.min = o.sec / 60 / gp;
      ['pts', 'reb', 'oreb', 'dreb', 'ast', 'stl', 'blk', 'tov', 'pf', 'fgm', 'fga', 'tpm', 'tpa', 'ftm', 'fta', 'pm'].forEach(function (k) {
        o[k + '_g'] = (o[k] || 0) / gp;
      });
      o.fg = o.fga ? 100 * o.fgm / o.fga : null;
      o.tp = o.tpa ? 100 * o.tpm / o.tpa : null;
      o.ft = o.fta ? 100 * o.ftm / o.fta : null;
      var tsa = 2 * (o.fga + 0.44 * o.fta);
      o.ts = tsa ? 100 * o.pts / tsa : null;
      o.efg = o.fga ? 100 * (o.fgm + 0.5 * o.tpm) / o.fga : null;
      o.eff_g = (o.pts + o.reb + o.ast + o.stl + o.blk - (o.fga - o.fgm) - (o.fta - o.ftm) - o.tov) / gp;
      return o;
    });
  };
  /** Multi-series SVG line chart. series: [{name, color, points: [[dateStr, value], ...]}] */
  TWB.lineChart = function (series, opts) {
    opts = opts || {};
    var w = opts.w || 760, h = opts.h || 220, padL = 40, padR = 10, padT = 10, padB = 22;
    var all = [];
    series.forEach(function (s) { s.points.forEach(function (p) { all.push(p); }); });
    if (all.length < 2) return '<div class="muted small">資料不足，無法繪圖</div>';
    var dates = all.map(function (p) { return p[0]; }).sort();
    var d0 = Date.parse(dates[0]), d1 = Date.parse(dates[dates.length - 1]);
    if (d1 <= d0) d1 = d0 + 86400000;
    var vals = all.map(function (p) { return p[1]; });
    var lo = Math.floor(Math.min.apply(null, vals) / 25) * 25, hi = Math.ceil(Math.max.apply(null, vals) / 25) * 25;
    if (hi - lo < 50) { hi += 25; lo -= 25; }
    var X = function (d) { return padL + (Date.parse(d) - d0) / (d1 - d0) * (w - padL - padR); };
    var Y = function (v) { return padT + (hi - v) / (hi - lo) * (h - padT - padB); };
    var grid = '';
    for (var v = lo; v <= hi; v += (hi - lo > 200 ? 50 : 25)) {
      grid += '<line x1="' + padL + '" x2="' + (w - padR) + '" y1="' + Y(v).toFixed(1) + '" y2="' + Y(v).toFixed(1) + '" stroke="#eef2f7"/>' +
        '<text x="' + (padL - 6) + '" y="' + (Y(v) + 4).toFixed(1) + '" font-size="10" text-anchor="end" fill="#94a3b8">' + v + '</text>';
    }
    if (lo < 1500 && hi > 1500) grid += '<line x1="' + padL + '" x2="' + (w - padR) + '" y1="' + Y(1500).toFixed(1) + '" y2="' + Y(1500).toFixed(1) + '" stroke="#cbd5e1" stroke-dasharray="4 3"/>';
    var months = {};
    dates.forEach(function (d) { months[d.slice(0, 7)] = 1; });
    var mk = Object.keys(months).sort();
    var stepM = Math.max(1, Math.ceil(mk.length / 8));
    mk.forEach(function (m, i) {
      if (i % stepM) return;
      var x = X(m + '-01');
      if (x < padL) x = padL;
      grid += '<text x="' + x.toFixed(1) + '" y="' + (h - 6) + '" font-size="10" fill="#94a3b8">' + m.slice(2, 4) + '/' + Number(m.slice(5)) + '</text>';
    });
    var lines = series.map(function (s) {
      if (s.points.length < 2) return '';
      var pts = s.points.map(function (p) { return X(p[0]).toFixed(1) + ',' + Y(p[1]).toFixed(1); }).join(' ');
      var last = s.points[s.points.length - 1];
      return '<polyline fill="none" stroke="' + TWB.esc(s.color) + '" stroke-width="' + (s.bold ? 2.6 : 1.6) + '" stroke-linejoin="round" opacity="' +
        (s.dim ? 0.35 : 1) + '" points="' + pts + '"><title>' + TWB.esc(s.name) + '</title></polyline>' +
        '<circle cx="' + X(last[0]).toFixed(1) + '" cy="' + Y(last[1]).toFixed(1) + '" r="3" fill="' + TWB.esc(s.color) + '"/>';
    }).join('');
    return '<svg class="chart" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + TWB.esc(opts.label || 'Elo 走勢') + '">' + grid + lines + '</svg>';
  };

  // ------------------------------------------------------------------ release notes (Pattern 173)
  var publishArmed = false;
  function apiGet(path) {
    return fetch(path, { headers: { Accept: 'application/json' } }).then(function (r) {
      return r.json().then(function (d) { if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status)); return d; });
    });
  }
  function apiPost(path, body) {
    return fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body || {}) })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status)); return d; }); });
  }
  TWB.apiGet = apiGet;
  TWB.apiPost = apiPost;
  function openReleaseModal() {
    publishArmed = false;
    var bd = document.getElementById('relModal');
    bd.classList.remove('hidden');
    var rd = window.TWB_RELEASES || { current_version: TWB.version, releases: [] };
    if (IS_STATIC) { renderRelease({ static: true, current_version: rd.current_version, releases: rd.releases }); return; }
    document.getElementById('relModalBody').innerHTML = '<div class="loading-box">讀取版本紀錄中…</div>';
    apiGet('/api/release_status').then(renderRelease, function () {
      renderRelease({ static: true, current_version: rd.current_version, releases: rd.releases });
    });
  }
  function renderRelease(st) {
    var isLocal = !IS_STATIC && !st.static;
    document.getElementById('relModalTitle').textContent = isLocal ? '🚀 台籃戰情室 · 版本紀錄與發布中心' : '📜 台籃戰情室 · Release Notes';
    var html = '';
    if (isLocal) {
      html += '<div class="card rel-dl"><div><strong>📦 GitHub Pages 單一檔案匯出（免安裝靜態版）</strong>' +
        '<div class="sub">把兩個聯盟的最新資料與所有頁面打包成單一 <code>index.html</code>，可直接上傳 GitHub Pages 或離線開啟。</div></div>' +
        '<a class="btn btn-soft" href="/download/index.html" download="index.html">⬇️ 下載單一 HTML</a></div>';
      if (st.has_changes) {
        var rec = st.recommended_bump || 'patch', nv = st.next_versions || {};
        html += '<div class="card rel-pub"><div class="sec-hdr"><div><strong>🛠️ 偵測到 ' + st.changed_files.length + ' 個未發布檔案變更（+' +
          st.total_added + ' / -' + st.total_removed + ' 行）</strong><div class="sub">' + TWB.esc(st.recommend_reason || '') + '</div></div>' +
          '<span class="chip warn">目前 v' + TWB.esc(st.current_version) + '</span></div><div class="rel-bumps">' +
          ['patch', 'minor', 'major'].map(function (b) {
            return '<label class="rel-bump' + (rec === b ? ' on' : '') + '"><input type="radio" name="relBump" value="' + b + '"' + (rec === b ? ' checked' : '') +
              '> <strong>v' + TWB.esc(nv[b] || '') + '</strong><div class="sub">' + TWB.esc((st.bump_descriptions || {})[b] || '') + '</div></label>';
          }).join('') + '</div>' +
          '<input class="inp" id="relTitleInp" value="' + TWB.esc(st.suggested_title || '') + '" placeholder="版本標題">' +
          '<textarea class="inp" id="relHlInp" rows="3" placeholder="每行一條更新重點">' + TWB.esc((st.suggested_highlights || []).join('\n')) + '</textarea>' +
          '<div class="rel-actions"><button type="button" class="btn btn-primary" id="relPublishBtn">🚀 發布新版本並重新打包</button></div></div>';
      } else {
        html += '<div class="card ok-box">✅ 目前程式碼與最新發布版 <strong>v' + TWB.esc(st.current_version) + '</strong> 同步，沒有待發布的修改。</div>';
      }
    }
    html += '<h4 class="rel-h">📜 Release Notes 歷史版本紀錄</h4>' + (st.releases || []).map(function (r) {
      return '<div class="card rel-item"><div class="rel-top"><span class="chip info">v' + TWB.esc(r.version) + '</span> <strong>' + TWB.esc(r.title || '') +
        '</strong><span class="sub">' + TWB.esc(r.date || '') + '</span></div><ul>' +
        (r.highlights || []).map(function (h) { return '<li>' + TWB.esc(h) + '</li>'; }).join('') + '</ul></div>';
    }).join('');
    document.getElementById('relModalBody').innerHTML = html;
    var btn = document.getElementById('relPublishBtn');
    if (btn) {
      btn.onclick = function () {
        var picked = (document.querySelector('input[name="relBump"]:checked') || {}).value || 'patch';
        if (!publishArmed) { publishArmed = true; btn.textContent = '⚠️ 確定發布 v' + ((st.next_versions || {})[picked] || '') + '？再按一次確認'; return; }
        btn.disabled = true;
        btn.textContent = '⏳ 發布並打包中…';
        apiPost('/api/release_publish', {
          bump_type: picked, title: document.getElementById('relTitleInp').value,
          highlights: document.getElementById('relHlInp').value.split('\n').map(function (x) { return x.trim(); }).filter(Boolean)
        }).then(function (next) {
          publishArmed = false;
          TWB.version = next.current_version;
          paintHeader();
          renderRelease(next);
          TWB.toast('🎉 已發布 v' + next.current_version);
        }, function (e) { publishArmed = false; btn.disabled = false; TWB.toast('⚠️ ' + e.message); });
      };
    }
  }
  TWB.openReleaseModal = openReleaseModal;

  // ------------------------------------------------------------------ live data (local server only)
  var metaTimer = 0, metaDue = false;
  function anyLive(m) {
    var lv = (m && m.live) || {};
    return Object.keys(lv).some(function (k) { return lv[k] > 0; });
  }
  function scheduleMeta() {
    clearTimeout(metaTimer);
    if (IS_STATIC || !TWB.meta) return;
    if (anyLive(TWB.meta) || (TWB.meta.sync && TWB.meta.sync.running)) { metaTimer = setTimeout(pollMeta, 60000); return; }
    // Idle: no polling — one wake-up at the next scheduled update (+45 s) or next tip-off (+3 min).
    var cands = [Date.parse(TWB.meta.next_update || '') + 45000];
    var nt = TWB.meta.next_tip || {};
    Object.keys(nt).forEach(function (k) { if (nt[k]) cands.push(Date.parse(nt[k]) + 180000); });
    var t = Math.min.apply(null, cands.filter(function (x) { return isFinite(x) && x > Date.now(); }));
    if (isFinite(t)) {
      var ms = t - Date.now();
      if (ms > 0 && ms < 12 * 3600 * 1000) metaTimer = setTimeout(pollMeta, ms);
    }
  }
  function pollMeta() {
    if (document.hidden) { metaDue = true; return; }
    metaDue = false;
    apiGet('/api/meta').then(function (m) {
      var changed = TWB.meta && m.updated_at && m.updated_at !== TWB.meta.updated_at;
      TWB.meta = m;
      if (changed) return loadSnapshot().then(function () { TWB.render(true); });
      renderUpdStrip();
    }).catch(function () { /* keep the current data */ }).then(scheduleMeta);
  }
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && metaDue) pollMeta();
  });
  function loadSnapshot() {
    return apiGet('/api/snapshot').then(function (s) { TWB.snap = s; TWB.version = s.version || TWB.version; });
  }

  // ------------------------------------------------------------------ boot
  function boot() {
    document.getElementById('relModalClose').onclick = function () { document.getElementById('relModal').classList.add('hidden'); };
    document.getElementById('relModal').onclick = function (e) { if (e.target.id === 'relModal') e.target.classList.add('hidden'); };
    document.getElementById('verBadgeBtn').onclick = openReleaseModal;
    document.getElementById('verBadgeBtn').title = IS_STATIC ? '查看 Release Notes' : '查看版本紀錄與發布中心';
    document.querySelectorAll('#lgSwitch .lg-btn').forEach(function (b) {
      b.addEventListener('click', function () {
        var lg = b.getAttribute('data-lg');
        if (lg !== TWB.league) TWB.setLeague(lg);
      });
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') document.getElementById('relModal').classList.add('hidden');
    });
    window.addEventListener('hashchange', function () { requestAnimationFrame(function () { TWB.render(); }); });
    if (IS_STATIC) {
      TWB.meta = TWB.snap ? TWB.snap.meta : null;
      TWB.render();
      return;
    }
    Promise.all([apiGet('/api/meta').catch(function () { return null; }), loadSnapshot()]).then(function (r) {
      TWB.meta = r[0] || (TWB.snap && TWB.snap.meta);
      if (r[0] && r[0].version) TWB.version = r[0].version;
      TWB.render();
      scheduleMeta();
    }).catch(function (e) {
      document.getElementById('appMain').innerHTML = '<div class="empty-box">⚠️ 資料載入失敗：' + TWB.esc(e.message) + '</div>';
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
