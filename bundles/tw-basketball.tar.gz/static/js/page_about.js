/* Page: 📖 說明 (#/about) — data sources, update schedule, the model in plain Chinese, glossary. */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;

  T.pages.about = function (root, ctx) {
    var L = ctx.L;
    T.pageTitle = '說明';
    var m = (T.snap && T.snap.meta) || {};
    var s = m.schedule_slots || { sync: [], notes: {} };
    var P = (L.model || {}).params || {};
    var html = '<div class="sec-hdr"><div><h1 class="sec-title">📖 關於台籃戰情室</h1><div class="sub">' + esc(m.study_note || '') + '</div></div></div>';
    html += '<div class="grid-2"><div class="card prose"><h3>🏀 這是什麼？</h3>' +
      '<p>台灣兩大職籃聯盟 <b>P. LEAGUE+</b> 與 <b>TPBL</b> 的數據分析戰情室。頁首可以一鍵切換聯盟，每一頁都只顯示所選聯盟的球隊、戰績、球員與模型，兩個聯盟的資料與模型完全分開、不會混在一起。</p>' +
      '<ul><li>今日賽事：即時比分、賽前預測（勝率、比分、分差、總得分、信心等級與關鍵因素）。</li>' +
      '<li>賽程比分、戰績排行、球隊數據、球員排行與每場比賽的逐場數據。</li>' +
      '<li>模型檢討：命中率、Brier 分數、分差與總分誤差、校準表、Elo 排行與自動調參紀錄。</li></ul>' +
      '<p class="muted small">分享網址可加上 <code>?lg=plg</code> 或 <code>?lg=tpbl</code> 直接指定聯盟，例如 <code>#/standings?lg=plg</code>。</p></div>' +
      '<div class="card prose"><h3>📡 資料來源</h3><ul>' +
      '<li><b>P. LEAGUE+</b>：<a href="https://pleagueofficial.com" target="_blank" rel="noopener">pleagueofficial.com</a> 官網的賽程頁（比分、場館、觀眾）、比賽頁的逐場數據與賽況。</li>' +
      '<li><b>TPBL</b>：<a href="https://tpbl.basketball" target="_blank" rel="noopener">tpbl.basketball</a> 官網使用的公開資料介面（賽季、賽程、比分、逐場數據）。</li></ul>' +
      '<p>抓取時每次請求間隔 1 秒以上、已完賽的比賽只抓一次並永久快取；歷史賽季只用賽程頁的最終比分建立 Elo，逐場數據保留最近兩季。比分與數據一律以官方公布為準。</p>' +
      '<p class="muted small">官方資料沒有提供球員國籍／身分欄位，因此本站不區分本土與洋將；戰績由本站依比分計算，官方排名若另含對戰成績等規則請以官方為準。</p></div></div>';

    html += '<div class="card prose" style="margin-top:12px"><h3>🔄 什麼時候更新？</h3><ul>' +
      s.sync.map(function (t) { return '<li><b>' + esc(t) + '</b>　' + esc((s.notes || {})[t] || '') + '</li>'; }).join('') +
      '<li><b>比賽進行中</b>　本機版每 ' + (s.live_every_min || 2) + ' 分鐘更新一次即時比分；完賽後自動抓逐場數據並重新計算模型。</li></ul>' +
      '<p class="muted small">GitHub 公開版由雲端排程在相同時段自動更新並重新發布（可能晚幾分鐘到半小時）；下載的離線檔案則停在打包當下，不會自動更新。</p></div>';

    html += '<div class="card prose" style="margin-top:12px"><h3>🧠 模型白話說明（每個聯盟各自一套）</h3><ol>' +
      '<li><b>Elo 戰力分數</b>：每隊從 1500 分開始，贏球加分、輸球扣分；贏越多分、或爆冷贏強隊，加得越多（分差乘數）。目前每場調整幅度 K = ' + T.num(P.k, 0) + '。</li>' +
      '<li><b>主場優勢</b>：主隊預設多 ' + T.num(P.hca, 0) + ' Elo（約 ' + T.num((P.hca || 0) / (P.epp || 28)) + ' 分）。</li>' +
      '<li><b>休息天數／背靠背</b>：前一天剛比賽的球隊扣 ' + T.num(P.b2b, 0) + ' Elo。</li>' +
      '<li><b>換季回歸</b>：新賽季開始時，每隊的 Elo 往聯盟平均拉回 ' + Math.round(100 * (P.regress || 0)) + '%（陣容會變動）。</li>' +
      '<li><b>攻守模型</b>：用每隊最近比賽「得分、失分比聯盟水準高或低多少」的加權平均（同時反映節奏與效率），推算雙方預期得分 → 預測總得分。</li>' +
      '<li><b>合成預測</b>：預測分差 = 60% Elo 分差 + 40% 攻守模型分差；勝率由預測分差換算（分差越大、勝率越接近 100%）。</li>' +
      '<li><b>信心等級</b>：看好方勝率 ≥ 72% 為「高」、≥ 60% 為「中」，其餘為「低」；兩隊本季出賽少於 3 場時一律降一級。</li>' +
      '<li><b>逐場前推回測</b>：依時間順序重播每一場，每場只用比賽前已知的資料預測，再把結果加進去，所以沒有偷看答案。</li>' +
      '<li><b>自動調參</b>：每累積 6 場新比賽或每 3 天，自動搜尋 K、主場優勢、回歸、背靠背等參數，只有在 Brier 分數明顯變好時才採用，並寫入調整紀錄。</li>' +
      '<li><b>賽前凍結</b>：每次更新都會重算未開賽的預測；開賽後那一版就固定不再修改，賽後誠實對照命中與否。</li></ol></div>';

    html += '<div class="card" style="margin-top:12px"><h3 class="sec-title sm" style="margin-bottom:8px">📚 名詞解釋</h3><dl class="gloss">' +
      '<dt>真實命中率 TS%</dt><dd>得分 ÷ (2 × (投籃出手 + 0.44 × 罰球出手))。把三分與罰球都算進去，最能反映得分效率。</dd>' +
      '<dt>有效命中率 eFG%</dt><dd>(投籃命中 + 0.5 × 三分命中) ÷ 投籃出手。三分球多算半顆，讓外線球員與內線球員能公平比較。</dd>' +
      '<dt>節奏 Pace</dt><dd>每場大約打幾個進攻回合（回合 ≈ 出手 + 0.44 × 罰球出手 − 進攻籃板 + 失誤，取兩隊平均；延長賽未扣除）。</dd>' +
      '<dt>進攻效率 ORtg／防守效率 DRtg</dt><dd>每 100 個回合得幾分／失幾分。排除節奏快慢的影響，ORtg 越高越好、DRtg 越低越好，相減就是攻守效率差。</dd>' +
      '<dt>Four Factors 四大因素</dt><dd>有效命中率、失誤率、進攻籃板率、罰球率：Dean Oliver 歸納的四個決定勝負的關鍵。</dd>' +
      '<dt>效率值 EFF</dt><dd>得分 + 籃板 + 助攻 + 抄截 + 阻攻 − 投籃不進 − 罰球不進 − 失誤。</dd>' +
      '<dt>Elo</dt><dd>源自西洋棋的戰力評分，1500 為平均；兩隊相差 100 分，大約代表強隊有 64% 勝率（未計主場）。</dd>' +
      '<dt>Brier 分數</dt><dd>(預測勝率 − 實際結果)² 的平均，0 最好、0.25 等於每場都猜 50%。</dd>' +
      '<dt>平均誤差 MAE</dt><dd>預測值和實際值差距的平均，例如分差誤差 10 分＝平均每場差 10 分。</dd>' +
      '<dt>背靠背</dt><dd>連續兩天出賽（第二天的那一場）。</dd>' +
      '<dt>勝差</dt><dd>與第一名的差距：((第一名勝 − 本隊勝) + (本隊敗 − 第一名敗)) ÷ 2。</dd></dl></div>';
    html += '<div class="study-note">' + esc(m.study_note || '') + '</div>';
    root.innerHTML = html;
  };
})();
