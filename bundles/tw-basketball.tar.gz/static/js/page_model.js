/* Page: 🧠 模型準確率與檢討 (#/model) — per league, never mixed. */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;

  function pctTxt(x) { return x === null || x === undefined ? '—' : (100 * x).toFixed(1) + '%'; }
  function kpi(label, val, desc, tip) {
    return '<div class="card kpi"><div class="k"' + (tip ? ' data-tip="' + esc(tip) + '"' : '') + '>' + label + '</div><div class="v">' + val + '</div><div class="d">' + desc + '</div></div>';
  }
  function mini(title, m, note) {
    if (!m || !m.n) return '<div class="card"><h3 class="sec-title sm">' + title + '</h3><div class="muted small" style="margin-top:6px">' + note + '</div></div>';
    return '<div class="card"><h3 class="sec-title sm">' + title + '</h3><div class="chips" style="margin-top:8px"><span class="chip info">' + m.n + ' 場</span>' +
      '<span class="chip ok">命中率 ' + pctTxt(m.hit) + '</span><span class="chip">Brier ' + T.num(m.brier, 3) + '</span><span class="chip">分差誤差 ' + T.num(m.mae_margin) +
      '</span><span class="chip">總分誤差 ' + T.num(m.mae_total) + '</span></div><div class="note-line">' + note + '</div></div>';
  }

  T.pages.model = function (root, ctx) {
    var L = ctx.L;
    T.pageTitle = '模型準確率與檢討';
    var M = L.model || {};
    var m = M.metrics_all || {};
    var P = M.params || {};
    var evalS = (M.eval_seasons || []).join('、');
    var html = '<div class="sec-hdr"><div><h1 class="sec-title">🧠 ' + esc(L.name) + ' 模型準確率與檢討</h1><div class="sub">只用 ' + esc(L.name) +
      ' 自己的比賽訓練與評估 · 模型版本 ' + esc(M.model_version || '—') + (M.run_at ? ' · 計算於 ' + esc(T.whenTw(M.run_at)) : '') + '</div></div></div>';
    if (!m.n) {
      root.innerHTML = html + '<div class="empty-box">已完賽場次還不夠，暫時無法評估模型。</div>';
      return;
    }
    html += '<div class="kpis">' +
      kpi('勝方命中率', pctTxt(m.hit), '對照「永遠猜主隊」' + pctTxt(m.home_base) + ' · ' + m.n + ' 場', '模型賽前看好的一方最後獲勝的比例') +
      kpi('Brier 分數', T.num(m.brier, 3), '越低越好；亂猜 50% = 0.250', '機率預測的平均平方誤差，衡量勝率給得準不準') +
      kpi('分差平均誤差', T.num(m.mae_margin) + ' 分', '預測分差與實際分差的平均差距', 'MAE：|預測分差 − 實際分差| 的平均') +
      kpi('總分平均誤差', T.num(m.mae_total) + ' 分', '預測總得分與實際總分的平均差距', 'MAE：|預測總分 − 實際總分| 的平均') + '</div>' +
      '<div class="note-line">回測區間：' + esc(evalS || '—') + '（第一個賽季只用來建立 Elo 起始戰力，不計分）。每場都只用「開賽前已知」的資料預測，沒有偷看結果。</div>';
    html += '<div class="grid-2" style="margin-top:12px">' +
      mini('📅 本季（' + esc(M.current_season || '') + '）', M.metrics_current, '本季已完賽場次的回測／凍結預測表現；季初樣本少，波動大。') +
      mini('🧊 賽前凍結預測（真正的未來預測）', M.metrics_frozen, '每場在開賽前最後一次更新時凍結，開賽後不再修改；這是最誠實的實戰成績，會隨著比賽進行累積。') + '</div>';

    // calibration
    var cal = (m.calibration || []).filter(function (b) { return b.n; });
    html += '<div class="grid-2" style="margin-top:12px"><div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">🎯 校準：模型說 X% 時，實際贏幾次？</h2></div>' +
      '<table class="tbl"><thead><tr><th>看好方勝率區間</th><th>場數</th><th>平均預測</th><th>實際勝率</th><th class="left" style="width:40%">對照</th></tr></thead><tbody>' +
      cal.map(function (b) {
        var diff = b.actual - b.pred;
        return '<tr><td>' + b.lo + '–' + b.hi + '%</td><td>' + b.n + '</td><td>' + T.num(b.pred) + '%</td><td class="' + (Math.abs(diff) <= 5 ? 'pos' : (diff < 0 ? 'neg' : '')) + '"><b>' +
          T.num(b.actual) + '%</b></td><td class="left"><div class="bar" title="預測 ' + b.pred + '%／實際 ' + b.actual + '%"><i style="width:' + Math.min(100, b.actual) +
          '%;background:var(--accent);opacity:.75"></i></div></td></tr>';
      }).join('') + '</tbody></table><div class="note-line">實際勝率越接近平均預測，代表模型給的機率越可信。</div></div>';

    // ladder
    var ladder = M.ladder || [];
    var lo = Math.min.apply(null, ladder.map(function (x) { return x.elo; }).concat([1450])) - 20;
    var hi = Math.max.apply(null, ladder.map(function (x) { return x.elo; }).concat([1550])) + 10;
    html += '<div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">🪜 Elo 戰力排行（' + esc(M.current_season || '') + '）</h2><span class="sub">1500 = 聯盟平均</span></div>' +
      ladder.map(function (x, i) {
        var t = T.team(x.team_id);
        return '<div class="bar-row" style="grid-template-columns:22px 96px minmax(0,1fr) 46px"><span class="rank-badge' + (i === 0 ? ' top' : '') + '">' + (i + 1) + '</span>' +
          T.teamLink(x.team_id, { size: 18 }) + '<div class="bar"><i style="width:' + (100 * (x.elo - lo) / (hi - lo)).toFixed(1) + '%;background:' + esc(t.color) + '"></i></div>' +
          '<b class="num" style="text-align:right">' + Math.round(x.elo) + '</b></div>';
      }).join('') + '</div></div>';

    // trend
    var hist = M.history || {};
    var series = ladder.map(function (x) {
      var t = T.team(x.team_id);
      return { name: t.short, color: t.color, points: hist[x.team_id] || [] };
    });
    html += '<div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">📈 Elo 走勢（最近兩季）</h2><span class="sub">每場賽後更新；換季時會往平均值回歸</span></div>' +
      T.lineChart(series, { w: 980, h: 260 }) + '<div class="legend">' + series.map(function (s) {
        return '<span><i style="background:' + esc(s.color) + '"></i>' + esc(s.name) + '</span>';
      }).join('') + '</div></div>';

    // params + tune log
    var tl = L.tune_log || [];
    html += '<div class="grid-2" style="margin-top:12px"><div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">⚙️ 目前參數</h2><span class="sub">由自動調參決定</span></div>' +
      '<table class="tbl"><tbody>' +
      '<tr><td class="left">K 值（每場調整幅度）</td><td><b>' + T.num(P.k, 0) + '</b></td></tr>' +
      '<tr><td class="left">主場優勢</td><td><b>' + T.num(P.hca, 0) + ' Elo</b>（約 ' + T.num(P.hca / (P.epp || 28)) + ' 分）</td></tr>' +
      '<tr><td class="left">換季回歸平均</td><td><b>' + Math.round(100 * (P.regress || 0)) + '%</b></td></tr>' +
      '<tr><td class="left">背靠背扣分</td><td><b>' + T.num(P.b2b, 0) + ' Elo</b></td></tr>' +
      '<tr><td class="left">每 1 分分差對應 Elo</td><td><b>' + T.num(P.epp, 0) + '</b></td></tr>' +
      '</tbody></table><div class="note-line">預測分差 = 60% Elo 分差 + 40% 攻守模型（各隊得失分相對聯盟水準的加權平均）；勝率由預測分差換算。</div></div>' +
      '<div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">🛠️ 調整紀錄</h2><span class="sub">每累積 6 場新比賽或每 3 天自動重新搜尋參數</span></div>' +
      (tl.length ? '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>時間</th><th>樣本</th><th class="left">結果</th><th>Brier 前→後</th><th>命中率 前→後</th></tr></thead><tbody>' +
        tl.map(function (r) {
          var pm = r.prev_metrics || {}, nm = r.metrics || {}, pp = r.params || {};
          return '<tr><td>' + esc(T.whenTw(r.run_at)) + '</td><td>' + (r.games || 0) + '</td><td class="left" data-tip="' + esc('K ' + pp.k + '／主場 ' + pp.hca + '／回歸 ' + pp.regress +
            '／背靠背 ' + pp.b2b + '／每分 Elo ' + pp.epp) + '">' + esc(r.note || '') + '</td><td>' + T.num(pm.brier, 3) + ' → <b>' + T.num(nm.brier, 3) + '</b></td><td>' +
            pctTxt(pm.hit) + ' → <b>' + pctTxt(nm.hit) + '</b></td></tr>';
        }).join('') + '</tbody></table></div>' : '<div class="muted small">尚未執行自動調參（完賽場次滿 30 場後開始）。</div>') + '</div></div>';
    html += '<div class="card prose" style="margin-top:12px"><h3>📖 怎麼看這些數字？</h3><ul>' +
      '<li><b>命中率</b>：只看「誰贏」。台灣職籃隊伍少、戰力接近，60% 上下已比「永遠猜主隊」好。</li>' +
      '<li><b>Brier 分數</b>：檢查勝率給得準不準；全部猜 50% 會得到 0.250，越低越好。</li>' +
      '<li><b>分差／總分誤差</b>：預測比分和實際差幾分，用來檢討攻守模型。</li>' +
      '<li><b>回測 vs 賽前凍結</b>：回測是事後用當時已知資料重算；凍結預測是開賽前就固定、事後不能改的版本，兩者都列出來，讓模型好壞一目了然。</li></ul></div>';
    html += '<div class="study-note">' + esc((T.snap.meta && T.snap.meta.study_note) || '') + '</div>';
    root.innerHTML = html;
  };
})();
