/* Page: 🏆 戰績排行 (#/standings) — computed from regular-season results. */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;

  T.pages.standings = function (root, ctx) {
    var L = ctx.L, q = ctx.query;
    T.pageTitle = '戰績排行';
    var withReg = function (s) { return ((L.standings || {})[s.season] || []).length > 0; };
    var opts = T.seasonOptions(withReg);
    var season = opts.some(function (s) { return s.season === q.season; }) ? q.season : T.displaySeason();
    if (!opts.some(function (s) { return s.season === season; }) && opts.length) season = opts[0].season;
    var rows = (L.standings || {})[season] || [];
    var isCur = season === L.current_season;
    var html = '<div class="sec-hdr"><div><h1 class="sec-title">🏆 ' + esc(L.name) + ' 戰績排行</h1>' +
      '<div class="sub">' + esc(season) + ' 賽季例行賽 · 依勝率排序（同勝率依勝敗差、淨勝分）</div></div>' +
      '<div class="filters" style="margin:0">' + T.seasonSelect(season, withReg) + '</div></div>';
    if (!rows.length) {
      html += '<div class="empty-box">這個賽季還沒有例行賽戰績。</div>';
    } else {
      html += '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>排名</th><th class="left sticky">球隊</th><th>勝</th><th>敗</th><th>勝率</th>' +
        '<th>勝差</th><th>主場</th><th>客場</th><th>連勝敗</th><th>近 10 場</th><th>近 5 場</th><th>場均得分</th><th>場均失分</th><th>淨勝分</th>' +
        (isCur ? '<th data-tip="模型目前的 Elo 戰力分數">Elo</th>' : '') + '</tr></thead><tbody>' +
        rows.map(function (r) {
          var dots = (r.last5 || '').split('').map(function (x) { return '<i class="' + x + '"></i>'; }).join('');
          return '<tr><td><span class="rank-badge' + (r.rank === 1 ? ' top' : '') + '">' + r.rank + '</span></td>' +
            '<td class="left sticky">' + T.teamLink(r.team_id) + '</td><td><b>' + r.w + '</b></td><td>' + r.l + '</td>' +
            '<td><b>' + (r.gp ? (r.pct * 100).toFixed(1) + '%' : '—') + '</b></td><td>' + esc(r.gb) + '</td><td>' + esc(r.home) + '</td>' +
            '<td>' + esc(r.away) + '</td><td class="' + (/勝/.test(r.strk) ? 'pos' : 'neg') + '">' + esc(r.strk || '—') + '</td>' +
            '<td>' + esc(r.l10) + '</td><td><span class="dots">' + dots + '</span></td><td>' + T.num(r.ppg) + '</td><td>' + T.num(r.opp) + '</td>' +
            '<td class="' + ((r.diff || 0) >= 0 ? 'pos' : 'neg') + '"><b>' + T.signed(r.diff) + '</b></td>' +
            (isCur ? '<td>' + (r.elo || '—') + '</td>' : '') + '</tr>';
        }).join('') + '</tbody></table></div>';
      html += '<div class="note-line">戰績由本站依官方公布的每場比分計算；官方排名若另含對戰成績等規則，請以官方公告為準。季後挑戰賽、季後賽與總冠軍賽不列入。</div>';
    }
    root.innerHTML = html;
    T.bindSelect(root, 'seasonSel', 'season');
  };
})();
