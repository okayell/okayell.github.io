/* Page: ⛹️ 球員排行 (#/players) — leaders + sortable per-game table (regular season, from box scores). */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;
  var COLS = [
    ['gp', '出賽', 0], ['min', '時間', 1], ['pts_g', '得分', 1], ['reb_g', '籃板', 1], ['ast_g', '助攻', 1], ['stl_g', '抄截', 1],
    ['blk_g', '阻攻', 1], ['tov_g', '失誤', 1], ['fg', '命中率', 1], ['tp', '三分%', 1], ['ft', '罰球%', 1], ['ts', 'TS%', 1],
    ['efg', 'eFG%', 1], ['eff_g', '效率', 1], ['pm_g', '+/-', 1]
  ];
  var TIPS = { ts: '真實命中率：得分 ÷ (2 × (投籃出手 + 0.44 × 罰球出手))', efg: '有效命中率：(命中 + 0.5 × 三分命中) ÷ 出手',
    eff_g: '效率值 EFF = 得分 + 籃板 + 助攻 + 抄截 + 阻攻 − 投籃不進 − 罰球不進 − 失誤（場均）', pm_g: '場上正負值（場均）' };
  var LEADERS = [
    ['pts_g', '🏀 得分', ''], ['reb_g', '🧱 籃板', ''], ['ast_g', '🎯 助攻', ''], ['stl_g', '🖐️ 抄截', ''], ['blk_g', '⛔ 阻攻', ''],
    ['fg', '✅ 投籃命中率', '%'], ['tp', '🎯 三分命中率', '%'], ['ts', '💧 真實命中率 TS%', '%'], ['eff_g', '⚡ 效率值', '']
  ];

  function qualifies(p, key, minGp) {
    if (p.gp < minGp) return false;
    if (key === 'fg') return p.fga_g >= 5;
    if (key === 'tp') return p.tpa_g >= 2;
    if (key === 'ft') return p.fta_g >= 1.5;
    if (key === 'ts' || key === 'efg') return p.fga_g >= 5;
    return true;
  }

  T.pages.players = function (root, ctx) {
    var L = ctx.L, q = ctx.query;
    T.pageTitle = '球員排行';
    var bs = L.box_seasons || [];
    var opts = T.seasonOptions(function (s) { return bs.indexOf(s.season) >= 0 && ((L.players || {})[s.season] || []).length > 0; });
    var season = opts.some(function (s) { return s.season === q.season; }) ? q.season :
      (opts.some(function (s) { return s.season === T.displaySeason(); }) ? T.displaySeason() : (opts[0] || {}).season);
    var all = season ? T.playerRows(season) : [];
    var teamIds = {};
    all.forEach(function (p) { teamIds[p.team_id] = 1; });
    var team = teamIds[q.team] ? q.team : '';
    var maxGp = all.reduce(function (m, p) { return Math.max(m, p.gp); }, 0);
    var minGp = Math.max(1, Math.round(maxGp * 0.4));
    var list = all.filter(function (p) { return !team || p.team_id === team; });
    var sort = COLS.some(function (c) { return c[0] === q.sort; }) ? q.sort : 'pts_g';
    var pctKey = ['fg', 'tp', 'ft', 'ts', 'efg'].indexOf(sort) >= 0;

    var html = '<div class="sec-hdr"><div><h1 class="sec-title">⛹️ ' + esc(L.name) + ' 球員排行</h1><div class="sub">' + esc(season || '—') +
      ' 賽季例行賽 · 依逐場數據統計 · 排行門檻：出賽 ≥ ' + minGp + ' 場（命中率另需場均出手 ≥ 5，三分 ≥ 2）</div></div></div>';
    if (!all.length) {
      root.innerHTML = html + '<div class="empty-box">目前沒有球員逐場數據（本站只保留最近兩季，賽季剛開打時資料較少）。</div>';
      return;
    }
    if (season === L.current_season && maxGp < 5) {
      html += '<div class="banner">📢 ' + esc(season) + ' 賽季才剛開打（最多 ' + maxGp + ' 場），排行波動大；可切換到上一季參考完整數據。</div>';
    }
    html += '<div class="filters">' + T.seasonSelect(season, function (s) { return opts.indexOf(s) >= 0; }) +
      '<select class="inp sel" id="teamSel" aria-label="球隊"><option value="">全部球隊</option>' + Object.keys(teamIds).sort(function (a, b) {
        return T.team(a).short.localeCompare(T.team(b).short, 'zh-Hant');
      }).map(function (t) { return '<option value="' + esc(t) + '"' + (t === team ? ' selected' : '') + '>' + esc(T.team(t).short) + '</option>'; }).join('') +
      '</select><input class="inp" id="plSearch" type="search" placeholder="搜尋球員姓名" autocomplete="off" style="width:160px"></div>';

    // leader cards
    html += '<div class="grid-3">' + LEADERS.map(function (ld) {
      var key = ld[0];
      var top = list.filter(function (p) { return qualifies(p, key, minGp) && p[key] !== null; })
        .sort(function (a, b) { return b[key] - a[key]; }).slice(0, 5);
      return '<div class="card"><div class="sec-hdr" style="margin:0 0 6px"><h3 class="sec-title sm">' + ld[1] + '</h3>' +
        '<a class="small" href="' + T.href('players', { season: season, team: team, sort: key }) + '">完整排行</a></div>' +
        (top.length ? top.map(function (p, i) {
          return '<div class="bar-row" style="grid-template-columns:22px minmax(0,1fr) 58px"><span class="rank-badge' + (i === 0 ? ' top' : '') + '">' + (i + 1) + '</span>' +
            '<span class="tm-nm"><b>' + esc(p.name) + '</b> <span class="muted small">' + esc(T.team(p.team_id).short) + '</span></span>' +
            '<b class="num" style="text-align:right">' + T.num(p[key]) + ld[2] + '</b></div>';
        }).join('') : '<div class="muted small">尚無符合門檻的球員</div>') + '</div>';
    }).join('') + '</div>';

    // table
    var rows = list.filter(function (p) { return !pctKey || qualifies(p, sort, minGp); })
      .sort(function (a, b) { return (b[sort] === null ? -1e9 : b[sort]) - (a[sort] === null ? -1e9 : a[sort]); });
    var showAll = q.all === '1';
    html += '<div class="sec-hdr"><h2 class="sec-title sm">📊 完整數據（場均）</h2><span class="sub">點欄位標題排序' +
      (pctKey ? '；命中率排序只列出達出手門檻的球員' : '') + '</span></div>';
    html += '<div class="tbl-wrap"><table class="tbl" id="plTable"><thead><tr><th>#</th><th class="left sticky">球員</th><th class="left">球隊</th>' +
      COLS.map(function (c) {
        return '<th class="sortable' + (c[0] === sort ? ' on' : '') + '" data-sort="' + c[0] + '"' + (TIPS[c[0]] ? ' data-tip="' + esc(TIPS[c[0]]) + '"' : '') + '>' + c[1] + '</th>';
      }).join('') + '</tr></thead><tbody>' +
      rows.map(function (p, i) {
        var more = !showAll && i >= 60;
        return '<tr data-name="' + esc(p.name) + '"' + (more ? ' data-more="1" style="display:none"' : '') + '><td>' + (i + 1) + '</td><td class="left sticky"><b>' + esc(p.name) + '</b>' + (p.number ? ' <span class="muted small">#' + esc(p.number) + '</span>' : '') +
          '</td><td class="left">' + T.teamLink(p.team_id, { size: 18 }) + '</td>' +
          COLS.map(function (c) {
            var v = p[c[0]];
            var txt = c[0] === 'pm_g' ? T.signed(v) : (c[2] === 0 ? String(v) : T.num(v));
            return '<td class="' + (c[0] === sort ? 'on' : '') + '">' + txt + '</td>';
          }).join('') + '</tr>';
      }).join('') + '</tbody></table></div>';
    if (!showAll && rows.length > 60) {
      html += '<div style="text-align:center;margin-top:10px"><a class="btn btn-sm" href="' + T.href('players', { season: season, team: team, sort: sort, all: 1 }) +
        '">顯示全部 ' + rows.length + ' 位球員</a></div>';
    }
    html += '<div class="note-line">官方資料未提供球員國籍／身分欄位，因此本站不區分本土與洋將。</div>';
    root.innerHTML = html;
    T.bindSelect(root, 'teamSel', 'team');
    var ss = root.querySelector('#seasonSel');
    if (ss) ss.addEventListener('change', function () { T.setQuery({ season: ss.value, team: '', all: '' }); });
    var table = root.querySelector('#plTable');
    table.tHead.addEventListener('click', function (ev) {
      var th = ev.target.closest('th[data-sort]');
      if (th) T.setQuery({ sort: th.getAttribute('data-sort') });
    });
    var search = root.querySelector('#plSearch');
    if (search) {
      var trs = Array.prototype.slice.call(table.tBodies[0].rows), raf = 0;
      var apply = function () {
        raf = 0;
        var k = search.value.trim();
        trs.forEach(function (tr) {
          var match = (tr.getAttribute('data-name') || '').indexOf(k) >= 0;
          var d = k ? (match ? '' : 'none') : (tr.getAttribute('data-more') ? 'none' : '');
          if (tr.style.display !== d) tr.style.display = d;
        });
      };
      search.addEventListener('input', function () { if (!raf) raf = requestAnimationFrame(apply); });
      search.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' && !T.isEnterSend(ev)) ev.preventDefault(); });
    }
  };
})();
