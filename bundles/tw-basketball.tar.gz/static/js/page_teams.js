/* Pages: 🛡️ 球隊數據 (#/teams) and 球隊詳情 (#/team/<id>). */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;

  function teamsInSeason(season) {
    var m = {};
    T.games(season).forEach(function (g) { if (g.st !== 'pre') { m[g.h] = 1; m[g.a] = 1; } });
    return Object.keys(m);
  }
  function standRow(L, season, tid) {
    return ((L.standings || {})[season] || []).filter(function (r) { return r.team_id === tid; })[0] || null;
  }
  function eloPoints(L, tid, season) {
    var h = ((L.model || {}).history || {})[tid] || [];
    var seasonGames = {};
    if (season) T.games(season).forEach(function (g) { seasonGames[g.d] = 1; });
    return h.filter(function (p) { return !season || seasonGames[p[0]]; });
  }
  function leagueAvg(stats, key) {
    var vals = Object.keys(stats || {}).map(function (k) { return stats[k][key]; }).filter(function (v) { return v !== null && v !== undefined; });
    return vals.length ? vals.reduce(function (a, b) { return a + b; }, 0) / vals.length : null;
  }

  // ------------------------------------------------------------------ list
  T.pages.teams = function (root, ctx) {
    var L = ctx.L, q = ctx.query;
    T.pageTitle = '球隊數據';
    var opts = T.seasonOptions(function (s) { return s.stages.indexOf('regular') >= 0; });
    var season = opts.some(function (s) { return s.season === q.season; }) ? q.season : T.displaySeason();
    var tids = teamsInSeason(season);
    var stats = (L.team_stats || {})[season] || {};
    var isCur = season === L.current_season;
    var elo = {};
    ((L.model || {}).ladder || []).forEach(function (x) { elo[x.team_id] = x.elo; });
    tids.sort(function (a, b) {
      var ra = standRow(L, season, a), rb = standRow(L, season, b);
      return (ra ? ra.rank : 99) - (rb ? rb.rank : 99);
    });
    var html = '<div class="sec-hdr"><div><h1 class="sec-title">🛡️ ' + esc(L.name) + ' 球隊數據</h1><div class="sub">' + esc(season) +
      ' 賽季 · ' + tids.length + ' 隊 · 點球隊看陣容、賽果與 Elo 走勢</div></div><div class="filters" style="margin:0">' +
      T.seasonSelect(season, function (s) { return s.stages.indexOf('regular') >= 0; }) + '</div></div><div class="team-grid">';
    html += tids.map(function (tid) {
      var t = T.team(tid), r = standRow(L, season, tid), s = stats[tid];
      var pts = eloPoints(L, tid, season);
      var dots = r ? (r.last5 || '').split('').map(function (x) { return '<i class="' + x + '"></i>'; }).join('') : '';
      return '<a class="card tcard" style="--tc:' + esc(t.color) + '" href="' + T.href('team/' + tid, { season: season }) + '">' +
        '<div class="tc-hd">' + T.logo(tid, 40) + '<div><div class="nm">' + esc(t.name) + '</div><div class="en">' + esc(t.en || '') + '</div></div></div>' +
        '<div class="chips">' + (r ? '<span class="chip info">第 ' + r.rank + ' 名 · ' + r.w + '-' + r.l + '</span>' : '') +
        (isCur && elo[tid] ? '<span class="chip">Elo ' + Math.round(elo[tid]) + '</span>' : '') +
        (r && r.strk ? '<span class="chip ' + (/勝/.test(r.strk) ? 'ok' : 'bad') + '">' + esc(r.strk) + '</span>' : '') + '<span class="dots">' + dots + '</span></div>' +
        '<div class="tc-stats"><div><div class="k">場均得分</div><div class="v">' + T.num(r && r.ppg) + '</div></div>' +
        '<div><div class="k">場均失分</div><div class="v">' + T.num(r && r.opp) + '</div></div>' +
        '<div><div class="k">淨勝分</div><div class="v ' + ((r && r.diff) >= 0 ? 'pos' : 'neg') + '">' + T.signed(r && r.diff) + '</div></div>' +
        (s ? '<div><div class="k">有效命中率</div><div class="v">' + T.num(s.efg) + '%</div></div><div><div class="k">節奏</div><div class="v">' + T.num(s.pace) +
          '</div></div><div><div class="k">攻守效率差</div><div class="v ' + ((s.net || 0) >= 0 ? 'pos' : 'neg') + '">' + T.signed(s.net) + '</div></div>' : '') +
        '</div>' + (pts.length > 1 ? '<div class="muted small">Elo 走勢 ' + T.sparkline(pts, { w: 220, h: 34, color: t.color }) + '</div>' : '') + '</a>';
    }).join('') + '</div>';
    if (!Object.keys(stats).length) html += '<div class="note-line">這個賽季沒有逐場數據（本站只保留最近兩季的逐場數據），因此只顯示得失分。</div>';
    root.innerHTML = html;
    T.bindSelect(root, 'seasonSel', 'season');
  };

  // ------------------------------------------------------------------ detail
  function ffRow(label, tip, mine, opp, avg, higherBetter) {
    var good = mine !== null && avg !== null ? (higherBetter ? mine >= avg : mine <= avg) : null;
    return '<tr><td class="left" data-tip="' + esc(tip) + '">' + label + '</td><td class="' + (good === null ? '' : (good ? 'pos' : 'neg')) + '"><b>' +
      T.num(mine) + '%</b></td><td>' + T.num(opp) + '%</td><td class="muted">' + T.num(avg) + '%</td></tr>';
  }

  T.pages.team = function (root, ctx) {
    var L = ctx.L, q = ctx.query;
    var tid = ctx.params[0];
    if (!tid || !L.teams[tid]) {
      root.innerHTML = '<div class="empty-box">找不到這支球隊（球隊編號只在同一個聯盟內有效）。<a href="' + T.href('teams') + '">回到球隊列表</a></div>';
      return;
    }
    var t = T.team(tid);
    T.pageTitle = t.name;
    var played = T.seasonOptions(function (s) {
      return T.games(s.season).some(function (g) { return g.h === tid || g.a === tid; });
    });
    var season = played.some(function (s) { return s.season === q.season; }) ? q.season :
      (played.some(function (s) { return s.season === T.displaySeason(); }) ? T.displaySeason() : (played[0] || {}).season);
    var r = standRow(L, season, tid);
    var s = ((L.team_stats || {})[season] || {})[tid];
    var stats = (L.team_stats || {})[season] || {};
    var isCur = season === L.current_season;
    var elo = null;
    ((L.model || {}).ladder || []).forEach(function (x) { if (x.team_id === tid) elo = x.elo; });

    var html = '<div class="card" style="border-top:4px solid ' + esc(t.color) + '"><div class="tc-hd team-hd">' + T.logo(tid, 56) +
      '<div style="flex:1;min-width:0"><div class="sec-title">' + esc(t.name) + '</div><div class="sub">' + esc([t.en, L.name].filter(Boolean).join(' · ')) + '</div></div>' +
      '<div class="filters" style="margin:0">' + T.seasonSelect(season, function (x) { return played.indexOf(x) >= 0; }) + '</div></div>' +
      '<div class="chips" style="margin-top:8px">' + (r ? '<span class="chip info">例行賽第 ' + r.rank + ' 名</span><span class="chip">' + r.w + ' 勝 ' + r.l +
        ' 敗（' + (r.pct * 100).toFixed(1) + '%）</span><span class="chip">主場 ' + esc(r.home) + '</span><span class="chip">客場 ' + esc(r.away) + '</span>' +
        (r.strk ? '<span class="chip ' + (/勝/.test(r.strk) ? 'ok' : 'bad') + '">' + esc(r.strk) + '</span>' : '') : '') +
      (isCur && elo ? '<span class="chip">Elo ' + Math.round(elo) + '</span>' : '') + '</div></div>';

    // KPIs + four factors
    html += '<div class="kpis" style="margin-top:12px">' +
      '<div class="card kpi"><div class="k">場均得分 / 失分</div><div class="v">' + T.num(r && r.ppg) + ' / ' + T.num(r && r.opp) + '</div><div class="d">淨勝分 ' + T.signed(r && r.diff) + '</div></div>' +
      '<div class="card kpi"><div class="k" data-tip="每場大約的進攻回合數（40 分鐘，延長賽未扣除）">節奏 Pace</div><div class="v">' + T.num(s && s.pace) + '</div><div class="d">聯盟平均 ' + T.num(leagueAvg(stats, 'pace')) + '</div></div>' +
      '<div class="card kpi"><div class="k" data-tip="每 100 回合得分">進攻效率 ORtg</div><div class="v">' + T.num(s && s.ortg) + '</div><div class="d">聯盟平均 ' + T.num(leagueAvg(stats, 'ortg')) + '</div></div>' +
      '<div class="card kpi"><div class="k" data-tip="每 100 回合失分（越低越好）">防守效率 DRtg</div><div class="v">' + T.num(s && s.drtg) + '</div><div class="d">攻守效率差 ' + T.signed(s && s.net) + '</div></div></div>';

    var hist = eloPoints(L, tid, null);
    html += '<div class="grid-2" style="margin-top:12px"><div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">📐 Four Factors（四大致勝因素）</h2><span class="sub">本隊 vs 對手 vs 聯盟平均</span></div>' +
      (s ? '<table class="tbl"><thead><tr><th class="left">項目</th><th>本隊</th><th>對手</th><th>聯盟平均</th></tr></thead><tbody>' +
        ffRow('有效命中率 eFG%', '(命中 + 0.5×三分命中) ÷ 出手；越高越好', s.efg, s.o_efg, leagueAvg(stats, 'efg'), true) +
        ffRow('失誤率 TOV%', '失誤 ÷ (出手 + 0.44×罰球出手 + 失誤)；越低越好', s.tov_pct, s.o_tov_pct, leagueAvg(stats, 'tov_pct'), false) +
        ffRow('進攻籃板率 ORB%', '本隊進攻籃板 ÷ (本隊進攻籃板 + 對手防守籃板)；越高越好', s.orb_pct, s.drb_pct === null ? null : 100 - s.drb_pct, leagueAvg(stats, 'orb_pct'), true) +
        ffRow('罰球率 FT/FGA', '罰球命中 ÷ 投籃出手；越高越好', s.ftr, s.o_ftr, leagueAvg(stats, 'ftr'), true) + '</tbody></table>' +
        '<div class="note-line">三分 ' + T.num(s.tp) + '%（場均出手 ' + T.num(s.tpa) + '）· 罰球 ' + T.num(s.ft) + '% · 場均籃板 ' + T.num(s.reb) + ' · 助攻 ' + T.num(s.ast) + ' · 失誤 ' + T.num(s.tov) + '</div>'
        : '<div class="muted">這個賽季沒有逐場數據（本站只保留最近兩季）。</div>') + '</div>' +
      '<div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">📈 Elo 走勢</h2><span class="sub">最近兩季，虛線＝1500 聯盟平均</span></div>' +
      T.lineChart([{ name: t.short, color: t.color, points: hist, bold: true }], { w: 560, h: 200 }) + '</div></div>';

    // results + upcoming
    var games = T.games(season).filter(function (g) { return g.h === tid || g.a === tid; });
    var done = games.filter(T.isFinal).reverse();
    var upcoming = games.filter(function (g) { return g.status === 'scheduled' || g.status === 'live'; }).slice(0, 4);
    if (upcoming.length) {
      html += '<div class="sec-hdr"><h2 class="sec-title sm">🗓️ 接下來的比賽</h2></div><div class="games-grid">' +
        upcoming.map(function (g) { return T.gameCard(g, { compact: true }); }).join('') + '</div>';
    }
    html += '<div class="sec-hdr"><h2 class="sec-title sm">📋 賽果（' + done.length + ' 場）</h2><span class="sub">✔／✘＝模型賽前看好的一方是否獲勝</span></div>';
    if (done.length) {
      html += '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>日期</th><th>賽事</th><th class="left">對手</th><th>比分</th><th>勝負</th><th>模型</th><th></th></tr></thead><tbody>' +
        done.map(function (g) {
          var home = g.h === tid, my = home ? g.hs : g.as, op = home ? g.as : g.hs, won = my > op;
          var gr = T.grade(g, T.pred(g.id));
          return '<tr><td>' + esc(T.md(g.d)) + '</td><td><span class="chip stage">' + esc(T.stageLabel(g.st)) + '</span></td><td class="left">' +
            (home ? 'vs ' : '@ ') + T.teamLink(home ? g.a : g.h) + '</td><td><b>' + my + ' : ' + op + '</b></td><td class="' + (won ? 'pos' : 'neg') + '"><b>' + (won ? '勝' : '敗') + '</b></td>' +
            '<td>' + (gr ? '<span class="' + (gr.hit ? 'hit' : 'miss') + '">' + (gr.hit ? '✔' : '✘') + '</span>' : (g.st === 'pre' ? '<span class="muted">熱身</span>' : '—')) + '</td>' +
            '<td><a href="' + T.href('game/' + g.id) + '">詳情</a></td></tr>';
        }).join('') + '</tbody></table></div>';
    } else {
      html += '<div class="empty-box">這個賽季還沒有完賽紀錄。</div>';
    }

    // roster
    var roster = T.playerRows(season).filter(function (p) { return p.team_id === tid; }).sort(function (a, b) { return b.pts_g - a.pts_g; });
    html += '<div class="sec-hdr"><h2 class="sec-title sm">👥 陣容與球員數據（例行賽場均）</h2><span class="sub">依場均得分排序</span></div>';
    if (roster.length) {
      html += '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="left sticky">球員</th><th>背號</th><th>出賽</th><th>先發</th><th>時間</th><th>得分</th><th>籃板</th>' +
        '<th>助攻</th><th>抄截</th><th>阻攻</th><th>失誤</th><th>命中率</th><th>三分%</th><th>罰球%</th><th data-tip="真實命中率：把三分與罰球都算進去的得分效率">TS%</th><th data-tip="效率值 EFF">效率</th></tr></thead><tbody>' +
        roster.map(function (p) {
          return '<tr><td class="left sticky"><b>' + esc(p.name) + '</b>' + (p.pos ? ' <span class="muted small">' + esc(p.pos) + '</span>' : '') + '</td><td>' + esc(p.number) +
            '</td><td>' + p.gp + '</td><td>' + p.gs + '</td><td>' + T.num(p.min) + '</td><td class="on">' + T.num(p.pts_g) + '</td><td>' + T.num(p.reb_g) + '</td><td>' + T.num(p.ast_g) +
            '</td><td>' + T.num(p.stl_g) + '</td><td>' + T.num(p.blk_g) + '</td><td>' + T.num(p.tov_g) + '</td><td>' + T.num(p.fg) + '</td><td>' + T.num(p.tp) + '</td><td>' + T.num(p.ft) +
            '</td><td>' + T.num(p.ts) + '</td><td>' + T.num(p.eff_g) + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    } else {
      html += '<div class="empty-box">' + (s ? '這個賽季還沒有例行賽逐場數據。' : '這個賽季沒有逐場數據（本站只保留最近兩季）。') + '</div>';
    }
    root.innerHTML = html;
    T.bindSelect(root, 'seasonSel', 'season');
  };
})();
