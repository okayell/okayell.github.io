/* Page: 🏠 今日賽事＆賽前預測 (#/) + shared game card. */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;

  function recMap(L, season) {
    var m = {};
    ((L.standings || {})[season] || []).forEach(function (r) { m[r.team_id] = r.w + '-' + r.l; });
    return m;
  }

  function edge(a, b, higherBetter) {
    if (a === null || a === undefined || b === null || b === undefined || a === b) return ['', ''];
    var aBetter = higherBetter ? a > b : a < b;
    return aBetter ? ['edge', ''] : ['', 'edge'];
  }
  function restTxt(d, b2b) {
    if (d === null || d === undefined) return '季初首戰';
    return (b2b ? '<span class="b2b">背靠背</span>' : d + ' 天');
  }
  function factorTable(g, f) {
    if (!f || !f.elo) return '';
    var A = T.team(g.a).short, H = T.team(g.h).short;
    var e = edge(f.elo[0], f.elo[1], true);
    var r = edge(f.rest[0] === null ? 7 : f.rest[0], f.rest[1] === null ? 7 : f.rest[1], true);
    var pp = edge(f.ppg[0], f.ppg[1], true);
    var op = edge(f.opp[0], f.opp[1], false);
    function wins(s) { var m = /^(\d+)-(\d+)$/.exec(s || ''); return m ? Number(m[1]) - Number(m[2]) : null; }
    var l5 = edge(wins(f.last5[0]), wins(f.last5[1]), true);
    return '<table class="factors"><thead><tr><td class="muted">' + esc(A) + '（客）</td><th>關鍵因素</th><td class="muted">' + esc(H) + '（主）</td></tr></thead><tbody>' +
      '<tr><td class="' + e[0] + '">' + f.elo[0] + '</td><th data-tip="Elo 戰力分數：依每場勝負與分差累積，越高越強">Elo</th><td class="' + e[1] + '">' + f.elo[1] + '</td></tr>' +
      '<tr><td class="' + l5[0] + '">' + esc(f.last5[0]) + '</td><th>近 5 場</th><td class="' + l5[1] + '">' + esc(f.last5[1]) + '</td></tr>' +
      '<tr><td>' + esc(f.split[0]) + '</td><th>主客場</th><td>' + esc(f.split[1]) + '</td></tr>' +
      '<tr><td class="' + r[0] + '">' + restTxt(f.rest[0], f.b2b[0]) + '</td><th data-tip="距離上一場比賽的天數；前一天剛比賽＝背靠背">休息天數</th><td class="' + r[1] + '">' + restTxt(f.rest[1], f.b2b[1]) + '</td></tr>' +
      '<tr><td class="' + pp[0] + '">' + T.num(f.ppg[0]) + '</td><th data-tip="本季場均得分（反映節奏與進攻效率）">場均得分</th><td class="' + pp[1] + '">' + T.num(f.ppg[1]) + '</td></tr>' +
      '<tr><td class="' + op[0] + '">' + T.num(f.opp[0]) + '</td><th data-tip="本季場均失分（反映防守）">場均失分</th><td class="' + op[1] + '">' + T.num(f.opp[1]) + '</td></tr>' +
      '</tbody></table>';
  }
  T.factorTable = factorTable;

  function notes(g, p) {
    var f = p && p.f;
    if (!f || !f.elo) return [];
    var A = T.team(g.a).short, H = T.team(g.h).short, out = [];
    var de = f.elo[1] - f.elo[0];
    out.push(Math.abs(de) >= 15 ? 'Elo 差距 ' + Math.abs(de) + ' 分，' + (de > 0 ? H : A) + '帳面較強' : '兩隊 Elo 接近（差 ' + Math.abs(de) + ' 分），勝負較難預料');
    if (f.b2b[1]) out.push(H + '背靠背出賽（前一天剛比賽），模型略為扣分');
    if (f.b2b[0]) out.push(A + '背靠背出賽（前一天剛比賽），模型略為扣分');
    if (f.hca_pts) out.push('主場優勢約 +' + f.hca_pts + ' 分');
    if (f.gp && (f.gp[0] < 3 || f.gp[1] < 3)) out.push('本季已賽場數少，預測主要參考上季戰力，信心較低');
    return out.slice(0, 4);
  }

  /** Game card used on the home page and the team page. opts: {compact, rec} */
  T.gameCard = function (g, opts) {
    opts = opts || {};
    var L = T.L();
    var p = T.pred(g.id);
    var rec = opts.rec || recMap(L, g.s);
    var live = g.status === 'live', fin = T.isFinal(g);
    var hasScore = (live || fin) && g.hs !== null;
    var score = hasScore
      ? '<div class="gc-score"><span class="' + (g.as > g.hs ? 'w' : (fin ? 'l' : 'w')) + '">' + g.as + '</span> : <span class="' +
        (g.hs > g.as ? 'w' : (fin ? 'l' : 'w')) + '">' + g.hs + '</span></div>'
      : '<div class="gc-vs">VS</div>';
    var top = '<div class="gc-top"><span class="chip stage">' + esc(T.stageLabel(g.st)) + (g.c ? ' ' + esc(g.c) : '') + '</span>' +
      '<span>' + esc(T.dayLabel(g.d)) + ' ' + esc(g.t) + '</span>' + (g.v ? '<span>· ' + esc(g.v) + '</span>' : '') +
      '<span class="sp"></span>' + (p && !fin && p.conf ? T.confChip(p.conf) : '') + T.statusChip(g) + '</div>';
    var teams = '<div class="gc-teams"><div class="gc-side away">' + T.teamLink(g.a) +
      '<span class="gc-rec"><span class="ha">客</span> ' + esc(rec[g.a] || '') + '</span></div>' +
      '<div class="gc-mid">' + score + '</div>' +
      '<div class="gc-side home">' + T.teamLink(g.h) + '<span class="gc-rec">' + esc(rec[g.h] || '') + ' <span class="ha">主</span></span></div></div>';
    var body = '';
    if (g.st === 'pre') {
      body = '<div class="note-line">熱身賽不列入模型與戰績計算。</div>';
    } else if (p) {
      body += T.probBar(p.p, g);
      var favH = p.m >= 0;
      body += '<div class="gc-pred"><div><div class="k">預測比分</div><div class="v">' + T.num(p.ap) + ' : ' + T.num(p.hp) + '</div></div>' +
        '<div><div class="k">預測分差</div><div class="v">' + esc(T.team(favH ? g.h : g.a).short) + ' +' + T.num(Math.abs(p.m)) + '</div></div>' +
        '<div><div class="k">預測總得分</div><div class="v">' + T.num(p.tot) + '</div></div></div>';
      if (fin) {
        var gr = T.grade(g, p);
        if (gr) {
          body += '<div class="gc-grade"><span class="' + (gr.hit ? 'hit' : 'miss') + '">' + (gr.hit ? '✔ 命中勝方' : '✘ 未命中勝方') + '</span>' +
            '<span>實際分差 ' + esc(T.team(g.hs > g.as ? g.h : g.a).short) + ' +' + Math.abs(g.hs - g.as) + '（誤差 ' + T.num(gr.marginErr) + '）</span>' +
            '<span>實際總分 ' + (g.hs + g.as) + '（誤差 ' + T.num(gr.totalErr) + '）</span></div>';
        }
      }
      if (!opts.compact && !fin && p.f) {
        body += factorTable(g, p.f);
        var ns = notes(g, p);
        if (ns.length) body += '<ul class="gc-notes">' + ns.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>';
      }
    } else {
      body = '<div class="note-line">模型尚無這場的預測（兩隊歷史資料不足）。</div>';
    }
    var foot = '<div class="gc-foot"><span>' + (p ? esc(T.predKind(p)) + (p.at ? '（' + esc(T.whenTw(p.at)) + ' 更新）' : '') : '') +
      (fin && g.att ? ' · 觀眾 ' + Number(g.att).toLocaleString() + (g.cap ? ' / ' + Number(g.cap).toLocaleString() : '') : '') + '</span>' +
      '<a href="' + T.href('game/' + g.id) + '">比賽詳情 →</a></div>';
    return '<div class="gcard' + (live ? ' is-live' : '') + '">' + top + teams + body + foot + '</div>';
  };

  function otherHint(lg) {
    var o = lg === 'plg' ? 'tpbl' : 'plg';
    var L2 = T.L(o);
    if (!L2) return '';
    var today = T.today();
    var live = 0, cnt = 0, next = null;
    L2.games.forEach(function (g) {
      if (g.status === 'live') live++;
      if (g.d === today) cnt++;
      if (g.status === 'scheduled' && g.d > today && (!next || g.d < next)) next = g.d;
    });
    var label = live ? L2.name + ' 進行中 ' + live + ' 場' : (cnt ? L2.name + ' 今日 ' + cnt + ' 場' : (next ? L2.name + ' 下一個比賽日 ' + T.md(next) : L2.name));
    return '<button type="button" class="lg-hint" data-switch-lg="' + o + '"><span class="lg-dot" style="background:var(--' + o + ')"></span>' + esc(label) + ' →</button>';
  }

  function section(title, sub, cards) {
    if (!cards.length) return '';
    return '<div class="sec-hdr"><h2 class="sec-title sm">' + title + '</h2>' + (sub ? '<span class="sub">' + sub + '</span>' : '') + '</div>' +
      '<div class="games-grid">' + cards.join('') + '</div>';
  }

  T.pages.home = function (root, ctx) {
    var L = ctx.L;
    T.pageTitle = '今日賽事＆賽前預測';
    var today = T.today();
    var games = L.games.filter(function (g) { return g.st !== 'other'; });
    var live = games.filter(function (g) { return g.status === 'live'; });
    var todays = games.filter(function (g) { return g.d === today && g.status !== 'live'; });
    var remainingToday = todays.some(function (g) { return g.status === 'scheduled'; });
    var nextDate = null;
    games.forEach(function (g) { if (g.status === 'scheduled' && g.d > today && (!nextDate || g.d < nextDate)) nextDate = g.d; });
    var nextGames = nextDate && !remainingToday ? games.filter(function (g) { return g.d === nextDate && g.status === 'scheduled'; }) : [];
    var recentDate = null;
    games.forEach(function (g) { if (T.isFinal(g) && g.d < today && (!recentDate || g.d > recentDate)) recentDate = g.d; });
    var recent = recentDate ? games.filter(function (g) { return g.d === recentDate && T.isFinal(g); }) : [];
    var rec = recMap(L, L.current_season);

    var season = L.current_season;
    var seasonGames = games.filter(function (g) { return g.s === season && g.st !== 'pre'; });
    var graded = seasonGames.map(function (g) { return T.grade(g, T.pred(g.id)); }).filter(Boolean);
    var hits = graded.filter(function (x) { return x.hit; }).length;

    var html = '<div class="lg-hero"><h1>' + esc(L.name) + '</h1><span class="sub">' + esc(season || '') + ' 賽季</span><div class="hero-meta">' +
      (live.length ? '<span class="chip live"><i class="pulse"></i>進行中 ' + live.length + ' 場</span>' : '') +
      '<span class="chip">今日 ' + (live.length + todays.length) + ' 場</span>' +
      (nextDate ? '<span class="chip info">下一個比賽日 ' + esc(T.md(nextDate)) + '（' + esc(T.wd(nextDate)) + '）</span>' : '') +
      (graded.length ? '<span class="chip ok" data-tip="本季已完賽場次中，模型賽前看好的一方獲勝的比例（含回測與賽前凍結預測）">本季命中 ' + hits + '/' + graded.length + '</span>' : '') +
      '</div>' + otherHint(ctx.lg) + '</div>';
    if (L.banner) html += '<div class="banner">📢 ' + esc(L.banner) + '</div>';

    var body = '';
    body += section('🔴 進行中', '', live.map(function (g) { return T.gameCard(g, { rec: rec }); }));
    body += section('📅 今日賽事 · ' + esc(T.dayLabel(today)), '', todays.map(function (g) { return T.gameCard(g, { rec: rec }); }));
    if (nextGames.length) {
      body += section('📅 下一個比賽日 · ' + esc(T.dayLabel(nextDate)), '賽前預測會在每次更新時重算，開賽前最後一次更新的版本即凍結',
        nextGames.map(function (g) { return T.gameCard(g, { rec: rec }); }));
    }
    if (recent.length && recentDate !== today) {
      body += section('✅ 最近完賽 · ' + esc(T.dayLabel(recentDate)), '預測 vs 實際',
        recent.map(function (g) { return T.gameCard(g, { compact: true, rec: rec }); }));
    }
    if (!body) body = '<div class="empty-box">目前沒有排定的比賽。可到 <a href="' + T.href('schedule') + '">賽程比分</a> 查看過去賽季。</div>';
    html += body + '<div class="study-note">' + esc((T.snap.meta && T.snap.meta.study_note) || '本站為籃球數據研究與教學用途') + '</div>';
    root.innerHTML = html;
    root.querySelectorAll('[data-switch-lg]').forEach(function (b) {
      b.addEventListener('click', function () { T.setLeague(b.getAttribute('data-switch-lg')); });
    });
  };
})();
