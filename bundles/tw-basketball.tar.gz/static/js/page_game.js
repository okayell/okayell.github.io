/* Page: 🏟️ 比賽詳情 (#/game/<id>) — quarters, box score, team comparison, frozen prediction vs result. */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;

  function rowsToObj(rows, fields) {
    return (rows || []).map(function (r) { var o = {}; fields.forEach(function (f, i) { o[f] = r[i]; }); return o; });
  }
  function poss(t, o) {
    return ((t.fga + 0.44 * t.fta - t.oreb + t.tov) + (o.fga + 0.44 * o.fta - o.oreb + o.tov)) / 2;
  }

  function quarterTable(g) {
    if (!g.q || !g.q.length) return '';
    var heads = g.q.map(function (_, i) { return i < 4 ? 'Q' + (i + 1) : 'OT' + (i - 3); });
    var line = function (tid, idx, total) {
      return '<tr><td class="left">' + T.teamLink(tid) + '</td>' + g.q.map(function (q) { return '<td>' + q[idx] + '</td>'; }).join('') +
        '<td><b>' + (total === null ? '—' : total) + '</b></td></tr>';
    };
    return '<div class="tbl-wrap" style="margin-top:12px"><table class="tbl qtbl"><thead><tr><th class="left">球隊</th>' +
      heads.map(function (h) { return '<th>' + h + '</th>'; }).join('') + '<th>總分</th></tr></thead><tbody>' +
      line(g.a, 0, g.as) + line(g.h, 1, g.hs) + '</tbody></table></div>';
  }

  function compare(g, ta, th) {
    var pa = poss(ta, th), ph = pa;
    var items = [
      ['投籃命中率', T.pct(ta.fgm, ta.fga), T.pct(th.fgm, th.fga), ta.fga ? ta.fgm / ta.fga : 0, th.fga ? th.fgm / th.fga : 0],
      ['三分命中率', T.pct(ta.tpm, ta.tpa), T.pct(th.tpm, th.tpa), ta.tpa ? ta.tpm / ta.tpa : 0, th.tpa ? th.tpm / th.tpa : 0],
      ['罰球命中率', T.pct(ta.ftm, ta.fta), T.pct(th.ftm, th.fta), ta.fta ? ta.ftm / ta.fta : 0, th.fta ? th.ftm / th.fta : 0],
      ['有效命中率', T.pct(ta.fgm + 0.5 * ta.tpm, ta.fga), T.pct(th.fgm + 0.5 * th.tpm, th.fga), ta.fga ? (ta.fgm + 0.5 * ta.tpm) / ta.fga : 0, th.fga ? (th.fgm + 0.5 * th.tpm) / th.fga : 0],
      ['籃板', ta.reb, th.reb, ta.reb, th.reb], ['進攻籃板', ta.oreb, th.oreb, ta.oreb, th.oreb], ['助攻', ta.ast, th.ast, ta.ast, th.ast],
      ['抄截', ta.stl, th.stl, ta.stl, th.stl], ['阻攻', ta.blk, th.blk, ta.blk, th.blk], ['失誤', ta.tov, th.tov, ta.tov, th.tov],
      ['每百回合得分', T.num(100 * ta.pts / pa), T.num(100 * th.pts / ph), ta.pts, th.pts]
    ];
    var ca = T.team(g.a).color, ch = T.team(g.h).color;
    return '<div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">⚖️ 兩隊數據對比</h2><span class="sub">估計回合數 ' + T.num(pa) +
      '</span></div>' + items.map(function (it) {
        var tot = (it[3] + it[4]) || 1;
        return '<div class="cmp-row"><span class="va">' + it[1] + '</span><div class="cmp-bar away"><i style="width:' + (100 * it[3] / tot).toFixed(1) +
          '%;background:' + esc(ca) + '"></i></div><span class="lbl">' + it[0] + '</span><div class="cmp-bar"><i style="width:' + (100 * it[4] / tot).toFixed(1) +
          '%;background:' + esc(ch) + '"></i></div><span class="vh">' + it[2] + '</span></div>';
      }).join('') + '</div>';
  }

  function boxTable(tid, players, tot) {
    var starters = players.filter(function (p) { return p.starter; });
    var bench = players.filter(function (p) { return !p.starter; });
    var line = function (p) {
      return '<tr><td class="left sticky"><b>' + esc(p.name) + '</b>' + (p.number ? ' <span class="muted small">#' + esc(p.number) + '</span>' : '') +
        (p.pos ? ' <span class="muted small">' + esc(p.pos) + '</span>' : '') + '</td><td>' + T.fmtMin(p.sec) + '</td><td class="on">' + p.pts + '</td>' +
        '<td>' + p.fgm + '-' + p.fga + '</td><td>' + p.tpm + '-' + p.tpa + '</td><td>' + p.ftm + '-' + p.fta + '</td><td>' + p.oreb + '</td><td>' + p.dreb +
        '</td><td>' + p.reb + '</td><td>' + p.ast + '</td><td>' + p.stl + '</td><td>' + p.blk + '</td><td>' + p.tov + '</td><td>' + p.pf + '</td><td class="' +
        ((p.pm || 0) >= 0 ? 'pos' : 'neg') + '">' + (p.pm === null || p.pm === undefined ? '—' : T.signed(p.pm, 0)) + '</td></tr>';
    };
    var sep = function (t) { return '<tr class="sep"><td colspan="15">' + t + '</td></tr>'; };
    return '<div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">' + T.teamLink(tid, { full: true }) + '</h2></div>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="left sticky">球員</th><th>時間</th><th>得分</th><th>投籃</th><th>三分</th><th>罰球</th>' +
      '<th>進攻板</th><th>防守板</th><th>籃板</th><th>助攻</th><th>抄截</th><th>阻攻</th><th>失誤</th><th>犯規</th><th>+/-</th></tr></thead><tbody>' +
      (starters.length ? sep('先發') + starters.map(line).join('') : '') + (bench.length ? sep('替補') + bench.map(line).join('') : '') +
      (tot ? '<tr class="tot"><td class="left sticky">全隊</td><td></td><td>' + tot.pts + '</td><td>' + tot.fgm + '-' + tot.fga + '</td><td>' + tot.tpm + '-' + tot.tpa +
        '</td><td>' + tot.ftm + '-' + tot.fta + '</td><td>' + tot.oreb + '</td><td>' + tot.dreb + '</td><td>' + tot.reb + '</td><td>' + tot.ast + '</td><td>' + tot.stl +
        '</td><td>' + tot.blk + '</td><td>' + tot.tov + '</td><td>' + tot.pf + '</td><td></td></tr>' : '') + '</tbody></table></div></div>';
  }

  T.pages.game = function (root, ctx) {
    var L = ctx.L;
    var g = T.game(ctx.params[0]);
    if (!g) {
      root.innerHTML = '<div class="empty-box">找不到這場比賽（比賽編號只在同一個聯盟內有效）。<a href="' + T.href('schedule') + '">回到賽程</a></div>';
      return;
    }
    var A = T.team(g.a), H = T.team(g.h);
    T.pageTitle = A.short + ' vs ' + H.short;
    var p = T.pred(g.id);
    var fin = T.isFinal(g), live = g.status === 'live';
    var html = '<div class="card"><div class="gc-top" style="margin-bottom:10px"><span class="chip stage">' + esc(T.stageLabel(g.st)) + (g.c ? ' ' + esc(g.c) : '') +
      '</span><span>' + esc(g.s) + ' 賽季</span><span>· ' + esc(T.dayLabel(g.d)) + ' ' + esc(g.t) + '</span>' + (g.v ? '<span>· ' + esc(g.v) + '</span>' : '') +
      (g.att ? '<span>· 觀眾 ' + Number(g.att).toLocaleString() + (g.cap ? ' / ' + Number(g.cap).toLocaleString() : '') + '</span>' : '') +
      '<span class="sp"></span>' + T.statusChip(g) + '</div>' +
      '<div class="gp-hero"><a class="gp-team" href="' + T.href('team/' + g.a) + '">' + T.logo(g.a, 56) + '<span class="nm">' + esc(A.name) + '</span><span class="ha">客隊</span></a>' +
      '<div class="gp-score">' + ((fin || live) && g.hs !== null ? '<span class="' + (fin && g.as < g.hs ? 'muted' : '') + '">' + g.as + '</span> : <span class="' +
        (fin && g.hs < g.as ? 'muted' : '') + '">' + g.hs + '</span>' : '<span class="gc-vs">VS</span>') + '</div>' +
      '<a class="gp-team" href="' + T.href('team/' + g.h) + '">' + T.logo(g.h, 56) + '<span class="nm">' + esc(H.name) + '</span><span class="ha">主隊</span></a></div>' +
      quarterTable(g) + '</div>';

    // prediction vs result
    if (g.st !== 'pre' && p) {
      var gr = T.grade(g, p);
      var favH = p.m >= 0;
      html += '<div class="card"><div class="sec-hdr" style="margin-top:0"><h2 class="sec-title sm">🔮 ' + esc(T.predKind(p)) + (fin ? ' vs 實際結果' : '') + '</h2>' +
        (p.at ? '<span class="sub">預測時間 ' + esc(T.whenTw(p.at)) + '</span>' : '') + '</div>' + T.probBar(p.p, g) +
        '<div class="gc-pred" style="margin-top:8px"><div><div class="k">預測比分（客：主）</div><div class="v">' + T.num(p.ap) + ' : ' + T.num(p.hp) + '</div></div>' +
        '<div><div class="k">預測分差</div><div class="v">' + esc(T.team(favH ? g.h : g.a).short) + ' +' + T.num(Math.abs(p.m)) + '</div></div>' +
        '<div><div class="k">預測總得分</div><div class="v">' + T.num(p.tot) + '</div></div></div>' +
        (gr ? '<div class="gc-grade" style="margin-top:8px"><span class="' + (gr.hit ? 'hit' : 'miss') + '">' + (gr.hit ? '✔ 命中勝方' : '✘ 未命中勝方') + '</span>' +
          '<span>實際比分 ' + g.as + ' : ' + g.hs + '</span><span>分差誤差 ' + T.num(gr.marginErr) + '</span><span>總分誤差 ' + T.num(gr.totalErr) + '</span></div>' : '') +
        (p.f ? '<div style="margin-top:10px">' + T.factorTable(g, p.f) + '</div>' : '') +
        (p.kind === 'backtest' ? '<div class="note-line">這是用「比賽前已知的資料」逐場往前推算的回測預測，不是當時即時發布的版本。</div>' : '') + '</div>';
    } else if (g.st === 'pre') {
      html += '<div class="card note-line">熱身賽不列入模型與戰績計算。</div>';
    }

    // box score
    var box = (L.box || {})[g.id];
    var F = (T.snap.meta && T.snap.meta.box_fields) || {};
    if (box && box.t && box.t.length === 2) {
      var teams = rowsToObj(box.t, F.team || []);
      var players = rowsToObj(box.p, F.player || []);
      var ta = teams.filter(function (t) { return t.team_id === g.a; })[0];
      var th = teams.filter(function (t) { return t.team_id === g.h; })[0];
      if (ta && th) html += compare(g, ta, th);
      html += boxTable(g.a, players.filter(function (x) { return x.team_id === g.a; }), ta) +
        boxTable(g.h, players.filter(function (x) { return x.team_id === g.h; }), th);
    } else if (fin) {
      html += '<div class="card note-line">' + ((L.box_seasons || []).indexOf(g.s) >= 0 ? '這場比賽的逐場數據還沒抓到，下次更新會補上。' :
        '本站只保留最近兩季的逐場數據，較早的比賽只有比分。') + '</div>';
    } else if (live) {
      html += '<div class="card note-line">比賽進行中，逐場數據會在完賽後更新；即時比分每 2 分鐘更新（本機版）。</div>';
    }
    html += '<div style="margin-top:12px"><a href="' + T.href('schedule', { season: g.s }) + '">← 回到 ' + esc(g.s) + ' 賽程</a></div>';
    root.innerHTML = html;
  };
})();
