/* Page: 💬 意見回饋 (#/feedback) — 3 fields (類型／標題／內容); local server mails, static uses CampusNav. */
(function () {
  'use strict';
  var T = window.TWB;
  var esc = T.esc;
  var TARGET_EMAIL = 'okayell@hotmail.com';
  var TOOL = '台籃戰情室';
  var LS_KEY = 'twb.feedback.v1';
  var KINDS = [
    { id: 'feature', label: '✨ 功能許願' },
    { id: 'bug', label: '🐞 問題回報' },
    { id: 'ux', label: '🎨 介面建議' },
    { id: 'other', label: '💬 其他意見' }
  ];
  var items = null, selKind = 'feature', sending = false, statusHtml = '';

  function loadLocal() {
    try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); } catch (e) { return []; }
  }
  function saveLocal(list) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(list.slice(0, 50))); } catch (e) { /* ignore */ }
  }
  function fallback(kindLabel, title, desc, note) {
    if (window.CampusNav && window.CampusNav.fallbackHtml) {
      return window.CampusNav.fallbackHtml({ email: TARGET_EMAIL, tool: TOOL, kindLabel: kindLabel, title: title, description: desc, note: note });
    }
    var subject = '[' + TOOL + ' 意見回饋] ' + kindLabel + ' — ' + title;
    var href = 'mailto:' + TARGET_EMAIL + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(desc);
    return '<div class="card banner">' + esc(note || '請改用郵件寄送：') + ' <a href="' + esc(href) + '">📩 寄信給站長</a></div>';
  }
  function sendStatic(item) {
    if (window.CampusNav && window.CampusNav.sendStaticFeedback) {
      return window.CampusNav.sendStaticFeedback({ email: TARGET_EMAIL, tool: TOOL, kindLabel: item.kind_label, title: item.title,
        description: item.description, createdAt: item.created_at });
    }
    return Promise.resolve({ sent: false });
  }

  T.pages.feedback = function (root) {
    T.pageTitle = '意見回饋';
    if (items === null) {
      items = loadLocal();
      if (!T.isStatic) {
        T.apiGet('/api/feedback').then(function (res) {
          if (res && Array.isArray(res.items)) {
            items = res.items;
            if (T.route === 'feedback') T.render(true);
          }
        }).catch(function () { /* keep local history */ });
      }
    }
    root.innerHTML = '<div class="sec-hdr"><div><h1 class="sec-title">💬 意見回饋</h1><div class="sub">問題回報、功能許願或任何建議都歡迎，送出後會寄到站長信箱。</div></div></div>' +
      '<div class="fb-layout"><form class="card fb-form" id="fbForm" novalidate>' +
      '<div><label>類型</label><div class="fb-type-pills">' + KINDS.map(function (k) {
        return '<button type="button" class="fb-type-pill' + (k.id === selKind ? ' active' : '') + '" data-kind="' + k.id + '">' + k.label + '</button>';
      }).join('') + '</div></div>' +
      '<div><label for="fbTitle">標題</label><input class="inp" id="fbTitle" maxlength="150" placeholder="一句話說明建議或問題" style="width:100%"></div>' +
      '<div><label for="fbDesc">內容</label><textarea class="inp" id="fbDesc" rows="6" maxlength="4000" placeholder="詳細描述情境、希望增加的數據，或遇到的異常…"></textarea></div>' +
      '<div id="fbStatus">' + statusHtml + '</div>' +
      '<div style="display:flex;justify-content:flex-end"><button type="submit" class="btn btn-primary" id="fbSubmit">📨 送出</button></div></form>' +
      '<div class="card"><h2 class="sec-title sm" style="margin-bottom:8px">🗂️ 已送出的回饋（' + items.length + '）</h2><div class="fb-list">' +
      (items.length ? items.map(function (it) {
        return '<div class="fb-item"><div style="display:flex;justify-content:space-between;gap:8px"><span class="chip info">' + esc(it.kind_label || it.kind) +
          '</span><span class="muted small">' + esc(it.created_at || '') + '</span></div><div style="font-weight:800;margin-top:4px">' + esc(it.title) + '</div>' +
          '<div class="small" style="white-space:pre-wrap;color:#334155;margin-top:2px">' + esc(it.description) + '</div></div>';
      }).join('') : '<div class="muted small">還沒有回饋紀錄。</div>') + '</div></div></div>';

    var pills = root.querySelector('.fb-type-pills');
    pills.addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-kind]');
      if (!b) return;
      selKind = b.getAttribute('data-kind');
      pills.querySelectorAll('[data-kind]').forEach(function (x) { x.classList.toggle('active', x === b); });
    });
    var titleInp = root.querySelector('#fbTitle');
    titleInp.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' && !T.isEnterSend(ev)) ev.preventDefault();
    });
    root.querySelector('#fbForm').addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (sending) return;
      var title = titleInp.value.trim();
      var desc = root.querySelector('#fbDesc').value.trim();
      if (!title || !desc) { T.toast('⚠️ 請填寫標題與內容'); return; }
      var kind = KINDS.filter(function (k) { return k.id === selKind; })[0] || KINDS[0];
      sending = true;
      var btn = root.querySelector('#fbSubmit');
      btn.disabled = true;
      btn.textContent = '⏳ 送出中…';
      var done = function (html) {
        sending = false;
        statusHtml = html;
        T.render(true);
      };
      if (!T.isStatic) {
        T.apiPost('/api/feedback', { kind: selKind, title: title, description: desc }).then(function (res) {
          items = res.items || [res.item].concat(items);
          saveLocal(items);
          var ok = !res.item || res.item.mail_sent !== false;
          if (ok) T.toast('✅ 感謝回饋！已寄到站長信箱');
          done(ok ? '<div class="card ok-box">✅ 已收到並寄出通知信，感謝你的建議！</div>' :
            fallback(kind.label, title, desc, '✅ 回饋已存到伺服器；自動寄信暫時忙碌，請任選下方一種方式一鍵寄給站長：'));
        }, function (e) {
          done(fallback(kind.label, title, desc, '⚠️ 伺服器暫時無法寄信（' + (e.message || '連線忙碌') + '），請任選下方一種方式一鍵寄給站長：'));
        });
        return;
      }
      var item = { id: 'FB-' + Date.now().toString(36).toUpperCase(), kind: selKind, kind_label: kind.label, title: title, description: desc,
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ') };
      sendStatic(item).then(function (r) {
        items = [item].concat(items);
        saveLocal(items);
        done(r && r.sent ? '<div class="card ok-box">✅ 感謝回饋！已寄到站長信箱。</div>' : fallback(kind.label, title, desc));
      }, function () {
        items = [item].concat(items);
        saveLocal(items);
        done(fallback(kind.label, title, desc));
      });
    });
  };
})();
