#!/usr/bin/env python3
"""P. LEAGUE+ scraper + pure parsers (server-rendered HTML at https://pleagueofficial.com).

Pages used:
  /schedule-regular-season[/YYYY-YY], /schedule-playoffs/YYYY-YY, /schedule-finals/YYYY-YY
      -> one `<!--單一場次-->` block per game (date, teams, scores, code, venue, attendance, /game/<id>)
  /api/boxscore.preciser.php?id=<gid>&away_tab=total&home_tab=total  (JSON used by the game page)
  /game/<gid>   -> status badge (已完賽 / LIVE / 尚未開始) for today's games
  /standings/YYYY-YY -> official team colours (--team-color)
"""
from __future__ import annotations

import re
from typing import Any

import config
import net

STAGE_PATH = {
    'pre': 'schedule-pre-season', 'regular': 'schedule-regular-season',
    'playoffs': 'schedule-playoffs', 'finals': 'schedule-finals',
}
_BLOCK_RE = re.compile(r'<!--單一場次-->(.*?)<!--/單一場次-->', re.S)


def _int(v: Any) -> int | None:
  try:
    if v is None:
      return None
    s = str(v).replace(',', '').strip()
    if s in ('', '-'):
      return None
    return int(float(s))
  except (TypeError, ValueError):
    return None


def _txt(s: str | None) -> str:
  return net.clean_str(s)


# --------------------------------------------------------------------------- season navigation
def parse_season_nav(html: str) -> tuple[list[str], str | None]:
  """All regular-season keys linked from the schedule navigation + the season shown on this page."""
  seasons = set(re.findall(r'href="/schedule-regular-season/(\d{4}-\d{2})"', html))
  cur = None
  m = re.search(r'<title>\s*(\d{4}-\d{2})-', html)
  if m:
    cur = m.group(1)
  else:
    m = re.search(r'href="/schedule-(?:pre-season|playoffs|finals)/(\d{4}-\d{2})"', html)
    cur = m.group(1) if m else None
  if cur:
    seasons.add(cur)
  return sorted(seasons), cur


# --------------------------------------------------------------------------- schedule rows
def _side(block: str, start: str, end: str) -> dict[str, str]:
  i, j = block.find(start), block.find(end)
  seg = block[i:j] if i >= 0 and j > i else ''
  short = re.search(r'<span class="PC_only fs14">([^<]+)</span>', seg)
  en = re.search(r'<span class="fs12 PC_only\s*">([^<]+)</span>', seg)
  logo = re.search(r'<img[^>]+src="([^"]+)"', seg)
  logo_url = logo.group(1) if logo else ''
  if logo_url.startswith('//'):
    logo_url = 'https:' + logo_url
  tid = re.search(r'logo_(\d+)_', logo_url)
  return {'short': _txt(short.group(1)) if short else '', 'en': _txt(en.group(1)) if en else '',
          'logo': logo_url, 'logo_tid': tid.group(1) if tid else ''}


def parse_schedule(html: str, season: str, stage: str) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
  games: list[dict[str, Any]] = []
  teams: dict[str, dict[str, Any]] = {}
  for block in _BLOCK_RE.findall(html or ''):
    cls_m = re.search(r'class="([^"]*match_row[^"]*)"', block)
    gid_m = re.search(r'href="/game/(\d+)"', block)
    if not cls_m or not gid_m:
      continue
    cls = cls_m.group(1).split()
    ym = next((c[2:] for c in cls if re.fullmatch(r'd-\d{4}-\d{2}', c)), '')
    home_id = next((c[len('team-home-'):] for c in cls if c.startswith('team-home-')), '')
    tids = [c[len('team-'):] for c in cls if re.fullmatch(r'team-\d+', c)]
    md = re.search(r'<h5 class="fs16[^"]*">\s*(\d{1,2})/(\d{1,2})\s*</h5>', block)
    tm = re.search(r'<h6 class="fs12">\s*(\d{1,2}:\d{2})\s*</h6>', block)
    if not md or not ym:
      continue
    year = int(ym[:4])
    month, day = int(md.group(1)), int(md.group(2))
    if int(ym[5:7]) != month:  # class month wins on mismatch (should not happen)
      month = int(ym[5:7])
    date = f'{year:04d}-{month:02d}-{day:02d}'
    away, home = _side(block, '<!--AWAY-->', '<!--INFO-->'), _side(block, '<!--HOME-->', '<!--PANEL-->')
    if not home_id:
      home_id = home['logo_tid']
    away_id = next((t for t in tids if t != home_id), away['logo_tid'])
    if not home_id or not away_id:
      continue
    scores = re.findall(r'<h6 class="PC_only\s+ff8bit fs20">\s*([^<]*?)\s*</h6>', block)
    a_sc = _int(scores[0]) if len(scores) > 0 else None
    h_sc = _int(scores[1]) if len(scores) > 1 else None
    code = re.search(r'<h5 class="fs14 mb-2">\s*(.+?)\s*</h5>', block, re.S)
    venue = re.search(r'<h5 class="fs12 mb-0">\s*([^<]+?)\s*</h5>', block)
    att = re.search(r'seat\.svg[^>]*>\s*([\d,]+)\s*/\s*([\d,]+)', block)
    played = bool((a_sc or 0) or (h_sc or 0))
    if 'before-today' in cls:
      # An unplayed past playoff game = the series ended early (not a postponement).
      status = 'final' if played else ('cancelled' if stage in ('playoffs', 'finals') else 'postponed')
    else:
      status = 'live' if played else 'scheduled'  # today's games are refined via the game page
    attendance = _int(att.group(1)) if att else None
    capacity = _int(att.group(2)) if att else None
    tip = tm.group(1) if tm else ''
    if tip and len(tip) == 4:
      tip = '0' + tip
    games.append({
        'league': 'plg', 'game_id': gid_m.group(1), 'season': season, 'stage': stage,
        'code': _txt(code.group(1)) if code else '', 'game_date': date, 'game_time': tip,
        'tip_ts': f'{date}T{tip or "00:00"}:00+08:00', 'home_id': home_id, 'away_id': away_id,
        'home_score': h_sc if played else None, 'away_score': a_sc if played else None,
        'status': status, 'venue': _txt(venue.group(1)) if venue else '',
        'attendance': attendance or None, 'capacity': capacity or None,
    })
    for tid, side in ((home_id, home), (away_id, away)):
      teams[tid] = {'league': 'plg', 'team_id': tid, 'short': side['short'] or tid,
                    'name': side['short'] or tid, 'en': side['en'], 'logo': side['logo']}
  return games, teams


# --------------------------------------------------------------------------- game page
def parse_game_page(html: str) -> dict[str, Any]:
  out: dict[str, Any] = {'status': None, 'home_name': '', 'away_name': ''}
  m = re.search(r'<span class="badge[^"]*">\s*([^<]+?)\s*</span>', html or '')
  badge = (m.group(1) if m else '').strip()
  if '完賽' in badge:
    out['status'] = 'final'
  elif badge.upper().startswith('LIVE') or '進行' in badge:
    out['status'] = 'live'
  elif '尚未' in badge or '延' in badge:
    out['status'] = 'scheduled' if '尚未' in badge else 'postponed'
  out['badge'] = badge
  t = re.search(r'<title>\s*(\S+)\s+(.+?)\s+VS\s+(.+?)\s*[│|]', html or '')
  if t:  # "<stage> <home> VS <away>│P. LEAGUE+"
    out['stage_name'], out['home_name'], out['away_name'] = t.group(1), _txt(t.group(2)), _txt(t.group(3))
  return out


# --------------------------------------------------------------------------- box score JSON
def _sec(mins: Any) -> int | None:
  m = re.fullmatch(r'\s*(\d+):(\d{2})\s*', str(mins or ''))
  return int(m.group(1)) * 60 + int(m.group(2)) if m else None


def _box_counts(p: dict[str, Any]) -> dict[str, int]:
  two_m, two_a = _int(p.get('two_m')) or 0, _int(p.get('two')) or 0
  tpm, tpa = _int(p.get('trey_m')) or 0, _int(p.get('trey')) or 0
  return {
      'pts': _int(p.get('points')) or 0, 'fgm': two_m + tpm, 'fga': two_a + tpa, 'tpm': tpm, 'tpa': tpa,
      'ftm': _int(p.get('ft_m')) or 0, 'fta': _int(p.get('ft')) or 0,
      'oreb': _int(p.get('reb_o')) or 0, 'dreb': _int(p.get('reb_d')) or 0, 'reb': _int(p.get('reb')) or 0,
      'ast': _int(p.get('ast')) or 0, 'stl': _int(p.get('stl')) or 0, 'blk': _int(p.get('blk')) or 0,
      'tov': _int(p.get('turnover')) or 0, 'pf': _int(p.get('pfoul')) or 0,
  }


def parse_box(payload: dict[str, Any], game_id: str, home_id: str,
              away_id: str) -> tuple[list[dict], list[dict], list[list[int]], dict[str, Any]]:
  """Box JSON -> (team_rows, player_rows, quarters [[away, home], …], scores {home, away})."""
  d = (payload or {}).get('data') or {}
  quarters: list[list[int]] = []
  for q in ('q1', 'q2', 'q3', 'q4', 'ot1', 'ot2', 'ot3'):
    a, h = _int(d.get(f'{q}_away')), _int(d.get(f'{q}_home'))
    if a is None and h is None:
      continue
    quarters.append([a or 0, h or 0])
  team_rows: list[dict] = []
  player_rows: list[dict] = []
  for side, tid, is_home in (('home', home_id, 1), ('away', away_id, 0)):
    plist = d.get(side) or []
    played = []
    for p in plist:
      sec = _sec(p.get('mins'))
      if sec is None:  # DNP
        continue
      row = {'league': 'plg', 'game_id': game_id, 'team_id': tid, 'player_id': str(p.get('player_id') or ''),
             'name': _txt(p.get('name')), 'number': str(p.get('jersey') or ''), 'pos': '',
             'starter': 1 if str(p.get('starter') or '').strip() else 0, 'sec': sec,
             'pm': _int(p.get('positive')), 'eff': _int(p.get('eff'))}
      row.update(_box_counts(p))
      if row['player_id']:
        played.append(row)
    player_rows.extend(played)
    tot = d.get(f'{side}_total') or {}
    if played or _int(tot.get('points')):
      trow = {'league': 'plg', 'game_id': game_id, 'team_id': tid, 'is_home': is_home}
      trow.update(_box_counts(tot))
      if not trow['pts']:
        trow['pts'] = _int(d.get(f'score_{side}')) or sum(r['pts'] for r in played)
      team_rows.append(trow)
  scores = {'home': _int(d.get('score_home')), 'away': _int(d.get('score_away'))}
  return team_rows, player_rows, quarters, scores


def parse_standings_colors(html: str) -> dict[str, str]:
  out = {}
  for m in re.finditer(r'--team-color:\s*(#[0-9a-fA-F]{3,8})[^>]*>.*?href="/team/(\d+)"', html or '', re.S):
    out.setdefault(m.group(2), m.group(1).lower())
  return out


def parse_team_full_names(html: str) -> list[str]:
  """Full team names from the /stat-player team filter (e.g. 臺北富邦勇士, 洋基工程方舟)."""
  m = re.search(r'<select[^>]*id="team-name"[^>]*>(.*?)</select>', html or '', re.S)
  if not m:
    return []
  return [_txt(v) for v in re.findall(r'<option value="([^"]+)"', m.group(1)) if _txt(v)]


def fetch_stat_player() -> str:
  return net.fetch_text(f'{config.PLG_SITE}/stat-player', timeout=30)


# --------------------------------------------------------------------------- fetchers
def fetch_schedule(season: str | None, stage: str = 'regular') -> str:
  path = STAGE_PATH[stage]
  url = f'{config.PLG_SITE}/{path}' + (f'/{season}' if season else '')
  return net.fetch_text(url, timeout=30)


def fetch_box(game_id: str) -> dict[str, Any]:
  return net.fetch_json(
      f'{config.PLG_SITE}/api/boxscore.preciser.php?id={game_id}&away_tab=total&home_tab=total',
      headers={'X-Requested-With': 'XMLHttpRequest', 'Referer': f'{config.PLG_SITE}/game/{game_id}'})


def fetch_game_page(game_id: str) -> str:
  return net.fetch_text(f'{config.PLG_SITE}/game/{game_id}', timeout=30)


def fetch_standings(season: str) -> str:
  return net.fetch_text(f'{config.PLG_SITE}/standings/{season}', timeout=30)
