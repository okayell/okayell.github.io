"""Data source adapters for 台籃戰情室 (P. LEAGUE+ HTML scraper, TPBL JSON API)."""
