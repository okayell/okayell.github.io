#!/usr/bin/env python3
"""TPBL JSON API client + pure parsers (https://api.tpbl.basketball/api)."""
from __future__ import annotations

import re
from typing import Any

import config
import net

# Short display names keyed by the API's meta.alt_name (falls back to the full name).
SHORT_BY_ALT = {
    'dea': '特攻', 'aquas': '海神', 'dreamers': '夢想家', 'kings': '國王', 'mars': '戰神',
    'leopards': '雲豹', 'lioneers': '攻城獅',
}
STAGE_BY_NAME = {
    '熱身賽': 'pre', '例行賽': 'regular', '季後挑戰賽': 'playin', '季後賽': 'playoffs',
    '冠軍賽': 'finals', '總冠軍賽': 'finals',
}
POS_ABBR = {'PointGuard': 'PG', 'ShootingGuard': 'SG', 'SmallForward': 'SF', 'PowerForward': 'PF', 'Center': 'C'}


def _int(v: Any) -> int | None:
  try:
    if v is None or v == '':
      return None
    return int(float(v))
  except (TypeError, ValueError):
    return None


def season_key(name: str, started_at: str = '') -> str:
  m = re.search(r'(\d{4})\s*[-–/]\s*(\d{2,4})', name or '')
  if m:
    return f'{m.group(1)}-{m.group(2)[-2:]}'
  y = (started_at or '')[:4]
  if y.isdigit():
    return f'{y}-{str(int(y) + 1)[-2:]}'
  return name or '?'


def pos_label(raw: str | None) -> str:
  if not raw:
    return ''
  parts = [p for p in str(raw).split('And') if p]
  return '/'.join(POS_ABBR.get(p, p) for p in parts)


# --------------------------------------------------------------------------- parsers
def parse_seasons(data: list[dict[str, Any]]) -> list[dict[str, Any]]:
  out = []
  for s in data or []:
    out.append({
        'league': 'tpbl',
        'season': season_key(s.get('name', ''), s.get('started_at', '')),
        'name': s.get('name') or '',
        'src_id': str(s.get('id')),
        'status': str(s.get('status') or ''),
        'start_date': (s.get('started_at') or '')[:10],
        'end_date': (s.get('ended_at') or '')[:10],
        'ord': _int(s.get('id')) or 0,
    })
  return out


def parse_divisions(data: list[dict[str, Any]]) -> dict[str, str]:
  """division_id -> stage ('pre' | 'regular' | 'playin' | 'playoffs' | 'finals' | 'other')."""
  out = {}
  for d in data or []:
    name = str(d.get('name') or '').strip()
    out[str(d.get('id'))] = STAGE_BY_NAME.get(name, 'other')
  return out


def team_from(t: dict[str, Any]) -> dict[str, Any]:
  meta = t.get('meta') or {}
  name = str(t.get('name') or '')
  # meta.logo points at a retired path (HTTP 403); real logos come from parse_logo_map().
  return {
      'league': 'tpbl', 'team_id': str(t.get('id')), 'name': name,
      'short': SHORT_BY_ALT.get(str(meta.get('alt_name') or '').lower(), name),
      'en': str(meta.get('alt_name') or '').lower(), 'logo': None,
  }


def parse_logo_map(html: str) -> dict[str, str]:
  """alt_name -> current hashed logo URL from the tpbl.basketball home page (Nuxt assets)."""
  out: dict[str, str] = {}
  for m in re.finditer(r'https://assets\.tpbl\.basketball/frontend/_nuxt/([a-z]+)\.[A-Za-z0-9_-]+\.webp', html or ''):
    if m.group(1) in SHORT_BY_ALT:
      out.setdefault(m.group(1), m.group(0))
  return out


def fetch_home() -> str:
  return net.fetch_text('https://tpbl.basketball/', timeout=30)


def game_status(g: dict[str, Any]) -> str:
  st = str(g.get('status') or '').upper()
  if g.get('is_live') or st == 'IN_PROGRESS':
    return 'live'
  if st == 'COMPLETED':
    return 'final'
  if st == 'NOT_STARTED':
    return 'scheduled'
  return 'postponed'


def parse_games(data: list[dict[str, Any]], season: str,
                div_map: dict[str, str]) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
  games: list[dict[str, Any]] = []
  teams: dict[str, dict[str, Any]] = {}
  for g in data or []:
    h, a = g.get('home_team') or {}, g.get('away_team') or {}
    if not h.get('id') or not a.get('id'):
      continue
    for t in (h, a):
      teams[str(t['id'])] = team_from(t)
    status = game_status(g)
    has_score = status in ('live', 'final')
    date = str(g.get('game_date') or '')[:10]
    tm = str(g.get('game_time') or '')[:5]
    meta = g.get('meta') or {}
    games.append({
        'league': 'tpbl', 'game_id': str(g.get('id')), 'season': season,
        'stage': div_map.get(str(g.get('division_id')), 'other'),
        'code': str(g.get('code') or ''), 'game_date': date, 'game_time': tm,
        'tip_ts': f'{date}T{tm or "00:00"}:00+08:00' if date else None,
        'home_id': str(h['id']), 'away_id': str(a['id']),
        'home_score': _int(h.get('won_score')) if has_score else None,
        'away_score': _int(a.get('won_score')) if has_score else None,
        'status': status, 'venue': str(g.get('venue') or ''),
        'attendance': _int(meta.get('visitors')), 'capacity': None,
    })
  return games, teams


_TEAM_KEYS = {
    'fgm': 'field_goals_made', 'fga': 'field_goals_attempted', 'tpm': 'three_pointers_made',
    'tpa': 'three_pointers_attempted', 'ftm': 'free_throws_made', 'fta': 'free_throws_attempted',
    'oreb': 'offensive_rebounds', 'dreb': 'defensive_rebounds', 'reb': 'rebounds', 'ast': 'assists',
    'stl': 'steals', 'blk': 'blocks', 'tov': 'turnovers', 'pf': 'fouls',
}


def parse_box(data: dict[str, Any], game_id: str) -> tuple[list[dict], list[dict], list[list[int]]]:
  """/games/{id}/stats -> (team_rows, player_rows, quarters [[away, home], …])."""
  team_rows: list[dict] = []
  player_rows: list[dict] = []
  rounds: dict[str, dict[int, int]] = {}
  for side, is_home in (('home_team', 1), ('away_team', 0)):
    t = (data or {}).get(side) or {}
    tid = str(t.get('id') or '')
    if not tid:
      continue
    tot = (t.get('teams') or {}).get('total') or {}
    row = {'league': 'tpbl', 'game_id': game_id, 'team_id': tid, 'is_home': is_home,
           'pts': _int(tot.get('won_score'))}
    for k, src in _TEAM_KEYS.items():
      row[k] = _int(tot.get(src))
    team_rows.append(row)
    rr = {}
    for rk, rv in ((t.get('teams') or {}).get('rounds') or {}).items():
      try:
        rr[int(rk)] = _int((rv or {}).get('won_score')) or 0
      except ValueError:
        continue
    rounds['home' if is_home else 'away'] = rr
    for p in ((t.get('players') or {}).get('total') or {}).values():
      if 'score' not in p:  # did not play
        continue
      prow = {
          'league': 'tpbl', 'game_id': game_id, 'team_id': tid, 'player_id': str(p.get('id')),
          'name': str(p.get('name') or ''), 'number': str(p.get('number') or ''),
          'pos': pos_label(p.get('positions')), 'starter': 1 if p.get('is_starting') else 0,
          'sec': _int(p.get('time_on_court')) or 0, 'pts': _int(p.get('score')) or 0,
          'pm': _int(p.get('plus_minus')),
          'eff': _int(p.get('efficiency') if p.get('efficiency') is not None else p.get('pir')),
      }
      for k, src in _TEAM_KEYS.items():
        prow[k] = _int(p.get(src)) or 0
      player_rows.append(prow)
  quarters: list[list[int]] = []
  hr, ar = rounds.get('home') or {}, rounds.get('away') or {}
  for r in sorted(set(hr) | set(ar)):
    quarters.append([ar.get(r, 0), hr.get(r, 0)])
  return team_rows, player_rows, quarters


# --------------------------------------------------------------------------- fetchers
def fetch_seasons() -> list[dict[str, Any]]:
  return net.fetch_json(f'{config.TPBL_API}/seasons')


def fetch_divisions(season_src_id: str) -> list[dict[str, Any]]:
  return net.fetch_json(f'{config.TPBL_API}/events/{season_src_id}/divisions')


def fetch_games(season_src_id: str) -> list[dict[str, Any]]:
  return net.fetch_json(f'{config.TPBL_API}/seasons/{season_src_id}/games', timeout=30)


def fetch_box(game_id: str) -> dict[str, Any]:
  return net.fetch_json(f'{config.TPBL_API}/games/{game_id}/stats', timeout=40)
