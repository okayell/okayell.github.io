#!/usr/bin/env python3
"""Configuration constants for 台籃戰情室 (Taiwan Hoops War Room: P. LEAGUE+ & TPBL)."""
from __future__ import annotations

import datetime as dt
import os
from zoneinfo import ZoneInfo

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get('TWB_DATA_DIR', os.path.join(ROOT_DIR, 'data'))
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')
DB_PATH = os.path.join(DATA_DIR, 'tw_basketball.db')
SNAPSHOT_JSON = os.path.join(DATA_DIR, 'snapshot.json')
LOCK_FILE = os.path.join(DATA_DIR, 'updater.lock')
STATE_JSON = os.path.join(DATA_DIR, 'sync_state.json')

TOOL_NAME = '台籃戰情室'
TOOL_EN = 'Taiwan Hoops War Room'
SERVICE_SLUG = 'tw-basketball'
CAMPUS_ID = 'twbasket'
BACKEND_PORT = 8942
PROXY_PORT = 8943

TZ_TW = ZoneInfo('Asia/Taipei')
TZ_UTC = dt.timezone.utc

STUDY_NOTE = '本站為籃球數據研究與教學用途'

# --------------------------------------------------------------------------- leagues
LEAGUES = ('plg', 'tpbl')
LEAGUE_META = {
    'plg': {
        'key': 'plg', 'name': 'P. LEAGUE+', 'short': 'P+', 'full_name': 'P. LEAGUE+ 職業籃球聯盟',
        'site': 'https://pleagueofficial.com', 'accent': '#1e3a8a', 'badge': '#b8935a',
    },
    'tpbl': {
        'key': 'tpbl', 'name': 'TPBL', 'short': 'TPBL', 'full_name': '台灣職業籃球大聯盟 TPBL',
        'site': 'https://tpbl.basketball', 'accent': '#c8102e', 'badge': '#111827',
    },
}
DEFAULT_LEAGUE = 'tpbl'

# First season used for Elo history (older seasons are not fetched).
PLG_FIRST_SEASON = '2022-23'
TPBL_API = 'https://api.tpbl.basketball/api'
PLG_SITE = 'https://pleagueofficial.com'
# Per-game box scores are fetched only for the latest N seasons of each league
# (older seasons use the cheap schedule pages for final scores / Elo).
BOX_SEASONS = 2

# Polite per-host minimum interval between requests (seconds).
HOST_INTERVAL = {
    'pleagueofficial.com': 1.2,
    'api.tpbl.basketball': 0.35,
}
DEFAULT_INTERVAL = 0.5

# --------------------------------------------------------------------------- schedule
# Full sync times (Asia/Taipei). They match the campus GitHub Actions windows.
SYNC_TIMES = ('07:40', '12:30', '18:30', '23:03')
# While a game is in progress the backend refreshes live scores every N minutes.
LIVE_REFRESH_MIN = 2
# A game counts as "maybe live" from tip-off until this many hours later.
LIVE_WINDOW_HOURS = 4
# Structured schedule for the 「🔄 資料更新頻率」 strip (Pattern 205): /api/meta + static build.
SCHEDULE_SLOTS = {
    'sync': list(SYNC_TIMES),
    'live_every_min': LIVE_REFRESH_MIN,
    'notes': {
        '07:40': '補齊前一晚完賽的比分、逐場數據與模型檢討',
        '12:30': '午後場次開打前更新賽前預測',
        '18:30': '下午場完賽結果、晚場賽前預測',
        '23:03': '晚場完賽結果與下一個比賽日的賽前預測',
    },
}

# --------------------------------------------------------------------------- model
# Default Elo parameters (the self-tuner replaces them per league; see model_engine).
MODEL_DEFAULTS = {
    'k': 20.0,          # Elo K factor
    'hca': 40.0,        # home-court advantage in Elo points
    'regress': 0.33,    # season carry-over: regress this share toward the league mean
    'b2b': 15.0,        # back-to-back penalty in Elo points
    'epp': 28.0,        # Elo points per point of margin
}
TUNE_GRID = {   # coarse full grid first, then coordinate descent over the fine grids (model_engine.self_tune)
    'k': (6.0, 8.0, 10.0, 12.0, 14.0, 16.0, 20.0, 24.0, 28.0, 34.0),
    'hca': (0.0, 15.0, 30.0, 40.0, 50.0, 60.0, 75.0, 90.0, 110.0),
    'regress': (0.15, 0.25, 0.33, 0.42, 0.5, 0.6, 0.7, 0.8),
    'b2b': (0.0, 10.0, 20.0, 30.0, 40.0),
    'epp': (12.0, 14.0, 16.0, 18.0, 20.0, 22.0, 25.0, 28.0, 32.0),
}
TUNE_COARSE = {
    'k': (10.0, 16.0, 24.0), 'hca': (20.0, 50.0, 80.0), 'regress': (0.25, 0.5),
    'b2b': (0.0, 20.0), 'epp': (16.0, 22.0, 28.0),
}
TUNE_MIN_NEW_GAMES = 6      # re-tune after this many newly completed games
TUNE_MAX_AGE_HOURS = 72     # ... or at least every 3 days
