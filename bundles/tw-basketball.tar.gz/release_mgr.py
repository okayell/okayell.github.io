#!/usr/bin/env python3
"""Version, Release Notes & SemVer publisher for 台籃戰情室 (Pattern 164 / 173 / 176)."""
from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import json
import os
import sys
import threading
from typing import Any

import config

ROOT_DIR = config.ROOT_DIR
RELEASES_JSON = os.path.join(ROOT_DIR, 'releases.json')
BASELINE_JSON = os.path.join(config.DATA_DIR, 'release_baseline.json')
RELEASES_JS = os.path.join(config.STATIC_DIR, 'js', 'releases.js')
_LOCK = threading.RLock()
TOOL = config.TOOL_NAME

FILE_META: dict[str, tuple[str, str]] = {
    'server.py': ('後端服務', 'HTTP 伺服器、JSON API、每日 4 時段排程與比賽進行中即時比分更新'),
    'config.py': ('系統設定', '埠號、更新時段、聯盟設定與模型預設參數'),
    'net.py': ('網路抓取', '限速、Gzip 與指數退避重試的 HTTP 客戶端'),
    'db.py': ('資料庫', 'SQLite 賽季、球隊、賽程、逐場數據與賽前預測結構'),
    'updater.py': ('資料管線', 'TPBL API 與 P. LEAGUE+ 官網同步、檔案鎖與即時比分更新'),
    'model_engine.py': ('預測模型', 'Elo＋攻守模型、逐場前推回測、自動調參與賽前預測凍結'),
    'snapshot.py': ('資料快照', '兩聯盟分開的全站快照（戰績、球隊、球員、預測、模型）'),
    'feedback_mailer.py': ('意見回饋寄信', '意見回饋儲存與寄送站長信箱'),
    'release_mgr.py': ('版本發布', '版號與 Release Notes 管理'),
    'install.sh': ('部署腳本', 'systemd 雙服務安裝與啟動'),
    'README.md': ('文件', '架構與操作說明'),
    'sources/tpbl.py': ('資料來源', 'TPBL 官方 JSON API（賽季、賽程、逐場數據）'),
    'sources/plg.py': ('資料來源', 'P. LEAGUE+ 官網賽程頁、逐場數據 JSON 與賽況解析'),
    'tools/build_dist.py': ('打包匯出', 'GitHub Pages 單一 HTML 靜態版建置與外洩防護'),
    'static/index.html': ('頁面骨架', '聯盟切換、導覽列、版號徽章與視窗骨架'),
    'static/app.css': ('視覺樣式', '淺色高密度戰情室版面與手機版排版'),
    'static/js/app.js': ('前端核心', '路由、聯盟切換、資料更新頻率列、共用元件與版本視窗'),
    'static/js/page_home.js': ('頁面', '今日賽事與賽前預測'),
    'static/js/page_schedule.js': ('頁面', '賽程與比分（賽季／球隊／月份／狀態篩選）'),
    'static/js/page_standings.js': ('頁面', '戰績排行'),
    'static/js/page_teams.js': ('頁面', '球隊數據、陣容與 Elo 走勢'),
    'static/js/page_players.js': ('頁面', '球員排行與各項數據領先者'),
    'static/js/page_game.js': ('頁面', '比賽詳情：各節比分、逐場數據與賽前預測對照'),
    'static/js/page_model.js': ('頁面', '模型準確率、校準與調整紀錄'),
    'static/js/page_about.js': ('頁面', '資料來源、更新時間、模型說明與名詞解釋'),
    'static/js/page_feedback.js': ('頁面', '意見回饋'),
    'static/js/campus_nav.js': ('校園導覽', '開心學園跨館導覽與在線狀態同步'),
}

DEV_IGNORE_PREFIXES = ('tests/', 'tools/')
EXCLUDED_TRACK = {'static/js/releases.js', 'release_mgr.py'}

INITIAL_RELEASE: dict[str, Any] = {
    'version': '1.0.0',
    'date': '2026-10-31',
    'bump': 'major',
    'title': f'{TOOL} v1.0.0 初版上線',
    'notes': 'P. LEAGUE+ 與 TPBL 分開呈現的台灣職籃數據分析戰情室。',
    'highlights': [
        '聯盟切換：頁首一鍵切換 P. LEAGUE+／TPBL，每一頁只顯示所選聯盟，網址可用 ?lg=plg 或 ?lg=tpbl 直接分享。',
        '今日賽事與賽前預測：即時比分、模型勝率、預測比分／分差／總得分、信心等級與關鍵因素（Elo、近 5 場、主客場、休息天數、攻守表現）。',
        '賽程比分、戰績排行、球隊數據（含 Four Factors、節奏與攻守效率）、球員排行與比賽詳情逐場數據。',
        '模型準確率與檢討：逐場前推回測的命中率、Brier、分差與總分誤差、校準表、Elo 排行與自動調參紀錄；賽前預測在開賽前凍結，賽後誠實對照。',
    ],
    'files_count': 0,
}

BUMP_TEXT = {
    'major': '進第 1 位數（X.0.0）：全站架構大改版',
    'minor': '進第 2 位數（1.X.0）：新增頁面、資料來源或模型功能',
    'patch': '進第 3 位數（1.x.X）：介面微調、文字修正或小幅參數調整',
}


def tracked_paths() -> list[str]:
  out: list[str] = []
  for name in sorted(os.listdir(ROOT_DIR)):
    if name in EXCLUDED_TRACK:
      continue
    if name.endswith(('.py', '.sh', '.md')) and os.path.isfile(os.path.join(ROOT_DIR, name)):
      out.append(name)
  for folder, exts in (('sources', ('.py',)), ('static', ('.html', '.css')), ('static/js', ('.js',)),
                       ('tools', ('.py',)), ('tests', ('.py',))):
    d = os.path.join(ROOT_DIR, folder)
    if not os.path.isdir(d):
      continue
    for name in sorted(os.listdir(d)):
      rel = f'{folder}/{name}'
      if rel in EXCLUDED_TRACK or name == '__init__.py':
        continue
      if os.path.isfile(os.path.join(ROOT_DIR, rel)) and name.endswith(exts):
        out.append(rel)
  return out


def _read(rel: str) -> str:
  with open(os.path.join(ROOT_DIR, rel), encoding='utf-8', errors='replace') as f:
    return f.read()


def _sha(text: str) -> str:
  return hashlib.sha256(text.encode('utf-8')).hexdigest()


def load_releases() -> dict[str, Any]:
  with _LOCK:
    if os.path.isfile(RELEASES_JSON):
      try:
        with open(RELEASES_JSON, encoding='utf-8') as f:
          data = json.load(f)
        if isinstance(data, dict) and data.get('releases'):
          return data
      except (OSError, ValueError):
        pass
    data = {'current_version': INITIAL_RELEASE['version'], 'releases': [dict(INITIAL_RELEASE)]}
    save_releases(data)
    return data


def save_releases(data: dict[str, Any]) -> None:
  tmp = RELEASES_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
  os.replace(tmp, RELEASES_JSON)
  write_releases_js(data)


def write_releases_js(data: dict[str, Any] | None = None) -> None:
  rel_data = data or load_releases()
  os.makedirs(os.path.dirname(RELEASES_JS), exist_ok=True)
  js = 'window.TWB_RELEASES = ' + json.dumps(rel_data, ensure_ascii=False, separators=(',', ':')) + ';\n'
  try:
    with open(RELEASES_JS, encoding='utf-8') as f:
      if f.read() == js:
        return
  except OSError:
    pass
  tmp = RELEASES_JS + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    f.write(js)
  os.replace(tmp, RELEASES_JS)


def current_version() -> str:
  return str(load_releases().get('current_version') or INITIAL_RELEASE['version'])


def snapshot_baseline() -> dict[str, Any]:
  files = {rel: {'sha': _sha(txt), 'content': txt} for rel in tracked_paths() for txt in [_read(rel)]}
  os.makedirs(config.DATA_DIR, exist_ok=True)
  payload = {'version': current_version(),
             'snapshotted_at': dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S'), 'files': files}
  tmp = BASELINE_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(payload, f, ensure_ascii=False)
  os.replace(tmp, BASELINE_JSON)
  return payload


def _line_diff(old_txt: str, new_txt: str) -> tuple[int, int]:
  sm = difflib.SequenceMatcher(a=old_txt.splitlines(), b=new_txt.splitlines(), autojunk=False)
  added = removed = 0
  for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag in ('insert', 'replace'):
      added += j2 - j1
    if tag in ('delete', 'replace'):
      removed += i2 - i1
  return added, removed


def _bump_ver(ver: str, bump_type: str) -> str:
  parts = [int(x) for x in ver.lstrip('v').split('.')[:3]]
  while len(parts) < 3:
    parts.append(0)
  if bump_type == 'major':
    return f'{parts[0] + 1}.0.0'
  if bump_type == 'minor':
    return f'{parts[0]}.{parts[1] + 1}.0'
  return f'{parts[0]}.{parts[1]}.{parts[2] + 1}'


def get_release_status() -> dict[str, Any]:
  with _LOCK:
    rel_data = load_releases()
    cur_ver = rel_data['current_version']
    base_files: dict[str, dict[str, str]] = {}
    if os.path.isfile(BASELINE_JSON):
      try:
        with open(BASELINE_JSON, encoding='utf-8') as f:
          base_files = (json.load(f) or {}).get('files') or {}
      except (OSError, ValueError):
        base_files = {}
    cur_paths = tracked_paths()
    changed: list[dict[str, Any]] = []
    prod_added = prod_removed = prod_files = 0
    has_new_prod_file = False
    for rel in cur_paths:
      txt = _read(rel)
      cat, desc = FILE_META.get(rel, ('專案檔案', rel))
      is_prod = not rel.startswith(DEV_IGNORE_PREFIXES) and not rel.endswith('.md')
      if rel not in base_files:
        lines = len(txt.splitlines())
        changed.append({'path': rel, 'status': 'added', 'added': lines, 'removed': 0, 'category': cat, 'desc': desc})
        if is_prod:
          has_new_prod_file = True
          prod_added += lines
          prod_files += 1
      elif base_files[rel].get('sha') != _sha(txt):
        ad, rm = _line_diff(base_files[rel].get('content', ''), txt)
        changed.append({'path': rel, 'status': 'modified', 'added': ad, 'removed': rm, 'category': cat, 'desc': desc})
        if is_prod:
          prod_added += ad
          prod_removed += rm
          prod_files += 1
    for old_rel in sorted(set(base_files) - set(cur_paths)):
      rm = len((base_files[old_rel].get('content') or '').splitlines())
      cat, desc = FILE_META.get(old_rel, ('專案檔案', old_rel))
      changed.append({'path': old_rel, 'status': 'deleted', 'added': 0, 'removed': rm, 'category': cat, 'desc': desc})
    churn = prod_added + prod_removed
    if (prod_removed >= 400 and churn >= 1200) or prod_files >= 14 or churn >= 3500:
      rec, reason = 'major', f'核心程式大幅改寫（{prod_files} 個檔案、共變動 {churn} 行），建議進第 1 位數。'
    elif has_new_prod_file or prod_files >= 3 or churn >= 110:
      rec, reason = 'minor', f'新增或擴充功能（{prod_files} 個檔案、+{prod_added}/-{prod_removed} 行），建議進第 2 位數。'
    else:
      rec, reason = 'patch', f'局部介面或文字微調（+{prod_added}/-{prod_removed} 行），建議進第 3 位數。'
    nxt = {b: _bump_ver(cur_ver, b) for b in ('patch', 'minor', 'major')}
    return {
        'current_version': cur_ver, 'has_changes': bool(changed), 'changed_files': changed,
        'total_added': sum(c['added'] for c in changed), 'total_removed': sum(c['removed'] for c in changed),
        'recommended_bump': rec, 'recommend_reason': reason, 'bump_descriptions': BUMP_TEXT,
        'next_versions': nxt, 'suggested_title': f'{TOOL} v{nxt[rec]} 功能更新',
        'suggested_highlights': [f"【{c['category']}】{c['desc']}（{c['path']} +{c['added']}/-{c['removed']}）"
                                 for c in changed[:6]],
        'releases': rel_data['releases'],
    }


def publish_release(bump_type: str, title: str, highlights: list[str]) -> dict[str, Any]:
  with _LOCK:
    st = get_release_status()
    btype = bump_type if bump_type in ('patch', 'minor', 'major') else st['recommended_bump']
    new_ver = _bump_ver(st['current_version'], btype)
    clean = [h.strip() for h in (highlights or []) if str(h).strip()] or st['suggested_highlights'] or ['例行維護與資料更新']
    entry = {'version': new_ver, 'date': dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d'), 'bump': btype,
             'title': (title or '').strip() or f'{TOOL} v{new_ver} 更新', 'notes': clean[0], 'highlights': clean,
             'files_count': len(st['changed_files'])}
    rel_data = load_releases()
    rel_data['current_version'] = new_ver
    rel_data['releases'].insert(0, entry)
    save_releases(rel_data)
    snapshot_baseline()
    try:
      from tools import build_dist  # pylint: disable=import-outside-toplevel
      build_dist.build_all()
    except Exception:  # pylint: disable=broad-except
      pass
    return get_release_status()


if __name__ == '__main__':
  cmd = sys.argv[1] if len(sys.argv) > 1 else 'status'
  if cmd == 'init':
    load_releases()
    write_releases_js()
    snapshot_baseline()
    print('Initialized baseline at', current_version())
  else:
    print(json.dumps(get_release_status(), ensure_ascii=False, indent=2))
