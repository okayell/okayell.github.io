#!/usr/bin/env python3
"""台籃戰情室 prediction model (stdlib only, one independent model per league).

* Elo with home-court advantage, margin-of-victory multiplier, season carry-over (regression to the
  mean) and a back-to-back penalty.
* Points model: exponentially weighted offense / defense residuals vs. the league scoring level
  (captures pace + efficiency) -> expected score for each side.
* Prediction = blend of the Elo margin and the points-model margin; total = points model;
  win probability = logistic of the blended margin (Elo scale).
* Walk-forward replay over completed games (each game is predicted from the state *before* it,
  no look-ahead) -> 命中率 / Brier / 分差 MAE / 總分 MAE / calibration.
* Self-tune: grid search over K / HCA / regression / back-to-back / points-per-Elo, logged in tune_log.
* Frozen predictions: every sync writes predictions for games that have not tipped off yet; once a
  game starts its row is never touched again, so live accuracy is honest.
"""
from __future__ import annotations

import datetime as dt
import itertools
import json
import math
import sqlite3
import time
from collections import defaultdict, deque
from typing import Any

import config
import db

MODEL_VERSION = 'elo-pts-1'
W_ELO = 0.6            # blend weight of the Elo margin (rest = points model)
EWMA_A = 0.15          # offense / defense residual smoothing
CARRY_PTS = 0.5        # share of offense / defense residual kept across seasons
LG_PRIOR_PTS = 95.0    # weak prior for the league scoring level (4 pseudo team-games)
LG_WINDOW = 80         # rolling window (team-games) for the league scoring level
CAL_BINS = ((50, 55), (55, 60), (60, 65), (65, 70), (70, 80), (80, 101))
MODEL_STAGES = ('regular', 'playin', 'playoffs', 'finals')


def _d(s: str) -> dt.date:
  return dt.date.fromisoformat(s[:10])


def _now_tw() -> dt.datetime:
  return dt.datetime.now(config.TZ_TW)


def load_games(conn: sqlite3.Connection, league: str) -> list[dict[str, Any]]:
  return db.rows(conn, """
      SELECT g.*, s.ord AS season_ord FROM games g
      LEFT JOIN seasons s ON s.league = g.league AND s.season = g.season
      WHERE g.league = ? ORDER BY g.tip_ts, CAST(g.game_id AS INTEGER)""", (league,))


def _is_done(g: dict[str, Any]) -> bool:
  return g.get('status') == 'final' and g.get('home_score') is not None and g.get('away_score') is not None


class _Team:
  __slots__ = ('season', 'gp', 'w', 'l', 'pf', 'pa', 'hw', 'hl', 'aw', 'al', 'last', 'last_date', 'off', 'dfn')

  def __init__(self) -> None:
    self.season = None
    self.gp = self.w = self.l = self.pf = self.pa = self.hw = self.hl = self.aw = self.al = 0
    self.last: list[str] = []
    self.last_date: dt.date | None = None
    self.off = 0.0
    self.dfn = 0.0


class Replay:
  """Chronological state machine; `predict` never looks at the game's own result."""

  def __init__(self, params: dict[str, float]) -> None:
    self.p = dict(config.MODEL_DEFAULTS, **(params or {}))
    self.elo: dict[str, float] = {}
    self.t: dict[str, _Team] = defaultdict(_Team)
    self.season: str | None = None
    self.recent: deque[int] = deque(maxlen=LG_WINDOW)
    self.hist: dict[str, list[list[Any]]] = defaultdict(list)

  # ------------------------------------------------------------------ season handling
  def _season(self, season: str) -> None:
    if season == self.season:
      return
    if self.season is not None and self.elo:
      mean = sum(self.elo.values()) / len(self.elo)
      r = self.p['regress']
      for k in self.elo:
        self.elo[k] = mean + (self.elo[k] - mean) * (1 - r)
    for st in self.t.values():
      st.off *= CARRY_PTS
      st.dfn *= CARRY_PTS
    self.season = season

  def _team(self, tid: str, season: str) -> _Team:
    st = self.t[tid]
    if st.season != season:
      st.season = season
      st.gp = st.w = st.l = st.pf = st.pa = st.hw = st.hl = st.aw = st.al = 0
      st.last = []
    return st

  def lg_avg(self) -> float:
    n = len(self.recent)
    return (LG_PRIOR_PTS * 4 + sum(self.recent)) / (4 + n)

  # ------------------------------------------------------------------ prediction
  def predict(self, g: dict[str, Any], last_dates: dict[str, dt.date] | None = None) -> dict[str, Any]:
    p = self.p
    season = g['season']
    self._season(season)
    h, a = g['home_id'], g['away_id']
    sh, sa = self._team(h, season), self._team(a, season)
    eh, ea = self.elo.get(h, 1500.0), self.elo.get(a, 1500.0)
    day = _d(g['game_date'])
    ld = last_dates or {}
    lh = ld.get(h, sh.last_date)
    la = ld.get(a, sa.last_date)
    rest_h = (day - lh).days if lh and sh.gp else None   # first game of a season = no rest signal
    rest_a = (day - la).days if la and sa.gp else None
    b2b_h, b2b_a = rest_h == 1, rest_a == 1
    rest_adj = (-p['b2b'] if b2b_h else 0.0) + (p['b2b'] if b2b_a else 0.0)
    diff = eh - ea + p['hca'] + rest_adj
    m_elo = diff / p['epp']
    avg = self.lg_avg()
    hca_pts = p['hca'] / p['epp']
    exp_h = avg + sh.off + sa.dfn + hca_pts / 2
    exp_a = avg + sa.off + sh.dfn - hca_pts / 2
    margin = W_ELO * m_elo + (1 - W_ELO) * (exp_h - exp_a)
    total = exp_h + exp_a
    prob = 1.0 / (1.0 + 10 ** (-(margin * p['epp']) / 400.0))
    gp_min = min(sh.gp, sa.gp)
    fav = max(prob, 1 - prob)
    if gp_min < 3:
      conf = '中' if fav >= 0.75 else '低'
    else:
      conf = '高' if fav >= 0.72 else ('中' if fav >= 0.6 else '低')
    factors = {
        'elo': [round(ea), round(eh)],
        'last5': [_wl(sa.last[-5:]), _wl(sh.last[-5:])],
        'split': [f'客場 {sa.aw}-{sa.al}', f'主場 {sh.hw}-{sh.hl}'],
        'record': [f'{sa.w}-{sa.l}', f'{sh.w}-{sh.l}'],
        'rest': [rest_a, rest_h], 'b2b': [b2b_a, b2b_h],
        'ppg': [_r1(sa.pf / sa.gp) if sa.gp else None, _r1(sh.pf / sh.gp) if sh.gp else None],
        'opp': [_r1(sa.pa / sa.gp) if sa.gp else None, _r1(sh.pa / sh.gp) if sh.gp else None],
        'gp': [sa.gp, sh.gp], 'hca_pts': _r1(hca_pts), 'm_elo': _r1(m_elo), 'm_pts': _r1(exp_h - exp_a),
    }
    return {
        'p_home': round(prob, 4), 'pred_margin': _r1(margin), 'pred_total': _r1(total),
        'pred_home_pts': _r1((total + margin) / 2), 'pred_away_pts': _r1((total - margin) / 2),
        'elo_home': round(eh, 1), 'elo_away': round(ea, 1), 'confidence': conf, 'factors': factors,
    }

  # ------------------------------------------------------------------ update with a result
  def update(self, g: dict[str, Any]) -> None:
    p = self.p
    season = g['season']
    self._season(season)
    h, a = g['home_id'], g['away_id']
    hs, as_ = int(g['home_score']), int(g['away_score'])
    sh, sa = self._team(h, season), self._team(a, season)
    eh, ea = self.elo.get(h, 1500.0), self.elo.get(a, 1500.0)
    day = _d(g['game_date'])
    b2b_h = bool(sh.last_date and (day - sh.last_date).days == 1)
    b2b_a = bool(sa.last_date and (day - sa.last_date).days == 1)
    diff = eh - ea + p['hca'] + (-p['b2b'] if b2b_h else 0.0) + (p['b2b'] if b2b_a else 0.0)
    mov = hs - as_
    s_h = 1.0 if mov > 0 else (0.0 if mov < 0 else 0.5)
    e_h = 1.0 / (1.0 + 10 ** (-diff / 400.0))
    win_diff = diff if mov >= 0 else -diff
    mult = ((abs(mov) + 3) ** 0.8) / max(2.0, 7.5 + 0.006 * win_diff)
    delta = p['k'] * mult * (s_h - e_h)
    self.elo[h] = eh + delta
    self.elo[a] = ea - delta
    avg = self.lg_avg()
    for st, pf, pa, home in ((sh, hs, as_, True), (sa, as_, hs, False)):
      st.gp += 1
      st.pf += pf
      st.pa += pa
      won = pf > pa
      st.w += won
      st.l += not won
      if home:
        st.hw += won
        st.hl += not won
      else:
        st.aw += won
        st.al += not won
      st.last.append('W' if won else 'L')
      st.last = st.last[-10:]
      st.last_date = day
      st.off += EWMA_A * ((pf - avg) - st.off)
      st.dfn += EWMA_A * ((pa - avg) - st.dfn)
    self.recent.append(hs)
    self.recent.append(as_)
    self.hist[h].append([g['game_date'], round(self.elo[h], 1), g['season']])
    self.hist[a].append([g['game_date'], round(self.elo[a], 1), g['season']])


def _wl(seq: list[str]) -> str:
  return f'{seq.count("W")}-{seq.count("L")}' if seq else '—'


def _r1(x: float | None) -> float | None:
  return None if x is None else round(float(x), 1)


# --------------------------------------------------------------------------- evaluation
def walk_forward(games: list[dict[str, Any]], params: dict[str, float]) -> tuple[Replay, dict[str, dict]]:
  rp = Replay(params)
  preds: dict[str, dict] = {}
  for g in games:
    if g.get('stage') not in MODEL_STAGES or not _is_done(g):
      continue
    pr = rp.predict(g)
    preds[g['game_id']] = pr
    rp.update(g)
  return rp, preds


def eval_seasons(games: list[dict[str, Any]]) -> list[str]:
  """Seasons used for scoring = every season after the first one (the first is Elo warm-up)."""
  seasons = sorted({g['season'] for g in games if g.get('stage') in MODEL_STAGES and _is_done(g)},
                   key=lambda s: next((g.get('season_ord') or 0 for g in games if g['season'] == s), 0))
  return seasons[1:] if len(seasons) > 1 else seasons


def metrics(games: list[dict[str, Any]], preds: dict[str, dict], seasons: list[str] | None = None) -> dict[str, Any]:
  n = hits = home_hits = 0
  brier = mae_m = mae_t = ll = 0.0
  bins = [{'lo': lo, 'hi': hi, 'n': 0, 'p': 0.0, 'w': 0} for lo, hi in CAL_BINS]
  for g in games:
    pr = preds.get(g['game_id'])
    if not pr or (seasons and g['season'] not in seasons):
      continue
    if g.get('stage') not in MODEL_STAGES or not _is_done(g) or pr.get('p_home') is None:
      continue
    y = 1.0 if g['home_score'] > g['away_score'] else 0.0
    ph = pr['p_home']
    n += 1
    hits += (ph >= 0.5) == (y == 1.0)
    home_hits += y == 1.0
    brier += (ph - y) ** 2
    pc = min(max(ph, 1e-4), 1 - 1e-4)
    ll += -(y * math.log(pc) + (1 - y) * math.log(1 - pc))
    mae_m += abs(pr['pred_margin'] - (g['home_score'] - g['away_score']))
    mae_t += abs(pr['pred_total'] - (g['home_score'] + g['away_score']))
    fav = max(ph, 1 - ph) * 100
    fav_won = (ph >= 0.5) == (y == 1.0)
    for b in bins:
      if b['lo'] <= fav < b['hi']:
        b['n'] += 1
        b['p'] += fav
        b['w'] += fav_won
        break
  out = {'n': n}
  if n:
    out.update({
        'hit': round(hits / n, 4), 'brier': round(brier / n, 4), 'logloss': round(ll / n, 4),
        'mae_margin': round(mae_m / n, 2), 'mae_total': round(mae_t / n, 2),
        'home_base': round(home_hits / n, 4),
    })
  out['calibration'] = [
      {'lo': b['lo'], 'hi': min(b['hi'], 100), 'n': b['n'],
       'pred': round(b['p'] / b['n'], 1) if b['n'] else None,
       'actual': round(100 * b['w'] / b['n'], 1) if b['n'] else None} for b in bins]
  return out


def self_tune(games: list[dict[str, Any]], base: dict[str, float]) -> tuple[dict[str, float], dict, dict]:
  """Coarse full grid, then coordinate descent over the fine grids (objective: Brier, then 分差 MAE)."""
  seasons = eval_seasons(games)
  cache: dict[tuple, dict] = {}

  def score(cand: dict[str, float]) -> dict:
    key = tuple(round(cand[k], 4) for k in ('k', 'hca', 'regress', 'b2b', 'epp'))
    if key not in cache:
      _, pr = walk_forward(games, cand)
      cache[key] = metrics(games, pr, seasons)
    return cache[key]

  def better(a: dict, b: dict) -> bool:
    return bool(a.get('n')) and (not b.get('n') or (a['brier'], a['mae_margin']) < (b['brier'], b['mae_margin']))

  base = {k: float(base[k]) for k in ('k', 'hca', 'regress', 'b2b', 'epp')}
  base_m = score(base)
  best_p, best_m = dict(base), base_m
  c = config.TUNE_COARSE
  for k, hca, reg, b2b, epp in itertools.product(c['k'], c['hca'], c['regress'], c['b2b'], c['epp']):
    cand = {'k': k, 'hca': hca, 'regress': reg, 'b2b': b2b, 'epp': epp}
    m = score(cand)
    if better(m, best_m):
      best_p, best_m = cand, m
  for _ in range(3):
    moved = False
    for name, grid in config.TUNE_GRID.items():
      for v in grid:
        cand = dict(best_p, **{name: v})
        m = score(cand)
        if better(m, best_m):
          best_p, best_m, moved = cand, m, True
    if not moved:
      break
  return best_p, best_m, base_m


# --------------------------------------------------------------------------- run (per sync)
def _needs_tune(conn: sqlite3.Connection, league: str, n_done: int) -> bool:
  last = conn.execute('SELECT run_at, games FROM tune_log WHERE league = ? ORDER BY id DESC LIMIT 1',
                      (league,)).fetchone()
  if not last:
    return True
  if n_done - int(last['games'] or 0) >= config.TUNE_MIN_NEW_GAMES:
    return True
  try:
    age_h = (_now_tw() - dt.datetime.fromisoformat(last['run_at'])).total_seconds() / 3600
  except (TypeError, ValueError):
    return True
  return age_h >= config.TUNE_MAX_AGE_HOURS


def _freeze(conn: sqlite3.Connection, league: str, games: list[dict[str, Any]], rp: Replay,
            now: dt.datetime, cur_season: str | None) -> tuple[int, dict[str, dict]]:
  """Writes predictions for games that have not tipped off yet; returns late (unfrozen) estimates.

  Only games of the latest season are predicted: replaying a stale game of an older season (e.g. an
  unplayed playoff game) would rewind the replay's season state.
  """
  frozen_at = now.isoformat(timespec='seconds')
  last_dates = {tid: st.last_date for tid, st in rp.t.items() if st.last_date}
  wrote = 0
  late: dict[str, dict] = {}
  existing = {r['game_id'] for r in db.rows(conn, 'SELECT game_id FROM predictions WHERE league = ?', (league,))}
  for g in games:
    if g.get('stage') not in MODEL_STAGES or _is_done(g) or not g.get('tip_ts'):
      continue
    if g['season'] != cur_season or g.get('status') == 'cancelled':
      continue
    try:
      tip = dt.datetime.fromisoformat(g['tip_ts'])
    except ValueError:
      continue
    pr = rp.predict(g, last_dates)
    last_dates[g['home_id']] = last_dates[g['away_id']] = _d(g['game_date'])
    if tip > now and g.get('status') in ('scheduled', 'postponed'):
      db.upsert(conn, 'predictions', {
          'league': league, 'game_id': g['game_id'], 'frozen_at': frozen_at, 'model_ver': MODEL_VERSION,
          'p_home': pr['p_home'], 'pred_margin': pr['pred_margin'], 'pred_total': pr['pred_total'],
          'pred_home_pts': pr['pred_home_pts'], 'pred_away_pts': pr['pred_away_pts'],
          'elo_home': pr['elo_home'], 'elo_away': pr['elo_away'], 'confidence': pr['confidence'],
          'factors': json.dumps(pr['factors'], ensure_ascii=False, separators=(',', ':')),
      }, keys=('league', 'game_id'))
      wrote += 1
    elif g['game_id'] not in existing:
      late[g['game_id']] = pr
  return wrote, late


def run_league(conn: sqlite3.Connection, league: str, allow_tune: bool = True,
               now: dt.datetime | None = None) -> dict[str, Any]:
  now = now or _now_tw()
  games = load_games(conn, league)
  done = [g for g in games if g.get('stage') in MODEL_STAGES and _is_done(g)]
  stored = db.get_kv(conn, f'model_params:{league}') or {}
  params = dict(config.MODEL_DEFAULTS, **stored)
  tuned = None
  if allow_tune and len(done) >= 30 and _needs_tune(conn, league, len(done)):
    t0 = time.time()
    best, best_m, base_m = self_tune(games, params)
    improved = best_m.get('n') and base_m.get('n') and best_m['brier'] < base_m['brier'] - 0.0005
    note = '採用新參數' if improved else '維持原參數（新組合沒有明顯更好）'
    if improved:
      params = dict(config.MODEL_DEFAULTS, **best)
      db.set_kv(conn, f'model_params:{league}', params)
    elif not stored:
      db.set_kv(conn, f'model_params:{league}', params)
    conn.execute(
        'INSERT INTO tune_log(league, run_at, games, params, prev_params, metrics, prev_metrics, note) '
        'VALUES(?,?,?,?,?,?,?,?)',
        (league, now.isoformat(timespec='seconds'), len(done),
         json.dumps(best if improved else params), json.dumps(stored or config.MODEL_DEFAULTS),
         json.dumps({k: v for k, v in best_m.items() if k != 'calibration'}),
         json.dumps({k: v for k, v in base_m.items() if k != 'calibration'}),
         note + f'（{time.time() - t0:.1f} 秒）'))
    tuned = note
  rp, preds = walk_forward(games, params)
  seasons = eval_seasons(games)
  cur_season = max((g['season'] for g in games), default=None,
                   key=lambda s: next((x.get('season_ord') or 0 for x in games if x['season'] == s), 0))
  m_all = metrics(games, preds, seasons)
  m_cur = metrics(games, preds, [cur_season] if cur_season else None)
  wrote, late = _freeze(conn, league, games, rp, now, cur_season)
  # Frozen (live, out-of-sample) accuracy.
  fz_rows = db.rows(conn, 'SELECT * FROM predictions WHERE league = ?', (league,))
  fz = {r['game_id']: r for r in fz_rows}
  m_frozen = metrics(games, fz, None)
  active = {g['home_id'] for g in games if g['season'] == cur_season} | {g['away_id'] for g in games if g['season'] == cur_season}
  ladder = sorted(({'team_id': t, 'elo': round(e, 1)} for t, e in rp.elo.items() if t in active),
                  key=lambda x: -x['elo'])
  keep_seasons = sorted({g['season'] for g in games}, key=lambda s: next(
      (x.get('season_ord') or 0 for x in games if x['season'] == s), 0))[-2:]
  history = {t: [h[:2] for h in rows if h[2] in keep_seasons] for t, rows in rp.hist.items() if t in active}
  out = {
      'league': league, 'model_version': MODEL_VERSION, 'params': params, 'run_at': now.isoformat(timespec='seconds'),
      'eval_seasons': seasons, 'current_season': cur_season, 'metrics_all': m_all, 'metrics_current': m_cur,
      'metrics_frozen': m_frozen, 'ladder': ladder, 'history': history, 'n_done': len(done),
      'backtest': {gid: {k: pr[k] for k in ('p_home', 'pred_margin', 'pred_total', 'pred_home_pts',
                                            'pred_away_pts', 'confidence')} for gid, pr in preds.items()},
      'late': late, 'frozen_written': wrote, 'tuned': tuned,
  }
  db.set_kv(conn, f'model:{league}', out)
  return {'league': league, 'n_done': len(done), 'frozen_written': wrote, 'tuned': tuned,
          'hit': m_all.get('hit'), 'brier': m_all.get('brier')}


def run(conn: sqlite3.Connection, allow_tune: bool = True) -> dict[str, Any]:
  out = {}
  for lg in config.LEAGUES:
    try:
      out[lg] = run_league(conn, lg, allow_tune=allow_tune)
    except Exception as e:  # pylint: disable=broad-except
      out[lg] = {'error': str(e)[:300]}
  conn.commit()
  return out
