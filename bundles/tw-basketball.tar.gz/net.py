#!/usr/bin/env python3
"""Polite HTTP client: per-host rate limiting, browser-like UA, gzip, retries with backoff."""
from __future__ import annotations

import gzip
import html
import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

import config

USER_AGENT = (
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
)

_HOST_LAST_TS: dict[str, float] = {}
_HOST_LOCK = threading.Lock()
STATS = {'requests': 0, 'bytes': 0, 'errors': 0}


def _throttle(url: str) -> None:
  host = urllib.parse.urlparse(url).netloc.lower()
  min_iv = config.HOST_INTERVAL.get(host, config.DEFAULT_INTERVAL)
  with _HOST_LOCK:
    now = time.monotonic()
    wait = (_HOST_LAST_TS.get(host, 0.0) + min_iv) - now
    if wait > 0:
      time.sleep(wait)
    _HOST_LAST_TS[host] = time.monotonic()


def fetch_bytes(url: str, timeout: float = 20.0, retries: int = 3,
                headers: dict[str, str] | None = None) -> bytes:
  last_err: Exception | None = None
  for attempt in range(retries):
    _throttle(url)
    hdrs = {
        'User-Agent': USER_AGENT,
        'Accept-Encoding': 'gzip',
        'Accept': 'application/json,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.8',
    }
    hdrs.update(headers or {})
    req = urllib.request.Request(url, headers=hdrs)
    try:
      with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        if (resp.headers.get('Content-Encoding') or '').lower() == 'gzip' or raw[:2] == b'\x1f\x8b':
          try:
            raw = gzip.decompress(raw)
          except OSError:
            pass
        STATS['requests'] += 1
        STATS['bytes'] += len(raw)
        return raw
    except urllib.error.HTTPError as e:
      last_err = e
      if 400 <= e.code < 500 and e.code != 429:
        break
    except (urllib.error.URLError, TimeoutError, OSError) as e:
      last_err = e
    if attempt + 1 < retries:
      time.sleep(1.0 * (2 ** attempt))
  STATS['errors'] += 1
  raise RuntimeError(f'GET {url} failed: {last_err}')


def fetch_text(url: str, timeout: float = 20.0, retries: int = 3,
               headers: dict[str, str] | None = None) -> str:
  return fetch_bytes(url, timeout=timeout, retries=retries, headers=headers).decode('utf-8', errors='replace')


def fetch_json(url: str, timeout: float = 20.0, retries: int = 3,
               headers: dict[str, str] | None = None) -> Any:
  return json.loads(fetch_text(url, timeout=timeout, retries=retries, headers=headers))


def clean_str(s: str | None) -> str:
  if not s:
    return ''
  t = html.unescape(str(s))
  t = re.sub(r'[\ufeff\u200b-\u200f\u2060-\u2064]', '', t)
  t = t.replace('\xa0', ' ').replace('\u3000', ' ')
  t = re.sub(r'<[^>]+>', ' ', t)
  return re.sub(r'\s+', ' ', t).strip()
