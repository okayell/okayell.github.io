#!/usr/bin/env python3
"""Builds data/snapshot.json — everything the UI needs for BOTH leagues (never mixed)."""
from __future__ import annotations

import datetime as dt
import json
import os
import sqlite3
from collections import defaultdict
from typing import Any

import config
import db

BOX_TEAM_FIELDS = ['team_id', 'is_home', 'pts', 'fgm', 'fga', 'tpm', 'tpa', 'ftm', 'fta', 'oreb', 'dreb',
                   'reb', 'ast', 'stl', 'blk', 'tov', 'pf']
BOX_PLAYER_FIELDS = ['team_id', 'player_id', 'name', 'number', 'pos', 'starter', 'sec', 'pts', 'fgm', 'fga',
                     'tpm', 'tpa', 'ftm', 'fta', 'oreb', 'dreb', 'reb', 'ast', 'stl', 'blk', 'tov', 'pf', 'pm']
PLAYER_FIELDS = ['player_id', 'name', 'team_id', 'number', 'pos', 'gp', 'gs', 'sec', 'pts', 'fgm', 'fga', 'tpm',
                 'tpa', 'ftm', 'fta', 'oreb', 'dreb', 'reb', 'ast', 'stl', 'blk', 'tov', 'pf', 'pm']
STAT_KEYS = ['pts', 'fgm', 'fga', 'tpm', 'tpa', 'ftm', 'fta', 'oreb', 'dreb', 'reb', 'ast', 'stl', 'blk', 'tov', 'pf']
PALETTE = ['#2563eb', '#dc2626', '#059669', '#d97706', '#7c3aed', '#0891b2', '#db2777', '#4b5563', '#65a30d']


def now_tw() -> dt.datetime:
  return dt.datetime.now(config.TZ_TW)


def iso(t: dt.datetime) -> str:
  return t.astimezone(config.TZ_TW).isoformat(timespec='seconds')


def next_update_time(now: dt.datetime | None = None) -> str:
  now = now or now_tw()
  for add in (0, 1):
    day = (now + dt.timedelta(days=add)).date()
    for t in config.SYNC_TIMES:
      hh, mm = map(int, t.split(':'))
      cand = dt.datetime(day.year, day.month, day.day, hh, mm, tzinfo=config.TZ_TW)
      if cand > now:
        return iso(cand)
  return iso(now + dt.timedelta(hours=6))


def _season_order(conn: sqlite3.Connection, league: str) -> list[dict[str, Any]]:
  return db.rows(conn, 'SELECT * FROM seasons WHERE league = ? ORDER BY ord', (league,))


def box_seasons(conn: sqlite3.Connection, league: str) -> list[str]:
  rows = db.rows(conn, """SELECT s.season FROM seasons s WHERE s.league = ? AND EXISTS (
      SELECT 1 FROM games g WHERE g.league = s.league AND g.season = s.season) ORDER BY s.ord DESC""", (league,))
  return [r['season'] for r in rows[:config.BOX_SEASONS]]


def _r(x: float | None, n: int = 1) -> float | None:
  return None if x is None else round(x, n)


def _pct(m: float, a: float) -> float | None:
  return round(100.0 * m / a, 1) if a else None


# --------------------------------------------------------------------------- standings
def standings(games: list[dict[str, Any]], elo: dict[str, float] | None = None) -> list[dict[str, Any]]:
  st: dict[str, dict[str, Any]] = {}
  done = sorted((g for g in games if g['stage'] == 'regular' and g['status'] == 'final'
                 and g['home_score'] is not None), key=lambda g: (g['tip_ts'] or '', g['game_id']))
  teams = {g['home_id'] for g in games if g['stage'] == 'regular'} | {g['away_id'] for g in games if g['stage'] == 'regular'}
  for t in teams:
    st[t] = {'team_id': t, 'gp': 0, 'w': 0, 'l': 0, 'hw': 0, 'hl': 0, 'aw': 0, 'al': 0, 'pf': 0, 'pa': 0, 'seq': []}
  for g in done:
    for tid, pf, pa, home in ((g['home_id'], g['home_score'], g['away_score'], True),
                              (g['away_id'], g['away_score'], g['home_score'], False)):
      s = st[tid]
      won = pf > pa
      s['gp'] += 1
      s['w'] += won
      s['l'] += not won
      s['pf'] += pf
      s['pa'] += pa
      if home:
        s['hw'] += won
        s['hl'] += not won
      else:
        s['aw'] += won
        s['al'] += not won
      s['seq'].append('W' if won else 'L')
  out = []
  for s in st.values():
    seq = s.pop('seq')
    strk = ''
    if seq:
      last = seq[-1]
      n = 0
      for x in reversed(seq):
        if x != last:
          break
        n += 1
      strk = f'{"連勝" if last == "W" else "連敗"} {n}'
    l10 = seq[-10:]
    gp = s['gp']
    s.update({
        'pct': round(s['w'] / gp, 3) if gp else 0.0, 'home': f'{s["hw"]}-{s["hl"]}', 'away': f'{s["aw"]}-{s["al"]}',
        'strk': strk, 'l10': f'{l10.count("W")}-{l10.count("L")}' if l10 else '—',
        'ppg': _r(s['pf'] / gp) if gp else None, 'opp': _r(s['pa'] / gp) if gp else None,
        'diff': _r((s['pf'] - s['pa']) / gp) if gp else None, 'last5': ''.join(seq[-5:]),
        'elo': round(elo[s['team_id']]) if elo and s['team_id'] in elo else None,
    })
    out.append(s)
  out.sort(key=lambda s: (-s['pct'], -(s['w'] - s['l']), -(s['diff'] or 0), s['team_id']))
  if out:
    lead = out[0]
    for i, s in enumerate(out):
      s['rank'] = i + 1
      gb = ((lead['w'] - s['w']) + (s['l'] - lead['l'])) / 2
      s['gb'] = '—' if gb == 0 else (f'{gb:.1f}'.rstrip('0').rstrip('.') if gb % 1 else str(int(gb)))
  return out


# --------------------------------------------------------------------------- team & player aggregates
def team_stats(conn: sqlite3.Connection, league: str, season: str) -> dict[str, dict[str, Any]]:
  rows = db.rows(conn, """
      SELECT tb.*, g.home_id, g.away_id FROM team_box tb JOIN games g ON g.league = tb.league AND g.game_id = tb.game_id
      WHERE tb.league = ? AND g.season = ? AND g.stage = 'regular' AND g.status = 'final'""", (league, season))
  by_game: dict[str, list[dict]] = defaultdict(list)
  for r in rows:
    by_game[r['game_id']].append(r)
  agg: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
  for gid, pair in by_game.items():
    if len(pair) != 2:
      continue
    for me, op in ((pair[0], pair[1]), (pair[1], pair[0])):
      a = agg[me['team_id']]
      a['g'] += 1
      for k in STAT_KEYS:
        a[k] += me[k] or 0
        a['o_' + k] += op[k] or 0
      poss = ((me['fga'] or 0) + 0.44 * (me['fta'] or 0) - (me['oreb'] or 0) + (me['tov'] or 0)
              + (op['fga'] or 0) + 0.44 * (op['fta'] or 0) - (op['oreb'] or 0) + (op['tov'] or 0)) / 2
      a['poss'] += poss
  out = {}
  for tid, a in agg.items():
    g = a['g']
    if not g:
      continue
    fga, fta, tov = a['fga'], a['fta'], a['tov']
    out[tid] = {
        'g': int(g), 'ppg': _r(a['pts'] / g), 'opp': _r(a['o_pts'] / g),
        'fg': _pct(a['fgm'], fga), 'tp': _pct(a['tpm'], a['tpa']), 'ft': _pct(a['ftm'], fta),
        'efg': _pct(a['fgm'] + 0.5 * a['tpm'], fga), 'tov_pct': _pct(tov, fga + 0.44 * fta + tov),
        'orb_pct': _pct(a['oreb'], a['oreb'] + a['o_dreb']), 'ftr': _pct(a['ftm'], fga),
        'o_efg': _pct(a['o_fgm'] + 0.5 * a['o_tpm'], a['o_fga']),
        'o_tov_pct': _pct(a['o_tov'], a['o_fga'] + 0.44 * a['o_fta'] + a['o_tov']),
        'drb_pct': _pct(a['dreb'], a['dreb'] + a['o_oreb']), 'o_ftr': _pct(a['o_ftm'], a['o_fga']),
        'pace': _r(a['poss'] / g), 'ortg': _r(100 * a['pts'] / a['poss']) if a['poss'] else None,
        'drtg': _r(100 * a['o_pts'] / a['poss']) if a['poss'] else None,
        'reb': _r(a['reb'] / g), 'ast': _r(a['ast'] / g), 'stl': _r(a['stl'] / g), 'blk': _r(a['blk'] / g),
        'tov': _r(a['tov'] / g), 'tpa': _r(a['tpa'] / g),
    }
    if out[tid]['ortg'] is not None and out[tid]['drtg'] is not None:
      out[tid]['net'] = _r(out[tid]['ortg'] - out[tid]['drtg'])
  return out


def player_totals(conn: sqlite3.Connection, league: str, season: str) -> list[list[Any]]:
  rows = db.rows(conn, """
      SELECT pb.*, g.tip_ts FROM player_box pb JOIN games g ON g.league = pb.league AND g.game_id = pb.game_id
      WHERE pb.league = ? AND g.season = ? AND g.stage = 'regular' AND g.status = 'final'
      ORDER BY g.tip_ts""", (league, season))
  agg: dict[str, dict[str, Any]] = {}
  for r in rows:
    a = agg.get(r['player_id'])
    if a is None:
      a = agg[r['player_id']] = {k: 0 for k in PLAYER_FIELDS[5:]}
    a.update({'player_id': r['player_id'], 'name': r['name'], 'team_id': r['team_id'],
              'number': r['number'], 'pos': r['pos'] or a.get('pos') or ''})
    a['gp'] += 1
    a['gs'] += r['starter'] or 0
    a['sec'] += r['sec'] or 0
    for k in STAT_KEYS:
      a[k] += r[k] or 0
    a['pm'] += r['pm'] or 0
  return [[a[f] for f in PLAYER_FIELDS] for a in agg.values()]


def box_scores(conn: sqlite3.Connection, league: str, seasons: list[str]) -> dict[str, dict[str, Any]]:
  if not seasons:
    return {}
  ph = ','.join('?' for _ in seasons)
  out: dict[str, dict[str, Any]] = {}
  for r in db.rows(conn, f"""SELECT tb.* FROM team_box tb JOIN games g ON g.league = tb.league AND g.game_id = tb.game_id
                            WHERE tb.league = ? AND g.season IN ({ph})""", (league, *seasons)):
    out.setdefault(r['game_id'], {'t': [], 'p': []})['t'].append([r[f] for f in BOX_TEAM_FIELDS])
  for r in db.rows(conn, f"""SELECT pb.* FROM player_box pb JOIN games g ON g.league = pb.league AND g.game_id = pb.game_id
                            WHERE pb.league = ? AND g.season IN ({ph}) ORDER BY pb.starter DESC, pb.sec DESC""",
                   (league, *seasons)):
    out.setdefault(r['game_id'], {'t': [], 'p': []})['p'].append([r[f] for f in BOX_PLAYER_FIELDS])
  return out


# --------------------------------------------------------------------------- league payload
def _compact_game(g: dict[str, Any]) -> dict[str, Any]:
  q = None
  if g.get('quarters'):
    try:
      q = json.loads(g['quarters'])
    except ValueError:
      q = None
  return {'id': g['game_id'], 's': g['season'], 'st': g['stage'], 'c': g['code'] or '', 'd': g['game_date'],
          't': g['game_time'] or '', 'h': g['home_id'], 'a': g['away_id'], 'hs': g['home_score'],
          'as': g['away_score'], 'status': g['status'], 'v': g['venue'] or '', 'att': g['attendance'],
          'cap': g['capacity'], 'q': q, 'box': g['has_box'] or 0}


def league_payload(conn: sqlite3.Connection, league: str, now: dt.datetime) -> dict[str, Any]:
  meta = dict(config.LEAGUE_META[league])
  seasons = _season_order(conn, league)
  games = db.rows(conn, 'SELECT * FROM games WHERE league = ? ORDER BY tip_ts, CAST(game_id AS INTEGER)', (league,))
  by_season: dict[str, list[dict]] = defaultdict(list)
  for g in games:
    by_season[g['season']].append(g)
  model = db.get_kv(conn, f'model:{league}') or {}
  elo = {x['team_id']: x['elo'] for x in model.get('ladder') or []}
  today = now.date().isoformat()
  season_rows = []
  for s in reversed(seasons):
    gl = by_season.get(s['season'], [])
    season_rows.append({
        'season': s['season'], 'name': s['name'] or f'{s["season"]} 賽季', 'status': s['status'], 'ord': s['ord'],
        'n_games': len(gl), 'n_final': sum(1 for g in gl if g['status'] == 'final'),
        'stages': sorted({g['stage'] for g in gl}), 'first_date': gl[0]['game_date'] if gl else None,
    })
  season_rows = [s for s in season_rows if s['n_games']]
  current = season_rows[0]['season'] if season_rows else None
  display = current
  banner = None
  if season_rows and season_rows[0]['n_final'] == 0 and len(season_rows) > 1:
    first = season_rows[0]['first_date'] or ''
    if not first or first > today:
      display = season_rows[1]['season']
      banner = f'{meta["name"]} {current} 賽季尚未開打，以下為 {display} 賽季資料'
  bseasons = box_seasons(conn, league)
  teams = {}
  for t in db.rows(conn, 'SELECT * FROM teams WHERE league = ?', (league,)):
    teams[t['team_id']] = {'id': t['team_id'], 'name': t['name'] or t['short'], 'short': t['short'] or t['name'],
                           'en': (t['en'] or '') if league == 'plg' else '',  # TPBL only has URL slugs
                           'logo': t['logo'] or '', 'color': t['color'] or ''}
  for i, tid in enumerate(sorted(teams, key=lambda x: int(x) if x.isdigit() else 0)):
    if not teams[tid]['color']:
      teams[tid]['color'] = PALETTE[i % len(PALETTE)]
  stand = {s['season']: standings(by_season[s['season']], elo if s['season'] == current else None)
           for s in season_rows}
  tstats = {s: team_stats(conn, league, s) for s in bseasons}
  players = {s: player_totals(conn, league, s) for s in bseasons}
  # Predictions: frozen (pre-game, live) > late estimate (no frozen row) > walk-forward backtest.
  pred: dict[str, dict[str, Any]] = {}
  for gid, b in (model.get('backtest') or {}).items():
    pred[gid] = {'p': b['p_home'], 'm': b['pred_margin'], 'tot': b['pred_total'], 'hp': b['pred_home_pts'],
                 'ap': b['pred_away_pts'], 'conf': b['confidence'], 'kind': 'backtest'}
  for gid, b in (model.get('late') or {}).items():
    pred[gid] = {'p': b['p_home'], 'm': b['pred_margin'], 'tot': b['pred_total'], 'hp': b['pred_home_pts'],
                 'ap': b['pred_away_pts'], 'conf': b['confidence'], 'f': b.get('factors'), 'kind': 'late'}
  for r in db.rows(conn, 'SELECT * FROM predictions WHERE league = ?', (league,)):
    try:
      f = json.loads(r['factors'] or '{}')
    except ValueError:
      f = {}
    pred[r['game_id']] = {'p': r['p_home'], 'm': r['pred_margin'], 'tot': r['pred_total'],
                          'hp': r['pred_home_pts'], 'ap': r['pred_away_pts'], 'conf': r['confidence'],
                          'f': f, 'kind': 'frozen', 'at': r['frozen_at']}
  tune = db.rows(conn, 'SELECT run_at, games, params, prev_params, metrics, prev_metrics, note FROM tune_log '
                       'WHERE league = ? ORDER BY id DESC LIMIT 20', (league,))
  for t in tune:
    for k in ('params', 'prev_params', 'metrics', 'prev_metrics'):
      try:
        t[k] = json.loads(t[k] or '{}')
      except ValueError:
        t[k] = {}
  live = [g for g in games if g['status'] == 'live']
  upcoming = [g for g in games if g['status'] == 'scheduled' and (g['tip_ts'] or '') > iso(now)]
  meta.update({
      'fetched_at': db.get_kv(conn, f'fetched:{league}'), 'fetch_error': db.get_kv(conn, f'fetch_error:{league}'),
      'seasons': season_rows, 'current_season': current, 'display_season': display, 'banner': banner,
      'box_seasons': bseasons, 'teams': teams, 'games': [_compact_game(g) for g in games],
      'standings': stand, 'team_stats': tstats, 'players': players, 'box': box_scores(conn, league, bseasons),
      'pred': pred,
      'model': {k: model.get(k) for k in ('params', 'metrics_all', 'metrics_current', 'metrics_frozen',
                                         'eval_seasons', 'current_season', 'ladder', 'history', 'n_done',
                                         'run_at', 'model_version')},
      'tune_log': tune,
      'today': {'date': today, 'live': len(live), 'games': sum(1 for g in games if g['game_date'] == today),
                'next_tip': upcoming[0]['tip_ts'] if upcoming else None},
  })
  return meta


def default_league(payloads: dict[str, dict[str, Any]]) -> str:
  live = [lg for lg, p in payloads.items() if (p.get('today') or {}).get('live')]
  if live:
    return 'tpbl' if 'tpbl' in live else live[0]
  nxt = [(p['today']['next_tip'], lg) for lg, p in payloads.items() if (p.get('today') or {}).get('next_tip')]
  if nxt:
    return min(nxt)[1]
  return config.DEFAULT_LEAGUE


def build(conn: sqlite3.Connection) -> dict[str, Any]:
  now = now_tw()
  leagues = {lg: league_payload(conn, lg, now) for lg in config.LEAGUES}
  try:
    import release_mgr  # pylint: disable=import-outside-toplevel
    version = release_mgr.current_version()
  except Exception:  # pylint: disable=broad-except
    version = '1.0.0'
  return {
      'generated_at': iso(now), 'version': version,
      'meta': {
          'tool': config.TOOL_NAME, 'campus_id': config.CAMPUS_ID, 'updated_at': iso(now),
          'next_update': next_update_time(now), 'schedule_slots': config.SCHEDULE_SLOTS,
          'default_league': default_league(leagues), 'study_note': config.STUDY_NOTE,
          'box_fields': {'team': BOX_TEAM_FIELDS, 'player': BOX_PLAYER_FIELDS}, 'player_fields': PLAYER_FIELDS,
      },
      'leagues': leagues,
  }


def write(conn: sqlite3.Connection) -> dict[str, Any]:
  snap = build(conn)
  os.makedirs(config.DATA_DIR, exist_ok=True)
  tmp = config.SNAPSHOT_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(snap, f, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
  os.replace(tmp, config.SNAPSHOT_JSON)
  return snap


def load_cached() -> dict[str, Any]:
  """Snapshot from disk; rebuilds it from the DB when missing (never fetches the network)."""
  if os.path.isfile(config.SNAPSHOT_JSON):
    try:
      with open(config.SNAPSHOT_JSON, encoding='utf-8') as f:
        return json.load(f)
    except (OSError, ValueError):
      pass
  conn = db.connect()
  try:
    return write(conn)
  finally:
    conn.close()
