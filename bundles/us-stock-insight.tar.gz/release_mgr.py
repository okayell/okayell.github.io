#!/usr/bin/env python3
"""Version & Release Notes manager for 美股戰情室.

* Tracks project source files against the snapshot of the last published release
  (`data/release_baseline.json`) and computes per-file line diffs.
* Recommends the SemVer bump (MAJOR.MINOR.PATCH, 1.x.x) from the size and kind of change.
* Publishes a release: appends Release Notes to `releases.json`, bumps the version,
  re-snapshots the baseline and rebuilds the GitHub single-file HTML (tools/build_dist.py).

CLI:  python3 release_mgr.py status | init [--exclude PATH ...]
"""
from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import json
import os
import sys
import threading
from typing import Any

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
RELEASES_JSON = os.path.join(ROOT_DIR, 'releases.json')
BASELINE_JSON = os.path.join(ROOT_DIR, 'data', 'release_baseline.json')
_LOCK = threading.RLock()

# path -> (category, description). Unknown files fall back to their folder's category.
FILE_META: dict[str, tuple[str, str]] = {
    'server.py': ('後端服務', 'HTTP 伺服器、JSON API、排程與下載端點'),
    'config.py': ('系統設定', '路徑、埠號、美股夏冬令排程時間與模型參數'),
    'net.py': ('資料抓取', '網路請求、重試與各網站限速'),
    'db.py': ('資料庫', 'SQLite WAL 資料表結構與存取'),
    'updater.py': ('資料抓取', 'NYSE 休市日曆、每日排程更新與歷史行情回補'),
    'ta.py': ('技術分析引擎', '美股技術指標、支撐壓力、型態辨識與白話解說'),
    'scoring.py': ('選股模型', '五大因子百分位評分、每日推薦 20 檔與 Walk-Forward 回測'),
    'morning.py': ('盤前盤後引擎', '美股夏冬令時制、盤前盤後異動、財報日曆、台股 ADR 換算與開盤重判'),
    'etf_hub.py': ('ETF 專區引擎', '48 檔美股核心 ETF 費用率、規模、殖利率與除息日曆彙整'),
    'snapshot.py': ('分析彙整', '全市場指標、推薦、板塊供應鏈、ETF 與盤前盤後 API 快照'),
    'feedback_mailer.py': ('後端服務', '意見回饋儲存與郵件通知寄送模組'),
    'release_mgr.py': ('版本發布', '版號、Release Notes 與待發布變更偵測'),
    'install.sh': ('部署', 'systemd 服務安裝與重啟'),
    'README.md': ('文件', '使用說明、資料來源與架構'),
    'SPEC.md': ('文件', 'API 欄位、單位規範與模組合約'),
    'sources/universe_curated.py': ('資料來源', 'S&P 500、那指 100、費半、ADR 與 48 檔核心 ETF 清單及 GICS 分類'),
    'sources/cnyes_us.py': ('資料來源', '鉅亨網極速美股日 K、四大指數、即時批次報價與匯率'),
    'sources/nasdaq.py': ('資料來源', 'Nasdaq 全市場篩選、季財報、EPS 驚喜、華爾街目標價與機構持股'),
    'sources/chains_us.py': ('資料來源', '16 條美股核心主題與台美連動供應鏈上中下游定義'),
    'sources/news_us.py': ('資料來源', '鉅亨網美股總經與 Google 新聞繁體中文 RSS'),
    'static/index.html': ('頁面骨架', 'SPA 主頁結構、雙色模式切換與免責條款彈窗'),
    'static/app.css': ('視覺樣式', '全站版面、美股綠漲／台股紅漲雙色變數與響應式樣式'),
    'static/js/campus_nav.js': ('前端核心', '開心學園跨館導覽列與靜態意見回饋橋接'),
    'static/js/indicators.js': ('技術分析引擎', '前端週月 K 重取樣與技術指標計算（靜態版）'),
    'static/js/app.js': ('前端核心', '路由、掛載相容 API、美元與億美元格式化、漲跌配色與搜尋'),
    'static/js/kchart.js': ('K 線圖', 'Lightweight Charts K 線、均線、成交量與雙色即時切換'),
    'static/js/releases.js': ('版本發布', '版號徽章與 Release Notes 彈跳視窗'),
    'static/js/page_home.js': ('頁面', '今日推薦首頁：四大指數、美股七巨頭、Top 20 推薦與板塊熱力圖'),
    'static/js/page_morning.js': ('頁面', '盤前盤後戰情：夏冬令時鐘、異動股、財報日曆與台股 ADR 折溢價'),
    'static/js/page_screener.js': ('頁面', '美股選股器：多維度財務與技術條件篩選及 6 大策略範本'),
    'static/js/page_etf.js': ('頁面', 'ETF 專區：48 檔核心美股 ETF、除息日曆與定期定額股息試算機'),
    'static/js/page_stock.js': ('頁面', '個股深度分析：K 線、一鍵技術分析、財報驚喜與華爾街共識'),
    'static/js/page_industry.js': ('頁面', 'GICS 11 大板塊強弱與 16 條台美連動供應鏈上中下游'),
    'static/js/page_picks.js': ('頁面', '績效追蹤：對比 S&P 500 與等權重之 Walk-Forward 歷史回測'),
    'static/js/page_watchlist.js': ('頁面', '自選股清單與七巨頭／費半／ADR 一鍵匯入組合'),
    'static/js/page_about.js': ('頁面', '說明頁：五因子權重、美股夏冬令交易時間、ADR 公式與指標教學'),
    'static/js/page_feedback.js': ('頁面', '意見回饋、問題回報與功能許願頁'),
    'tools/build_dist.py': ('發布工具', 'GitHub Pages 單一 HTML 靜態版打包與洩漏掃描器'),
    'tools/check_us_stock.py': ('開發工具', '美股戰情室資料品質、繁中純度與即時來源涵蓋率 Harness'),
    'tests/test_backend.py': ('測試', '後端選股、快照結構、ADR 換算與 API 單元測試'),
    'tests/test_ta.py': ('測試', '美股技術分析與指標單元測試'),
}
FOLDER_META = {
    'sources/': ('資料來源', '資料來源模組'),
    'static/js/': ('頁面', '前端頁面'),
    'tests/': ('測試', '單元測試'),
    'tools/': ('開發工具', '開發輔助工具'),
}
FEATURE_CATS = {
    '技術分析引擎', '選股模型', '盤前盤後引擎', 'ETF 專區引擎', '頁面', '前端核心',
    'K 線圖', '資料來源', '資料抓取', '分析彙整', '後端服務', '版本發布', '發布工具', '頁面骨架',
}
BUMP_TEXT = {
    'major': '進第 1 位數（X.0.0）：全站架構大改版、跨模組大規模升級',
    'minor': '進第 2 位數（1.X.0）：新增功能、頁面、資料來源或分析能力',
    'patch': '進第 3 位數（1.x.X）：介面微調、文字修正、小 Bug 修復',
}

INITIAL_RELEASE = {
    'version': '1.0.0',
    'date': '2026-11-12',
    'bump': 'major',
    'title': '美股戰情室首發',
    'highlights': [
        '核心美股與 ETF 資料庫：涵蓋 S&P 500、那斯達克 100、費城半導體 SOX、美股七巨頭（Magnificent 7）、台灣與國際重點 ADR 及 48 檔旗艦美股 ETF，'
        '整合近 300 日日 K 行情、季財報、EPS 驚喜與華爾街分析師共識。',
        '五大因子量化推薦與回測：結合財報成長與驚喜（30%）、機構共識與籌碼（25%）、技術趨勢動能（25%）、估值與獲利品質（15%）、低波動穩定度（5%），'
        '每日產出 Top 20 推薦與支撐壓力目標價，並提供對比 S&P 500 之 Walk-Forward 歷史回測。',
        '盤前盤後戰情與台美供應鏈連動：自動判別美股夏令（EDT）／冬令（EST）交易時段，整合盤前盤後異動股、近 7 日重磅財報行事曆、'
        '台股 ADR 折溢價橋接（TSM、UMC、ASX、CHT）及 16 條 AI 半導體與台美連動供應鏈。',
        '個股深度技術分析與雙色介面：TradingView Lightweight Charts K 線搭配「🧠 一鍵技術分析」、美股選股器（6 大策略範本）、'
        'ETF 定期定額與股息試算機，並支援「🟢 美股綠漲／🔴 台股紅漲」一鍵即時切換與單一 HTML 靜態打包。',
    ],
    'files_count': 40,
}


def _meta(rel: str) -> tuple[str, str]:
  if rel in FILE_META:
    return FILE_META[rel]
  for prefix, m in FOLDER_META.items():
    if rel.startswith(prefix):
      return m[0], os.path.basename(rel)
  return '專案檔案', rel


def tracked_paths() -> list[str]:
  out: list[str] = []
  for name in sorted(os.listdir(ROOT_DIR)):
    if name.endswith(('.py', '.sh', '.md')) and os.path.isfile(os.path.join(ROOT_DIR, name)):
      out.append(name)
  for folder, exts in (('sources', ('.py',)), ('static', ('.html', '.css')), ('static/js', ('.js',)),
                       ('tools', ('.py', '.mjs', '.js')), ('tests', ('.py',))):
    d = os.path.join(ROOT_DIR, folder)
    if not os.path.isdir(d):
      continue
    for name in sorted(os.listdir(d)):
      fp = os.path.join(d, name)
      if os.path.isfile(fp) and name.endswith(exts) and name != '__init__.py':
        out.append(f'{folder}/{name}')
  return out


def _read(rel: str) -> str:
  with open(os.path.join(ROOT_DIR, rel), encoding='utf-8', errors='replace') as f:
    return f.read()


def _sha(text: str) -> str:
  return hashlib.sha256(text.encode('utf-8')).hexdigest()


# ---------------------------------------------------------------- storage ----

def load_releases() -> dict[str, Any]:
  with _LOCK:
    try:
      with open(RELEASES_JSON, encoding='utf-8') as f:
        data = json.load(f)
      if isinstance(data, dict) and data.get('releases'):
        return data
    except (OSError, ValueError):
      pass
    data = {'current_version': INITIAL_RELEASE['version'], 'releases': [dict(INITIAL_RELEASE)]}
    save_releases(data)
    return data


def save_releases(data: dict[str, Any]) -> None:
  tmp = RELEASES_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
  os.replace(tmp, RELEASES_JSON)


def current_version() -> str:
  return load_releases().get('current_version') or INITIAL_RELEASE['version']


def snapshot_baseline(version: str, exclude: tuple[str, ...] = ()) -> int:
  files: dict[str, dict[str, Any]] = {}
  for rel in tracked_paths():
    if rel in exclude:
      continue
    text = _read(rel)
    files[rel] = {'sha256': _sha(text), 'lines': len(text.splitlines()), 'content': text}
  os.makedirs(os.path.dirname(BASELINE_JSON), exist_ok=True)
  tmp = BASELINE_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump({'version': version, 'timestamp': dt.datetime.now().isoformat(timespec='seconds'),
               'files': files}, f, ensure_ascii=False)
  os.replace(tmp, BASELINE_JSON)
  return len(files)


def _load_baseline() -> dict[str, Any]:
  if not os.path.isfile(BASELINE_JSON):
    snapshot_baseline(current_version())
  with open(BASELINE_JSON, encoding='utf-8') as f:
    return json.load(f)


def bump_version(ver: str, bump: str) -> str:
  parts = [int(x) for x in ver.lstrip('v').split('.')[:3]]
  while len(parts) < 3:
    parts.append(0)
  major, minor, patch = parts
  if bump == 'major':
    return f'{major + 1}.0.0'
  if bump == 'minor':
    return f'{major}.{minor + 1}.0'
  return f'{major}.{minor}.{patch + 1}'


# ----------------------------------------------------------------- status ----

def _diff_counts(old: str, new: str) -> tuple[int, int]:
  added = removed = 0
  sm = difflib.SequenceMatcher(None, old.splitlines(), new.splitlines(), autojunk=False)
  for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag in ('replace', 'insert'):
      added += j2 - j1
    if tag in ('replace', 'delete'):
      removed += i2 - i1
  return added, removed


def changed_files() -> list[dict[str, Any]]:
  base = _load_baseline().get('files', {})
  out: list[dict[str, Any]] = []
  current = tracked_paths()
  for rel in current:
    text = _read(rel)
    cat, desc = _meta(rel)
    old = base.get(rel)
    if old is None:
      out.append({'path': rel, 'status': 'added', 'status_zh': '新增檔案', 'cat': cat, 'desc': desc,
                  'added_lines': len(text.splitlines()), 'removed_lines': 0})
    elif _sha(text) != old.get('sha256'):
      a, r = _diff_counts(old.get('content') or '', text)
      out.append({'path': rel, 'status': 'modified', 'status_zh': '已修改', 'cat': cat, 'desc': desc,
                  'added_lines': a, 'removed_lines': r})
  for rel, old in base.items():
    if rel not in current:
      cat, desc = _meta(rel)
      out.append({'path': rel, 'status': 'deleted', 'status_zh': '已刪除', 'cat': cat, 'desc': desc,
                  'added_lines': 0, 'removed_lines': old.get('lines', 0)})
  out.sort(key=lambda c: (-(c['added_lines'] + c['removed_lines']), c['path']))
  return out


NON_PRODUCT_CATS = {'測試', '開發工具', '文件'}


def recommend(changed: list[dict[str, Any]]) -> tuple[str | None, str]:
  """Returns (bump, zh reason) from the size and kind of the unreleased changes."""
  if not changed:
    return None, '目前沒有未發布的修改，工作區與最新版本完全一致。'
  product = [c for c in changed if c['cat'] not in NON_PRODUCT_CATS]
  ignored = len(changed) - len(product)
  note = f'（另有 {ignored} 個測試／工具／文件檔案，不影響版號）' if ignored else ''
  if not product:
    return 'patch', f'只修改了測試、開發工具或文件共 {len(changed)} 個檔案，建議進第 3 位數（Patch）。'
  added = sum(c['added_lines'] for c in product)
  removed = sum(c['removed_lines'] for c in product)
  churn = added + removed
  modified = sum(1 for c in product if c['status'] != 'added')
  cats = sorted({c['cat'] for c in product})
  feature = [c for c in product if c['cat'] in FEATURE_CATS]
  new_feature_files = [c for c in feature if c['status'] == 'added']
  big_feature = [c for c in feature if c['added_lines'] >= 40]
  scope = f'產品程式共 {len(product)} 個檔案（{"、".join(cats)}），變動 {churn} 行（+{added} / -{removed}）{note}'
  if (removed >= 400 and churn >= 1200) or removed >= 800 or modified >= 15 or churn >= 4000:
    return 'major', f'{scope}，改寫了大量既有程式，屬於大改版，建議進第 1 位數（Major）。'
  if new_feature_files or big_feature or len(product) >= 4 or churn >= 150:
    why: list[str] = []
    if new_feature_files:
      why.append('新增 ' + '、'.join(c['path'] for c in new_feature_files[:3]))
    if big_feature and not new_feature_files:
      why.append('「' + '、'.join(sorted({c['cat'] for c in big_feature})) + '」有明顯功能擴充')
    tail = f'；{"；".join(why)}' if why else ''
    return 'minor', f'{scope}{tail}，以新增功能為主、沒有大幅改寫既有程式，建議進第 2 位數（Minor）。'
  return 'patch', f'{scope}，屬於細節調整或修正，建議進第 3 位數（Patch）。'


def get_status() -> dict[str, Any]:
  with _LOCK:
    rel = load_releases()
    ver = rel.get('current_version') or INITIAL_RELEASE['version']
    changed = changed_files()
    bump, reason = recommend(changed)
    nexts = {b: bump_version(ver, b) for b in ('patch', 'minor', 'major')}
    cats: list[str] = []
    for c in changed:
      if c['cat'] not in cats:
        cats.append(c['cat'])
    suggested_title = f'更新{"、".join(cats[:3])}（{len(changed)} 個檔案）' if changed else ''
    suggested = [f'[{c["cat"]}] {c["status_zh"]} {c["path"]}：{c["desc"]}'
                 f'（+{c["added_lines"]} / -{c["removed_lines"]} 行）' for c in changed[:8]]
    return {
        'current_version': ver, 'has_changes': bool(changed), 'changed_files': changed,
        'total_added': sum(c['added_lines'] for c in changed),
        'total_removed': sum(c['removed_lines'] for c in changed),
        'recommended_bump': bump, 'recommended_version': nexts.get(bump) if bump else None,
        'recommendation_reason': reason, 'next_versions': nexts, 'bump_text': BUMP_TEXT,
        'suggested_title': suggested_title, 'suggested_highlights': suggested,
        'releases': rel.get('releases', []),
    }


def publish(bump: str = '', title: str = '', highlights: list[str] | None = None) -> dict[str, Any]:
  with _LOCK:
    st = get_status()
    if not st['has_changes']:
      return {'ok': False, 'error': '目前沒有未發布的修改，不需要發布新版本。'}
    chosen = bump if bump in ('patch', 'minor', 'major') else st['recommended_bump']
    new_ver = st['next_versions'][chosen]
    notes = [h.strip() for h in (highlights or []) if h and h.strip()] or st['suggested_highlights']
    entry = {'version': new_ver, 'date': dt.date.today().isoformat(), 'bump': chosen,
             'title': (title or '').strip() or st['suggested_title'] or f'v{new_ver} 更新',
             'highlights': notes, 'files_count': len(st['changed_files'])}
    rel = load_releases()
    rel['current_version'] = new_ver
    rel['releases'].insert(0, entry)
    save_releases(rel)
    snapshot_baseline(new_ver)
  dist = None
  try:
    from tools import build_dist  # pylint: disable=import-outside-toplevel
    dist = build_dist.build(force=True)
  except Exception as e:  # pylint: disable=broad-except
    dist = {'error': f'打包失敗：{e}'}
  return {'ok': True, 'new_version': new_ver, 'release': entry, 'dist': dist, 'status': get_status()}


def main() -> None:
  args = sys.argv[1:]
  if not args or args[0] == 'status':
    st = get_status()
    print(json.dumps({k: v for k, v in st.items() if k != 'releases'}, ensure_ascii=False, indent=2))
    return
  if args[0] == 'init':
    excl_items: list[str] = []
    for a in args[1:]:
      if a == '--exclude':
        continue
      if a.startswith('--exclude='):
        excl_items.append(a.split('=', 1)[1])
      elif not a.startswith('--'):
        excl_items.append(a)
    excl = tuple(excl_items)
    data = load_releases()
    n = snapshot_baseline(data['current_version'], exclude=excl)
    print(f'baseline v{data["current_version"]}: {n} files (excluded: {", ".join(excl) or "-"})')


if __name__ == '__main__':
  main()
