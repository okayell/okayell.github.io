"""Data pipeline for 美股戰情室: first-time backfill + incremental daily / intraday updates.

Run standalone:  python3 updater.py [--quick | --full] [--no-analytics]
The server imports `run_update()` etc. and calls them from its scheduler thread.

Speed design: cnyes daily-K for ~600 symbols (300 trading days) is fetched with a
ThreadPoolExecutor(12) in roughly 30–60 s; Nasdaq fundamentals are cached for
FUND_TTL_DAYS and only pre-fetched for the top FUND_TOP_N names by market cap / turnover
(the rest are fetched on demand when a stock page is opened).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import config
import db
from sources import cnyes_us
from sources import nasdaq
from sources import universe_curated as uc

TZ = dt.timezone(dt.timedelta(hours=8))
CODE_OK = re.compile(r'^[A-Z][A-Z0-9.\-]{0,7}$')
_CJK = re.compile(r'[\u4e00-\u9fff]')
_RUN_LOCK = threading.Lock()


def now_tw() -> dt.datetime:
  return dt.datetime.now(TZ)


def today_tw() -> str:
  return now_tw().date().isoformat()


class Progress:
  """Thread-safe progress state shared with the HTTP server (/api/meta)."""

  def __init__(self) -> None:
    self._lock = threading.Lock()
    self.state: dict[str, Any] = {'state': 'idle', 'step': '', 'progress': 1.0,
                                  'message': '', 'errors': [], 'started_at': None,
                                  'finished_at': None}
    try:
      with open(config.STATE_PATH, encoding='utf-8') as f:
        saved = json.load(f)
      self.state.update({k: saved[k] for k in ('finished_at',) if k in saved})
    except (OSError, ValueError):
      pass

  def set(self, **kw: Any) -> None:
    with self._lock:
      self.state.update(kw)
      snap = dict(self.state)
    try:
      os.makedirs(config.DATA_DIR, exist_ok=True)
      tmp = config.STATE_PATH + '.tmp'
      with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(snap, f, ensure_ascii=False)
      os.replace(tmp, config.STATE_PATH)
    except OSError:
      pass

  def error(self, msg: str) -> None:
    with self._lock:
      errs = (self.state.get('errors') or [])[-19:]
      errs.append(f'{now_tw():%H:%M:%S} {msg[:300]}')
      self.state['errors'] = errs
    print(msg, flush=True)

  def get(self) -> dict[str, Any]:
    with self._lock:
      return dict(self.state)


PROGRESS = Progress()


# ------------------------------------------------------- NYSE calendar ------

def _nth_weekday(year: int, month: int, weekday: int, n: int) -> dt.date:
  """n-th (1-based) weekday of a month; n=-1 means the last one."""
  if n > 0:
    d = dt.date(year, month, 1)
    d += dt.timedelta(days=(weekday - d.weekday()) % 7)
    return d + dt.timedelta(weeks=n - 1)
  d = dt.date(year + (month == 12), month % 12 + 1, 1) - dt.timedelta(days=1)
  return d - dt.timedelta(days=(d.weekday() - weekday) % 7)


def _easter(year: int) -> dt.date:
  """Anonymous Gregorian algorithm."""
  a = year % 19
  b, c = divmod(year, 100)
  d, e = divmod(b, 4)
  f = (b + 8) // 25
  g = (b - f + 1) // 3
  h = (19 * a + b - d - g + 15) % 30
  i, k = divmod(c, 4)
  l = (32 + 2 * e + 2 * i - h - k) % 7
  m = (a + 11 * h + 22 * l) // 451
  month = (h + l - 7 * m + 114) // 31
  day = (h + l - 7 * m + 114) % 31 + 1
  return dt.date(year, month, day)


def _observed(d: dt.date, allow_friday: bool = True) -> dt.date | None:
  if d.weekday() == 5:
    return d - dt.timedelta(days=1) if allow_friday else None
  if d.weekday() == 6:
    return d + dt.timedelta(days=1)
  return d


def nyse_holidays(year: int) -> dict[str, str]:
  """NYSE full-day market holidays {YYYY-MM-DD: name}."""
  hs: dict[dt.date | None, str] = {
      _observed(dt.date(year, 1, 1), allow_friday=False): '元旦',
      _nth_weekday(year, 1, 0, 3): '馬丁路德金恩紀念日',
      _nth_weekday(year, 2, 0, 3): '總統日',
      _easter(year) - dt.timedelta(days=2): '耶穌受難日',
      _nth_weekday(year, 5, 0, -1): '陣亡將士紀念日',
      _observed(dt.date(year, 7, 4)): '美國獨立紀念日',
      _nth_weekday(year, 9, 0, 1): '勞動節',
      _nth_weekday(year, 11, 3, 4): '感恩節',
      _observed(dt.date(year, 12, 25)): '聖誕節',
  }
  if year >= 2022:
    hs[_observed(dt.date(year, 6, 19))] = '六月節（Juneteenth）'
  # New Year's Day of next year falling on Saturday is NOT observed on Dec 31 (NYSE rule).
  return {d.isoformat(): n for d, n in hs.items() if d is not None}


def holidays(year: int | None = None) -> set[str]:
  y = year or now_tw().year
  out: set[str] = set()
  for yy in (y - 1, y, y + 1):
    out |= set(nyse_holidays(yy))
  return out


def is_trading_day(d: dt.date, hol: set[str] | None = None) -> bool:
  """US NYSE trading day (Mon–Fri excluding NYSE market holidays)."""
  if d.weekday() >= 5:
    return False
  hol = hol if hol is not None else set(nyse_holidays(d.year))
  return d.isoformat() not in hol


def is_us_dst(utc: dt.datetime) -> bool:
  """US DST: 2nd Sunday of March 07:00 UTC .. 1st Sunday of November 06:00 UTC."""
  y = utc.year
  start = dt.datetime.combine(_nth_weekday(y, 3, 6, 2), dt.time(7), dt.timezone.utc)
  end = dt.datetime.combine(_nth_weekday(y, 11, 6, 1), dt.time(6), dt.timezone.utc)
  return start <= utc < end


def now_et(now: dt.datetime | None = None) -> dt.datetime:
  utc = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
  off = -4 if is_us_dst(utc) else -5
  return utc.astimezone(dt.timezone(dt.timedelta(hours=off)))


def market_date_for(now: dt.datetime | None = None) -> dt.date:
  """US session date whose data a Taiwan-time run refers to (ET calendar date, minus the
  pre-04:00-ET early-morning hours which still belong to the previous session)."""
  et = now_et(now)
  d = et.date()
  if et.hour < 4:
    d -= dt.timedelta(days=1)
  return d


def last_trading_date(now: dt.datetime | None = None) -> dt.date:
  """Most recent US session that has a final close (regular close 16:00 ET)."""
  et = now_et(now)
  d = et.date()
  if et.hour < 16 or (et.hour == 16 and et.minute < 15):
    d -= dt.timedelta(days=1)
  while not is_trading_day(d):
    d -= dt.timedelta(days=1)
  return d


def is_regular_session(now: dt.datetime | None = None) -> bool:
  et = now_et(now)
  if not is_trading_day(et.date()):
    return False
  hm = et.hour * 60 + et.minute
  return 9 * 60 + 30 <= hm < 16 * 60


# --------------------------------------------------------------- universe ---

def sync_universe(screener: list[dict[str, Any]] | None = None) -> int:
  """Upserts curated entries (+ Nasdaq screener sector / mcap / country) into `stocks`."""
  scr = {r['code']: r for r in (screener or [])}
  now = now_tw().isoformat(timespec='seconds')
  old = {r[0]: r[1:] for r in db.query('SELECT code, name, mcap, country, ipo_year, nasdaq_sector, '
                                       'nasdaq_industry FROM stocks')}
  rows = []
  for e in uc.all_entries():
    code = e['code']
    s = scr.get(code) or {}
    o = old.get(code) or (None,) * 6
    ind, sub = e.get('industry'), e.get('sub_industry')
    if (not ind or ind not in config.SECTORS) and e.get('type') != 'ETF' and s.get('sector'):
      ind, sub = uc.sector_from_nasdaq(s.get('sector', ''), s.get('industry', ''))
    name = e.get('name') or o[0] or e.get('en_name') or code
    rows.append((code, name, e.get('en_name') or s.get('en_name') or '', e.get('market') or 'NASDAQ',
                 e.get('type') or '股票', ind or '工業', sub or '其他',
                 json.dumps(e.get('index_tags') or [], ensure_ascii=False),
                 s.get('country') or o[2] or '', s.get('ipo_year') or o[3] or '',
                 s.get('sector') or o[4] or '', s.get('industry') or o[5] or '',
                 s.get('mcap') if s.get('mcap') else o[1], now))
  db.upsert_many('stocks', ('code', 'name', 'en_name', 'market', 'type', 'industry', 'sub_industry',
                            'index_tags', 'country', 'ipo_year', 'nasdaq_sector', 'nasdaq_industry',
                            'mcap', 'updated'), rows)
  if scr:
    q = []
    for code, s in scr.items():
      if code in uc.STOCK_CODES or code in uc.ETF_CODES:
        q.append((code, None, s.get('close'), s.get('chg'), s.get('pct'), None, None, None,
                  s.get('vol'), None, s.get('mcap'), now, 'nasdaq'))
    db.upsert_many('quotes', ('code', 'date', 'close', 'chg', 'pct', 'open', 'high', 'low', 'vol',
                              'prev', 'mcap', 'quote_time', 'source'), q)
  return len(rows)


def task_screener() -> list[dict[str, Any]]:
  try:
    scr = nasdaq.screener_stocks()
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'Nasdaq 全市場快照取得失敗：{e!r}')
    return []
  if len(scr) < 1000:
    PROGRESS.error(f'GUARD: Nasdaq screener 僅 {len(scr)} 筆，保留既有市值與產業資料')
    return []
  return scr


# ------------------------------------------------------------- daily bars ---

def _save_bars(code: str, bars: list[list], table: str = 'daily', key: str = 'code') -> int:
  if not bars:
    return 0
  return db.upsert_many(table, (key, 'date', 'open', 'high', 'low', 'close', 'vol'),
                        [(code, *b[:6]) for b in bars])


def _fetch_one(code: str, days: int) -> tuple[str, list[list], dict[str, Any]]:
  try:
    bars, q = cnyes_us.history(code, days, retries=2)
    if bars:
      return code, bars, q
  except Exception:  # pylint: disable=broad-except
    pass
  try:   # Nasdaq fallback
    to = dt.date.today()
    fr = to - dt.timedelta(days=days)
    ac = 'etf' if code in uc.ETF_CODES else 'stocks'
    return code, nasdaq.historical(code, fr.isoformat(), to.isoformat(), ac, limit=min(days, 500)), {}
  except Exception:  # pylint: disable=broad-except
    return code, [], {}


def task_indices(days: int) -> int:
  n = 0
  for key, info in config.INDICES.items():
    try:
      bars, _ = cnyes_us.history(info['cnyes'], days)
      n += _save_bars(key, bars, 'index_daily', 'name')
    except Exception as e:  # pylint: disable=broad-except
      PROGRESS.error(f'指數 {info["code"]} 取得失敗：{e!r}')
  try:
    bars, _ = cnyes_us.history(config.FX_CNYES, days)
    n += _save_bars('usdtwd', bars, 'index_daily', 'name')
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'美元／台幣匯率取得失敗：{e!r}')
  return n


def task_daily_bars(days: int) -> dict[str, Any]:
  """Parallel cnyes daily-K for every tracked symbol; returns stats incl. GUARD info."""
  codes = [e['code'] for e in uc.all_entries()]
  t0 = time.time()
  done = ok = 0
  latest: dict[str, int] = {}
  names: dict[str, str] = {}
  with ThreadPoolExecutor(max_workers=config.FETCH_WORKERS) as ex:
    for code, bars, q in ex.map(lambda c: _fetch_one(c, days), codes):
      done += 1
      if bars:
        ok += 1
        _save_bars(code, bars)
        latest[bars[-1][0]] = latest.get(bars[-1][0], 0) + 1
      zh = (q or {}).get('zh_name')
      if zh and _CJK.search(zh):
        names[code] = zh
      if done % 40 == 0:
        PROGRESS.set(progress=round(0.1 + 0.5 * done / len(codes), 3),
                     message=f'日 K 線 {done}/{len(codes)}（{time.time() - t0:.0f} 秒）')
  _apply_zh_names(names)
  top_date = max(latest, key=lambda d: (d, latest[d])) if latest else None
  return {'ok': ok, 'total': len(codes), 'latest_date': top_date,
          'latest_count': latest.get(top_date, 0) if top_date else 0,
          'seconds': round(time.time() - t0, 1)}


def _apply_zh_names(names: dict[str, str]) -> None:
  """Fills cnyes `200009` Chinese names for symbols whose curated name has no Chinese."""
  if not names:
    return
  upd = []
  for code, zh in names.items():
    e = uc.get(code) or {}
    cur = e.get('name') or ''
    if _CJK.search(cur):
      continue
    brand = (e.get('en_name') or code).split(',')[0].replace(' Inc.', '').replace(' Corporation', '')
    brand = re.sub(r'\s+(Inc|Corp|Corporation|Company|Co|Ltd|plc|N\.V\.|S\.A\.)\.?$', '', brand).strip()
    upd.append((f'{zh} {brand}'[:40], code))
  for name, code in upd:
    db.execute('UPDATE stocks SET name=? WHERE code=?', (name, code))


# ------------------------------------------------------------ fundamentals --

def task_fundamentals(top_n: int = config.FUND_TOP_N) -> int:
  """Refreshes stale Nasdaq fundamentals for the top-N equities by mcap/turnover + all ETFs."""
  import snapshot  # pylint: disable=import-outside-toplevel
  mc = {c: m or 0 for c, m in db.query('SELECT code, mcap FROM stocks')}
  last = db.query_one('SELECT MAX(date) FROM daily')
  val: dict[str, float] = {}
  if last and last[0]:
    for c, cl, v in db.query('SELECT code, close, vol FROM daily WHERE date=?', (last[0],)):
      val[c] = (cl or 0) * (v or 0) / 1e8
  eq = [c for c in uc.STOCK_CODES]
  by_mcap = sorted(eq, key=lambda c: -(mc.get(c) or 0))[:top_n]
  by_val = sorted(eq, key=lambda c: -(val.get(c) or 0))[:top_n // 2]
  must = list(uc.MAG7) + list(uc.ADR_MAP)
  targets: list[tuple[str, bool]] = []
  seen: set[str] = set()
  for c in must + by_mcap + by_val:
    if c not in seen:
      seen.add(c)
      targets.append((c, False))
  targets += [(c, True) for c in sorted(uc.ETF_CODES)]
  ttl = config.FUND_TTL_DAYS * 86400
  jobs = []
  for c, is_etf in targets:
    kinds = ('summary', 'div') if is_etf else snapshot.FUND_KINDS
    for k in kinds:
      if db.fund_age(c, k) > ttl:
        jobs.append((c, is_etf, (k,)))
  t0 = time.time()
  done = 0
  with ThreadPoolExecutor(max_workers=config.FUND_WORKERS) as ex:
    for _ in ex.map(lambda j: snapshot.fetch_fundamentals(*j), jobs):
      done += 1
      if done % 40 == 0:
        PROGRESS.set(message=f'基本面快取 {done}/{len(jobs)}（{time.time() - t0:.0f} 秒）')
  return len(jobs)


def task_side_data() -> None:
  import snapshot  # pylint: disable=import-outside-toplevel
  try:
    snapshot.fetch_earnings_calendar(7)
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'財報行事曆取得失敗：{e!r}')
  try:
    snapshot.market_news_cached(max_age=0)
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'市場新聞取得失敗：{e!r}')


# ------------------------------------------------------------------ locks ---

def _try_file_lock():
  """Cross-process exclusive lock so CLI runs and the server never overlap."""
  import fcntl  # pylint: disable=import-outside-toplevel
  os.makedirs(config.DATA_DIR, exist_ok=True)
  fh = open(config.LOCK_PATH, 'a+')  # pylint: disable=consider-using-with
  try:
    fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
  except OSError:
    fh.close()
    return None
  return fh


def _release_file_lock(fh) -> None:
  import fcntl  # pylint: disable=import-outside-toplevel
  try:
    fcntl.flock(fh, fcntl.LOCK_UN)
  finally:
    fh.close()


def is_running_here() -> bool:
  return _RUN_LOCK.locked()


def lock_held_elsewhere() -> bool:
  if is_running_here():
    return False
  fh = _try_file_lock()
  if fh is None:
    return True
  _release_file_lock(fh)
  return False


class _Run:
  """Context manager acquiring both the in-process and the cross-process lock."""

  def __init__(self) -> None:
    self.fh = None
    self.ok = False

  def __enter__(self) -> '_Run':
    if not _RUN_LOCK.acquire(blocking=False):
      return self
    self.fh = _try_file_lock()
    if self.fh is None:
      _RUN_LOCK.release()
      return self
    self.ok = True
    return self

  def __exit__(self, *exc: Any) -> None:
    if not self.ok:
      return
    PROGRESS.set(state='idle', step='', progress=1.0,
                 finished_at=now_tw().isoformat(timespec='seconds'))
    _release_file_lock(self.fh)
    _RUN_LOCK.release()


# ------------------------------------------------------------------ runs ----

def _analytics(is_intraday: bool | None = None, quote_time: str | None = None,
               build_dist: bool = True) -> dict[str, Any]:
  PROGRESS.set(step='計算指標與推薦', message='')
  t0 = time.time()
  try:
    import snapshot  # pylint: disable=import-outside-toplevel
    payloads = snapshot.build_all(progress=PROGRESS, is_intraday=is_intraday, quote_time=quote_time)
    if not payloads:
      PROGRESS.error('分析計算略過：資料庫尚無日 K 資料')
      return {'ok': False}
    if build_dist:
      PROGRESS.set(step='打包 GitHub 靜態版', message='')
      try:
        from tools import build_dist as bd  # pylint: disable=import-outside-toplevel
        bd.build(force=True)
      except Exception as e:  # pylint: disable=broad-except
        PROGRESS.error(f'GitHub 靜態版打包失敗：{e!r}')
    PROGRESS.set(message=f'分析完成（{time.time() - t0:.0f} 秒）')
    an = db.get_kv('analytics', {}) or {}
    return {'ok': True, 'data_date': an.get('data_date'), 'counts': an.get('counts'),
            'seconds': round(time.time() - t0, 1)}
  except Exception as e:  # pylint: disable=broad-except
    traceback.print_exc()
    PROGRESS.error(f'分析計算失敗：{e!r}')
    return {'ok': False, 'error': repr(e)}


def run_analytics_only() -> dict[str, Any]:
  """Rebuilds snapshots from the DB only (no network). Returns a status dict."""
  with _Run() as run:
    if not run.ok:
      return {'ok': False, 'busy': True}
    db.init()
    PROGRESS.set(state='running', step='計算指標與推薦', progress=0.0, errors=[])
    return _analytics()


def run_update(reason: str = '', quick: bool = False, analytics: bool = True,
               full: bool = False) -> bool:
  """Fetches bars / screener / fundamentals, then rebuilds analytics. False if busy/guarded."""
  with _Run() as run:
    if not run.ok:
      return False
    try:
      db.init()
      first = db.query_one('SELECT COUNT(DISTINCT date) FROM daily')[0] < 60
      state = 'backfill' if first else 'running'
      PROGRESS.set(state=state, step='下載資料', progress=0.0, errors=[],
                   started_at=now_tw().isoformat(timespec='seconds'), message=reason)
      PROGRESS.set(step='Nasdaq 全市場快照', progress=0.03)
      scr = task_screener()
      sync_universe(scr)
      days = int(config.BACKFILL_DAYS * 1.5) if (first or full) else 20
      PROGRESS.set(step='四大指數與匯率', progress=0.06)
      task_indices(max(days, 400) if first or full else days)
      PROGRESS.set(step='下載日 K 線（12 執行緒）', progress=0.1)
      prev_count = int(db.get_kv('last_bar_count', 0) or 0)
      st = task_daily_bars(days)
      PROGRESS.set(message=f'日 K 完成 {st["ok"]}/{st["total"]} 檔（{st["seconds"]} 秒）')
      guard = max(100, int(prev_count * 0.6))
      if st['latest_count'] < guard:
        PROGRESS.error(f'GUARD: 最新交易日僅 {st["latest_count"]} 檔有報價（門檻 {guard}），保留既有快照')
        return False
      db.set_kv('last_bar_count', st['latest_count'])
      task_side_data()
      if analytics:
        _analytics(build_dist=quick or not first)
      if quick:
        return True
      PROGRESS.set(step='基本面快取（前 160 大＋ETF）', progress=0.75)
      n = task_fundamentals()
      if analytics and (n or first):
        _analytics()
      return True
    except Exception as e:  # pylint: disable=broad-except
      traceback.print_exc()
      PROGRESS.error(f'更新失敗：{e!r}')
      return False


def run_morning_update(reason: str = '') -> bool:
  """Pre-market: news, earnings calendar, extended-hours movers, ADR bridge and re-judgment."""
  with _Run() as run:
    if not run.ok:
      return False
    try:
      db.init()
      PROGRESS.set(state='running', step='盤前戰情：新聞、財報與盤前異動', progress=0.3, message=reason)
      try:
        bars, _ = cnyes_us.history(config.FX_CNYES, 10)
        _save_bars('usdtwd', bars, 'index_daily', 'name')
      except Exception:  # pylint: disable=broad-except
        pass
      import snapshot  # pylint: disable=import-outside-toplevel
      snapshot.morning_cached(force=True)
      return True
    except Exception as e:  # pylint: disable=broad-except
      traceback.print_exc()
      PROGRESS.error(f'盤前戰情更新失敗：{e!r}')
      return False


def run_intraday_update(reason: str = '') -> bool:
  """US regular session: batch cnyes quotes -> today's provisional bars -> analytics."""
  with _Run() as run:
    if not run.ok:
      return False
    try:
      db.init()
      et = now_et()
      if not is_trading_day(et.date()):
        return False
      PROGRESS.set(state='running', step='下載美股盤中即時報價', progress=0.1, errors=[],
                   started_at=now_tw().isoformat(timespec='seconds'), message=reason)
      codes = [e['code'] for e in uc.all_entries()]
      qs = cnyes_us.quotes(codes)
      prev_count = int(db.get_kv('last_bar_count', 0) or 0)
      guard = max(100, int(prev_count * 0.6))
      if len(qs) < guard:
        PROGRESS.error(f'GUARD: 盤中報價僅 {len(qs)} 檔（門檻 {guard}），保留既有快照')
        return False
      rows = []
      today = et.date().isoformat()
      for code, q in qs.items():
        if not q.get('close') or not q.get('time'):
          continue
        qd = cnyes_us.ts_to_date(q['time'] - 5 * 3600)   # quote epoch -> US calendar date
        if qd != today:
          continue
        o = q.get('open') or q['close']
        rows.append((code, today, o, max(q.get('high') or o, o, q['close']),
                     min(q.get('low') or o, o, q['close']), q['close'], q.get('vol') or 0))
      if len(rows) < guard:
        PROGRESS.error(f'GUARD: 今日盤中有效報價僅 {len(rows)} 檔，可能尚未開盤')
        return False
      db.upsert_many('daily', ('code', 'date', 'open', 'high', 'low', 'close', 'vol'), rows)
      iq = cnyes_us.quotes([i['cnyes'] for i in config.INDICES.values()] + [config.FX_CNYES])
      irows = []
      for key, info in list(config.INDICES.items()) + [('usdtwd', {'cnyes': config.FX_CNYES})]:
        q = iq.get(info['cnyes']) or {}
        if q.get('close'):
          o = q.get('open') or q['close']
          irows.append((key, today, o, max(q.get('high') or o, o, q['close']),
                        min(q.get('low') or o, o, q['close']), q['close'], q.get('vol') or 0))
      db.upsert_many('index_daily', ('name', 'date', 'open', 'high', 'low', 'close', 'vol'), irows)
      _analytics(is_intraday=True, quote_time=f'{et:%Y-%m-%d %H:%M} ET')
      return True
    except Exception as e:  # pylint: disable=broad-except
      traceback.print_exc()
      PROGRESS.error(f'盤中行情更新失敗：{e!r}')
      return False


def main() -> None:
  ap = argparse.ArgumentParser(description='美股戰情室資料更新')
  ap.add_argument('--quick', action='store_true', help='bars + analytics only (skip fundamentals)')
  ap.add_argument('--full', action='store_true', help='full 300-day backfill')
  ap.add_argument('--no-analytics', action='store_true')
  ap.add_argument('--analytics-only', action='store_true')
  ap.add_argument('--morning', action='store_true')
  args = ap.parse_args()
  t0 = time.time()
  if args.analytics_only:
    print(run_analytics_only())
  elif args.morning:
    run_morning_update(reason='CLI')
  else:
    run_update(reason='CLI', quick=args.quick, analytics=not args.no_analytics, full=args.full)
  st = PROGRESS.get()
  print(f'done in {time.time() - t0:.0f}s; errors={len(st.get("errors") or [])}')
  for e in st.get('errors') or []:
    print('  ', e)


if __name__ == '__main__':
  main()
