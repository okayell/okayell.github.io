"""美股夏／冬令開收盤時鐘、盤前盤後異動、財報行事曆、事件知識圖譜、台股 ADR 折溢價橋接與推薦股動作重判。"""
from __future__ import annotations

from collections.abc import Callable
import datetime as dt
import hashlib
import math
import re
from typing import Any

TZ_TW = dt.timezone(dt.timedelta(hours=8))

ADR_RATIO: dict[str, int] = {
  'TSM': 5,
  'UMC': 5,
  'ASX': 2,
  'CHT': 10,
}

_FALLBACK_ADR_MAP: dict[str, dict[str, Any]] = {
  'TSM': {'name': '台積電 ADR', 'tw_code': '2330', 'tw_name': '台積電', 'ratio': 5},
  'UMC': {'name': '聯電 ADR', 'tw_code': '2303', 'tw_name': '聯電', 'ratio': 5},
  'ASX': {'name': '日月光 ADR', 'tw_code': '3711', 'tw_name': '日月光投控', 'ratio': 2},
  'CHT': {'name': '中華電 ADR', 'tw_code': '2412', 'tw_name': '中華電', 'ratio': 10},
}

CATEGORY_LABELS: dict[str, str] = {
  'fed_macro': '🏦 聯準會與總經數據',
  'tech_giant': '🚀 科技巨頭與 AI 算力',
  'tariff_trade': '🌐 關稅與貿易政策',
  'geopolitics': '⚔️ 地緣政治與能源',
  'earnings': '📊 重磅財報與企業事件',
}

POLARITY_ZH: dict[str, str] = {
  'bull': '偏多催化',
  'bear': '偏空警戒',
  'mixed': '多空分歧',
}

VALID_CHAIN_IDS: frozenset[str] = frozenset({
  'AI_GPU',
  'SEMI_EQUIP',
  'MEMORY',
  'FOUNDRY_ADR',
  'NETWORK_OPTICS',
  'CLOUD_SOFTWARE',
  'CYBERSEC',
  'EV_AUTONOMY',
  'ROBOTICS',
  'POWER_GRID',
  'GLP1_BIOTECH',
  'FINTECH_PAY',
  'ECOMMERCE_ADS',
  'SPACE_DEFENSE',
  'ENERGY_OIL',
  'CONSUMER_BRANDS',
})

BULL_WORDS: tuple[str, ...] = (
  '大漲', '勁揚', '飆漲', '創高', '新高', '優於預期', '上修', '調升', '擴產', '大單',
  '追單', '滿載', '利多', '受惠', '突破', '降息', '停火', '和談', '緩解', '豁免',
  '強勁', '成長', '翻倍', '加碼', '看旺', '報喜', '助攻', '反彈', '回升', '增溫',
  '庫藏股', '軟著陸', 'beat', 'surge', 'rally', 'upgrade', 'record high', 'raises guidance',
)

BEAR_WORDS: tuple[str, ...] = (
  '大跌', '重挫', '暴跌', '崩跌', '跳水', '低於預期', '不如預期', '下修', '砍單', '調降',
  '裁員', '利空', '衝擊', '承壓', '破底', '升息', '通膨升溫', '開戰', '空襲', '飛彈',
  '封鎖', '制裁', '禁令', '加徵關稅', '關稅威脅', '衰退', '虧損', '延後', '過熱', '泡沫',
  '罷工', '違約', '警告', '示警', 'miss', 'plunge', 'slump', 'downgrade', 'cuts guidance', 'layoff',
)

_TICKER_TOKEN_RE = re.compile(r'\b([A-Z]{2,5}(?:\.[A-Z])?)\b')
_COMMON_EN_STOPWORDS: frozenset[str] = frozenset({
  'AI', 'US', 'USA', 'FED', 'CPI', 'PCE', 'GDP', 'PMI', 'ISM', 'ETF', 'ADR', 'EPS',
  'CEO', 'CFO', 'IPO', 'OPEC', 'WTI', 'FDA', 'SEC', 'DOJ', 'FTC', 'EU', 'UK', 'UN',
  'NATO', 'BMO', 'AMC', 'YOY', 'QOQ', 'IT', 'PC', 'TV', 'EV', 'NEW', 'TOP', 'ALL',
  'FOR', 'AND', 'THE', 'WITH', 'FROM', 'INTO', 'OVER', 'AFTER', 'BEFORE',
})

# 五大類美股事件知識圖譜規則（對應 16 條美股供應鏈 ID 與核心美股代號）
EVENT_RULES: list[dict[str, Any]] = [
  {
    'id': 'fed_rates_inflation',
    'category': 'fed_macro',
    'kw': (
      '聯準會', 'Fed', 'FOMC', '鮑爾', 'Powell', '降息', '升息', '利率決策', '點陣圖',
      'CPI', 'PCE', '通膨', '美債殖利率', '公債殖利率', '聯邦資金利率',
      'rate cut', 'rate hike', 'inflation', 'treasury yield', 'hawkish', 'dovish',
    ),
    'default_polarity': 'mixed',
    'dovish_kw': ('降息', '偏鴿', '通膨降溫', '通膨放緩', '殖利率回落', '殖利率下滑', 'rate cut', 'dovish', 'cooling inflation'),
    'hawkish_kw': ('升息', '偏鷹', '通膨升溫', '通膨反彈', '延後降息', '殖利率飆', '殖利率攀升', 'rate hike', 'hawkish', 'hot inflation'),
    'explain_dovish': '通膨趨緩或聯準會釋出偏鴿降息訊號，壓低美債長端殖利率，有助提升 AI 科技、雲端軟體與金融科技股的估值擴張空間。',
    'explain_hawkish': '通膨黏著或聯準會態度偏鷹推升美債殖利率，短線對高估值雲端軟體與非必需消費構成折現率逆風，大型銀行則受惠淨利差維持高檔。',
    'sectors_dovish': [
      {'name': 'AI 算力與科技成長', 'chain_id': 'AI_GPU', 'dir': 'beneficiary',
       'reason': '折現率下行有利高成長半導體與 AI 基礎設施評價提升'},
      {'name': '雲端與企業軟體', 'chain_id': 'CLOUD_SOFTWARE', 'dir': 'beneficiary',
       'reason': '資金成本降低提振企業雲端轉型與軟體訂閱預算'},
      {'name': '支付與金融科技', 'chain_id': 'FINTECH_PAY', 'dir': 'beneficiary',
       'reason': '消費信貸壓力舒緩，跨境支付與數位金融交易量回溫'},
    ],
    'stocks_dovish': [
      ('NVDA', 'beneficiary', 'AI 算力核心權值龍頭'),
      ('MSFT', 'beneficiary', '雲端與企業 AI 平台龍頭'),
      ('GOOGL', 'beneficiary', '雲端與搜尋廣告巨頭'),
      ('CRM', 'beneficiary', '企業雲端軟體指標'),
      ('NOW', 'beneficiary', '工作流自動化 SaaS 龍頭'),
      ('V', 'beneficiary', '全球支付網路龍頭'),
      ('TLT', 'beneficiary', '長天期美債殖利率下行直接受惠'),
    ],
    'sectors_hawkish': [
      {'name': '雲端與高估值軟體', 'chain_id': 'CLOUD_SOFTWARE', 'dir': 'victim',
       'reason': '長端殖利率上行壓抑高本益比軟體股評價倍數'},
      {'name': '消費品牌與耐久財', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'victim',
       'reason': '高利率環境延長壓抑房貸與非必需消費動能'},
      {'name': '銀行與支付金融', 'chain_id': 'FINTECH_PAY', 'dir': 'beneficiary',
       'reason': '利率維持高檔支撐大型商業銀行利息淨收益'},
    ],
    'stocks_hawkish': [
      ('JPM', 'beneficiary', '美國最大商業銀行受惠高利差'),
      ('BAC', 'beneficiary', '存放款利差具防禦韌性'),
      ('CRM', 'victim', '高估值軟體對利率敏感'),
      ('SNOW', 'victim', '雲端資料平台估值受殖利率牽動'),
      ('TSLA', 'victim', '車貸利率偏高影響終端購車負擔'),
      ('TLT', 'victim', '長天期公債價格隨殖利率走升承壓'),
    ],
  },
  {
    'id': 'macro_jobs_growth',
    'category': 'fed_macro',
    'kw': (
      '非農', '失業率', '就業報告', '初領失業金', 'GDP', '零售銷售', '消費者信心',
      'PMI', 'ISM', '製造業指數', '經濟衰退', '軟著陸', '景氣',
      'payroll', 'unemployment', 'retail sales', 'recession', 'soft landing', 'consumer confidence',
    ),
    'default_polarity': 'mixed',
    'explain': '美國就業市場與零售消費數據直接反映內需韌性與軟著陸機率，牽動電商零售、消費品牌與支付網路的營收展望。',
    'sectors': [
      {'name': '消費品牌與大型量販', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'same',
       'reason': '家庭實質所得與就業穩定度直接決定零售終端銷售表現'},
      {'name': '電商與數位廣告', 'chain_id': 'ECOMMERCE_ADS', 'dir': 'same',
       'reason': '線上消費熱度與企業行銷預算隨總體景氣同步擴縮'},
      {'name': '支付與金融科技', 'chain_id': 'FINTECH_PAY', 'dir': 'same',
       'reason': '刷卡總額與跨境旅遊消費直接反映終端需求強弱'},
    ],
    'stocks': [
      ('AMZN', 'same', '北美電商與雲端消費景氣指標'),
      ('WMT', 'same', '美國民生消費與量販通路龍頭'),
      ('COST', 'same', '會員制倉儲零售景氣溫度計'),
      ('V', 'same', '全球消費刷卡交易量指標'),
      ('MA', 'same', '跨境旅遊與消費支付指標'),
      ('META', 'same', '企業數位廣告投放需求代表'),
    ],
  },
  {
    'id': 'ai_gpu_datacenter',
    'category': 'tech_giant',
    'kw': (
      '輝達', 'NVIDIA', 'NVDA', '黃仁勳', 'Blackwell', 'Rubin', 'AI 晶片', 'AI晶片',
      'AI 算力', 'AI算力', 'AI 伺服器', 'AI伺服器', '資本支出', 'CapEx', '超微', 'AMD',
      '博通', 'Broadcom', 'AVGO', 'ASIC', 'OpenAI', '資料中心', 'CPO', '光通訊',
      'data center', 'hyperscaler', 'GPU',
    ),
    'default_polarity': 'bull',
    'explain': '北美四大雲端巨頭（CSP）AI 資本支出與次世代 GPU／客製化 ASIC 進展，是驅動 AI 晶片、高速光通訊網通與資料中心電力基建的核心引擎。',
    'sectors': [
      {'name': 'AI 算力與加速器生態系', 'chain_id': 'AI_GPU', 'dir': 'same',
       'reason': '雲端資料中心擴建直接拉動訓練與推論 GPU／ASIC 出貨動能'},
      {'name': 'AI 網通與光通訊', 'chain_id': 'NETWORK_OPTICS', 'dir': 'same',
       'reason': '萬卡級 AI 叢集推升 800G／1.6T 乙太網交換器與光收發模組需求'},
      {'name': 'AI 電力與電網基建', 'chain_id': 'POWER_GRID', 'dir': 'same',
       'reason': '高密度算力機櫃耗電激增，帶動核能供電、變壓器與液冷溫控設備'},
    ],
    'stocks': [
      ('NVDA', 'same', 'AI GPU 與加速運算絕對龍頭'),
      ('AVGO', 'same', '客製化 AI ASIC 與高速交換晶片龍頭'),
      ('AMD', 'same', '資料中心 MI 系列 AI 加速器供應商'),
      ('TSM', 'same', '全球 AI 晶片獨家先進製程代工'),
      ('ANET', 'same', '雲端 AI 資料中心高速交換器龍頭'),
      ('MRVL', 'same', '光通訊 DSP 與客製化雲端晶片大廠'),
      ('VRT', 'same', '資料中心電力管理與液冷基礎建設指標'),
      ('CEG', 'same', '無碳核電支援大型資料中心長約供電'),
    ],
  },
  {
    'id': 'semi_foundry_memory',
    'category': 'tech_giant',
    'kw': (
      '台積電', 'TSMC', 'TSM', '魏哲家', '艾司摩爾', 'ASML', 'EUV', 'CoWoS',
      '先進封裝', '先進製程', '2奈米', '晶圓代工', '美光', 'Micron', 'HBM',
      'DRAM', 'NAND', '記憶體', '應用材料', '科林研發', '半導體設備', '費半', 'SOX',
    ),
    'default_polarity': 'bull',
    'explain': '先進晶圓代工、CoWoS 封裝擴產與 HBM 高頻寬記憶體供需吃緊，直接牽動台灣 ADR、半導體製程設備及記憶體族群獲利週期。',
    'sectors': [
      {'name': '晶圓代工與台灣 ADR', 'chain_id': 'FOUNDRY_ADR', 'dir': 'same',
       'reason': '先進製程定價權與先進封裝產能決定全球高階晶片供給'},
      {'name': '半導體設備與材料', 'chain_id': 'SEMI_EQUIP', 'dir': 'same',
       'reason': '晶圓廠資本支出直接轉化為曝光、蝕刻、薄膜沉積與檢測設備訂單'},
      {'name': '記憶體與 HBM', 'chain_id': 'MEMORY', 'dir': 'same',
       'reason': 'HBM 產能排擠效應支撐企業級 DRAM 與儲存記憶體合約報價'},
    ],
    'stocks': [
      ('TSM', 'same', '全球先進晶圓代工與 CoWoS 龍頭'),
      ('ASML', 'same', 'EUV 極紫外光曝光機獨家供應商'),
      ('MU', 'same', '美系 HBM 與高階 DRAM 記憶體龍頭'),
      ('AMAT', 'same', '全球半導體製程設備解決方案龍頭'),
      ('LRCX', 'same', '先進蝕刻與晶圓清洗設備大廠'),
      ('KLAC', 'same', '半導體製程良率檢測與量測龍頭'),
      ('ASX', 'same', '全球半導體封裝測試龍頭 ADR'),
      ('UMC', 'same', '成熟與特殊製程晶圓代工 ADR'),
    ],
  },
  {
    'id': 'cloud_cyber_platform',
    'category': 'tech_giant',
    'kw': (
      '微軟', 'Microsoft', 'MSFT', 'Azure', 'Google', 'Alphabet', 'GOOGL', 'Gemini',
      'AWS', '亞馬遜雲端', '甲骨文', 'Oracle', 'ORCL', '雲端運算', 'SaaS', 'AI 代理',
      'Agentic', '資安', '駭客', '網攻', '勒索軟體', 'CrowdStrike', 'Palo Alto', 'cybersecurity',
    ),
    'default_polarity': 'bull',
    'explain': '雲端巨頭 AI 平台商業化變現、企業軟體導入 AI 代理與全球資安防護升級，驅動大型科技平台與經常性訂閱軟體穩健成長。',
    'sectors': [
      {'name': '雲端與企業軟體', 'chain_id': 'CLOUD_SOFTWARE', 'dir': 'same',
       'reason': 'AI 助手與雲端資料庫工作負載推升企業客戶單價與續約率'},
      {'name': '資安防護生態系', 'chain_id': 'CYBERSEC', 'dir': 'same',
       'reason': '雲端攻擊面擴大促使企業優先配置零信任與端點 AI 偵測預算'},
      {'name': '電商與數位廣告', 'chain_id': 'ECOMMERCE_ADS', 'dir': 'same',
       'reason': '生成式 AI 強化廣告精準投放與搜尋商業變現效率'},
    ],
    'stocks': [
      ('MSFT', 'same', 'Azure 雲端與企業 Copilot 生態系龍頭'),
      ('GOOGL', 'same', '搜尋廣告與 Google Cloud AI 雙引擎'),
      ('AMZN', 'same', 'AWS 雲端基礎設施全球市占第一'),
      ('ORCL', 'same', 'OCI 雲端算力租賃與企業資料庫巨頭'),
      ('PANW', 'same', '平台化網路資安整合解決方案龍頭'),
      ('CRWD', 'same', '雲端原生端點資安防護指標'),
      ('PLTR', 'same', '企業與國防 AI 決策軟體平台代表'),
    ],
  },
  {
    'id': 'ev_robotics_device',
    'category': 'tech_giant',
    'kw': (
      '特斯拉', 'Tesla', 'TSLA', '馬斯克', 'Musk', 'Robotaxi', 'FSD', '自駕車', '自動駕駛',
      '電動車', 'Optimus', '人形機器人', '機器人', '工業自動化', '蘋果', 'Apple', 'AAPL',
      'iPhone', 'Apple Intelligence',
    ),
    'default_polarity': 'bull',
    'explain': '自駕軟體演進、人形機器人量產時程與旗艦終端邊緣 AI 換機週期，牽動電動車、精密工業自動化與消費科技龍頭表現。',
    'sectors': [
      {'name': '電動車與自駕生態系', 'chain_id': 'EV_AUTONOMY', 'dir': 'same',
       'reason': '全自動駕駛與無人計程車商業化進度決定車廠軟體估值溢價'},
      {'name': '機器人與工業自動化', 'chain_id': 'ROBOTICS', 'dir': 'same',
       'reason': '物理 AI 與智慧工廠升級帶動機器視覺、手術與工業機器人需求'},
      {'name': '消費品牌與終端生態', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'same',
       'reason': '邊緣 AI 應用體驗左右全球智慧型手機與穿戴裝置升級意願'},
    ],
    'stocks': [
      ('TSLA', 'same', '電動車、FSD 自駕與人形機器人指標'),
      ('AAPL', 'same', '全球高階消費電子與邊緣 AI 生態龍頭'),
      ('ISRG', 'same', '達文西微創手術機器人全球龍頭'),
      ('HON', 'same', '航太與工業自動化控制系統巨頭'),
      ('ON', 'same', '車用碳化矽功率半導體與影像感測供應商'),
      ('QCOM', 'same', '邊緣 AI 手機與智慧車用座艙晶片龍頭'),
    ],
  },
  {
    'id': 'tariff_trade_policy',
    'category': 'tariff_trade',
    'kw': (
      '關稅', '貿易戰', '出口管制', '晶片禁令', '實體清單', '貿易談判', '對等關稅',
      '301條款', '232條款', '反傾銷', '供應鏈移轉', '美國製造', '商務部禁令', '關稅豁免',
      'tariff', 'trade war', 'export control', 'entity list', 'trade deal', 'import duty',
    ),
    'default_polarity': 'bear',
    'relief_kw': ('豁免', '暫緩', '調降關稅', '取消關稅', '達成協議', '貿易協議', 'tariff exemption', 'tariff pause', 'trade deal'),
    'explain_relief': '關稅豁免或雙邊貿易談判緩和，有助降低跨國硬體供應鏈與消費零售進口成本壓力，修復高外銷占比企業獲利預期。',
    'explain_bear': '關稅壁壘與半導體出口管制升溫，將測試跨國硬體品牌成本轉嫁能力並干擾設備出貨；純雲端軟體與美國本土電網基建相對具防禦優勢。',
    'sectors_relief': [
      {'name': '晶圓代工與台灣 ADR', 'chain_id': 'FOUNDRY_ADR', 'dir': 'beneficiary',
       'reason': '貿易摩擦降溫減輕跨境晶片與電子組裝關稅不確定性'},
      {'name': '半導體設備與材料', 'chain_id': 'SEMI_EQUIP', 'dir': 'beneficiary',
       'reason': '管制疑慮舒緩有利全球晶圓廠設備交付與售後服務營收'},
      {'name': '消費品牌與跨國零售', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'beneficiary',
       'reason': '進口關稅壓力緩解直接改善服飾、電子與量販毛利率預期'},
    ],
    'stocks_relief': [
      ('AAPL', 'beneficiary', '全球消費電子硬體供應鏈直接受惠關稅緩和'),
      ('NVDA', 'beneficiary', '全球 AI 晶片出貨與供應鏈順暢度提升'),
      ('TSM', 'beneficiary', '跨國先進製程客戶拉貨信心回穩'),
      ('AMAT', 'beneficiary', '全球半導體設備出貨能見度改善'),
      ('NKE', 'beneficiary', '海外製鞋成衣進口成本壓力減輕'),
      ('AMZN', 'beneficiary', '跨境電商商品成本結構受惠'),
    ],
    'sectors_bear': [
      {'name': '半導體設備與材料', 'chain_id': 'SEMI_EQUIP', 'dir': 'victim',
       'reason': '出口管制趨嚴限制特定海外市場高階設備銷售與維護'},
      {'name': '消費品牌與跨國零售', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'victim',
       'reason': '加徵進口關稅墊高採購成本，壓縮終端零售毛利空間'},
      {'name': '雲端與企業軟體', 'chain_id': 'CLOUD_SOFTWARE', 'dir': 'beneficiary',
       'reason': '數位軟體訂閱無實體海關關稅成本，成為資金避風港'},
      {'name': 'AI 電力與美國基建', 'chain_id': 'POWER_GRID', 'dir': 'beneficiary',
       'reason': '製造業回流美國本土直接推升工業配電與電網擴建需求'},
    ],
    'stocks_bear': [
      ('ETN', 'beneficiary', '美國製造業回流帶動本土配電設備訂單'),
      ('MSFT', 'beneficiary', '雲端軟體營收不受實體商品關稅直接衝擊'),
      ('AAPL', 'victim', '跨國硬體組裝供應鏈對關稅政策敏感'),
      ('NKE', 'victim', '高度仰賴海外生產基地，進口關稅敏感度高'),
      ('AMAT', 'victim', '出口管制規範影響海外晶圓廠設備出貨'),
      ('ASML', 'victim', '高階曝光設備受跨國出口許可政策牽動'),
    ],
  },
  {
    'id': 'geopolitics_energy_defense',
    'category': 'geopolitics',
    'kw': (
      '戰爭', '開戰', '空襲', '飛彈', '中東', '以色列', '伊朗', '烏克蘭', '俄羅斯',
      '紅海', '台海', '北約', '國防預算', '軍工', '停火', '和談', '原油', '石油',
      '油價', 'OPEC', 'WTI', '布蘭特', '天然氣', '戰備儲油',
      'geopolitics', 'ceasefire', 'missile', 'crude oil', 'defense spending',
    ),
    'default_polarity': 'mixed',
    'calm_kw': ('停火', '和談', '撤軍', '和平協議', '油價大跌', '油價回落', '增產', 'ceasefire', 'peace deal', 'oil drops'),
    'explain_calm': '地緣衝突趨緩或國際油價回落，有助降低全球通膨與航運燃料成本壓力，提振消費零售與航空旅遊信心，上游油氣短線則隨油價修正。',
    'explain_tense': '區域地緣衝突與產油區風險升溫，推升國際油價、黃金與避險需求，歐美航太國防與上游能源現金流受惠，高成本敏感消費族群則易承壓。',
    'sectors_calm': [
      {'name': '消費品牌與旅遊零售', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'beneficiary',
       'reason': '汽油與能源支出下降釋放家庭可支配所得，支撐消費動能'},
      {'name': '能源與油氣開採', 'chain_id': 'ENERGY_OIL', 'dir': 'victim',
       'reason': '地緣風險溢價消退與供給增加壓抑原油報價及煉油利差'},
    ],
    'stocks_calm': [
      ('COST', 'beneficiary', '物流運輸成本回落且民生消費穩健'),
      ('WMT', 'beneficiary', '燃油價格下滑有利中低所得客群消費力'),
      ('AMZN', 'beneficiary', '倉儲配送燃油成本減輕'),
      ('XOM', 'victim', '上游油氣實現價格隨原油回檔修正'),
      ('CVX', 'victim', '國際油價回落影響短期獲利彈性'),
      ('USO', 'victim', 'WTI 原油期貨 ETF 直接反映油價回落'),
    ],
    'sectors_tense': [
      {'name': '航太國防與軍工', 'chain_id': 'SPACE_DEFENSE', 'dir': 'beneficiary',
       'reason': '地緣安全威脅促使各國擴大防空飛彈、戰機與衛星偵察採購'},
      {'name': '能源與油氣開採', 'chain_id': 'ENERGY_OIL', 'dir': 'beneficiary',
       'reason': '中東與航道供應風險推升布蘭特及西德州原油期貨價格'},
      {'name': '消費品牌與零售', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'victim',
       'reason': '能源價格攀升與避險情緒升溫壓抑非必需消費意願'},
    ],
    'stocks_tense': [
      ('LMT', 'beneficiary', '全球最大國防承包商與防空飛彈系統龍頭'),
      ('RTX', 'beneficiary', '愛國者防空雷達與航太發動機大廠'),
      ('NOC', 'beneficiary', '戰略轟炸機與太空防衛系統指標'),
      ('XOM', 'beneficiary', '北美綜合油氣開採龍頭直接受惠高油價'),
      ('CVX', 'beneficiary', '高現金流油氣巨頭具地緣通膨對沖屬性'),
      ('GLD', 'beneficiary', '地緣風險升溫帶動黃金避險配置需求'),
      ('NKE', 'victim', '全球航運與跨國消費情緒波動形成逆風'),
    ],
  },
  {
    'id': 'biotech_glp1_fda',
    'category': 'earnings',
    'kw': (
      '禮來', 'Eli Lilly', 'LLY', '諾和諾德', 'Novo Nordisk', 'NVO', 'GLP-1',
      '減重藥', '瘦瘦針', '肥胖症', 'FDA', '臨床試驗', '三期臨床', '新藥核准', '藥價談判',
      'clinical trial', 'FDA approval', 'weight-loss drug',
    ),
    'default_polarity': 'bull',
    'explain': 'GLP-1 代謝減重藥物產能擴充、新適應症臨床數據與 FDA 藥證審批進展，直接主導全球大型製藥與精準醫療生技股評價。',
    'sectors': [
      {'name': 'GLP-1 減重與創新醫療', 'chain_id': 'GLP1_BIOTECH', 'dir': 'same',
       'reason': '臨床療效、口服劑型進度與醫保給付範圍直接決定百億美元級藥品銷售曲線'},
      {'name': '機器人與精準醫療器材', 'chain_id': 'ROBOTICS', 'dir': 'same',
       'reason': '醫療院所手術量復甦與智慧微創設備裝機需求穩健成長'},
    ],
    'stocks': [
      ('LLY', 'same', '全球 GLP-1 代謝與減重藥市值龍頭'),
      ('NVO', 'same', '歐洲代謝與糖尿病新藥巨頭 ADR'),
      ('AMGN', 'same', '長效減重候選藥物與生物製劑大廠'),
      ('VRTX', 'same', '罕見疾病與非鴉片類止痛新藥龍頭'),
      ('ABBV', 'same', '免疫學與腫瘤學高現金流藥廠'),
      ('ISRG', 'same', '微創手術機器人領導廠商'),
    ],
  },
  {
    'id': 'earnings_guidance_corp',
    'category': 'earnings',
    'kw': (
      '財報', '季報', 'EPS', '營收創高', '財測', '指引', '上修財測', '下修財測',
      '庫藏股', '買回庫藏股', '股票分割', '拆股', '併購', '收購', '股息調升',
      'earnings', 'guidance', 'buyback', 'stock split', 'acquires', 'merger', 'quarterly results',
    ),
    'default_polarity': 'bull',
    'explain': '美股超級財報週期間，企業實際 EPS 驚喜幅度、下季營收毛利率指引及庫藏股回購規模，是驅動個股跳空重估與同業比價的關鍵催化劑。',
    'sectors': [
      {'name': 'AI 算力與科技硬體', 'chain_id': 'AI_GPU', 'dir': 'same',
       'reason': '科技權值股財報與下季資本支出指引主導全市場風險偏好'},
      {'name': '電商與數位廣告', 'chain_id': 'ECOMMERCE_ADS', 'dir': 'same',
       'reason': '平台巨頭廣告變現率與雲端營業利益率為財報季焦點'},
      {'name': '支付與大型金融', 'chain_id': 'FINTECH_PAY', 'dir': 'same',
       'reason': '華爾街投行財報與支付機構交易量率先揭示企業活動熱度'},
    ],
    'stocks': [
      ('NVDA', 'same', '財報季 AI 算力需求最高指標'),
      ('MSFT', 'same', '雲端成長率與資本支出風向球'),
      ('META', 'same', '數位廣告獲利與 AI 投資回報代表'),
      ('AMZN', 'same', 'AWS 利潤率與零售物流效率指標'),
      ('JPM', 'same', '美股財報季金融業領頭羊'),
      ('NFLX', 'same', '串流訂閱淨增與廣告方案獲利代表'),
    ],
  },
]


def _num(x: Any, nd: int | None = None) -> float | None:
  """安全轉換有限浮點數；布林、None、NaN、Inf 一律回傳 None。"""
  if x is None or isinstance(x, bool):
    return None
  if isinstance(x, (int, float)):
    v = float(x)
  elif isinstance(x, str):
    s = x.strip().replace(',', '').replace('$', '').replace('%', '')
    if not s:
      return None
    try:
      v = float(s)
    except ValueError:
      return None
  else:
    return None
  if not math.isfinite(v):
    return None
  return round(v, nd) if nd is not None else v


def _sanitize(obj: Any) -> Any:
  """遞迴清除任何 NaN / Inf，確保 JSON allow_nan=False 100% 安全。"""
  if obj is None or isinstance(obj, (bool, str, int)):
    return obj
  if isinstance(obj, float):
    return obj if math.isfinite(obj) else None
  if isinstance(obj, dict):
    return {str(k): _sanitize(v) for k, v in obj.items()}
  if isinstance(obj, (list, tuple)):
    return [_sanitize(v) for v in obj]
  return str(obj)


def _fmt_usd(v: float | None) -> str:
  """格式化美元價格（固定兩位小數）。"""
  n = _num(v, 2)
  if n is None:
    return '$0.00'
  return f'${n:.2f}'


def _nth_sunday(year: int, month: int, n: int) -> dt.date:
  """計算指定年月的第 n 個週日（1-based）。"""
  first = dt.date(year, month, 1)
  days_to_sun = (6 - first.weekday()) % 7
  return first + dt.timedelta(days=days_to_sun + (n - 1) * 7)


def _is_us_dst_utc(utc_dt: dt.datetime) -> bool:
  """純標準庫判斷美國東岸夏令時間（3 月第 2 個週日 02:00 EST 至 11 月第 1 個週日 02:00 EDT）。"""
  yr = utc_dt.year
  start_sun = _nth_sunday(yr, 3, 2)
  end_sun = _nth_sunday(yr, 11, 1)
  dst_start_utc = dt.datetime(yr, 3, start_sun.day, 7, 0, 0, tzinfo=dt.timezone.utc)
  dst_end_utc = dt.datetime(yr, 11, end_sun.day, 6, 0, 0, tzinfo=dt.timezone.utc)
  return dst_start_utc <= utc_dt < dst_end_utc


def _to_tw_datetime(now: dt.datetime | None) -> dt.datetime:
  """將傳入時間正規化為台灣時區（UTC+8）datetime。"""
  if now is None:
    return dt.datetime.now(TZ_TW)
  if now.tzinfo is None:
    return now.replace(tzinfo=TZ_TW)
  return now.astimezone(TZ_TW)


def us_session(
  now: dt.datetime | None = None,
  is_trading_day: Callable[[dt.date], bool] | None = None,
) -> dict[str, Any]:
  """計算美股東岸夏／冬令狀態與對應台灣交易時段（SPEC §4.2）。"""
  now_tw = _to_tw_datetime(now)
  now_utc = now_tw.astimezone(dt.timezone.utc)
  is_dst = _is_us_dst_utc(now_utc)
  tz_et = dt.timezone(dt.timedelta(hours=-4 if is_dst else -5), name='EDT' if is_dst else 'EST')
  et = now_utc.astimezone(tz_et)

  hm = et.hour * 60 + et.minute
  if et.weekday() >= 5:
    state = 'weekend'
    state_zh = '美股週末休市'
  elif is_trading_day is not None and not is_trading_day(et.date()):
    state = 'closed'
    state_zh = '美股假日休市'
  elif 4 * 60 <= hm < 9 * 60 + 30:
    state = 'pre'
    state_zh = '美股盤前交易中'
  elif 9 * 60 + 30 <= hm < 16 * 60:
    state = 'regular'
    state_zh = '美股正規開盤交易中'
  elif 16 * 60 <= hm < 20 * 60:
    state = 'post'
    state_zh = '美股盤後交易中（正規盤已收盤）'
  else:
    state = 'closed'
    state_zh = '美股已收盤（含盤後結算）'

  if is_dst:
    season = '夏令時間 (EDT)'
    pre_tw = '16:00 ～ 21:30'
    regular_tw = '21:30 ～ 隔日 04:00'
    post_tw = '04:00 ～ 08:00'
  else:
    season = '冬令時間 (EST)'
    pre_tw = '17:00 ～ 22:30'
    regular_tw = '22:30 ～ 隔日 05:00'
    post_tw = '05:00 ～ 09:00'

  return _sanitize({
    'is_dst': is_dst,
    'season': season,
    'state': state,
    'state_zh': state_zh,
    'et_time': f"{et.strftime('%Y-%m-%d %H:%M')} ET",
    'tw_time': now_tw.strftime('%Y-%m-%d %H:%M'),
    'pre_tw': pre_tw,
    'regular_tw': regular_tw,
    'post_tw': post_tw,
  })


def _get_adr_map() -> tuple[dict[str, dict[str, Any]], Callable[[str], dict[str, Any] | None] | None]:
  """讀取 sources.universe_curated.ADR_MAP，若模組尚未就緒則使用內建常數備援。"""
  try:
    from sources import universe_curated  # type: ignore
    amap = getattr(universe_curated, 'ADR_MAP', None)
    getter = getattr(universe_curated, 'get', None)
    if isinstance(amap, dict) and amap:
      return amap, getter if callable(getter) else None
  except Exception:
    pass
  return _FALLBACK_ADR_MAP, None


def adr_bridge(rows: dict[str, dict[str, Any]], usdtwd: float | None) -> list[dict[str, Any]]:
  """計算台灣核心美股 ADR（TSM/UMC/ASX/CHT）折合新台幣隱含價（SPEC §4.6）。"""
  safe_rows = rows if isinstance(rows, dict) else {}
  amap, uni_get = _get_adr_map()
  fx_raw = _num(usdtwd)
  fx_out = _num(usdtwd, 4) if fx_raw is not None and fx_raw > 0 else None

  ordered_codes: list[str] = [c for c in ('TSM', 'UMC', 'ASX', 'CHT') if c in amap]
  for c in amap:
    if c not in ordered_codes:
      ordered_codes.append(c)

  out: list[dict[str, Any]] = []
  for code in ordered_codes:
    meta = amap.get(code) or {}
    fb = _FALLBACK_ADR_MAP.get(code) or {}
    r = safe_rows.get(code) or {}
    uni_entry = uni_get(code) if uni_get else None

    tw_code = str(meta.get('tw_code') or fb.get('tw_code') or '')
    tw_name = str(meta.get('tw_name') or fb.get('tw_name') or '')
    ratio_val = meta.get('ratio') or ADR_RATIO.get(code) or fb.get('ratio') or 1
    ratio = int(ratio_val) if isinstance(ratio_val, (int, float)) and ratio_val > 0 else 1

    name = str(
      r.get('name')
      or (uni_entry.get('name') if isinstance(uni_entry, dict) else '')
      or meta.get('name')
      or fb.get('name')
      or f'{tw_name} ADR'
    ).strip()

    close_raw = _num(r.get('close'))
    adr_close = round(close_raw, 2) if close_raw is not None and close_raw > 0 else None
    adr_pct = _num(r.get('pct'), 2)

    implied_twd: float | None = None
    if close_raw is not None and close_raw > 0 and fx_raw is not None and fx_raw > 0 and ratio > 0:
      implied_twd = round(close_raw * fx_raw / ratio, 2)

    out.append({
      'code': code,
      'name': name,
      'tw_code': tw_code,
      'tw_name': tw_name,
      'ratio': ratio,
      'adr_close': adr_close,
      'adr_pct': adr_pct,
      'usdtwd': round(fx_out, 2) if fx_out is not None and round(fx_out, 2) == fx_out else fx_out,
      'implied_twd': implied_twd,
      'note': f'1 單位 {code} ADR = {ratio} 股 {tw_code} 普通股',
    })

  return _sanitize(out)


def _normalize_rows(raw_rows: Any) -> dict[str, dict[str, Any]]:
  if isinstance(raw_rows, dict):
    return {str(k).upper(): v for k, v in raw_rows.items() if isinstance(v, dict)}
  if isinstance(raw_rows, list):
    return {
      str(it['code']).upper(): it
      for it in raw_rows
      if isinstance(it, dict) and it.get('code')
    }
  return {}


def _build_decision(
  rows: dict[str, dict[str, Any]],
  market: dict[str, Any],
) -> dict[str, Any]:
  """依 SPX/SOX/IXIC 漲跌、VIX 與市場廣度研判盤勢格局與風險水位。"""
  indices = (market.get('indices') if isinstance(market, dict) else None) or {}
  macro = (market.get('macro') if isinstance(market, dict) else None) or {}
  breadth = (market.get('breadth') if isinstance(market, dict) else None) or {}
  sectors = (market.get('sectors') if isinstance(market, dict) else None) or []

  def _idx_pct(key: str, etf_fallback: str) -> float | None:
    node = indices.get(key)
    p = _num(node.get('pct'), 2) if isinstance(node, dict) else None
    if p is None and etf_fallback in rows:
      p = _num(rows[etf_fallback].get('pct'), 2)
    return p

  spx_pct = _idx_pct('spx', 'SPY')
  sox_pct = _idx_pct('sox', 'SOXX')
  ixic_pct = _idx_pct('ixic', 'QQQ')
  dji_pct = _idx_pct('dji', 'DIA')

  vix_node = macro.get('vix') if isinstance(macro.get('vix'), dict) else {}
  vix_pct = _num(vix_node.get('pct'), 2)
  if vix_pct is None and 'VIXY' in rows:
    vix_pct = _num(rows['VIXY'].get('pct'), 2)
  vix_close = _num(vix_node.get('close'), 2)

  up_cnt = _num(breadth.get('up'))
  down_cnt = _num(breadth.get('down'))
  if up_cnt is None or down_cnt is None:
    up_cnt = float(sum(
      1 for r in rows.values()
      if r.get('type') != 'ETF' and (_num(r.get('pct')) or 0.0) > 0
    ))
    down_cnt = float(sum(
      1 for r in rows.values()
      if r.get('type') != 'ETF' and (_num(r.get('pct')) or 0.0) < 0
    ))
  denom = up_cnt + down_cnt
  up_ratio = (up_cnt / denom) if denom > 0 else 0.5
  breadth_pct = round(up_ratio * 100.0)

  spx_v = spx_pct or 0.0
  sox_v = sox_pct or 0.0
  ixic_v = ixic_pct or 0.0
  dji_v = dji_pct or 0.0
  vix_p = vix_pct or 0.0

  idx_score = spx_v * 16.0 + ixic_v * 12.0 + sox_v * 10.0 + dji_v * 6.0
  breadth_score = (up_ratio - 0.5) * 48.0
  vix_score = max(-20.0, min(20.0, -vix_p * 2.4))
  if vix_close is not None and str(vix_node.get('code') or '').upper() == 'VIX':
    if vix_close >= 28.0:
      vix_score -= 10.0
    elif vix_close <= 15.0:
      vix_score += 4.0
  comp = max(-100.0, min(100.0, idx_score + breadth_score + vix_score))

  top_sec = ''
  if isinstance(sectors, list) and sectors:
    ranked_sec = sorted(
      (s for s in sectors if isinstance(s, dict) and s.get('name')),
      key=lambda s: _num(s.get('pct_1d')) or -999.0,
      reverse=True,
    )
    if ranked_sec:
      top_sec = str(ranked_sec[0]['name'])

  vix_phrase = (
    f'恐慌指標彈升（{vix_pct:+.2f}%）' if (vix_pct is not None and vix_pct >= 3.5)
    else (f'VIX 指標回落（{vix_pct:+.2f}%）' if (vix_pct is not None and vix_pct <= -1.5) else '波動率維持穩定')
  )
  sec_hint = f'強勢板塊由「{top_sec}」領軍，' if top_sec else ''

  if comp >= 26.0:
    regime = '偏多格局 · 科技半導體領軍' if (sox_v >= 0.8 or ixic_v >= spx_v) else '積極偏多 · 指數廣度齊揚'
    regime_cls = 'bull'
    allocation = '建議風險水位 65–80%'
    advice = (
      f'四大指數同步走強（SPX {spx_v:+.2f}%、費半 {sox_v:+.2f}%）、上漲家數比達 {breadth_pct}% 且{vix_phrase}；'
      f'{sec_hint}短線資金聚焦財報優於預期與均線多頭主流股，惟跳空過大標的宜等拉回支撐分批觀察。'
    )
  elif comp >= 8.0:
    regime = '偏多格局 · 科技半導體領軍' if (sox_v >= 0.8 and ixic_v >= 0.3) else '震盪偏多 · 類股良性輪動'
    regime_cls = 'bull'
    allocation = '建議風險水位 60–75%'
    advice = (
      f'美股維持溫和偏多結構（SPX {spx_v:+.2f}%、那指 {ixic_v:+.2f}%、費半 {sox_v:+.2f}%）、{vix_phrase}；'
      f'{sec_hint}資金聚焦 AI 算力與基本面績優股，追高留意盤前盤後財報波動。'
    )
  elif comp > -10.0:
    regime = '中性震盪 · 個股財報分化'
    regime_cls = 'neutral'
    allocation = '建議風險水位 45–60%'
    advice = (
      f'主要指數多空拉鋸（SPX {spx_v:+.2f}%、費半 {sox_v:+.2f}%，上漲家數比 {breadth_pct}%），市場進入選股不選市階段；'
      f'{sec_hint}宜聚焦季報驚喜與機構評級上修標的，嚴守關鍵支撐與停損紀律。'
    )
  elif comp > -28.0:
    regime = '震盪偏弱 · 資金轉趨防禦'
    regime_cls = 'bear'
    allocation = '建議風險水位 30–45%'
    advice = (
      f'美股指數拉回修正（SPX {spx_v:+.2f}%、那指 {ixic_v:+.2f}%）且上漲家數比降至 {breadth_pct}%，{vix_phrase}；'
      f'短線不宜貿然追價高波動題材，建議提高現金與低波防禦配置比重，靜待回測支撐止穩。'
    )
  else:
    regime = '避險警戒 · 嚴控部位風險'
    regime_cls = 'bear'
    allocation = '建議風險水位 15–30%'
    advice = (
      f'主要指數顯著承壓（SPX {spx_v:+.2f}%、費半 {sox_v:+.2f}%）伴隨{vix_phrase}，市場避險情緒升溫；'
      f'操作上以風險控管與資金保護為優先，跌破停損位個股宜果斷減碼，耐心等待量縮止跌訊號。'
    )

  return {
    'regime': regime,
    'regime_cls': regime_cls,
    'allocation': allocation,
    'summary_advice': advice,
    'spx_est': {
      'spx_pct': spx_pct,
      'sox_pct': sox_pct,
      'ixic_pct': ixic_pct,
      'dji_pct': dji_pct,
    },
  }


def _build_extended_movers(
  extended: list[dict[str, Any]],
  rows: dict[str, dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
  """合併盤前／盤後異動與收盤行情，依 |ext_pct| 排序取前 30 名。"""
  by_code: dict[str, dict[str, Any]] = {}
  for it in extended or []:
    if not isinstance(it, dict):
      continue
    code = str(it.get('code') or '').strip().upper()
    if not code:
      continue
    r = rows.get(code) or {}
    close = _num(it.get('close') if it.get('close') is not None else r.get('close'), 2)
    reg_pct = _num(it.get('reg_pct') if it.get('reg_pct') is not None else r.get('pct'), 2)
    ext_price = _num(it.get('ext_price'), 2)
    ext_pct = _num(it.get('ext_pct'), 2)
    if ext_pct is None and ext_price is not None and close is not None and close > 0:
      ext_pct = round((ext_price / close - 1.0) * 100.0, 2)
    if ext_price is None and ext_pct is None:
      continue

    raw_type = str(it.get('ext_type') or '').strip()
    if raw_type in ('盤前', 'pre', 'PRE', 'BMO'):
      ext_type = '盤前'
    else:
      ext_type = '盤後'

    vol_num = _num(it.get('vol'))
    vol = int(round(vol_num)) if vol_num is not None and vol_num >= 0 else None
    name = str(it.get('name') or r.get('name') or code)

    cand = {
      'code': code,
      'name': name,
      'close': close,
      'reg_pct': reg_pct,
      'ext_type': ext_type,
      'ext_price': ext_price,
      'ext_pct': ext_pct,
      'vol': vol,
    }
    prev = by_code.get(code)
    if prev is None or abs(ext_pct or 0.0) > abs(prev.get('ext_pct') or 0.0):
      by_code[code] = cand

  movers = sorted(
    by_code.values(),
    key=lambda x: (-abs(x.get('ext_pct') or 0.0), -(x.get('vol') or 0), x['code']),
  )
  return movers[:30], by_code


def _parse_iso_date(s: Any) -> dt.date | None:
  if not isinstance(s, str) or len(s) < 10:
    return None
  try:
    return dt.date.fromisoformat(s[:10])
  except ValueError:
    return None


def _normalize_earn_time(raw: Any) -> str:
  s = str(raw or '').strip()
  low = s.lower()
  if '盤前' in s or 'bmo' in low or 'pre' in low or 'before' in low:
    return '盤前 (BMO)'
  if '盤後' in s or 'amc' in low or 'after' in low or 'post' in low:
    return '盤後 (AMC)'
  return '未定'


def _build_earnings_calendar(
  earnings: list[dict[str, Any]],
  rows: dict[str, dict[str, Any]],
  ref_date: dt.date,
  data_date_obj: dt.date | None,
) -> list[dict[str, Any]]:
  """篩選近 7 日重磅財報行事曆，標記宇宙內成分並依日期與市值排序（上限 120 筆）。"""
  start_d = ref_date
  if data_date_obj is not None and 0 <= (ref_date - data_date_obj).days <= 2:
    start_d = data_date_obj
  end_d = ref_date + dt.timedelta(days=7)

  seen: set[tuple[str, str]] = set()
  items: list[dict[str, Any]] = []

  for it in earnings or []:
    if not isinstance(it, dict):
      continue
    code = str(it.get('code') or '').strip().upper()
    d_obj = _parse_iso_date(it.get('date'))
    if not code or d_obj is None:
      continue
    if not (start_d <= d_obj <= end_d):
      continue
    d_str = d_obj.isoformat()
    if (d_str, code) in seen:
      continue
    seen.add((d_str, code))

    in_universe = code in rows
    r = rows.get(code) or {}
    name = str(r.get('name') or it.get('name') or code)
    mcap = _num(it.get('mcap') if it.get('mcap') is not None else r.get('mcap'), 2)

    items.append({
      'date': d_str,
      'time': _normalize_earn_time(it.get('time')),
      'code': code,
      'name': name,
      'mcap': mcap,
      'quarter': str(it.get('quarter') or ''),
      'eps_est': _num(it.get('eps_est'), 2),
      'last_yr_eps': _num(it.get('last_yr_eps'), 2),
      'in_universe': in_universe,
    })

  items.sort(
    key=lambda x: (
      x['date'],
      0 if x['in_universe'] else 1,
      -(x['mcap'] if x['mcap'] is not None else -1.0),
      x['code'],
    )
  )
  return items[:120]


def _score_sentiment(text: str) -> tuple[int, int]:
  low = text.lower()
  bull_n = sum(1 for w in BULL_WORDS if w.lower() in low)
  bear_n = sum(1 for w in BEAR_WORDS if w.lower() in low)
  return bull_n, bear_n


def _detect_headline_tickers(title: str, rows: dict[str, dict[str, Any]]) -> list[str]:
  """偵測新聞標題中直接提及且存在於宇宙 rows 的美股代號。"""
  found: list[str] = []
  for m in _TICKER_TOKEN_RE.finditer(title):
    tok = m.group(1)
    if tok in _COMMON_EN_STOPWORDS:
      continue
    if tok in rows and tok not in found:
      found.append(tok)
  return found


def _format_sectors(raw_sectors: list[dict[str, Any]], same_dir: str) -> list[dict[str, Any]]:
  out: list[dict[str, Any]] = []
  for s in raw_sectors:
    cid = str(s.get('chain_id') or 'AI_GPU')
    if cid not in VALID_CHAIN_IDS:
      cid = 'AI_GPU'
    raw_d = str(s.get('dir') or 'same')
    if raw_d == 'same':
      d = same_dir
    elif raw_d in ('beneficiary', 'victim'):
      d = raw_d
    else:
      d = 'victim' if raw_d == 'headwind' else 'beneficiary'
    out.append({
      'name': str(s.get('name') or ''),
      'chain_id': cid,
      'dir': d,
      'reason': str(s.get('reason') or ''),
    })
  return out


def _format_stocks(
  raw_stocks: list[tuple[str, str, str]],
  rows: dict[str, dict[str, Any]],
  same_dir: str,
  extra_codes: list[str] | None = None,
) -> list[dict[str, Any]]:
  """建立事件受惠／承壓個股清單（僅保留 rows 中存在的代號並附當日 pct）。"""
  out: list[dict[str, Any]] = []
  seen: set[str] = set()

  if extra_codes:
    for code in extra_codes:
      if code in rows and code not in seen:
        seen.add(code)
        r = rows[code]
        out.append({
          'code': code,
          'name': str(r.get('name') or code),
          'dir': same_dir,
          'reason': '新聞標題直接點名焦點標的',
          'pct': _num(r.get('pct'), 2),
        })

  for code, raw_d, reason in raw_stocks:
    if code not in rows or code in seen:
      continue
    seen.add(code)
    r = rows[code]
    if raw_d == 'same':
      d = same_dir
    elif raw_d in ('beneficiary', 'victim'):
      d = raw_d
    else:
      d = 'victim' if raw_d == 'headwind' else 'beneficiary'
    out.append({
      'code': code,
      'name': str(r.get('name') or code),
      'dir': d,
      'reason': reason,
      'pct': _num(r.get('pct'), 2),
    })
    if len(out) >= 8:
      break

  return out


def _resolve_rule_event(
  rule: dict[str, Any],
  news_item: dict[str, Any],
  rows: dict[str, dict[str, Any]],
) -> dict[str, Any]:
  title = str(news_item.get('title') or '').strip()
  text = f"{title} {news_item.get('summary') or ''}"
  low = text.lower()
  bull_n, bear_n = _score_sentiment(text)
  rid = rule['id']

  if rid == 'fed_rates_inflation':
    is_hawk = any(w.lower() in low for w in rule['hawkish_kw'])
    is_dove = any(w.lower() in low for w in rule['dovish_kw'])
    if is_hawk and not is_dove:
      polarity = 'bear'
      explain = rule['explain_hawkish']
      raw_secs = rule['sectors_hawkish']
      raw_stks = rule['stocks_hawkish']
    elif is_dove and not is_hawk:
      polarity = 'bull'
      explain = rule['explain_dovish']
      raw_secs = rule['sectors_dovish']
      raw_stks = rule['stocks_dovish']
    elif bear_n > bull_n:
      polarity = 'bear'
      explain = rule['explain_hawkish']
      raw_secs = rule['sectors_hawkish']
      raw_stks = rule['stocks_hawkish']
    else:
      polarity = 'bull' if bull_n > bear_n else 'mixed'
      explain = rule['explain_dovish']
      raw_secs = rule['sectors_dovish']
      raw_stks = rule['stocks_dovish']
  elif rid == 'tariff_trade_policy':
    is_relief = any(w.lower() in low for w in rule['relief_kw']) and bear_n == 0
    if is_relief:
      polarity = 'bull'
      explain = rule['explain_relief']
      raw_secs = rule['sectors_relief']
      raw_stks = rule['stocks_relief']
    else:
      polarity = 'bear' if bear_n >= bull_n else 'mixed'
      explain = rule['explain_bear']
      raw_secs = rule['sectors_bear']
      raw_stks = rule['stocks_bear']
  elif rid == 'geopolitics_energy_defense':
    is_calm = any(w.lower() in low for w in rule['calm_kw']) and bear_n == 0
    if is_calm:
      polarity = 'bull'
      explain = rule['explain_calm']
      raw_secs = rule['sectors_calm']
      raw_stks = rule['stocks_calm']
    else:
      polarity = 'bear' if bear_n > bull_n + 1 else 'mixed'
      explain = rule['explain_tense']
      raw_secs = rule['sectors_tense']
      raw_stks = rule['stocks_tense']
  else:
    if bull_n > bear_n:
      polarity = 'bull'
    elif bear_n > bull_n:
      polarity = 'bear'
    else:
      polarity = str(rule.get('default_polarity') or 'bull')
    explain = str(rule.get('explain') or '')
    raw_secs = rule.get('sectors') or []
    raw_stks = rule.get('stocks') or []

  same_dir = 'victim' if polarity == 'bear' else 'beneficiary'
  direct_codes = _detect_headline_tickers(title, rows)
  sectors_out = _format_sectors(raw_secs, same_dir)
  stocks_out = _format_stocks(raw_stks, rows, same_dir, extra_codes=direct_codes)

  cat = str(rule['category'])
  eid = 'ev_' + hashlib.sha1(title.encode('utf-8')).hexdigest()[:10]
  return {
    'id': eid,
    'category': cat,
    'category_label': CATEGORY_LABELS[cat],
    'polarity': polarity,
    'polarity_zh': POLARITY_ZH[polarity],
    'title': title,
    'explain': explain,
    'source': str(news_item.get('source') or '市場新聞'),
    'time': str(news_item.get('time') or ''),
    'link': str(news_item.get('link') or ''),
    'affected_sectors': sectors_out,
    'affected_stocks': stocks_out,
  }


def _build_baseline_events(
  rows: dict[str, dict[str, Any]],
  market: dict[str, Any],
  earnings_cal: list[dict[str, Any]],
  now_iso: str,
) -> list[dict[str, Any]]:
  """依當日 SOX／VIX／油價美債 ETF 與財報日曆推演常態觀察事件，確保無新聞命中時仍有 ≥ 3 則事件。"""
  indices = (market.get('indices') if isinstance(market, dict) else None) or {}
  macro = (market.get('macro') if isinstance(market, dict) else None) or {}

  sox_pct = _num((indices.get('sox') or {}).get('pct'), 2)
  if sox_pct is None and 'SOXX' in rows:
    sox_pct = _num(rows['SOXX'].get('pct'), 2)
  sox_v = sox_pct or 0.0

  vix_pct = _num((macro.get('vix') or {}).get('pct'), 2)
  if vix_pct is None and 'VIXY' in rows:
    vix_pct = _num(rows['VIXY'].get('pct'), 2)
  vix_v = vix_pct or 0.0

  tlt_pct = _num((macro.get('tlt') or {}).get('pct'), 2)
  if tlt_pct is None and 'TLT' in rows:
    tlt_pct = _num(rows['TLT'].get('pct'), 2)
  tlt_v = tlt_pct or 0.0

  uso_pct = _num((macro.get('uso') or {}).get('pct'), 2)
  if uso_pct is None and 'USO' in rows:
    uso_pct = _num(rows['USO'].get('pct'), 2)
  uso_v = uso_pct or 0.0

  baselines: list[dict[str, Any]] = []

  # 1. 半導體與 AI 算力常態觀察（SOX）
  if sox_v >= 0.5:
    sox_pol, sox_dir = 'bull', 'beneficiary'
    sox_title = f'常態觀察：費城半導體指數收漲 {sox_v:+.2f}%，AI 算力與先進製程動能延續'
    sox_exp = '費半指數維持多方表態，顯示資金持續聚焦 AI GPU、客製化晶片與先進封裝供應鏈。'
  elif sox_v <= -0.5:
    sox_pol, sox_dir = 'bear', 'victim'
    sox_title = f'常態觀察：費城半導體指數回檔 {sox_v:+.2f}%，高估值晶片族群短線震盪整固'
    sox_exp = '費半指數短線拉回整理，AI 硬體與半導體設備族群進入獲利了結消化階段，留意關鍵均線支撐。'
  else:
    sox_pol, sox_dir = 'mixed', 'beneficiary'
    sox_title = f'常態觀察：費城半導體指數平盤整理（{sox_v:+.2f}%），科技權值高低位階輪動'
    sox_exp = '半導體指數窄幅整理，市場資金於 AI 晶片、光通訊網通與企業軟體間進行結構性輪動。'

  baselines.append({
    'id': 'obs_sox_ai_semi',
    'category': 'tech_giant',
    'category_label': CATEGORY_LABELS['tech_giant'],
    'polarity': sox_pol,
    'polarity_zh': POLARITY_ZH[sox_pol],
    'title': sox_title,
    'explain': sox_exp,
    'source': '盤勢量化常態觀測',
    'time': now_iso,
    'link': '',
    'affected_sectors': _format_sectors([
      {'name': 'AI 算力與加速器生態系', 'chain_id': 'AI_GPU', 'dir': sox_dir,
       'reason': '費半指數走勢直接牽動 AI 晶片與伺服器硬體風險偏好'},
      {'name': '晶圓代工與台灣 ADR', 'chain_id': 'FOUNDRY_ADR', 'dir': sox_dir,
       'reason': '先進製程與封測 ADR 與費半指數高度連動'},
    ], sox_dir),
    'affected_stocks': _format_stocks([
      ('NVDA', sox_dir, 'AI GPU 核心權值指標'),
      ('TSM', sox_dir, '先進晶圓代工 ADR 龍頭'),
      ('AVGO', sox_dir, 'AI ASIC 與高速網通晶片龍頭'),
      ('AMD', sox_dir, '資料中心加速器指標'),
      ('ASML', sox_dir, 'EUV 曝光機設備指標'),
    ], rows, sox_dir),
  })

  # 2. VIX 波動率與美債利率常態觀察
  if vix_v >= 3.0 or tlt_v <= -0.8:
    mac_pol = 'bear'
    mac_title = f'常態觀察：恐慌指標變動 {vix_v:+.2f}%、長債 ETF {tlt_v:+.2f}%，利率與波動度偏謹慎'
    mac_exp = '避險波動率上升或長天期美債回檔反映殖利率壓力，高估值雲端軟體宜留意評價修正，金融支付相對抗跌。'
    mac_secs = [
      {'name': '雲端與企業軟體', 'chain_id': 'CLOUD_SOFTWARE', 'dir': 'victim',
       'reason': '長端利率與波動度攀升壓抑高估值成長股'},
      {'name': '支付與金融科技', 'chain_id': 'FINTECH_PAY', 'dir': 'beneficiary',
       'reason': '大型金融與支付龍頭現金流穩健具防禦性'},
    ]
    mac_stks = [
      ('JPM', 'beneficiary', '大型商業銀行利差穩健'),
      ('V', 'beneficiary', '全球支付現金流護城河'),
      ('CRM', 'victim', '軟體估值受長端殖利率牽動'),
      ('TLT', 'victim', '長天期美債反映殖利率波動'),
    ]
  elif vix_v <= -1.5 or tlt_v >= 0.4:
    mac_pol = 'bull'
    mac_title = f'常態觀察：VIX 指標回落（{vix_v:+.2f}%）、長債 ETF {tlt_v:+.2f}%，總經資金環境溫和偏多'
    mac_exp = '市場恐慌情緒降溫且美債殖利率趨穩，有利長久期科技成長股、雲端軟體與電力基建延續估值修復。'
    mac_secs = [
      {'name': '雲端與企業軟體', 'chain_id': 'CLOUD_SOFTWARE', 'dir': 'beneficiary',
       'reason': '波動率與殖利率趨穩提振企業軟體評價'},
      {'name': 'AI 電力與電網基建', 'chain_id': 'POWER_GRID', 'dir': 'beneficiary',
       'reason': '融資環境穩定有利資料中心電力與公用事業資本投資'},
    ]
    mac_stks = [
      ('MSFT', 'beneficiary', '大型雲端與 AI 軟體權值首選'),
      ('NOW', 'beneficiary', '企業自動化 SaaS 指標'),
      ('ETN', 'beneficiary', '電網與資料中心配電龍頭'),
      ('TLT', 'beneficiary', '長天期美債殖利率趨穩受惠'),
    ]
  else:
    mac_pol = 'mixed'
    mac_title = f'常態觀察：VIX 波動指標（{vix_v:+.2f}%）與美債殖利率區間整理，靜待總經數據指引'
    mac_exp = '總經利率與波動率維持窄幅區間，市場觀望後續通膨與聯準會官員談話，資金偏好高現金流品質股。'
    mac_secs = [
      {'name': '雲端與企業軟體', 'chain_id': 'CLOUD_SOFTWARE', 'dir': 'beneficiary',
       'reason': '經常性訂閱營收於總經觀望期具高能見度'},
      {'name': '支付與金融科技', 'chain_id': 'FINTECH_PAY', 'dir': 'beneficiary',
       'reason': '消費支付網路營運穩健'},
    ]
    mac_stks = [
      ('MSFT', 'beneficiary', '高現金流雲端平台龍頭'),
      ('V', 'beneficiary', '跨境與內需刷卡龍頭'),
      ('JPM', 'beneficiary', '美國綜合金融指標'),
      ('TLT', 'beneficiary', '長端利率觀察指標'),
    ]

  baselines.append({
    'id': 'obs_vix_rates_macro',
    'category': 'fed_macro',
    'category_label': CATEGORY_LABELS['fed_macro'],
    'polarity': mac_pol,
    'polarity_zh': POLARITY_ZH[mac_pol],
    'title': mac_title,
    'explain': mac_exp,
    'source': '總經指標常態觀測',
    'time': now_iso,
    'link': '',
    'affected_sectors': _format_sectors(mac_secs, 'beneficiary'),
    'affected_stocks': _format_stocks(mac_stks, rows, 'beneficiary'),
  })

  # 3. 能源油價與地緣避險常態觀察（USO）
  if uso_v >= 1.2:
    oil_pol = 'mixed'
    oil_title = f'常態觀察：原油指標 ETF 走揚 {uso_v:+.2f}%，能源與航太國防抗跌、運輸零售留意成本'
    oil_exp = '國際油價短線轉強支撐北美油氣開採獲利與抗通膨配置，但終端零售物流與高耗能產業須留意成本變化。'
    oil_secs = [
      {'name': '能源與油氣開採', 'chain_id': 'ENERGY_OIL', 'dir': 'beneficiary',
       'reason': '原油報價走高直接擴大上游開採現金流'},
      {'name': '航太國防與軍工', 'chain_id': 'SPACE_DEFENSE', 'dir': 'beneficiary',
       'reason': '地緣與能源風險環境下防務訂單具剛性支撐'},
      {'name': '消費品牌與零售', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'victim',
       'reason': '燃油價格上揚墊高物流配送與家庭能源支出'},
    ]
    oil_stks = [
      ('XOM', 'beneficiary', '綜合油氣龍頭直接受惠油價上行'),
      ('CVX', 'beneficiary', '上游原油價格敏感度高'),
      ('LMT', 'beneficiary', '航太防務龍頭具避險配置價值'),
      ('USO', 'beneficiary', 'WTI 原油期貨指標 ETF'),
      ('COST', 'victim', '零售物流燃油成本觀察標的'),
    ]
  elif uso_v <= -1.2:
    oil_pol = 'bull'
    oil_title = f'常態觀察：原油指標 ETF 回落 {uso_v:+.2f}%，減輕通膨預期並提振民生消費零售'
    oil_exp = '國際油價回檔有助舒緩整體通膨與企業物流運輸成本，對大型零售量販與電商消費形成順風；上游油氣短線承壓。'
    oil_secs = [
      {'name': '消費品牌與零售', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'beneficiary',
       'reason': '油價降溫減輕家庭燃料負擔並降低配送成本'},
      {'name': '能源與油氣開採', 'chain_id': 'ENERGY_OIL', 'dir': 'victim',
       'reason': '原油報價拉回壓抑短期上游開採評價'},
    ]
    oil_stks = [
      ('WMT', 'beneficiary', '民生零售龍頭受惠運輸成本下降'),
      ('COST', 'beneficiary', '量販消費動能穩健'),
      ('AMZN', 'beneficiary', '北美電商物流成本壓力減輕'),
      ('XOM', 'victim', '油價回檔壓抑短線動能'),
      ('USO', 'victim', '原油期貨 ETF 隨油價修正'),
    ]
  else:
    oil_pol = 'mixed'
    oil_title = f'常態觀察：國際原油指標平穩（{uso_v:+.2f}%），能源供需與地緣風險處於均衡區間'
    oil_exp = '原油價格維持區間震盪，未對通膨預期造成額外干擾，能源高息股與消費品牌各自回歸基本面表現。'
    oil_secs = [
      {'name': '能源與油氣開採', 'chain_id': 'ENERGY_OIL', 'dir': 'beneficiary',
       'reason': '油價穩定區間仍支撐頁岩油龍頭自由現金流與配息'},
      {'name': '消費品牌與零售', 'chain_id': 'CONSUMER_BRANDS', 'dir': 'beneficiary',
       'reason': '能源成本穩定有利零售毛利率維持高檔'},
    ]
    oil_stks = [
      ('XOM', 'beneficiary', '高股息現金流能源代表'),
      ('CVX', 'beneficiary', '資產負債表穩健油氣巨頭'),
      ('COST', 'beneficiary', '會員續卡率高之消費龍頭'),
      ('WMT', 'beneficiary', '全通路零售防禦指標'),
    ]

  baselines.append({
    'id': 'obs_oil_geopolitics',
    'category': 'geopolitics',
    'category_label': CATEGORY_LABELS['geopolitics'],
    'polarity': oil_pol,
    'polarity_zh': POLARITY_ZH[oil_pol],
    'title': oil_title,
    'explain': oil_exp,
    'source': '原物料與避險常態觀測',
    'time': now_iso,
    'link': '',
    'affected_sectors': _format_sectors(oil_secs, 'beneficiary'),
    'affected_stocks': _format_stocks(oil_stks, rows, 'beneficiary'),
  })

  # 4. 近期重磅財報雷達觀察（備用第 4 則）
  uni_earn = [e for e in earnings_cal if e.get('in_universe')]
  if uni_earn:
    top_names = '、'.join(f"{e['name']}({e['code']})" for e in uni_earn[:3])
    earn_title = f'常態觀察：近 7 日聚焦 {top_names} 等重點企業財報與指引'
    extra = [e['code'] for e in uni_earn[:5]]
  else:
    earn_title = '常態觀察：持續追蹤美股權值股季報 EPS 驚喜率與華爾街目標價修正'
    extra = []

  baselines.append({
    'id': 'obs_earnings_focus',
    'category': 'earnings',
    'category_label': CATEGORY_LABELS['earnings'],
    'polarity': 'mixed',
    'polarity_zh': POLARITY_ZH['mixed'],
    'title': earn_title,
    'explain': '財報公布前後盤後波動通常顯著放大，建議對照市場 EPS 共識與毛利率指引評估跳空延續性。',
    'source': '財報行事曆常態觀測',
    'time': now_iso,
    'link': '',
    'affected_sectors': _format_sectors([
      {'name': 'AI 算力與加速器生態系', 'chain_id': 'AI_GPU', 'dir': 'beneficiary',
       'reason': '科技財報資本支出與訂單指引為市場核心焦點'},
      {'name': '電商與數位廣告', 'chain_id': 'ECOMMERCE_ADS', 'dir': 'beneficiary',
       'reason': '雲端與廣告營收年增率直接驗證終端需求'},
    ], 'beneficiary'),
    'affected_stocks': _format_stocks([
      ('NVDA', 'beneficiary', 'AI 財報核心指標'),
      ('MSFT', 'beneficiary', '雲端企業支出指標'),
      ('AMZN', 'beneficiary', '電商與 AWS 獲利指標'),
      ('META', 'beneficiary', '數位廣告變現指標'),
    ], rows, 'beneficiary', extra_codes=extra),
  })

  return baselines


def _build_events(
  news: list[dict[str, Any]],
  rows: dict[str, dict[str, Any]],
  market: dict[str, Any],
  earnings_cal: list[dict[str, Any]],
  now_iso: str,
) -> list[dict[str, Any]]:
  """比對中英文新聞標題關鍵字建構 5 大類事件圖譜；不足 3 則時自動補齊常態觀察事件。"""
  events: list[dict[str, Any]] = []
  seen_titles: set[str] = set()
  rule_counts: dict[str, int] = {}

  for it in news or []:
    if not isinstance(it, dict):
      continue
    title = str(it.get('title') or '').strip()
    if not title or title in seen_titles:
      continue
    text_low = f"{title} {it.get('summary') or ''}".lower()

    best_rule: dict[str, Any] | None = None
    best_hits = 0
    for rule in EVENT_RULES:
      hits = sum(1 for kw in rule['kw'] if kw.lower() in text_low)
      if hits > best_hits:
        best_hits = hits
        best_rule = rule

    if best_rule is None or best_hits == 0:
      continue
    rid = str(best_rule['id'])
    if rule_counts.get(rid, 0) >= 3:
      continue

    seen_titles.add(title)
    rule_counts[rid] = rule_counts.get(rid, 0) + 1
    events.append(_resolve_rule_event(best_rule, it, rows))
    if len(events) >= 15:
      break

  if len(events) < 3:
    existing_cats = {e['category'] for e in events}
    baselines = _build_baseline_events(rows, market, earnings_cal, now_iso)
    # 優先補齊尚未出現之類別，再補足至至少 3 則
    for b in baselines:
      if len(events) >= 3:
        break
      if b['category'] not in existing_cats:
        events.append(b)
        existing_cats.add(b['category'])
    for b in baselines:
      if len(events) >= 3:
        break
      if all(e['id'] != b['id'] for e in events):
        events.append(b)

  return events


def _rejudge_picks(
  picks: list[dict[str, Any]],
  rows: dict[str, dict[str, Any]],
  ext_by_code: dict[str, dict[str, Any]],
  decision: dict[str, Any],
) -> list[dict[str, Any]]:
  """依正規盤漲跌、盤前盤後異動與支撐／停損價位重新研判今日推薦股操作動作（SPEC §4.6）。"""
  regime_cls = str(decision.get('regime_cls') or 'neutral')
  sox_pct = _num(((decision.get('spx_est') or {}).get('sox_pct')), 2) or 0.0
  out: list[dict[str, Any]] = []

  for p in picks or []:
    if not isinstance(p, dict):
      continue
    code = str(p.get('code') or '').strip().upper()
    if not code:
      continue
    r = rows.get(code) or {}
    ext = ext_by_code.get(code) or {}

    name = str(p.get('name') or r.get('name') or code)
    close = _num(p.get('close') if p.get('close') is not None else r.get('close'), 2)
    pct = _num(p.get('pct') if p.get('pct') is not None else r.get('pct'), 2)
    ext_pct = _num(ext.get('ext_pct'), 2)
    ext_price = _num(ext.get('ext_price'), 2)
    ext_type = str(ext.get('ext_type') or '盤後')
    score_num = _num(p.get('score') if p.get('score') is not None else r.get('score'), 1)
    score: int | float | None = (
      int(score_num) if score_num is not None and score_num == int(score_num) else score_num
    )

    levels = p.get('levels') if isinstance(p.get('levels'), dict) else {}
    support = _num(levels.get('support'), 2)
    stop = _num(levels.get('stop'), 2)
    target = _num(levels.get('target'), 2)
    rsi = _num(r.get('rsi'), 1)

    eff_price = ext_price if (ext_price is not None and ext_price > 0) else close
    sup_ref = support if support is not None else close
    stop_ref = stop if stop is not None else (round(close * 0.94, 2) if close is not None else 0.0)

    if stop is not None and eff_price is not None and eff_price < stop:
      action = '跌破停損減碼'
      action_cls = 'bear'
      reason = f'最新參考價 {_fmt_usd(eff_price)} 已跌破風控停損位 {_fmt_usd(stop)}，短線趨勢轉弱建議優先減碼控管風險'
    elif ext_pct is not None and ext_pct <= -1.5:
      action = f'{ext_type}轉弱暫緩追價'
      action_cls = 'bear' if (ext_pct <= -3.0 or (support is not None and eff_price is not None and eff_price < support)) else 'neutral'
      reason = (
        f'{ext_type}拉回 {ext_pct:+.2f}%（參考價 {_fmt_usd(eff_price)}），暫緩開盤追價，'
        f'觀察支撐 {_fmt_usd(sup_ref)} 守穩力道並嚴守停損 {_fmt_usd(stop_ref)}'
      )
    elif support is not None and eff_price is not None and eff_price < support:
      action = '觀望等待回測支撐'
      action_cls = 'neutral'
      reason = (
        f'現價 {_fmt_usd(eff_price)} 暫低於關鍵支撐 {_fmt_usd(support)}，'
        f'宜靜待站回支撐之上再行評估，風控停損設於 {_fmt_usd(stop_ref)}'
      )
    elif (pct is not None and pct >= 6.0) or (rsi is not None and rsi >= 78.0):
      action = '觀望等待回測支撐'
      action_cls = 'neutral'
      reason = (
        f'短線急漲（單日 {(pct or 0.0):+.2f}%）正乖離偏大，切忌追高，'
        f'建議耐心等待回測支撐 {_fmt_usd(sup_ref)} 量縮守穩再分批布局'
      )
    elif regime_cls == 'bear' and (pct or 0.0) <= -1.2:
      action = '觀望等待回測支撐'
      action_cls = 'neutral'
      reason = (
        f'大盤風險偏好降溫且個股收跌 {(pct or 0.0):+.2f}%，'
        f'建議等待回測支撐 {_fmt_usd(sup_ref)} 止穩訊號，跌破 {_fmt_usd(stop_ref)} 執行停損'
      )
    else:
      action = '續抱／拉回分批布局'
      action_cls = 'bull'
      lead_parts: list[str] = []
      if sox_pct >= 1.0 and str(p.get('industry') or r.get('industry') or '') == '資訊科技':
        lead_parts.append('費半強勢')
      elif pct is not None:
        lead_parts.append(f'正規盤 {pct:+.2f}%')
      if ext_pct is not None and ext_pct >= 0.3:
        lead_parts.append(f'{ext_type}續揚 {ext_pct:+.2f}%')
      lead_txt = '＋'.join(lead_parts) if lead_parts else '量化多因子維持前段班'
      target_clause = f'，波段目標觀察 {_fmt_usd(target)}' if target is not None else ''
      reason = f'{lead_txt}，守穩支撐 {_fmt_usd(sup_ref)} 偏多看待{target_clause}'

    out.append({
      'code': code,
      'name': name,
      'close': close,
      'pct': pct,
      'ext_pct': ext_pct,
      'score': score,
      'action': action,
      'action_cls': action_cls,
      'reason': reason,
    })

  return out


def build_morning(ctx: dict[str, Any]) -> dict[str, Any]:
  """建構 /api/morning 完整戰情快照 payload（SPEC §4.6，純運算無網路呼叫）。"""
  safe_ctx = ctx if isinstance(ctx, dict) else {}
  raw_now = safe_ctx.get('now')
  now_tw = _to_tw_datetime(raw_now if isinstance(raw_now, dt.datetime) else None)
  is_trading_day = safe_ctx.get('is_trading_day')
  trading_fn = is_trading_day if callable(is_trading_day) else None

  session = us_session(now_tw, is_trading_day=trading_fn)

  rows = _normalize_rows(safe_ctx.get('rows'))
  market = safe_ctx.get('market') if isinstance(safe_ctx.get('market'), dict) else {}

  raw_picks = safe_ctx.get('picks')
  if isinstance(raw_picks, dict):
    picks_list = raw_picks.get('picks') if isinstance(raw_picks.get('picks'), list) else []
  elif isinstance(raw_picks, list):
    picks_list = raw_picks
  else:
    picks_list = []

  extended_list = safe_ctx.get('extended') if isinstance(safe_ctx.get('extended'), list) else []
  earnings_list = safe_ctx.get('earnings') if isinstance(safe_ctx.get('earnings'), list) else []
  news_list = safe_ctx.get('news') if isinstance(safe_ctx.get('news'), list) else []

  data_date = str(
    safe_ctx.get('data_date')
    or market.get('date')
    or session['et_time'][:10]
  )
  data_date_obj = _parse_iso_date(data_date)
  et_date_obj = _parse_iso_date(session['et_time'][:10]) or now_tw.date()
  # 若測試未傳入 now 但有指定歷史 data_date，以 data_date 為財報行事曆基準日
  ref_date = et_date_obj if isinstance(raw_now, dt.datetime) else (data_date_obj or et_date_obj)

  decision = _build_decision(rows, market)
  ext_movers, ext_by_code = _build_extended_movers(extended_list, rows)
  earnings_cal = _build_earnings_calendar(earnings_list, rows, ref_date, data_date_obj)

  macro = market.get('macro') if isinstance(market.get('macro'), dict) else {}
  usdtwd_node = macro.get('usdtwd') if isinstance(macro.get('usdtwd'), dict) else {}
  usdtwd_val = _num(usdtwd_node.get('close'))
  adrs = adr_bridge(rows, usdtwd_val)

  now_iso = now_tw.isoformat(timespec='seconds')
  events = _build_events(news_list, rows, market, earnings_cal, now_iso)
  rejudged = _rejudge_picks(picks_list, rows, ext_by_code, decision)

  payload = {
    'generated_at': now_iso,
    'data_date': data_date,
    'us_session': session,
    'decision': decision,
    'extended_movers': ext_movers,
    'earnings_calendar': earnings_cal,
    'adr_bridge': adrs,
    'events': events,
    'rejudged_picks': rejudged,
  }
  return _sanitize(payload)
