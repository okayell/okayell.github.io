/* 板塊與供應鏈 (#/industry) — GICS 11 板塊強弱（色塊＋排序表）與美股供應鏈卡片；
 * 供應鏈詳情 (#/industry/<CHAIN_ID>, route 'chain') 上游 → 中游 → 下游環節與個股。資料：/api/industries、/api/industry/<id>（SPEC §4.7）。 */
(function () {
  'use strict';
  var PERIODS = [['1d', '今日', 'pct_1d'], ['5d', '5日', 'pct_5d'], ['20d', '20日', 'pct_20d']];
  var PFIELD = {'1d': 'pct_1d', '5d': 'pct_5d', '20d': 'pct_20d'};
  var HEAT_MAX = {'1d': 3, '5d': 6, '20d': 12};
  var TW_INDUSTRY_URL = 'https://okayell.github.io/tw-stock-insight/#/industry';
  var I = {el: null, alive: false, data: null, tab: 'sectors', p: '1d', sort: 'pct', dir: 'desc', csort: 'default', cq: ''};

  function segBtns(attr, opts, cur) {
    return '<div class="seg">' + opts.map(function (o) {
      return '<button type="button" class="' + (o[0] === cur ? 'on' : '') + '" data-' + attr + '="' + esc(o[0]) + '">' + o[1] + '</button>';
    }).join('') + '</div>';
  }
  function leaderChips(list, n) {
    return (list || []).slice(0, n || 3).map(function (l) {
      return '<a class="chip" href="#/stock/' + encodeURIComponent(l.code) + '" data-tip="' + esc((l.name || '') + ' ' + l.code) + '">' + esc(l.code) +
        (isNum(l.pct) ? ' <span class="' + clsUpDown(l.pct) + '">' + fmtPct(l.pct, 1) + '</span>' : '') + '</a>';
    }).join('');
  }

  // ================================================================== #/industry
  function head() {
    return '<div class="ph"><h1>🏭 板塊與供應鏈</h1><span class="sub">GICS 11 大板塊漲跌與資金流向，以及美股重點產業的上中下游供應鏈</span></div>';
  }
  function readQuery(q) {
    q = q || {};
    I.tab = q.tab === 'chains' ? 'chains' : 'sectors';
    I.p = PFIELD[q.p] ? q.p : '1d';
  }
  function render(params, el) {
    I.el = el;
    I.alive = true;
    readQuery(params.query);
    setTitle('板塊與供應鏈');
    el.innerHTML = head() + skeleton(3, 200);
    el.addEventListener('click', onClick);
    el.addEventListener('input', onInput);
    return api('/api/industries').then(function (d) {
      if (!I.alive) return;
      I.data = d || {};
      paint();
    });
  }
  function paint() {
    var d = I.data;
    if (isEmptyPayload(d)) { I.el.innerHTML = head() + buildingHtml(d && d.message); return; }
    I.el.innerHTML = head() + '<div class="card flush"><div class="tabs" style="padding:0 8px" role="tablist">' +
      '<button type="button" class="' + (I.tab === 'sectors' ? 'on' : '') + '" data-itab="sectors">📊 GICS 板塊強弱（' + (d.sectors || []).length + '）</button>' +
      '<button type="button" class="' + (I.tab === 'chains' ? 'on' : '') + '" data-itab="chains">🔗 供應鏈（' + (d.chains || []).length + '）</button></div>' +
      '<div style="padding:16px" id="indBody"></div></div>' + disclaimerHtml();
    paintBody();
  }
  function syncUrl() {
    replaceHash('#/industry' + buildQuery({tab: I.tab === 'chains' ? 'chains' : '', p: I.p !== '1d' ? I.p : ''}));
  }
  function paintBody() {
    var body = document.getElementById('indBody');
    if (!body) return;
    setHtml(body, I.tab === 'sectors' ? sectorsHtml() : chainsHtml());
    syncUrl();
  }

  // ------------------------------------------------------------------ GICS sectors
  var SCOLS = [['name', '板塊', 'l'], ['count', '檔數'], ['pct_1d', '今日'], ['pct_5d', '5日'], ['pct_20d', '20日'],
    ['updown', '漲／跌'], ['value', '成交額（億美元）'], ['value_share', '占比'], ['leaders', '領漲股', 'l', 1]];
  function sortVal(c, k) {
    if (k === 'pct') return c[PFIELD[I.p]];
    if (k === 'updown') return (c.up || 0) - (c.down || 0);
    return c[k];
  }
  function sectorsHtml() {
    var secs = (I.data.sectors || []).slice(), pf = PFIELD[I.p];
    if (!secs.length) return '<div class="empty"><div class="big">📊</div><h3>板塊資料建立中</h3><p>收盤資料更新完成後會自動顯示。</p></div>';
    var key = I.sort, dir = I.dir === 'asc' ? 1 : -1;
    secs.sort(function (a, b) {
      var x = sortVal(a, key), y = sortVal(b, key);
      if (typeof x === 'string' || typeof y === 'string') return String(x || '').localeCompare(String(y || ''), 'zh-Hant') * dir;
      if (!isNum(x) || !isNum(y)) return isNum(x) ? -1 : (isNum(y) ? 1 : 0);
      return (x - y) * dir;
    });
    var heatOrder = secs.slice().sort(function (a, b) { return (b[pf] || -999) - (a[pf] || -999); });
    var heat = '<div class="ux-heat">' + heatOrder.map(function (c) {
      var col = heatColor(c[pf], HEAT_MAX[I.p]);
      var tip = c.name + (c.en ? '（' + c.en + '）' : '') + '\n今日 ' + fmtPct(c.pct_1d) + '・5日 ' + fmtPct(c.pct_5d) + '・20日 ' + fmtPct(c.pct_20d) +
        '\n成交額 ' + fmtUsdYi(c.value) + (isNum(c.value_share) ? '（' + fmtNum(c.value_share, 1) + '%）' : '') +
        '\n上漲 ' + fmtInt(c.up) + '／下跌 ' + fmtInt(c.down) + '（共 ' + fmtInt(c.count) + ' 檔）';
      var lead = (c.leaders || [])[0];
      return '<div class="t" data-href="#/screener?ind=' + encodeURIComponent(c.name) + '" data-tip="' + esc(tip) + '" style="background:' + col.bg + ';color:' + col.fg + '">' +
        '<span class="tn">' + esc(c.name) + '</span><span class="tp">' + fmtPct(c[pf]) + '</span>' +
        '<span class="ts">' + (lead ? '領漲 ' + esc(lead.code) + ' ' + fmtPct(lead.pct, 1) : esc(c.en || '')) + '</span></div>';
    }).join('') + '</div>';
    var rows = secs.map(function (c) {
      return '<tr data-href="#/screener?ind=' + encodeURIComponent(c.name) + '"><td class="l"><b>' + esc(c.name) + '</b>' + (c.en ? '<div class="small muted">' + esc(c.en) + '</div>' : '') + '</td>' +
        '<td>' + fmtInt(c.count) + '</td>' + ['pct_1d', 'pct_5d', 'pct_20d'].map(function (k) {
          return '<td class="' + clsUpDown(c[k]) + '">' + (k === pf ? '<b>' + fmtPct(c[k]) + '</b>' : fmtPct(c[k])) + '</td>';
        }).join('') +
        '<td><span class="up">' + fmtInt(c.up) + '</span> / <span class="down">' + fmtInt(c.down) + '</span></td>' +
        '<td>' + fmtYi(c.value) + '</td><td>' + (isNum(c.value_share) ? fmtNum(c.value_share, 1) + '%' : '—') + '</td>' +
        '<td class="l"><div class="sigs">' + leaderChips(c.leaders, 3) + '</div></td></tr>';
    }).join('');
    return '<div class="row wrap" style="margin-bottom:12px"><b>漲跌期間</b>' + segBtns('per', PERIODS, I.p) +
      '<span class="small muted">板塊漲跌以市值加權；點色塊或列可在選股器查看該板塊個股</span></div>' + heat +
      '<div class="tbl-wrap mt"><table class="tbl dense"><thead><tr>' + SCOLS.map(function (c) {
        var k = /^pct_/.test(c[0]) ? (c[0] === pf ? 'pct' : null) : c[0];
        var sortable = !c[3] && k;
        var on = sortable && I.sort === k;
        return '<th class="' + (c[2] || '') + (sortable ? ' sortable' : '') + (on ? ' sorted' + (I.dir === 'asc' ? ' asc' : '') : '') + (c[0] === pf ? ' sel' : '') + '"' +
          (sortable ? ' data-ssort="' + k + '"' : (/^pct_/.test(c[0]) ? ' data-per="' + c[0].slice(4) + '" style="cursor:pointer" data-tip="切換為' + c[1] + '漲跌"' : '')) + '>' + c[1] + '</th>';
      }).join('') + '</tr></thead><tbody>' + rows + '</tbody></table></div>';
  }

  // ------------------------------------------------------------------ chains list
  function streamCounts(s) {
    if (Array.isArray(s)) return s.map(function (x) { return typeof x === 'string' ? x : (x.stream || x.name || ''); }).filter(Boolean);
    if (s && typeof s === 'object') return Object.keys(s).map(function (k) { return k + (isNum(s[k]) ? ' ' + s[k] : ''); });
    return [];
  }
  function chainsHtml() {
    var chains = (I.data.chains || []).slice(), pf = I.p === '20d' ? 'pct_20d' : 'pct_1d', q = I.cq.trim().toLowerCase();
    if (!chains.length) return '<div class="empty"><div class="big">🔗</div><h3>供應鏈資料建立中</h3><p>完成後會自動顯示。</p></div>';
    if (q) chains = chains.filter(function (c) { return ((c.name || '') + ' ' + (c.id || '') + ' ' + (c.summary || '')).toLowerCase().indexOf(q) >= 0; });
    if (I.csort === 'pct') chains.sort(function (a, b) { return (isNum(b[pf]) ? b[pf] : -999) - (isNum(a[pf]) ? a[pf] : -999); });
    else if (I.csort === 'count') chains.sort(function (a, b) { return (b.stock_count || 0) - (a.stock_count || 0); });
    return '<div class="row wrap" style="margin-bottom:12px"><input class="input" id="chainQ" type="search" placeholder="搜尋供應鏈（例如：AI、電動車、雲端）" value="' + esc(I.cq) +
      '" style="flex:1 1 220px;max-width:320px;min-width:0" autocomplete="off">' + segBtns('per', [['1d', '今日'], ['20d', '20日']], I.p === '20d' ? '20d' : '1d') +
      '<span class="small muted">排序</span>' + segBtns('csort', [['default', '預設'], ['pct', '漲幅'], ['count', '檔數']], I.csort) + '</div>' +
      (chains.length ? '<div class="ux-grid">' + chains.map(function (c) {
        var href = '#/industry/' + encodeURIComponent(c.id);
        return '<div class="chain-card" data-href="' + esc(href) + '" role="link" tabindex="0">' +
          '<div class="hd"><b>' + esc(c.icon || '🔗') + ' <a href="' + esc(href) + '" style="color:inherit">' + esc(c.name) + '</a></b><span class="p ' + clsUpDown(c[pf]) + '">' + fmtPct(c[pf]) + '</span></div>' +
          (c.summary ? '<div class="small muted" style="line-height:1.6">' + esc(c.summary) + '</div>' : '') +
          '<div class="pp"><div class="' + (pf === 'pct_1d' ? 'sel' : '') + '"><span>今日</span><b class="' + clsUpDown(c.pct_1d) + '">' + fmtPct(c.pct_1d, 1) + '</b></div>' +
          '<div class="' + (pf === 'pct_20d' ? 'sel' : '') + '"><span>20日</span><b class="' + clsUpDown(c.pct_20d) + '">' + fmtPct(c.pct_20d, 1) + '</b></div>' +
          '<div><span>追蹤個股</span><b>' + fmtInt(c.stock_count) + ' 檔</b></div></div>' +
          '<div class="chips">' + streamCounts(c.streams).map(function (s) { return '<span class="chip ghost">' + esc(s) + '</span>'; }).join('') + '</div>' +
          ((c.leaders || []).length ? '<div class="chips">' + leaderChips(c.leaders, 4) + '</div>' : '') + '</div>';
      }).join('') + '</div>' : '<div class="empty">找不到「' + esc(I.cq) + '」相關的供應鏈</div>') +
      '<div class="small muted mt">漲跌幅為鏈上個股市值加權平均；🇹🇼 想看對應的台股供應鏈，可前往 <a href="' + TW_INDUSTRY_URL + '" target="_blank" rel="noopener">台股戰情室 產業鏈 ↗</a>。</div>';
  }

  function onClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-itab]'))) {
      I.tab = x.getAttribute('data-itab');
      $$('[data-itab]', I.el).forEach(function (b) { b.classList.toggle('on', b === x); });
      paintBody();
      return;
    }
    if ((x = t.closest('[data-per]'))) { I.p = x.getAttribute('data-per'); paintBody(); return; }
    if ((x = t.closest('[data-csort]'))) { I.csort = x.getAttribute('data-csort'); paintBody(); return; }
    if ((x = t.closest('[data-ssort]'))) {
      var k = x.getAttribute('data-ssort');
      if (I.sort === k) I.dir = I.dir === 'desc' ? 'asc' : 'desc';
      else { I.sort = k; I.dir = k === 'name' ? 'asc' : 'desc'; }
      paintBody();
    }
  }
  var chainFilterLater = App.debounce(function () {
    if (!I.alive || I.tab !== 'chains') return;
    var input = document.getElementById('chainQ'), pos = input ? input.selectionStart : 0;
    paintBody();
    var again = document.getElementById('chainQ');
    if (again) { again.focus({preventScroll: true}); try { again.setSelectionRange(pos, pos); } catch (e) { /* ignore */ } }
  }, 160);
  function onInput(ev) { if (ev.target.id === 'chainQ') { I.cq = ev.target.value; chainFilterLater(); } }
  function onKeyNav(ev) {
    if (ev.key !== 'Enter') return;
    var c = ev.target.classList && ev.target.classList.contains('chain-card') ? ev.target : null;
    if (c) navigate(c.getAttribute('data-href'));
  }

  window.Pages.industry = {
    render: function (params, el) { el.addEventListener('keydown', onKeyNav); return render(params, el); },
    update: function (params) {
      if (!I.alive || !I.data) return false;
      var tab = I.tab, p = I.p;
      readQuery(params.query);
      if (tab !== I.tab || p !== I.p) paint();
      return true;
    },
    destroy: function () {
      I.alive = false;
      if (I.el) { I.el.removeEventListener('click', onClick); I.el.removeEventListener('input', onInput); I.el.removeEventListener('keydown', onKeyNav); }
    }
  };

  // ================================================================== #/industry/<id>
  var C = {el: null, alive: false, id: '', d: null};

  function stocksOf(g) { return g.stocks || g.companies || []; }
  function avg(list, k) {
    var v = list.map(function (s) { return s[k]; }).filter(isNum);
    return v.length ? v.reduce(function (a, b) { return a + b; }, 0) / v.length : null;
  }
  function segId(si, gi) { return 'chSeg' + si + '_' + gi; }

  function renderChain(params, el) {
    C = {el: el, alive: true, id: String(params.id || ''), d: null};
    setTitle('供應鏈');
    el.innerHTML = '<div class="skel" style="height:90px"></div><div class="skel mt" style="height:380px"></div>';
    el.addEventListener('click', onChainClick);
    return api('/api/industry/' + encodeURIComponent(C.id)).then(function (d) {
      if (!C.alive) return;
      C.d = d || {};
      if (isEmptyPayload(C.d)) { el.innerHTML = '<div class="ph"><h1>供應鏈</h1></div>' + buildingHtml(C.d.message); return; }
      setTitle((C.d.name || C.id) + ' 供應鏈');
      paintChain();
    }, function (e) {
      if (!C.alive) return;
      el.innerHTML = '<div class="ph"><h1>供應鏈</h1></div><div class="card empty err"><div class="big">🔗</div><h3>' +
        (e && e.status === 404 ? '找不到這條供應鏈（' + esc(C.id) + '）' : '無法載入供應鏈') + '</h3><p>' + esc(e && e.message) +
        '</p><a class="btn sm" href="#/industry?tab=chains">回到供應鏈列表</a></div>';
    });
  }
  function stockTable(list) {
    if (!list.length) return '<div class="small muted">此環節目前沒有追蹤中的個股。</div>';
    var rows = list.slice().sort(function (a, b) { return (b.mcap || 0) - (a.mcap || 0); });
    return '<div class="tbl-wrap"><table class="tbl dense"><thead><tr><th class="c" style="width:30px"></th><th class="l">代號／名稱</th><th class="l">供應鏈角色</th>' +
      '<th>收盤</th><th>漲跌</th><th>20日</th><th>本益比</th><th>市值</th><th>綜合分</th></tr></thead><tbody>' + rows.map(function (s) {
        var href = '#/stock/' + encodeURIComponent(s.code);
        return '<tr data-href="' + esc(href) + '"><td class="c">' + starBtn(s.code, 'icon') + '</td>' +
          '<td class="l"><a class="nm" href="' + esc(href) + '">' + esc(s.code) + '</a> <span class="small muted">' + esc(s.name || '') + '</span></td>' +
          '<td class="l wrap"><span class="small">' + esc(s.role || '—') + '</span></td>' +
          '<td>' + fmtUsd(s.close) + '</td><td class="' + clsUpDown(s.pct) + '">' + fmtPct(s.pct) + '</td>' +
          '<td class="' + clsUpDown(s.r20) + '">' + fmtPct(s.r20, 1) + '</td><td>' + fmtNum(s.pe, 1) + '</td><td>' + fmtUsdYi(s.mcap) + '</td>' +
          '<td><b style="color:' + scoreColor(s.score) + '">' + (isNum(s.score) ? Math.round(s.score) : '—') + '</b></td></tr>';
      }).join('') + '</tbody></table></div>';
  }
  function paintChain() {
    var d = C.d, streams = d.streams || [];
    var cols = streams.map(function () { return 'minmax(0,1fr)'; }).join(' 28px ') || 'minmax(0,1fr)';
    var flow = streams.map(function (s, si) {
      var all = [];
      (s.segments || []).forEach(function (g) { all = all.concat(stocksOf(g)); });
      var sp = avg(all, 'pct');
      return (si ? '<div class="flow-arrow" aria-hidden="true">➜</div>' : '') + '<div class="flow-col"><h3>' + esc(s.stream || s.name || '') +
        (isNum(sp) ? ' <span class="' + clsUpDown(sp) + '">' + fmtPct(sp, 1) + '</span>' : '') + '</h3>' +
        (s.desc ? '<div class="small muted" style="text-align:center;margin-top:-4px;line-height:1.5">' + esc(s.desc) + '</div>' : '') +
        (s.segments || []).map(function (g, gi) {
          var st = stocksOf(g), p = avg(st, 'pct');
          return '<button type="button" class="seg-card" data-jump="' + segId(si, gi) + '" data-tip="' + esc(g.desc || g.name || '') + '">' +
            '<span class="nm">' + esc(g.name || '') + (isNum(p) ? '<span class="p ' + clsUpDown(p) + '">' + fmtPct(p, 1) + '</span>' : '') + '</span>' +
            '<span class="mt2">' + st.length + ' 檔' + (st.length ? '：' + esc(st.slice(0, 4).map(function (x) { return x.code; }).join('、')) : '') + '</span></button>';
        }).join('') + '</div>';
    }).join('');
    var detail = streams.map(function (s, si) {
      return '<section class="card mt"><div class="card-h"><span class="chip info">' + esc(s.stream || s.name || '') + '</span>' +
        (s.desc ? '<span class="sub">' + esc(s.desc) + '</span>' : '') + '</div>' +
        (s.segments || []).map(function (g, gi) {
          return '<div id="' + segId(si, gi) + '" style="scroll-margin-top:calc(var(--hdr-h, 56px) + 16px)"><div class="subh">' + esc(g.name || '') + '</div>' +
            (g.desc ? '<div class="small muted" style="margin:-4px 0 8px;line-height:1.6">' + esc(g.desc) + '</div>' : '') + stockTable(stocksOf(g)) + '</div>';
        }).join('') + '</section>';
    }).join('');
    var tw = '<div class="card mt" style="border-color:#bfdbfe;background:#f8fbff"><div class="row wrap"><b>🇹🇼 台股供應鏈對照</b><span class="sp"></span>' +
      '<a class="btn xs" href="' + TW_INDUSTRY_URL + '" target="_blank" rel="noopener">前往台股戰情室 產業鏈 ↗</a></div>' +
      '<div class="small mt-xs" style="line-height:1.7;color:var(--text-2)">' + esc(d.tw_link_note || '同一條供應鏈的台灣供應商，可在台股戰情室的產業鏈頁查看。') + '</div></div>';
    C.el.innerHTML = '<div class="ph"><a class="btn sm ghost" href="#/industry?tab=chains">← 供應鏈列表</a><h1>' + esc(d.icon || '🔗') + ' ' + esc(d.name || C.id) + '</h1></div>' +
      (d.summary ? '<section class="card intro"><p>' + esc(d.summary) + '</p></section>' : '') + tw +
      '<section class="card mt"><div class="card-h"><h2>🔗 供應鏈結構</h2><span class="sub">點選環節跳到該環節個股；百分比為環節內個股平均漲跌</span></div>' +
      (streams.length ? '<div class="flow"' + (streams.length === 3 ? '' : ' style="grid-template-columns:' + cols + '"') + '>' + flow + '</div>' : '<div class="empty">此供應鏈沒有環節資料</div>') + '</section>' +
      detail + disclaimerHtml();
  }
  function onChainClick(ev) {
    var x = ev.target.closest('[data-jump]');
    if (!x) return;
    var tgt = document.getElementById(x.getAttribute('data-jump'));
    if (tgt) tgt.scrollIntoView({behavior: 'smooth', block: 'start'});
  }

  window.Pages.chain = {
    render: renderChain,
    update: function (params) { return !!(C.alive && C.d && String(params.id) === C.id); },
    destroy: function () {
      C.alive = false;
      if (C.el) C.el.removeEventListener('click', onChainClick);
    }
  };
})();
