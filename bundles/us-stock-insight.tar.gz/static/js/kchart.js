/* 美股 K 線圖元件 (TradingView Lightweight Charts v4.2.3) — 漲跌配色跟隨 App.getColorMode()
 * （預設 us 綠漲紅跌、tw 紅漲綠跌），訂閱 App.onColorMode() 即時重繪 K 棒、量柱、MACD 柱與多空箭頭。
 * candles + MA5…MA240 + Bollinger, volume pane, KD / MACD / RSI pane,
 * synced time scales + crosshair, hover legends and analysis annotations.
 * Usage: var kc = new KChart(rootEl, {ma: {ma5: true}, bb: false, sub: 'kd'}); kc.setData(payload); kc.destroy();
 */
(function () {
  'use strict';
  var UP = '#16a34a', DOWN = '#dc2626';
  var UP_A = 'rgba(22,163,74,.55)', DOWN_A = 'rgba(220,38,38,.55)';
  // ta.py emits US-convention annotation colours (bull green / bear red); remap them to the live mode.
  var TA_BULL = '#16a34a', TA_BEAR = '#dc2626';
  function hexA(hex, a) {
    var n = parseInt(String(hex).slice(1), 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function syncColors() {
    var A = window.App;
    UP = A && A.upColor ? A.upColor() : '#16a34a';
    DOWN = A && A.downColor ? A.downColor() : '#dc2626';
    UP_A = hexA(UP, 0.55);
    DOWN_A = hexA(DOWN, 0.55);
  }
  function mapAnnColor(c) {
    var k = String(c || '').toLowerCase();
    if (k === TA_BULL) return UP;
    if (k === TA_BEAR) return DOWN;
    return c;
  }
  /** Fills missing indicators (static build ships bars without `ind`). */
  function ensureInd(bars, ind) {
    if (ind && Object.keys(ind).length) return ind;
    if (!bars || !bars.length) return {};
    var T = window.TWInd || window.USInd, A = window.TA;
    try {
      if (T && T.compute) return T.compute(bars) || {};
      if (A && A.computeIndicators) return A.computeIndicators(bars) || {};
    } catch (e) { console.error(e); }
    return {};
  }
  var MA_DEF = [['ma5', 'MA5', '#f59e0b'], ['ma10', 'MA10', '#0ea5e9'], ['ma20', 'MA20', '#a855f7'],
    ['ma60', 'MA60', '#14b8a6'], ['ma120', 'MA120', '#64748b'], ['ma240', 'MA240', '#b45309']];
  var SUB_DEF = {
    kd: [['k', 'K', '#2563eb'], ['d', 'D', '#f59e0b']],
    macd: [['dif', 'DIF', '#2563eb'], ['dea', 'DEA', '#f59e0b']],
    rsi: [['rsi6', 'RSI6', '#2563eb'], ['rsi14', 'RSI14', '#a855f7']]
  };

  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function lineStyleOf(s) {
    var L = window.LightweightCharts.LineStyle;
    var map = {solid: L.Solid, dotted: L.Dotted, dashed: L.Dashed, large_dashed: L.LargeDashed, sparse: L.SparseDotted};
    return map[s] !== undefined ? map[s] : L.Dashed;
  }
  function tickFmt(t, type) {
    var y, m, d;
    if (typeof t === 'string') { y = +t.slice(0, 4); m = +t.slice(5, 7); d = +t.slice(8, 10); }
    else if (t && typeof t === 'object') { y = t.year; m = t.month; d = t.day; }
    else { var dt = new Date(t * 1000); y = dt.getUTCFullYear(); m = dt.getUTCMonth() + 1; d = dt.getUTCDate(); }
    if (type === 0) return y + '年';
    if (type === 1) return m + '月';
    return m + '/' + d;
  }
  function addMonths(iso, months) {
    var d = new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10)));
    d.setUTCMonth(d.getUTCMonth() - months);
    return d.toISOString().slice(0, 10);
  }

  function KChart(root, opts) {
    var LC = window.LightweightCharts;
    if (!LC) throw new Error('圖表程式庫載入失敗');
    opts = opts || {};
    syncColors();
    this.root = root;
    this.maOn = Object.assign({ma5: true, ma20: true, ma60: true}, opts.ma || {});
    this.bbOn = !!opts.bb;
    this.subMode = opts.sub || 'kd';
    this.annVisible = true;
    this.ann = null;
    this.bars = [];
    this.times = [];
    this.ind = {};
    this.n = 0;
    this._plines = [];
    this._segs = [];
    this._subSeries = [];
    this._legendIdx = -1;
    root.innerHTML =
      '<div class="kc-pane kc-main"><div class="kc-legend" data-l="main"></div></div>' +
      '<div class="kc-pane kc-vol"><div class="kc-legend" data-l="vol"></div></div>' +
      '<div class="kc-pane kc-sub"><div class="kc-legend" data-l="sub"></div></div>';
    this.panes = [root.querySelector('.kc-main'), root.querySelector('.kc-vol'), root.querySelector('.kc-sub')];
    this.legends = [root.querySelector('[data-l=main]'), root.querySelector('[data-l=vol]'), root.querySelector('[data-l=sub]')];
    var font = getComputedStyle(document.body).fontFamily;
    var self = this;
    function base(showTime) {
      return {
        width: self.panes[0].clientWidth || 800,
        height: 200,
        layout: {background: {type: 'solid', color: '#ffffff'}, textColor: '#475569', fontSize: 11, fontFamily: font, attributionLogo: false},
        grid: {vertLines: {color: '#f3f5f8'}, horzLines: {color: '#f3f5f8'}},
        rightPriceScale: {borderColor: '#e5e7eb', minimumWidth: 86, entireTextOnly: true},
        timeScale: {borderColor: '#e5e7eb', visible: showTime, rightOffset: 4, barSpacing: 8, minBarSpacing: 0.4,
          tickMarkFormatter: tickFmt, lockVisibleTimeRangeOnResize: true},
        crosshair: {mode: LC.CrosshairMode.Normal,
          vertLine: {color: '#94a3b8', width: 1, style: LC.LineStyle.Dashed, labelBackgroundColor: '#334155', labelVisible: showTime},
          horzLine: {color: '#94a3b8', width: 1, style: LC.LineStyle.Dashed, labelBackgroundColor: '#334155'}},
        localization: {locale: 'zh-TW', dateFormat: 'yyyy-MM-dd'},
        handleScroll: {mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false},
        handleScale: {axisPressedMouseMove: {time: true, price: true}, mouseWheel: true, pinch: true}
      };
    }
    this.main = LC.createChart(this.panes[0], base(false));
    this.vol = LC.createChart(this.panes[1], base(false));
    this.sub = LC.createChart(this.panes[2], base(true));
    this.charts = [this.main, this.vol, this.sub];
    this.main.priceScale('right').applyOptions({scaleMargins: {top: 0.08, bottom: 0.05}});
    this.vol.priceScale('right').applyOptions({scaleMargins: {top: 0.18, bottom: 0}});
    this.sub.priceScale('right').applyOptions({scaleMargins: {top: 0.12, bottom: 0.08}});
    this.candle = this.main.addCandlestickSeries({upColor: UP, downColor: DOWN, borderUpColor: UP, borderDownColor: DOWN,
      wickUpColor: UP, wickDownColor: DOWN, priceLineWidth: 1, priceLineStyle: LC.LineStyle.Dotted});
    this.ma = {};
    MA_DEF.forEach(function (d) {
      self.ma[d[0]] = self.main.addLineSeries({color: d[2], lineWidth: 1, priceLineVisible: false, lastValueVisible: false,
        crosshairMarkerVisible: false});
    });
    var bbOpt = {color: '#94a3b8', lineWidth: 1, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false};
    this.bb = {
      bb_up: this.main.addLineSeries(Object.assign({lineStyle: LC.LineStyle.Dashed}, bbOpt)),
      bb_mid: this.main.addLineSeries(Object.assign({lineStyle: LC.LineStyle.Dotted}, bbOpt)),
      bb_lo: this.main.addLineSeries(Object.assign({lineStyle: LC.LineStyle.Dashed}, bbOpt))
    };
    var volFmt = {type: 'custom', minMove: 1, formatter: function (v) { return window.fmtCompact ? window.fmtCompact(v) : String(Math.round(v)); }};
    this.volS = this.vol.addHistogramSeries({priceFormat: volFmt, priceLineVisible: false, lastValueVisible: false});
    this.volMa5 = this.vol.addLineSeries({color: '#f59e0b', lineWidth: 1, priceLineVisible: false, lastValueVisible: false,
      crosshairMarkerVisible: false, priceFormat: volFmt});
    this.volMa20 = this.vol.addLineSeries({color: '#a855f7', lineWidth: 1, priceLineVisible: false, lastValueVisible: false,
      crosshairMarkerVisible: false, priceFormat: volFmt});
    // Time-scale + crosshair sync.
    this._syncing = false;
    this.charts.forEach(function (c, i) {
      c.timeScale().subscribeVisibleLogicalRangeChange(function (r) {
        if (!r || self._syncing) return;
        self._syncing = true;
        self.charts.forEach(function (o, j) { if (j !== i) o.timeScale().setVisibleLogicalRange(r); });
        self._syncing = false;
      });
      c.subscribeCrosshairMove(function (p) { self._onCross(i, p); });
    });
    // Responsive sizing (one layout read per frame).
    this._raf = 0;
    this._ro = new ResizeObserver(function () {
      if (self._raf) return;
      self._raf = requestAnimationFrame(function () { self._raf = 0; self.resize(); });
    });
    this._ro.observe(root);
    this.resize();
    if (window.App && window.App.onColorMode) {
      this._offCm = window.App.onColorMode(function () { self.setColorMode(); });
    }
  }

  /** Re-applies up/down colours after the 漲跌配色 toggle (no page reload, keeps zoom). */
  KChart.prototype.setColorMode = function () {
    if (!this.charts) return;
    syncColors();
    this.candle.applyOptions({upColor: UP, downColor: DOWN, borderUpColor: UP, borderDownColor: DOWN, wickUpColor: UP, wickDownColor: DOWN});
    var range = this.main.timeScale().getVisibleLogicalRange();
    this.volS.setData(this.bars.map(function (b) { return {time: b[0], value: b[5] || 0, color: b[4] >= b[1] ? UP_A : DOWN_A}; }));
    this._applySub();
    if (this.ann && this.annVisible) { this._clearAnn(); this._drawAnn(); }
    this._legendIdx = -1;
    this._legend(this.n - 1);
    if (range) this.main.timeScale().setVisibleLogicalRange(range);
  };

  KChart.prototype.resize = function () {
    if (!this.charts) return;
    var w = this.root.clientWidth;
    if (!w) return;
    for (var i = 0; i < 3; i++) this.charts[i].resize(w, this.panes[i].clientHeight || 100);
  };

  KChart.prototype._line = function (arr) {
    var t = this.times, out = new Array(t.length);
    for (var i = 0; i < t.length; i++) out[i] = isNum(arr && arr[i]) ? {time: t[i], value: arr[i]} : {time: t[i]};
    return out;
  };

  KChart.prototype.setData = function (payload) {
    syncColors();
    var raw = (payload && payload.bars) || [], ind = ensureInd(raw, payload && payload.ind);
    var keep = [], bars = [];
    for (var i = 0; i < raw.length; i++) {
      if (i && raw[i][0] <= raw[i - 1][0]) continue; // defensive: strictly ascending
      keep.push(i);
      bars.push(raw[i]);
    }
    var ind2 = {};
    Object.keys(ind).forEach(function (k) {
      var a = ind[k] || [];
      ind2[k] = keep.length === raw.length ? a : keep.map(function (j) { return a[j]; });
    });
    this.bars = bars;
    this.ind = ind2;
    this.n = bars.length;
    this.times = bars.map(function (b) { return b[0]; });
    var last = bars.length ? bars[bars.length - 1][4] : 100;
    var prec = window.pricePrec ? window.pricePrec(last) : 2;
    this.prec = prec;
    this.candle.applyOptions({priceFormat: {type: 'price', precision: prec, minMove: Math.pow(10, -prec)}});
    this.candle.setData(bars.map(function (b) { return {time: b[0], open: b[1], high: b[2], low: b[3], close: b[4]}; }));
    this._applyMA();
    this._applyBB();
    this.volS.setData(bars.map(function (b) { return {time: b[0], value: b[5] || 0, color: b[4] >= b[1] ? UP_A : DOWN_A}; }));
    this.volMa5.setData(this._line(ind2.vol_ma5));
    this.volMa20.setData(this._line(ind2.vol_ma20));
    this._applySub();
    this._legendIdx = -1;
    this._legend(this.n - 1);
    if (this.ann && this.annVisible) { this._clearAnn(); this._drawAnn(); }
  };

  KChart.prototype._applyMA = function () {
    var self = this;
    MA_DEF.forEach(function (d) { self.ma[d[0]].setData(self.maOn[d[0]] ? self._line(self.ind[d[0]]) : []); });
  };
  KChart.prototype._applyBB = function () {
    var self = this;
    Object.keys(this.bb).forEach(function (k) { self.bb[k].setData(self.bbOn ? self._line(self.ind[k]) : []); });
  };
  KChart.prototype.setMA = function (key, on) {
    this.maOn[key] = !!on;
    this.ma[key].setData(on ? this._line(this.ind[key]) : []);
    this._legendIdx = -1;
    this._legend(this.n - 1);
  };
  KChart.prototype.setBB = function (on) {
    this.bbOn = !!on;
    this._applyBB();
    this._legendIdx = -1;
    this._legend(this.n - 1);
  };
  KChart.prototype.setSub = function (mode) {
    if (!SUB_DEF[mode]) return;
    this.subMode = mode;
    this._applySub();
    this._legendIdx = -1;
    this._legend(this.n - 1);
  };
  KChart.prototype._applySub = function () {
    var LC = window.LightweightCharts, self = this, sub = this.sub, mode = this.subMode;
    this._subSeries.forEach(function (s) { sub.removeSeries(s); });
    this._subSeries = [];
    var fixed = mode !== 'macd' ? function () { return {priceRange: {minValue: 0, maxValue: 100}}; } : undefined;
    if (mode === 'macd') {
      var h = sub.addHistogramSeries({priceLineVisible: false, lastValueVisible: false,
        priceFormat: {type: 'price', precision: 2, minMove: 0.01}});
      var hist = this.ind.hist || [];
      h.setData(this.times.map(function (t, i) {
        return isNum(hist[i]) ? {time: t, value: hist[i], color: hist[i] >= 0 ? UP_A : DOWN_A} : {time: t};
      }));
      this._subSeries.push(h);
    }
    SUB_DEF[mode].forEach(function (d) {
      var s = sub.addLineSeries({color: d[2], lineWidth: 1, priceLineVisible: false, lastValueVisible: true,
        crosshairMarkerVisible: false, autoscaleInfoProvider: fixed, priceFormat: {type: 'price', precision: 2, minMove: 0.01}});
      s.setData(self._line(self.ind[d[0]]));
      self._subSeries.push(s);
    });
    var ref = this._subSeries[this._subSeries.length - 2] || this._subSeries[0];
    var levels = mode === 'kd' ? [80, 20] : (mode === 'rsi' ? [70, 30] : [0]);
    levels.forEach(function (v) {
      ref.createPriceLine({price: v, color: '#cbd5e1', lineWidth: 1, lineStyle: LC.LineStyle.Dashed, axisLabelVisible: false, title: ''});
    });
  };

  KChart.prototype.setRange = function (months) {
    if (!this.n) return;
    var from = 0;
    if (months) {
      var cut = addMonths(this.times[this.n - 1], months), lo = 0, hi = this.n - 1;
      while (lo < hi) { var mid = (lo + hi) >> 1; if (this.times[mid] < cut) lo = mid + 1; else hi = mid; }
      from = lo;
    }
    this.main.timeScale().setVisibleLogicalRange({from: from - 0.5, to: this.n - 1 + 4});
  };

  KChart.prototype._onCross = function (i, p) {
    if (this._xsync || !this.n) return;
    var idx = (p && p.time !== undefined && isNum(p.logical)) ? Math.max(0, Math.min(this.n - 1, Math.round(p.logical))) : null;
    this._xsync = true;
    for (var j = 0; j < 3; j++) {
      if (j === i) continue;
      var c = this.charts[j];
      if (idx === null) { c.clearCrosshairPosition(); continue; }
      var s, v;
      if (j === 0) { s = this.candle; v = this.bars[idx][4]; }
      else if (j === 1) { s = this.volS; v = this.bars[idx][5] || 0; }
      else {
        s = this._subSeries[this._subSeries.length - 2] || this._subSeries[0];
        var key = SUB_DEF[this.subMode][0][0];
        v = this.ind[key] && isNum(this.ind[key][idx]) ? this.ind[key][idx] : (this.subMode === 'macd' ? 0 : 50);
      }
      if (s) c.setCrosshairPosition(v, this.times[idx], s);
    }
    this._xsync = false;
    this._legend(idx === null ? this.n - 1 : idx);
  };

  function f2(v) { return isNum(v) ? (window.fmtNum ? window.fmtNum(v, 2) : v.toFixed(2)) : '—'; }
  KChart.prototype._legend = function (idx) {
    if (!this.n || idx < 0) {
      this.legends.forEach(function (l) { l.innerHTML = ''; });
      return;
    }
    if (idx === this._legendIdx) return;
    this._legendIdx = idx;
    var b = this.bars[idx], prev = idx > 0 ? this.bars[idx - 1][4] : b[1], ind = this.ind, self = this;
    var ref = b[4], fp = function (v) { return window.fmtPrice ? window.fmtPrice(v, ref) : String(v); };
    var chg = b[4] - prev, pct = prev ? chg / prev * 100 : 0, cls = chg > 0 ? 'up' : (chg < 0 ? 'down' : 'flat');
    var h = '<span class="t">' + b[0] + '</span><span>開 <b>' + fp(b[1]) + '</b></span><span>高 <b>' + fp(b[2]) +
      '</b></span><span>低 <b>' + fp(b[3]) + '</b></span><span>收 <b class="' + cls + '">' + fp(b[4]) + '</b></span><span class="' + cls +
      '"><b>' + (chg > 0 ? '+' : '') + fp(chg) + ' (' + (pct > 0 ? '+' : '') + pct.toFixed(2) + '%)</b></span>';
    MA_DEF.forEach(function (d) {
      if (self.maOn[d[0]] && ind[d[0]]) h += '<span style="color:' + d[2] + '">' + d[1] + ' <b>' + (isNum(ind[d[0]][idx]) ? fp(ind[d[0]][idx]) : '—') + '</b></span>';
    });
    if (this.bbOn && ind.bb_up) {
      h += '<span style="color:#64748b">布林 <b>' + (isNum(ind.bb_up[idx]) ? fp(ind.bb_up[idx]) + ' / ' + fp(ind.bb_lo[idx]) : '—') + '</b></span>';
    }
    this.legends[0].innerHTML = h;
    var fc = window.fmtShares || window.fmtInt || function (v) { return String(v); };
    this.legends[1].innerHTML = '<span class="t">成交量</span><span><b class="' + cls + '">' + fc(b[5]) + '</b></span>' +
      '<span style="color:#f59e0b">MA5 <b>' + (ind.vol_ma5 && isNum(ind.vol_ma5[idx]) ? fc(ind.vol_ma5[idx]) : '—') + '</b></span>' +
      '<span style="color:#a855f7">MA20 <b>' + (ind.vol_ma20 && isNum(ind.vol_ma20[idx]) ? fc(ind.vol_ma20[idx]) : '—') + '</b></span>';
    var s = '<span class="t">' + {kd: 'KD(9)', macd: 'MACD(12,26,9)', rsi: 'RSI'}[this.subMode] + '</span>';
    SUB_DEF[this.subMode].forEach(function (d) {
      s += '<span style="color:' + d[2] + '">' + d[1] + ' <b>' + f2(ind[d[0]] && ind[d[0]][idx]) + '</b></span>';
    });
    if (this.subMode === 'macd' && ind.hist) {
      var hv = ind.hist[idx];
      s += '<span>OSC <b class="' + (hv > 0 ? 'up' : hv < 0 ? 'down' : '') + '">' + f2(hv) + '</b></span>';
    }
    this.legends[2].innerHTML = s;
  };

  // ------------------------------------------------------------------ annotations
  KChart.prototype._snap = function (date) {
    if (!this.n || !date) return null;
    var t = this.times;
    if (date < t[0]) return null;
    if (date >= t[this.n - 1]) return t[this.n - 1];
    var lo = 0, hi = this.n - 1;
    while (lo < hi) { var mid = (lo + hi + 1) >> 1; if (t[mid] <= date) lo = mid; else hi = mid - 1; }
    return t[lo];
  };
  KChart.prototype.setAnnotations = function (ann) {
    this._clearAnn();
    this.ann = ann || null;
    if (this.ann && this.annVisible) this._drawAnn();
  };
  KChart.prototype.showAnnotations = function (on) {
    this.annVisible = !!on;
    this._clearAnn();
    if (on && this.ann) this._drawAnn();
  };
  KChart.prototype._clearAnn = function () {
    var self = this;
    this._plines.forEach(function (l) { try { self.candle.removePriceLine(l); } catch (e) { /* gone */ } });
    this._plines = [];
    this._segs.forEach(function (s) { try { self.main.removeSeries(s); } catch (e) { /* gone */ } });
    this._segs = [];
    this.candle.setMarkers([]);
  };
  KChart.prototype._drawAnn = function () {
    var a = this.ann, self = this;
    if (!a || !this.n) return;
    var narrow = this.root.clientWidth < 640; // titles would cover the candles on phones
    (a.lines || []).forEach(function (l) {
      if (!isNum(l.price)) return;
      self._plines.push(self.candle.createPriceLine({price: l.price, color: mapAnnColor(l.color) || '#64748b', lineWidth: 1,
        lineStyle: lineStyleOf(l.style), axisLabelVisible: true, title: narrow ? '' : (l.title || '')}));
    });
    (a.segments || []).forEach(function (s) {
      var pts = [];
      (s.points || []).forEach(function (p) {
        var t = self._snap(p && p[0]);
        if (!t || !isNum(p[1])) return;
        if (pts.length && pts[pts.length - 1].time === t) pts[pts.length - 1].value = p[1];
        else if (!pts.length || pts[pts.length - 1].time < t) pts.push({time: t, value: p[1]});
      });
      if (pts.length < 2) return;
      var ser = self.main.addLineSeries({color: mapAnnColor(s.color) || '#2563eb', lineWidth: 2, priceLineVisible: false, lastValueVisible: false,
        crosshairMarkerVisible: false, autoscaleInfoProvider: function () { return null; }});
      ser.setData(pts);
      self._segs.push(ser);
    });
    var mk = [];
    (a.markers || []).forEach(function (m) {
      var t = self._snap(m.date);
      if (!t) return;
      mk.push({time: t, position: m.position || 'aboveBar', shape: m.shape || 'circle', color: mapAnnColor(m.color) || '#64748b', text: m.text || ''});
    });
    mk.sort(function (x, y) { return x.time < y.time ? -1 : (x.time > y.time ? 1 : 0); });
    this.candle.setMarkers(mk);
  };
  KChart.prototype.annCount = function () {
    return {lines: this._plines.length, segments: this._segs.length};
  };

  KChart.prototype.destroy = function () {
    if (this._offCm) { this._offCm(); this._offCm = null; }
    if (this._ro) this._ro.disconnect();
    if (this._raf) cancelAnimationFrame(this._raf);
    (this.charts || []).forEach(function (c) { try { c.remove(); } catch (e) { /* ignore */ } });
    this.charts = null;
    this.root.innerHTML = '';
  };

  KChart.MA_DEF = MA_DEF;
  window.KChart = KChart;
})();
