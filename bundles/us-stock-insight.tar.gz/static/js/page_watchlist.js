/* 自選股 (#/watchlist) — localStorage['us.watchlist.v1'] 清單，結合 /api/universe 即時欄位；一鍵匯入預設組合。 */
(function () {
  'use strict';
  var W = {el: null, alive: false, U: null, sort: 'order', dir: 'asc'};
  var PRESETS = [
    ['mag7', '🌟 美股七巨頭 Mag7', ['AAPL', 'MSFT', 'NVDA', 'GOOGL', 'AMZN', 'META', 'TSLA']],
    ['sox', '🔬 費半核心', ['NVDA', 'AVGO', 'AMD', 'TSM', 'ASML', 'QCOM', 'MU', 'AMAT', 'LRCX', 'KLAC', 'MRVL', 'INTC']],
    ['adr', '🇹🇼 台股 ADR', ['TSM', 'UMC', 'ASX', 'CHT']]
  ];
  var COLS = [['code', '代號', 1], ['name', '名稱', 1], ['industry', '板塊', 1], ['close', '收盤'], ['chg', '漲跌'], ['pct', '漲跌%'],
    ['vol', '成交量'], ['mcap', '市值'], ['r20', '20日%'], ['pe', '本益比'], ['fwd_pe', '預估PE'], ['target_upside', '目標價空間'],
    ['score', '分數'], ['signals', '訊號', 1, 1], ['risk', '風險', 1, 1]];

  function render(params, el) {
    W.el = el;
    W.alive = true;
    setTitle('自選股');
    el.innerHTML = head(watchList().length) + skeleton(1, 240);
    el.addEventListener('click', onClick);
    el.addEventListener('keydown', onKey);
    document.addEventListener('us:watch', onWatch);
    return getUniverse().then(function (U) {
      if (!W.alive) return;
      W.U = U;
      paint();
    });
  }
  function head(n) {
    return '<div class="ph"><h1>⭐ 自選股</h1><span class="sub">' + (n ? n + ' 檔・' : '') + '清單只存在這台裝置的瀏覽器中</span><span class="sp"></span>' +
      '<div class="row wrap" style="min-width:0"><input class="input" id="wlAdd" placeholder="代號或名稱（如 NVDA、輝達）" autocomplete="off" style="width:220px;max-width:100%">' +
      '<button type="button" class="btn sm primary" data-act="add">＋ 加入</button></div></div>' +
      '<div class="card" style="margin-bottom:14px;padding:10px 14px"><div class="row wrap"><b class="small">⚡ 一鍵匯入預設組合：</b>' +
      PRESETS.map(function (p) {
        return '<button type="button" class="btn sm" data-preset="' + p[0] + '" data-tip="' + esc(p[2].join('、')) + '">' + esc(p[1]) + '</button>';
      }).join('') + (n ? '<span class="sp"></span><button type="button" class="btn xs ghost" data-act="clear">🗑️ 清空清單</button>' : '') + '</div></div>';
  }
  function rowsData() {
    var list = watchList(), U = W.U;
    var rows = list.map(function (code, i) {
      var r = U && U.by[code];
      return r ? Object.assign({_order: i}, r) : {code: code, name: '（查無資料）', _order: i, _missing: true, signals: [], risk: [], index_tags: []};
    });
    if (W.sort !== 'order') {
      var k = W.sort, dir = W.dir === 'asc' ? 1 : -1;
      rows.sort(function (a, b) {
        var x = a[k], y = b[k];
        var xn = x === null || x === undefined, yn = y === null || y === undefined;
        if (xn || yn) return xn === yn ? 0 : (xn ? 1 : -1);
        return typeof x === 'string' ? x.localeCompare(y, 'zh-Hant') * dir : (x - y) * dir;
      });
    }
    return rows;
  }
  function paint() {
    var rows = rowsData();
    var body;
    if (!rows.length) {
      body = '<div class="card empty"><div class="big">☆</div><h3>還沒有自選股</h3><p>在 <b>今日推薦</b>、<b>選股器</b> 或 <b>個股分析</b> 頁面點「☆」即可加入；也可以用上方輸入框或一鍵匯入預設組合。</p>' +
        '<div class="row wrap" style="justify-content:center;margin-top:12px"><a class="btn sm primary" href="#/">看今日推薦</a><a class="btn sm" href="#/screener">打開選股器</a></div></div>';
    } else {
      var up = rows.filter(function (r) { return r.pct > 0; }).length, down = rows.filter(function (r) { return r.pct < 0; }).length;
      body = '<div class="card flush"><div class="res-h"><span class="count">共 <b>' + rows.length + '</b> 檔</span><span class="small"><span class="up">上漲 ' + up +
        '</span> · <span class="down">下跌 ' + down + '</span></span><span class="sp"></span>' + (W.sort !== 'order' ? '<button type="button" class="btn xs ghost" data-act="order">↺ 依加入順序</button>' : '') +
        '</div><div class="tbl-wrap"><table class="tbl"><thead><tr><th class="c"></th>' + COLS.map(function (c) {
          var on = W.sort === c[0];
          return '<th class="' + (c[2] ? 'l ' : '') + (c[3] ? '' : 'sortable ') + (on ? 'sorted ' + (W.dir === 'asc' ? 'asc' : '') : '') + '"' + (c[3] ? '' : ' data-wsort="' + c[0] + '"') + '>' + c[1] + '</th>';
        }).join('') + '<th class="c">移除</th></tr></thead><tbody>' + rows.map(function (r) {
          return '<tr data-href="#/stock/' + encodeURIComponent(r.code) + '"><td class="c">' + starBtn(r.code, 'icon') + '</td><td class="l code">' + esc(r.code) +
            '</td><td class="l nm">' + esc(r.name || '') + ' ' + idxTags((r.index_tags || []).filter(function (t) { return t === 'MAG7' || t === 'ADR' || t === 'SOX'; })) +
            '</td><td class="l muted">' + esc(r.type === 'ETF' ? 'ETF' : (r.industry || '—')) + '</td><td>' + fmtUsd(r.close) + '</td><td class="' + clsUpDown(r.chg) + '">' + App.fmtUsdChg(r.chg) +
            '</td><td class="' + clsUpDown(r.pct) + '"><b>' + fmtPct(r.pct) + '</b></td><td>' + fmtShares(r.vol) + '</td><td>' + fmtUsdYi(r.mcap) + '</td><td class="' + clsUpDown(r.r20) + '">' + fmtPct(r.r20, 1) +
            '</td><td>' + fmtNum(r.pe, 1) + '</td><td>' + fmtNum(r.fwd_pe, 1) + '</td><td class="' + clsUpDown(r.target_upside) + '">' + fmtPct(r.target_upside, 1) +
            '</td><td><b style="color:' + App.scoreColor(r.score) + '">' + App.fmtScore(r.score) + '</b></td>' +
            '<td class="l"><div class="sigs">' + (r.signals || []).slice(0, 3).map(sigChip).join('') + '</div></td><td class="l"><div class="sigs">' + (r.risk || []).map(riskChip).join('') + '</div></td>' +
            '<td class="c"><button type="button" class="btn xs ghost" data-rm="' + esc(r.code) + '" aria-label="移除 ' + esc(r.code) + '">✕</button></td></tr>';
        }).join('') + '</tbody></table></div></div>';
    }
    var input = document.getElementById('wlAdd'), val = input ? input.value : '', focused = input && document.activeElement === input;
    W.el.innerHTML = head(rows.length) + body + disclaimerHtml();
    var again = document.getElementById('wlAdd');
    if (again) { again.value = val; if (focused) again.focus({preventScroll: true}); }
  }
  function addFromInput() {
    var input = document.getElementById('wlAdd');
    if (!input) return;
    var q = input.value.trim();
    if (!q) return;
    var hit = App.searchUniverse(q, 1)[0];
    if (!hit && App.isCode(q)) hit = {code: q.toUpperCase(), name: q.toUpperCase()};
    if (!hit) { toast('找不到「' + q + '」', 'warn'); return; }
    input.value = '';
    if (watchHas(hit.code)) { toast((hit.name || hit.code) + ' 已在自選股中'); return; }
    watchToggle(hit.code);
  }
  function importPreset(id) {
    var p = PRESETS.filter(function (x) { return x[0] === id; })[0];
    if (!p) return;
    var added = 0;
    p[2].slice().reverse().forEach(function (code) {
      if (W.U && W.U.list.length && !W.U.by[code]) return;
      if (!watchHas(code)) { watchToggle(code, true); added++; }
    });
    toast(added ? '已匯入「' + p[1] + '」' + added + ' 檔' : '「' + p[1] + '」都已在自選股中', added ? 'ok' : '');
    paint();
  }
  function onKey(ev) {
    if (ev.target.id === 'wlAdd' && App.isEnterSend(ev)) { ev.preventDefault(); addFromInput(); }
  }
  function onClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-rm]'))) { watchToggle(x.getAttribute('data-rm')); return; }
    if ((x = t.closest('[data-preset]'))) { importPreset(x.getAttribute('data-preset')); return; }
    if ((x = t.closest('[data-wsort]'))) {
      var k = x.getAttribute('data-wsort');
      if (W.sort === k) W.dir = W.dir === 'asc' ? 'desc' : 'asc';
      else { W.sort = k; W.dir = (k === 'code' || k === 'name' || k === 'industry') ? 'asc' : 'desc'; }
      paint();
      return;
    }
    if ((x = t.closest('[data-act]'))) {
      var act = x.getAttribute('data-act');
      if (act === 'add') addFromInput();
      else if (act === 'order') { W.sort = 'order'; paint(); }
      else if (act === 'clear') {
        if (!window.confirm('確定要清空全部自選股？')) return;
        watchList().slice().forEach(function (c) { watchToggle(c, true); });
        toast('已清空自選股');
        paint();
      }
    }
  }
  function onWatch() { if (W.alive && W.U) paint(); }

  window.Pages.watchlist = {
    render: render,
    refresh: function () { if (!W.alive) return false; getUniverse().then(function (U) { if (W.alive) { W.U = U; paint(); } }); return true; },
    destroy: function () {
      W.alive = false;
      document.removeEventListener('us:watch', onWatch);
      if (W.el) { W.el.removeEventListener('click', onClick); W.el.removeEventListener('keydown', onKey); }
    }
  };
})();
