/* 今日推薦 (#/) — 四大指數、總經條、美股七巨頭、盤前盤後＆ADR 快報、今日推薦 Top 20、GICS 熱力圖、熱門榜、新聞。 */
(function () {
  'use strict';
  var S = {el: null, alive: false, unsub: null, hotTab: 'gainers', showAll: false, market: null, picks: null, morning: null, mode: ''};
  var STANCE_CLS = {'強勢多頭': 'solid-bull', '偏多': 'bull', '中性': '', '偏空': 'bear', '弱勢空頭': 'solid-bear'};
  var PICKS_FIRST = 8;
  var SUB = '五大因子：財報成長 × 機構共識 × 技術動能 × 估值品質 × 低波穩定';

  function headHtml() {
    return '<div class="ph"><h1>🏆 今日推薦</h1><span class="sub">' + SUB + '</span></div>' +
      '<div class="campus-acad-bar"><b>🏛️ 財經學院 · 四大分析維度對照教學：</b>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/ta" href="https://okayell.github.io/finance/#/track/ta">📈 技術分析</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/fa" href="https://okayell.github.io/finance/#/track/fa">📊 基本面</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/chip" href="https://okayell.github.io/finance/#/track/chip">🧮 籌碼面</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/news" href="https://okayell.github.io/finance/#/track/news">📰 消息面</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/glossary" href="https://okayell.github.io/finance/#/glossary">📖 術語百科</a></div>';
  }

  function render(params, el) {
    S.el = el;
    S.alive = true;
    S.showAll = false;
    setTitle('今日推薦');
    el.innerHTML = headHtml() +
      '<div class="mstrip">' + [1, 2, 3, 4, 5].map(function () { return '<div class="skel" style="height:92px"></div>'; }).join('') + '</div>' +
      '<div class="sec-title"><h2>🏆 今日推薦 Top 20</h2></div>' + skeleton(2, 260);
    el.addEventListener('click', onClick);
    S.unsub = onMeta(onMetaChange);
    return getMeta().then(function (m) {
      if (!S.alive) return;
      if (needsProgress(m)) { showProgress(m); return; }
      return load();
    });
  }

  function needsProgress(m) { return !m.data_date || metaState(m) === 'backfill'; }
  function onMetaChange(m) {
    if (!S.alive) return;
    if (needsProgress(m)) { showProgress(m); return; }
    if (S.mode === 'progress') load();
  }
  function showProgress(m) {
    S.mode = 'progress';
    var st = m.status || {}, pct = Math.round((st.progress || 0) * 100);
    setHtml(S.el, '<div class="card progress-card"><div style="font-size:40px">🛠️</div><h2>首次建立美股資料庫中… ' + pct + '%</h2>' +
      '<p class="muted">正在下載美股與 ETF 歷史行情、財報 EPS、華爾街評級與機構持股資料。完成後會自動顯示今日推薦，不需要重新整理。</p>' +
      '<div class="pbar"><span style="width:' + pct + '%"></span></div>' +
      '<div class="small muted">' + esc(st.step || '準備中') + (st.message ? '：' + esc(st.message) : '') + '</div>' +
      msgsHtml(st.errors) + '</div>');
  }
  function msgsHtml(errors) {
    if (!errors || !errors.length) return '';
    return '<details class="msgs"><summary>資料更新訊息（' + errors.length + '）</summary><ul>' +
      errors.slice(-20).map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></details>';
  }

  function load() {
    S.mode = 'data';
    var settle = function (p) { return p.then(function (d) { return {ok: true, d: d}; }, function (e) { return {ok: false, e: e}; }); };
    return Promise.all([settle(api('/api/market')), settle(api('/api/picks')), settle(api('/api/morning'))]).then(function (res) {
      if (!S.alive) return;
      S.market = res[0];
      S.picks = res[1];
      S.morning = res[2];
      paint();
    });
  }

  function paint() {
    var m = S.market, p = S.picks, pm = S.morning, meta = App.meta || {};
    var disc = '<div class="inline-disc-bar"><span>⚖️ <b>免責聲明：</b>本站量化評分與推薦清單純供個人研究參考，非投顧建議亦不保證獲利；' +
      '<b>美股無漲跌幅限制且涉及匯率風險，投資人應獨立判斷並自負一切投資盈虧</b>。</span>' +
      '<button type="button" class="inline-disc-link" data-open-disclaimer="1">查看完整免責條款 →</button></div>';
    var mOk = m && m.ok && !isEmptyPayload(m.d);
    var marketH = !m.ok ? errorHtml(m.e && m.e.message) : (mOk ? marketHtml(m.d) + macroHtml(m.d) + mag7Html(m.d) : '');
    var morningH = (pm && pm.ok && !isEmptyPayload(pm.d)) ? morningStripHtml(pm.d, mOk ? m.d : null) : '';
    var picksH;
    if (!p.ok) picksH = errorHtml(p.e && p.e.message);
    else if (isEmptyPayload(p.d)) picksH = buildingHtml(p.d.message);
    else picksH = picksHtml(p.d);
    var lower = '';
    if (mOk) {
      lower = '<div class="grid g-main-side mt"><section class="card" id="hHeat">' + heatCard() + '</section>' +
        '<section class="card" id="hHot">' + hotCard(m.d) + '</section></div>' + newsCard(m.d.news || []);
    } else if (m.ok) {
      lower = buildingHtml(m.d && m.d.message);
    }
    var st = meta.status || {};
    S.el.innerHTML = headHtml() + disc + marketH + morningH + picksH + lower +
      disclaimerHtml('推薦清單由程式依公開資料自動計算，可能因資料延遲或錯誤而失準。') +
      (st.errors && st.errors.length ? '<div class="mt-s">' + msgsHtml(st.errors) + '</div>' : '');
    layoutHeat();
  }

  // ------------------------------------------------------------------ 四大指數 + 市場寬度
  function idxCard(label, x) {
    x = x || {};
    var ser = (x.series || []).map(function (r) { return r[1]; }).slice(-120);
    return '<div class="mk"><div class="mk-l">' + esc(label) + '</div><div class="mk-row"><div><div class="mk-v num">' + fmtNum(x.close, 2) +
      '</div><div class="mk-s ' + clsUpDown(x.chg) + '">' + arrow(x.chg) + ' ' + (App.isNum(x.chg) ? fmtNum(Math.abs(x.chg), 2) : '—') + '（' + fmtPct(x.pct) +
      '）</div></div>' + (ser.length > 1 ? svgSpark(ser, {w: 104, h: 40}) : '') + '</div></div>';
  }
  function marketHtml(m) {
    var ix = m.indices || {}, b = m.breadth || {};
    var n = (b.up || 0) + (b.down || 0) + (b.flat || 0) || 1;
    return '<div class="mstrip">' + idxCard('標普 500 (S&P 500)', ix.spx) + idxCard('那斯達克 (Nasdaq)', ix.ixic) +
      idxCard('道瓊工業 (Dow 30)', ix.dji) + idxCard('費城半導體 (SOX)', ix.sox) +
      '<div class="mk"><div class="mk-l">追蹤股漲跌家數</div><div class="mk-v num"><span class="up">' + fmtInt(b.up) +
      '</span> <span class="muted" style="font-size:14px">/</span> <span class="down">' + fmtInt(b.down) + '</span></div>' +
      '<div class="breadth-bar" data-tip="上漲 ' + fmtInt(b.up) + '、平盤 ' + fmtInt(b.flat) + '、下跌 ' + fmtInt(b.down) + '">' +
      '<span style="width:' + ((b.up || 0) / n * 100).toFixed(1) + '%;background:var(--up)"></span><span style="width:' + ((b.flat || 0) / n * 100).toFixed(1) +
      '%;background:#cbd5e1"></span><span style="width:' + ((b.down || 0) / n * 100).toFixed(1) + '%;background:var(--down)"></span></div>' +
      '<div class="mk-s muted">52 週新高 <span class="up">' + fmtInt(b.new_hi52) + '</span> · 新低 <span class="down">' + fmtInt(b.new_lo52) +
      '</span> · 站上月線 ' + fmtInt(b.above_ma20) + '／' + fmtInt(b.total) + '</div>' +
      '<div class="mk-s muted">總成交額 ' + fmtUsdYi(m.turnover_total) + '</div></div></div>';
  }
  function macroHtml(m) {
    var mc = m.macro || {};
    var it = function (key, label, isFx) {
      var x = mc[key];
      if (!x) return '';
      return '<span class="it" data-tip="' + esc(x.name || label) + '"><span class="muted">' + esc(label) + '</span><b>' +
        (isFx ? fmtNum(x.close, 2) : fmtUsd(x.close)) + '</b><span class="num ' + clsUpDown(x.pct) + '">' + arrow(x.pct) + ' ' + fmtPct(x.pct) + '</span></span>';
    };
    var html = it('vix', '😨 VIX 恐慌') + it('tlt', '🏦 20年美債 TLT') + it('gld', '🥇 黃金 GLD') + it('uso', '🛢️ 原油 USO') + it('usdtwd', '💱 美元／台幣', true);
    return html ? '<div class="card ux-macro mt-s" role="group" aria-label="總經指標">' + html + '</div>' : '';
  }
  function mag7Html(m) {
    var list = m.mag7 || [];
    if (!list.length) return '';
    return '<section class="card mt"><div class="card-h"><h2>🌟 Magnificent 7 美股七巨頭即時戰況</h2>' +
      '<span class="sub">合計市值 ' + fmtUsdYi(list.reduce(function (s, x) { return s + (App.isNum(x.mcap) ? x.mcap : 0); }, 0)) + '</span></div>' +
      '<div class="ux-mag">' + list.map(function (x) {
        return '<div class="m" data-href="#/stock/' + encodeURIComponent(x.code) + '" data-tip="' + esc((x.name || x.code) + '\n市值 ' + fmtUsdYi(x.mcap) +
          '\n20 日漲跌 ' + fmtPct(x.r20) + '\n本益比 ' + fmtNum(x.pe, 1) + '\n綜合分數 ' + (App.isNum(x.score) ? Math.round(x.score) : '—')) + '">' +
          '<div class="row"><span class="c">' + esc(x.code) + '</span><span class="sp"></span>' + starBtn(x.code, 'icon') + '</div>' +
          '<div class="n">' + esc(x.name || '') + '</div>' +
          '<div class="p num">' + fmtUsd(x.close) + '</div>' +
          '<div class="small num ' + clsUpDown(x.pct) + '"><b>' + arrow(x.pct) + ' ' + fmtPct(x.pct) + '</b> <span class="muted">· 20日 </span><span class="' +
          clsUpDown(x.r20) + '">' + fmtPct(x.r20) + '</span></div>' +
          '<div class="small muted">' + fmtUsdYi(x.mcap) + '</div></div>';
      }).join('') + '</div></section>';
  }

  // ------------------------------------------------------------------ 盤前盤後 + ADR 快報
  function morningStripHtml(d, mk) {
    var dec = d.decision || {}, ses = d.us_session || (App.meta || {}).us_session || {};
    var movers = (d.extended_movers || []).slice().sort(function (a, b) { return Math.abs(b.ext_pct || 0) - Math.abs(a.ext_pct || 0); }).slice(0, 6);
    var adrs = (d.adr_bridge && d.adr_bridge.length) ? d.adr_bridge : ((mk && mk.adrs) || []);
    var evs = (d.events || []).slice(0, 3);
    var moverH = movers.length ? '<div class="hm-us-row">' + movers.map(function (x) {
      return '<a class="hm-us-pill" href="#/stock/' + encodeURIComponent(x.code) + '" data-tip="' + esc((x.name || '') + '\n正規盤 ' + fmtPct(x.reg_pct) +
        '\n' + (x.ext_type || '盤後') + ' ' + fmtUsd(x.ext_price) + '（' + fmtPct(x.ext_pct) + '）') + '"><b>' + esc(x.code) + '</b> <small class="muted">' +
        esc(x.ext_type || '盤後') + '</small> <span class="num ' + clsUpDown(x.ext_pct) + '">' + arrow(x.ext_pct) + ' ' + fmtPct(x.ext_pct) + '</span></a>';
    }).join('') + '</div>' : '';
    var adrH = adrs.length ? '<div class="hm-us-row mt-s">' + adrs.slice(0, 4).map(function (a) {
      var px = App.isNum(a.adr_close) ? a.adr_close : a.close, pc = App.isNum(a.adr_pct) ? a.adr_pct : a.pct;
      return '<span class="hm-us-pill" data-tip="' + esc((a.note || ('1 單位 ' + a.code + ' ADR = ' + (a.ratio || '—') + ' 股 ' + (a.tw_code || ''))) +
        '\n美元／台幣 ' + fmtNum(a.usdtwd, 2)) + '"><b>🇹🇼 ' + esc(a.code) + '↔' + esc(a.tw_code || '') + '</b> ' + fmtUsd(px) +
        ' <span class="num ' + clsUpDown(pc) + '">' + fmtPct(pc) + '</span> <small class="muted">折合 NT$ ' + fmtNum(a.implied_twd, 1) + '</small></span>';
    }).join('') + '</div>' : '';
    return '<section class="card hm-pm-card mt"><div class="card-h"><h2>🌅 盤前盤後與台股 ADR 快報</h2>' +
      (dec.regime ? '<span class="chip ' + esc(dec.regime_cls || '') + '">' + esc(dec.regime) + '</span>' : '') +
      (dec.allocation ? '<span class="chip info">' + esc(dec.allocation) + '</span>' : '') +
      (ses.season ? '<span class="chip ghost">' + (ses.is_dst ? '🌞 ' : '❄️ ') + esc(ses.season) + (ses.state_zh ? ' · ' + esc(ses.state_zh) : '') + '</span>' : '') +
      '<span class="sp"></span><a class="btn sm primary" href="#/morning">盤前盤後戰情 →</a></div>' +
      moverH + adrH +
      (dec.summary_advice ? '<div class="small muted mt-s">' + esc(dec.summary_advice) + '</div>' : '') +
      (evs.length ? '<div class="hm-ev-grid mt-s">' + evs.map(function (ev) {
        var polCls = ev.polarity === 'bull' ? 'bull' : (ev.polarity === 'bear' ? 'bear' : 'info');
        var secs = (ev.affected_sectors || []).slice(0, 2).map(function (s) { return s.name; }).join('、');
        return '<a class="hm-ev" href="#/morning?ev=' + encodeURIComponent(ev.id || '') + '"><div class="row wrap"><span class="chip ' + polCls + '">' +
          esc(ev.polarity_zh || '事件') + '</span><span class="chip ghost">' + esc(ev.category_label || '') + '</span></div>' +
          '<div class="hm-ev-ttl">' + esc(ev.title || '') + '</div>' +
          '<div class="small muted">牽動族群：<b>' + esc(secs || '相關供應鏈') + '</b> · 點擊查看受影響個股 →</div></a>';
      }).join('') + '</div>' : '') + '</section>';
  }

  // ------------------------------------------------------------------ picks
  function picksHtml(d) {
    var picks = d.picks || [];
    var head = '<div class="sec-title"><h2>🏆 今日推薦 Top 20</h2><span class="sub">' + picks.length + ' 檔 · 資料日 ' + esc(d.date || '—') +
      ' · 綜合分數由高到低</span><span class="sp"></span><a class="btn sm" href="#/picks">📊 績效追蹤</a>' +
      '<a class="btn sm" href="#/screener">🧮 選股器</a></div>';
    if (!picks.length) {
      return head + '<div class="card empty"><div class="big">🔍</div><h3>今天沒有符合條件的推薦股</h3><p>模型要求財報、機構共識與技術面同時達標，市場偏弱時清單可能為空。</p></div>';
    }
    var shown = S.showAll ? picks : picks.slice(0, PICKS_FIRST);
    var more = picks.length > PICKS_FIRST ? '<div class="row mt-s" style="justify-content:center"><button type="button" class="btn" data-act="more-picks">' +
      (S.showAll ? '收合，只看前 ' + PICKS_FIRST + ' 檔' : '顯示全部 ' + picks.length + ' 檔') + '</button></div>' : '';
    return head + '<div class="picks-grid">' + shown.map(function (x) { return pickCard(x, d.method); }).join('') + '</div>' + more;
  }
  function lvl(label, v, cls, tip) {
    return '<div' + (tip ? ' data-tip="' + esc(tip) + '"' : '') + '><div class="lb">' + label + '</div><div class="v ' + (cls || '') + '">' +
      (App.isNum(v) ? fmtUsd(v) : '—') + '</div></div>';
  }
  function pickCard(p, method) {
    var L = p.levels || {}, t = p.tech || {}, code = esc(p.code), href = '#/stock/' + encodeURIComponent(p.code);
    var sig = (p.signals || []).slice(0, 6);
    return '<article class="pick">' +
      '<div class="pick-hd"><div class="pick-rank' + (p.rank <= 3 ? ' top' : '') + '" data-tip="綜合排名">' + esc(p.rank || '') + '</div>' +
      '<div class="pick-id"><a class="pick-name" href="' + href + '">' + esc(p.name || p.code) + ' <span class="code">' + code + '</span></a>' +
      '<div class="pick-meta"><span class="chip">' + esc(p.market || '') + '</span>' + (p.industry ? '<span class="chip">' + esc(p.industry) + '</span>' : '') +
      (p.sub_industry ? '<span class="chip ghost">' + esc(p.sub_industry) + '</span>' : '') + ' ' + idxTags(p.index_tags) + '</div></div>' +
      scoreRing(p.score, 52) + '</div>' +
      '<div class="pick-px"><span class="px ' + clsUpDown(p.pct) + '">' + fmtUsd(p.close) + '</span><span class="chg ' + clsUpDown(p.pct) + '">' +
      arrow(p.pct) + ' ' + fmtPct(p.pct) + '</span>' + svgSpark(p.spark, {w: 150, h: 38}) + '</div>' +
      '<div class="pick-body">' + factorBars(p.factors, method && method.weights) + '<ul class="reasons">' +
      (p.reasons || []).slice(0, 4).map(function (r) { return '<li>' + esc(r) + '</li>'; }).join('') + '</ul></div>' +
      '<div class="levels">' + lvl('支撐', L.support, 'sup', '下方支撐價位') + lvl('壓力', L.resistance, 'res', '上方壓力價位') +
      lvl('停損', L.stop, 'down', '跌破此價位代表技術面轉弱（僅供研究參考）') + lvl('目標', L.target, 'up', '技術面推估目標價') +
      '<div data-tip="報酬風險比 = (目標 − 現價) ÷ (現價 − 停損)"><div class="lb">報酬風險比</div><div class="v">' + (App.isNum(L.rr) ? fmtNum(L.rr, 2) : '—') + '</div></div></div>' +
      (t.stance || t.summary ? '<div class="pick-tech"><span class="chip ' + (STANCE_CLS[t.stance] || '') + '">' + esc(t.stance || '技術面') +
        (App.isNum(t.score) ? ' ' + Math.round(t.score) : '') + '</span><span>' + esc(t.summary || '') + '</span></div>' : '') +
      '<div class="pick-ft">' + (sig.length || (p.risks || []).length ? '<div class="chips">' +
        (p.risks || []).map(function (r) { return '<span class="chip warn">⚠ ' + esc(r) + '</span>'; }).join('') + sig.map(sigChip).join('') + '</div>' : '<span class="sp"></span>') +
      '<a class="btn sm primary" href="' + href + '">個股分析 →</a>' + starBtn(p.code) + '</div></article>';
  }

  // ------------------------------------------------------------------ GICS heat map
  function heatCard() {
    return '<div class="card-h"><h2>🌡️ GICS 11 大板塊熱力圖</h2><span class="sub">面積 = 成交額、顏色 = 今日漲跌</span><span class="sp"></span>' +
      '<a class="btn xs ghost" href="#/industry">板塊與供應鏈 →</a></div><div class="heat" id="heatBox"></div>' +
      '<div class="heat-legend"><span>−4%</span><span class="scale">' + [-4, -3, -2, -1, 0, 1, 2, 3, 4].map(function (v) {
        return '<span style="background:' + heatColor(v).bg + '"></span>';
      }).join('') + '</span><span>+4%</span><span class="sp"></span><span>點擊板塊 → 選股器篩選</span></div>';
  }
  function layoutHeat() {
    var box = document.getElementById('heatBox');
    if (!box || !S.market || !S.market.ok || !S.market.d) return;
    var secs = (S.market.d.sectors || []).filter(function (s) { return (s.value || 0) > 0; })
      .sort(function (a, b) { return b.value - a.value; });
    var W = box.clientWidth || 800, H = box.clientHeight || 340;
    var rects = treemap(secs, W, H);
    box.innerHTML = secs.map(function (s, i) {
      var r = rects[i];
      if (!r) return '';
      var c = heatColor(s.pct_1d), small = r.w < 86 || r.h < 44, tiny = r.w < 46 || r.h < 26;
      var tip = s.name + (s.en ? '（' + s.en + '）' : '') + '\n漲跌 ' + fmtPct(s.pct_1d) + '（5日 ' + fmtPct(s.pct_5d) + '、20日 ' + fmtPct(s.pct_20d) + '）\n成交額 ' +
        fmtUsdYi(s.value) + '（占 ' + fmtNum(s.value_share, 1) + '%）\n上漲 ' + fmtInt(s.up) + ' · 下跌 ' + fmtInt(s.down) + ' · 共 ' + fmtInt(s.count) + ' 檔' +
        ((s.leaders || []).length ? '\n領漲：' + s.leaders.slice(0, 3).map(function (x) { return (x.name || x.code) + ' ' + fmtPct(x.pct); }).join('、') : '');
      return '<div class="tile' + (small ? ' sm' : '') + '" data-href="#/screener?ind=' + encodeURIComponent(s.name) + '" data-tip="' + esc(tip) +
        '" style="left:' + (r.x / W * 100).toFixed(3) + '%;top:' + (r.y / H * 100).toFixed(3) + '%;width:' + (r.w / W * 100).toFixed(3) +
        '%;height:' + (r.h / H * 100).toFixed(3) + '%;background:' + c.bg + ';color:' + c.fg + '">' +
        (tiny ? '' : '<b>' + esc(s.name) + '</b><span>' + fmtPct(s.pct_1d) + '</span>') + '</div>';
    }).join('');
  }

  // ------------------------------------------------------------------ hot lists + news
  var HOT_TABS = [['gainers', '漲幅榜'], ['losers', '跌幅榜'], ['value', '成交額榜']];
  function hotCard(m) {
    var list = (m.hot || {})[S.hotTab] || [];
    return '<div class="card-h"><h2>🔥 熱門榜</h2><span class="sp"></span><div class="seg" role="tablist">' + HOT_TABS.map(function (t) {
      return '<button type="button" class="' + (t[0] === S.hotTab ? 'on' : '') + '" data-hot="' + t[0] + '">' + t[1] + '</button>';
    }).join('') + '</div></div><div class="hot-list">' + (list.length ? list.slice(0, 10).map(function (r, i) {
      return '<div class="hot-row" data-href="#/stock/' + encodeURIComponent(r.code) + '" data-tip="' + esc((r.name || r.code) + ' · 成交額 ' + fmtUsdYi(r.value)) +
        '"><span class="i">' + (i + 1) + '</span><span class="n">' + esc(r.name || r.code) + '<small>' + esc(r.code) + '</small></span>' +
        '<span class="c">' + (S.hotTab === 'value' ? fmtUsdYi(r.value) : fmtUsd(r.close)) + '</span><span class="p ' + clsUpDown(r.pct) + '">' + fmtPct(r.pct) + '</span></div>';
    }).join('') : '<div class="empty">暫無資料</div>') + '</div>';
  }
  function newsCard(news) {
    if (!news.length) return '';
    return '<section class="card mt"><div class="card-h"><h2>📰 美股新聞</h2><span class="sub">外部連結，於新分頁開啟</span></div><div class="news-list">' +
      news.slice(0, 16).map(function (n) {
        return '<div class="news-item"><a href="' + esc(n.link) + '" target="_blank" rel="noopener noreferrer">' + esc(n.title) + '</a>' +
          '<span class="meta"><span>' + esc(n.source || '') + '</span><span>' + esc(relTime(n.time)) + '</span></span></div>';
      }).join('') + '</div></section>';
  }

  function onClick(ev) {
    var t = ev.target;
    var hot = t.closest('[data-hot]');
    if (hot) {
      S.hotTab = hot.getAttribute('data-hot');
      var box = document.getElementById('hHot');
      if (box && S.market && S.market.ok) setHtml(box, hotCard(S.market.d));
      return;
    }
    if (t.closest('[data-act="more-picks"]')) {
      S.showAll = !S.showAll;
      paint();
    }
  }

  var onResize = App.debounce(function () { if (S.alive && S.mode === 'data') layoutHeat(); }, 150);
  window.addEventListener('resize', onResize);

  window.Pages.home = {
    render: render,
    destroy: function () {
      S.alive = false;
      if (S.unsub) S.unsub();
      S.unsub = null;
      if (S.el) S.el.removeEventListener('click', onClick);
      S.mode = '';
    }
  };
})();
