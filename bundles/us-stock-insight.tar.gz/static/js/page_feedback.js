/* 💬 意見回饋 (#/feedback) — 功能許願、問題回報與選股建議。
 * 本機版 POST api/feedback（伺服器端轉寄站長）；GitHub 靜態版一鍵走 CampusNav.sendStaticFeedback 直達（CAMP-95）。
 * 介面只稱「站長」，不顯示任何信箱（CAMP-96）。 */
(function () {
  'use strict';
  var TOOL = '美股戰情室';
  var LS_KEY = 'us.feedback.v1';
  var KINDS = [
    ['feature', '✨ 功能許願'],
    ['bug', '🐞 問題回報 (Bug)'],
    ['ux', '🎨 介面與選股建議'],
    ['other', '💬 其他意見']
  ];
  var FB = {el: null, alive: false, items: null, kind: 'feature', sending: false};
  var OK_BOX = 'background:var(--up-soft,#f0fdf4);border:1px solid #86efac;color:#166534;padding:10px 12px;border-radius:8px;font-size:13px';

  function loadLocal() {
    try { var a = JSON.parse(localStorage.getItem(LS_KEY) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; }
  }
  function saveLocal(items) {
    try { localStorage.setItem(LS_KEY, JSON.stringify((items || []).slice(0, 50))); } catch (e) { /* ignore */ }
  }
  function isStaticEnv() {
    return Boolean(App.isStatic || window.__STATIC_API__ || location.protocol === 'file:' ||
      /\.github\.io$|\.pages\.dev$|\.netlify\.app$|\.vercel\.app$/i.test(location.hostname || ''));
  }
  function fallbackBox(kindLabel, title, desc) {
    if (window.CampusNav && CampusNav.fallbackHtml) {
      return CampusNav.fallbackHtml({tool: TOOL, kindLabel: kindLabel, title: title, description: desc});
    }
    return '<div style="background:#fffbeb;border:1px solid #fcd34d;color:#92400e;padding:10px 12px;border-radius:8px;font-size:13px">' +
      '✅ 已收到你的回饋！已暫存在這台裝置，網路恢復後會自動轉寄給站長。</div>';
  }
  function sendStatic(item) {
    if (window.CampusNav && CampusNav.sendStaticFeedback) {
      return CampusNav.sendStaticFeedback({tool: TOOL, kindLabel: item.kind_label, title: item.title,
        description: item.description, createdAt: item.created_at}).then(null, function () { return {sent: false}; });
    }
    return Promise.resolve({sent: false});
  }

  function paint(bannerHtml) {
    if (!FB.alive || !FB.el) return;
    var items = FB.items || [];
    FB.el.innerHTML =
      '<div class="card" style="margin-bottom:14px">' +
        '<h1 style="margin:0 0 6px;font-size:20px">💬 意見回饋・問題回報・功能許願</h1>' +
        '<p class="muted" style="margin:0;font-size:13.5px">想要新的美股篩選條件、ETF 試算功能、技術指標，或發現資料與介面問題，歡迎隨時留言！送出後會自動轉寄給站長。</p>' +
      '</div>' +
      '<div class="ux-grid" style="align-items:start">' +
        '<form class="card" id="usFbForm" style="display:flex;flex-direction:column;gap:14px">' +
          '<div><label style="font-weight:700;font-size:13.5px;display:block;margin-bottom:6px">1. 回饋類型</label>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap">' + KINDS.map(function (k) {
              var on = FB.kind === k[0];
              return '<button type="button" class="btn sm' + (on ? ' primary' : '') + '" data-us-fb-kind="' + k[0] + '" aria-pressed="' + on + '">' + k[1] + '</button>';
            }).join('') + '</div></div>' +
          '<div><label for="usFbTitle" style="font-weight:700;font-size:13.5px;display:block;margin-bottom:6px">2. 標題</label>' +
            '<input class="input" id="usFbTitle" required maxlength="150" placeholder="簡短說明您的建議、許願功能或遇到的問題…" style="width:100%"></div>' +
          '<div><label for="usFbDesc" style="font-weight:700;font-size:13.5px;display:block;margin-bottom:6px">3. 內容描述</label>' +
            '<textarea class="input" id="usFbDesc" required rows="6" maxlength="4000" placeholder="請描述詳細情境、希望新增的美股／ETF 指標或篩選條件，或操作上遇到的異常狀況…" ' +
            'style="width:100%;min-height:130px;resize:vertical"></textarea></div>' +
          (bannerHtml || '') +
          '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">' +
            '<span class="muted" style="font-size:12px">📩 送出後會自動通知站長</span>' +
            '<button type="submit" class="btn primary" id="usFbSubmit">📨 送出回饋</button>' +
          '</div>' +
        '</form>' +
        '<div class="card"><h3 style="margin:0 0 10px;font-size:15.5px">🗂️ 已送出的回饋紀錄（' + items.length + '）</h3>' +
          '<div style="display:flex;flex-direction:column;gap:10px;max-height:520px;overflow-y:auto">' +
          (items.length ? items.map(function (it) {
            return '<div style="padding:10px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:9px;min-width:0">' +
              '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:4px;flex-wrap:wrap">' +
                '<span class="chip info">' + esc(it.kind_label || it.kind || '意見') + '</span>' +
                '<span class="muted" style="font-size:11.5px">' + esc(it.created_at || '') + '</span></div>' +
              '<div style="font-weight:700;font-size:13.5px;overflow-wrap:anywhere">' + esc(it.title || '') + '</div>' +
              '<div style="font-size:12.5px;color:#334155;margin-top:4px;white-space:pre-wrap;overflow-wrap:anywhere">' + esc(it.description || '') + '</div></div>';
          }).join('') : '<div class="muted" style="padding:24px 0;text-align:center">目前尚無回饋紀錄，歡迎留下第一則建議！</div>') +
          '</div></div>' +
      '</div>' + disclaimerHtml();
    bind();
  }

  function bind() {
    $$('[data-us-fb-kind]', FB.el).forEach(function (btn) {
      btn.onclick = function () {
        var curT = ($('#usFbTitle', FB.el) || {}).value || '';
        var curD = ($('#usFbDesc', FB.el) || {}).value || '';
        FB.kind = btn.getAttribute('data-us-fb-kind');
        paint();
        if ($('#usFbTitle', FB.el)) $('#usFbTitle', FB.el).value = curT;
        if ($('#usFbDesc', FB.el)) $('#usFbDesc', FB.el).value = curD;
      };
    });
    var tInp = $('#usFbTitle', FB.el);
    if (tInp) tInp.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' && (ev.isComposing || !App.isEnterSend(ev))) ev.preventDefault(); });
    var form = $('#usFbForm', FB.el);
    if (form) form.onsubmit = onSubmit;
  }

  function onSubmit(ev) {
    ev.preventDefault();
    if (FB.sending) return;
    var title = (($('#usFbTitle', FB.el) || {}).value || '').trim();
    var description = (($('#usFbDesc', FB.el) || {}).value || '').trim();
    if (!title || !description) { toast('請填寫標題與內容描述', 'warn'); return; }
    FB.sending = true;
    var btn = $('#usFbSubmit', FB.el);
    if (btn) { btn.disabled = true; btn.textContent = '⏳ 寄送中…'; }
    var kindLabel = (KINDS.filter(function (x) { return x[0] === FB.kind; })[0] || KINDS[0])[1];
    var item = {id: 'FB-' + Date.now().toString(36).toUpperCase(), kind: FB.kind, kind_label: kindLabel, title: title,
      description: description, created_at: new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 19).replace('T', ' ')};
    if (!isStaticEnv()) {
      api('/api/feedback', {method: 'POST', cache: false, body: JSON.stringify({kind: FB.kind, title: title, description: description})}).then(function (d) {
        FB.sending = false;
        if (!d || !d.ok) throw new Error((d && d.error) || '送出失敗');
        FB.items = d.items || [d.item || item].concat(FB.items || []);
        saveLocal(FB.items);
        if (!d.item || d.item.mail_sent !== false) {
          toast('✅ 感謝您的回饋！已轉寄給站長', 'ok');
          paint('<div style="' + OK_BOX + '">✅ 已成功收到並通知站長！感謝您的寶貴建議。</div>');
        } else {
          paint(fallbackBox(kindLabel, title, description));
        }
      }).catch(function () {
        FB.sending = false;
        FB.items = [item].concat(FB.items || []);
        saveLocal(FB.items);
        paint(fallbackBox(kindLabel, title, description));
      });
      return;
    }
    sendStatic(item).then(function (res) {
      FB.sending = false;
      FB.items = [item].concat(FB.items || []);
      saveLocal(FB.items);
      paint(res && res.sent ? '<div style="' + OK_BOX + '">✅ 感謝回饋！意見已成功轉寄給站長。</div>' : fallbackBox(kindLabel, title, description));
    });
  }

  function render(params, el) {
    FB.el = el;
    FB.alive = true;
    setTitle('意見回饋');
    if (FB.items === null) FB.items = loadLocal();
    paint();
    if (!isStaticEnv()) {
      api('/api/feedback', {cache: false}).then(function (d) {
        if (d && Array.isArray(d.items)) { FB.items = d.items; if (FB.alive) paint(); }
      }, function () { /* keep local list */ });
    }
  }

  window.Pages.feedback = {render: render, destroy: function () { FB.alive = false; FB.el = null; }};
})();
