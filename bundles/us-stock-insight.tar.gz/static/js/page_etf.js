/* 美股 ETF 專區 (#/etf) — 分類篩選、費用率／規模／配息頻率／殖利率、除息日曆，與定期定額＆股息再投入試算機 */
(function () {
  'use strict';
  var CAT_ORDER = ['大盤指數', '科技半導體', '高股息價值', '美債固定收益', '黃金原物料與主題'];
  var CAT_ICON = {'大盤指數': '🏛️', '科技半導體': '💻', '高股息價值': '💰', '美債固定收益': '🏦', '黃金原物料與主題': '🪙'};
  var COLS = [
    {k: 'star', t: '', s: false, c: true},
    {k: 'code', t: '代號', l: true},
    {k: 'name', t: 'ETF 名稱', l: true},
    {k: 'category', t: '分類', l: true},
    {k: 'close', t: '市價'},
    {k: 'pct', t: '漲跌%'},
    {k: 'r20', t: '20日%'},
    {k: 'r250', t: '近一年%'},
    {k: 'expense_ratio', t: '費用率'},
    {k: 'aum', t: '資產規模'},
    {k: 'freq', t: '配息', c: true},
    {k: 'yld_ttm', t: '近12月殖利率'},
    {k: 'last_cash', t: '最近配息'},
    {k: 'ex_date', t: '除息日', c: true},
    {k: 'calc', t: '試算', s: false, c: true}
  ];
  var CKEY = 'us.etf.calc.v1';
  var DEF_CALC = {pmt: 500, years: 20, ret: 7, yld: 1.5, drip: true, code: ''};
  var PAGE = 150;
  var S = {el: null, alive: false, data: null, rows: [], limit: PAGE, q: '', cat: '', freq: '', sort: 'aum', dir: 'desc',
    calTab: 'upcoming', calc: null};

  function loadCalc() {
    var c = {};
    try { c = JSON.parse(localStorage.getItem(CKEY) || '{}') || {}; } catch (e) { c = {}; }
    var o = {};
    Object.keys(DEF_CALC).forEach(function (k) { o[k] = c[k] !== undefined && c[k] !== null ? c[k] : DEF_CALC[k]; });
    ['pmt', 'years', 'ret', 'yld'].forEach(function (k) { if (!isNum(o[k])) o[k] = DEF_CALC[k]; });
    o.drip = o.drip !== false;
    return o;
  }
  function saveCalc() { try { localStorage.setItem(CKEY, JSON.stringify(S.calc)); } catch (e) { /* quota */ } }

  function applyQuery(q) {
    q = q || {};
    S.cat = q.cat || '';
    S.freq = q.freq || '';
    S.q = q.q || '';
    S.sort = q.sort || 'aum';
    S.dir = q.dir === 'asc' ? 'asc' : 'desc';
  }
  function syncUrl() {
    replaceHash('#/etf' + buildQuery({cat: S.cat, freq: S.freq, q: S.q.trim(), sort: S.sort !== 'aum' ? S.sort : '', dir: S.dir !== 'desc' ? S.dir : ''}));
  }
  function items() { return (S.data && S.data.items) || []; }
  function byCode(code) {
    var a = items();
    for (var i = 0; i < a.length; i++) if (a[i].code === code) return a[i];
    return null;
  }

  // ------------------------------------------------------------------ render
  var HEAD = '<div class="ph"><h1>🧺 美股 ETF 專區</h1>';
  function render(params, el) {
    S.el = el;
    S.alive = true;
    S.limit = PAGE;
    S.calc = loadCalc();
    applyQuery((params && params.query) || {});
    setTitle('美股 ETF 專區');
    el.innerHTML = HEAD + '<span class="sub">大盤指數、科技半導體、高股息、美債與黃金原物料 ETF，費用率、規模、殖利率與除息日曆一次看</span></div>' +
      skeleton(3, 110) + '<div class="mt">' + skeleton(1, 360) + '</div>';
    el.addEventListener('click', onClick);
    el.addEventListener('input', onInput);
    el.addEventListener('change', onChange);
    return load();
  }
  function load() {
    return api('/api/etfs').then(function (d) {
      if (!S.alive) return;
      S.data = d;
      if (isEmptyPayload(d) || !d || !(d.items || []).length) {
        S.el.innerHTML = HEAD + '</div>' + buildingHtml(d && d.message);
        return;
      }
      paint();
    });
  }

  function categories() {
    var sum = (S.data && S.data.summary) || {}, cnt = {}, names = [];
    (sum.categories || []).forEach(function (c) {
      if (c && c.name) { cnt[c.name] = isNum(c.count) ? c.count : 0; names.push(c.name); }
    });
    var counted = {};
    items().forEach(function (it) {
      var c = it.category || '其他';
      counted[c] = (counted[c] || 0) + 1;
      if (names.indexOf(c) < 0) names.push(c);
    });
    names.forEach(function (n) { if (!isNum(cnt[n]) || !cnt[n]) cnt[n] = counted[n] || 0; });
    names.sort(function (a, b) {
      var ia = CAT_ORDER.indexOf(a), ib = CAT_ORDER.indexOf(b);
      if (ia < 0) ia = 99;
      if (ib < 0) ib = 99;
      return ia - ib || (cnt[b] - cnt[a]);
    });
    return names.map(function (n) { return [n, cnt[n]]; });
  }
  function freqs() {
    var seen = {}, out = [];
    var order = ['月配', '季配', '半年配', '年配', '不配息'];
    items().forEach(function (it) { if (it.freq && !seen[it.freq]) { seen[it.freq] = 1; out.push(it.freq); } });
    return out.sort(function (a, b) {
      var ia = order.indexOf(a), ib = order.indexOf(b);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
  }

  function paint() {
    var d = S.data, sum = d.summary || {}, all = items();
    var aumTot = all.reduce(function (s, x) { return s + (isNum(x.aum) ? x.aum : 0); }, 0);
    var cheap = all.filter(function (x) { return isNum(x.expense_ratio); }).sort(function (a, b) { return a.expense_ratio - b.expense_ratio; })[0];
    var topY = all.filter(function (x) { return isNum(x.yld_ttm); }).sort(function (a, b) { return b.yld_ttm - a.yld_ttm; })[0];
    var avgY = isNum(sum.avg_yld) ? sum.avg_yld : null;
    S.el.innerHTML = HEAD + '<span class="sub">資料日期 ' + esc(d.date || '—') + ' · 收錄 ' + fmtInt(isNum(sum.count) ? sum.count : all.length) +
      ' 檔美股 ETF（價格為美元，規模單位為億美元；點擊列可看 K 線與技術分析）</span></div>' +
      '<div class="kpis">' +
        kpi('📊 收錄 ETF', fmtInt(isNum(sum.count) ? sum.count : all.length) + ' 檔', '合計資產規模 ' + fmtUsdYi(aumTot || null)) +
        kpi('💵 平均殖利率', isNum(avgY) ? fmtPct(avgY, 2, true) : '—', topY ? '最高：' + topY.code + ' ' + fmtPct(topY.yld_ttm, 2, true) : '近 12 個月現金配息／市價') +
        kpi('📅 近期除息', fmtInt(isNum(sum.upcoming_ex_count) ? sum.upcoming_ex_count : upcoming().length) + ' 檔', '已公告或預估之即將除息 ETF') +
        kpi('🪶 最低費用率', cheap ? fmtNum(cheap.expense_ratio, 2) + '%' : '—', cheap ? cheap.code + ' · ' + (cheap.name || '') : '內扣總費用率（年）') +
      '</div>' +
      '<section class="card mt etf-ctrl"><div class="etf-ctrl-grid">' + controlsInner() + '</div></section>' +
      '<section class="card flush mt" id="etfRes"><div class="res-h" id="etfResHead"></div><div class="tbl-wrap etf-tbl-wrap" id="etfTblBox"></div></section>' +
      '<div class="ux-grid mt">' +
        '<section class="card" id="etfCalBox">' + calendarInner() + '</section>' +
        '<section class="card" id="etfCalcBox">' + calcInner() + '</section>' +
      '</div>' +
      disclaimerHtml('ETF 過去配息與報酬不代表未來績效；美股 ETF 配息對台灣投資人通常預扣 30% 股息稅，試算結果未計稅負、匯率與交易成本，僅供參考。');
    filterAndPaint();
    paintCalcResult();
  }
  function kpi(label, val, sub) {
    return '<div class="kpi"><div class="kpi-l">' + label + '</div><div class="kpi-v num">' + esc(val) + '</div><div class="kpi-s">' + esc(sub) + '</div></div>';
  }

  // ------------------------------------------------------------------ controls
  function controlsInner() {
    var cats = categories(), fq = freqs(), total = items().length;
    return '<div class="row wrap"><span class="small muted" style="min-width:60px">ETF 分類</span><div class="chips" id="etfCatBar">' +
        '<button type="button" class="preset' + (!S.cat ? ' on' : '') + '" data-ecat="">全部 <span class="num" style="opacity:.7">(' + total + ')</span></button>' +
        cats.map(function (c) {
          return '<button type="button" class="preset' + (S.cat === c[0] ? ' on' : '') + '" data-ecat="' + esc(c[0]) + '">' + (CAT_ICON[c[0]] ? CAT_ICON[c[0]] + ' ' : '') +
            esc(c[0]) + ' <span class="num" style="opacity:.7">(' + fmtInt(c[1]) + ')</span></button>';
        }).join('') + '</div></div>' +
      (fq.length ? '<div class="row wrap"><span class="small muted" style="min-width:60px">配息頻率</span><div class="seg" id="etfFreqBar">' +
        [['', '全部']].concat(fq.map(function (f) { return [f, f]; })).map(function (f) {
          return '<button type="button" class="' + (S.freq === f[0] ? 'on' : '') + '" data-efreq="' + esc(f[0]) + '">' + esc(f[1]) + '</button>';
        }).join('') + '</div></div>' : '') +
      '<div class="row wrap"><input class="input" id="etfQ" type="search" placeholder="搜尋代號、名稱或發行商（如 SPY、Vanguard、債）" value="' + esc(S.q) +
        '" autocomplete="off" style="width:320px;max-width:100%"></div>';
  }
  function refreshControls() {
    $$('#etfCatBar [data-ecat]', S.el).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-ecat') === S.cat); });
    $$('#etfFreqBar [data-efreq]', S.el).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-efreq') === S.freq); });
    var q = document.getElementById('etfQ');
    if (q && q.value !== S.q) q.value = S.q;
  }

  // ------------------------------------------------------------------ table
  function filterAndPaint() {
    var q = S.q.trim().toLowerCase();
    var list = items().filter(function (x) {
      if (S.cat && (x.category || '其他') !== S.cat) return false;
      if (S.freq && x.freq !== S.freq) return false;
      if (q) {
        var hay = (x.code + ' ' + (x.name || '') + ' ' + (x.en_name || '') + ' ' + (x.issuer || '') + ' ' + (x.category || '')).toLowerCase();
        if (hay.indexOf(q) < 0) return false;
      }
      return true;
    });
    var sk = S.sort, mul = S.dir === 'asc' ? 1 : -1;
    list.sort(function (a, b) {
      var va = a[sk], vb = b[sk];
      var na = va === null || va === undefined || va === '' || (typeof va === 'number' && !isFinite(va));
      var nb = vb === null || vb === undefined || vb === '' || (typeof vb === 'number' && !isFinite(vb));
      if (na || nb) return na === nb ? 0 : (na ? 1 : -1);
      if (typeof va === 'string' || typeof vb === 'string') return String(va).localeCompare(String(vb), 'zh-Hant') * mul;
      return (va - vb) * mul;
    });
    S.rows = list;
    paintHead();
    paintTable();
  }
  function paintHead() {
    var active = [];
    if (S.cat) active.push('<span class="chip info" data-clear="cat" data-tip="移除此條件">' + esc(S.cat) + ' ✕</span>');
    if (S.freq) active.push('<span class="chip info" data-clear="freq" data-tip="移除此條件">' + esc(S.freq) + ' ✕</span>');
    if (S.q.trim()) active.push('<span class="chip info" data-clear="q" data-tip="移除此條件">關鍵字：' + esc(S.q.trim()) + ' ✕</span>');
    setHtml(document.getElementById('etfResHead'),
      '<span class="count">符合 <b>' + fmtInt(S.rows.length) + '</b> 檔 ETF</span>' +
      '<div class="active-f">' + active.join('') + '</div>' +
      (active.length ? '<button type="button" class="btn xs" data-act="reset">重設篩選</button>' : '') +
      '<span class="small muted">💡 點「🧮」可把該 ETF 的近一年報酬與殖利率帶入下方試算機</span>');
  }
  function freqChip(f) {
    if (!f) return '<span class="muted">—</span>';
    var cls = f === '月配' ? 'fund' : (f === '季配' ? 'info' : 'ghost');
    return '<span class="chip ' + cls + '">' + esc(f) + '</span>';
  }
  function paintTable() {
    var box = document.getElementById('etfTblBox');
    if (!box) return;
    if (!S.rows.length) {
      setHtml(box, '<div class="empty"><div class="big">🔍</div><h3>沒有符合篩選條件的 ETF</h3><p>請改選其他分類、配息頻率或清除關鍵字。</p></div>');
      return;
    }
    var thead = '<thead><tr>' + COLS.map(function (c) {
      var cls = [c.l ? 'l' : (c.c ? 'c' : ''), c.s === false ? '' : 'sortable', S.sort === c.k ? 'sorted' + (S.dir === 'asc' ? ' asc' : '') : ''].filter(Boolean).join(' ');
      return '<th' + (cls ? ' class="' + cls + '"' : '') + (c.s === false ? '' : ' data-esort="' + c.k + '"') + '>' + esc(c.t) + '</th>';
    }).join('') + '</tr></thead>';
    var tbody = '<tbody>' + S.rows.slice(0, S.limit).map(function (it) {
      return '<tr data-href="#/stock/' + encodeURIComponent(it.code) + '">' +
        '<td class="c">' + starBtn(it.code, 'icon') + '</td>' +
        '<td class="l"><span class="code">' + esc(it.code) + '</span></td>' +
        '<td class="l"><span class="nm" title="' + esc(it.en_name || '') + '">' + esc(it.name || it.code) + '</span>' +
          (it.issuer ? '<div class="small muted">' + esc(it.issuer) + '</div>' : '') + '</td>' +
        '<td class="l">' + (it.category ? '<span class="chip">' + esc(it.category) + '</span>' : '<span class="muted">—</span>') + '</td>' +
        '<td>' + fmtUsd(it.close) + '</td>' +
        '<td class="' + clsUpDown(it.pct) + '">' + fmtPct(it.pct) + '</td>' +
        '<td class="' + clsUpDown(it.r20) + '">' + fmtPct(it.r20, 1) + '</td>' +
        '<td class="' + clsUpDown(it.r250) + '">' + fmtPct(it.r250, 1) + '</td>' +
        '<td>' + (isNum(it.expense_ratio) ? fmtNum(it.expense_ratio, 2) + '%' : '—') + '</td>' +
        '<td class="nowrap">' + fmtUsdYi(it.aum) + '</td>' +
        '<td class="c">' + freqChip(it.freq) + '</td>' +
        '<td><b>' + fmtPct(it.yld_ttm, 2, true) + '</b></td>' +
        '<td>' + fmtUsd(it.last_cash, 4) + '</td>' +
        '<td class="c nowrap">' + esc(it.ex_date || '—') + '</td>' +
        '<td class="c"><button type="button" class="btn xs" data-calc="' + esc(it.code) + '" data-tip="帶入試算機" aria-label="帶入 ' + esc(it.code) + ' 至試算機">🧮</button></td>' +
      '</tr>';
    }).join('') + '</tbody>';
    var more = S.rows.length > S.limit
      ? '<div class="more-row"><button type="button" class="btn sm" data-act="more">載入更多（尚有 ' + fmtInt(S.rows.length - S.limit) + ' 檔）</button></div>' : '';
    setHtml(box, '<table class="tbl dense">' + thead + tbody + '</table>' + more);
  }

  // ------------------------------------------------------------------ calendar
  function todayStr() {
    var d = new Date();
    return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  }
  function parseD(s) { var t = Date.parse((s || '') + 'T00:00:00'); return isFinite(t) ? t : null; }
  function daysLeft(s) {
    var t = parseD(s), now = parseD(todayStr());
    return t === null || now === null ? null : Math.round((t - now) / 86400000);
  }
  /** 美股 T+1 交割：最後買進日 ≈ 除息日前一個交易日（未計美國假日）。 */
  function lastBuy(s) {
    var t = parseD(s);
    if (t === null) return '—';
    var d = new Date(t);
    do { d.setDate(d.getDate() - 1); } while (d.getDay() === 0 || d.getDay() === 6);
    return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  }
  function calItems() {
    var cal = (S.data && S.data.calendar) || [];
    if (!cal.length) cal = items().filter(function (x) { return x.ex_date; });
    return cal.map(function (c) {
      var base = byCode(c.code) || {};
      var o = {};
      Object.keys(base).forEach(function (k) { o[k] = base[k]; });
      Object.keys(c).forEach(function (k) { if (c[k] !== null && c[k] !== undefined) o[k] = c[k]; });
      if (isNum(c.cash)) o.last_cash = c.cash;
      return o;
    }).filter(function (c) { return c.ex_date; });
  }
  function upcoming() {
    var t = todayStr();
    return calItems().filter(function (c) { return c.ex_date >= t; }).sort(function (a, b) { return a.ex_date < b.ex_date ? -1 : (a.ex_date > b.ex_date ? 1 : 0); });
  }
  function recent() {
    var t = todayStr();
    return calItems().filter(function (c) { return c.ex_date < t; }).sort(function (a, b) { return a.ex_date < b.ex_date ? 1 : (a.ex_date > b.ex_date ? -1 : 0); });
  }
  function calendarInner() {
    var up = upcoming(), rec = recent(), isUp = S.calTab === 'upcoming';
    var rows = (isUp ? up : rec).slice(0, 20);
    var head = '<div class="card-h"><h2>📅 ETF 除息日曆</h2><span class="sp"></span><div class="seg" role="tablist">' +
      '<button type="button" class="' + (isUp ? 'on' : '') + '" data-caltab="upcoming">即將除息 (' + up.length + ')</button>' +
      '<button type="button" class="' + (!isUp ? 'on' : '') + '" data-caltab="recent">近期已除息 (' + rec.length + ')</button></div></div>' +
      '<p class="small muted" style="margin:0 0 8px">' + (isUp ? '美股採 T+1 交割，需在「除息日前一個交易日」收盤前持有才領得到本次配息（最後買進日未計美國假日）。'
        : '依除息日由近到遠排列；配息金額為每單位美元。') + '</p>';
    if (!rows.length) return head + '<div class="empty">' + (isUp ? '目前沒有已公告的即將除息 ETF' : '近期沒有除息紀錄') + '</div>';
    return head + '<div class="tbl-wrap"><table class="tbl dense"><thead><tr>' +
      (isUp ? '<th class="c">倒數</th><th class="c">最後買進日</th>' : '') + '<th class="c">除息日</th><th class="l">ETF</th><th>每單位配息</th><th>殖利率</th><th class="c">發放日</th>' +
      '</tr></thead><tbody>' + rows.map(function (c) {
        var dl = daysLeft(c.ex_date);
        return '<tr data-href="#/stock/' + encodeURIComponent(c.code) + '">' +
          (isUp ? '<td class="c">' + (isNum(dl) ? '<span class="chip ' + (dl <= 3 ? 'bad' : 'info') + '">' + (dl === 0 ? '今天' : dl + ' 天') + '</span>' : '—') + '</td>' +
            '<td class="c nowrap"><b style="color:var(--accent)">' + esc(lastBuy(c.ex_date)) + '</b></td>' : '') +
          '<td class="c nowrap">' + esc(c.ex_date) + '</td>' +
          '<td class="l"><span class="code">' + esc(c.code) + '</span> <span class="small muted">' + esc(c.name || '') + '</span>' +
            (c.freq ? ' ' + freqChip(c.freq) : '') + '</td>' +
          '<td><b>' + fmtUsd(c.last_cash, 4) + '</b></td>' +
          '<td>' + fmtPct(c.yld_ttm, 2, true) + '</td>' +
          '<td class="c nowrap">' + esc(c.pay_date || '待公告') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  // ------------------------------------------------------------------ DCA & dividend calculator
  function calcInner() {
    var c = S.calc;
    var opts = items().slice().sort(function (a, b) { return (b.aum || 0) - (a.aum || 0); }).map(function (it) {
      return '<option value="' + esc(it.code) + '"' + (c.code === it.code ? ' selected' : '') + '>' + esc(it.code + ' · ' + (it.name || '')) + '</option>';
    }).join('');
    var field = function (id, label, val, step, unit, min, max) {
      return '<label class="small" style="display:flex;flex-direction:column;gap:3px;min-width:0"><span class="muted">' + label + '</span>' +
        '<span style="display:flex;align-items:center;gap:4px"><input class="input num" data-calcf="' + id + '" type="number" inputmode="decimal" step="' + step +
        '" min="' + min + '" max="' + max + '" value="' + esc(String(val)) + '" style="width:100%;min-width:0;text-align:right;font-weight:700">' +
        '<span class="muted nowrap">' + unit + '</span></span></label>';
    };
    return '<div class="card-h"><h2>🧮 美股 ETF 定期定額＆股息試算機</h2></div>' +
      '<div class="row wrap" style="margin-bottom:8px"><span class="small muted">帶入 ETF</span>' +
        '<select class="input" id="etfCalcSel" style="flex:1;min-width:0;max-width:100%"><option value="">— 自行輸入參數 —</option>' + opts + '</select></div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,130px),1fr));gap:10px">' +
        field('pmt', '每月投入', c.pmt, 50, '美元', 0, 1000000) +
        field('years', '投資年數', c.years, 1, '年', 1, 50) +
        field('ret', '預期年化價格報酬', c.ret, 0.5, '%', -50, 50) +
        field('yld', '殖利率', c.yld, 0.1, '%', 0, 30) +
      '</div>' +
      '<label class="check mt-xs"><input type="checkbox" id="etfCalcDrip"' + (c.drip ? ' checked' : '') + '> 股息再投入（DRIP，配息自動買回同檔 ETF）</label>' +
      '<div id="etfCalcNote" class="small muted mt-xs"></div>' +
      '<div id="etfCalcOut" class="mt"></div>';
  }
  function simulate(c) {
    var months = Math.round(Math.max(1, Math.min(50, c.years)) * 12);
    var g = Math.pow(1 + Math.max(-0.99, c.ret / 100), 1 / 12) - 1;
    var y = Math.max(0, c.yld) / 100 / 12;
    var val = 0, inv = 0, divs = 0, cash = 0, yearly = [];
    for (var m = 1; m <= months; m++) {
      val += c.pmt;
      inv += c.pmt;
      val *= 1 + g;
      var dv = val * y;
      divs += dv;
      if (c.drip) val += dv; else cash += dv;
      if (m % 12 === 0 || m === months) yearly.push({y: Math.ceil(m / 12), val: val, inv: inv, divs: divs, cash: cash});
    }
    return {val: val, inv: inv, divs: divs, cash: cash, total: val + cash, annualDiv: val * Math.max(0, c.yld) / 100, yearly: yearly};
  }
  function paintCalcResult() {
    var out = document.getElementById('etfCalcOut'), note = document.getElementById('etfCalcNote');
    if (!out) return;
    var c = S.calc;
    var it = c.code ? byCode(c.code) : null;
    setHtml(note, it ? '已帶入 <b>' + esc(it.code) + '</b>：近一年報酬 ' + fmtPct(it.r250, 1) + '、近 12 月殖利率 ' + fmtPct(it.yld_ttm, 2, true) +
      (isNum(it.expense_ratio) ? '、費用率 ' + fmtNum(it.expense_ratio, 2) + '%' : '') + '。單一年度報酬波動大，長期試算建議改用 6%～10% 較保守。'
      : '「預期年化價格報酬」不含配息，配息另以殖利率計算，避免重複計入。');
    if (!isNum(c.pmt) || c.pmt <= 0 || !isNum(c.years) || c.years < 1) {
      setHtml(out, '<div class="empty small">請輸入大於 0 的每月投入金額與至少 1 年的投資期間</div>');
      return;
    }
    var r = simulate(c);
    var gain = r.total - r.inv;
    var card = function (l, v, s, cls) {
      return '<div class="val-card"><div class="l">' + l + '</div><div class="v ' + (cls || '') + '">' + v + '</div><div class="s">' + s + '</div></div>';
    };
    var chart = r.yearly.length >= 2 ? '<div class="subh mt">📈 逐年市值（長條）與累積股息（折線）</div>' +
      '<div class="legend-row"><span><i style="background:#60a5fa"></i>期末市值（美元）</span><span><i class="ln" style="background:#f59e0b"></i>累積股息（美元）</span></div>' +
      svgBarLine({
        w: 640, h: 200,
        labels: r.yearly.map(function (x) { return '第 ' + x.y + ' 年'; }),
        bars: r.yearly.map(function (x) { return Math.round(x.val); }),
        barColor: function () { return '#60a5fa'; },
        barFmt: function (v) { return fmtUsd(v, 0); },
        line: r.yearly.map(function (x) { return Math.round(x.divs); }),
        lineColor: '#f59e0b',
        lineFmt: function (v) { return fmtUsd(v, 0); },
        xLabel: function (i) { return String(r.yearly[i].y); },
        tip: function (i) {
          var x = r.yearly[i];
          return '第 ' + x.y + ' 年\n期末市值：' + fmtUsd(x.val, 0) + '\n累積投入：' + fmtUsd(x.inv, 0) + '\n累積股息：' + fmtUsd(x.divs, 0);
        }
      }) : '';
    setHtml(out,
      '<div class="val-cards">' +
        card('期末市值', fmtUsd(r.val, 0), c.drip ? '含股息再投入' : '另有現金股息 ' + fmtUsd(r.cash, 0)) +
        card('累積投入', fmtUsd(r.inv, 0), fmtUsd(c.pmt, 0) + ' × ' + fmtInt(Math.round(c.years * 12)) + ' 個月') +
        card('累積股息', fmtUsd(r.divs, 0), '期末年領約 ' + fmtUsd(r.annualDiv, 0) + '（月均 ' + fmtUsd(r.annualDiv / 12, 0) + '）') +
        card('總損益', (gain > 0 ? '+' : '') + fmtUsd(gain, 0), '報酬率 ' + fmtPct(r.inv > 0 ? gain / r.inv * 100 : null, 1), clsUpDown(gain)) +
      '</div>' + chart +
      '<p class="small muted mt-xs">未計 30% 股息預扣稅、匯率、費用率以外之交易成本；歷史表現不代表未來報酬。</p>');
  }
  function syncCalcInputs() {
    $$('[data-calcf]', S.el).forEach(function (inp) {
      var k = inp.getAttribute('data-calcf');
      if (String(S.calc[k]) !== inp.value) inp.value = String(S.calc[k]);
    });
    var sel = document.getElementById('etfCalcSel');
    if (sel) sel.value = S.calc.code || '';
  }
  function pickEtf(code, scroll) {
    var it = byCode(code);
    S.calc.code = it ? code : '';
    if (it) {
      if (isNum(it.r250)) S.calc.ret = Math.round(it.r250 * 10) / 10;
      if (isNum(it.yld_ttm)) S.calc.yld = Math.round(it.yld_ttm * 100) / 100;
    }
    saveCalc();
    syncCalcInputs();
    paintCalcResult();
    if (scroll) {
      var box = document.getElementById('etfCalcBox');
      if (box && box.scrollIntoView) box.scrollIntoView({behavior: 'smooth', block: 'start'});
      if (it) toast('已帶入 ' + code + ' 至試算機', 'ok');
    }
  }
  var calcLater = debounce(function () { if (S.alive) { saveCalc(); paintCalcResult(); } }, 150);

  // ------------------------------------------------------------------ events
  function filtersChanged() {
    S.limit = PAGE;
    refreshControls();
    syncUrl();
    filterAndPaint();
  }
  function onClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-calc]'))) { ev.preventDefault(); pickEtf(x.getAttribute('data-calc'), true); return; }
    if ((x = t.closest('[data-caltab]'))) {
      S.calTab = x.getAttribute('data-caltab');
      setHtml(document.getElementById('etfCalBox'), calendarInner());
      return;
    }
    if ((x = t.closest('[data-ecat]'))) {
      var c = x.getAttribute('data-ecat');
      S.cat = S.cat === c ? '' : c;
      filtersChanged();
      return;
    }
    if ((x = t.closest('[data-efreq]'))) { S.freq = x.getAttribute('data-efreq'); filtersChanged(); return; }
    if ((x = t.closest('[data-clear]'))) {
      var k = x.getAttribute('data-clear');
      S[k] = '';
      filtersChanged();
      return;
    }
    if ((x = t.closest('[data-esort]'))) {
      var sk = x.getAttribute('data-esort');
      if (S.sort === sk) S.dir = S.dir === 'desc' ? 'asc' : 'desc';
      else { S.sort = sk; S.dir = (sk === 'code' || sk === 'name' || sk === 'category' || sk === 'expense_ratio' || sk === 'ex_date') ? 'asc' : 'desc'; }
      syncUrl();
      filterAndPaint();
      return;
    }
    if ((x = t.closest('[data-act]'))) {
      var act = x.getAttribute('data-act');
      if (act === 'more') { S.limit += PAGE; paintTable(); }
      else if (act === 'reset') { S.cat = ''; S.freq = ''; S.q = ''; filtersChanged(); }
    }
  }
  var searchLater = debounce(function () { if (S.alive) { S.limit = PAGE; syncUrl(); filterAndPaint(); } }, 140);
  function onInput(ev) {
    var t = ev.target;
    if (t.id === 'etfQ') { S.q = t.value; searchLater(); return; }
    var k = t.getAttribute('data-calcf');
    if (k) {
      var v = parseFloat(t.value);
      if (isFinite(v)) {
        if (k === 'years') v = Math.max(1, Math.min(50, v));
        S.calc[k] = v;
        if (k === 'ret' || k === 'yld') {
          S.calc.code = '';
          var sel = document.getElementById('etfCalcSel');
          if (sel) sel.value = '';
        }
        calcLater();
      }
    }
  }
  function onChange(ev) {
    var t = ev.target;
    if (t.id === 'etfCalcSel') { pickEtf(t.value, false); return; }
    if (t.id === 'etfCalcDrip') { S.calc.drip = t.checked; saveCalc(); paintCalcResult(); }
  }

  window.Pages = window.Pages || {};
  window.Pages.etf = {
    render: render,
    update: function (params) {
      if (!S.alive || !S.data || !items().length) return false;
      applyQuery((params && params.query) || {});
      S.limit = PAGE;
      refreshControls();
      filterAndPaint();
      return true;
    },
    refresh: function () {
      if (!S.alive) return false;
      load();
      return true;
    },
    destroy: function () {
      S.alive = false;
      if (S.el) {
        S.el.removeEventListener('click', onClick);
        S.el.removeEventListener('input', onInput);
        S.el.removeEventListener('change', onChange);
      }
    }
  };
})();
