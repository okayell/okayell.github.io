/* 美股選股器 (#/screener) — client-side filters over /api/universe; state lives in the hash query. */
(function () {
  'use strict';
  // [hash key, label, universe field, panel group]
  var RANGES = [
    ['close', '股價（美元）', 'close', 'pv'], ['pct', '漲跌幅 %', 'pct', 'pv'], ['mcap', '市值（億美元）', 'mcap', 'pv'],
    ['value', '成交額（億美元）', 'value', 'pv'], ['r20', '20 日漲幅 %', 'r20', 'pv'], ['r250', '近一年漲幅 %', 'r250', 'pv'],
    ['vr', '量比 5/20', 'vol_ratio', 'pv'],
    ['pe', '本益比 P/E', 'pe', 'fund'], ['fpe', '預估本益比 Fwd P/E', 'fwd_pe', 'fund'], ['peg', 'PEG', 'peg', 'fund'],
    ['yld', '殖利率 %', 'yld', 'fund'], ['ryoy', '季營收 YoY %', 'rev_yoy', 'fund'], ['surp', 'EPS 驚喜 %', 'eps_surprise', 'fund'],
    ['gm', '毛利率 %', 'gross_margin', 'fund'],
    ['tup', '目標價空間 %', 'target_upside', 'wall'], ['abuy', '分析師買進比例 %', 'analyst_buy_pct', 'wall'],
    ['inst', '機構持股 %', 'inst_own_pct', 'wall'],
    ['score', '綜合分數', 'score', 'tech'], ['rank', '綜合排名', 'rank', 'tech'], ['rsi', 'RSI', 'rsi', 'tech'],
    ['dh', '距 52 週高 %', 'dist_hi52', 'tech']
  ];
  var RMAP = {};
  RANGES.forEach(function (r) { RMAP[r[0]] = {label: r[1], field: r[2], group: r[3]}; });
  var MARKETS = [['', '全部'], ['NASDAQ', 'NASDAQ'], ['NYSE', 'NYSE'], ['AMEX', 'AMEX']];
  var TYPES = [['', '全部'], ['eq', '股票＋ADR'], ['股票', '股票'], ['ADR', 'ADR'], ['ETF', 'ETF']];
  var GICS = ['資訊科技', '通訊服務', '非必需消費', '金融', '醫療保健', '工業', '必需消費', '能源', '公用事業', '房地產', '原物料'];
  var IDX = [['SP500', 'S&P 500'], ['NDX100', '那斯達克 100'], ['SOX', '費城半導體'], ['MAG7', '七巨頭 MAG7'], ['ADR', 'ADR'], ['DOW30', '道瓊 30']];
  var IDX_LBL = {};
  IDX.forEach(function (x) { IDX_LBL[x[0]] = x[1]; });
  // 台灣企業 ADR → 台股代號（對照台股戰情室）
  var TW_ADR = {TSM: '2330', UMC: '2303', ASX: '3711', CHT: '2412', IMOS: '8150', HIMX: '', SIMO: ''};
  var TAG_GROUPS = [
    ['財報／華爾街', ['財報Beat', 'EPS連2季Beat', 'EPS連3季Beat', 'EPS連4季Beat', '財報Miss', '營收加速', '營收高成長', '營收創高', 'EPS成長',
      '毛利率提升', '華爾街強買', '華爾街買進', '目標價空間大', '下修目標價', '機構加碼', '機構高持股', '高殖利率', '股息成長', '回購']],
    ['均線／趨勢', ['多頭排列', '空頭排列', '站上月線', '跌破月線', '站上季線', '跌破季線', '均線糾結', '創52週新高', '突破60日高', '跌破60日低', '突破箱型']],
    ['K線／缺口', ['跳空上漲', '跳空下跌', '長紅K', '長黑K', '多頭吞噬', '空頭吞噬', '錘子線', '十字線', '晨星', '夜星']],
    ['技術指標', ['KD黃金交叉', 'KD死亡交叉', 'KD高檔鈍化', 'KD低檔鈍化', 'MACD黃金交叉', 'MACD死亡交叉', 'MACD翻紅', 'MACD翻綠',
      'RSI超買', 'RSI超賣', '布林突破上軌', '布林跌破下軌', '布林收斂']],
    ['量能', ['爆量', '量增', '量縮', '價漲量增', '價跌量增']]
  ];
  var GROUPED = {};
  TAG_GROUPS.forEach(function (g) { g[1].forEach(function (t) { GROUPED[t] = 1; }); });
  // [id, label, tooltip, state]
  var PRESETS = [
    ['ai', '🚀 AI 與費半強勢股', '費半成分股或 AI／半導體次產業，站上月線且 20 日漲幅 ≥ 0%，依 20 日漲幅排序',
      {ai: true, m20: true, type: 'eq', r: {r20: [0, null]}, sort: 'r20'}],
    ['beat', '💎 財報 Beat 成長王', '最近一季 EPS 優於華爾街共識（驚喜 > 0%）且季營收年增 ≥ 15%，依營收 YoY 排序',
      {type: 'eq', r: {surp: [0.01, null], ryoy: [15, null]}, sort: 'rev_yoy'}],
    ['wall', '🏦 華爾街高潛力買進', '平均目標價空間 ≥ 20%、分析師買進比例 ≥ 60%、市值 ≥ 100 億美元，依目標價空間排序',
      {type: 'eq', r: {tup: [20, null], abuy: [60, null], mcap: [100, null]}, sort: 'target_upside'}],
    ['yield', '💰 高息價值護城河', '殖利率 ≥ 3%、本益比 0～25（排除虧損）、市值 ≥ 500 億美元的大型價值股，依殖利率排序',
      {type: 'eq', r: {yld: [3, null], pe: [0, 25], mcap: [500, null]}, sort: 'yld'}],
    ['twadr', '🇹🇼 台股 ADR 全覽', '台積電、聯電、日月光、中華電等台灣企業在美掛牌 ADR，依市值排序',
      {twadr: true, sort: 'mcap'}],
    ['ma', '📈 均線多頭突破', '均線多頭排列、站上季線與年線、距 52 週高點 5% 以內，依 20 日漲幅排序',
      {bull: true, m60: true, m240: true, type: 'eq', r: {dh: [-5, null]}, sort: 'r20'}]
  ];
  var PMAP = {};
  PRESETS.forEach(function (p) { PMAP[p[0]] = p; });
  var BOOLS = [['bull', '均線多頭排列（MA5＞MA10＞MA20＞MA60）', '多頭排列'], ['m20', '站上月線（MA20）', '站上月線'],
    ['m60', '站上季線（MA60）', '站上季線'], ['m240', '站上年線（MA240）', '站上年線'],
    ['ai', 'AI／半導體題材（費半成分或 AI 半導體次產業）', 'AI／半導體'], ['twadr', '僅台灣企業 ADR', '台灣 ADR']];
  var COLS = [
    {k: 'star', t: '', s: false, c: true, w: 30}, {k: 'code', t: '代號', l: true, w: 62}, {k: 'name', t: '名稱', l: true, w: 150},
    {k: 'industry', t: '板塊', l: true, w: 82}, {k: 'close', t: '收盤', w: 76}, {k: 'pct', t: '漲跌%', w: 70},
    {k: 'mcap', t: '市值', w: 92}, {k: 'value', t: '成交額', w: 86}, {k: 'r20', t: '20日%', w: 66},
    {k: 'pe', t: 'P/E', w: 54}, {k: 'fwd_pe', t: 'Fwd P/E', w: 62}, {k: 'peg', t: 'PEG', w: 50}, {k: 'yld', t: '殖利率', w: 58},
    {k: 'rev_yoy', t: '營收YoY', w: 72}, {k: 'eps_surprise', t: 'EPS驚喜', w: 70}, {k: 'target_upside', t: '目標空間', w: 72},
    {k: 'inst_own_pct', t: '機構%', w: 58}, {k: 'score', t: '分數', w: 50}, {k: 'signals', t: '訊號', l: true, s: false, w: 200}
  ];
  var PAGE = 200;
  var S = {el: null, alive: false, U: null, F: null, rows: [], limit: PAGE, tagCount: {}, indCount: [], idxCount: {}, extraTags: [], panelOpen: false};

  function num(v) {
    if (v === undefined || v === null || v === '') return null;
    var n = parseFloat(v);
    return isFinite(n) ? n : null;
  }
  function blankState() {
    return {q: '', mkt: '', type: '', ind: [], idx: [], r: {}, bull: false, m20: false, m60: false, m240: false, ai: false,
      twadr: false, sig: [], nr: false, sort: 'score', dir: 'desc', p: ''};
  }
  function presetState(id) {
    var F = blankState(), p = PMAP[id];
    if (!p) return F;
    var f = JSON.parse(JSON.stringify(p[3]));
    Object.keys(f).forEach(function (k) { F[k] = f[k]; });
    F.p = id;
    return F;
  }
  function list(s) { return s ? String(s).split(',').filter(Boolean) : []; }
  function stateFromQuery(q) {
    var keys = Object.keys(q).filter(function (k) { return k !== 'p'; });
    if (q.p && PMAP[q.p] && !keys.length) return presetState(q.p);
    var F = blankState();
    F.q = q.q || '';
    F.mkt = MARKETS.some(function (m) { return m[0] === q.mkt; }) ? q.mkt : '';
    F.type = TYPES.some(function (m) { return m[0] === q.type; }) ? q.type : '';
    F.ind = list(q.ind);
    F.idx = list(q.idx);
    BOOLS.forEach(function (b) { F[b[0]] = q[b[0]] === '1'; });
    F.nr = q.nr === '1';
    F.sig = list(q.sig);
    F.sort = q.sort || 'score';
    F.dir = q.dir === 'asc' ? 'asc' : 'desc';
    F.p = q.p && PMAP[q.p] ? q.p : '';
    RANGES.forEach(function (r) {
      var v = q[r[0]];
      if (!v) return;
      var parts = v.split('~');
      var lo = num(parts[0]), hi = num(parts[1]);
      if (lo !== null || hi !== null) F.r[r[0]] = [lo, hi];
    });
    return F;
  }
  function queryFromState(F) {
    var o = {p: F.p, q: F.q.trim(), mkt: F.mkt, type: F.type, ind: F.ind.join(','), idx: F.idx.join(','), sig: F.sig.join(','), nr: F.nr};
    BOOLS.forEach(function (b) { o[b[0]] = F[b[0]]; });
    RANGES.forEach(function (r) {
      var v = F.r[r[0]];
      if (v && (v[0] !== null || v[1] !== null)) o[r[0]] = (v[0] === null ? '' : v[0]) + '~' + (v[1] === null ? '' : v[1]);
    });
    if (F.sort !== 'score') o.sort = F.sort;
    if (F.dir !== 'desc') o.dir = F.dir;
    return o;
  }

  // ------------------------------------------------------------------ render
  var HEAD = '<div class="ph"><h1>🔎 美股選股器</h1>';
  function render(params, el) {
    S.el = el;
    S.alive = true;
    S.limit = PAGE;
    S.F = stateFromQuery((params && params.query) || {});
    setTitle('美股選股器');
    el.innerHTML = HEAD + '<span class="sub">NASDAQ／NYSE／AMEX 美股、ADR 與 ETF，條件即時篩選</span></div>' + skeleton(1, 420);
    el.addEventListener('click', onClick);
    el.addEventListener('input', onInput);
    el.addEventListener('change', onChange);
    return load();
  }
  function load() {
    return getUniverse().then(function (U) {
      if (!S.alive) return;
      S.U = U;
      if (U.empty || !U.list.length) { S.el.innerHTML = HEAD + '</div>' + buildingHtml(U.message); return; }
      countTags();
      paint();
    });
  }
  function countTags() {
    var tc = {}, ic = {}, xc = {};
    S.U.list.forEach(function (r) {
      (r.signals || []).forEach(function (t) { tc[t] = (tc[t] || 0) + 1; });
      (r.index_tags || []).forEach(function (t) { xc[t] = (xc[t] || 0) + 1; });
      var ind = r.industry || '未分類';
      ic[ind] = (ic[ind] || 0) + 1;
    });
    S.tagCount = tc;
    S.idxCount = xc;
    S.extraTags = Object.keys(tc).filter(function (t) { return !GROUPED[t]; }).sort(function (a, b) { return tc[b] - tc[a]; });
    // GICS 11 sectors first (fixed order), then ETF / other categories by count.
    var gics = GICS.filter(function (g) { return ic[g]; }).map(function (g) { return [g, ic[g]]; });
    var rest = Object.keys(ic).filter(function (k) { return GICS.indexOf(k) < 0; }).map(function (k) { return [k, ic[k]]; })
      .sort(function (a, b) { return b[1] - a[1]; });
    S.indCount = gics.concat(rest);
  }
  function paint() {
    var nEtf = S.U.list.filter(function (r) { return r.type === 'ETF'; }).length;
    S.el.innerHTML = HEAD + '<span class="sub">全市場 ' + fmtInt(S.U.list.length - nEtf) + ' 檔美股／ADR 與 ' + fmtInt(nEtf) +
      ' 檔 ETF（資料日期 ' + esc(S.U.date || '—') + '），條件即時篩選；網址會記住條件，可直接分享或加入書籤</span></div>' +
      '<div class="presets card" style="padding:10px 12px;margin-bottom:12px"><span class="small muted" style="margin-right:2px">⚡ 一鍵範本</span>' +
      PRESETS.map(function (p) {
        return '<button type="button" class="preset' + (S.F.p === p[0] ? ' on' : '') + '" data-preset="' + p[0] + '" data-tip="' + esc(p[2]) + '">' + p[1] + '</button>';
      }).join('') + '</div>' +
      '<div class="scr"><aside class="card fpanel' + (S.panelOpen ? ' open' : '') + '" id="scrPanel">' + panelHtml() + '</aside>' +
      '<section class="card flush" id="scrRes"><div class="res-h" id="scrHead"></div><div class="tbl-wrap scr-tbl" id="scrTbl"></div></section></div>' +
      disclaimerHtml('篩選結果僅為條件比對，不代表投資建議；價格以美元計，市值與成交額單位為億美元，資料為美股收盤後數據。');
    apply();
  }
  function rangeRow(k) {
    var v = S.F.r[k] || [null, null], d = RMAP[k];
    var val = function (x) { return x === null || x === undefined ? '' : String(x); };
    return '<div class="frow"><label for="r_' + k + '_0">' + esc(d.label) + '</label>' +
      '<input id="r_' + k + '_0" class="' + (v[0] !== null ? 'set' : '') + '" data-range="' + k + '" data-i="0" type="number" inputmode="decimal" step="any" placeholder="最低" value="' + val(v[0]) + '">' +
      '<span class="dash">~</span><input class="' + (v[1] !== null ? 'set' : '') + '" data-range="' + k + '" data-i="1" type="number" inputmode="decimal" step="any" placeholder="最高" value="' + val(v[1]) + '" aria-label="' + esc(d.label) + ' 最高"></div>';
  }
  function secCount(group) {
    var n = 0, F = S.F;
    if (group === 'basic') n = (F.q ? 1 : 0) + (F.mkt ? 1 : 0) + (F.type ? 1 : 0) + (F.nr ? 1 : 0);
    else if (group === 'ind') n = F.ind.length;
    else if (group === 'idx') n = F.idx.length;
    else if (group === 'cond') n = BOOLS.filter(function (b) { return F[b[0]]; }).length;
    else if (group === 'sig') n = F.sig.length;
    else RANGES.forEach(function (r) { if (r[3] === group && S.F.r[r[0]]) n++; });
    return n ? '<span class="cnt">' + n + '</span>' : '';
  }
  function seg(name, opts, cur) {
    return '<div class="seg" style="flex-wrap:wrap;max-width:100%">' + opts.map(function (o) {
      return '<button type="button" class="' + (cur === o[0] ? 'on' : '') + '" data-seg="' + name + '" data-v="' + esc(o[0]) + '">' + esc(o[1]) + '</button>';
    }).join('') + '</div>';
  }
  function tagBtn(t) {
    var on = S.F.sig.indexOf(t) >= 0;
    return '<button type="button" class="chip tag-toggle ' + (on ? 'on' : sigClass(t)) + '" data-tag="' + esc(t) + '"' +
      (App.SIG_TIP[t] ? ' data-tip="' + esc(App.SIG_TIP[t]) + '"' : '') + '>' + esc(t) + ' <span class="muted" style="opacity:.7">' + (S.tagCount[t] || 0) + '</span></button>';
  }
  function panelHtml() {
    var F = S.F;
    var groups = TAG_GROUPS.concat(S.extraTags.length ? [['其他', S.extraTags]] : []);
    var tagHtml = groups.map(function (g) {
      var tags = g[1].filter(function (t) { return S.tagCount[t] || F.sig.indexOf(t) >= 0; });
      if (!tags.length) return '';
      return '<div class="tag-group"><span class="gl">' + esc(g[0]) + '</span><div class="chips">' + tags.map(tagBtn).join('') + '</div></div>';
    }).join('') || '<div class="small muted">目前沒有技術訊號資料</div>';
    var idxHtml = '<div class="chips">' + IDX.filter(function (x) { return S.idxCount[x[0]] || F.idx.indexOf(x[0]) >= 0; }).map(function (x) {
      var on = F.idx.indexOf(x[0]) >= 0;
      return '<button type="button" class="chip tag-toggle' + (on ? ' on' : '') + '" data-idx="' + x[0] + '">' + esc(x[1]) +
        ' <span class="muted" style="opacity:.7">' + (S.idxCount[x[0]] || 0) + '</span></button>';
    }).join('') + '</div><div class="small muted mt-xs">多選時需同時屬於所選指數</div>';
    var sec = function (id, title, body, open) {
      return '<details class="fsec" data-sec="' + id + '"' + (open ? ' open' : '') + '><summary>' + title + secCount(id) + '</summary><div class="fsec-b">' + body + '</div></details>';
    };
    var rangesOf = function (g) { return RANGES.filter(function (r) { return r[3] === g; }).map(function (r) { return rangeRow(r[0]); }).join(''); };
    return '<div class="fpanel-h"><h2>篩選條件</h2><span class="sp"></span><button type="button" class="btn xs" data-act="clear">清除全部</button></div>' +
      sec('basic', '基本', '<input class="input" id="scrQ" type="search" placeholder="代號、中文或英文名稱" value="' + esc(F.q) + '" autocomplete="off">' +
        '<div class="row" style="flex-wrap:wrap"><span class="small muted" style="width:46px">交易所</span>' + seg('mkt', MARKETS, F.mkt) + '</div>' +
        '<div class="row" style="flex-wrap:wrap"><span class="small muted" style="width:46px">類型</span>' + seg('type', TYPES, F.type) + '</div>' +
        '<label class="check"><input type="checkbox" data-bool="nr"' + (F.nr ? ' checked' : '') + '> 排除風險股（高波動／過熱／流動性偏低／虧損／財報將屆）</label>', true) +
      sec('idx', '指數成分', idxHtml, F.idx.length > 0) +
      sec('ind', 'GICS 板塊', '<input class="input" id="indQ" type="search" placeholder="搜尋板塊" autocomplete="off" style="height:28px">' +
        '<div class="ind-list" id="indList">' + indListHtml('') + '</div>', F.ind.length > 0) +
      sec('pv', '價量與市值', rangesOf('pv'), true) +
      sec('fund', '財報與估值', rangesOf('fund'), hasGroup('fund')) +
      sec('wall', '華爾街與機構', rangesOf('wall'), hasGroup('wall')) +
      sec('tech', '技術與評分', rangesOf('tech'), hasGroup('tech')) +
      sec('cond', '均線與題材', BOOLS.map(function (b) {
        return '<label class="check"><input type="checkbox" data-bool="' + b[0] + '"' + (F[b[0]] ? ' checked' : '') + '> ' + esc(b[1]) + '</label>';
      }).join(''), secCount('cond') !== '') +
      sec('sig', '技術訊號標籤 <span class="small muted" style="font-weight:400">（需同時符合）</span>', tagHtml, F.sig.length > 0);
  }
  function hasGroup(g) { return RANGES.some(function (r) { return r[3] === g && S.F.r[r[0]]; }); }
  function indListHtml(filter) {
    filter = (filter || '').trim();
    return S.indCount.filter(function (x) { return !filter || x[0].indexOf(filter) >= 0; }).map(function (x) {
      return '<label><input type="checkbox" data-ind="' + esc(x[0]) + '"' + (S.F.ind.indexOf(x[0]) >= 0 ? ' checked' : '') + '> ' + esc(x[0]) +
        '<span class="n">' + x[1] + '</span></label>';
    }).join('') || '<div class="small muted" style="padding:6px">沒有符合的板塊</div>';
  }

  // ------------------------------------------------------------------ filtering
  var AI_RE = /AI|半導體|晶片|晶圓|GPU|記憶體/i;
  function isAi(r) { return r.index_tags.indexOf('SOX') >= 0 || AI_RE.test(r.sub_industry || ''); }
  function apply() {
    var F = S.F, all = S.U.list, out = [];
    var q = F.q.trim().toLowerCase();
    var indSet = F.ind.length ? new Set(F.ind) : null;
    var rdefs = [];
    Object.keys(F.r).forEach(function (k) {
      var v = F.r[k];
      if (v && RMAP[k] && (v[0] !== null || v[1] !== null)) rdefs.push([RMAP[k].field, v[0], v[1]]);
    });
    for (var i = 0; i < all.length; i++) {
      var r = all[i];
      if (F.mkt && r.market !== F.mkt) continue;
      if (F.type === 'eq') { if (r.type === 'ETF') continue; } else if (F.type && r.type !== F.type) continue;
      if (indSet && !indSet.has(r.industry || '未分類')) continue;
      if (q && r._hay.indexOf(q) < 0) continue;
      var ok = true, j;
      for (j = 0; j < F.idx.length; j++) { if (r.index_tags.indexOf(F.idx[j]) < 0) { ok = false; break; } }
      if (!ok) continue;
      for (j = 0; j < rdefs.length; j++) {
        var v = r[rdefs[j][0]];
        if (typeof v !== 'number' || !isFinite(v) || (rdefs[j][1] !== null && v < rdefs[j][1]) || (rdefs[j][2] !== null && v > rdefs[j][2])) { ok = false; break; }
      }
      if (!ok) continue;
      var bits = r.ma_bits || 0;
      if (F.bull && !(bits & 64)) continue;
      if (F.m20 && !(bits & 4)) continue;
      if (F.m60 && !(bits & 8)) continue;
      if (F.m240 && !(bits & 32)) continue;
      if (F.ai && !isAi(r)) continue;
      if (F.twadr && !Object.prototype.hasOwnProperty.call(TW_ADR, r.code)) continue;
      if (F.sig.length) {
        for (j = 0; j < F.sig.length; j++) { if (r.signals.indexOf(F.sig[j]) < 0) { ok = false; break; } }
        if (!ok) continue;
      }
      if (F.nr && r.risk.length) continue;
      out.push(r);
    }
    var key = F.sort, dir = F.dir === 'asc' ? 1 : -1;
    out.sort(function (a, b) {
      var x = a[key], y = b[key];
      var xn = x === null || x === undefined || (typeof x === 'number' && !isFinite(x));
      var yn = y === null || y === undefined || (typeof y === 'number' && !isFinite(y));
      if (xn || yn) return xn === yn ? 0 : (xn ? 1 : -1);
      if (typeof x === 'string') return x.localeCompare(y, 'zh-Hant') * dir;
      return (x - y) * dir;
    });
    S.rows = out;
    renderHead();
    renderTable();
    syncUrl();
  }
  function syncUrl() { App.replaceHash('#/screener' + buildQuery(queryFromState(S.F))); }

  function activeChips() {
    var F = S.F, c = [];
    if (F.q) c.push(['q', '關鍵字：' + F.q]);
    if (F.mkt) c.push(['mkt', F.mkt]);
    if (F.type) c.push(['type', F.type === 'eq' ? '股票＋ADR' : F.type]);
    F.idx.forEach(function (x) { c.push(['idx:' + x, IDX_LBL[x] || x]); });
    F.ind.forEach(function (x) { c.push(['ind:' + x, x]); });
    RANGES.forEach(function (r) {
      var v = F.r[r[0]];
      if (!v) return;
      var t = v[0] !== null && v[1] !== null ? v[0] + '～' + v[1] : (v[0] !== null ? '≥ ' + v[0] : '≤ ' + v[1]);
      c.push(['r:' + r[0], r[1].replace(/ /g, '') + ' ' + t]);
    });
    BOOLS.forEach(function (b) { if (F[b[0]]) c.push([b[0], b[2]]); });
    F.sig.forEach(function (x) { c.push(['sig:' + x, '#' + x]); });
    if (F.nr) c.push(['nr', '排除風險股']);
    return c;
  }
  function renderHead() {
    var chips = activeChips();
    setHtml(document.getElementById('scrHead'),
      '<button type="button" class="btn sm f-toggle" data-act="panel">⚙️ 篩選條件' + (chips.length ? '（' + chips.length + '）' : '') + '</button>' +
      '<span class="count">符合 <b>' + fmtInt(S.rows.length) + '</b> 檔</span>' +
      '<div class="active-f">' + chips.map(function (c) {
        return '<span class="chip info" data-rm="' + esc(c[0]) + '" data-tip="移除此條件">' + esc(c[1]) + ' ✕</span>';
      }).join('') + '</div>' +
      '<button type="button" class="btn sm" data-act="csv"' + (S.rows.length ? '' : ' disabled') + ' data-tip="匯出全部符合的標的（含未顯示的列）">⬇ 匯出 CSV</button>');
  }
  function pctCell(v, d) { return '<td class="' + clsUpDown(v) + '">' + fmtPct(v, d === undefined ? 1 : d) + '</td>'; }
  function nameCell(r) {
    var tw = Object.prototype.hasOwnProperty.call(TW_ADR, r.code) && TW_ADR[r.code];
    var tags = (r.index_tags || []).filter(function (t) { return t !== 'ADR' || r.type !== 'ADR'; });
    return '<td class="l nm" title="' + esc((r.name || '') + (r.en_name ? ' · ' + r.en_name : '')) + '">' + esc(r.name || r.code) +
      (r.risk.length ? '<span class="risk-dot" data-tip="風險：' + esc(r.risk.join('、')) + '">⚠</span>' : '') +
      ((tags.length || r.type === 'ADR' || tw) ? '<div class="nowrap" style="margin-top:2px;overflow:hidden;text-overflow:ellipsis">' +
        (r.type === 'ADR' ? '<span class="idx-tag t-ADR" data-tip="美國存託憑證（ADR）">ADR</span> ' : '') + idxTags(tags) +
        (tw ? ' <a class="idx-tag" href="' + esc(twStockUrl(tw)) + '" target="_blank" rel="noopener" data-tip="開啟台股戰情室：' + tw + '">🇹🇼 ' + tw + '</a>' : '') +
        '</div>' : '') + '</td>';
  }
  function cell(r, k) {
    switch (k) {
      case 'star': return '<td class="c">' + starBtn(r.code, 'icon') + '</td>';
      case 'code': return '<td class="l code">' + esc(r.code) + '</td>';
      case 'name': return nameCell(r);
      case 'industry': return '<td class="l muted" title="' + esc((r.industry || '') + (r.sub_industry ? '／' + r.sub_industry : '')) + '">' +
        esc(r.type === 'ETF' ? 'ETF' : (r.industry || '—')) + (r.market ? '<div class="small muted">' + esc(r.market) + '</div>' : '') + '</td>';
      case 'close': return '<td>' + fmtUsd(r.close) + '</td>';
      case 'pct': return pctCell(r.pct, 2);
      case 'mcap': return '<td>' + fmtUsdYi(r.mcap) + '</td>';
      case 'value': return '<td>' + fmtUsdYi(r.value) + '</td>';
      case 'r20': return pctCell(r.r20);
      case 'pe': return '<td>' + fmtNum(r.pe, 1) + '</td>';
      case 'fwd_pe': return '<td>' + fmtNum(r.fwd_pe, 1) + '</td>';
      case 'peg': return '<td>' + fmtNum(r.peg, 2) + '</td>';
      case 'yld': return '<td>' + fmtPct(r.yld, 2, true) + '</td>';
      case 'rev_yoy': return pctCell(r.rev_yoy);
      case 'eps_surprise': return pctCell(r.eps_surprise);
      case 'target_upside': return pctCell(r.target_upside);
      case 'inst_own_pct': return '<td>' + fmtPct(r.inst_own_pct, 1, true) + '</td>';
      case 'score': return '<td>' + (isNum(r.score) ? '<b style="color:' + App.scoreColor(r.score) + '">' + fmtScore(r.score) + '</b>' : '—') + '</td>';
      case 'signals': return '<td class="l sig-cell"' + (r.signals.length > 3 ? ' data-tip="' + esc(r.signals.join('、')) + '"' : '') + '><div class="sigs">' +
        (r.signals.length ? r.signals.slice(0, 4).map(sigChip).join('') : '<span class="muted">—</span>') + '</div></td>';
    }
    return '<td></td>';
  }
  function renderTable() {
    var F = S.F, rows = S.rows.slice(0, S.limit);
    var head = '<thead><tr>' + COLS.map(function (c) {
      var sortable = c.s !== false, on = F.sort === c.k;
      return '<th class="' + (c.l ? 'l ' : '') + (c.c ? 'c ' : '') + (sortable ? 'sortable ' : '') + (on ? 'sorted ' + (F.dir === 'asc' ? 'asc' : '') : '') + '"' +
        (sortable ? ' data-sort="' + c.k + '"' : '') + '>' + c.t + '</th>';
    }).join('') + '</tr></thead>';
    var body = rows.map(function (r) {
      return '<tr data-href="#/stock/' + encodeURIComponent(r.code) + '">' + COLS.map(function (c) { return cell(r, c.k); }).join('') + '</tr>';
    }).join('');
    var html;
    if (!S.rows.length) {
      html = '<div class="empty"><div class="big">🔎</div><h3>沒有符合條件的標的</h3><p>試著放寬數值範圍、減少指數或標籤條件，或點「清除全部」。</p></div>';
    } else {
      var tw = COLS.reduce(function (s, c) { return s + (c.w || 0); }, 0);
      html = '<table class="tbl dense fixed" style="min-width:' + tw + 'px"><colgroup>' + COLS.map(function (c) { return c.w ? '<col style="width:' + c.w + 'px">' : '<col>'; }).join('') +
        '</colgroup>' + head + '<tbody>' + body + '</tbody></table>' +
        (S.rows.length > S.limit ? '<div class="more-row"><button type="button" class="btn sm" data-act="more">顯示更多（已顯示 ' + fmtInt(S.limit) +
          ' / ' + fmtInt(S.rows.length) + '）</button></div>' : '');
    }
    setHtml(document.getElementById('scrTbl'), html);
  }

  // ------------------------------------------------------------------ events
  function changed(clearPreset) {
    if (clearPreset !== false) S.F.p = '';
    S.limit = PAGE;
    $$('.preset', S.el).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-preset') === S.F.p); });
    $$('.fsec', S.el).forEach(function (d) {
      var s = d.querySelector('summary'), id = d.getAttribute('data-sec');
      var old = s.querySelector('.cnt');
      if (old) old.remove();
      var cnt = secCount(id);
      if (cnt) s.insertAdjacentHTML('beforeend', cnt);
    });
    apply();
  }
  var applyLater = App.debounce(function () { if (S.alive) changed(); }, 140);
  function onInput(ev) {
    var t = ev.target;
    if (t.id === 'scrQ') { S.F.q = t.value; applyLater(); return; }
    if (t.id === 'indQ') { setHtml(document.getElementById('indList'), indListHtml(t.value)); return; }
    var rk = t.getAttribute('data-range');
    if (rk) {
      var v = S.F.r[rk] || [null, null];
      v[+t.getAttribute('data-i')] = num(t.value);
      if (v[0] === null && v[1] === null) delete S.F.r[rk]; else S.F.r[rk] = v;
      t.classList.toggle('set', num(t.value) !== null);
      applyLater();
    }
  }
  function onChange(ev) {
    var t = ev.target;
    var b = t.getAttribute('data-bool');
    if (b) { S.F[b] = t.checked; changed(); return; }
    if (t.hasAttribute('data-ind')) {
      var ind = t.getAttribute('data-ind'), i = S.F.ind.indexOf(ind);
      if (t.checked && i < 0) S.F.ind.push(ind);
      if (!t.checked && i >= 0) S.F.ind.splice(i, 1);
      changed();
    }
  }
  function rebuildPanel() {
    var p = document.getElementById('scrPanel');
    if (p) p.innerHTML = panelHtml();
  }
  function removeChip(key) {
    var F = S.F;
    if (key.indexOf('ind:') === 0) F.ind = F.ind.filter(function (x) { return x !== key.slice(4); });
    else if (key.indexOf('idx:') === 0) F.idx = F.idx.filter(function (x) { return x !== key.slice(4); });
    else if (key.indexOf('sig:') === 0) F.sig = F.sig.filter(function (x) { return x !== key.slice(4); });
    else if (key.indexOf('r:') === 0) delete F.r[key.slice(2)];
    else if (key === 'q' || key === 'mkt' || key === 'type') F[key] = '';
    else F[key] = false;
    rebuildPanel();
    changed();
  }
  function onClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-preset]'))) {
      var id = x.getAttribute('data-preset');
      S.F = S.F.p === id ? blankState() : presetState(id);
      rebuildPanel();
      changed(false);
      return;
    }
    if ((x = t.closest('[data-seg]'))) {
      S.F[x.getAttribute('data-seg')] = x.getAttribute('data-v');
      $$('[data-seg="' + x.getAttribute('data-seg') + '"]', S.el).forEach(function (b) { b.classList.toggle('on', b === x); });
      changed();
      return;
    }
    if ((x = t.closest('[data-idx]'))) {
      var ix = x.getAttribute('data-idx'), ii = S.F.idx.indexOf(ix);
      if (ii >= 0) S.F.idx.splice(ii, 1); else S.F.idx.push(ix);
      x.classList.toggle('on', ii < 0);
      changed();
      return;
    }
    if ((x = t.closest('[data-tag]'))) {
      var tag = x.getAttribute('data-tag'), i = S.F.sig.indexOf(tag);
      if (i >= 0) S.F.sig.splice(i, 1); else S.F.sig.push(tag);
      x.classList.toggle('on', i < 0);
      if (i >= 0) { var cls = sigClass(tag); if (cls) x.classList.add(cls); } else x.classList.remove('bull', 'bear', 'fund', 'warn');
      changed();
      return;
    }
    if ((x = t.closest('[data-sort]'))) {
      var k = x.getAttribute('data-sort');
      if (S.F.sort === k) S.F.dir = S.F.dir === 'desc' ? 'asc' : 'desc';
      else { S.F.sort = k; S.F.dir = (k === 'code' || k === 'name' || k === 'industry' || k === 'pe' || k === 'fwd_pe' || k === 'peg') ? 'asc' : 'desc'; }
      S.limit = PAGE;
      apply();
      return;
    }
    if ((x = t.closest('[data-rm]'))) { removeChip(x.getAttribute('data-rm')); return; }
    if ((x = t.closest('[data-act]'))) {
      var act = x.getAttribute('data-act');
      if (act === 'more') { S.limit += PAGE; renderTable(); }
      else if (act === 'clear') { S.F = blankState(); rebuildPanel(); changed(); }
      else if (act === 'csv') exportCsv();
      else if (act === 'panel') {
        S.panelOpen = !S.panelOpen;
        var p = document.getElementById('scrPanel');
        if (p) p.classList.toggle('open', S.panelOpen);
      }
    }
  }
  function csvCell(v) {
    if (v === null || v === undefined || (typeof v === 'number' && !isFinite(v))) return '';
    var s = Array.isArray(v) ? v.join('、') : String(v);
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function exportCsv() {
    var cols = [['code', '代號'], ['name', '名稱'], ['en_name', '英文名稱'], ['market', '交易所'], ['industry', 'GICS 板塊'], ['sub_industry', '次產業'],
      ['type', '類型'], ['index_tags', '指數成分'], ['close', '收盤(美元)'], ['chg', '漲跌(美元)'], ['pct', '漲跌%'], ['vol', '成交量(股)'],
      ['value', '成交額(億美元)'], ['mcap', '市值(億美元)'], ['r5', '5日%'], ['r20', '20日%'], ['r60', '60日%'], ['r250', '近一年%'],
      ['pe', '本益比'], ['fwd_pe', '預估本益比'], ['peg', 'PEG'], ['pb', '股價淨值比'], ['yld', '殖利率%'], ['eps_ttm', 'EPS近四季(美元)'],
      ['eps_surprise', 'EPS驚喜%'], ['rev_yoy', '季營收YoY%'], ['gross_margin', '毛利率%'], ['inst_own_pct', '機構持股%'],
      ['target_price', '目標價(美元)'], ['target_upside', '目標價空間%'], ['analyst_buy_pct', '分析師買進%'], ['score', '綜合分數'],
      ['rank', '排名'], ['tech_score', '技術分數'], ['signals', '訊號'], ['risk', '風險']];
    var lines = [cols.map(function (c) { return c[1]; }).join(',')];
    S.rows.forEach(function (r) { lines.push(cols.map(function (c) { return csvCell(r[c[0]]); }).join(',')); });
    var blob = new Blob(['\ufeff' + lines.join('\r\n')], {type: 'text/csv;charset=utf-8'});
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'us_screener_' + (S.U.date || 'data') + '.csv';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
    toast('已匯出 ' + S.rows.length + ' 檔標的', 'ok');
  }

  window.Pages = window.Pages || {};
  window.Pages.screener = {
    render: render,
    update: function (params) {
      if (!S.U || !S.alive) return false;
      var F = stateFromQuery((params && params.query) || {});
      if (JSON.stringify(queryFromState(F)) === JSON.stringify(queryFromState(S.F))) return true;
      S.F = F;
      paint();
      return true;
    },
    refresh: function () {
      if (!S.alive) return false;
      load();
      return true;
    },
    destroy: function () {
      S.alive = false;
      if (S.el) {
        S.el.removeEventListener('click', onClick);
        S.el.removeEventListener('input', onInput);
        S.el.removeEventListener('change', onChange);
      }
    }
  };
})();
