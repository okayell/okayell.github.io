/* 績效追蹤 (#/picks) — walk-forward 回測 KPI、三線 SVG 淨值曲線（策略／標普 500／全市場等權）、
 * 不同持有天數報酬與勝率、歷史推薦紀錄、選股方法。資料：/api/picks（SPEC §4.5）。 */
(function () {
  'use strict';
  var P = {el: null, alive: false, d: null, showN: 10, w: 0};
  // [label, color, column index in equity rows [date, strat, spx, ew]]
  var LINES = [['策略', '#2563eb', 1], ['標普 500', '#94a3b8', 2], ['全市場等權', '#f59e0b', 3]];

  function kpi(label, val, sub, cls, tip) {
    return '<div class="kpi"' + (tip ? ' data-tip="' + esc(tip) + '"' : '') + '><div class="kpi-l">' + label + '</div><div class="kpi-v ' + (cls || '') + '">' + val + '</div>' +
      (sub ? '<div class="kpi-s">' + sub + '</div>' : '') + '</div>';
  }
  function head() {
    return '<div class="ph"><h1>📈 績效追蹤</h1><span class="sub">用歷史資料檢驗「今日推薦」模型：每期買進推薦股，表現能否勝過標普 500？</span></div>';
  }
  function benchName(bt) { return (bt && bt.bench_name) || '標普 500'; }
  function lineLabel(l, bt) {
    if (l[2] === 1) return '策略（前 ' + (isNum(bt.top_n) ? bt.top_n : 'N') + ' 名等權）';
    if (l[2] === 2) return benchName(bt);
    return l[0];
  }

  function render(params, el) {
    P.el = el;
    P.alive = true;
    P.showN = 10;
    setTitle('績效追蹤');
    el.innerHTML = head() + skeleton(3, 140);
    el.addEventListener('click', onClick);
    window.addEventListener('resize', onResize);
    return api('/api/picks').then(function (d) {
      if (!P.alive) return;
      P.d = d || {};
      paint();
    });
  }
  function paint() {
    var d = P.d;
    if (isEmptyPayload(d)) { P.el.innerHTML = head() + buildingHtml(d && d.message); return; }
    var bt = d.backtest || {}, hasBt = isNum(bt.avg_ret);
    var html = head();
    if (hasBt) {
      html += '<div class="kpis">' +
        kpi('回測期間', esc(fmtMD(bt.start) + ' – ' + fmtMD(bt.end)), esc((bt.start || '').slice(0, 4)) + ' 年起・' + fmtInt(bt.samples) + ' 期樣本') +
        kpi('策略平均報酬', fmtPct(bt.avg_ret), '每期持有 ' + fmtInt(bt.hold_days) + ' 個交易日・前 ' + fmtInt(bt.top_n) + ' 名', clsUpDown(bt.avg_ret),
          '每期等權買進推薦前 N 名、持有固定天數的平均報酬') +
        kpi(esc(benchName(bt)) + ' 平均', fmtPct(bt.bench_avg_ret), '同期間大盤', clsUpDown(bt.bench_avg_ret)) +
        (isNum(bt.ew_avg_ret) ? kpi('全市場等權平均', fmtPct(bt.ew_avg_ret), '同期間所有合格股票', clsUpDown(bt.ew_avg_ret),
          '比較基準：同期間所有合格股票的等權平均報酬，比市值加權指數更能反映選股能力') : '') +
        kpi('超額報酬（vs 大盤）', fmtPct(bt.excess), isNum(bt.excess_ew) ? 'vs 全市場等權 ' + fmtPct(bt.excess_ew) : '', clsUpDown(bt.excess)) +
        kpi('勝率', isNum(bt.win_rate) ? fmtNum(bt.win_rate, 1) + '%' : '—', '報酬為正的期數比例', isNum(bt.win_rate) ? (bt.win_rate >= 50 ? 'up' : 'down') : '') + '</div>' +
        (bt.note ? '<div class="small muted mt-s">ℹ️ ' + esc(bt.note) + '</div>' : '') +
        '<section class="card mt"><div class="card-h"><h2>📈 累積淨值曲線</h2><span class="sub">起點 = 0%，滑鼠移到圖上看各期數值</span><span class="sp"></span>' +
        '<div class="legend-row" style="margin:0">' + LINES.filter(function (l) { return hasCol(bt, l[2]); }).map(function (l) {
          return '<span><i class="ln" style="background:' + l[1] + '"></i>' + esc(lineLabel(l, bt)) + '</span>';
        }).join('') + '</div></div><div id="eqLast" class="row wrap small" style="margin-bottom:6px"></div><div id="eqChart" style="width:100%;min-width:0"></div></section>' +
        horizonsHtml(bt);
    } else {
      html += '<div class="card empty"><div class="big">⏳</div><h3>回測資料累積中</h3><p>需要足夠的歷史資料才能計算回測績效，資料建立完成後會自動顯示。</p></div>';
    }
    html += historyHtml(d.history || []) + methodHtml(d.method || {}) +
      disclaimerHtml('回測結果為歷史模擬，未來市場狀況可能完全不同；過去績效不代表未來報酬，美股另涉及匯率風險。');
    P.el.innerHTML = html;
    if (hasBt) drawEquity();
  }
  function hasCol(bt, i) { return (bt.equity || []).some(function (r) { return r && isNum(r[i]); }); }

  // ------------------------------------------------------------------ SVG equity curve
  function drawEquity() {
    var box = document.getElementById('eqChart'), bt = (P.d && P.d.backtest) || {};
    if (!box) return;
    var rows = (bt.equity || []).filter(function (r) { return r && r[0]; });
    if (rows.length < 2) { setHtml(box, '<div class="empty">資料點不足，無法繪製曲線</div>'); return; }
    var W = Math.max(300, Math.round(box.clientWidth || 760)), H = W < 520 ? 240 : 320;
    P.w = W;
    var padL = 50, padR = 12, padT = 12, padB = 26, plotW = W - padL - padR, plotH = H - padT - padB, n = rows.length;
    var lines = LINES.filter(function (l) { return hasCol(bt, l[2]); });
    var vals = [];
    rows.forEach(function (r) { lines.forEach(function (l) { if (isNum(r[l[2]])) vals.push((r[l[2]] - 1) * 100); }); });
    var sc = niceScale(Math.min.apply(null, vals.concat([0])), Math.max.apply(null, vals.concat([0])), 4);
    var xOf = function (i) { return padL + (n === 1 ? 0 : i * plotW / (n - 1)); };
    var yOf = function (v) { return padT + (1 - (v - sc.min) / (sc.max - sc.min)) * plotH; };
    var out = [];
    sc.ticks.forEach(function (t) {
      var y = yOf(t).toFixed(1);
      out.push('<line class="' + (t === 0 ? 'axis-l' : 'grid-l') + '" x1="' + padL + '" x2="' + (W - padR) + '" y1="' + y + '" y2="' + y + '"' +
        (t === 0 ? ' stroke-dasharray="4 3"' : '') + '/>');
      out.push('<text x="' + (padL - 6) + '" y="' + y + '" dy="4" text-anchor="end">' + esc((t > 0 ? '+' : '') + fmtNum(t, sc.step < 1 ? 1 : 0) + '%') + '</text>');
    });
    var every = Math.max(1, Math.ceil(n / Math.max(2, plotW / 74)));
    for (var j = 0; j < n; j++) {
      if ((n - 1 - j) % every) continue;
      out.push('<text x="' + xOf(j).toFixed(1) + '" y="' + (H - 7) + '" text-anchor="middle">' + esc(fmtMD(rows[j][0])) + '</text>');
    }
    lines.slice().reverse().forEach(function (l) {
      var d = '', pen = false;
      rows.forEach(function (r, i) {
        var v = r[l[2]];
        if (!isNum(v)) { pen = false; return; }
        d += (pen ? 'L' : 'M') + xOf(i).toFixed(1) + ' ' + yOf((v - 1) * 100).toFixed(1);
        pen = true;
      });
      out.push('<path d="' + d + '" fill="none" style="stroke:' + l[1] + '" stroke-width="' + (l[2] === 1 ? 2.6 : 1.8) + '" stroke-linejoin="round" stroke-linecap="round"/>');
    });
    var step = Math.max(1, Math.ceil(n / 160)), hw = plotW / Math.max(1, (n - 1) / step);
    for (var i = 0; i < n; i += step) {
      var r = rows[i];
      var tip = r[0] + lines.map(function (l) { return isNum(r[l[2]]) ? '\n' + lineLabel(l, bt) + ' ' + fmtPct((r[l[2]] - 1) * 100, 1) : ''; }).join('');
      out.push('<rect class="hit" x="' + Math.max(padL, xOf(i) - hw / 2).toFixed(1) + '" y="' + padT + '" width="' + hw.toFixed(1) + '" height="' + plotH + '" data-tip="' + esc(tip) + '"/>');
    }
    setHtml(box, '<div class="svgc"><svg viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '" role="img" aria-label="累積淨值曲線">' + out.join('') + '</svg></div>');
    var last = rows[n - 1], lastBox = document.getElementById('eqLast');
    if (lastBox) {
      setHtml(lastBox, '<span class="muted">截至 ' + esc(last[0]) + '：</span>' + lines.map(function (l) {
        var v = last[l[2]];
        return '<span><span style="color:' + l[1] + ';font-weight:700">' + esc(lineLabel(l, bt)) + '</span> <b class="' + clsUpDown(isNum(v) ? v - 1 : null) + '">' +
          (isNum(v) ? fmtPct((v - 1) * 100, 1) : '—') + '</b></span>';
      }).join('<span class="muted">・</span>'));
    }
  }
  var onResize = App.debounce(function () {
    if (!P.alive) return;
    var box = document.getElementById('eqChart');
    if (box && Math.abs((box.clientWidth || 0) - P.w) > 8) drawEquity();
  }, 150);

  // ------------------------------------------------------------------ horizons / history / method
  function horizonsHtml(bt) {
    var hz = bt.horizons || [];
    if (!hz.length) return '';
    var hasEw = hz.some(function (h) { return isNum(h.ew); });
    return '<section class="card mt"><div class="card-h"><h2>⏱ 不同持有天數</h2><span class="sub">持有 5／10／20 個交易日，報酬與勝率怎麼變化？</span></div>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="l">持有天數</th><th>策略平均報酬</th><th>勝率</th><th>' + esc(benchName(bt)) + '</th><th>超額（vs 大盤）</th>' +
      (hasEw ? '<th>全市場等權</th><th>超額（vs 等權）</th>' : '') + '<th>樣本數</th></tr></thead><tbody>' +
      hz.map(function (h) {
        var ex = isNum(h.bench) && isNum(h.avg_ret) ? h.avg_ret - h.bench : null, exEw = isNum(h.ew) && isNum(h.avg_ret) ? h.avg_ret - h.ew : null;
        return '<tr><td class="l"><b>' + fmtInt(h.days) + ' 日</b></td><td class="' + clsUpDown(h.avg_ret) + '"><b>' + fmtPct(h.avg_ret) + '</b></td>' +
          '<td>' + (isNum(h.win_rate) ? fmtNum(h.win_rate, 1) + '%' : '—') + '</td>' +
          '<td class="' + clsUpDown(h.bench) + '">' + fmtPct(h.bench) + '</td><td class="' + clsUpDown(ex) + '">' + fmtPct(ex) + '</td>' +
          (hasEw ? '<td class="' + clsUpDown(h.ew) + '">' + fmtPct(h.ew) + '</td><td class="' + clsUpDown(exEw) + '">' + fmtPct(exEw) + '</td>' : '') +
          '<td>' + fmtInt(h.samples) + '</td></tr>';
      }).join('') + '</tbody></table></div></section>';
  }
  function historyHtml(hist) {
    var h = '<section class="card mt"><div class="card-h"><h2>🗂 歷史推薦紀錄</h2><span class="sub">每期推薦股從推薦日收盤到最新收盤的報酬</span></div>';
    if (!hist.length) return h + '<div class="empty">尚無歷史推薦紀錄（網站啟用後每個交易日會累積一筆）。</div></section>';
    var list = hist.slice(0, P.showN);
    return h + '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="l">推薦日</th><th class="c">類型</th><th>平均報酬</th><th>大盤</th><th>超額</th>' +
      '<th class="l">個股報酬（推薦日收盤 → 最新）</th></tr></thead><tbody>' +
      list.map(function (x) {
        var ex = isNum(x.avg_ret) && isNum(x.bench_ret) ? x.avg_ret - x.bench_ret : null;
        var items = (x.items || []).slice().sort(function (a, b) { return (isNum(b.ret) ? b.ret : -1e9) - (isNum(a.ret) ? a.ret : -1e9); });
        var live = x.kind === '實盤';
        return '<tr><td class="l"><b>' + esc(x.date || '—') + '</b></td><td class="c"><span class="chip ' + (live ? 'info' : 'ghost') + '" data-tip="' +
          (live ? '網站當天實際產生的推薦' : '網站啟用前，以相同模型回推的推薦') + '">' + esc(x.kind || '—') + '</span></td>' +
          '<td class="' + clsUpDown(x.avg_ret) + '"><b>' + fmtPct(x.avg_ret) + '</b></td><td class="' + clsUpDown(x.bench_ret) + '">' + fmtPct(x.bench_ret) + '</td>' +
          '<td class="' + clsUpDown(ex) + '">' + fmtPct(ex) + '</td><td class="l wrap"><div class="hist-items">' +
          items.map(function (it) {
            return '<a href="#/stock/' + encodeURIComponent(it.code) + '" data-tip="' + esc(it.code + ' ' + (it.name || '') + '\n推薦日 ' + fmtUsd(it.entry) + ' → 最新 ' + fmtUsd(it.last)) + '">' +
              esc(it.code) + ' <span class="' + clsUpDown(it.ret) + '">' + fmtPct(it.ret, 1) + '</span></a>';
          }).join('') + '</div></td></tr>';
      }).join('') + '</tbody></table></div>' +
      (hist.length > P.showN ? '<div class="more-row"><button type="button" class="btn sm" data-act="more-hist">顯示更多（' + P.showN + ' / ' + hist.length + '）</button></div>' : '') +
      '</section>';
  }
  function methodHtml(m) {
    var w = m.weights || {}, labels = m.factor_labels || {}, names = App.FACTOR_NAME || {};
    var keys = (App.FACTORS || []).map(function (f) { return f[0]; });
    Object.keys(w).forEach(function (k) { if (keys.indexOf(k) < 0) keys.push(k); });
    keys.sort(function (a, b) { return (w[b] || 0) - (w[a] || 0); });
    var maxW = Math.max.apply(null, keys.map(function (k) { return w[k] || 0; }).concat([0.01]));
    return '<section class="card mt"><div class="card-h"><h2>🧠 選股方法</h2><span class="sub">五因子全市場百分位綜合排名</span></div>' +
      '<div class="ux-grid"><div>' + (m.text ? '<p style="line-height:1.8;color:var(--text-2)">' + esc(m.text) + '</p>' : '') +
      ((m.filters || []).length ? '<div class="subh">篩選條件</div><ul class="risk-list">' + m.filters.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ul>' : '') +
      '</div><div><div class="subh" style="margin-top:0">因子權重</div><div class="wbars">' + keys.map(function (k) {
        var wt = isNum(w[k]) ? w[k] : 0;
        return '<div class="wbar' + (wt ? '' : ' ref') + '"><span>' + esc(labels[k] || names[k] || k) + '</span><span class="tr"><span class="fl" style="width:' +
          (wt ? Math.max(4, wt * 100 / maxW) : 0).toFixed(0) + '%"></span></span><b>' + (wt ? Math.round(wt * 100) + '%' : '<span class="chip ghost">參考</span>') + '</b></div>';
      }).join('') + '</div><p class="small muted mt">各因子先換算成全市場百分位（0–100），再依權重加總成綜合分數；ETF 不列入排名。</p></div></div></section>';
  }

  function onClick(ev) {
    if (ev.target.closest('[data-act="more-hist"]')) {
      P.showN += 10;
      var y = window.scrollY;
      paint();
      window.scrollTo({top: y, left: 0, behavior: 'instant'});
    }
  }

  window.Pages.picks = {
    render: render,
    destroy: function () {
      P.alive = false;
      window.removeEventListener('resize', onResize);
      if (P.el) P.el.removeEventListener('click', onClick);
    }
  };
})();
