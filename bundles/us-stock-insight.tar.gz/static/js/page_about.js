/* 說明 (#/about) — 五大因子權重、美股夏令／冬令交易時間、盤前盤後規則、ADR 換算公式、指標白話辭典、資料來源與免責聲明。 */
(function () {
  'use strict';
  var A = {el: null, alive: false, unCm: null, meta: null, picks: null};
  var DEFAULT_W = {earn: 0.30, inst: 0.25, mom: 0.25, val: 0.15, vol: 0.05};
  var GLOSSARY = [
    ['🧾', 'EPS 與財報驚喜（Beat／Miss）', 'EPS 是每股盈餘。美股每季公布財報前，華爾街分析師會給出「共識預估 EPS」；實際 EPS 高於預估叫 Beat（優於預期），低於叫 Miss。驚喜率 =（實際 − 預估）÷ |預估|。',
      '連續多季 Beat 代表公司持續超越市場期待，常是股價動能的來源；但若 Beat 幅度縮小或財測保守，股價仍可能下跌。'],
    ['📆', '盤前 BMO／盤後 AMC', '美股財報多在開盤前（Before Market Open，BMO）或收盤後（After Market Close，AMC）公布。台灣時間來看，BMO 約在晚上 7～9 點、AMC 約在清晨 4～5 點。',
      '財報公布當下會先反映在盤前／盤後交易，流動性較低、價差較大，波動可能被放大。'],
    ['🏦', '華爾街評級與目標價', '投資銀行分析師對個股給出買進（Buy）、持有（Hold）、賣出（Sell）評級，並估算 12 個月目標價。目標價空間 =（平均目標價 − 現價）÷ 現價。',
      '多數分析師同時調升目標價時通常是正面訊號；但目標價常跟著股價調整，僅供參考。'],
    ['🏢', '機構持股比例', '共同基金、退休基金、避險基金等機構投資人合計持有的股數占流通股比例（來自每季 13F 申報）。',
      '機構持股高代表大型資金認同，但也可能在調節時造成賣壓；季度變化比絕對數字更值得觀察。'],
    ['🧮', '本益比 PE／預估本益比 Forward PE／PEG', 'PE = 股價 ÷ 過去四季 EPS；Forward PE = 股價 ÷ 未來 12 個月預估 EPS；PEG = PE ÷ EPS 成長率（%）。',
      '成長股 PE 通常較高，用 PEG 比較較公平；PEG 小於 1 常被視為成長相對便宜。'],
    ['📏', '均線（MA）與多頭排列', '過去 N 個交易日收盤價的平均。MA20 約一個月、MA60 約一季、MA240 約一年。短天期均線在上、長天期在下叫多頭排列。',
      '股價站上均線代表近期買方占優；多頭排列的股票較常漲多跌少，但乖離過大時容易拉回。'],
    ['🕯', 'K 線顏色（美股綠漲 vs 台股紅漲）', '美股慣例：收盤高於開盤畫綠色、低於開盤畫紅色；台灣慣例正好相反。本站預設美股慣例，可用右上角「🟢 美股綠漲／🔴 台股紅漲」一鍵切換。',
      '切換後 K 線、成交量、熱力圖與所有漲跌數字都會即時改色，不需要重新整理。'],
    ['🎢', 'KD／RSI／MACD', 'KD 與 RSI 把價格強弱換算成 0～100；MACD 用快慢兩條指數均線的差距判斷動能，柱狀體由負轉正代表動能轉強。',
      'RSI 70 以上為超買、30 以下為超賣；強勢股可能長時間維持高檔，需搭配趨勢判讀。'],
    ['🌡', 'ATR 平均真實波幅', '一天平均會波動多少美元。ATR 為股價 3% 代表平常一天上下 3% 很正常。', '美股沒有漲跌幅限制，設停損時可預留 1～2 倍 ATR，避免被正常波動洗出場。'],
    ['😨', 'VIX 恐慌指標', '由標普 500 選擇權價格推算的市場預期波動率，俗稱恐慌指數。本站以 VIX 相關 ETF 代表其方向。', 'VIX 低於 15 代表市場平靜；急升至 25～30 以上常伴隨股市大跌與避險情緒。'],
    ['🔬', '費城半導體指數（SOX）', '追蹤美國上市的 30 檔主要半導體公司（含台積電 ADR、輝達、博通、AMD 等）。', '與台股電子權值股連動高，常被視為隔天台股開盤的領先指標。'],
    ['🇹🇼', 'ADR 美國存託憑證', '外國公司在美國掛牌交易的憑證。例如 1 單位台積電 ADR（TSM）代表 5 股台積電普通股（2330）。', 'ADR 收盤換算回台幣後與台股收盤比較，即為 ADR 折溢價，常用來推估台股開盤方向。'],
    ['🛑', '停損、目標價與報酬風險比', '停損是「判斷錯誤就出場」的價位；目標價是技術面推估可能到達的價位。報酬風險比 =（目標 − 現價）÷（現價 − 停損）。',
      '報酬風險比 2 以上代表潛在報酬是潛在風險的 2 倍；本站數字僅供量化研究參考。'],
    ['💵', '殖利率與配息頻率', '殖利率 = 過去 12 個月現金股利 ÷ 股價。美股多為季配，部分 ETF 為月配。', '美國股利對非美國居民通常預扣 30% 稅，實際到手殖利率會較低。']
  ];

  function render(params, el) {
    A.el = el;
    A.alive = true;
    setTitle('說明');
    el.addEventListener('click', onClick);
    A.unCm = App.onColorMode(function () { if (A.alive) paint(); });
    A.meta = App.meta;
    paint();
    return Promise.all([getMeta().then(null, function () { return null; }), api('/api/picks').then(null, function () { return null; })]).then(function (r) {
      if (!A.alive) return;
      A.meta = r[0];
      A.picks = r[1];
      paint();
    });
  }
  function onClick(ev) {
    var t = ev.target;
    if (t.closest('[data-act="cm-us"]')) { App.setColorMode('us'); return; }
    if (t.closest('[data-act="cm-tw"]')) { App.setColorMode('tw'); return; }
    var b = t.closest('[data-act="gloss-all"]');
    if (!b) return;
    var open = !$$('.gloss-item', A.el).every(function (d) { return d.open; });
    $$('.gloss-item', A.el).forEach(function (d) { d.open = open; });
    b.textContent = open ? '⊟ 收合全部' : '⊞ 展開全部';
  }

  function sessionTable() {
    var rows = [
      ['盤前交易（Pre-market）', '16:00 ～ 21:30', '17:00 ～ 22:30', '04:00 ～ 09:30'],
      ['正規交易（Regular）', '21:30 ～ 隔日 04:00', '22:30 ～ 隔日 05:00', '09:30 ～ 16:00'],
      ['盤後交易（After-hours）', '04:00 ～ 08:00', '05:00 ～ 09:00', '16:00 ～ 20:00']
    ];
    return '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="l">時段</th><th class="l">🌞 夏令 EDT（台灣時間）</th><th class="l">❄️ 冬令 EST（台灣時間）</th><th class="l">美東時間 ET</th></tr></thead><tbody>' +
      rows.map(function (r) { return '<tr><td class="l"><b>' + r[0] + '</b></td><td class="l num">' + r[1] + '</td><td class="l num">' + r[2] + '</td><td class="l num">' + r[3] + '</td></tr>'; }).join('') +
      '</tbody></table></div>' +
      '<ul class="src-list small mt-s"><li>夏令時間：每年 3 月第二個週日起至 11 月第一個週日止；其餘為冬令時間，台灣時間整體晚 1 小時。</li>' +
      '<li>盤前盤後交易流動性低、買賣價差大，多數券商僅接受限價單；本站盤前盤後價格僅供參考。</li>' +
      '<li>美股休市日：元旦、馬丁路德金恩紀念日、總統日、耶穌受難日、陣亡將士紀念日、六月節、獨立紀念日、勞動節、感恩節、聖誕節。</li>' +
      '<li>美股無漲跌幅限制，但個股單日劇烈波動時可能觸發交易暫停（LULD）；大盤急跌 7%／13%／20% 會觸發市場熔斷。</li></ul>';
  }

  function paint() {
    if (!A.alive) return;
    var meta = A.meta || App.meta || {}, picks = A.picks;
    var m = (picks && picks.method) || {}, w = m.weights || DEFAULT_W, names = m.factor_labels || App.FACTOR_NAME || {}, st = meta.status || {}, cnt = meta.counts || {};
    var ses = meta.us_session || {}, mode = App.getColorMode();
    var weightsHtml = (App.FACTORS || []).map(function (f) {
      var wt = w[f[0]];
      return '<div class="wbar' + (wt ? '' : ' ref') + '" data-tip="' + esc(f[2]) + '"><span>' + esc(names[f[0]] || f[1]) + '</span><span class="tr"><span class="fl" style="width:' +
        (App.isNum(wt) ? Math.max(wt ? 4 : 0, wt * 100) : 0) + '%"></span></span><b>' + (App.isNum(wt) ? (wt ? Math.round(wt * 100) + '%' : '參考') : '—') + '</b></div>';
    }).join('');
    setHtml(A.el, '<div class="ph"><h1>📘 說明</h1><span class="sub">五大因子模型、美股交易時間、ADR 換算與新手指標白話辭典</span></div>' +
      '<div class="ux-grid">' +
      '<section class="card"><div class="card-h"><h2>🗽 關於美股戰情室</h2></div><p style="line-height:1.8;color:var(--text-2)">「美股戰情室」是個人量化研究用的美股分析工具，追蹤標普 500、那斯達克 100、費城半導體、台股 ADR 與重點成長股約 580 檔，以及 48 檔核心美股 ETF。' +
      '每個美股交易日依夏／冬令自動更新行情、財報 EPS、華爾街評級與機構持股，計算技術指標與五大因子分數，產生<a href="#/">今日推薦</a>、<a href="#/morning">盤前盤後戰情</a>、<a href="#/screener">選股器</a>、' +
      '<a href="#/industry">板塊與供應鏈</a>與<a href="#/etf">ETF 專區</a>，並提供個股 K 線圖與<b>🧠 一鍵技術分析</b>。</p>' +
      '<div class="subh">漲跌配色（目前：' + (mode === 'tw' ? '🔴 台股慣例紅漲綠跌' : '🟢 美股慣例綠漲紅跌') + '）</div>' +
      '<div class="color-demo"><span class="chip solid-bull">上漲／偏多</span><span class="chip solid-bear">下跌／偏空</span>' +
      '<span class="chip" style="background:#e0f2fe;color:#0369a1">支撐線 = 藍</span><span class="chip" style="background:#ffedd5;color:#c2410c">壓力線 = 橘</span>' +
      '<span class="chip fund">財報／華爾街標籤 = 紫</span></div>' +
      '<div class="row wrap mt-s"><button type="button" class="btn sm' + (mode === 'us' ? ' primary' : '') + '" data-act="cm-us">🟢 美股綠漲紅跌</button>' +
      '<button type="button" class="btn sm' + (mode === 'tw' ? ' primary' : '') + '" data-act="cm-tw">🔴 台股紅漲綠跌</button></div></section>' +
      (App.isStatic ? staticCard(meta) :
      '<section class="card"><div class="card-h"><h2>🕒 資料更新</h2></div><div class="kv-grid" style="grid-template-columns:minmax(0,1fr)">' +
      '<div><span>資料日期（美東）</span><span>' + esc(meta.data_date || '—') + '</span></div>' +
      '<div><span>最後更新</span><span>' + esc((meta.updated_at || '—').replace('T', ' ').slice(0, 19)) + '</span></div>' +
      '<div><span>目前時令</span><span>' + esc(ses.season || '—') + (ses.state_zh ? ' · ' + esc(ses.state_zh) : '') + '</span></div>' +
      '<div><span>自動更新排程</span><span>' + esc(meta.schedule || '—') + '</span></div>' +
      '<div><span>下次更新</span><span>' + esc((meta.next_update || '—').replace('T', ' ').slice(0, 16)) + '</span></div>' +
      '<div><span>收錄股票／ETF／可評分</span><span>' + fmtInt(cnt.stocks) + ' 檔／' + fmtInt(cnt.etfs) + ' 檔／' + fmtInt(cnt.eligible) + ' 檔</span></div>' +
      '<div><span>歷史資料天數</span><span>' + fmtInt(cnt.days) + ' 個交易日</span></div></div>' +
      ((st.errors || []).length ? '<details class="msgs"><summary>資料更新訊息（' + st.errors.length + '）</summary><ul>' +
        st.errors.slice(-20).map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></details>' : '') + '</section>') + '</div>' +
      '<section class="card mt"><div class="card-h"><h2>🧮 五大因子綜合分數怎麼算？</h2><span class="sp"></span><a class="btn xs ghost" href="#/picks">看回測績效 →</a></div><div class="ux-grid"><div>' +
      '<p style="line-height:1.8;color:var(--text-2)">' + esc(m.text || '結合季報 EPS 驚喜與營收年增、華爾街目標價空間與機構持股、技術面均線趨勢、估值品質及低波動穩定度，進行全市場百分位綜合排名。') + '</p>' +
      ((m.filters || []).length ? '<div class="subh">納入條件</div><ul class="risk-list">' + m.filters.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ul>' : '') +
      '</div><div><div class="subh" style="margin-top:0">因子權重</div><div class="wbars">' + weightsHtml + '</div>' +
      '<p class="small muted mt">每個因子先換算成「全市場百分位」：80 分代表贏過 80% 的股票，再依權重加總成 0–100 綜合分數。ETF 不參與個股評分。</p></div></div></section>' +
      '<section class="card mt"><div class="card-h"><h2>🕰️ 美股交易時間對照表</h2><span class="sub">夏令 EDT 21:30–04:00 ／ 冬令 EST 22:30–05:00（台灣時間）</span></div>' + sessionTable() + '</section>' +
      '<section class="card mt"><div class="card-h"><h2>🇹🇼 ADR 折溢價換算公式</h2></div>' +
      '<div class="ux-grid"><div><p style="line-height:1.9;color:var(--text-2);margin:0">' +
      '<b>ADR 折合台股價（新台幣）</b> = ADR 收盤價（美元）× 美元兌台幣匯率 ÷ ADR 換股比例<br>' +
      '<b>折溢價（%）</b> =（ADR 折合台股價 − 台股收盤價）÷ 台股收盤價 × 100%</p>' +
      '<p class="small muted mt-s">例：TSM 收 $413.35、匯率 32.15、1 ADR = 5 股 → 折合 413.35 × 32.15 ÷ 5 ≈ NT$ 2,657.8。</p></div>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="l">ADR</th><th class="l">台股</th><th>換股比例</th></tr></thead><tbody>' +
      [['TSM', '2330 台積電', 5], ['UMC', '2303 聯電', 5], ['ASX', '3711 日月光投控', 2], ['CHT', '2412 中華電', 10]].map(function (r) {
        return '<tr><td class="l code">' + r[0] + '</td><td class="l">' + r[1] + '</td><td>1 : ' + r[2] + '</td></tr>';
      }).join('') + '</tbody></table></div></div>' +
      '<p class="small muted mt-s">ADR 與台股有時差、匯率與交易成本差異，折溢價僅能作為隔日台股開盤方向的參考。</p></section>' +
      '<section class="card mt"><div class="card-h"><h2>🔗 資料來源</h2></div><ul class="src-list">' +
      '<li>美股與指數日 K 行情、即時報價：鉅亨網公開行情資料</li>' +
      '<li>美股篩選快照、財報 EPS 與驚喜率、季營收與利潤率、華爾街評級與目標價、機構持股、配息、盤前盤後交易、財報行事曆：Nasdaq 公開資料</li>' +
      '<li>新聞：鉅亨網美股與國際總經新聞、Google 新聞 RSS（點擊後開啟原網站）</li>' +
      '<li>K 線圖：<a href="https://www.tradingview.com/lightweight-charts/" target="_blank" rel="noopener noreferrer">TradingView Lightweight Charts™</a>（Apache 2.0 授權）</li></ul></section>' +
      '<section class="card mt"><div class="card-h"><h2>📖 新手指標白話辭典</h2><span class="sub">點標題展開說明</span><span class="sp"></span><button type="button" class="btn xs" data-act="gloss-all">⊞ 展開全部</button></div>' +
      '<div class="gloss">' + GLOSSARY.map(function (g) {
        return '<details class="gloss-item"><summary><h3 style="display:inline-flex">' + g[0] + ' ' + esc(g[1]) + '</h3></summary><p style="margin-top:6px">' + esc(g[2]) +
          '</p><div class="how">👉 怎麼看：' + esc(g[3]) + '</div></details>';
      }).join('') + '</div></section>' +
      '<section class="card mt" style="background:#fffbeb;border-color:#fcd34d"><div class="card-h"><h2>⚖️ 投資風險與法律免責聲明</h2><span class="sp"></span>' +
      '<button type="button" class="btn xs" data-open-disclaimer="1">查看完整條款</button></div>' +
      '<p style="line-height:1.8;color:#78350f;margin:0">' + esc(App.disclaimer()) + ' 本站暨開發者並非證券投資顧問事業，所有資料可能因來源延遲、格式變動或程式解析誤差而不完整；過去之回測績效不代表未來表現，投資人於下單前應自行查證並獨立評估風險。</p></section>');
  }

  function staticCard(meta) {
    var t = App.staticInfo || {};
    return '<section class="card"><div class="card-h"><h2>🕒 資料快照資訊</h2></div><div class="kv-grid" style="grid-template-columns:minmax(0,1fr)">' +
      '<div><span>版本</span><span>v' + esc(t.version || meta.version || '—') + '</span></div>' +
      '<div><span>資料日期（美東）</span><span>' + esc(meta.data_date || t.data_date || '—') + '</span></div>' +
      '<div><span>打包時間</span><span>' + esc((t.built_at || '—').replace('T', ' ').slice(0, 16)) + '</span></div>' +
      '<div><span>完整 K 線與技術分析</span><span>' + fmtInt(t.stocks_full) + ' 檔（熱門股、七巨頭＋今日推薦）</span></div></div>' +
      '<p class="small muted mt-s">選股器、板塊表現、ETF 專區與供應鏈涵蓋全部追蹤標的；其他個股提供重點數據模式。</p></section>';
  }

  window.Pages.about = {
    render: render,
    destroy: function () {
      A.alive = false;
      if (A.unCm) A.unCm();
      A.unCm = null;
      if (A.el) A.el.removeEventListener('click', onClick);
    }
  };
})();
