/* 盤前盤後 (#/morning) — 美股夏／冬令交易時鐘、戰情結論、盤前／盤後異動排行、近 7 日財報行事曆、
 * 台股 ADR 折溢價換算、事件雷達（受影響板塊／個股）、今日推薦股開盤重判。資料：/api/morning（SPEC §4.6）。 */
(function () {
  'use strict';
  var S = {el: null, alive: false, data: null, refreshing: false, extTab: 'all', cat: 'all', evId: '', earnDay: 'all', clockTimer: 0, offMeta: null};

  var EXT_TABS = [['all', '全部'], ['盤前', '🌅 盤前'], ['盤後', '🌙 盤後']];
  var STATE_LBL = {open: '正規盤交易中', pre: '盤前交易中', post: '盤後交易中', closed: '已收盤'};
  var STATE_ICO = {open: '🟢', pre: '🌅', post: '🌙', closed: '💤'};
  var WD = '日一二三四五六';

  function applyQuery(q) {
    q = q || {};
    if (q.ext && EXT_TABS.some(function (t) { return t[0] === q.ext; })) S.extTab = q.ext;
    if (q.cat) S.cat = q.cat;
    if (q.ev) S.evId = q.ev;
  }
  function syncUrl() {
    replaceHash('#/morning' + buildQuery({ext: S.extTab !== 'all' ? S.extTab : '', cat: S.cat !== 'all' ? S.cat : '', ev: S.evId || ''}));
  }
  function head(sub, btn) {
    return '<div class="ph"><h1>🌅 盤前盤後戰情</h1><span class="sub">' + (sub || '美股夏／冬令交易時段、盤前盤後異動、財報行事曆、台股 ADR 連動與事件雷達') +
      '</span>' + (btn ? '<span class="sp"></span>' + btn : '') + '</div>';
  }

  function render(params, el) {
    S.el = el;
    S.alive = true;
    S.refreshing = false;
    applyQuery((params && params.query) || {});
    setTitle('盤前盤後');
    el.innerHTML = head() + skeleton(2, 180) + '<div class="mt">' + skeleton(3, 220) + '</div>';
    el.addEventListener('click', onClick);
    el.addEventListener('keydown', onKey);
    S.offMeta = onMeta(function () { paintClock(); });
    clearInterval(S.clockTimer);
    S.clockTimer = setInterval(paintClock, 30000);
    return load(false);
  }

  function load(force) {
    var p = force
      ? api('/api/morning/refresh', {method: 'POST', cache: false}).then(function (r) { return (r && r.morning) || r; })
      : api('/api/morning');
    return p.then(function (d) {
      if (!S.alive) return;
      S.data = d || {};
      if (isEmptyPayload(S.data)) { S.el.innerHTML = head() + buildingHtml(S.data.message); return; }
      ensureEvent();
      paint();
    });
  }

  function paint() {
    var d = S.data || {};
    var gen = d.generated_at ? String(d.generated_at).replace('T', ' ').slice(0, 16) : '';
    var btn = App.isStatic ? '' : '<button type="button" class="btn sm primary" data-act="refresh-morning"' + (S.refreshing ? ' disabled' : '') + '>' +
      (S.refreshing ? '<span class="spin"></span> 更新中…' : '↻ 立即更新盤前盤後') + '</button>';
    S.el.innerHTML = head((gen ? '產生於 ' + esc(gen) + '（台灣時間）· ' : '') + '美股收盤基準 ' + esc(d.data_date || '—'), btn) +
      '<div class="ux-grid">' +
        '<section class="card">' + decisionHtml(d) + '</section>' +
        '<section class="card" id="pmClock"></section>' +
      '</div>' +
      '<section class="card mt" id="pmRejudge">' + rejudgeHtml(d) + '</section>' +
      '<section class="card mt" id="pmExt">' + extHtml(d) + '</section>' +
      '<section class="card mt" id="pmEarn">' + earnHtml(d) + '</section>' +
      '<section class="card mt" id="pmAdr">' + adrHtml(d) + '</section>' +
      '<section class="mt" id="pmEvSec">' + eventsHtml(d) + '</section>' +
      disclaimerHtml('盤前盤後異動、財報預估、ADR 換算與事件影響映射皆由程式依公開資料自動整理；延長交易時段流動性較低、價格波動大，開盤後仍須以實際量價為準。');
    paintClock();
  }

  // ------------------------------------------------------------------ 戰情結論
  function decisionHtml(d) {
    var dec = d.decision || {}, est = dec.spx_est || {};
    var cls = dec.regime_cls === 'bull' ? 'bull' : (dec.regime_cls === 'bear' ? 'bear' : 'info');
    var kp = [['標普 500', est.spx_pct], ['那斯達克', est.ixic_pct], ['道瓊工業', est.dji_pct], ['費城半導體', est.sox_pct]];
    return '<div class="card-h"><h2>🧭 今日戰情結論</h2></div>' +
      '<div class="row wrap" style="margin-bottom:10px"><span class="chip lg ' + cls + '">' + esc(dec.regime || '中性震盪') + '</span>' +
      (dec.allocation ? '<span class="chip info">' + esc(dec.allocation) + '</span>' : '') + '</div>' +
      (dec.summary_advice ? '<p class="pm-advice">' + esc(dec.summary_advice) + '</p>' : '<p class="pm-advice muted">尚無戰情摘要。</p>') +
      '<div class="ux-grid xs mt-s">' + kp.map(function (k) {
        return '<div class="pm-kpi"><div class="kpi-l">' + k[0] + '</div><div class="kpi-v num ' + clsUpDown(k[1]) + '">' + arrow(k[1]) + ' ' + fmtPct(k[1]) + '</div></div>';
      }).join('') + '</div>';
  }

  // ------------------------------------------------------------------ 夏／冬令交易時鐘
  function etNow() {
    try {
      var parts = new Intl.DateTimeFormat('en-US', {timeZone: 'America/New_York', hour12: false, weekday: 'short', year: 'numeric',
        month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', timeZoneName: 'short'}).formatToParts(new Date());
      var o = {};
      parts.forEach(function (p) { o[p.type] = p.value; });
      var h = (+o.hour) % 24, m = +o.minute, wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(o.weekday);
      if (!isNum(h) || !isNum(m) || wd < 0) return null;
      var mins = h * 60 + m, st;
      if (wd === 0 || wd === 6) st = 'closed';
      else if (mins >= 240 && mins < 570) st = 'pre';
      else if (mins >= 570 && mins < 960) st = 'open';
      else if (mins >= 960 && mins < 1200) st = 'post';
      else st = 'closed';
      var tz = String(o.timeZoneName || '');
      return {state: st, is_dst: tz.indexOf('DT') >= 0 || tz === 'GMT-4', et: o.year + '-' + o.month + '-' + o.day + ' ' + o.hour.replace(/^24/, '00') + ':' + o.minute + ' ET'};
    } catch (e) { return null; }
  }
  function twNow() {
    try {
      var d = new Date(Date.now() + 8 * 3600000);
      return d.toISOString().slice(0, 10) + '（' + WD.charAt(d.getUTCDay()) + '）' + d.toISOString().slice(11, 16);
    } catch (e) { return ''; }
  }
  function schedBox(title, range, rows, on) {
    return '<div class="pm-sched-box' + (on ? ' active' : '') + '"><div class="hd"><b>' + title + '</b><span>' + range + '</span>' +
      (on ? '<em class="chip ok">目前適用</em>' : '') + '</div><ul>' + rows.map(function (r) {
        return '<li><span>' + r[0] + '</span><b class="num">' + esc(r[1]) + '</b></li>';
      }).join('') + '</ul></div>';
  }
  function paintClock() {
    var box = S.alive && document.getElementById('pmClock');
    if (!box) return;
    var ses = (S.data && S.data.us_session) || (App.meta && App.meta.us_session) || {};
    var live = etNow();
    var state = live ? live.state : (STATE_LBL[ses.state] ? ses.state : 'closed');
    var isDst = live ? live.is_dst : !!ses.is_dst;
    var season = isDst ? '夏令時間 (EDT)' : '冬令時間 (EST)';
    var stLbl = live ? STATE_LBL[state] : (ses.state_zh || STATE_LBL[state]);
    var sum = isDst ? [['盤前交易', '16:00 ～ 21:30'], ['正規交易', '21:30 ～ 隔日 04:00'], ['盤後交易', '04:00 ～ 08:00']]
      : [['盤前交易', '17:00 ～ 22:30'], ['正規交易', '22:30 ～ 隔日 05:00'], ['盤後交易', '05:00 ～ 09:00']];
    if (!live && ses.pre_tw) sum = [['盤前交易', ses.pre_tw], ['正規交易', ses.regular_tw || '—'], ['盤後交易', ses.post_tw || '—']];
    var html = '<div class="card-h"><h2>🕒 美股交易時鐘（台灣時間）</h2></div>' +
      '<div class="ux-clock"><span class="st ' + state + '"><span class="dot"></span>' + STATE_ICO[state] + ' ' + esc(stLbl) + '</span>' +
      '<span class="chip info">' + (isDst ? '🌞 ' : '❄️ ') + esc(season) + '</span>' +
      '<span class="small muted num">台灣 ' + esc(twNow()) + (live ? ' · 美東 ' + esc(live.et.slice(11)) : (ses.et_time ? ' · 美東 ' + esc(ses.et_time) : '')) + '</span></div>' +
      '<div class="ux-grid sm mt-s">' +
        schedBox('🌞 夏令 EDT', '3 月第 2 個週日 ～ 11 月第 1 個週日', isDst ? sum : [['盤前交易', '16:00 ～ 21:30'], ['正規交易', '21:30 ～ 隔日 04:00'], ['盤後交易', '04:00 ～ 08:00']], isDst) +
        schedBox('❄️ 冬令 EST', '11 月第 1 個週日 ～ 隔年 3 月第 2 個週日', !isDst ? sum : [['盤前交易', '17:00 ～ 22:30'], ['正規交易', '22:30 ～ 隔日 05:00'], ['盤後交易', '05:00 ～ 09:00']], !isDst) +
      '</div>' +
      '<div class="small muted mt-s">💡 交易狀態依美東時間即時推算，未計入美股休市日與提前收盤；美股無漲跌幅限制，延長交易時段流動性較低。</div>';
    setHtml(box, html);
  }

  // ------------------------------------------------------------------ 今日推薦開盤重判
  function rejudgeHtml(d) {
    var list = d.rejudged_picks || [];
    var h = '<div class="card-h"><h2>🎯 今日推薦股開盤重判</h2><span class="sub">結合收盤量化分數與盤前盤後異動，重新研判開盤操作</span>' +
      '<span class="sp"></span><a class="btn xs ghost" href="#/">看完整推薦 →</a></div>';
    if (!list.length) return h + '<div class="empty">目前沒有需要重判的推薦股。</div>';
    return h + '<div class="ux-grid">' + list.map(function (it) {
      var href = '#/stock/' + encodeURIComponent(it.code);
      var cls = it.action_cls === 'bull' ? 'bull' : (it.action_cls === 'bear' ? 'bear' : (it.action_cls === 'warn' ? 'warn' : 'info'));
      return '<article class="pick" data-href="' + esc(href) + '" style="cursor:pointer">' +
        '<div class="pick-hd"><div class="pick-id"><a class="pick-name" href="' + esc(href) + '">' + esc(it.name || it.code) + ' <span class="code">' + esc(it.code) + '</span></a>' +
        '<div class="pick-meta"><span class="chip ' + cls + '">' + esc(it.action || '觀察') + '</span></div></div>' + scoreRing(it.score, 46) + '</div>' +
        '<div class="pick-px"><span class="px num ' + clsUpDown(it.pct) + '">' + fmtUsd(it.close) + '</span>' +
        '<span class="chg ' + clsUpDown(it.pct) + '">' + arrow(it.pct) + ' ' + fmtPct(it.pct) + '</span><span class="sp"></span>' +
        (isNum(it.ext_pct) ? '<span class="small">延長盤 <b class="num ' + clsUpDown(it.ext_pct) + '">' + fmtPct(it.ext_pct) + '</b></span>' : '') + '</div>' +
        (it.reason ? '<div class="act-plan"><b>📋 </b>' + esc(it.reason) + '</div>' : '') +
        '<div class="pick-ft"><span class="sp"></span>' + starBtn(it.code) + '</div></article>';
    }).join('') + '</div>';
  }

  // ------------------------------------------------------------------ 盤前／盤後異動排行
  function extHtml(d) {
    var all = d.extended_movers || [];
    var cnt = {all: all.length};
    all.forEach(function (m) { cnt[m.ext_type] = (cnt[m.ext_type] || 0) + 1; });
    var list = (S.extTab === 'all' ? all : all.filter(function (m) { return m.ext_type === S.extTab; })).slice()
      .sort(function (a, b) { return Math.abs(b.ext_pct || 0) - Math.abs(a.ext_pct || 0); });
    var h = '<div class="card-h"><h2>⚡ 盤前／盤後異動排行</h2><span class="sub">依延長交易時段漲跌幅絕對值排序</span><span class="sp"></span>' +
      '<div class="seg">' + EXT_TABS.map(function (t) {
        return '<button type="button" class="' + (S.extTab === t[0] ? 'on' : '') + '" data-ext="' + esc(t[0]) + '">' + t[1] + ' <span class="num muted">' + (cnt[t[0]] || 0) + '</span></button>';
      }).join('') + '</div></div>';
    if (!list.length) return h + '<div class="empty">目前沒有' + (S.extTab === 'all' ? '盤前／盤後' : esc(S.extTab)) + '異動資料。</div>';
    return h + '<div class="tbl-wrap"><table class="tbl dense"><thead><tr><th class="c" style="width:30px"></th><th class="l">代號／名稱</th>' +
      '<th class="c">時段</th><th>正規收盤</th><th>正規漲跌</th><th>延長盤價</th><th>延長漲跌</th><th>延長盤量</th></tr></thead><tbody>' +
      list.map(function (m) {
        var href = '#/stock/' + encodeURIComponent(m.code);
        return '<tr data-href="' + esc(href) + '"><td class="c">' + starBtn(m.code, 'icon') + '</td>' +
          '<td class="l"><a class="nm" href="' + esc(href) + '">' + esc(m.code) + '</a> <span class="small muted">' + esc(m.name || '') + '</span></td>' +
          '<td class="c"><span class="chip ' + (m.ext_type === '盤前' ? 'warn' : 'ghost') + '">' + esc(m.ext_type || '—') + '</span></td>' +
          '<td>' + fmtUsd(m.close) + '</td><td class="' + clsUpDown(m.reg_pct) + '">' + fmtPct(m.reg_pct) + '</td>' +
          '<td>' + fmtUsd(m.ext_price) + '</td><td class="' + clsUpDown(m.ext_pct) + '"><b>' + arrow(m.ext_pct) + ' ' + fmtPct(m.ext_pct) + '</b></td>' +
          '<td>' + fmtShares(m.vol) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  // ------------------------------------------------------------------ 近 7 日財報行事曆
  function sessChip(t) {
    t = String(t || '');
    if (/AMC|盤後/.test(t)) return '<span class="chip ghost" data-tip="收盤後公布（After Market Close）">🌙 盤後 AMC</span>';
    if (/BMO|盤前/.test(t)) return '<span class="chip warn" data-tip="開盤前公布（Before Market Open）">🌅 盤前 BMO</span>';
    return '<span class="chip ghost">' + esc(t || '時間未定') + '</span>';
  }
  function dayLbl(s) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s || '')) return esc(s || '—');
    return fmtMD(s) + '（' + WD.charAt(new Date(s + 'T00:00:00Z').getUTCDay()) + '）';
  }
  function earnHtml(d) {
    var all = (d.earnings_calendar || []).slice().sort(function (a, b) {
      return (a.date || '').localeCompare(b.date || '') || (b.mcap || 0) - (a.mcap || 0);
    });
    var days = [];
    all.forEach(function (e) { if (days.indexOf(e.date) < 0) days.push(e.date); });
    if (S.earnDay !== 'all' && days.indexOf(S.earnDay) < 0) S.earnDay = 'all';
    var list = S.earnDay === 'all' ? all : all.filter(function (e) { return e.date === S.earnDay; });
    var h = '<div class="card-h"><h2>📅 近 7 日財報行事曆</h2><span class="sub">美東日期；EPS 為華爾街共識預估（美元）</span></div>';
    if (!all.length) return h + '<div class="empty">近 7 日沒有追蹤中的財報公布。</div>';
    h += '<div class="presets" style="margin-bottom:10px"><button type="button" class="preset' + (S.earnDay === 'all' ? ' on' : '') + '" data-eday="all">全部 <span class="num">(' + all.length + ')</span></button>' +
      days.map(function (dd) {
        var n = all.filter(function (e) { return e.date === dd; }).length;
        return '<button type="button" class="preset' + (S.earnDay === dd ? ' on' : '') + '" data-eday="' + esc(dd) + '">' + dayLbl(dd) + ' <span class="num">(' + n + ')</span></button>';
      }).join('') + '</div>';
    return h + '<div class="tbl-wrap"><table class="tbl dense"><thead><tr><th class="l">日期</th><th class="c">時段</th><th class="l">代號／名稱</th>' +
      '<th class="l">財報季度</th><th>EPS 預估</th><th>去年同期 EPS</th><th>預估年增</th><th>市值</th></tr></thead><tbody>' +
      list.map(function (e) {
        var yoy = isNum(e.eps_est) && isNum(e.last_yr_eps) && e.last_yr_eps > 0 ? (e.eps_est / e.last_yr_eps - 1) * 100 : null;
        var href = '#/stock/' + encodeURIComponent(e.code || '');
        var link = e.in_universe !== false && e.code;
        return '<tr' + (link ? ' data-href="' + esc(href) + '"' : '') + '><td class="l">' + dayLbl(e.date) + '</td><td class="c">' + sessChip(e.time) + '</td>' +
          '<td class="l">' + (link ? '<a class="nm" href="' + esc(href) + '">' + esc(e.code) + '</a>' : '<b>' + esc(e.code || '—') + '</b>') +
          ' <span class="small muted">' + esc(e.name || '') + '</span></td><td class="l">' + esc(e.quarter || '—') + '</td>' +
          '<td>' + fmtUsd(e.eps_est, 2) + '</td><td>' + fmtUsd(e.last_yr_eps, 2) + '</td><td class="' + clsUpDown(yoy) + '">' + fmtPct(yoy, 1) + '</td>' +
          '<td>' + fmtUsdYi(e.mcap) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  // ------------------------------------------------------------------ 🇹🇼 ADR 折溢價換算
  function adrHtml(d) {
    var list = d.adr_bridge || [];
    var h = '<div class="card-h"><h2>🇹🇼 台股 ADR 折溢價換算</h2><span class="sub">ADR 收盤 × 匯率 ÷ 換算比例 = 每股普通股折合新台幣</span></div>';
    if (!list.length) return h + '<div class="empty">暫無 ADR 換算資料。</div>';
    var hasTw = list.some(function (a) { return isNum(a.tw_close); });
    return h + '<div class="tbl-wrap"><table class="tbl dense"><thead><tr><th class="l">ADR</th><th>ADR 收盤</th><th>ADR 漲跌</th><th>換算比例</th>' +
      '<th>美元／台幣</th><th>折合台幣</th>' + (hasTw ? '<th>台股收盤</th><th>折溢價</th>' : '') + '<th class="l">對應台股</th></tr></thead><tbody>' +
      list.map(function (a) {
        var href = '#/stock/' + encodeURIComponent(a.code);
        var prem = isNum(a.premium_pct) ? a.premium_pct : (isNum(a.implied_twd) && isNum(a.tw_close) && a.tw_close > 0 ? (a.implied_twd / a.tw_close - 1) * 100 : null);
        return '<tr data-href="' + esc(href) + '"' + (a.note ? ' data-tip="' + esc(a.note) + '"' : '') + '>' +
          '<td class="l"><a class="nm" href="' + esc(href) + '">' + esc(a.code) + '</a> <span class="small muted">' + esc(a.name || '') + '</span></td>' +
          '<td>' + fmtUsd(a.adr_close) + '</td><td class="' + clsUpDown(a.adr_pct) + '">' + fmtPct(a.adr_pct) + '</td>' +
          '<td>' + (isNum(a.ratio) ? '1 : ' + fmtNum(a.ratio, a.ratio % 1 ? 2 : 0) : '—') + '</td><td>' + fmtNum(a.usdtwd, 3) + '</td>' +
          '<td><b>' + (isNum(a.implied_twd) ? 'NT$ ' + fmtNum(a.implied_twd, 1) : '—') + '</b></td>' +
          (hasTw ? '<td>' + (isNum(a.tw_close) ? 'NT$ ' + fmtNum(a.tw_close, a.tw_close < 100 ? 2 : 1) : '—') + '</td><td class="' + clsUpDown(prem) + '">' + fmtPct(prem) + '</td>' : '') +
          '<td class="l">' + (a.tw_code ? '<a href="' + esc(twStockUrl(a.tw_code)) + '" target="_blank" rel="noopener" data-tip="在台股戰情室開啟">' +
            esc(a.tw_code) + ' ' + esc(a.tw_name || '') + ' ↗</a>' : '—') + '</td></tr>';
      }).join('') + '</tbody></table></div>' +
      '<div class="small muted mt-s">💡 折溢價 = ADR 折合台幣 ÷ 台股收盤 − 1；ADR 與台股交易時段不同，僅供開盤前參考。點台股代號可在台股戰情室查看個股。</div>';
  }

  // ------------------------------------------------------------------ 🌍 事件雷達
  function dirOf(x) { return x.dir || x.direction || ''; }
  function isBen(x) { var v = dirOf(x); return v === 'beneficiary' || v === 'bull' || v === 'up'; }
  function filteredEvents() {
    var evs = (S.data && S.data.events) || [];
    return S.cat === 'all' ? evs : evs.filter(function (e) { return e.category === S.cat; });
  }
  function ensureEvent() {
    var evs = (S.data && S.data.events) || [];
    if (S.cat !== 'all' && !evs.some(function (e) { return e.category === S.cat; })) S.cat = 'all';
    var list = filteredEvents();
    if (!list.length) { S.evId = ''; return; }
    if (!S.evId || !list.some(function (e) { return e.id === S.evId; })) S.evId = list[0].id;
  }
  function polChip(e) {
    var c = e.polarity === 'bull' ? 'bull' : (e.polarity === 'bear' ? 'bear' : 'info');
    return '<span class="chip ' + c + '">' + esc(e.polarity_zh || (c === 'bull' ? '偏多' : (c === 'bear' ? '偏空' : '中性'))) + '</span>';
  }
  function eventsHtml(d) {
    var evs = d.events || [], cats = [], seen = {}, cnt = {};
    evs.forEach(function (e) {
      cnt[e.category] = (cnt[e.category] || 0) + 1;
      if (!seen[e.category]) { seen[e.category] = 1; cats.push([e.category, e.category_label || e.category]); }
    });
    var h = '<div class="sec-title"><h2>🌍 事件雷達</h2><span class="sub">點選事件，查看受影響的板塊、供應鏈與個股</span></div>';
    if (!evs.length) return h + '<div class="card empty"><div class="big">📡</div><h3>目前沒有重大事件</h3><p>有新的總經、科技巨頭或地緣事件時會自動出現在這裡。</p></div>';
    var bar = cats.length > 1 ? '<div class="presets" style="margin-bottom:12px"><button type="button" class="preset' + (S.cat === 'all' ? ' on' : '') +
      '" data-evcat="all">全部 <span class="num">(' + evs.length + ')</span></button>' + cats.map(function (c) {
        return '<button type="button" class="preset' + (S.cat === c[0] ? ' on' : '') + '" data-evcat="' + esc(c[0]) + '">' + esc(c[1]) + ' <span class="num">(' + cnt[c[0]] + ')</span></button>';
      }).join('') + '</div>' : '';
    var list = filteredEvents(), cur = list.filter(function (e) { return e.id === S.evId; })[0] || list[0];
    return h + bar + '<div class="ev-layout"><div class="ev-list" id="pmEvList">' + list.map(function (e) { return evCard(e, cur && e.id === cur.id); }).join('') +
      '</div><div class="card ev-detail" id="pmEvDetail">' + evDetail(cur) + '</div></div>';
  }
  function evCard(e, on) {
    var st = e.affected_stocks || [], ben = st.filter(isBen).length, hw = st.length - ben;
    var secs = (e.affected_sectors || []).slice(0, 3).map(function (s) { return s.name; }).join('、');
    return '<article class="ev-card' + (on ? ' on' : '') + '" data-ev="' + esc(e.id) + '" tabindex="0" role="button" aria-pressed="' + (on ? 'true' : 'false') + '">' +
      '<div class="ev-meta">' + (e.category_label ? '<span class="chip">' + esc(e.category_label) + '</span>' : '') + polChip(e) +
      '<span class="sp"></span><span class="small muted">' + esc(e.source || '') + (e.time ? ' · ' + esc(relTime(e.time)) : '') + '</span></div>' +
      '<h3 class="ev-title">' + esc(e.title || '') + '</h3>' +
      '<div class="ev-foot"><span class="small muted">牽動：<b>' + esc(secs || '—') + '</b></span><span class="sp"></span>' +
      (ben ? '<span class="small up">▲ 受惠 ' + ben + ' 檔</span>' : '') + (hw ? '<span class="small down">▼ 承壓 ' + hw + ' 檔</span>' : '') +
      '<span class="ev-arrow">查看影響 →</span></div></article>';
  }
  function evDetail(e) {
    if (!e) return '<div class="empty">請點選左側事件</div>';
    var secs = e.affected_sectors || [], stks = e.affected_stocks || [];
    var secHtml = secs.length ? '<div class="subh">🏭 受影響板塊／供應鏈（' + secs.length + '）</div><div class="ev-secs">' + secs.map(function (s) {
      var b = isBen(s);
      return '<div class="ev-sec-item ' + (b ? 'ben' : 'hw') + '"><div class="row wrap"><span class="chip ' + (b ? 'bull' : 'bear') + '">' + (b ? '📈 受惠' : '📉 承壓') + '</span>' +
        '<b>' + esc(s.name || '') + '</b><span class="sp"></span>' +
        (s.chain_id ? '<a class="btn xs" href="#/industry/' + encodeURIComponent(s.chain_id) + '">🔗 供應鏈圖譜</a>' : '') + '</div>' +
        (s.reason ? '<div class="small muted mt-xs">' + esc(s.reason) + '</div>' : '') + '</div>';
    }).join('') + '</div>' : '';
    var stkHtml = stks.length ? '<div class="subh">📊 受影響個股（' + stks.length + '）</div><div class="tbl-wrap"><table class="tbl dense"><thead><tr>' +
      '<th class="c" style="width:30px"></th><th class="l">代號／名稱</th><th class="c">影響</th><th class="l">原因</th><th>漲跌</th></tr></thead><tbody>' +
      stks.slice().sort(function (a, b) { return (isBen(b) ? 1 : 0) - (isBen(a) ? 1 : 0); }).map(function (s) {
        var href = '#/stock/' + encodeURIComponent(s.code), b = isBen(s);
        return '<tr data-href="' + esc(href) + '"><td class="c">' + starBtn(s.code, 'icon') + '</td><td class="l"><a class="nm" href="' + esc(href) + '">' + esc(s.code) +
          '</a> <span class="small muted">' + esc(s.name || '') + '</span></td><td class="c"><span class="small ' + (b ? 'up' : 'down') + '">' + (b ? '▲ 受惠' : '▼ 承壓') + '</span></td>' +
          '<td class="l wrap"><span class="small">' + esc(s.reason || '—') + '</span></td><td class="' + clsUpDown(s.pct) + '">' + fmtPct(s.pct) + '</td></tr>';
      }).join('') + '</tbody></table></div>' : '';
    return '<div class="ev-det-hd"><div class="row wrap">' + (e.category_label ? '<span class="chip">' + esc(e.category_label) + '</span>' : '') + polChip(e) +
      '<span class="sp"></span>' + (/^https?:\/\//.test(e.link || '') ? '<a class="btn xs" href="' + esc(e.link) + '" target="_blank" rel="noopener noreferrer">📰 新聞原文 ↗</a>' : '') + '</div>' +
      '<h3 class="ev-det-title">' + esc(e.title || '') + '</h3>' +
      '<div class="small muted">' + esc(e.source || '') + (e.time ? ' · ' + esc(String(e.time).replace('T', ' ').slice(0, 16)) : '') + '</div></div>' +
      (e.explain ? '<div class="ev-why"><b>🧠 影響解讀：</b>' + esc(e.explain) + '</div>' : '') + secHtml + stkHtml +
      (!secs.length && !stks.length ? '<div class="small muted">此事件尚未對應到特定板塊或個股。</div>' : '');
  }
  function selectEvent(card) {
    S.evId = card.getAttribute('data-ev');
    syncUrl();
    $$('#pmEvList .ev-card', S.el).forEach(function (c) {
      var on = c.getAttribute('data-ev') === S.evId;
      c.classList.toggle('on', on);
      c.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    var cur = filteredEvents().filter(function (e) { return e.id === S.evId; })[0];
    var det = document.getElementById('pmEvDetail');
    if (det && cur) {
      setHtml(det, evDetail(cur));
      if (window.innerWidth <= 960) det.scrollIntoView({behavior: 'smooth', block: 'nearest'});
    }
  }

  // ------------------------------------------------------------------ events
  function onKey(ev) {
    if (ev.key !== 'Enter' && ev.key !== ' ') return;
    var card = ev.target.closest && ev.target.closest('[data-ev]');
    if (card && ev.target === card) { ev.preventDefault(); selectEvent(card); }
  }
  function onClick(ev) {
    var t = ev.target, x;
    if (t.closest('[data-act="refresh-morning"]')) {
      if (S.refreshing || App.isStatic) return;
      S.refreshing = true;
      paint();
      load(true).then(function () {
        S.refreshing = false;
        if (S.alive && S.data && !isEmptyPayload(S.data)) { paint(); toast('已更新盤前盤後戰情', 'ok'); }
      }, function (e) {
        S.refreshing = false;
        if (S.alive) { paint(); toast((e && e.message) || '更新失敗', 'err'); }
      });
      return;
    }
    if ((x = t.closest('[data-ext]'))) {
      S.extTab = x.getAttribute('data-ext');
      syncUrl();
      setHtml(document.getElementById('pmExt'), extHtml(S.data || {}));
      return;
    }
    if ((x = t.closest('[data-eday]'))) {
      S.earnDay = x.getAttribute('data-eday');
      setHtml(document.getElementById('pmEarn'), earnHtml(S.data || {}));
      return;
    }
    if ((x = t.closest('[data-evcat]'))) {
      S.cat = x.getAttribute('data-evcat');
      S.evId = '';
      ensureEvent();
      syncUrl();
      setHtml(document.getElementById('pmEvSec'), eventsHtml(S.data || {}));
      return;
    }
    if ((x = t.closest('[data-ev]')) && !t.closest('a,button')) selectEvent(x);
  }

  window.Pages.morning = {
    render: render,
    update: function (params) {
      if (!S.alive || !S.data || isEmptyPayload(S.data)) return false;
      applyQuery((params && params.query) || {});
      ensureEvent();
      paint();
      return true;
    },
    refresh: function () {
      if (!S.alive) return false;
      load(false).then(null, function (e) { if (S.alive) S.el.innerHTML = head() + errorHtml(e && e.message); });
      return true;
    },
    destroy: function () {
      S.alive = false;
      clearInterval(S.clockTimer);
      S.clockTimer = 0;
      if (S.offMeta) { S.offMeta(); S.offMeta = null; }
      if (S.el) { S.el.removeEventListener('click', onClick); S.el.removeEventListener('keydown', onKey); }
    }
  };
})();
