"""Configuration constants for 美股戰情室 (US Stock War Room)."""
from __future__ import annotations

import os

VERSION = '1.0.0'   # initial version only; the live version lives in releases.json (release_mgr)
TOOL_NAME = '美股戰情室'
SERVICE_ID = 'us-stock'
PUBLIC_URL = 'https://okayell.github.io/us-stock-insight/'
MOUNT_PATH = '/us-stock-insight/'

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
DATA_DIR = os.environ.get('US_STOCK_DATA_DIR', os.path.join(ROOT_DIR, 'data'))
RAW_DIR = os.path.join(DATA_DIR, 'raw')
DB_PATH = os.path.join(DATA_DIR, 'stock.db')
STATE_PATH = os.path.join(DATA_DIR, 'state.json')
SNAP_DIR = os.path.join(DATA_DIR, 'snapshots')
LOCK_PATH = os.path.join(DATA_DIR, 'update.lock')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')

BACKEND_PORT = 8954
PUBLIC_PORT = 8955

# History to keep / backfill (trading days).
BACKFILL_DAYS = int(os.environ.get('US_STOCK_BACKFILL_DAYS', '300'))
LONG_HISTORY_YEARS = 6          # on-demand long history for the stock page (range=5y/max)
FETCH_WORKERS = 12              # cnyes daily-K parallelism
FUND_WORKERS = 12               # nasdaq fundamentals parallelism (per-request jobs)
FUND_TOP_N = 160                # fundamentals pre-cached for the top-N by mcap / turnover
FUND_TTL_DAYS = 5               # fundamentals cache lifetime
NEWS_TTL_SEC = 1800

# Polite per-host minimum interval between requests (seconds).
HOST_INTERVAL = {
    'ws.api.cnyes.com': 0.0,
    'api.cnyes.com': 0.3,
    'api.nasdaq.com': 0.12,
    'news.google.com': 0.5,
}
DEFAULT_INTERVAL = 0.3

# Daily update schedule (Asia/Taipei local time).  Slots are expressed in Taiwan time and are
# valid for both EDT and EST (the US regular session closes 04:00 TW in summer, 05:00 in winter).
MORNING_TIMES = ('21:35',)
INTRADAY_TIMES = ('01:30',)
UPDATE_TIMES = ('05:20', '08:10')
SCHEDULE_TEXT = ('美股交易日（依夏／冬令自動調整）：台灣時間 21:35 盤前戰情、01:30 盤中更新、'
                 '05:20 收盤行情與選股運算、08:10 盤後財報與 ADR 結算')
SCHEDULE_SLOTS = {
    'morning': list(MORNING_TIMES),
    'intraday': list(INTRADAY_TIMES),
    'update': list(UPDATE_TIMES),
    'notes': {
        '21:35': '美股盤前異動、當晚經濟數據與財報預告',
        '01:30': '美股盤中即時行情、四大指數與板塊強弱',
        '05:20': '美股正規盤收盤行情、技術指標與今日推薦 20 檔運算',
        '08:10': '美股盤後財報異動結算與台股 ADR 折溢價連動',
    },
}

# Major indices (cnyes symbols).
INDICES = {
    'spx': {'code': 'SPX', 'cnyes': 'GI:INX:INDEX', 'name': '標普 500 (S&P 500)'},
    'ixic': {'code': 'IXIC', 'cnyes': 'GI:IXIC:INDEX', 'name': '那斯達克 (Nasdaq)'},
    'dji': {'code': 'DJI', 'cnyes': 'GI:DJI:INDEX', 'name': '道瓊工業 (Dow 30)'},
    'sox': {'code': 'SOX', 'cnyes': 'GI:SOX:INDEX', 'name': '費城半導體 (SOX)'},
}
FX_CNYES = 'FX:USDTWD:FOREX'
MACRO_ETFS = {
    'vix': ('VIXY', 'VIX 恐慌指標 ETF'),
    'tlt': ('TLT', '20年美債 ETF (TLT)'),
    'gld': ('GLD', '黃金 ETF (GLD)'),
    'uso': ('USO', 'WTI 原油 ETF (USO)'),
}

# GICS 11 sectors (zh-Hant -> English).
SECTORS = {
    '資訊科技': 'Information Technology',
    '通訊服務': 'Communication Services',
    '非必需消費': 'Consumer Discretionary',
    '金融': 'Financials',
    '醫療保健': 'Health Care',
    '工業': 'Industrials',
    '必需消費': 'Consumer Staples',
    '能源': 'Energy',
    '公用事業': 'Utilities',
    '房地產': 'Real Estate',
    '原物料': 'Materials',
}

# Recommendation model.
PICK_TOP_N = 20
MIN_AVG_VALUE20 = 0.2       # 億美元 (= USD 20M average daily turnover)
MIN_PRICE = 5.0
MIN_HISTORY = 60            # trading days
WEIGHTS = {'earn': 0.30, 'inst': 0.25, 'mom': 0.25, 'val': 0.15, 'vol': 0.05}
FACTOR_LABELS = {'earn': '財報成長與驚喜', 'inst': '機構共識與籌碼', 'mom': '技術趨勢動能',
                 'val': '估值與獲利品質', 'vol': '低波動穩定度'}
BACKTEST_TOP_N = 10
BACKTEST_HOLD = 10
BACKTEST_COST = 0.10        # % round-trip slippage + fees

# Static-build sizing.
TOP_STOCKS = 150
TOP_ETFS = 30

DISCLAIMER = (
    '本站所有量化評分、今日推薦、盤前盤後戰情、選股篩選、ADR 折溢價與技術指標分析，均由程式依公開歷史資料自動運算，'
    '純供個人量化研究參考，絕不構成任何證券投資顧問建議、買賣邀約或獲利保證；美股交易另涉匯率、時差與稅務風險，'
    '投資人應獨立判斷並自行查證，任何投資決策之盈虧或財務損失皆由投資人完全自負，概與本站及開發者無關。'
)

USER_AGENT = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/124.0 Safari/537.36')
