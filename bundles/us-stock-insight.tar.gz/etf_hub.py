"""US core ETF hub: categories, issuer, expense ratio, AUM, dividend frequency, TTM yield and
ex-dividend calendar (SPEC §4.8).  Pure computation; the updater caches the network data."""
from __future__ import annotations

import datetime as dt
import math
from typing import Any

from sources import universe_curated as uc

CATEGORY_ORDER = ['大盤指數', '國際市場', '科技半導體', '產業類股', '高股息', '主動收益',
                  '美債與固定收益', '原物料與商品', '波動率與另類', '加密資產']
FREQ_PER_YEAR = {'月配': 12, '季配': 4, '半年配': 2, '年配': 1, '不配息': 0}


def _ok(x: Any) -> bool:
  return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _r(x: Any, nd: int = 2) -> float | None:
  return round(float(x), nd) if _ok(x) else None


def etf_meta() -> dict[str, dict[str, Any]]:
  return {e['code']: e for e in uc.ETFS}


def _infer_freq(rows: list[dict[str, Any]], default: str) -> str:
  """Infers payout frequency from the number of ex-dates in the trailing ~13 months."""
  if not rows:
    return default
  last = rows[0]['ex_date']
  try:
    cut = (dt.date.fromisoformat(last) - dt.timedelta(days=395)).isoformat()
  except ValueError:
    return default
  n = sum(1 for r in rows if r['ex_date'] > cut)
  if n >= 10:
    return '月配'
  if n >= 4:
    return '季配'
  if n >= 2:
    return '半年配'
  if n == 1:
    return '年配'
  return default


def etf_item(code: str, row: dict[str, Any], meta: dict[str, Any], div: dict[str, Any] | None,
             summ: dict[str, Any] | None, today: str) -> dict[str, Any]:
  div = div or {}
  summ = summ or {}
  rows = [r for r in (div.get('rows') or []) if r.get('ex_date')]
  rows.sort(key=lambda r: r['ex_date'], reverse=True)
  close = row.get('close')
  try:
    cut = (dt.date.fromisoformat(today) - dt.timedelta(days=365)).isoformat()
  except ValueError:
    cut = '0000-00-00'
  ttm = sum(r['cash'] for r in rows if r['ex_date'] > cut and _ok(r.get('cash')))
  freq = _infer_freq(rows, meta.get('freq') or '季配')
  if rows and _ok(close) and close > 0 and ttm > 0:
    yld = ttm / close * 100
    div_ttm = ttm
  else:
    yld = div.get('yld') if _ok(div.get('yld')) else meta.get('yld_est')
    div_ttm = (close * yld / 100) if _ok(close) and _ok(yld) else None
  last = rows[0] if rows else {}
  aum = summ.get('aum') if _ok(summ.get('aum')) else meta.get('aum')
  er = summ.get('expense_ratio') if _ok(summ.get('expense_ratio')) else meta.get('expense_ratio')
  return {
      'code': code, 'name': meta.get('name') or row.get('name') or code,
      'en_name': meta.get('en_name') or row.get('en_name') or '',
      'category': meta.get('category') or '大盤指數', 'issuer': meta.get('issuer') or '',
      'expense_ratio': _r(er, 2), 'desc': meta.get('desc') or '',
      'close': _r(close), 'pct': _r(row.get('pct')), 'r20': _r(row.get('r20')),
      'r60': _r(row.get('r60')), 'r250': _r(row.get('r250')),
      'aum': _r(aum, 1), 'vol': row.get('vol'), 'value': _r(row.get('value')),
      'freq': freq, 'yld_ttm': _r(yld), 'div_ttm': _r(div_ttm, 4),
      'ex_date': last.get('ex_date') or div.get('ex_date'),
      'pay_date': last.get('pay_date') or div.get('pay_date'),
      'last_cash': _r(last.get('cash'), 4) if last else _r(meta.get('last_cash_est'), 4),
      'hi52': _r(row.get('hi52')), 'lo52': _r(row.get('lo52')),
      'signals': list(row.get('signals') or [])[:4],
      'divs': [{'ex_date': r['ex_date'], 'pay_date': r.get('pay_date'), 'cash': _r(r.get('cash'), 4)}
               for r in rows[:16]],
  }


def build_payload(rows: dict[str, dict[str, Any]], dividends: dict[str, dict[str, Any]],
                  summaries: dict[str, dict[str, Any]], today: str,
                  data_date: str | None = None) -> dict[str, Any]:
  meta = etf_meta()
  items = []
  for code, m in meta.items():
    row = rows.get(code) or {}
    if not row.get('close'):
      continue
    items.append(etf_item(code, row, m, dividends.get(code), summaries.get(code), today))
  cat_rank = {c: i for i, c in enumerate(CATEGORY_ORDER)}
  items.sort(key=lambda x: (cat_rank.get(x['category'], 99), -(x.get('aum') or 0)))
  cats: dict[str, int] = {}
  for it in items:
    cats[it['category']] = cats.get(it['category'], 0) + 1
  ylds = [it['yld_ttm'] for it in items if _ok(it.get('yld_ttm')) and it['yld_ttm'] > 0]
  # Calendar: ex-dates in the last 45 days + projected next ex-date from the payout rhythm.
  try:
    t = dt.date.fromisoformat(today)
  except ValueError:
    t = dt.date.today()
  cal = []
  upcoming = 0
  for it in items:
    for d in it['divs'][:3]:
      try:
        ex = dt.date.fromisoformat(d['ex_date'])
      except (TypeError, ValueError):
        continue
      if (t - ex).days <= 45:
        cal.append({'code': it['code'], 'name': it['name'], 'category': it['category'],
                    'ex_date': d['ex_date'], 'pay_date': d.get('pay_date'), 'cash': d.get('cash'),
                    'status': '已除息' if ex <= t else '即將除息', 'estimated': False})
        if ex > t:
          upcoming += 1
    per = FREQ_PER_YEAR.get(it['freq'], 0)
    if per and it.get('ex_date'):
      try:
        last = dt.date.fromisoformat(it['ex_date'])
      except ValueError:
        continue
      nxt = last + dt.timedelta(days=round(365 / per))
      if t < nxt <= t + dt.timedelta(days=40):
        upcoming += 1
        cal.append({'code': it['code'], 'name': it['name'], 'category': it['category'],
                    'ex_date': nxt.isoformat(), 'pay_date': None, 'cash': it.get('last_cash'),
                    'status': '預估除息', 'estimated': True})
  cal.sort(key=lambda x: x['ex_date'], reverse=True)
  return {
      'date': data_date or today,
      'summary': {'count': len(items), 'avg_yld': _r(sum(ylds) / len(ylds)) if ylds else None,
                  'upcoming_ex_count': upcoming,
                  'categories': [{'name': c, 'count': cats[c]} for c in sorted(cats, key=lambda c: cat_rank.get(c, 99))]},
      'items': items, 'calendar': cal[:80],
  }
