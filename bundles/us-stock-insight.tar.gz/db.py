"""SQLite storage for 美股戰情室 (WAL, one connection per thread)."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from typing import Any, Iterable, Sequence

import config

_LOCAL = threading.local()
_WRITE_LOCK = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS stocks (
  code TEXT PRIMARY KEY, name TEXT, en_name TEXT, market TEXT, type TEXT, industry TEXT,
  sub_industry TEXT, index_tags TEXT, country TEXT, ipo_year TEXT, nasdaq_sector TEXT,
  nasdaq_industry TEXT, mcap REAL, updated TEXT);
CREATE TABLE IF NOT EXISTS daily (
  code TEXT, date TEXT, open REAL, high REAL, low REAL, close REAL, vol REAL,
  PRIMARY KEY (code, date)) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS daily_date ON daily(date);
CREATE TABLE IF NOT EXISTS index_daily (
  name TEXT, date TEXT, open REAL, high REAL, low REAL, close REAL, vol REAL,
  PRIMARY KEY (name, date)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS quotes (
  code TEXT PRIMARY KEY, date TEXT, close REAL, chg REAL, pct REAL, open REAL, high REAL,
  low REAL, vol REAL, prev REAL, mcap REAL, quote_time TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS fundamentals (
  code TEXT, kind TEXT, fetched_at REAL, data TEXT, PRIMARY KEY (code, kind)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS extended (
  code TEXT PRIMARY KEY, ext_type TEXT, ext_price REAL, ext_pct REAL, vol REAL, fetched_at REAL);
CREATE TABLE IF NOT EXISTS fetch_log (
  source TEXT, key TEXT, status TEXT, fetched_at REAL,
  PRIMARY KEY (source, key)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS picks (
  date TEXT, rank INTEGER, code TEXT, score REAL, close REAL, data TEXT,
  PRIMARY KEY (date, rank)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS news_cache (code TEXT PRIMARY KEY, fetched_at REAL, data TEXT);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
"""


def connect() -> sqlite3.Connection:
  """Returns this thread's connection (created on first use)."""
  conn = getattr(_LOCAL, 'conn', None)
  path = getattr(_LOCAL, 'path', None)
  if conn is None or path != config.DB_PATH:
    if conn is not None:
      try:
        conn.close()
      except sqlite3.Error:
        pass
    os.makedirs(os.path.dirname(config.DB_PATH) or '.', exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH, timeout=60, check_same_thread=False)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    conn.execute('PRAGMA busy_timeout=60000')
    conn.execute('PRAGMA temp_store=MEMORY')
    _LOCAL.conn = conn
    _LOCAL.path = config.DB_PATH
  return conn


def init() -> None:
  with _WRITE_LOCK:
    conn = connect()
    conn.executescript(SCHEMA)
    conn.commit()


def query(sql: str, params: Sequence[Any] = ()) -> list[tuple]:
  return connect().execute(sql, params).fetchall()


def query_one(sql: str, params: Sequence[Any] = ()) -> tuple | None:
  return connect().execute(sql, params).fetchone()


def execute(sql: str, params: Sequence[Any] = ()) -> None:
  with _WRITE_LOCK:
    conn = connect()
    conn.execute(sql, params)
    conn.commit()


def upsert_many(table: str, cols: Sequence[str], rows: Iterable[Sequence[Any]]) -> int:
  """INSERT OR REPLACE rows; returns count."""
  rows = list(rows)
  if not rows:
    return 0
  sql = (f'INSERT OR REPLACE INTO {table} ({",".join(cols)}) '
         f'VALUES ({",".join("?" * len(cols))})')
  with _WRITE_LOCK:
    conn = connect()
    conn.executemany(sql, rows)
    conn.commit()
  return len(rows)


def fetched(source: str, key: str) -> str | None:
  row = query_one('SELECT status FROM fetch_log WHERE source=? AND key=?', (source, key))
  return row[0] if row else None


def fetched_age(source: str, key: str) -> float:
  """Seconds since (source, key) was last fetched OK (inf when never)."""
  row = query_one("SELECT fetched_at FROM fetch_log WHERE source=? AND key=? AND status='ok'",
                  (source, key))
  return time.time() - row[0] if row and row[0] else float('inf')


def mark_fetched(source: str, key: str, status: str = 'ok') -> None:
  execute('INSERT OR REPLACE INTO fetch_log VALUES (?,?,?,?)',
          (source, key, status, time.time()))


def get_kv(key: str, default: Any = None) -> Any:
  row = query_one('SELECT value FROM kv WHERE key=?', (key,))
  if not row:
    return default
  try:
    return json.loads(row[0])
  except (TypeError, ValueError):
    return default


def set_kv(key: str, value: Any) -> None:
  execute('INSERT OR REPLACE INTO kv VALUES (?,?)',
          (key, json.dumps(value, ensure_ascii=False)))


def get_fund(code: str, kind: str, max_age: float | None = None) -> Any:
  """Cached fundamentals JSON for (code, kind); None when missing or older than max_age sec."""
  row = query_one('SELECT fetched_at, data FROM fundamentals WHERE code=? AND kind=?', (code, kind))
  if not row:
    return None
  if max_age is not None and time.time() - (row[0] or 0) > max_age:
    return None
  try:
    return json.loads(row[1])
  except (TypeError, ValueError):
    return None


def fund_age(code: str, kind: str) -> float:
  row = query_one('SELECT fetched_at FROM fundamentals WHERE code=? AND kind=?', (code, kind))
  return time.time() - row[0] if row and row[0] else float('inf')


def set_fund(code: str, kind: str, data: Any) -> None:
  execute('INSERT OR REPLACE INTO fundamentals VALUES (?,?,?,?)',
          (code, kind, time.time(), json.dumps(data, ensure_ascii=False)))


def all_fund(kind: str) -> dict[str, Any]:
  out: dict[str, Any] = {}
  for code, data in query('SELECT code, data FROM fundamentals WHERE kind=?', (kind,)):
    try:
      out[code] = json.loads(data)
    except (TypeError, ValueError):
      continue
  return out


def trading_dates(limit: int | None = None) -> list[str]:
  """Market-wide trading dates (dates with >= 100 stocks or an S&P 500 bar), ascending."""
  d_rows = query('SELECT date FROM daily GROUP BY date HAVING COUNT(*) >= 100')
  i_rows = query("SELECT date FROM index_daily WHERE name='spx'")
  dates = sorted({r[0] for r in d_rows} | {r[0] for r in i_rows})
  return dates[-limit:] if limit else dates
