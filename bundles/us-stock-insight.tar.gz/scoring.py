"""US five-factor stock scoring, daily top-20 picks and an honest walk-forward backtest.

Scored factors (cross-sectional percentiles among eligible equities, 0..1):
  earn 30% 財報成長與驚喜 — latest EPS surprise, beat streak, revenue YoY, EPS growth.
  inst 25% 機構共識與籌碼 — analyst target upside, buy ratio, institutional ownership & net flow.
  mom  25% 技術趨勢動能   — 6/3-month returns, distance to 52-week high, MA20 slope, trend bits,
                            overheat penalty.
  val  15% 估值與獲利品質 — earnings yield (trailing & forward), PEG, operating & gross margin.
  vol   5% 低波動穩定度   — low 20-day volatility and ATR%.

The walk-forward backtest only uses information that was known at each historical date:
price/volume momentum, OBV money flow and low volatility (fundamental snapshots are not
point-in-time, so they are deliberately excluded to avoid look-ahead bias).
"""
from __future__ import annotations

import bisect
import math
from collections import deque
from typing import Any, Sequence

import config

EQUITY_TYPES = ('股票', 'ADR')


# ------------------------------------------------------------------ basics --

def _ok(x: Any) -> bool:
  return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _r(x: float | None, nd: int = 2) -> float | None:
  return round(float(x), nd) if _ok(x) else None


def pct_rank(values: dict[str, float | None]) -> dict[str, float]:
  """Percentile rank 0..1 for non-null values (ties share the average rank)."""
  items = [(v, k) for k, v in values.items() if _ok(v)]
  if not items:
    return {}
  items.sort()
  n = len(items)
  out: dict[str, float] = {}
  i = 0
  while i < n:
    j = i
    while j + 1 < n and items[j + 1][0] == items[i][0]:
      j += 1
    r = ((i + j) / 2) / (n - 1) if n > 1 else 0.5
    for t in range(i, j + 1):
      out[items[t][1]] = r
    i = j + 1
  return out


def rolling_sum(xs: Sequence[float], n: int) -> list[float | None]:
  out: list[float | None] = [None] * len(xs)
  s = 0.0
  for i, x in enumerate(xs):
    s += x
    if i >= n:
      s -= xs[i - n]
    if i >= n - 1:
      out[i] = s
  return out


def rolling_mean(xs: Sequence[float], n: int) -> list[float | None]:
  return [None if v is None else v / n for v in rolling_sum(xs, n)]


def rolling_max(xs: Sequence[float], n: int) -> list[float]:
  out, dq = [], deque()
  for i, x in enumerate(xs):
    while dq and xs[dq[-1]] <= x:
      dq.pop()
    dq.append(i)
    if dq[0] <= i - n:
      dq.popleft()
    out.append(xs[dq[0]])
  return out


def rolling_volatility(closes: Sequence[float], n: int) -> list[float | None]:
  """Population stdev (%) of the last n daily returns."""
  rets = [0.0] + [((closes[i] / closes[i - 1] - 1) * 100 if closes[i - 1] else 0.0)
                  for i in range(1, len(closes))]
  out: list[float | None] = [None] * len(closes)
  s = s2 = 0.0
  for i, r in enumerate(rets):
    s += r
    s2 += r * r
    if i >= n:
      s -= rets[i - n]
      s2 -= rets[i - n] ** 2
      m = s / n
      out[i] = math.sqrt(max(0.0, s2 / n - m * m))
  return out


def obv_series(closes: Sequence[float], vols: Sequence[float]) -> list[float]:
  out, acc = [], 0.0
  for i, c in enumerate(closes):
    if i:
      if c > closes[i - 1]:
        acc += vols[i]
      elif c < closes[i - 1]:
        acc -= vols[i]
    out.append(acc)
  return out


def obv_flow(obv: Sequence[float], vols: Sequence[float], i: int, n: int = 20) -> float | None:
  """OBV change over n days as a share of total n-day volume (-1..1)."""
  if i < n:
    return None
  tot = sum(vols[i - n + 1:i + 1])
  return (obv[i] - obv[i - n]) / tot if tot > 0 else None


# ------------------------------------------------------------ raw factors --

def mom_raw(r60: float | None, r120: float | None, dist_hi52: float | None,
            ma20_slope: float | None, above20: bool | None, bias20: float | None,
            rsi: float | None = None) -> float | None:
  if r60 is None and dist_hi52 is None:
    return None
  x = 0.0
  x += 0.35 * max(-40.0, min(60.0, r60 or 0.0)) / 20
  x += 0.20 * max(-50.0, min(100.0, r120 or 0.0)) / 30
  x += 0.25 * max(-40.0, min(0.0, dist_hi52 if dist_hi52 is not None else -20.0)) / 10 + 1.0
  x += 0.15 * max(-3.0, min(3.0, ma20_slope or 0.0))
  x += 0.15 if above20 else -0.15
  if bias20 is not None and bias20 > 15:      # overheated: far above MA20
    x -= (bias20 - 15) / 10
  if rsi is not None and rsi > 80:
    x -= (rsi - 80) / 20
  return x


def flow_raw(obv_flow20: float | None, vol_ratio: float | None, r5: float | None) -> float | None:
  if obv_flow20 is None:
    return None
  x = obv_flow20
  if vol_ratio is not None and r5 is not None and r5 > 0:
    x += 0.05 * max(-2.0, min(2.0, vol_ratio - 1))
  return x


def stab_raw(volat20: float | None, atr_pct: float | None = None) -> float | None:
  if volat20 is None and atr_pct is None:
    return None
  v = volat20 if volat20 is not None else (atr_pct or 0) * 0.8
  return -(v + 0.3 * (atr_pct or v))


def _blend(code: str, parts: list[tuple[dict[str, float], float]]) -> float | None:
  tot = w = 0.0
  for ranks, wt in parts:
    if code in ranks:
      tot += ranks[code] * wt
      w += wt
  return tot / w if w > 0 else None


def is_eligible(row: dict[str, Any]) -> bool:
  if row.get('type') not in EQUITY_TYPES:
    return False
  if not _ok(row.get('close')) or row['close'] < config.MIN_PRICE:
    return False
  if (row.get('value20') or 0) < config.MIN_AVG_VALUE20:
    return False
  return (row.get('n_bars') or 0) >= config.MIN_HISTORY


def score_universe(rows: dict[str, dict[str, Any]]) -> list[str]:
  """Writes score/rank/f_* (0–100) into eligible rows; returns codes ranked best-first."""
  elig = [c for c, r in rows.items() if is_eligible(r)]
  for r in rows.values():
    for k in ('score', 'rank', 'f_earn', 'f_inst', 'f_mom', 'f_val', 'f_vol'):
      r[k] = None
  if not elig:
    return []

  def col(fn) -> dict[str, float]:
    return pct_rank({c: fn(rows[c]) for c in elig})

  def inv(x: Any) -> float | None:
    return 1.0 / x if _ok(x) and x > 0 else (-0.05 if _ok(x) else None)

  # earn
  e_sur = col(lambda r: max(-50, min(50, r['eps_surprise'])) if _ok(r.get('eps_surprise')) else None)
  e_beat = col(lambda r: r.get('beat_count'))
  e_rev = col(lambda r: max(-60, min(200, r['rev_yoy'])) if _ok(r.get('rev_yoy')) else None)
  e_eps = col(lambda r: max(-100, min(300, r['eps_yoy'])) if _ok(r.get('eps_yoy')) else None)
  # inst
  i_up = col(lambda r: max(-50, min(120, r['target_upside'])) if _ok(r.get('target_upside')) else None)
  i_buy = col(lambda r: r.get('analyst_buy_pct') if (r.get('analyst_n') or 0) >= 3 else None)
  i_own = col(lambda r: r.get('inst_own_pct'))
  i_flow = col(lambda r: r.get('inst_flow'))
  i_obv = col(lambda r: r.get('obv_flow20'))
  # mom
  m_raw = col(lambda r: mom_raw(r.get('r60'), r.get('r120'), r.get('dist_hi52'), r.get('ma20_slope'),
                                bool((r.get('ma_bits') or 0) & 4), r.get('bias20'), r.get('rsi')))
  # val
  v_ey = col(lambda r: inv(r.get('pe')))
  v_fey = col(lambda r: inv(r.get('fwd_pe')))
  v_peg = col(lambda r: inv(r.get('peg')))
  v_opm = col(lambda r: r.get('op_margin'))
  v_gm = col(lambda r: r.get('gross_margin'))
  # vol
  s_vol = col(lambda r: stab_raw(r.get('volat20'), r.get('atr_pct')))

  facs: dict[str, dict[str, float]] = {k: {} for k in config.WEIGHTS}
  for c in elig:
    vals = {
        'earn': _blend(c, [(e_sur, 0.3), (e_beat, 0.2), (e_rev, 0.3), (e_eps, 0.2)]),
        'inst': _blend(c, [(i_up, 0.3), (i_buy, 0.3), (i_own, 0.1), (i_flow, 0.15), (i_obv, 0.15)]),
        'mom': _blend(c, [(m_raw, 1.0)]),
        'val': _blend(c, [(v_ey, 0.3), (v_fey, 0.3), (v_peg, 0.15), (v_opm, 0.15), (v_gm, 0.1)]),
        'vol': _blend(c, [(s_vol, 1.0)]),
    }
    for k, v in vals.items():
      if v is not None:
        facs[k][c] = v
  # Re-rank each blended factor so f_* is a clean 0–100 percentile.
  franks = {k: pct_rank(v) for k, v in facs.items()}
  total: dict[str, float] = {}
  for c in elig:
    total[c] = sum(w * franks[k].get(c, 0.3) for k, w in config.WEIGHTS.items())
  ranked = sorted(elig, key=lambda c: (-total[c], c))
  for i, c in enumerate(ranked, 1):
    r = rows[c]
    r['score'] = int(round(total[c] * 100))
    r['rank'] = i
    for k in config.WEIGHTS:
      v = franks[k].get(c)
      r['f_' + k] = None if v is None else int(round(v * 100))
  return ranked


# ---------------------------------------------------------------- reasons --

def _usd(x: float | None) -> str:
  return '—' if not _ok(x) else f'${x:,.2f}'


def reasons_for(r: dict[str, Any]) -> tuple[list[str], list[str]]:
  """Concrete zh-Hant reasons (strongest first) and risks for one scored row."""
  cand: list[tuple[float, str]] = []
  sp, act, cons = r.get('eps_surprise'), r.get('eps_q'), r.get('eps_cons')
  if _ok(sp) and sp > 0 and _ok(act):
    beat = r.get('beat_count') or 0
    txt = f'上季 EPS {_usd(act)} 優於華爾街共識 {_usd(cons)}（驚喜 +{sp:.1f}%）'
    if beat >= 3:
      txt += f'，近 4 季 {beat} 季 Beat'
    cand.append((80 + min(sp, 20), txt))
  if _ok(r.get('rev_yoy')) and r['rev_yoy'] >= 10:
    txt = f'季營收年增 +{r["rev_yoy"]:.1f}%'
    if _ok(r.get('gross_margin')):
      txt += f'，毛利率 {r["gross_margin"]:.1f}%'
    cand.append((70 + min(r['rev_yoy'], 60) / 2, txt))
  if _ok(r.get('eps_yoy')) and r['eps_yoy'] >= 15:
    cand.append((60 + min(r['eps_yoy'], 80) / 4, f'EPS 成長 +{r["eps_yoy"]:.1f}%，獲利動能強勁'))
  n = r.get('analyst_n') or 0
  if n >= 3 and _ok(r.get('target_upside')) and r['target_upside'] > 5:
    buy = r.get('analyst_buy', 0)
    cand.append((65 + min(r['target_upside'], 50) / 2,
                 f'{buy} 位華爾街分析師給予買進評級，平均目標價 {_usd(r.get("target_price"))}'
                 f'（隱含空間 +{r["target_upside"]:.1f}%）'))
  if _ok(r.get('inst_own_pct')) and r['inst_own_pct'] >= 70 and _ok(r.get('inst_flow')) and r['inst_flow'] > 0.1:
    cand.append((55, f'機構持股 {r["inst_own_pct"]:.1f}%，近一季加碼股數多於減碼'))
  bits = r.get('ma_bits') or 0
  if bits & 64:
    cand.append((58 + min(r.get('r20') or 0, 20) / 2, f'均線多頭排列，近 20 日上漲 {r.get("r20") or 0:+.1f}%'))
  elif bits & 4 and _ok(r.get('r60')) and r['r60'] > 10:
    cand.append((52, f'站穩月線，近 3 個月漲幅 {r["r60"]:+.1f}%'))
  if _ok(r.get('dist_hi52')) and r['dist_hi52'] > -5:
    cand.append((50, f'股價距 52 週高點僅 {abs(r["dist_hi52"]):.1f}%，趨勢強勢'))
  if _ok(r.get('obv_flow20')) and r['obv_flow20'] > 0.15:
    cand.append((48, 'OBV 能量潮走升，資金持續流入'))
  if _ok(r.get('fwd_pe')) and 0 < r['fwd_pe'] < 18:
    cand.append((45, f'預估本益比 {r["fwd_pe"]:.1f} 倍，估值相對合理'))
  if _ok(r.get('op_margin')) and r['op_margin'] >= 30:
    cand.append((44, f'營業利益率 {r["op_margin"]:.1f}%，獲利品質優異'))
  if _ok(r.get('volat20')) and r['volat20'] < 1.2:
    cand.append((40, f'20 日波動度 {r["volat20"]:.2f}%，走勢穩健'))
  cand.sort(key=lambda x: -x[0])
  reasons = [t for _, t in cand[:4]]
  if not reasons:
    reasons = [f'五因子綜合評分 {r.get("score")} 分，於全市場合格股排名第 {r.get("rank")}']
  risks: list[str] = []
  if _ok(r.get('atr_pct')) and r['atr_pct'] >= 3.5:
    risks.append(f'ATR 波動率 {r["atr_pct"]:.1f}% 偏高，留意大幅震盪')
  if _ok(r.get('bias20')) and r['bias20'] > 12:
    risks.append(f'股價高於月線 {r["bias20"]:.1f}%，短線乖離過大')
  if _ok(r.get('rsi')) and r['rsi'] > 75:
    risks.append(f'RSI {r["rsi"]:.0f} 進入過熱區')
  if _ok(r.get('pe')) and r['pe'] > 60:
    risks.append(f'本益比 {r["pe"]:.0f} 倍，估值偏高')
  if _ok(r.get('eps_ttm')) and r['eps_ttm'] < 0:
    risks.append('近四季 EPS 為負，仍在虧損')
  ne = r.get('next_earn_days')
  if isinstance(ne, int) and 0 <= ne <= 7:
    risks.append(f'{ne} 天內公布財報，留意財報前後跳空')
  if _ok(r.get('eps_surprise')) and r['eps_surprise'] < 0:
    risks.append(f'上季 EPS 低於預期 {r["eps_surprise"]:.1f}%')
  return reasons, risks[:3]


def risk_tags(r: dict[str, Any]) -> list[str]:
  out = []
  if _ok(r.get('atr_pct')) and r['atr_pct'] >= 4:
    out.append('高波動')
  if (_ok(r.get('rsi')) and r['rsi'] > 78) or (_ok(r.get('bias20')) and r['bias20'] > 15):
    out.append('過熱')
  if r.get('type') != 'ETF' and (r.get('value20') or 0) < config.MIN_AVG_VALUE20:
    out.append('流動性偏低')
  if _ok(r.get('eps_ttm')) and r['eps_ttm'] < 0:
    out.append('虧損')
  ne = r.get('next_earn_days')
  if isinstance(ne, int) and 0 <= ne <= 7:
    out.append('財報將屆')
  return out


def signal_tags(r: dict[str, Any], tech_signals: Sequence[str] = ()) -> list[str]:
  out = list(tech_signals or [])[:4]
  if (r.get('beat_count') or 0) >= 4:
    out.append('EPS連4季Beat')
  elif (r.get('beat_count') or 0) >= 3:
    out.append('EPS連3季Beat')
  if (r.get('analyst_n') or 0) >= 8 and (r.get('analyst_buy_pct') or 0) >= 80:
    out.append('華爾街強買')
  if _ok(r.get('rev_yoy')) and r['rev_yoy'] >= 30:
    out.append('營收高成長')
  if _ok(r.get('dist_hi52')) and r['dist_hi52'] >= -1:
    out.append('創52週新高')
  seen, uniq = set(), []
  for s in out:
    if s not in seen:
      seen.add(s)
      uniq.append(s)
  return uniq[:6]


def levels(close: float, support: float | None, resistance: float | None,
           atr: float | None, ma20: float | None = None, hi52: float | None = None) -> dict[str, Any]:
  """Support / resistance / stop / target / reward-risk (USD, 2 dp)."""
  a = atr if _ok(atr) and atr > 0 else close * 0.025
  sup = support if _ok(support) and support < close else (ma20 if _ok(ma20) and ma20 < close else close - 1.5 * a)
  res = resistance if _ok(resistance) and resistance > close else (
      hi52 if _ok(hi52) and hi52 > close * 1.01 else close + 2.0 * a)
  stop = min(sup - 0.5 * a, close - 1.0 * a)
  stop = max(stop, close * 0.85)
  target = max(res, close + 2.0 * a)
  risk = close - stop
  rr = (target - close) / risk if risk > 0 else None
  return {'support': _r(sup), 'resistance': _r(res), 'stop': _r(stop), 'target': _r(target),
          'rr': _r(rr)}


# -------------------------------------------------------------- backtest -----

BT_WEIGHTS = {'mom': 0.55, 'flow': 0.30, 'vol': 0.15}


def backtest(series: dict[str, dict[str, Any]], bench: dict[str, float], dates: list[str],
             lookback: int = 220, top_n: int | None = None,
             hold: int | None = None) -> dict[str, Any]:
  """Walk-forward test using only point-in-time price/volume factors.

  series[code] = {'dates': [...], 'close': [...], 'vol': [...], 'type': '股票'|'ADR'|'ETF'}
  bench = {date: S&P 500 close}.  Signals use day-d close; entry is the NEXT day's close.
  """
  top_n = top_n or config.BACKTEST_TOP_N
  hold = hold or config.BACKTEST_HOLD
  if len(dates) < 90:
    return {}
  horizons = (5, 10, 20)
  cost = config.BACKTEST_COST
  prep = {}
  for code, s in series.items():
    if s.get('type') not in EQUITY_TYPES or len(s['close']) < 80:
      continue
    closes, vols = s['close'], s['vol']
    idx = {d: i for i, d in enumerate(s['dates'])}
    ma20 = rolling_mean(closes, 20)
    val20 = rolling_mean([c * v / 1e8 for c, v in zip(closes, vols)], 20)
    vma5, vma20 = rolling_mean(vols, 5), rolling_mean(vols, 20)
    hi = rolling_max(closes, 250)
    volat = rolling_volatility(closes, 20)
    obv = obv_series(closes, vols)
    prep[code] = (idx, closes, vols, ma20, val20, vma5, vma20, hi, volat, obv)
  if not prep:
    return {}
  start = max(70, len(dates) - lookback - max(horizons))
  test_days = dates[start:len(dates) - 1]
  date_pos = {d: i for i, d in enumerate(dates)}
  picks_by_day: dict[str, list[str]] = {}
  universe_by_day: dict[str, list[str]] = {}
  for d in test_days:
    raws: dict[str, dict[str, float | None]] = {k: {} for k in BT_WEIGHTS}
    for code, (idx, closes, vols, ma20, val20, vma5, vma20, hi, volat, obv) in prep.items():
      i = idx.get(d)
      if i is None or i < 65 or closes[i] < config.MIN_PRICE:
        continue
      if (val20[i] or 0) < config.MIN_AVG_VALUE20:
        continue
      c = closes[i]
      r5 = (c / closes[i - 5] - 1) * 100
      r60 = (c / closes[i - 60] - 1) * 100
      r120 = (c / closes[i - 120] - 1) * 100 if i >= 120 else None
      bias20 = (c / ma20[i] - 1) * 100 if ma20[i] else None
      dist = (c / hi[i] - 1) * 100 if hi[i] else None
      slope = (ma20[i] / ma20[i - 5] - 1) * 100 if ma20[i] and ma20[i - 5] else None
      vr = (vma5[i] / vma20[i]) if vma5[i] and vma20[i] else None
      raws['mom'][code] = mom_raw(r60, r120, dist, slope, bool(ma20[i] and c > ma20[i]), bias20)
      raws['flow'][code] = flow_raw(obv_flow(obv, vols, i), vr, r5)
      raws['vol'][code] = stab_raw(volat[i])
    ranks = {k: pct_rank(v) for k, v in raws.items()}
    total = {code: sum(w * ranks[k].get(code, 0.3) for k, w in BT_WEIGHTS.items())
             for code in raws['mom']}
    if len(total) < top_n * 3:
      continue
    picks_by_day[d] = sorted(total, key=lambda c: (-total[c], c))[:top_n]
    universe_by_day[d] = list(total)

  def fwd(code: str, d: str, h: int) -> float | None:
    idx, closes = prep[code][0], prep[code][1]
    i = idx.get(d)
    if i is None or i + 1 + h >= len(closes):
      return None
    return (closes[i + 1 + h] / closes[i + 1] - 1) * 100

  def bench_fwd(d: str, h: int) -> float | None:
    j = date_pos[d]
    if j + 1 + h >= len(dates):
      return None
    a, b = bench.get(dates[j + 1]), bench.get(dates[j + 1 + h])
    return None if not a or not b else (b / a - 1) * 100

  ew_cache: dict[tuple[str, int], float | None] = {}

  def ew_fwd(d: str, h: int) -> float | None:
    if (d, h) not in ew_cache:
      rs = [x for x in (fwd(c, d, h) for c in universe_by_day.get(d, [])) if x is not None]
      ew_cache[(d, h)] = sum(rs) / len(rs) if rs else None
    return ew_cache[(d, h)]

  out_h = []
  for h in horizons:
    rets, wins, benches, ews = [], 0.0, [], []
    for d, codes in picks_by_day.items():
      rs = [x for x in (fwd(c, d, h) for c in codes) if x is not None]
      bm, ew = bench_fwd(d, h), ew_fwd(d, h)
      if not rs or bm is None or ew is None:
        continue
      rets.append(sum(rs) / len(rs) - cost)
      benches.append(bm)
      ews.append(ew)
      wins += sum(1 for x in rs if x - cost > 0) / len(rs)
    if rets:
      out_h.append({'days': h, 'avg_ret': round(sum(rets) / len(rets), 2),
                    'win_rate': round(wins / len(rets) * 100, 1),
                    'bench': round(sum(benches) / len(benches), 2),
                    'ew': round(sum(ews) / len(ews), 2), 'samples': len(rets)})
  equity, nav, bnav, enav = [], 1.0, 1.0, 1.0
  days = [d for d in test_days if d in picks_by_day]
  history = []
  for k in range(0, len(days), hold):
    d = days[k]
    rs_pairs = [(c, fwd(c, d, hold)) for c in picks_by_day[d]]
    rs = [x for _, x in rs_pairs if x is not None]
    bm, ew = bench_fwd(d, hold), ew_fwd(d, hold)
    if not rs or bm is None or ew is None:
      break
    j = date_pos[d]
    nav *= 1 + (sum(rs) / len(rs) - cost) / 100
    bnav *= 1 + bm / 100
    enav *= 1 + ew / 100
    equity.append([dates[min(j + 1 + hold, len(dates) - 1)], round(nav, 4), round(bnav, 4), round(enav, 4)])
    items = []
    for c, x in rs_pairs:
      idx, closes = prep[c][0], prep[c][1]
      i = idx[d]
      if x is None:
        continue
      items.append({'code': c, 'entry': _r(closes[i + 1]), 'last': _r(closes[i + 1 + hold]), 'ret': _r(x)})
    history.append({'date': dates[j + 1], 'kind': '回測', 'avg_ret': _r(sum(rs) / len(rs) - cost),
                    'bench_ret': _r(bm), 'items': items})
  if equity:
    equity.insert(0, [dates[min(date_pos[days[0]] + 1, len(dates) - 1)], 1.0, 1.0, 1.0])
  hh = next((h for h in out_h if h['days'] == hold), None) or (out_h[0] if out_h else {})
  return {
      'start': days[0] if days else None, 'end': dates[-1], 'top_n': top_n, 'hold_days': hold,
      'samples': hh.get('samples', 0), 'avg_ret': hh.get('avg_ret'), 'bench_avg_ret': hh.get('bench'),
      'ew_avg_ret': hh.get('ew'), 'win_rate': hh.get('win_rate'),
      'excess': round((hh.get('avg_ret') or 0) - (hh.get('bench') or 0), 2) if hh else None,
      'excess_ew': round((hh.get('avg_ret') or 0) - (hh.get('ew') or 0), 2) if hh else None,
      'bench_name': '標普 500 (S&P 500)',
      'note': (f'Walk-forward 歷史回測（每 {hold} 個交易日換倉、前 {top_n} 名等權重持有，僅使用當時已知的'
               f'價量動能、OBV 資金流向與低波動因子，訊號日隔天收盤價進場，扣除雙邊 {cost:.2f}% 滑價成本）。'
               '比較基準為標普 500 與全體合格股票等權平均。歷史績效不代表未來報酬。'),
      'equity': equity, 'horizons': out_h, 'history': history[::-1][:12],
  }


def asof_index(keys: list[str], d: str) -> int:
  return bisect.bisect_right(keys, d) - 1
