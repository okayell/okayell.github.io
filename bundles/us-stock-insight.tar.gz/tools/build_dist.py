#!/usr/bin/env python3
"""Builds the GitHub Pages single-file HTML (static data snapshot) of 美股戰情室.

Output: dist/index.html — CSS, Lightweight Charts, every page script and an API snapshot
(`window.__STATIC_API__`, parsed from an inert JSON island `#usStaticApi`) inlined into one file
that works from file:// or any static host.
Contents: meta / universe (all tracked US equities & ETFs, screener works fully) / market / picks /
industries / etfs / morning / all supply chains / full 1y daily K-line + analysis for picks +
top-turnover stocks/ADRs and ETFs. Indicators are recomputed client-side (`indicators.js`).

CLI: python3 tools/build_dist.py [--force]
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import json
import os
import re
import sys
import threading
import time
from typing import Any

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

import config  # noqa: E402  pylint: disable=wrong-import-position
import release_mgr  # noqa: E402  pylint: disable=wrong-import-position

DIST_DIR = config.DIST_DIR
OUT_HTML = os.path.join(DIST_DIR, 'index.html')
INFO_JSON = os.path.join(DIST_DIR, 'build_info.json')
TOP_STOCKS = config.TOP_STOCKS
TOP_ETFS = config.TOP_ETFS
_LOCK = threading.Lock()

# Encoded patterns to prevent literal internal hostnames, paths, or usernames in source.
_FORBIDDEN = re.compile(
    '|'.join(
        re.escape(base64.b64decode(b).decode())
        for b in (
            b'Z29vZ2xlcnMuY29t',
            b'Y29ycC5nb29nbGU=',
            b'Z29vZ2xlcGxleA==',
            b'aHVhbmd5aWNoYW8=',
            b'L2dvb2dsZS9zcmMv',
            b'QGdvb2dsZS5jb20=',
        )
    ),
    re.I,
)

_FALLBACK_HTML = (
    '<!doctype html>\n<html lang="zh-Hant-TW">\n<head>\n'
    '  <meta charset="utf-8">\n'
    '  <meta name="viewport" content="width=device-width, initial-scale=1">\n'
    '  <meta name="referrer" content="no-referrer">\n'
    '  <title>美股戰情室</title>\n'
    '</head>\n<body data-color-mode="us">\n'
    '  <main id="app"></main>\n'
    '</body>\n</html>\n'
)


def _static_files() -> list[str]:
  out: list[str] = []
  for rel in ('index.html', 'app.css'):
    fp = os.path.join(config.STATIC_DIR, rel)
    if os.path.isfile(fp):
      out.append(fp)
  for sub in ('vendor', 'js'):
    sub_dir = os.path.join(config.STATIC_DIR, sub)
    if os.path.isdir(sub_dir):
      for name in sorted(os.listdir(sub_dir)):
        fp = os.path.join(sub_dir, name)
        if name.endswith('.js') and os.path.isfile(fp):
          out.append(fp)
  return out


def _code_hash() -> str:
  h = hashlib.sha1()
  for fp in _static_files() + [os.path.abspath(__file__)]:
    try:
      with open(fp, 'rb') as f:
        h.update(f.read())
    except OSError:
      continue
  return h.hexdigest()[:16]


def info() -> dict[str, Any] | None:
  """Last build info plus `fresh` (matches current version, data date and code)."""
  try:
    with open(INFO_JSON, encoding='utf-8') as f:
      data = json.load(f)
  except (OSError, ValueError):
    return None
  if not os.path.isfile(OUT_HTML):
    return None
  import snapshot  # pylint: disable=import-outside-toplevel
  meta = snapshot.get_payload('universe') or {}
  an = snapshot.db.get_kv('analytics', {}) or {}
  data['fresh'] = (
      data.get('version') == release_mgr.current_version()
      and data.get('data_date') == meta.get('date')
      and data.get('data_updated_at') == an.get('updated_at')
      and data.get('code_hash') == _code_hash()
  )
  return data


def _full_codes(rows: dict[str, dict[str, Any]] | list[dict[str, Any]],
                picks: dict[str, Any]) -> list[str]:
  codes: list[str] = []
  for p in (picks or {}).get('picks') or []:
    code = p.get('code')
    if code and code not in codes:
      codes.append(code)
  row_list = list(rows.values()) if isinstance(rows, dict) else list(rows or [])
  stocks = sorted(
      (r for r in row_list if r.get('type') in ('股票', 'ADR')),
      key=lambda r: -(r.get('value') or 0.0),
  )
  etfs = sorted(
      (r for r in row_list if r.get('type') == 'ETF'),
      key=lambda r: -(r.get('value') or 0.0),
  )
  for r in stocks[:TOP_STOCKS] + etfs[:TOP_ETFS]:
    code = r.get('code')
    if code and code not in codes:
      codes.append(code)
  return codes


def _us_session_safe(morning_payload: dict[str, Any]) -> dict[str, Any]:
  try:
    import morning  # pylint: disable=import-outside-toplevel
    sess = morning.us_session()
    if isinstance(sess, dict) and sess:
      return sess
  except Exception:  # pylint: disable=broad-except
    pass
  sess_fallback = morning_payload.get('us_session')
  return sess_fallback if isinstance(sess_fallback, dict) else {}


def _api_snapshot() -> tuple[dict[str, Any], list[str], str | None]:
  import snapshot  # pylint: disable=import-outside-toplevel
  rows = snapshot.get_rows() or {}
  universe = snapshot.get_payload('universe') or {}
  market = dict(snapshot.get_payload('market') or {})
  cached_news = snapshot.market_news_cached()
  if cached_news or 'news' not in market:
    market['news'] = cached_news or []
  picks = snapshot.get_payload('picks') or {}
  industries = snapshot.get_payload('industries') or {}
  etfs = snapshot.get_payload('etfs') or {}
  morning_data = snapshot.morning_cached(force=False) or snapshot.get_payload('morning') or {}
  data_date = universe.get('date') or market.get('date')
  an = snapshot.db.get_kv('analytics', {}) or {}
  version = release_mgr.current_version()
  rel = release_mgr.load_releases()
  us_sess = _us_session_safe(morning_data)
  api: dict[str, Any] = {
      '/api/meta': {
          'version': version,
          'data_date': data_date,
          'updated_at': an.get('updated_at'),
          'static': True,
          'is_intraday': bool(an.get('is_intraday')),
          'quote_time': an.get('quote_time'),
          'us_session': us_sess,
          'status': {'state': 'idle', 'step': '', 'progress': 1.0, 'message': '', 'errors': []},
          'counts': an.get('counts') or {},
          'next_update': None,
          'schedule': config.SCHEDULE_TEXT,
          'schedule_slots': config.SCHEDULE_SLOTS,
          'disclaimer': config.DISCLAIMER,
      },
      '/api/universe': universe,
      '/api/market': market,
      '/api/picks': picks,
      '/api/industries': industries,
      '/api/etfs': etfs,
      '/api/morning': morning_data,
      '/api/release_status': {
          'static': True,
          'current_version': version,
          'has_changes': False,
          'releases': rel.get('releases', []),
      },
  }
  for ch in industries.get('chains') or []:
    cid = ch.get('id') if isinstance(ch, dict) else None
    if not cid:
      continue
    try:
      detail = snapshot.chain_detail(cid)
      if detail:
        api[f'/api/industry/{cid}'] = detail
    except Exception:  # pylint: disable=broad-except
      continue
  codes = _full_codes(rows, picks)
  done: list[str] = []
  for code in codes:
    try:
      detail = snapshot.stock_detail(code, 'D', '1y', network=False)
      if not detail or not detail.get('bars'):
        continue
      slim_detail = dict(detail)
      slim_detail.pop('ind', None)
      api[f'/api/stock/{code}'] = slim_detail
      analysis = snapshot.stock_analysis(code, 'D')
      if analysis:
        api[f'/api/stock/{code}/analysis'] = analysis
      done.append(code)
    except Exception:  # pylint: disable=broad-except
      continue
  return api, done, data_date


def _js_json(obj: Any) -> str:
  text = json.dumps(obj, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
  return text.replace('</', '<\\/').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


def _json_island(el_id: str, global_name: str, obj: Any) -> str:
  """Embeds a big payload as an inert JSON <script> parsed once with JSON.parse."""
  text = json.dumps(obj, ensure_ascii=False, separators=(',', ':'), allow_nan=False).replace('<', '\\u003c')
  return (f'<script type="application/json" id="{el_id}">{text}</script>\n'
          f'<script>(function () {{ var e = document.getElementById("{el_id}"); '
          f'window.{global_name} = JSON.parse(e.textContent); e.remove(); }})();</script>')


def _assemble(api: dict[str, Any], static_info: dict[str, Any]) -> str:
  index_fp = os.path.join(config.STATIC_DIR, 'index.html')
  if os.path.isfile(index_fp):
    with open(index_fp, encoding='utf-8') as f:
      html = f.read()
  else:
    html = _FALLBACK_HTML

  css_fp = os.path.join(config.STATIC_DIR, 'app.css')
  css = ''
  if os.path.isfile(css_fp):
    with open(css_fp, encoding='utf-8') as f:
      css = f.read()
  html = re.sub(r'<link[^>]+href="[^"]*app\.css[^"]*"[^>]*>', lambda _: f'<style>\n{css}\n</style>', html)

  srcs = re.findall(r'<script\s+src="([^"]+)"\s*>\s*</script>', html)
  blocks = [
      '<script>window.US_STATIC = ' + _js_json(static_info) + '; window.TW_STATIC = window.US_STATIC;</script>',
      _json_island('usStaticApi', '__STATIC_API__', api),
  ]
  for src in srcs:
    rel = src.split('?')[0].lstrip('/')
    rel = rel[len('static/'):] if rel.startswith('static/') else rel
    fp = os.path.join(config.STATIC_DIR, rel)
    if not os.path.isfile(fp):
      blocks.append(f'<script>/* skipped missing: {rel} */</script>')
      continue
    with open(fp, encoding='utf-8') as f:
      code = f.read().replace('</script', '<\\/script')
    blocks.append(f'<script>/* {rel} */\n{code}\n</script>')

  html = re.sub(r'\s*<script\s+src="[^"]+"\s*>\s*</script>', '', html)
  idx = html.rfind('</body>')
  if idx >= 0:
    html = html[:idx] + '\n' + '\n'.join(blocks) + '\n' + html[idx:]
  else:
    html = html + '\n' + '\n'.join(blocks) + '\n'
  html = html.replace('<head>', '<head>\n  <meta name="generator" content="美股戰情室 static build">', 1)
  return html


def build(force: bool = False) -> dict[str, Any]:
  """Builds dist/index.html unless the existing bundle is already fresh."""
  with _LOCK:
    cur = info()
    if cur and cur.get('fresh') and not force:
      return cur
    t0 = time.time()
    api, codes, data_date = _api_snapshot()
    version = release_mgr.current_version()
    built_at = dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat(timespec='seconds')
    static_info = {
        'version': version,
        'built_at': built_at,
        'data_date': data_date,
        'stocks_full': len(codes),
        'full_codes': codes,
    }
    html = _assemble(api, static_info)
    leak = _FORBIDDEN.search(html)
    if leak:
      raise RuntimeError(f'靜態檔含有內部網址、路徑或帳號字串：{leak.group(0)}，已停止打包')
    os.makedirs(DIST_DIR, exist_ok=True)
    tmp = OUT_HTML + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
      f.write(html)
      f.flush()
      os.fsync(f.fileno())
    os.replace(tmp, OUT_HTML)
    data = {
        'version': version,
        'data_date': data_date,
        'built_at': built_at,
        'data_updated_at': (api.get('/api/meta') or {}).get('updated_at'),
        'bytes': os.path.getsize(OUT_HTML),
        'stocks_full': len(codes),
        'code_hash': _code_hash(),
        'seconds': round(time.time() - t0, 1),
    }
    info_tmp = INFO_JSON + '.tmp'
    with open(info_tmp, 'w', encoding='utf-8') as f:
      json.dump(data, f, ensure_ascii=False, indent=2)
      f.flush()
      os.fsync(f.fileno())
    os.replace(info_tmp, INFO_JSON)
    data['fresh'] = True
    return data


build_all = build


if __name__ == '__main__':
  print(json.dumps(build(force='--force' in sys.argv), ensure_ascii=False, indent=2))
