"""Builds and caches every API payload of 美股戰情室 (SPEC §4).

Units: prices USD; `vol` shares; `value` (turnover) and `mcap` in 億美元 (USD / 1e8).
Network access is limited to on-demand helpers (stock detail fundamentals, long history,
news); `build_all()` is pure DB -> JSON computation.
"""
from __future__ import annotations

import datetime as dt
import json
import math
import os
import threading
import time
import traceback
from typing import Any

import config
import db
import etf_hub
import morning
import scoring
import ta
from sources import chains_us
from sources import cnyes_us
from sources import nasdaq
from sources import news_us
from sources import universe_curated as uc

TZ = dt.timezone(dt.timedelta(hours=8))
PAYLOAD_NAMES = ('universe', 'market', 'picks', 'industries', 'etfs', 'morning')
FIELDS = [
    'code', 'name', 'en_name', 'market', 'industry', 'sub_industry', 'type', 'index_tags',
    'close', 'chg', 'pct', 'open', 'high', 'low', 'vol', 'value', 'mcap',
    'r5', 'r20', 'r60', 'r120', 'r250', 'hi52', 'lo52', 'dist_hi52',
    'ma_bits', 'ma20', 'ma60', 'rsi', 'k', 'd', 'macd_hist', 'bias20', 'vol_ratio', 'atr_pct',
    'pe', 'fwd_pe', 'peg', 'pb', 'yld',
    'eps_ttm', 'eps_q', 'eps_q_label', 'eps_yoy', 'eps_surprise',
    'rev_q_label', 'rev_yoy', 'rev_qoq', 'gross_margin', 'op_margin',
    'inst_own_pct', 'target_price', 'target_upside', 'analyst_rating', 'analyst_buy_pct',
    'score', 'rank', 'f_earn', 'f_inst', 'f_mom', 'f_val', 'f_vol',
    'tech_score', 'signals', 'risk',
]
FUND_KINDS = ('summary', 'eps', 'fin', 'analyst', 'inst', 'div')
_LOCK = threading.RLock()
_MEM: dict[str, Any] = {'rows': {}, 'payloads': {}, 'version': 0}


# ------------------------------------------------------------------ helpers --

def _ok(x: Any) -> bool:
  return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _r(x: Any, nd: int = 2) -> float | None:
  return round(float(x), nd) if _ok(x) else None


def _now_iso() -> str:
  return dt.datetime.now(TZ).isoformat(timespec='seconds')


def clean(obj: Any) -> Any:
  """Recursively replaces NaN/inf with None and sets with sorted lists (JSON-safe)."""
  if isinstance(obj, float):
    return obj if math.isfinite(obj) else None
  if isinstance(obj, dict):
    return {k: clean(v) for k, v in obj.items()}
  if isinstance(obj, (list, tuple)):
    return [clean(v) for v in obj]
  if isinstance(obj, set):
    return sorted(obj)
  return obj


def _ret(closes: list[float], n: int) -> float | None:
  if len(closes) <= n or not closes[-1 - n]:
    return None
  return _r((closes[-1] / closes[-1 - n] - 1) * 100)


def _write_json(name: str, obj: Any) -> None:
  os.makedirs(config.SNAP_DIR, exist_ok=True)
  tmp = os.path.join(config.SNAP_DIR, f'{name}.json.tmp')
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(clean(obj), f, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
  os.replace(tmp, os.path.join(config.SNAP_DIR, f'{name}.json'))


def _mini(r: dict[str, Any]) -> dict[str, Any]:
  return {'code': r['code'], 'name': r.get('name'), 'pct': r.get('pct')}


def _rating_zh(buy_pct: float | None, n: int) -> str | None:
  if not n or buy_pct is None:
    return None
  if buy_pct >= 75:
    return '強力買進 (Buy)'
  if buy_pct >= 55:
    return '買進 (Moderate Buy)'
  if buy_pct >= 30:
    return '持有 (Hold)'
  return '賣出 (Sell)'


def quarter_label(period_end: str) -> str:
  try:
    y, m = int(period_end[:4]), int(period_end[5:7])
  except (TypeError, ValueError):
    return period_end or ''
  return f'{y}Q{(m - 1) // 3 + 1}'


# ----------------------------------------------------------- data loading --

def load_meta() -> dict[str, dict[str, Any]]:
  """Stock master rows from DB merged over the curated universe."""
  out: dict[str, dict[str, Any]] = {}
  for e in uc.all_entries():
    out[e['code']] = dict(e)
  for (code, name, en_name, market, typ, ind, sub, tags, country, ipo, nsec, nind,
       mcap) in db.query('SELECT code, name, en_name, market, type, industry, sub_industry, '
                         'index_tags, country, ipo_year, nasdaq_sector, nasdaq_industry, mcap '
                         'FROM stocks'):
    m = out.setdefault(code, {'code': code})
    try:
      tag_list = json.loads(tags) if tags else None
    except ValueError:
      tag_list = None
    for k, v in (('name', name), ('en_name', en_name), ('market', market), ('type', typ),
                 ('industry', ind), ('sub_industry', sub), ('index_tags', tag_list),
                 ('country', country), ('ipo_year', ipo), ('nasdaq_sector', nsec),
                 ('nasdaq_industry', nind), ('mcap', mcap)):
      if v not in (None, '', []) and (k not in m or not m.get(k) or k in ('mcap', 'country', 'ipo_year',
                                                                         'nasdaq_sector', 'nasdaq_industry')):
        m[k] = v
  return out


def load_all_bars(days: int = 320) -> tuple[list[str], dict[str, list[list]]]:
  dates = db.trading_dates(days)
  if not dates:
    return [], {}
  by: dict[str, list[list]] = {}
  for code, d, o, h, l, c, v in db.query(
      'SELECT code, date, open, high, low, close, vol FROM daily WHERE date >= ? ORDER BY code, date',
      (dates[0],)):
    if c:
      by.setdefault(code, []).append([d, o or c, h or c, l or c, c, v or 0])
  return dates, by


def load_index(name: str, limit: int = 400) -> list[list]:
  rows = db.query('SELECT date, open, high, low, close, vol FROM index_daily WHERE name=? '
                  'ORDER BY date DESC LIMIT ?', (name, limit))
  return [list(r) for r in rows[::-1]]


def earnings_by_code() -> dict[str, dict[str, Any]]:
  out: dict[str, dict[str, Any]] = {}
  for it in db.get_kv('earnings_cal', []) or []:
    c = it.get('code')
    if c and (c not in out or it.get('date', '') < out[c].get('date', '')):
      out[c] = it
  return out


# --------------------------------------------------------- fundamentals ----

def fund_features(code: str, close: float | None, f: dict[str, Any],
                  today: str | None = None) -> dict[str, Any]:
  """Derives valuation / earnings / analyst features from cached Nasdaq fundamentals."""
  out: dict[str, Any] = {}
  summ = f.get('summary') or {}
  ep = f.get('eps') or {}
  qs = [q for q in ep.get('quarters') or [] if _ok(q.get('actual'))]
  up = [u for u in ep.get('upcoming') or [] if _ok(u.get('consensus'))]
  if qs:
    last = qs[-1]
    out['eps_q'] = _r(last['actual'])
    out['eps_cons'] = _r(last.get('consensus'))
    out['eps_q_label'] = last.get('q') or last.get('period')
    out['eps_surprise'] = _r(last.get('surprise_pct'))
    out['beat_count'] = sum(1 for q in qs[-4:] if _ok(q.get('consensus')) and q['actual'] > q['consensus'])
    if len(qs) >= 4:
      out['eps_ttm'] = _r(sum(q['actual'] for q in qs[-4:]))
    if len(qs) >= 5 and qs[-5]['actual'] and qs[-5]['actual'] > 0:
      out['eps_yoy'] = _r((qs[-1]['actual'] / qs[-5]['actual'] - 1) * 100, 1)
  if out.get('eps_ttm') is None and _ok(summ.get('eps_ttm')):
    out['eps_ttm'] = _r(summ['eps_ttm'])
  ttm = out.get('eps_ttm')
  fwd = sum(u['consensus'] for u in up[:4]) if len(up) >= 4 else None
  if out.get('eps_yoy') is None and _ok(fwd) and _ok(ttm) and ttm > 0:
    out['eps_yoy'] = _r((fwd / ttm - 1) * 100, 1)        # forward 4Q vs trailing 4Q
  if _ok(close) and close > 0:
    if _ok(ttm) and ttm > 0:
      out['pe'] = _r(close / ttm, 1)
    elif _ok(summ.get('pe')):
      out['pe'] = _r(summ['pe'], 1)
    if _ok(fwd) and fwd > 0:
      out['fwd_pe'] = _r(close / fwd, 1)
    elif _ok(summ.get('fwd_pe')):
      out['fwd_pe'] = _r(summ['fwd_pe'], 1)
  g = out.get('eps_yoy')
  if _ok(out.get('pe')) and _ok(g) and g > 0:
    out['peg'] = _r(out['pe'] / g, 2)
  out['yld'] = _r(summ.get('yld')) if _ok(summ.get('yld')) else None
  out['beta'] = _r(summ.get('beta'))
  if _ok(summ.get('target_1y')):
    out['target_1y'] = summ['target_1y']
  fin = f.get('fin') or {}
  qf = [q for q in fin.get('quarterly') or [] if _ok(q.get('rev'))]
  if qf:
    lq = qf[-1]
    out['rev_q_label'] = quarter_label(lq['period_end'])
    out['rev_q'] = lq['rev']
    if len(qf) >= 2 and qf[-2]['rev']:
      out['rev_qoq'] = _r((lq['rev'] / qf[-2]['rev'] - 1) * 100, 1)
    if len(qf) >= 5 and qf[-5]['rev']:
      out['rev_yoy'] = _r((lq['rev'] / qf[-5]['rev'] - 1) * 100, 1)
    if lq['rev']:
      if _ok(lq.get('gross')):
        out['gross_margin'] = _r(lq['gross'] / lq['rev'] * 100, 1)
      if _ok(lq.get('op')):
        out['op_margin'] = _r(lq['op'] / lq['rev'] * 100, 1)
      if _ok(lq.get('net')):
        out['net_margin'] = _r(lq['net'] / lq['rev'] * 100, 1)
  ann = [a for a in fin.get('annual') or [] if _ok(a.get('rev'))]
  if out.get('rev_yoy') is None and len(ann) >= 2 and ann[-2]['rev']:
    out['rev_yoy'] = _r((ann[-1]['rev'] / ann[-2]['rev'] - 1) * 100, 1)
  an = f.get('analyst') or {}
  n = (an.get('buy') or 0) + (an.get('hold') or 0) + (an.get('sell') or 0)
  tgt = an.get('target_mean') if _ok(an.get('target_mean')) else summ.get('target_1y')
  if _ok(tgt):
    out['target_price'] = _r(tgt)
    if _ok(close) and close > 0:
      out['target_upside'] = _r((tgt / close - 1) * 100, 1)
  out['analyst_n'] = n
  out['analyst_buy'] = an.get('buy') or 0
  out['analyst_buy_pct'] = _r((an.get('buy') or 0) / n * 100, 1) if n else None
  out['analyst_rating'] = _rating_zh(out['analyst_buy_pct'], n)
  inst = f.get('inst') or {}
  out['inst_own_pct'] = _r(inst.get('inst_own_pct'), 1)
  out['inst_flow'] = _r(inst.get('net_flow_ratio'), 4)
  return out


def load_fundamentals() -> dict[str, dict[str, Any]]:
  by: dict[str, dict[str, Any]] = {}
  for kind in FUND_KINDS:
    for code, data in db.all_fund(kind).items():
      by.setdefault(code, {})[kind] = data
  return by


def fetch_fundamentals(code: str, is_etf: bool = False, kinds: tuple[str, ...] | None = None) -> dict[str, Any]:
  """Fetches & caches Nasdaq fundamentals for one ticker (quarterly financials are merged)."""
  kinds = kinds or (('summary', 'div') if is_etf else FUND_KINDS)
  ac = 'etf' if is_etf else 'stocks'
  out: dict[str, Any] = {}
  for kind in kinds:
    try:
      if kind == 'summary':
        data = nasdaq.summary(code, ac)
      elif kind == 'eps':
        data = nasdaq.eps(code)
      elif kind == 'fin':
        data = nasdaq.financials(code)
        old = db.get_fund(code, 'fin') or {}
        merged = {q['period_end']: q for q in (old.get('quarterly') or []) if q.get('period_end')}
        for q in data.get('quarterly') or []:
          merged[q['period_end']] = q
        data['quarterly'] = [merged[k] for k in sorted(merged)][-12:]
        if not data.get('annual'):
          data['annual'] = old.get('annual') or []
      elif kind == 'analyst':
        data = nasdaq.analyst(code)
      elif kind == 'inst':
        data = nasdaq.institutional(code)
      elif kind == 'div':
        data = nasdaq.dividends(code, ac)
      else:
        continue
    except Exception:  # pylint: disable=broad-except
      continue
    if data:
      db.set_fund(code, kind, data)
      out[kind] = data
  return out


# ------------------------------------------------------------- build rows --

def _tech_row(bars: list[list]) -> dict[str, Any]:
  closes = [b[4] for b in bars]
  vols = [b[5] or 0 for b in bars]
  n = len(bars)
  out: dict[str, Any] = {'n_bars': n}
  try:
    ind = ta.compute_indicators(bars)
    q = ta.quick_signals(bars, ind)
  except Exception:  # pylint: disable=broad-except
    ind, q = {}, {}

  def last(key: str) -> float | None:
    s = ind.get(key) or []
    return s[-1] if s and _ok(s[-1]) else None

  c = closes[-1]
  out.update({
      'r5': _ret(closes, 5), 'r20': _ret(closes, 20), 'r60': _ret(closes, 60),
      'r120': _ret(closes, 120), 'r250': _ret(closes, 250) if n > 250 else _ret(closes, n - 1),
      'hi52': _r(max(b[2] for b in bars[-250:])), 'lo52': _r(min(b[3] for b in bars[-250:])),
      'ma20': _r(last('ma20')), 'ma60': _r(last('ma60')), 'rsi': _r(last('rsi14'), 1),
      'k': _r(last('k'), 1), 'd': _r(last('d'), 1), 'macd_hist': _r(last('hist'), 3),
      'ma_bits': int(q.get('ma_bits') or 0), 'tech_score': q.get('tech_score'),
      'stance_level': q.get('stance_level'), 'tech_signals': list(q.get('signals') or []),
      'support': q.get('support'), 'resistance': q.get('resistance'), 'atr': q.get('atr'),
  })
  out['dist_hi52'] = _r((c / out['hi52'] - 1) * 100) if out['hi52'] else None
  out['bias20'] = _r((c / out['ma20'] - 1) * 100) if out['ma20'] else None
  vm5, vm20 = last('vol_ma5'), last('vol_ma20')
  out['vol_ratio'] = _r(vm5 / vm20) if vm5 and vm20 else None
  out['atr_pct'] = _r(out['atr'] / c * 100) if _ok(out.get('atr')) and c else None
  vals = [b[4] * (b[5] or 0) / 1e8 for b in bars[-20:]]
  out['value20'] = _r(sum(vals) / len(vals), 3) if vals else 0.0
  vol = scoring.rolling_volatility(closes[-60:], 20)
  out['volat20'] = _r(vol[-1], 3) if vol and vol[-1] is not None else None
  ma20s = scoring.rolling_mean(closes, 20)
  if n >= 26 and ma20s[-1] and ma20s[-6]:
    out['ma20_slope'] = _r((ma20s[-1] / ma20s[-6] - 1) * 100, 3)
  obv = scoring.obv_series(closes, vols)
  out['obv_flow20'] = _r(scoring.obv_flow(obv, vols, n - 1), 4)
  return out


def _universe_row(code: str, meta: dict[str, Any], bars: list[list], quote: dict[str, Any] | None,
                  fund: dict[str, Any], earn: dict[str, Any] | None, today: str) -> dict[str, Any]:
  last = bars[-1]
  prev = bars[-2][4] if len(bars) >= 2 else None
  close = last[4]
  chg = close - prev if prev else None
  row: dict[str, Any] = {
      'code': code, 'name': meta.get('name') or code, 'en_name': meta.get('en_name') or '',
      'market': meta.get('market') or 'NASDAQ', 'industry': meta.get('industry') or '工業',
      'sub_industry': meta.get('sub_industry') or '其他', 'type': meta.get('type') or '股票',
      'index_tags': list(meta.get('index_tags') or []), 'date': last[0],
      'close': _r(close), 'chg': _r(chg), 'pct': _r(chg / prev * 100) if prev else None,
      'open': _r(last[1]), 'high': _r(last[2]), 'low': _r(last[3]), 'vol': int(last[5] or 0),
      'value': _r(close * (last[5] or 0) / 1e8),
  }
  mcap = (quote or {}).get('mcap') or meta.get('mcap')
  row['mcap'] = _r(mcap, 1) if _ok(mcap) and mcap > 0 else None
  row.update(_tech_row(bars))
  if row['type'] != 'ETF':
    row.update(fund_features(code, close, fund, today))
  else:
    summ = fund.get('summary') or {}
    if row['mcap'] is None and _ok(summ.get('aum')):
      row['mcap'] = _r(summ['aum'], 1)
    div = fund.get('div') or {}
    row['yld'] = _r(div.get('yld')) if _ok(div.get('yld')) else None
  if earn and earn.get('date'):
    try:
      row['next_earn_days'] = (dt.date.fromisoformat(earn['date']) - dt.date.fromisoformat(today)).days
      row['next_earn'] = earn['date']
    except ValueError:
      pass
  row.setdefault('pb', None)
  return row


# ---------------------------------------------------------------- build all --

def build_all(progress: Any = None, is_intraday: bool | None = None,
              quote_time: str | None = None) -> dict[str, Any]:
  """Recomputes every snapshot; writes JSON files and refreshes the memory cache."""
  t0 = time.time()

  def step(msg: str, p: float) -> None:
    if progress is not None:
      progress.set(step='計算指標與推薦', message=msg, progress=p)

  step('載入資料', 0.05)
  dates, bars_by = load_all_bars(320)
  if not dates:
    return {}
  data_date = dates[-1]
  today = dt.datetime.now(TZ).date().isoformat()
  meta = load_meta()
  funds = load_fundamentals()
  earn = earnings_by_code()
  quotes = {r[0]: {'mcap': r[1]} for r in db.query('SELECT code, mcap FROM quotes')}

  step('計算技術指標', 0.15)
  rows: dict[str, dict[str, Any]] = {}
  for code, bars in bars_by.items():
    m = meta.get(code)
    if not m or len(bars) < 5:
      continue
    try:
      rows[code] = _universe_row(code, m, bars, quotes.get(code), funds.get(code, {}),
                                 earn.get(code), today)
    except Exception:  # pylint: disable=broad-except
      traceback.print_exc()
  step('計算五因子分數', 0.5)
  ranked = scoring.score_universe(rows)
  for code, r in rows.items():
    r['risk'] = scoring.risk_tags(r)
    r['signals'] = scoring.signal_tags(r, r.get('tech_signals') or [])
  for c in ranked:
    rows[c]['_reasons'], rows[c]['_risks'] = scoring.reasons_for(rows[c])

  step('產生今日推薦', 0.6)
  picks = _build_picks(rows, ranked, bars_by)
  _save_picks(data_date, picks)
  step('Walk-forward 回測', 0.7)
  spx = load_index('spx', 400)
  bench = {b[0]: b[4] for b in spx}
  series = {c: {'dates': [b[0] for b in bars_by[c]], 'close': [b[4] for b in bars_by[c]],
                'vol': [b[5] or 0 for b in bars_by[c]], 'type': rows[c]['type']}
            for c in rows if c in bars_by}
  try:
    bt = scoring.backtest(series, bench, dates) if bench else {}
  except Exception:  # pylint: disable=broad-except
    traceback.print_exc()
    bt = {}
  picks_payload = _picks_payload(picks, bt, rows, data_date)

  step('整理市場、產業、ETF 與盤前資料', 0.85)
  market = _market_payload(rows, data_date)
  industries = _industries_payload(rows, data_date)
  etfs = etf_hub.build_payload(rows, {c: f.get('div') for c, f in funds.items() if f.get('div')},
                               {c: f.get('summary') for c, f in funds.items() if f.get('summary')},
                               today, data_date)
  try:
    morning_payload = build_morning_payload(rows, market, picks_payload, data_date)
  except Exception:  # pylint: disable=broad-except
    traceback.print_exc()
    morning_payload = (get_payload('morning') or {})
  universe = {'date': data_date, 'fields': FIELDS,
              'rows': [[clean(rows[c].get(f)) for f in FIELDS]
                       for c in sorted(rows, key=lambda c: -(rows[c].get('mcap') or 0))]}
  counts = {'stocks': sum(1 for r in rows.values() if r['type'] != 'ETF'),
            'etfs': sum(1 for r in rows.values() if r['type'] == 'ETF'),
            'eligible': len(ranked), 'days': len(dates)}
  if is_intraday is None:
    is_intraday = False
  market['is_intraday'] = bool(is_intraday)
  if quote_time:
    market['quote_time'] = quote_time
  payloads = {'universe': universe, 'market': market, 'picks': picks_payload,
              'industries': industries, 'etfs': etfs, 'morning': morning_payload}
  payloads = {k: clean(v) for k, v in payloads.items()}
  for k, v in payloads.items():
    _write_json(k, v)
  _write_json('reasons', {c: [rows[c].get('_reasons') or [], rows[c].get('_risks') or []] for c in ranked})
  with _LOCK:
    _MEM['rows'] = rows
    _MEM['payloads'] = payloads
    _MEM['version'] += 1
  db.set_kv('analytics', {'data_date': data_date, 'updated_at': _now_iso(), 'counts': counts,
                          'is_intraday': bool(is_intraday),
                          'quote_time': quote_time or f'{data_date} 16:00 ET',
                          'seconds': round(time.time() - t0, 1)})
  step(f'完成（{time.time() - t0:.0f} 秒）', 1.0)
  return payloads


def _stance_summary(r: dict[str, Any]) -> str:
  bits = r.get('ma_bits') or 0
  parts = []
  if bits & 64:
    parts.append('均線多頭排列')
  elif bits & 128:
    parts.append('均線空頭排列')
  elif bits & 4:
    parts.append('站上月線')
  else:
    parts.append('位於月線之下')
  vr = r.get('vol_ratio')
  if _ok(vr) and vr > 1.3 and (r.get('pct') or 0) > 0:
    parts.append('量增價揚')
  elif _ok(vr) and vr < 0.7:
    parts.append('量能收斂')
  rsi = r.get('rsi')
  if _ok(rsi) and rsi > 75:
    parts.append('RSI 過熱')
  elif _ok(rsi) and rsi < 30:
    parts.append('RSI 超賣')
  return '，'.join(parts)


def _build_picks(rows: dict[str, dict[str, Any]], ranked: list[str],
                 bars_by: dict[str, list[list]]) -> list[dict[str, Any]]:
  full_ranked = [c for c in ranked if all(rows[c].get('f_' + k) is not None for k in config.WEIGHTS)]
  rest_ranked = [c for c in ranked if c not in set(full_ranked)]
  ordered = (full_ranked + rest_ranked)[:config.PICK_TOP_N]
  picks = []
  for idx, code in enumerate(ordered, 1):
    r = rows[code]
    lv = scoring.levels(r['close'], r.get('support'), r.get('resistance'), r.get('atr'),
                        r.get('ma20'), r.get('hi52'))
    picks.append({
        'code': code, 'name': r['name'], 'market': r['market'], 'industry': r['industry'],
        'sub_industry': r['sub_industry'], 'index_tags': r.get('index_tags') or [],
        'close': r['close'], 'pct': r.get('pct'), 'score': r['score'], 'rank': idx,
        'factors': {k: (r.get('f_' + k) if r.get('f_' + k) is not None else 30) for k in config.WEIGHTS},
        'reasons': r.get('_reasons') or [], 'risks': r.get('_risks') or [], 'levels': lv,
        'tech': {'stance': ta.STANCES.get(r.get('stance_level') or 0, '中性'),
                 'score': r.get('tech_score'), 'summary': _stance_summary(r)},
        'signals': r.get('signals') or [],
        'spark': [_r(b[4]) for b in bars_by.get(code, [])[-60:]],
        'mcap': r.get('mcap'), 'pe': r.get('pe'), 'r20': r.get('r20'),
    })
  return picks


def _save_picks(date: str, picks: list[dict[str, Any]]) -> None:
  try:
    db.execute('DELETE FROM picks WHERE date=?', (date,))
    db.upsert_many('picks', ('date', 'rank', 'code', 'score', 'close', 'data'),
                   [(date, p['rank'], p['code'], p['score'], p['close'],
                     json.dumps({'name': p['name']}, ensure_ascii=False)) for p in picks])
  except Exception:  # pylint: disable=broad-except
    traceback.print_exc()


def _live_history(rows: dict[str, dict[str, Any]], data_date: str) -> list[dict[str, Any]]:
  """Tracks previously published daily picks against the latest close (true out-of-sample)."""
  out = []
  dates = [r[0] for r in db.query('SELECT DISTINCT date FROM picks WHERE date < ? ORDER BY date DESC '
                                   'LIMIT 20', (data_date,))]
  spx = {b[0]: b[4] for b in load_index('spx', 60)}
  spx_last = spx.get(data_date) or (list(spx.values())[-1] if spx else None)
  for d in dates:
    items = []
    for _, code, close in db.query('SELECT rank, code, close FROM picks WHERE date=? ORDER BY rank LIMIT 10',
                                   (d,)):
      r = rows.get(code)
      if not r or not close:
        continue
      items.append({'code': code, 'name': r['name'], 'entry': _r(close), 'last': r['close'],
                    'ret': _r((r['close'] / close - 1) * 100)})
    if not items:
      continue
    rets = [i['ret'] for i in items if i['ret'] is not None]
    b0 = spx.get(d)
    out.append({'date': d, 'kind': '實盤追蹤', 'avg_ret': _r(sum(rets) / len(rets)) if rets else None,
                'bench_ret': _r((spx_last / b0 - 1) * 100) if b0 and spx_last else None,
                'items': items})
  return out


def _picks_payload(picks: list[dict[str, Any]], bt: dict[str, Any], rows: dict[str, dict[str, Any]],
                   data_date: str) -> dict[str, Any]:
  bt = dict(bt or {})
  bt_hist = bt.pop('history', []) or []
  for h in bt_hist:
    for it in h.get('items') or []:
      it['name'] = (rows.get(it['code']) or {}).get('name') or it['code']
  return {
      'date': data_date, 'picks': picks,
      'method': {
          'weights': dict(config.WEIGHTS), 'factor_labels': dict(config.FACTOR_LABELS),
          'filters': ['20 日均成交額 ≥ 2,000 萬美元', f'股價 ≥ ${config.MIN_PRICE:.2f}',
                      '排除 ETF 與槓桿商品', f'至少 {config.MIN_HISTORY} 個交易日歷史資料'],
          'text': ('結合季報 EPS 驚喜與營收年增、華爾街目標價空間與機構買盤動能、技術面均線趨勢及'
                   '估值品質進行全市場百分位綜合排名。'),
      },
      'backtest': bt, 'history': _live_history(rows, data_date) + bt_hist,
  }


def _sector_stats(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
  tot_value = sum(r.get('value') or 0 for r in rows) or 1.0
  out = []
  for name, en in config.SECTORS.items():
    rs = [r for r in rows if r.get('industry') == name]
    if not rs:
      continue

    def wavg(key: str) -> float | None:
      num = den = 0.0
      for r in rs:
        v, w = r.get(key), r.get('mcap') or r.get('value') or 0
        if _ok(v) and w:
          num += v * w
          den += w
      return _r(num / den) if den else None

    val = sum(r.get('value') or 0 for r in rs)
    out.append({'name': name, 'en': en, 'count': len(rs), 'pct_1d': wavg('pct'), 'pct_5d': wavg('r5'),
                'pct_20d': wavg('r20'), 'value': _r(val, 1), 'value_share': _r(val / tot_value * 100, 1),
                'up': sum(1 for r in rs if (r.get('pct') or 0) > 0),
                'down': sum(1 for r in rs if (r.get('pct') or 0) < 0),
                'leaders': [_mini(r) for r in sorted(rs, key=lambda r: -(r.get('mcap') or 0))[:5]],
                'top': [_mini(r) for r in sorted(rs, key=lambda r: -(r.get('pct') or -99))[:5]]})
  out.sort(key=lambda s: -(s['value'] or 0))
  return out


def adr_rows(rows: dict[str, dict[str, Any]], usdtwd: float | None) -> list[dict[str, Any]]:
  out = []
  for code, m in uc.ADR_MAP.items():
    r = rows.get(code)
    if not r:
      continue
    implied = _r(r['close'] * usdtwd / m['ratio'], 2) if usdtwd and r.get('close') else None
    out.append({'code': code, 'name': r['name'], 'tw_code': m['tw_code'], 'tw_name': m['tw_name'],
                'ratio': m['ratio'], 'close': r['close'], 'pct': r.get('pct'),
                'implied_twd': implied, 'usdtwd': _r(usdtwd, 3)})
  return out


def _market_payload(rows: dict[str, dict[str, Any]], data_date: str) -> dict[str, Any]:
  indices = {}
  for key, info in config.INDICES.items():
    bars = load_index(key, 300)
    if not bars:
      continue
    c = bars[-1][4]
    p = bars[-2][4] if len(bars) >= 2 else None
    indices[key] = {'code': info['code'], 'name': info['name'], 'close': _r(c),
                    'chg': _r(c - p) if p else None, 'pct': _r((c / p - 1) * 100) if p else None,
                    'date': bars[-1][0], 'series': [[b[0], _r(b[4])] for b in bars[-250:]]}
  macro = {}
  for key, (code, name) in config.MACRO_ETFS.items():
    r = rows.get(code)
    if r:
      macro[key] = {'code': code, 'name': name, 'close': r['close'], 'pct': r.get('pct')}
  fx = load_index('usdtwd', 30)
  usdtwd = None
  if fx:
    usdtwd = fx[-1][4]
    p = fx[-2][4] if len(fx) >= 2 else None
    macro['usdtwd'] = {'code': 'USDTWD', 'name': '美元／台幣', 'close': _r(usdtwd, 3),
                       'pct': _r((usdtwd / p - 1) * 100) if p else None}
  eq = [r for r in rows.values() if r['type'] != 'ETF' and r.get('date') == data_date]
  if not eq:
    eq = [r for r in rows.values() if r['type'] != 'ETF']
  breadth = {'up': sum(1 for r in eq if (r.get('pct') or 0) > 0),
             'down': sum(1 for r in eq if (r.get('pct') or 0) < 0),
             'flat': sum(1 for r in eq if (r.get('pct') or 0) == 0),
             'new_hi52': sum(1 for r in eq if r.get('dist_hi52') is not None and r['dist_hi52'] >= -0.01),
             'new_lo52': sum(1 for r in eq if r.get('lo52') and r.get('close') and r['close'] <= r['lo52'] * 1.0001),
             'above_ma20': sum(1 for r in eq if (r.get('ma_bits') or 0) & 4), 'total': len(eq)}
  mag7 = []
  for code in uc.MAG7:
    r = rows.get(code)
    if r:
      mag7.append({'code': code, 'name': r['name'], 'close': r['close'], 'pct': r.get('pct'),
                   'mcap': r.get('mcap'), 'r20': r.get('r20'), 'pe': r.get('pe'), 'score': r.get('score'),
                   'spark': None})
  liquid = [r for r in eq if (r.get('value') or 0) >= 0.5]

  def hot(r: dict[str, Any]) -> dict[str, Any]:
    return {'code': r['code'], 'name': r['name'], 'close': r['close'], 'pct': r.get('pct'),
            'value': r.get('value')}

  return {
      'date': data_date, 'indices': indices, 'macro': macro, 'breadth': breadth,
      'turnover_total': _r(sum(r.get('value') or 0 for r in eq), 1),
      'mag7': mag7, 'adrs': adr_rows(rows, usdtwd), 'sectors': _sector_stats(eq),
      'hot': {'gainers': [hot(r) for r in sorted(liquid, key=lambda r: -(r.get('pct') or 0))[:12]],
              'losers': [hot(r) for r in sorted(liquid, key=lambda r: (r.get('pct') or 0))[:12]],
              'value': [hot(r) for r in sorted(eq, key=lambda r: -(r.get('value') or 0))[:12]]},
      'news': [],
  }


def _chain_members(ch: dict[str, Any]) -> list[tuple[str, str, str, str]]:
  out = []
  for s in ch.get('streams') or []:
    for seg in s.get('segments') or []:
      for item in seg.get('stocks') or []:
        code, role = (item[0], item[1]) if isinstance(item, (list, tuple)) else (item.get('code'), item.get('role', ''))
        out.append((code, role, s.get('stream'), seg.get('name')))
  return out


def _industries_payload(rows: dict[str, dict[str, Any]], data_date: str) -> dict[str, Any]:
  eq = [r for r in rows.values() if r['type'] != 'ETF']
  chains = []
  for ch in chains_us.CHAINS:
    mem = _chain_members(ch)
    seen: set[str] = set()
    rs = []
    streams: dict[str, int] = {}
    for code, _, stream, _ in mem:
      streams[stream] = streams.get(stream, 0) + 1
      if code in rows and code not in seen:
        seen.add(code)
        rs.append(rows[code])
    p1 = [r['pct'] for r in rs if _ok(r.get('pct'))]
    p20 = [r['r20'] for r in rs if _ok(r.get('r20'))]
    chains.append({'id': ch['id'], 'name': ch['name'], 'icon': ch.get('icon', ''),
                   'summary': ch.get('summary', ''), 'pct_1d': _r(sum(p1) / len(p1)) if p1 else None,
                   'pct_20d': _r(sum(p20) / len(p20)) if p20 else None, 'stock_count': len(seen),
                   'streams': streams,
                   'leaders': [_mini(r) for r in sorted(rs, key=lambda r: -(r.get('pct') or -99))[:4]]})
  return {'date': data_date, 'sectors': _sector_stats(eq), 'chains': chains}


def chain_detail(chain_id: str) -> dict[str, Any] | None:
  ch = chains_us.get_chain(chain_id)
  if not ch:
    return None
  rows = get_rows()
  streams = []
  for s in ch.get('streams') or []:
    segs = []
    for seg in s.get('segments') or []:
      stocks = []
      for item in seg.get('stocks') or []:
        code, role = (item[0], item[1]) if isinstance(item, (list, tuple)) else (item.get('code'), item.get('role', ''))
        r = rows.get(code) or {}
        m = uc.get(code) or {}
        stocks.append({'code': code, 'name': r.get('name') or m.get('name') or code,
                       'close': r.get('close'), 'pct': r.get('pct'), 'r20': r.get('r20'),
                       'pe': r.get('pe'), 'mcap': r.get('mcap'), 'score': r.get('score'), 'role': role})
      segs.append({'name': seg.get('name'), 'desc': seg.get('desc', ''), 'stocks': stocks})
    streams.append({'stream': s.get('stream'), 'desc': s.get('desc', ''), 'segments': segs})
  return {'id': ch['id'], 'name': ch['name'], 'icon': ch.get('icon', ''), 'summary': ch.get('summary', ''),
          'tw_link_note': ch.get('tw_link_note', ''), 'streams': streams}


# ----------------------------------------------------------------- morning --

def extended_list() -> list[dict[str, Any]]:
  cut = time.time() - 20 * 3600
  return [{'code': c, 'ext_type': t, 'ext_price': p, 'ext_pct': pc, 'vol': v}
          for c, t, p, pc, v, fa in db.query('SELECT code, ext_type, ext_price, ext_pct, vol, fetched_at '
                                             'FROM extended') if (fa or 0) >= cut and _ok(pc)]


def build_morning_payload(rows: dict[str, dict[str, Any]], market: dict[str, Any],
                          picks_payload: dict[str, Any], data_date: str) -> dict[str, Any]:
  import updater  # pylint: disable=import-outside-toplevel
  earnings = []
  for it in db.get_kv('earnings_cal', []) or []:
    r = rows.get(it.get('code')) or {}
    m = uc.get(it.get('code')) or {}
    earnings.append(dict(it, name=r.get('name') or m.get('name') or it.get('en_name') or it.get('code')))
  ctx = {'now': dt.datetime.now(TZ), 'data_date': data_date, 'rows': rows, 'market': market,
         'picks': picks_payload.get('picks') or [], 'extended': extended_list(),
         'earnings': earnings, 'news': market_news_cached(network=False),
         'is_trading_day': updater.is_trading_day}
  return morning.build_morning(ctx)


_MORNING_REFRESHING = threading.Lock()


def morning_cached(force: bool = False) -> dict[str, Any]:
  """Pre/post-market briefing; `force` refetches news + extended-hours quotes first."""
  cur = get_payload('morning')
  if not force and cur:
    return cur
  with _MORNING_REFRESHING:
    if force:
      try:
        refresh_morning_inputs()
      except Exception:  # pylint: disable=broad-except
        traceback.print_exc()
    rows = get_rows()
    if not rows:
      return cur or {}
    market = get_payload('market') or {}
    picks = get_payload('picks') or {}
    data_date = (get_payload('universe') or {}).get('date') or ''
    fresh = clean(build_morning_payload(rows, market, picks, data_date))
    _write_json('morning', fresh)
    with _LOCK:
      _MEM['payloads']['morning'] = fresh
      _MEM['version'] += 1
    return fresh


def refresh_morning_inputs(max_codes: int = 80) -> None:
  """Network: market news, earnings calendar (7 days) and extended-hours quotes."""
  market_news_cached(max_age=0)
  fetch_earnings_calendar(7)
  rows = get_rows()
  codes = list(uc.MAG7) + list(uc.ADR_MAP)
  codes += [p['code'] for p in (get_payload('picks') or {}).get('picks') or []]
  codes += [c for c, _ in sorted(((c, r.get('mcap') or 0) for c, r in rows.items() if r.get('type') != 'ETF'),
                                 key=lambda x: -x[1])]
  seen, uniq = set(), []
  for c in codes:
    if c not in seen:
      seen.add(c)
      uniq.append(c)
  fetch_extended(uniq[:max_codes])


def fetch_extended(codes: list[str], markettype: str | None = None) -> int:
  from concurrent.futures import ThreadPoolExecutor  # pylint: disable=import-outside-toplevel
  if markettype is None:
    st = morning.us_session(dt.datetime.now(TZ))
    markettype = 'pre' if st.get('state') == 'pre' else 'post'

  def one(code: str) -> tuple | None:
    try:
      e = nasdaq.extended(code, markettype)
    except Exception:  # pylint: disable=broad-except
      return None
    if not e or not _ok(e.get('ext_pct')):
      return None
    return (code, e['ext_type'], e.get('ext_price'), e['ext_pct'], e.get('vol'), time.time())

  with ThreadPoolExecutor(max_workers=config.FUND_WORKERS) as ex:
    res = [r for r in ex.map(one, codes) if r]
  db.upsert_many('extended', ('code', 'ext_type', 'ext_price', 'ext_pct', 'vol', 'fetched_at'), res)
  return len(res)


def fetch_earnings_calendar(days: int = 7) -> int:
  today = dt.datetime.now(TZ).date()
  items: list[dict[str, Any]] = []
  for k in range(-1, days + 1):
    d = today + dt.timedelta(days=k)
    if d.weekday() >= 5:
      continue
    try:
      items.extend(nasdaq.earnings_calendar(d.isoformat()))
    except Exception:  # pylint: disable=broad-except
      continue
  if items:
    items = [it for it in items if (it.get('mcap') or 0) >= 20 or uc.get(it['code'])]
    items.sort(key=lambda x: (x['date'], -(x.get('mcap') or 0)))
    db.set_kv('earnings_cal', items[:400])
  return len(items)


def market_news_cached(max_age: float = config.NEWS_TTL_SEC, network: bool = True) -> list[dict[str, Any]]:
  row = db.query_one("SELECT fetched_at, data FROM news_cache WHERE code='_market'")
  if row and (time.time() - row[0] < max_age or not network):
    try:
      return json.loads(row[1])
    except ValueError:
      pass
  if not network:
    return []
  try:
    items = news_us.market_news(30)
  except Exception:  # pylint: disable=broad-except
    items = []
  if items:
    db.execute('INSERT OR REPLACE INTO news_cache VALUES (?,?,?)',
               ('_market', time.time(), json.dumps(items, ensure_ascii=False)))
    return items
  return json.loads(row[1]) if row else []


# ------------------------------------------------------------ memory cache --

def get_rows() -> dict[str, dict[str, Any]]:
  with _LOCK:
    rows = _MEM['rows']
  if not rows:
    _load_from_disk()
    with _LOCK:
      rows = _MEM['rows']
  return rows


def get_full_row(code: str) -> dict[str, Any] | None:
  return get_rows().get(code)


def get_payload(name: str) -> dict[str, Any] | None:
  with _LOCK:
    p = _MEM['payloads'].get(name)
  if p is None:
    _load_from_disk()
    with _LOCK:
      p = _MEM['payloads'].get(name)
  return p


def version() -> int:
  with _LOCK:
    return _MEM['version']


def _load_from_disk() -> None:
  payloads = {}
  for k in PAYLOAD_NAMES:
    fp = os.path.join(config.SNAP_DIR, f'{k}.json')
    try:
      with open(fp, encoding='utf-8') as f:
        payloads[k] = json.load(f)
    except (OSError, ValueError):
      pass
  rows: dict[str, dict[str, Any]] = {}
  u = payloads.get('universe')
  if u:
    fields = u.get('fields') or []
    for r in u.get('rows') or []:
      d = dict(zip(fields, r))
      rows[d['code']] = d
  try:
    with open(os.path.join(config.SNAP_DIR, 'reasons.json'), encoding='utf-8') as f:
      for code, (rs, rk) in json.load(f).items():
        if code in rows:
          rows[code]['_reasons'], rows[code]['_risks'] = rs, rk
  except (OSError, ValueError):
    pass
  if payloads:
    with _LOCK:
      if not _MEM['payloads']:
        _MEM['payloads'] = payloads
        _MEM['rows'] = rows
        _MEM['version'] += 1


# ----------------------------------------------------------- stock detail ---

RANGE_BARS = {'D': {'3m': 66, '6m': 130, '1y': 252, '2y': 504, '5y': 1260},
              'W': {'3m': 14, '6m': 27, '1y': 53, '2y': 105, '5y': 262},
              'M': {'3m': 4, '6m': 7, '1y': 13, '2y': 25, '5y': 61}}


def stock_meta(code: str) -> dict[str, Any] | None:
  row = db.query_one('SELECT code, name, en_name, market, type, industry, sub_industry, index_tags, '
                     'country, ipo_year, nasdaq_sector, nasdaq_industry, mcap FROM stocks WHERE code=?',
                     (code,))
  base = dict(uc.get(code) or {})
  if row:
    keys = ('code', 'name', 'en_name', 'market', 'type', 'industry', 'sub_industry', 'index_tags',
            'country', 'ipo_year', 'nasdaq_sector', 'nasdaq_industry', 'mcap')
    for k, v in zip(keys, row):
      if k == 'index_tags':
        try:
          v = json.loads(v) if v else None
        except ValueError:
          v = None
      if v not in (None, '', []) and not (k in ('name', 'industry', 'sub_industry') and base.get(k)):
        base[k] = v
  return base or None


def stock_bars(code: str, long: bool = False, network: bool = True) -> list[list]:
  if long and network:
    ensure_long_history(code)
  return [list(r) for r in db.query('SELECT date, open, high, low, close, vol FROM daily WHERE code=? '
                                    'ORDER BY date', (code,)) if r[4]]


def ensure_long_history(code: str, years: int = config.LONG_HISTORY_YEARS) -> None:
  key = f'long_{code}'
  if db.fetched_age('cnyes_long', key) < 7 * 86400:
    return
  first = db.query_one('SELECT MIN(date) FROM daily WHERE code=?', (code,))
  start = (dt.date.today() - dt.timedelta(days=365 * years - 30)).isoformat()
  if first and first[0] and first[0] <= start:
    db.mark_fetched('cnyes_long', key)
    return
  try:
    bars, _ = cnyes_us.history(code, 365 * years)
  except Exception:  # pylint: disable=broad-except
    return
  if bars:
    db.upsert_many('daily', ('code', 'date', 'open', 'high', 'low', 'close', 'vol'),
                   [(code, *b) for b in bars])
    db.mark_fetched('cnyes_long', key)


def _ensure_fund(code: str, is_etf: bool, network: bool) -> dict[str, Any]:
  f = {k: db.get_fund(code, k) for k in FUND_KINDS}
  f = {k: v for k, v in f.items() if v}
  if not network:
    return f
  need = ('summary', 'div') if is_etf else FUND_KINDS
  stale = [k for k in need if db.fund_age(code, k) > config.FUND_TTL_DAYS * 86400]
  if stale:
    f.update(fetch_fundamentals(code, is_etf, tuple(stale)))
  return f


def _profile_desc(m: dict[str, Any], r: dict[str, Any]) -> str:
  if m.get('desc'):
    return m['desc']
  parts = [f'{m.get("name") or m.get("code")}為美國{m.get("market") or ""}上市的'
           f'{m.get("industry") or ""}類股，細分領域為「{m.get("sub_industry") or "其他"}」']
  if m.get('index_tags'):
    tag_zh = {'SP500': '標普 500', 'NDX100': '那斯達克 100', 'SOX': '費城半導體', 'MAG7': '七巨頭',
              'ADR': '美國存託憑證', 'DOW30': '道瓊工業'}
    parts.append('，名列' + '、'.join(tag_zh.get(t, t) for t in m['index_tags']) + '成分')
  return ''.join(parts) + '。'


def stock_detail(code: str, tf: str = 'D', rng: str = '2y', network: bool = True) -> dict[str, Any] | None:
  code = (code or '').upper()
  tf = tf if tf in ('D', 'W', 'M') else 'D'
  rng = rng if rng in ('3m', '6m', '1y', '2y', '5y', 'max') else '2y'
  m = stock_meta(code)
  if not m:
    return None
  daily = stock_bars(code, long=rng in ('5y', 'max') or tf == 'M', network=network)
  if not daily and network:
    try:
      bars, _ = cnyes_us.history(code, 500)
      if bars:
        db.upsert_many('daily', ('code', 'date', 'open', 'high', 'low', 'close', 'vol'),
                       [(code, *b) for b in bars])
        daily = bars
    except Exception:  # pylint: disable=broad-except
      daily = []
  if not daily:
    return None
  full = ta.resample(daily, tf) if tf != 'D' else daily
  ind = ta.compute_indicators(full)
  n = len(full) if rng == 'max' else RANGE_BARS[tf].get(rng, 504)
  bars = full[-n:]
  ind = {k: v[-n:] for k, v in ind.items()}
  rows = get_rows()
  u = rows.get(code) or {}
  is_etf = (m.get('type') == 'ETF')
  f = _ensure_fund(code, is_etf, network)
  last, prev = daily[-1], (daily[-2][4] if len(daily) >= 2 else None)
  close = last[4]
  feats = fund_features(code, close, f) if not is_etf else {}
  summ = f.get('summary') or {}
  quote = {'date': last[0], 'close': _r(close), 'chg': _r(close - prev) if prev else None,
           'pct': _r((close / prev - 1) * 100) if prev else None, 'open': _r(last[1]),
           'high': _r(last[2]), 'low': _r(last[3]), 'vol': int(last[5] or 0),
           'value': _r(close * (last[5] or 0) / 1e8),
           'hi52': u.get('hi52') or _r(max(b[2] for b in daily[-250:])),
           'lo52': u.get('lo52') or _r(min(b[3] for b in daily[-250:]))}
  mcap = u.get('mcap') or m.get('mcap') or summ.get('mcap') or summ.get('aum')
  adr = uc.ADR_MAP.get(code)
  profile = {
      'full_name': m.get('en_name') or '', 'exchange': summ.get('exchange') or m.get('market'),
      'sector': f'{m.get("industry") or ""}' + (f' ({m["nasdaq_sector"]})' if m.get('nasdaq_sector') else ''),
      'sub_industry': f'{m.get("sub_industry") or ""}' + (
          f' ({m["nasdaq_industry"]})' if m.get('nasdaq_industry') else ''),
      'country': m.get('country') or '', 'ipo_year': m.get('ipo_year') or '',
      'mcap': _r(mcap, 1), 'beta': _r(summ.get('beta')), 'website': m.get('website'),
      'desc': _profile_desc(m, u),
      'adr_info': ({'tw_code': adr['tw_code'], 'tw_name': adr['tw_name'], 'ratio': adr['ratio'],
                    'note': f'1 單位 {code} ADR = {adr["ratio"]} 股 {adr["tw_code"]} 普通股'} if adr else None),
  }
  if is_etf:
    em = etf_hub.etf_meta().get(code) or {}
    profile.update({'issuer': em.get('issuer'), 'category': em.get('category'),
                    'expense_ratio': summ.get('expense_ratio') or em.get('expense_ratio'),
                    'aum': summ.get('aum') or em.get('aum'), 'desc': em.get('desc') or profile['desc']})
  # Revenue history (億美元).
  qf = [q for q in ((f.get('fin') or {}).get('quarterly') or []) if _ok(q.get('rev'))]
  revenue = []
  for i, q in enumerate(qf):
    revenue.append({'q': quarter_label(q['period_end']), 'period': q['period_end'][:7], 'rev': _r(q['rev']),
                    'qoq': _r((q['rev'] / qf[i - 1]['rev'] - 1) * 100, 1) if i >= 1 and qf[i - 1]['rev'] else None,
                    'yoy': _r((q['rev'] / qf[i - 4]['rev'] - 1) * 100, 1) if i >= 4 and qf[i - 4]['rev'] else None,
                    'gross_margin': _r(q['gross'] / q['rev'] * 100, 1) if _ok(q.get('gross')) and q['rev'] else None,
                    'op_margin': _r(q['op'] / q['rev'] * 100, 1) if _ok(q.get('op')) and q['rev'] else None})
  ep = f.get('eps') or {}
  eps = [{'q': q.get('q'), 'period': q.get('period'), 'actual': _r(q.get('actual')),
          'consensus': _r(q.get('consensus')), 'surprise_pct': _r(q.get('surprise_pct'))}
         for q in ep.get('quarters') or []]
  divs = (f.get('div') or {}).get('rows') or []
  an = f.get('analyst') or {}
  inst = f.get('inst') or {}
  analyst = {'rating': feats.get('analyst_rating'), 'buy': an.get('buy'), 'hold': an.get('hold'),
             'sell': an.get('sell'), 'target_mean': _r(an.get('target_mean') or summ.get('target_1y')),
             'target_high': _r(an.get('target_high')), 'target_low': _r(an.get('target_low')),
             'upside_pct': feats.get('target_upside'), 'inst_own_pct': _r(inst.get('inst_own_pct'), 1),
             'inst_holders': [{'name': h.get('name'), 'shares': h.get('shares'), 'value': h.get('value'),
                               'chg_pct': _r(h.get('chg_pct'))} for h in (inst.get('holders') or [])[:10]]}
  sub = m.get('sub_industry')
  peers_all = [r for r in rows.values() if r['code'] != code and r.get('type') == m.get('type', '股票')
               and r.get('sub_industry') == sub]
  if len(peers_all) < 4:
    peers_all += [r for r in rows.values() if r['code'] != code and r.get('type') != 'ETF'
                  and r.get('industry') == m.get('industry') and r not in peers_all]
  peers = [{'code': r['code'], 'name': r['name'], 'close': r.get('close'), 'pct': r.get('pct'),
            'pe': r.get('pe'), 'fwd_pe': r.get('fwd_pe'), 'yld': r.get('yld'), 'r20': r.get('r20'),
            'mcap': r.get('mcap'), 'score': r.get('score')}
           for r in sorted(peers_all, key=lambda r: -(r.get('mcap') or 0))[:10]]
  pes = sorted(r['pe'] for r in peers_all if _ok(r.get('pe')) and r['pe'] > 0)
  score = None
  if u.get('score') is not None:
    score = {'score': u.get('score'), 'rank': u.get('rank'),
             'factors': {k: u.get('f_' + k) for k in config.WEIGHTS},
             'reasons': u.get('_reasons') or [], 'risks': u.get('_risks') or []}
  lq = qf[-1] if qf else {}
  return {
      'code': code, 'name': m.get('name') or code, 'en_name': m.get('en_name') or '',
      'market': m.get('market') or '', 'industry': m.get('industry') or '',
      'sub_industry': m.get('sub_industry') or '', 'type': m.get('type') or '股票',
      'index_tags': m.get('index_tags') or [], 'tf': tf, 'range': rng, 'adjusted': True,
      'profile': profile, 'quote': quote,
      'bars': [[b[0], _r(b[1], 4), _r(b[2], 4), _r(b[3], 4), _r(b[4], 4), int(b[5] or 0)] for b in bars],
      'ind': ind,
      'valuation': {'pe': feats.get('pe'), 'fwd_pe': feats.get('fwd_pe'), 'peg': feats.get('peg'),
                    'pb': None, 'yld': feats.get('yld') if not is_etf else u.get('yld'),
                    'eps_ttm': feats.get('eps_ttm'),
                    'pe_industry_median': _r(pes[len(pes) // 2], 1) if pes else None},
      'margins': ({'q': quarter_label(lq['period_end']), 'gross': feats.get('gross_margin'),
                   'operating': feats.get('op_margin'), 'net': feats.get('net_margin')} if lq else None),
      'revenue': revenue, 'eps': eps, 'eps_forecast': ep.get('upcoming') or [],
      'dividends': divs[:24], 'analyst': analyst, 'peers': peers,
      'chains': chains_us.chains_for_code(code), 'score': score,
      'signals': u.get('signals') or [], 'risk': u.get('risk') or [], 'tech_score': u.get('tech_score'),
  }


def stock_analysis(code: str, tf: str = 'D') -> dict[str, Any] | None:
  code = (code or '').upper()
  m = stock_meta(code)
  if not m:
    return None
  tf = tf if tf in ('D', 'W', 'M') else 'D'
  daily = stock_bars(code, long=(tf == 'M'))
  if not daily:
    return None
  bars = ta.resample(daily, tf) if tf in ('W', 'M') else daily[-500:]
  out = ta.analyze(bars, tf=tf)
  out['code'], out['name'] = code, m.get('name') or code
  return out


def stock_news(code: str) -> dict[str, Any] | None:
  code = (code or '').upper()
  m = stock_meta(code)
  if not m:
    return None
  row = db.query_one('SELECT fetched_at, data FROM news_cache WHERE code=?', (f'news:{code}',))
  if row and time.time() - row[0] < config.NEWS_TTL_SEC:
    items, fetched = json.loads(row[1]), row[0]
  else:
    try:
      items = news_us.stock_news(code, m.get('name') or '', m.get('en_name') or '')
    except Exception:  # pylint: disable=broad-except
      items = json.loads(row[1]) if row else []
    fetched = time.time()
    if items:
      db.execute('INSERT OR REPLACE INTO news_cache VALUES (?,?,?)',
                 (f'news:{code}', fetched, json.dumps(items, ensure_ascii=False)))
  return {'code': code, 'fetched_at': dt.datetime.fromtimestamp(fetched, TZ).isoformat(timespec='seconds'),
          'items': items}
