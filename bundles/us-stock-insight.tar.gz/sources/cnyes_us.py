"""鉅亨網 (cnyes) US market adapter: fast daily OHLCV history, batch quotes, zh names, USD/TWD.

Verified behaviour of `ws.api.cnyes.com/ws/api/v1/charting/history`:
* `from` MUST be the NEWER unix timestamp and `to` the OLDER one.
* Arrays `t, o, h, l, c, v` come back newest-first -> reversed to ascending here.
* Each `t[k]` is 00:00 UTC of the US trading date -> converted with UTC (never New York time).
"""
from __future__ import annotations

import datetime as dt
import math
import time
import urllib.parse
from typing import Any

import net
from sources import fetch_json_parallel

HIST_URL = ('https://ws.api.cnyes.com/ws/api/v1/charting/history?resolution={res}'
            '&symbol={sym}&from={frm}&to={to}&quote=1')
QUOTES_URL = 'https://ws.api.cnyes.com/ws/api/v1/quote/quotes/{codes}'
BATCH = 40


def cnyes_symbol(code: str) -> str:
  """Ticker -> cnyes symbol (`USS:NVDA:STOCK`); passes through already-qualified symbols."""
  code = (code or '').strip().upper()
  if ':' in code:
    return code
  return f'USS:{code}:STOCK'


def ts_to_date(ts: float | int) -> str:
  """cnyes bar timestamp (00:00 UTC of the trading date) -> 'YYYY-MM-DD'."""
  return dt.datetime.fromtimestamp(int(ts), dt.timezone.utc).strftime('%Y-%m-%d')


def _f(x: Any) -> float | None:
  try:
    v = float(str(x).replace(',', '').replace('+', '')) if isinstance(x, str) else float(x)
  except (TypeError, ValueError):
    return None
  return v if math.isfinite(v) else None


def parse_history(js: dict[str, Any]) -> tuple[list[list], dict[str, Any]]:
  """Parses a history response -> (ascending bars [date,o,h,l,c,vol], quote dict)."""
  data = (js or {}).get('data') or {}
  ts = data.get('t') or []
  o, h, l, c, v = (data.get(k) or [] for k in ('o', 'h', 'l', 'c', 'v'))
  bars: dict[str, list] = {}
  for i, t in enumerate(ts):
    try:
      cl = _f(c[i])
    except IndexError:
      continue
    if cl is None or cl <= 0:
      continue
    op = _f(o[i] if i < len(o) else None) or cl
    hi = _f(h[i] if i < len(h) else None) or cl
    lo = _f(l[i] if i < len(l) else None) or cl
    vol = _f(v[i] if i < len(v) else None) or 0.0
    hi, lo = max(hi, op, cl), min(lo, op, cl)
    bars[ts_to_date(t)] = [ts_to_date(t), round(op, 4), round(hi, 4), round(lo, 4), round(cl, 4),
                           int(round(vol))]
  out = [bars[d] for d in sorted(bars)]
  return out, parse_quote(data.get('quote') or {})


def parse_quote(q: dict[str, Any]) -> dict[str, Any]:
  """Normalizes a cnyes quote object (numeric field ids) into readable keys."""
  if not q:
    return {}
  sym = q.get('0') or q.get('800013') or ''
  close = _f(q.get('6'))
  prev = _f(q.get('21'))
  chg = _f(q.get('11'))
  pct = _f(q.get('56'))
  if pct is None and close and prev:
    pct = (close / prev - 1) * 100
  if chg is None and close and prev:
    chg = close - prev
  vol = _f(q.get('200013'))
  if vol is None:
    vol = _f(q.get('800001'))
  t = q.get('200007')
  return {
      'symbol': sym, 'code': (q.get('200010') or (sym.split(':')[1] if sym.count(':') >= 2 else sym)),
      'zh_name': (q.get('200009') or '').strip() or None,
      'close': close, 'prev': prev, 'chg': None if chg is None else round(chg, 4),
      'pct': None if pct is None else round(pct, 2),
      'open': _f(q.get('19')), 'high': _f(q.get('12')), 'low': _f(q.get('13')),
      'vol': vol, 'time': int(t) if isinstance(t, (int, float)) else None,
      'is_trading': bool(q.get('isTrading')),
  }


def history(code: str, days: int = 450, *, resolution: str = 'D',
            end: dt.datetime | None = None, timeout: float = 20.0,
            retries: int = 2) -> tuple[list[list], dict[str, Any]]:
  """Daily bars (ascending) covering roughly the last `days` calendar days + quote."""
  now = int((end or dt.datetime.now(dt.timezone.utc)).timestamp()) + 86400
  old = now - int(days) * 86400
  url = HIST_URL.format(res=resolution, sym=urllib.parse.quote(cnyes_symbol(code), safe=':.'),
                        frm=now, to=old)
  js = fetch_json_parallel(url, timeout=timeout, retries=retries)
  return parse_history(js)


def index_history(cnyes_sym: str, days: int = 450) -> tuple[list[list], dict[str, Any]]:
  return history(cnyes_sym, days)


def quotes(codes: list[str], timeout: float = 15.0) -> dict[str, dict[str, Any]]:
  """Batch real-time quotes keyed by the input code (40 symbols per request)."""
  out: dict[str, dict[str, Any]] = {}
  syms = [(c, cnyes_symbol(c)) for c in codes if c]
  for i in range(0, len(syms), BATCH):
    chunk = syms[i:i + BATCH]
    url = QUOTES_URL.format(codes=','.join(urllib.parse.quote(s, safe=':.') for _, s in chunk))
    try:
      js = fetch_json_parallel(url, timeout=timeout, retries=2)
    except net.FetchError:
      continue
    by_sym = {}
    for q in (js or {}).get('data') or []:
      pq = parse_quote(q)
      if pq.get('symbol'):
        by_sym[pq['symbol'].upper()] = pq
    for code, sym in chunk:
      if sym.upper() in by_sym:
        out[code] = by_sym[sym.upper()]
  return out


def usdtwd() -> dict[str, Any]:
  """USD/TWD spot quote {'close', 'chg', 'pct', 'time'} (empty dict on failure)."""
  try:
    q = quotes(['FX:USDTWD:FOREX']).get('FX:USDTWD:FOREX') or {}
  except Exception:  # pylint: disable=broad-except
    return {}
  return q


def usdtwd_history(days: int = 450) -> list[list]:
  try:
    bars, _ = history('FX:USDTWD:FOREX', days)
  except Exception:  # pylint: disable=broad-except
    return []
  return bars


def zh_name(code: str) -> str | None:
  """Chinese short name from cnyes (`quote['200009']`)."""
  try:
    q = quotes([code]).get(code) or {}
  except Exception:  # pylint: disable=broad-except
    return None
  return q.get('zh_name')


if __name__ == '__main__':
  t0 = time.time()
  b, q = history('NVDA', 20)
  print(len(b), b[-2:], q.get('zh_name'), q.get('close'), f'{time.time() - t0:.2f}s')
