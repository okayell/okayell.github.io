"""News adapters: 鉅亨網 `us_stock` / `wd_macro` market news + Google News RSS (zh-TW)."""
from __future__ import annotations

import datetime as dt
import email.utils
import html
import re
import urllib.parse
from typing import Any

import net

TZ = dt.timezone(dt.timedelta(hours=8))
CNYES_LIST = 'https://api.cnyes.com/media/api/v1/newslist/category/{cat}?limit={limit}'
_LOW_QUALITY = ('同學會', '操作明細', 'PTT', '批踢踢', '討論區', 'Dcard', '爆料')


def _iso(d: dt.datetime) -> str:
  return d.astimezone(TZ).replace(microsecond=0).isoformat()


def clean_title(t: str) -> str:
  t = html.unescape(re.sub(r'<[^>]+>', '', t or '')).strip()
  return re.sub(r'\s+', ' ', t)


def cnyes_news(category: str = 'us_stock', limit: int = 30) -> list[dict[str, Any]]:
  js = net.fetch_json(CNYES_LIST.format(cat=category, limit=limit), timeout=20)
  out = []
  for r in ((js.get('items') or {}).get('data') or [])[:limit]:
    try:
      t = dt.datetime.fromtimestamp(int(r.get('publishAt')), tz=dt.timezone.utc)
    except (TypeError, ValueError):
      continue
    out.append({'title': clean_title(r.get('title', '')),
                'link': f'https://news.cnyes.com/news/id/{r.get("newsId")}',
                'source': '鉅亨網', 'time': _iso(t),
                'summary': clean_title(r.get('summary') or '')[:160]})
  return out


def google_news(query: str, limit: int = 20) -> list[dict[str, Any]]:
  url = ('https://news.google.com/rss/search?q=' + urllib.parse.quote(query) +
         '&hl=zh-TW&gl=TW&ceid=TW:zh-Hant')
  doc = net.fetch_text(url, timeout=20)
  out = []
  for item in re.findall(r'<item>(.*?)</item>', doc, flags=re.S)[:limit]:
    title = clean_title((re.findall(r'<title>(.*?)</title>', item, flags=re.S) or [''])[0])
    link = html.unescape((re.findall(r'<link>(.*?)</link>', item, flags=re.S) or [''])[0]).strip()
    src = clean_title((re.findall(r'<source[^>]*>(.*?)</source>', item, flags=re.S) or [''])[0])
    pub = (re.findall(r'<pubDate>(.*?)</pubDate>', item, flags=re.S) or [''])[0]
    try:
      t = email.utils.parsedate_to_datetime(pub)
    except (TypeError, ValueError):
      continue
    if src and title.endswith(' - ' + src):
      title = title[: -len(src) - 3]
    out.append({'title': title, 'link': link, 'source': src, 'time': _iso(t)})
  return out


def _dedupe(items: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
  seen, out = set(), []
  for it in sorted(items, key=lambda x: x.get('time') or '', reverse=True):
    key = re.sub(r'\W', '', it.get('title') or '')[:40]
    text = f"{it.get('title', '')} {it.get('source', '')}"
    if not it.get('title') or key in seen or any(k in text for k in _LOW_QUALITY):
      continue
    seen.add(key)
    out.append(it)
  return out[:limit]


def market_news(limit: int = 30) -> list[dict[str, Any]]:
  """US market + world macro headlines (鉅亨網 first, Google News fallback)."""
  items: list[dict[str, Any]] = []
  for cat, n in (('us_stock', 25), ('wd_macro', 15)):
    try:
      items.extend(cnyes_news(cat, n))
    except Exception:  # pylint: disable=broad-except
      continue
  if len(items) < 10:
    try:
      items.extend(google_news('美股 華爾街', 20))
    except Exception:  # pylint: disable=broad-except
      pass
  return _dedupe(items, limit)


def stock_news(code: str, name: str = '', en_name: str = '') -> list[dict[str, Any]]:
  """Per-ticker news from Google News (zh-TW): `<中文名> <代號> 美股` then English name."""
  zh = re.sub(r'\s*[A-Za-z][A-Za-z0-9 .&\-]*$', '', name or '').strip() or name
  queries = [f'{zh} {code} 美股' if zh else f'{code} 美股']
  if en_name:
    queries.append(f'{en_name.split(",")[0]} {code}')
  items: list[dict[str, Any]] = []
  for q in queries:
    try:
      items.extend(google_news(q, 25))
    except Exception:  # pylint: disable=broad-except
      continue
    if len(items) >= 20:
      break
  return _dedupe(items, 40)
