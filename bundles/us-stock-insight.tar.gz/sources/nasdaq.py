"""api.nasdaq.com adapter: bulk screener, fundamentals, analysts, holdings, dividends,
extended-hours trading, earnings calendar and historical OHLCV fallback.

Units returned by this module:
* `mcap`, `rev`, `gross`, `op`, `net`, holding `value` -> 億美元 (USD / 1e8).
  (Nasdaq financial tables are in USD thousands -> divide by 100,000.)
* volumes -> shares; prices -> USD; percentages -> % numbers.
"""
from __future__ import annotations

import datetime as dt
import math
import re
from typing import Any

import net
from sources import fetch_json_parallel

BASE = 'https://api.nasdaq.com/api'
HEADERS = {
    'Accept': 'application/json, text/plain, */*',
    'Origin': 'https://www.nasdaq.com',
    'Referer': 'https://www.nasdaq.com/',
}
_MON = {m: i for i, m in enumerate(
    ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], 1)}


# ------------------------------------------------------------------ helpers --

def num(x: Any) -> float | None:
  """'$1,234.5' / '(0.39)' / '2.87%' / '+1.2' / 'N/A' -> float | None."""
  if x is None:
    return None
  if isinstance(x, (int, float)):
    v = float(x)
    return v if math.isfinite(v) else None
  s = str(x).strip()
  if not s or s.upper() in ('N/A', 'NA', '--', '-', 'NONE', 'NULL'):
    return None
  neg = s.startswith('(') and s.endswith(')') or s.startswith('-$') or s.startswith('-')
  s = re.sub(r'[^0-9.eE]', '', s.replace('E+', 'e').replace('e+', 'e'))
  if not s or s in ('.', 'e'):
    return None
  try:
    v = float(s)
  except ValueError:
    return None
  if not math.isfinite(v):
    return None
  return -v if neg else v


def yi(usd: float | None) -> float | None:
  """USD -> 億美元."""
  return None if usd is None else round(usd / 1e8, 2)


def yi_from_thousands(k: float | None) -> float | None:
  """Nasdaq financial table value (USD thousands) -> 億美元."""
  return None if k is None else round(k / 100_000.0, 2)


def parse_date(s: Any) -> str | None:
  """'09/21/2026' | 'Sep 10, 2026' | '7/26/2026' | '2026-09-10' -> 'YYYY-MM-DD'."""
  if not s:
    return None
  s = str(s).strip()
  for fmt in ('%m/%d/%Y', '%b %d, %Y', '%Y-%m-%d', '%B %d, %Y', '%m/%d/%y'):
    try:
      return dt.datetime.strptime(s, fmt).strftime('%Y-%m-%d')
    except ValueError:
      continue
  return None


def period_to_q(period: str) -> str:
  """'Oct 2025' / '10/26/2025' -> calendar quarter label '2025Q4'."""
  p = (period or '').strip()
  m = re.match(r'([A-Za-z]{3})\w*\s+(\d{4})', p)
  if m and m.group(1)[:3].title() in _MON:
    mon, yr = _MON[m.group(1)[:3].title()], int(m.group(2))
  else:
    d = parse_date(p)
    if not d:
      return p
    yr, mon = int(d[:4]), int(d[5:7])
  return f'{yr}Q{(mon - 1) // 3 + 1}'


def to_nasdaq(code: str) -> str:
  return (code or '').upper().replace('.', '/')


def from_nasdaq(sym: str) -> str:
  return (sym or '').strip().upper().replace('/', '.').replace('^', '-')


def _variants(code: str) -> list[str]:
  c = (code or '').upper()
  out = []
  for v in (c, c.replace('.', '/'), c.replace('.', '-'), c.replace('.', '')):
    if v and v not in out:
      out.append(v)
  return out


def _get(path: str, timeout: float = 20.0, retries: int = 2) -> dict[str, Any]:
  js = fetch_json_parallel(f'{BASE}/{path}', headers=HEADERS, timeout=timeout, retries=retries)
  return js if isinstance(js, dict) else {}


def _get_sym(path_tpl: str, code: str, **kw: Any) -> dict[str, Any]:
  """Tries `BRK.B`, `BRK/B`, `BRK-B` variants until `data` is non-empty."""
  last: dict[str, Any] = {}
  for v in _variants(code):
    try:
      js = _get(path_tpl.format(sym=v.replace('/', '%2F') if '/' in v else v), **kw)
    except net.FetchError:
      continue
    last = js
    if js.get('data'):
      return js
    if '.' not in code:
      break
  return last


# ----------------------------------------------------------------- screener --

def screener_stocks(timeout: float = 60.0) -> list[dict[str, Any]]:
  """All US stocks in one request -> [{code, name, close, chg, pct, vol, mcap(億), ...}]."""
  js = _get('screener/stocks?tableonly=true&limit=25000&download=true', timeout=timeout, retries=3)
  data = js.get('data') or {}
  rows = data.get('rows') or (data.get('table') or {}).get('rows') or []
  out = []
  for r in rows:
    code = from_nasdaq(r.get('symbol') or '')
    close = num(r.get('lastsale'))
    if not code or close is None:
      continue
    out.append({
        'code': code, 'en_name': (r.get('name') or '').strip(), 'close': close,
        'chg': num(r.get('netchange')), 'pct': num(r.get('pctchange')),
        'vol': num(r.get('volume')), 'mcap': yi(num(r.get('marketCap'))),
        'country': r.get('country') or '', 'ipo_year': str(r.get('ipoyear') or ''),
        'industry': r.get('industry') or '', 'sector': r.get('sector') or '',
    })
  return out


def screener_etfs(timeout: float = 60.0) -> list[dict[str, Any]]:
  js = _get('screener/etf?tableonly=true&limit=6000&download=true', timeout=timeout, retries=3)
  data = js.get('data') or {}
  rows = data.get('rows') or (data.get('data') or {}).get('rows') or \
      (data.get('table') or {}).get('rows') or []
  out = []
  for r in rows:
    code = from_nasdaq(r.get('symbol') or '')
    close = num(r.get('lastSalePrice') or r.get('lastsale'))
    if not code or close is None:
      continue
    out.append({'code': code, 'en_name': (r.get('companyName') or r.get('name') or '').strip(),
                'close': close, 'chg': num(r.get('netChange') or r.get('netchange')),
                'pct': num(r.get('percentageChange') or r.get('pctchange'))})
  return out


# -------------------------------------------------------------- per symbol --

def _sv(sd: dict[str, Any], key: str) -> Any:
  v = sd.get(key)
  return v.get('value') if isinstance(v, dict) else v


def summary(code: str, assetclass: str = 'stocks') -> dict[str, Any]:
  js = _get_sym('quote/{sym}/summary?assetclass=' + assetclass, code)
  sd = (js.get('data') or {}).get('summaryData') or {}
  if not sd:
    return {}
  hl = str(_sv(sd, 'FiftTwoWeekHighLow') or '')
  hi52 = lo52 = None
  if '/' in hl:
    a, b = hl.split('/', 1)
    hi52, lo52 = num(a), num(b)
  aum_k = num(_sv(sd, 'AUM'))
  return {
      'exchange': _sv(sd, 'Exchange'), 'sector': _sv(sd, 'Sector'), 'industry': _sv(sd, 'Industry'),
      'target_1y': num(_sv(sd, 'OneYrTarget')), 'prev_close': num(_sv(sd, 'PreviousClose')),
      'hi52': hi52, 'lo52': lo52, 'mcap': yi(num(_sv(sd, 'MarketCap'))),
      'annual_div': num(_sv(sd, 'AnnualizedDividend')), 'yld': num(_sv(sd, 'Yield')),
      'ex_div_date': parse_date(_sv(sd, 'ExDividendDate')),
      'pay_date': parse_date(_sv(sd, 'DividendPaymentDate')),
      'pe': num(_sv(sd, 'PERatio')), 'fwd_pe': num(_sv(sd, 'ForwardPE1Yr')),
      'eps_ttm': num(_sv(sd, 'EarningsPerShare')), 'beta': num(_sv(sd, 'Beta')),
      'aum': yi_from_thousands(aum_k), 'expense_ratio': num(_sv(sd, 'ExpenseRatio')),
      'avg_vol20': num(_sv(sd, 'AvgDailyVol20Days')),
  }


def eps(code: str) -> dict[str, Any]:
  """Quarterly EPS actual vs consensus (oldest first) + upcoming consensus."""
  js = _get_sym('quote/{sym}/eps?assetclass=stocks', code)
  rows = (js.get('data') or {}).get('earningsPerShare') or []
  quarters, upcoming = [], []
  for r in rows:
    period = r.get('period') or ''
    cons, act = num(r.get('consensus')), num(r.get('earnings'))
    if r.get('type') == 'PreviousQuarter':
      sp = None
      if act is not None and cons not in (None, 0):
        sp = round((act - cons) / abs(cons) * 100, 2)
      quarters.append({'q': period_to_q(period), 'period': period, 'actual': act,
                       'consensus': cons, 'surprise_pct': sp})
    elif r.get('type') == 'UpcomingQuarter':
      upcoming.append({'period': period, 'consensus': cons, 'type': '季預測'})
  return {'quarters': quarters, 'upcoming': upcoming}


def _fin_table(tbl: dict[str, Any]) -> list[dict[str, Any]]:
  headers = tbl.get('headers') or {}
  cols = [k for k in sorted(headers, key=lambda k: int(re.sub(r'\D', '', k) or 0)) if k != 'value1']
  rows = {(r.get('value1') or '').strip(): r for r in tbl.get('rows') or []}

  def pick(*names: str) -> dict[str, Any]:
    for n in names:
      if n in rows:
        return rows[n]
    return {}

  rev, gp, op, ni = (pick('Total Revenue', 'Revenue'), pick('Gross Profit'),
                     pick('Operating Income'), pick('Net Income', 'Net Income Applicable to Common Shareholders'))
  out = []
  for c in cols:
    period = parse_date(headers.get(c))
    if not period:
      continue
    r = yi_from_thousands(num(rev.get(c)))
    out.append({'period_end': period, 'rev': r, 'gross': yi_from_thousands(num(gp.get(c))),
                'op': yi_from_thousands(num(op.get(c))), 'net': yi_from_thousands(num(ni.get(c)))})
  out.sort(key=lambda x: x['period_end'])
  return out


def financials(code: str) -> dict[str, Any]:
  """Quarterly (frequency=2) + annual (frequency=1) income statements, 億美元, oldest first."""
  out: dict[str, Any] = {'quarterly': [], 'annual': []}
  for key, freq in (('quarterly', 2), ('annual', 1)):
    try:
      js = _get_sym('company/{sym}/financials?frequency=' + str(freq), code)
    except Exception:  # pylint: disable=broad-except
      continue
    tbl = (js.get('data') or {}).get('incomeStatementTable') or {}
    if tbl:
      out[key] = _fin_table(tbl)
  return out


def analyst(code: str) -> dict[str, Any]:
  js = _get_sym('analyst/{sym}/targetprice', code)
  co = (js.get('data') or {}).get('consensusOverview') or {}
  if not co:
    return {}
  buy, hold, sell = (int(num(co.get(k)) or 0) for k in ('buy', 'hold', 'sell'))
  return {'target_mean': num(co.get('priceTarget')), 'target_high': num(co.get('highPriceTarget')),
          'target_low': num(co.get('lowPriceTarget')), 'buy': buy, 'hold': hold, 'sell': sell}


def institutional(code: str, limit: int = 10) -> dict[str, Any]:
  js = _get_sym('company/{sym}/institutional-holdings?limit=' + str(limit) +
                '&type=TOTAL&sortColumn=marketValue', code, timeout=30.0)
  data = js.get('data') or {}
  if not data:
    return {}
  osum = data.get('ownershipSummary') or {}
  pct = num(_sv(osum, 'SharesOutstandingPCT'))
  act = {(r.get('positions') or ''): r for r in (data.get('activePositions') or {}).get('rows') or []}
  inc = num((act.get('Increased Positions') or {}).get('shares'))
  dec = num((act.get('Decreased Positions') or {}).get('shares'))
  holders = []
  table = ((data.get('holdingsTransactions') or {}).get('table') or {}).get('rows') or []
  for r in table[:limit]:
    holders.append({'name': (r.get('ownerName') or '').strip(), 'shares': num(r.get('sharesHeld')),
                    'value': yi_from_thousands(num(r.get('marketValue'))),
                    'chg_pct': num(r.get('sharesChangePCT')), 'date': parse_date(r.get('date'))})
  return {'inst_own_pct': pct, 'increased_shares': inc, 'decreased_shares': dec,
          'net_flow_ratio': (round((inc - dec) / (inc + dec), 4) if inc and dec else None),
          'holders': holders}


def dividends(code: str, assetclass: str = 'stocks') -> dict[str, Any]:
  js = _get_sym('quote/{sym}/dividends?assetclass=' + assetclass, code)
  data = js.get('data') or {}
  rows = ((data.get('dividends') or {}).get('rows')) or []
  items = []
  for r in rows:
    ex = parse_date(r.get('exOrEffDate'))
    cash = num(r.get('amount'))
    if not ex or cash is None:
      continue
    items.append({'ex_date': ex, 'pay_date': parse_date(r.get('paymentDate')), 'cash': cash,
                  'type': '現金股利' if (r.get('type') or 'Cash').lower().startswith('cash') else '其他'})
  items.sort(key=lambda x: x['ex_date'], reverse=True)
  return {'yld': num(data.get('yield')), 'annual': num(data.get('annualizedDividend')),
          'ex_date': parse_date(data.get('exDividendDate')),
          'pay_date': parse_date(data.get('dividendPaymentDate')), 'rows': items}


def extended(code: str, markettype: str = 'post') -> dict[str, Any]:
  """Pre/post-market last trade -> {ext_type, ext_price, ext_chg, ext_pct, vol, updated}."""
  js = _get_sym('quote/{sym}/extended-trading?assetclass=stocks&markettype=' + markettype, code,
                timeout=15.0, retries=1)
  data = js.get('data') or {}
  rows = (data.get('infoTable') or {}).get('rows') or []
  if not rows:
    return {}
  cons = str(rows[0].get('consolidated') or '')
  m = re.match(r'\s*\$?([\d,.]+)\s+([+\-]?[\d,.]+)\s+\(([+\-]?[\d,.]+)%\)', cons)
  if not m:
    return {}
  upd = ' '.join(data.get('lastUpdateInfo') or [])[:120]
  return {'ext_type': '盤前' if markettype == 'pre' else '盤後', 'ext_price': num(m.group(1)),
          'ext_chg': num(m.group(2)), 'ext_pct': num(m.group(3)),
          'vol': num(rows[0].get('volume')), 'updated': upd}


_TIME_ZH = {'time-pre-market': '盤前 (BMO)', 'time-after-hours': '盤後 (AMC)',
            'time-not-supplied': '未定'}


def earnings_calendar(date: str) -> list[dict[str, Any]]:
  js = _get(f'calendar/earnings?date={date}', timeout=20.0)
  rows = ((js.get('data') or {}).get('rows')) or []
  out = []
  for r in rows:
    code = from_nasdaq(r.get('symbol') or '')
    if not code:
      continue
    out.append({'date': date, 'time': _TIME_ZH.get(r.get('time') or '', '未定'), 'code': code,
                'en_name': (r.get('name') or '').strip(), 'mcap': yi(num(r.get('marketCap'))),
                'quarter': (r.get('fiscalQuarterEnding') or '').replace('/', ' '),
                'eps_est': num(r.get('epsForecast')), 'last_yr_eps': num(r.get('lastYearEPS')),
                'n_est': int(num(r.get('noOfEsts')) or 0)})
  return out


def historical(code: str, fromdate: str, todate: str, assetclass: str = 'stocks',
               limit: int = 400) -> list[list]:
  """Fallback daily bars [date, o, h, l, c, vol] ascending."""
  js = _get_sym('quote/{sym}/historical?assetclass=' + assetclass +
                f'&fromdate={fromdate}&todate={todate}&limit={limit}', code, timeout=30.0)
  rows = (((js.get('data') or {}).get('tradesTable') or {}).get('rows')) or []
  out = {}
  for r in rows:
    d = parse_date(r.get('date'))
    c = num(r.get('close'))
    if not d or not c:
      continue
    o, h, l = num(r.get('open')) or c, num(r.get('high')) or c, num(r.get('low')) or c
    out[d] = [d, o, max(h, o, c), min(l, o, c), c, int(num(r.get('volume')) or 0)]
  return [out[d] for d in sorted(out)]
