"""Data-source adapters for 美股戰情室.

`fetch_json_parallel()` is a small concurrent HTTP JSON client used by the fast US endpoints
(cnyes / Nasdaq).  Unlike `net.fetch_json` (which serializes requests per host), it allows a
bounded number of in-flight requests per host so ThreadPoolExecutor workers really overlap.
"""
from __future__ import annotations

import gzip
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

import config
import net

_SEMS: dict[str, threading.BoundedSemaphore] = {}
_SEM_LOCK = threading.Lock()
HOST_CONCURRENCY = {'ws.api.cnyes.com': 12, 'api.nasdaq.com': 12}


def _sem(host: str) -> threading.BoundedSemaphore:
  with _SEM_LOCK:
    if host not in _SEMS:
      _SEMS[host] = threading.BoundedSemaphore(HOST_CONCURRENCY.get(host, 4))
    return _SEMS[host]


def fetch_json_parallel(url: str, *, headers: dict[str, str] | None = None, timeout: float = 20.0,
                        retries: int = 2) -> Any:
  """GET JSON with gzip, retries/backoff and bounded per-host concurrency; raises net.FetchError."""
  host = urllib.parse.urlparse(url).netloc
  hdrs = {'User-Agent': config.USER_AGENT, 'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.6',
          'Accept-Encoding': 'gzip'}
  if headers:
    hdrs.update(headers)
  last: Exception | None = None
  for attempt in range(max(1, retries)):
    with _sem(host):
      try:
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
          raw = resp.read()
          if resp.headers.get('Content-Encoding') == 'gzip':
            raw = gzip.decompress(raw)
        return json.loads(raw.decode('utf-8-sig', errors='replace'))
      except urllib.error.HTTPError as e:
        last = e
        if e.code in (400, 404):
          break
      except Exception as e:  # pylint: disable=broad-except
        last = e
    time.sleep(1.0 * (attempt + 1) + (5.0 if '429' in str(last) else 0.0))
  raise net.FetchError(f'{url}: {last!r}')
