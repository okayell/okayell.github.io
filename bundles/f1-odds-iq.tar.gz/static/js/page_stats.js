/* F1 運彩智庫 — Page 4: 車手／車隊數據排行與領先者 (#/stats) */
(function () {
  'use strict';
  const F1 = window.F1;

  const DRV_COLS = [
    { k: 'pts', lbl: '年度積分 PTS' },
    { k: 'pts_pg', lbl: '站均分 PTS/GP' },
    { k: 'wins', lbl: '勝場 WINS' },
    { k: 'podiums', lbl: '頒獎台 POD' },
    { k: 'poles', lbl: '桿位 POLE' },
    { k: 'top10', lbl: '前十完賽' },
    { k: 'avg_grid', lbl: '平均起跑', ascDefault: true },
    { k: 'avg_finish', lbl: '平均完賽', ascDefault: true },
    { k: 'avg_gain', lbl: '場均推進' },
    { k: 'fl', lbl: '最快圈 FL' },
    { k: 'dnfs', lbl: '退賽 DNF' },
    { k: 'clean_pct', lbl: '完賽率%' },
    { k: 'h2h_pct', lbl: 'H2H 過盤率%' },
  ];

  F1.pages.stats = function (el) {
    const snap = F1.snap || {};
    const ent = F1.state.statsEntity || 'drivers';
    const drivers = (snap.driver_stats || []).slice();
    const teams = (snap.teams || []).slice();

    el.innerHTML = `
      <div class="stats-nav-strip">
        <div class="stats-entity-links">
          <button type="button" class="stats-entity-btn ${ent === 'drivers' ? 'active' : ''}" data-ent="drivers">👨‍🚀 車手排行 Drivers</button>
          <span class="stats-sep">|</span>
          <button type="button" class="stats-entity-btn ${ent === 'teams' ? 'active' : ''}" data-ent="teams">🏎️ 車隊排行 Constructors</button>
          <span class="stats-sep">|</span>
          <button type="button" class="stats-entity-btn ${ent === 'leaders' ? 'active' : ''}" data-ent="leaders">🏅 分項領先者 Leaders</button>
        </div>
        <div style="font-size:12px;color:#64748b">點擊任一欄位標題可切換排序（黃底為目前排序欄位）</div>
      </div>
      <div id="statsContent"></div>
    `;

    el.querySelectorAll('[data-ent]').forEach((b) => {
      b.onclick = () => {
        F1.state.statsEntity = b.getAttribute('data-ent');
        window.location.hash = `#/stats/${F1.state.statsEntity}`;
      };
    });

    const box = document.getElementById('statsContent');
    if (ent === 'drivers') {
      const sk = F1.state.statsSort || 'pts';
      const dir = F1.state.statsDir === 'asc' ? 1 : -1;
      const tFlt = F1.state.statsTeam || 'ALL';
      const q = (F1.state.statsSearch || '').trim().toLowerCase();

      const rows = drivers
        .filter((d) => (tFlt === 'ALL' || d.team === tFlt) && (!q || `${d.zh} ${d.en} ${d.code}`.toLowerCase().includes(q)))
        .sort((a, b) => ((Number(a[sk]) || 0) - (Number(b[sk]) || 0)) * dir);

      box.innerHTML = `
        <div class="stats-filter-grid">
          <div class="sf-field">
            <span class="sf-lbl">所屬車隊 TEAM</span>
            <select class="inp" id="stTeamSel">
              <option value="ALL">全部 11 支車隊</option>
              ${teams.map((t) => `<option value="${t.abbr}" ${tFlt === t.abbr ? 'selected' : ''}>${F1.esc(t.zh)} (${t.abbr})</option>`).join('')}
            </select>
          </div>
          <div class="sf-field">
            <span class="sf-lbl">搜尋車手 DRIVER</span>
            <input class="inp" id="stDrvInp" value="${F1.esc(F1.state.statsSearch)}" placeholder="輸入姓名或縮寫…">
          </div>
        </div>

        <div class="nba-tbl-wrap standalone">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="sticky-rk no-sort">#</th>
                <th class="left sticky-pl no-sort">車手 DRIVER</th>
                <th class="left no-sort">車隊</th>
                <th class="no-sort">出賽</th>
                ${DRV_COLS.map((c) => `<th data-sort="${c.k}" class="${sk === c.k ? 'col-active' : ''}">${c.lbl}${sk === c.k ? (dir === -1 ? ' ▼' : ' ▲') : ''}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${rows.map((d, idx) => {
                const tm = F1.teamOf(d.team);
                return `
                  <tr>
                    <td class="sticky-rk">${idx + 1}</td>
                    <td class="left sticky-pl">
                      <span class="pl-link" data-player-id="${F1.esc(d.code)}" style="font-weight:800;color:#1d4ed8">${F1.esc(d.zh)} (${F1.esc(d.code)})</span>
                    </td>
                    <td class="left"><span class="tm-link" data-team-link="${F1.esc(d.team)}" style="font-weight:700;color:${F1.esc(tm.color)}">${F1.esc(tm.zh)}</span></td>
                    <td>${d.gp}</td>
                    ${DRV_COLS.map((c) => `<td class="${sk === c.k ? 'col-active' : ''}">${d[c.k]}</td>`).join('')}
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>`;

      document.getElementById('stTeamSel').onchange = (e) => { F1.state.statsTeam = e.target.value; F1.render(); };
      const inp = document.getElementById('stDrvInp');
      inp.onkeydown = (ev) => { if (F1.isEnterSend(ev)) { F1.state.statsSearch = inp.value; F1.render(); } };
      inp.onblur = () => { if (F1.state.statsSearch !== inp.value) { F1.state.statsSearch = inp.value; F1.render(); } };
      box.querySelectorAll('[data-sort]').forEach((th) => {
        th.onclick = () => {
          const k = th.getAttribute('data-sort');
          const col = DRV_COLS.find((x) => x.k === k) || {};
          if (F1.state.statsSort === k) F1.state.statsDir = F1.state.statsDir === 'desc' ? 'asc' : 'desc';
          else { F1.state.statsSort = k; F1.state.statsDir = col.ascDefault ? 'asc' : 'desc'; }
          F1.render();
        };
      });
    } else if (ent === 'teams') {
      const sk = F1.state.teamStatsSort || 'pts';
      const dir = F1.state.teamStatsDir === 'asc' ? 1 : -1;
      const cols = [
        { k: 'pts', lbl: '年度積分 PTS' },
        { k: 'pts_pg', lbl: '站均積分' },
        { k: 'wins', lbl: '分站冠軍' },
        { k: 'podiums', lbl: '頒獎台數' },
        { k: 'poles', lbl: '桿位數' },
        { k: 'dnfs', lbl: '退賽數' },
        { k: 'h2h_pct', lbl: '跨隊 H2H 勝率%' },
      ];
      const rows = teams.sort((a, b) => ((Number(a[sk]) || 0) - (Number(b[sk]) || 0)) * dir);
      box.innerHTML = `
        <div class="nba-tbl-wrap standalone">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="sticky-rk no-sort">#</th>
                <th class="left sticky-pl no-sort">車隊 CONSTRUCTOR</th>
                <th class="left no-sort">動力單元</th>
                ${cols.map((c) => `<th data-tsort="${c.k}" class="${sk === c.k ? 'col-active' : ''}">${c.lbl}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${rows.map((t, i) => `
                <tr>
                  <td class="sticky-rk">${i + 1}</td>
                  <td class="left sticky-pl"><span class="tm-link" data-team-link="${F1.esc(t.abbr)}" style="font-weight:800;color:${F1.esc(t.color)}">${F1.esc(t.zh)} (${F1.esc(t.abbr)})</span></td>
                  <td class="left">${F1.esc(t.pu)}</td>
                  ${cols.map((c) => `<td class="${sk === c.k ? 'col-active' : ''}">${t[c.k]}</td>`).join('')}
                </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
      box.querySelectorAll('[data-tsort]').forEach((th) => {
        th.onclick = () => {
          const k = th.getAttribute('data-tsort');
          if (F1.state.teamStatsSort === k) F1.state.teamStatsDir = F1.state.teamStatsDir === 'desc' ? 'asc' : 'desc';
          else { F1.state.teamStatsSort = k; F1.state.teamStatsDir = 'desc'; }
          F1.render();
        };
      });
    } else {
      const cats = [
        { title: '🏆 車手積分王 (Points)', k: 'pts', unit: '分', list: drivers.slice().sort((a, b) => b.pts - a.pts).slice(0, 5) },
        { title: '🥇 分站奪冠王 (Wins)', k: 'wins', unit: '勝', list: drivers.slice().sort((a, b) => b.wins - a.wins || b.pts - a.pts).slice(0, 5) },
        { title: '⚡ 排位桿位王 (Poles)', k: 'poles', unit: '桿', list: drivers.slice().sort((a, b) => b.poles - a.poles || a.avg_grid - b.avg_grid).slice(0, 5) },
        { title: '🚀 正賽推進王 (Avg Gain)', k: 'avg_gain', unit: '位', list: drivers.slice().sort((a, b) => b.avg_gain - a.avg_gain).slice(0, 5) },
        { title: '💰 H2H 配對過盤王 (H2H%)', k: 'h2h_pct', unit: '%', list: drivers.filter((d) => d.h2h_w + d.h2h_l >= 8).sort((a, b) => b.h2h_pct - a.h2h_pct).slice(0, 5) },
        { title: '🛡️ 完賽穩定王 (Clean%)', k: 'clean_pct', unit: '%', list: drivers.filter((d) => d.gp >= 8).sort((a, b) => b.clean_pct - a.clean_pct || b.pts - a.pts).slice(0, 5) },
      ];
      box.innerHTML = `
        <div class="leader-grid">
          ${cats.map((c) => {
            const top = c.list[0];
            if (!top) return '';
            return `
              <div class="leader-card">
                <div class="leader-hdr"><span>${c.title}</span><span style="font-size:11.5px;color:#64748b">Top 5</span></div>
                <div class="leader-top1">
                  <div style="display:flex;align-items:center;gap:10px">
                    <img loading="lazy" decoding="async" class="leader-avatar" src="${F1.esc(top.headshot)}" alt="">
                    <div>
                      <div class="pl-link" data-player-id="${F1.esc(top.code)}" style="font-weight:900;font-size:15px">${F1.esc(top.zh)}</div>
                      <div style="font-size:12px;color:#64748b">${F1.esc(F1.teamOf(top.team).zh)}</div>
                    </div>
                  </div>
                  <div class="leader-val-big">${top[c.k]}${c.unit}</div>
                </div>
                ${c.list.slice(1).map((d, idx) => `
                  <div class="leader-row">
                    <span><strong>${idx + 2}.</strong> <span class="pl-link" data-player-id="${F1.esc(d.code)}" style="font-weight:700">${F1.esc(d.zh)}</span> <span style="color:#94a3b8;font-size:11.5px">(${F1.esc(d.team)})</span></span>
                    <strong>${d[c.k]}${c.unit}</strong>
                  </div>`).join('')}
              </div>`;
          }).join('')}
        </div>`;
    }
  };
})();
