/* F1 運彩智庫 — Page 7: 個人注單追蹤與凱利試算 (#/bankroll) */
(function () {
  'use strict';
  const F1 = window.F1;

  F1.pages.bankroll = function (el) {
    const bets = F1.bets || [];
    const settled = bets.filter((b) => b.status === 'WIN' || b.status === 'LOSS' || b.status === 'PUSH');
    const wins = bets.filter((b) => b.status === 'WIN').length;
    const losses = bets.filter((b) => b.status === 'LOSS').length;
    const totalStake = settled.reduce((s, b) => s + Number(b.stake || 0), 0);
    const netPnl = settled.reduce((s, b) => s + Number(b.pnl || 0), 0);
    const roi = totalStake > 0 ? ((netPnl / totalStake) * 100).toFixed(1) : '0.0';

    el.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h2 class="sec-title">📝 個人 F1 注單帳本 & 1/4 凱利期望值試算機</h2>
          <div class="sec-sub">支援車手配對盤（H2H）、完賽車數大小盤與頒獎台／奪冠注單；完賽後系統自動對獎結算損益</div>
        </div>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>總注單數 / 待對獎</span></div>
          <div class="kpi-val">${bets.length} 筆</div>
          <div class="kpi-sub">待結算 ${bets.filter((b) => b.status === 'PENDING').length} 筆</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>已結算戰績</span></div>
          <div class="kpi-val">${wins}勝 - ${losses}敗</div>
          <div class="kpi-sub">命中率 ${wins + losses > 0 ? ((wins / (wins + losses)) * 100).toFixed(1) : '0.0'}%</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>累積淨損益 (PnL)</span></div>
          <div class="kpi-val" style="color:${netPnl >= 0 ? '#15803d' : '#b91c1c'}">${netPnl >= 0 ? '+' : ''}${netPnl.toFixed(0)}</div>
          <div class="kpi-sub">實戰投資報酬率 ROI ${roi}%</div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:14px;margin-bottom:14px">
        <div class="card">
          <h3 style="margin:0 0 10px;font-size:15px">🧮 1/4 凱利準則 (Quarter-Kelly) 與台彩／國際盤 EV 試算</h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(105px,1fr));gap:8px;margin-bottom:10px">
            <label style="font-size:12px">總資金池 (Bankroll)<input type="number" class="inp" id="klBank" value="50000" style="width:100%;margin-top:4px"></label>
            <label style="font-size:12px">預估勝率 (%)<input type="number" step="0.5" class="inp" id="klProb" value="60" style="width:100%;margin-top:4px"></label>
            <label style="font-size:12px">十進位賠率 (如 1.85)<input type="number" step="0.01" class="inp" id="klOdds" value="1.85" style="width:100%;margin-top:4px"></label>
          </div>
          <div class="card" id="klOutBox" style="background:#f8fafc;padding:10px 12px;font-size:13px"></div>
        </div>

        <div class="card">
          <h3 style="margin:0 0 10px;font-size:15px">➕ 手動新增 F1 注單</h3>
          <form id="manualBetForm" class="qb-form" novalidate>
            <div class="qb-explain">✍️ 用來記錄本站沒列出的注，例如頒獎台、分站冠軍或其他網站的盤口。<strong>手動注單不會自動對獎</strong>，正賽結束後請在下方明細按「勝／敗」結算；想自動對獎，請從「🎯 本站解盤」卡片按「➕ 加入注單」或「➕ 記單」。</div>
            <label class="qb-field">
              <span class="qb-step-title">① 分站與組合</span>
              <input class="inp" id="mbMatchup" maxlength="80" placeholder="例：R19 墨西哥城 安東內利 vs 羅素">
            </label>
            <div class="qb-fields">
              <label class="qb-field">
                <span class="qb-step-title">② 玩法</span>
                <select class="inp" id="mbMarket">
                  <option value="H2H">車手配對 H2H</option>
                  <option value="OU">完賽車數大小</option>
                  <option value="PODIUM">頒獎台 / 奪冠</option>
                </select>
              </label>
              <label class="qb-field">
                <span class="qb-step-title">③ 下注內容</span>
                <input class="inp" id="mbLabel" maxlength="120">
                <span class="qb-hint" id="mbLabelHint"></span>
              </label>
            </div>
            <div class="qb-fields">
              <label class="qb-field">
                <span class="qb-step-title">④ 賠率</span>
                <input type="number" inputmode="decimal" step="0.01" min="1.01" class="inp" id="mbOdds" value="1.85">
                <span class="qb-hint">請填你實際下注時看到的賠率（含本金，例如 1.85）。</span>
              </label>
              <div class="qb-field">
                <label class="qb-step-title" for="mbStake">⑤ 投注金額（NT$）</label>
                <input type="number" inputmode="numeric" step="100" min="1" class="inp" id="mbStake" value="1000">
                <div class="qb-chips">${[100, 500, 1000, 2000, 5000].map((v) => `<button type="button" class="qb-chip" data-mb-stake="${v}">${v.toLocaleString('en-US')}</button>`).join('')}</div>
              </div>
            </div>
            <div class="qb-preview" id="mbPreview" aria-live="polite"></div>
            <div class="qb-err" id="mbErr" role="alert"></div>
            <button type="submit" class="btn btn-primary" id="mbSubmit">💾 新增注單紀錄</button>
          </form>
        </div>
      </div>

      <div class="card">
        <h3 style="margin:0 0 10px;font-size:15px">📋 注單明細列表</h3>
        ${bets.length ? `
          <div class="tbl-wrap">
            <table class="data-tbl">
              <thead>
                <tr><th>日期</th><th>分站與對決</th><th>玩法</th><th>下注內容</th><th class="num">賠率</th><th class="num">本金</th><th>狀態</th><th class="num">損益</th><th>操作</th></tr>
              </thead>
              <tbody>
                ${bets.map((b) => `
                  <tr>
                    <td>${F1.esc(b.tw_date)}</td>
                    <td><strong>${F1.esc(b.matchup)}</strong></td>
                    <td><span class="chip muted">${F1.esc(b.market)}</span></td>
                    <td>${F1.esc(b.pick_label)}</td>
                    <td class="num">${Number(b.odds_decimal).toFixed(2)}</td>
                    <td class="num">${Number(b.stake).toFixed(0)}</td>
                    <td><span class="chip ${b.status === 'WIN' ? 'ok' : b.status === 'LOSS' ? 'bad' : 'warn'}">${F1.esc(b.status)}</span></td>
                    <td class="num" style="font-weight:800;color:${b.pnl > 0 ? '#15803d' : b.pnl < 0 ? '#b91c1c' : '#64748b'}">${b.pnl > 0 ? '+' + b.pnl : b.pnl}</td>
                    <td>
                      <button type="button" class="btn btn-sm" data-settle="${F1.esc(b.bet_id)}" data-st="WIN">勝</button>
                      <button type="button" class="btn btn-sm" data-settle="${F1.esc(b.bet_id)}" data-st="LOSS">敗</button>
                      <button type="button" class="btn btn-ghost btn-sm" data-del="${F1.esc(b.bet_id)}">✕</button>
                    </td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>` : '<div class="empty-box">目前尚無注單，可從「本站解盤」卡片點擊「➕ 加入注單」或由上方表單建立。</div>'}
      </div>
    `;

    function calcKelly() {
      const bk = Number(document.getElementById('klBank').value || 0);
      const p = Math.min(0.99, Math.max(0.01, Number(document.getElementById('klProb').value || 50) / 100));
      const od = Math.max(1.02, Number(document.getElementById('klOdds').value || 1.85));
      const b = od - 1;
      const ev = (p * od - 1) * 100;
      const fullK = Math.max(0, (b * p - (1 - p)) / b);
      const qK = fullK * 0.25;
      const be = (1 / od) * 100;
      document.getElementById('klOutBox').innerHTML = `
        <div>損益兩平勝率：<strong>${be.toFixed(2)}%</strong> ｜ 期望值 EV：<strong style="color:${ev >= 0 ? '#15803d' : '#b91c1c'}">${ev >= 0 ? '+' : ''}${ev.toFixed(2)}%</strong></div>
        <div style="margin-top:4px">1/4 凱利建議比例：<strong>${(qK * 100).toFixed(2)}%</strong> → 建議單筆注碼：<strong style="color:#dc2626">$${Math.round(bk * qK).toLocaleString()}</strong></div>
      `;
    }
    ['klBank', 'klProb', 'klOdds'].forEach((id) => { document.getElementById(id).oninput = calcKelly; });
    calcKelly();

    // Manual bets carry no game_id, so nothing settles them automatically: the form says so up front,
    // labels every field, adapts the hints to the market and previews the payout before saving.
    const MB_COPY = {
      H2H: { ph: '例：安東內利 勝', hint: '寫你押的車手，例如「安東內利 勝」。' },
      OU: { ph: '例：完賽車數 小於 17.5 台', hint: '寫大於或小於＋盤口線，例如「完賽車數 小於 17.5 台」。' },
      PODIUM: { ph: '例：維斯塔潘 站上頒獎台', hint: '寫車手＋結果，例如「維斯塔潘 分站冠軍」或「諾里斯 站上頒獎台」。' },
    };
    const mbForm = document.getElementById('manualBetForm');
    const mbMarket = document.getElementById('mbMarket');
    const mbOdds = document.getElementById('mbOdds');
    const mbStake = document.getElementById('mbStake');
    const mbErr = document.getElementById('mbErr');
    const mbSubmit = document.getElementById('mbSubmit');
    let mbSaving = false;
    const money = (n) => Math.round(n).toLocaleString('en-US');

    function refreshMb() {
      const odds = Number(mbOdds.value);
      const stake = Number(mbStake.value);
      const oddsOk = mbOdds.value.trim() !== '' && odds >= 1.01;
      const stakeOk = mbStake.value.trim() !== '' && stake >= 1;
      mbOdds.classList.toggle('inp-err', !oddsOk);
      mbStake.classList.toggle('inp-err', !stakeOk);
      el.querySelectorAll('[data-mb-stake]').forEach((b) => b.classList.toggle('on', Number(b.getAttribute('data-mb-stake')) === stake));
      const pv = document.getElementById('mbPreview');
      if (!oddsOk || !stakeOk) {
        pv.className = 'qb-preview invalid';
        pv.innerHTML = `${oddsOk ? '' : '<div>⚠️ 賠率要大於 1，例如 1.85</div>'}${stakeOk ? '' : '<div>⚠️ 請填投注金額，例如 1000</div>'}`;
        return false;
      }
      pv.className = 'qb-preview';
      pv.innerHTML = `
        <div>💰 若押中 → 可領回 <strong>NT$${money(stake * odds)}</strong>（含本金，淨賺 <strong>+${money(stake * odds - stake)}</strong>）</div>
        <div class="loss">若沒中 → 損失本金 NT$${money(stake)}</div>`;
      return true;
    }
    function applyMarket() {
      const c = MB_COPY[mbMarket.value] || MB_COPY.H2H;
      document.getElementById('mbLabel').placeholder = c.ph;
      document.getElementById('mbLabelHint').textContent = c.hint;
    }
    mbMarket.onchange = applyMarket;
    [mbOdds, mbStake].forEach((inp) => { inp.oninput = refreshMb; });
    el.querySelectorAll('[data-mb-stake]').forEach((b) => {
      b.onclick = () => { mbStake.value = b.getAttribute('data-mb-stake'); refreshMb(); };
    });
    ['mbMatchup', 'mbLabel'].forEach((id) => {
      document.getElementById(id).oninput = (ev) => {
        if (ev.target.value.trim()) ev.target.classList.remove('inp-err');
        if (!mbForm.querySelector('#mbMatchup.inp-err, #mbLabel.inp-err')) mbErr.textContent = '';
      };
    });
    // IME-safe: the Enter that confirms a 注音／倉頡 candidate must not submit the form.
    mbForm.onkeydown = (ev) => {
      if (ev.key === 'Enter' && ev.target.tagName === 'INPUT' && !F1.isEnterSend(ev)) ev.preventDefault();
    };
    applyMarket();
    refreshMb();

    mbForm.onsubmit = async (ev) => {
      ev.preventDefault();
      if (mbSaving) return;
      const errs = [];
      let firstBad = null;
      [['mbMatchup', '分站與組合'], ['mbLabel', '下注內容']].forEach(([id, name]) => {
        const inp = document.getElementById(id);
        const bad = !inp.value.trim();
        inp.classList.toggle('inp-err', bad);
        if (bad) { errs.push(`請填${name}`); firstBad = firstBad || inp; }
      });
      if (!refreshMb()) { errs.push('請確認賠率與投注金額'); firstBad = firstBad || mbOdds; }
      mbErr.textContent = errs.length ? `⚠️ ${errs.join('、')}` : '';
      if (errs.length) { firstBad.focus(); return; }
      mbSaving = true;
      mbSubmit.disabled = true;
      mbSubmit.textContent = '⏳ 儲存中…';
      try {
        const res = await F1.apiPost('/api/bets/add', {
          matchup: document.getElementById('mbMatchup').value.trim(),
          market: mbMarket.value,
          pick_label: document.getElementById('mbLabel').value.trim(),
          odds_decimal: Number(mbOdds.value),
          stake: Number(mbStake.value),
        });
        F1.bets = res.bets || [];
        F1.render();
        F1.toast('✅ 已儲存注單！手動注單請在正賽結束後按「勝／敗」結算');
      } catch (e) {
        mbSaving = false;
        mbSubmit.disabled = false;
        mbSubmit.textContent = '💾 新增注單紀錄';
        F1.toast('⚠️ ' + e.message);
      }
    };

    el.querySelectorAll('[data-settle]').forEach((b) => {
      b.onclick = async () => {
        const res = await F1.apiPost('/api/bets/settle', { bet_id: b.getAttribute('data-settle'), status: b.getAttribute('data-st') });
        F1.bets = res.bets || [];
        F1.render();
      };
    });
    el.querySelectorAll('[data-del]').forEach((b) => {
      b.onclick = async () => {
        const res = await F1.apiPost('/api/bets/delete', { bet_id: b.getAttribute('data-del') });
        F1.bets = res.bets || [];
        F1.render();
      };
    });
  };
})();
