/* F1 運彩智庫 — Page 8: F1 運彩百科與實戰指南 (#/guide) */
(function () {
  'use strict';
  const F1 = window.F1;

  F1.pages.guide = function (el) {
    el.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h2 class="sec-title">📖 F1 賽車運彩實戰百科與量化指標指南</h2>
          <div class="sec-sub">為什麼職業玩家主力鎖定「車手配對盤 (H2H)」與「完賽車數大小盤」，而非盲目追逐分站冠軍低賠？</div>
        </div>
        ${!F1.isStatic ? `<a class="btn btn-primary" href="/download/index.html" download="index.html">⬇️ 下載 GitHub Pages 單一 index.html</a>` : ''}
      </div>

      <div class="games-grid">
        <div class="card">
          <h3 style="margin:0 0 8px;font-size:15.5px">1️⃣ 車手配對盤 (Driver Head-to-Head H2H) — 職業玩家首選</h3>
          <p style="margin:0;color:#334155;font-size:13.5px;line-height:1.65">
            莊家將兩名實力相近的車手（例如<strong>同隊隊友內戰</strong>或爭冠對手）配成二選一對決，正賽官方最終分類名次較高者即勝出（雙退賽則依完成圈數多者勝）。<br>
            <strong>優勢：</strong>分站冠軍盤（Outright）莊家總抽水（Overround）高達 14%–22%，而雙向配對盤抽水僅約 4.5%（標準 1.91 賠率，損益兩平勝率 52.38%），且同隊內戰完全排除兩支車隊底盤與升級差異！
          </p>
        </div>

        <div class="card">
          <h3 style="margin:0 0 8px;font-size:15.5px">2️⃣ 完賽車數大小盤 (Classified Finishers O/U) & 安全車</h3>
          <p style="margin:0;color:#334155;font-size:13.5px;line-height:1.65">
            依 FIA 規則，車手完成領先者 90% 圈數即算「有分類完賽（Classified）」。2026 賽季共 11 支車隊 22 台賽車起跑，常見盤口為 <strong>17.5 台或 18.5 台</strong>。<br>
            • <strong>窄街與高牆賽道（巴庫、新加坡、墨爾本、吉達）：</strong>擦撞與紅旗率高，偏向小分（Under）。<br>
            • <strong>寬緩衝區傳統賽道（巴塞隆納、亨格羅林、盧賽爾）：</strong>退賽少，偏向大分（Over）。
          </p>
        </div>

        <div class="card">
          <h3 style="margin:0 0 8px;font-size:15.5px">3️⃣ 賽道四大空力分類學（Circuit DNA）</h3>
          <p style="margin:0;color:#334155;font-size:13.5px;line-height:1.65">
            • <strong>極窄街道（超車難度 1–2/5，如摩納哥、新加坡）：</strong>週六排位賽決定近 8 成勝負，排位單圈強者必追。<br>
            • <strong>高速低風阻（如蒙札、斯帕、拉斯維加斯）：</strong>直線極速與主動空力效率優先，排位小幅落後仍能輕易超車。<br>
            • <strong>高海拔稀薄空氣（如墨西哥城 2,285m）：</strong>渦輪增壓與煞車散熱負荷極限，需提防動力單元高溫退賽。
          </p>
        </div>

        <div class="card">
          <h3 style="margin:0 0 8px;font-size:15.5px">4️⃣ Parc Fermé（車輛封閉管制）進場黃金時機</h3>
          <p style="margin:0;color:#334155;font-size:13.5px;line-height:1.65">
            F1 賽車一旦進入週六排位賽即啟動 <strong>Parc Fermé 封閉管制</strong>，不得再大幅修改懸吊與空力設定。建議觀察 <strong>FP2 長距離模擬配速（Long-run Pace）</strong> 與 <strong>FIA 賽前動力單元更換公告</strong>：若強車手因換引擎罰退 10 位，在超車容易賽道（如英特拉格斯、斯帕）往往創造極佳的正賽追擊價值！
          </p>
        </div>
      </div>
    `;
  };
})();
