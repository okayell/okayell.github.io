/* F1 運彩智庫 — Page 5: 動力單元罰退雷達與中英文新聞 (#/news) */
(function () {
  'use strict';
  const F1 = window.F1;

  F1.pages.news = function (el) {
    const snap = F1.snap || {};
    const tab = F1.state.newsTab || 'tech';
    const teams = snap.teams || [];
    const twList = snap.tech_watch || [];
    const newsList = snap.news || [];

    el.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h2 class="sec-title">🔧 F1 動力單元罰退雷達 & 即時雙語新聞</h2>
          <div class="sec-sub">追蹤季末 ICE / 渦輪 / 變速箱配額罰退風險、正賽推進效率與 ESPN / 中英文 F1 即時情報</div>
        </div>
        <div class="sub-tabs" style="margin-bottom:0">
          <button type="button" class="sub-tab ${tab === 'tech' ? 'active' : ''}" data-ntab="tech">⚠️ 罰退與車況雷達 (${twList.length})</button>
          <button type="button" class="sub-tab ${tab === 'news' ? 'active' : ''}" data-ntab="news">📰 中英文 F1 新聞 (${newsList.length})</button>
        </div>
      </div>

      ${tab === 'tech' ? `
        <div class="stats-filter-grid">
          <div class="sf-field">
            <span class="sf-lbl">篩選車隊</span>
            <select class="inp" id="twTeamSel">
              <option value="ALL">全部車隊</option>
              ${teams.map((t) => `<option value="${t.abbr}" ${F1.state.techTeam === t.abbr ? 'selected' : ''}>${F1.esc(t.zh)} (${t.abbr})</option>`).join('')}
            </select>
          </div>
          <div class="sf-field">
            <span class="sf-lbl">狀態分類</span>
            <select class="inp" id="twStatusSel">
              <option value="ALL" ${F1.state.techStatus === 'ALL' ? 'selected' : ''}>全部狀態</option>
              <option value="WATCH" ${F1.state.techStatus === 'WATCH' ? 'selected' : ''}>⚠️ 動力單元罰退警戒</option>
              <option value="CAUTION" ${F1.state.techStatus === 'CAUTION' ? 'selected' : ''}>🔧 完賽波動留意</option>
              <option value="CLEAN" ${F1.state.techStatus === 'CLEAN' ? 'selected' : ''}>✅ 100% 高妥善率</option>
              <option value="UPGRADE" ${F1.state.techStatus === 'UPGRADE' ? 'selected' : ''}>🚀 正賽追擊強勢</option>
            </select>
          </div>
        </div>

        <div class="games-grid">
          ${twList
            .filter((x) => (F1.state.techTeam === 'ALL' || x.team_abbr === F1.state.techTeam) && (F1.state.techStatus === 'ALL' || x.status === F1.state.techStatus))
            .map((x) => {
              const tm = F1.teamOf(x.team_abbr);
              const chipCls = x.status === 'WATCH' ? 'bad' : x.status === 'CAUTION' ? 'warn' : x.status === 'CLEAN' ? 'ok' : 'info';
              return `
                <div class="card">
                  <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px">
                    <div style="display:flex;align-items:center;gap:8px">
                      <span class="tm-link" data-team-link="${F1.esc(x.team_abbr)}" style="font-weight:800;color:${F1.esc(tm.color)}">${F1.esc(tm.zh)}</span>
                      ${x.driver_code ? `<span class="pl-link" data-player-id="${F1.esc(x.driver_code)}" style="font-weight:800;color:#1d4ed8">${F1.esc(x.driver_code)}</span>` : ''}
                    </div>
                    <span class="chip ${chipCls}">${F1.esc(x.category_zh)}</span>
                  </div>
                  <div style="font-weight:800;font-size:14px;color:#0f172a;margin-bottom:6px">${F1.esc(x.headline_zh)}</div>
                  <div style="font-size:12.5px;color:#475569;line-height:1.55">${F1.esc(x.impact_note)}</div>
                </div>`;
            }).join('')}
        </div>
      ` : `
        <div class="stats-filter-grid">
          <div class="sf-field">
            <span class="sf-lbl">情報分類</span>
            <select class="inp" id="nwCatSel">
              <option value="ALL" ${F1.state.newsCat === 'ALL' ? 'selected' : ''}>全部新聞</option>
              <option value="PENALTY" ${F1.state.newsCat === 'PENALTY' ? 'selected' : ''}>⚖️ 判罰與罰退</option>
              <option value="UPGRADE" ${F1.state.newsCat === 'UPGRADE' ? 'selected' : ''}>🔧 空力與技術升級</option>
              <option value="BETTING" ${F1.state.newsCat === 'BETTING' ? 'selected' : ''}>💰 賠率與奪冠預測</option>
              <option value="RACE" ${F1.state.newsCat === 'RACE' ? 'selected' : ''}>🏁 賽事動態</option>
            </select>
          </div>
          <div class="sf-field">
            <span class="sf-lbl">相關車隊</span>
            <select class="inp" id="nwTeamSel">
              <option value="ALL">全部車隊</option>
              ${teams.map((t) => `<option value="${t.abbr}" ${F1.state.newsTeam === t.abbr ? 'selected' : ''}>${F1.esc(t.zh)}</option>`).join('')}
            </select>
          </div>
          <div class="sf-field">
            <span class="sf-lbl">關鍵字搜尋</span>
            <input class="inp" id="nwQueryInp" value="${F1.esc(F1.state.newsQuery)}" placeholder="輸入關鍵字按 Enter…">
          </div>
        </div>

        <div class="games-grid">
          ${newsList
            .filter((n) => {
              if (F1.state.newsCat !== 'ALL' && n.category !== F1.state.newsCat) return false;
              if (F1.state.newsTeam !== 'ALL' && n.team_abbr !== F1.state.newsTeam) return false;
              const q = (F1.state.newsQuery || '').trim().toLowerCase();
              if (q && !`${n.title} ${n.summary}`.toLowerCase().includes(q)) return false;
              return true;
            })
            .map((n) => `
              <div class="card" style="display:flex;flex-direction:column;justify-content:space-between;gap:8px">
                <div>
                  <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:6px;font-size:11.5px;color:#64748b">
                    <span><strong>${F1.esc(n.source)}</strong> · ${F1.esc(n.published_tw)}</span>
                    <div style="display:flex;gap:5px">
                      <span class="chip ${n.lang === 'ZH' ? 'strong' : 'muted'}">${n.lang === 'ZH' ? '繁中' : 'EN'}</span>
                      ${n.team_abbr ? `<span class="chip info tm-link" data-team-link="${F1.esc(n.team_abbr)}">${F1.esc(F1.teamOf(n.team_abbr).zh)}</span>` : ''}
                    </div>
                  </div>
                  <a href="${F1.esc(n.url)}" target="_blank" rel="noopener" style="font-size:14.5px;font-weight:800;color:#0f172a;line-height:1.45">${F1.esc(n.title)}</a>
                  ${n.summary ? `<p style="margin:6px 0 0;font-size:12.5px;color:#475569;line-height:1.55">${F1.esc(n.summary)}</p>` : ''}
                </div>
              </div>`).join('')}
        </div>
      `}
    `;

    el.querySelectorAll('[data-ntab]').forEach((b) => {
      b.onclick = () => { F1.state.newsTab = b.getAttribute('data-ntab'); F1.render(); };
    });
    const twT = document.getElementById('twTeamSel');
    if (twT) twT.onchange = () => { F1.state.techTeam = twT.value; F1.render(); };
    const twS = document.getElementById('twStatusSel');
    if (twS) twS.onchange = () => { F1.state.techStatus = twS.value; F1.render(); };
    const nwC = document.getElementById('nwCatSel');
    if (nwC) nwC.onchange = () => { F1.state.newsCat = nwC.value; F1.render(); };
    const nwT = document.getElementById('nwTeamSel');
    if (nwT) nwT.onchange = () => { F1.state.newsTeam = nwT.value; F1.render(); };
    const nwQ = document.getElementById('nwQueryInp');
    if (nwQ) {
      nwQ.onkeydown = (ev) => { if (F1.isEnterSend(ev)) { F1.state.newsQuery = nwQ.value; F1.render(); } };
      nwQ.onblur = () => { if (F1.state.newsQuery !== nwQ.value) { F1.state.newsQuery = nwQ.value; F1.render(); } };
    }
  };
})();
