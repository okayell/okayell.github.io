/* F1 運彩智庫 — Core SPA Router, State, IME-Safe Input, Telemetry Modals & Release Center */
(function () {
  'use strict';

  const _isPublicStaticHost = Boolean(
    window.F1_STATIC_ONLY ||
    location.protocol === 'file:' ||
    /\.github\.io$|\.pages\.dev$|\.netlify\.app$|\.vercel\.app$/i.test(location.hostname || '')
  );

  // Single-file builds embed the snapshot as <script type="application/json"> (JSON.parse is much faster
  // than evaluating a multi-MB object literal); drop the node afterwards so its text can be freed.
  function readEmbeddedSnapshot() {
    const el = document.getElementById('staticSnapshot');
    if (!el) return null;
    try { return JSON.parse(el.textContent); } catch (_) { return null; } finally { el.remove(); }
  }

  const F1 = (window.F1 = {
    isStatic: _isPublicStaticHost,
    snap: readEmbeddedSnapshot(),
    health: { ok: true, ai: false, version: '1.0.0' },
    bets: [],
    pages: {},
    route: 'picks',
    state: {
      picksRound: 0,
      picksFilter: 'ALL',
      picksSearch: '',
      resultsRound: 'ALL',
      resultsTab: 'ledger',
      activeTeam: 'MER',
      teamGameId: '',
      statsEntity: 'drivers',
      statsTeam: 'ALL',
      statsSearch: '',
      statsSort: 'pts',
      statsDir: 'desc',
      teamStatsSort: 'pts',
      teamStatsDir: 'desc',
      newsTab: 'tech',
      techTeam: 'ALL',
      techStatus: 'ALL',
      newsCat: 'ALL',
      newsTeam: 'ALL',
      newsQuery: '',
    },
  });

  // --- IME-Safe Enter Guard (Pattern 9 — Mandatory for Traditional Chinese IMEs) ---
  let _imeComposing = false;
  let _lastImeEndAt = 0;
  document.addEventListener('compositionstart', () => { _imeComposing = true; }, true);
  document.addEventListener('compositionend', () => { _imeComposing = false; _lastImeEndAt = Date.now(); }, true);
  F1.isEnterSend = function (ev) {
    return (
      ev.key === 'Enter' &&
      !ev.shiftKey &&
      !ev.isComposing &&
      ev.keyCode !== 229 &&
      !_imeComposing &&
      Date.now() - _lastImeEndAt >= 150
    );
  };

  F1.esc = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  F1.fmtSigned = function (val, digits = 1) {
    if (val == null || val === '') return '—';
    const n = Number(val);
    if (Number.isNaN(n)) return '—';
    return (n > 0 ? '+' : '') + n.toFixed(digits);
  };

  F1.teamMap = {};
  F1.driverMap = {};
  F1.raceMap = {};
  F1.teamOf = function (abbr) {
    return F1.teamMap[abbr] || { abbr: abbr || 'F1', zh: abbr || '車隊', en: abbr || '', logo: '', color: '#334155' };
  };
  F1.driverOf = function (code) {
    return F1.driverMap[code] || { code: code || '', zh: code || '', en: code || '', team: 'F1', headshot: '' };
  };

  F1.toast = function (msg) {
    const box = document.getElementById('toastBox');
    if (!box) return;
    const el = document.createElement('div');
    el.className = 'toast-msg';
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => { el.remove(); }, 3200);
  };

  F1.apiGet = async function (path) {
    if (F1.isStatic) {
      if (path === '/api/snapshot') return F1.snap;
      if (path === '/api/bets') {
        let list = [];
        try { list = JSON.parse(localStorage.getItem('f1.bets.v1') || '[]'); } catch (_) { list = []; }
        const graded = F1._gradeStaticBets(list);
        if (graded.changed) {
          try { localStorage.setItem('f1.bets.v1', JSON.stringify(graded.list)); } catch (_) { /* 無痕模式或空間不足：略過 */ }
        }
        return { bets: graded.list };
      }
      if (path === '/api/feedback') {
        try { return { ok: true, items: JSON.parse(localStorage.getItem('f1.feedback.v1') || '[]') }; }
        catch (_) { return { ok: true, items: [] }; }
      }
      if (path === '/api/release_status') {
        const rd = window.F1_RELEASES || { current_version: '1.0.0', releases: [] };
        return { static: true, current_version: rd.current_version, has_changes: false, changed_files: [], releases: rd.releases || [] };
      }
      return {};
    }
    const r = await fetch(path, { headers: { Accept: 'application/json' } });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  };

  F1.apiPost = async function (path, body) {
    if (F1.isStatic) {
      if (path.startsWith('/api/bets/')) return F1._staticBetAction(path, body || {});
      throw new Error('靜態離線版不支援雲端背景操作，請在主機環境操作。');
    }
    const r = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body || {}),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  };

  F1._staticBetAction = function (path, body) {
    let list = [];
    try { list = JSON.parse(localStorage.getItem('f1.bets.v1') || '[]'); } catch (_) { list = []; }
    if (path === '/api/bets/add') {
      list.unshift({
        bet_id: 'BET-' + Date.now().toString(36).toUpperCase(),
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
        tw_date: body.tw_date || '',
        game_id: body.game_id || '',
        matchup: body.matchup || '',
        market: body.market || 'H2H',
        pick_side: body.pick_side || 'A',
        pick_label: body.pick_label || '',
        line: Number(body.line || 0),
        odds_decimal: Number(body.odds_decimal || 1.91),
        stake: Number(body.stake || 1000),
        status: 'PENDING',
        pnl: 0,
        note: body.note || '',
      });
      list = F1._gradeStaticBets(list).list;
    } else if (path === '/api/bets/settle') {
      list = list.map((b) => {
        if (b.bet_id !== body.bet_id) return b;
        const st = body.status || 'PENDING';
        const pnl = st === 'WIN' ? +(b.stake * (b.odds_decimal - 1)).toFixed(2) : st === 'LOSS' ? -b.stake : 0;
        return { ...b, status: st, pnl };
      });
    } else if (path === '/api/bets/delete') {
      list = list.filter((b) => b.bet_id !== body.bet_id);
    }
    localStorage.setItem('f1.bets.v1', JSON.stringify(list));
    return { ok: true, bets: list };
  };

  // GitHub Pages / offline builds have no backend, so settle PENDING bets in the browser against the
  // bundled snapshot with the same rules as model_engine._grade_user_bets: H2H compares the two
  // drivers' race positions; finishers O/U compares classified cars with the line (exact = PUSH).
  F1._gradeStaticBets = function (list) {
    const races = (F1.snap && F1.snap.races) || [];
    let changed = false;
    const out = list.map((b) => {
      if (b.status !== 'PENDING') return b;
      const mkt = String(b.market || '').toUpperCase();
      const side = String(b.pick_side || '').toUpperCase();
      const gid = String(b.game_id || '');
      let st = '';
      if (mkt === 'H2H' && gid) {
        let m = null;
        for (const rc of races) {
          m = (rc.h2h || []).find((x) => x.matchup_id === gid);
          if (m) break;
        }
        if (m && m.pos_a != null && m.pos_b != null) {
          st = (side === 'A' && m.pos_a < m.pos_b) || (side === 'B' && m.pos_b < m.pos_a) ? 'WIN' : 'LOSS';
        }
      } else if (mkt === 'OU' && /^R\d+/.test(gid)) {
        const rc = races.find((r) => r.round === parseInt(gid.slice(1), 10));
        if (rc && rc.status === 'FINAL' && rc.classified_count != null) {
          const n = Number(rc.classified_count);
          const ln = Number(b.line || 18.5);
          st = n === ln ? 'PUSH' : (side === 'OVER' && n > ln) || (side === 'UNDER' && n < ln) ? 'WIN' : 'LOSS';
        }
      }
      if (!st) return b;
      changed = true;
      const stake = Number(b.stake || 0);
      const pnl = st === 'WIN' ? +(stake * (Number(b.odds_decimal) - 1)).toFixed(2) : st === 'LOSS' ? -stake : 0;
      return { ...b, status: st, pnl };
    });
    return { list: out, changed };
  };

  F1.openModal = function (title, bodyHtml, sizeCls) {
    const card = document.getElementById('appModalCard');
    if (card) card.className = 'modal-card' + (sizeCls ? ' ' + sizeCls : '');
    document.getElementById('appModalTitle').textContent = title;
    document.getElementById('appModalBody').innerHTML = bodyHtml;
    document.getElementById('appModalBd').classList.remove('hidden');
  };
  F1.closeModal = function () {
    document.getElementById('appModalBd').classList.add('hidden');
  };

  // --- Full 22-Car Grand Prix Telemetry Table ---
  // cols: [0:code, 1:zh, 2:en, 3:num, 4:team, 5:grid, 6:pos, 7:pos_text, 8:gain,
  //        9:points, 10:sprint_pts, 11:laps, 12:time_str, 13:classified, 14:fl_rank, 15:fl_time, 16:q_best]
  F1.renderRaceTelemetryHtml = function (gid) {
    const rc = ((F1.snap && F1.snap.races) || []).find((x) => x.game_id === gid);
    if (!rc) return '<div class="empty-box">找不到該分站紀錄</div>';
    const rows = ((F1.snap && F1.snap.race_telemetries) || {})[gid] || [];
    const cp = rc.circuit_profile || {};
    if (!rows.length) {
      return `<div class="empty-box">R${rc.round} ${F1.esc(rc.gp_zh)} 尚未完賽（正賽台灣時間：${F1.esc(rc.race_tw)}）</div>`;
    }
    return `
      <div style="display:flex;flex-direction:column;gap:12px">
        <div class="card" style="background:#f8fafc;padding:12px 16px">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
            <div>
              <strong style="font-size:16px">🏁 R${rc.round} ${F1.esc(rc.gp_zh)} · ${F1.esc(rc.circuit_zh)}</strong>
              <div style="font-size:12px;color:#64748b;margin-top:2px">
                正賽時間：${F1.esc(rc.race_tw)} ｜ ${F1.esc(cp.type_zh || '')} ｜ 完賽 ${rc.classified_count} 台 / 退賽 ${rc.dnf_count} 台（盤口 ${rc.finishers_line} 台 → ${rc.ou_result === 'OVER' ? '大分 OVER' : rc.ou_result === 'UNDER' ? '小分 UNDER' : '走水'}）
              </div>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              ${rc.winner_zh ? `<span class="chip strong">🏆 冠軍：${F1.esc(rc.winner_zh)}</span>` : ''}
              ${rc.pole_zh ? `<span class="chip info">⚡ 桿位：${F1.esc(rc.pole_zh)}</span>` : ''}
              ${rc.fastest_zh ? `<span class="chip ok">⏱️ 最快圈：${F1.esc(rc.fastest_zh)}</span>` : ''}
            </div>
          </div>
        </div>
        <div class="nba-tbl-wrap standalone">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="sticky-rk no-sort">名次</th>
                <th class="left sticky-pl no-sort">車手 DRIVER</th>
                <th class="left no-sort">車隊</th>
                <th class="no-sort">起跑位</th>
                <th class="no-sort">淨推進</th>
                <th class="no-sort">排位最佳圈</th>
                <th class="no-sort">完成圈數</th>
                <th class="left no-sort">完賽時間 / 狀態</th>
                <th class="no-sort">最快單圈</th>
                <th class="no-sort col-active">積分 PTS</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((r) => {
                const tm = F1.teamOf(r[4]);
                const gain = r[8];
                const gainTxt = !r[13] ? 'DNF' : gain > 0 ? `▲ +${gain}` : gain < 0 ? `▼ ${gain}` : '—';
                const gainCol = !r[13] ? '#b91c1c' : gain > 0 ? '#15803d' : gain < 0 ? '#b91c1c' : '#64748b';
                const totPts = r[9] + r[10];
                return `
                  <tr>
                    <td class="sticky-rk" style="font-weight:800;color:${r[6] <= 3 ? '#b45309' : '#334155'}">${F1.esc(r[7])}</td>
                    <td class="left sticky-pl">
                      <span class="pl-link" data-player-id="${F1.esc(r[0])}" style="font-weight:800;color:#1d4ed8">${F1.esc(r[1])} (${F1.esc(r[0])})</span>
                      ${r[3] ? `<span style="color:#94a3b8;font-size:11px;margin-left:3px">#${F1.esc(r[3])}</span>` : ''}
                    </td>
                    <td class="left">
                      <span class="tm-link" data-team-link="${F1.esc(r[4])}" style="display:inline-flex;align-items:center;gap:5px;font-weight:700">
                        <span style="width:9px;height:9px;border-radius:50%;background:${F1.esc(tm.color)}"></span>
                        ${F1.esc(tm.zh)}
                      </span>
                    </td>
                    <td>P${r[5] || '—'}</td>
                    <td style="font-weight:700;color:${gainCol}">${gainTxt}</td>
                    <td>${F1.esc(r[16] || '—')}</td>
                    <td>${r[11]}</td>
                    <td class="left" style="color:${r[13] ? '#1e293b' : '#b91c1c'};font-weight:${r[13] ? '500' : '700'}">${F1.esc(r[12])}</td>
                    <td>${r[14] === 1 ? '🟣 ' : ''}${F1.esc(r[15] || '—')}</td>
                    <td class="col-active">${totPts > 0 ? totPts : '0'}${r[10] > 0 ? ` <span style="font-size:10.5px;color:#64748b">(+${r[10]}衝)</span>` : ''}</td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
  };

  F1.openGameBoxscoreModal = function (gid) {
    const rc = ((F1.snap && F1.snap.races) || []).find((x) => x.game_id === gid);
    if (!rc) return;
    F1.openModal(`🏁 單站 22 車完整遙測與成績 · R${rc.round} ${rc.gp_zh}`, F1.renderRaceTelemetryHtml(gid), 'modal-xl');
  };

  F1.openPlayerModal = function (code) {
    const snap = F1.snap || {};
    const d = (snap.driver_stats || []).find((x) => x.code === code);
    if (!d) {
      F1.toast('找不到該車手本季紀錄');
      return;
    }
    const tm = F1.teamOf(d.team);
    const logs = [];
    const tels = snap.race_telemetries || {};
    (snap.races || []).forEach((rc) => {
      const row = (tels[rc.game_id] || []).find((r) => r[0] === code);
      if (row) logs.push({ rc, row });
    });
    logs.reverse();

    const bodyHtml = `
      <div style="display:flex;flex-direction:column;gap:14px">
        <div class="card" style="background:linear-gradient(135deg,#fef2f2 0%,#ffffff 100%);display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:14px">
            <img loading="lazy" decoding="async" src="${F1.esc(d.headshot)}" alt="" style="width:62px;height:62px;border-radius:14px;object-fit:contain">
            <div>
              <div style="font-size:20px;font-weight:900;color:#0f172a">
                ${F1.esc(d.zh)} <span style="font-size:15px;color:#475569">${F1.esc(d.en)}</span>
                ${d.num ? `<span style="color:#dc2626;font-size:15px">#${F1.esc(d.num)}</span>` : ''}
              </div>
              <div style="font-size:13px;color:#475569;margin-top:3px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
                <span class="tm-link" data-team-link="${F1.esc(d.team)}" style="font-weight:700;color:#dc2626">🏎️ ${F1.esc(tm.zh)} (${F1.esc(d.team)})</span>
                <span>年度排名：P${d.rank}</span>
                <span>國籍：${F1.esc(d.country || '—')}</span>
                <span>出賽 ${d.gp} 站</span>
              </div>
            </div>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <div class="th-stat"><div class="th-stat-lbl">年度積分 PTS</div><div class="th-stat-val" style="color:#dc2626">${d.pts}</div></div>
            <div class="th-stat"><div class="th-stat-lbl">分站勝 / 頒獎台</div><div class="th-stat-val">${d.wins} / ${d.podiums}</div></div>
            <div class="th-stat"><div class="th-stat-lbl">平均起跑 / 完賽</div><div class="th-stat-val">P${d.avg_grid} / P${d.avg_finish}</div></div>
            <div class="th-stat"><div class="th-stat-lbl">配對戰績 H2H</div><div class="th-stat-val" style="color:#15803d">${d.h2h_w}W-${d.h2h_l}L (${d.h2h_pct}%)</div></div>
          </div>
        </div>
        <div>
          <h4 style="margin:0 0 8px;font-size:14.5px">📅 2026 逐站排位與正賽遙測明細（點擊分站可看 22 車全場成績）</h4>
          <div class="nba-tbl-wrap standalone">
            <table class="nba-stats-tbl">
              <thead>
                <tr>
                  <th class="left no-sort">站別</th>
                  <th class="left no-sort">大獎賽</th>
                  <th class="no-sort">排位最佳圈</th>
                  <th class="no-sort">起跑位</th>
                  <th class="no-sort col-active">完賽名次</th>
                  <th class="no-sort">淨推進</th>
                  <th class="left no-sort">完賽狀態 / 差距</th>
                  <th class="no-sort">最快單圈</th>
                  <th class="no-sort">積分</th>
                </tr>
              </thead>
              <tbody>
                ${logs.map(({ rc, row }) => `
                  <tr>
                    <td class="left">R${rc.round} (${F1.esc(rc.tw_date)})</td>
                    <td class="left">
                      <button type="button" class="btn btn-sm" data-boxscore-gid="${F1.esc(rc.game_id)}" style="padding:2px 8px;font-size:12px">
                        🏁 ${F1.esc(rc.gp_zh)} 📊
                      </button>
                    </td>
                    <td>${F1.esc(row[16] || '—')}</td>
                    <td>P${row[5]}</td>
                    <td class="col-active">${F1.esc(row[7])}</td>
                    <td style="font-weight:700;color:${!row[13] ? '#b91c1c' : row[8] > 0 ? '#15803d' : row[8] < 0 ? '#b91c1c' : '#64748b'}">${!row[13] ? 'DNF' : row[8] > 0 ? '+' + row[8] : row[8]}</td>
                    <td class="left">${F1.esc(row[12])}</td>
                    <td>${row[14] === 1 ? '🟣 ' : ''}${F1.esc(row[15] || '—')}</td>
                    <td style="font-weight:700">${row[9] + row[10]}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>`;
    F1.openModal(`👨‍🚀 車手賽季遙測檔案 · ${d.zh} (${d.code})`, bodyHtml, 'modal-xl');
  };

  // --- Quick Bet Slip Modal（➕ 加入注單追蹤）---
  // Guided form instead of free-text fields: ① tap the side you back (this sets `pick_side`, which
  // auto-settlement grades) → ② odds (+ the line for O/U) → ③ stake, with a live payout preview.
  // The market is fixed by the card that opened the modal (H2H matchup card or finishers O/U card).
  F1.openQuickBetModal = function (mid, market) {
    const snap = F1.snap || {};
    let rc = null;
    let m = null;
    for (const r of snap.races || []) {
      if (r.game_id === mid) { rc = r; break; }
      m = (r.h2h || []).find((x) => x.matchup_id === mid) || null;
      if (m) { rc = r; break; }
    }
    if (!rc) return;

    const isH2H = market === 'H2H' && Boolean(m);
    const gp = `R${rc.round} ${rc.gp_zh}`;
    const matchup = isH2H ? `${gp} · ${m.driver_a_zh} vs ${m.driver_b_zh}` : gp;
    const money = (n) => Math.round(n).toLocaleString('en-US');
    let options;
    let recSide;
    let recIsPick;
    let stepTitle;
    if (isH2H) {
      const probA = Number(m.model_prob_a || 50);
      options = [
        { side: 'A', code: m.driver_a, zh: m.driver_a_zh, rival: m.driver_b_zh, team: m.team_a, odds: Number(m.close_odds_a) || 1.85, prob: probA.toFixed(1) },
        { side: 'B', code: m.driver_b, zh: m.driver_b_zh, rival: m.driver_a_zh, team: m.team_b, odds: Number(m.close_odds_b) || 1.85, prob: (100 - probA).toFixed(1) },
      ];
      recSide = m.pick_side === 'B' ? 'B' : 'A';
      recIsPick = m.tier !== 'PASS';
      stepTitle = '① 你看好哪一位車手？（點一下選擇）';
    } else {
      const oup = rc.ou_pred || {};
      options = [
        { side: 'OVER', zh: '大 OVER', odds: 1.91 },
        { side: 'UNDER', zh: '小 UNDER', odds: 1.91 },
      ];
      recIsPick = Boolean(oup.tier) && oup.tier !== 'PASS' && (oup.pick === 'OVER' || oup.pick === 'UNDER');
      recSide = recIsPick ? oup.pick : (oup.lean_side === 'OVER' ? 'OVER' : 'UNDER');
      stepTitle = `① 押大還是押小？（點一下選擇）${oup.pred_finishers ? `<span class="qb-step-sub">模型預估完賽 ${F1.esc(oup.pred_finishers)} 台</span>` : ''}`;
    }
    const optOf = (s) => options.find((o) => o.side === s) || options[0];
    const recChip = recIsPick ? '<span class="chip strong">👍 模型推薦</span>' : '<span class="chip muted">模型傾向</span>';
    const optHtml = (o) => `
      <label class="qb-opt" data-qb-side="${o.side}">
        <input type="radio" name="qbSide" value="${o.side}">
        <span class="qb-opt-hd">
          <span class="qb-opt-name"><span class="qb-radio" aria-hidden="true"></span>${F1.esc(isH2H ? `${o.zh} (${o.code})` : o.zh)}</span>
          ${o.side === recSide ? recChip : ''}
        </span>
        ${isH2H
          ? `<span class="qb-opt-sub">${F1.esc(F1.teamOf(o.team).zh)} · 模型勝率 ${o.prob}%</span>
             <span class="qb-opt-sub">本站參考賠率 <strong>${o.odds.toFixed(2)}</strong></span>`
          : `<span class="qb-opt-sub" data-qb-ou-desc="${o.side}"></span>`}
      </label>`;
    const explainHtml = isH2H
      ? '🏎️ <strong>車手配對盤（H2H）</strong>：只比這兩位車手在正賽的<strong>最終名次</strong>誰比較前面，跟誰拿冠軍無關；中途退賽（DNF）的車手名次會排在完賽者後面。'
      : '🚨 <strong>完賽車數大小盤</strong>：猜這站正賽最後有幾台車<strong>完賽</strong>（列入正式成績）；退賽、事故越多，完賽車數就越少。';
    const lineRowHtml = isH2H ? '' : `
      <div class="qb-line-row">
        <label for="qbLine">盤口線</label>
        <input type="number" inputmode="decimal" step="0.5" min="1" max="22" class="inp" id="qbLine" value="${Number(rc.finishers_line || 18.5)}">
        <span>台</span>
        <span class="qb-hint" id="qbLineHint"></span>
      </div>`;
    const oddsHint = isH2H
      ? '已帶入本站 18:00 初盤／23:00 定盤的參考賠率，請改成你實際下注時看到的數字。'
      : '預設 1.91 僅供參考，請改成你實際下注時看到的數字。';

    F1.openModal(
      `➕ 加入注單追蹤 · ${matchup}`,
      `<form id="quickBetForm" class="qb-form" novalidate>
        <div class="qb-explain">${explainHtml}</div>
        <div class="qb-step" role="radiogroup" aria-labelledby="qbStepPick">
          <div class="qb-step-title" id="qbStepPick">${stepTitle}</div>
          <div class="qb-opts">${options.map(optHtml).join('')}</div>
          ${lineRowHtml}
        </div>
        <div class="qb-fields">
          <label class="qb-field">
            <span class="qb-step-title">② 賠率</span>
            <input type="number" inputmode="decimal" step="0.01" min="1.01" class="inp" id="qbOdds" value="${optOf(recSide).odds.toFixed(2)}">
            <span class="qb-hint">${oddsHint}</span>
          </label>
          <div class="qb-field">
            <label class="qb-step-title" for="qbStake">③ 投注金額（NT$）</label>
            <input type="number" inputmode="numeric" step="100" min="1" class="inp" id="qbStake" value="1000">
            <div class="qb-chips">${[100, 500, 1000, 2000, 5000].map((v) => `<button type="button" class="qb-chip" data-qb-stake="${v}">${money(v)}</button>`).join('')}</div>
          </div>
        </div>
        <div class="qb-preview" id="qbPreview" aria-live="polite"></div>
        <label class="qb-field">
          <span class="qb-step-title">備註（選填）</span>
          <input class="inp" id="qbNote" maxlength="200" placeholder="例如：排位 Q3 領先、確認無罰退後進場">
        </label>
        <div class="qb-foot">📌 這裡只是幫你<strong>記帳</strong>，不會真的下注。正賽結束後系統會自動對獎、計算損益，可到「📝 注單追蹤」查看${F1.isStatic ? '（公開版的注單只存在這台裝置的瀏覽器）' : ''}。</div>
        <div class="qb-actions">
          <button type="button" class="btn" data-qb-cancel>取消</button>
          <button type="submit" class="btn btn-primary" id="qbSubmit">💾 儲存注單</button>
        </div>
      </form>`
    );

    const form = document.getElementById('quickBetForm');
    const oddsInp = document.getElementById('qbOdds');
    const stakeInp = document.getElementById('qbStake');
    const lineInp = document.getElementById('qbLine');
    const preview = document.getElementById('qbPreview');
    const submitBtn = document.getElementById('qbSubmit');
    let side = recSide;
    let saving = false;

    // O/U grades classified finishers against the line: a .5 line never pushes; on a whole-number
    // line an exact hit is a push (stake refunded) — same rule as model_engine._grade_user_bets.
    const ouCut = (ln) => ({ over: Math.floor(ln) + 1, under: Math.ceil(ln) - 1, push: Number.isInteger(ln) ? ln : null });

    function refresh() {
      const odds = Number(oddsInp.value);
      const stake = Number(stakeInp.value);
      const ln = lineInp ? Number(lineInp.value) : 0;
      const lineOk = !lineInp || (lineInp.value.trim() !== '' && ln >= 1 && ln <= 22);
      const oddsOk = oddsInp.value.trim() !== '' && odds >= 1.01;
      const stakeOk = stakeInp.value.trim() !== '' && stake >= 1;
      if (lineInp) lineInp.classList.toggle('inp-err', !lineOk);
      oddsInp.classList.toggle('inp-err', !oddsOk);
      stakeInp.classList.toggle('inp-err', !stakeOk);
      form.querySelectorAll('[data-qb-stake]').forEach((b) => b.classList.toggle('on', Number(b.getAttribute('data-qb-stake')) === stake));

      const cut = lineInp && lineOk ? ouCut(ln) : null;
      if (cut) {
        form.querySelector('[data-qb-ou-desc="OVER"]').textContent = `完賽 ${cut.over} 台以上（退賽少、比賽平穩）`;
        form.querySelector('[data-qb-ou-desc="UNDER"]').textContent = `完賽 ${cut.under} 台以下（事故、退賽多）`;
        document.getElementById('qbLineHint').textContent =
          `${ln} 代表 ${cut.over} 台以上算「大」、${cut.under} 台以下算「小」${cut.push != null ? `，剛好 ${cut.push} 台算走水（退回本金）` : ''}；請對照你下注的盤口。`;
      }

      const errs = [];
      if (!lineOk) errs.push('請填盤口線，例如 17.5');
      if (!oddsOk) errs.push('賠率要大於 1，例如 1.85');
      if (!stakeOk) errs.push('請填投注金額，例如 1000');
      submitBtn.disabled = saving || errs.length > 0;
      if (errs.length) {
        preview.className = 'qb-preview invalid';
        preview.innerHTML = errs.map((e) => `<div>⚠️ ${e}</div>`).join('');
        return;
      }
      const o = optOf(side);
      const back = stake * odds;
      let win;
      let lose;
      let pushHtml = '';
      if (isH2H) {
        win = `「${o.zh}」名次在「${o.rival}」前面`;
        lose = `「${o.zh}」名次落後`;
      } else {
        win = side === 'OVER' ? `完賽 ${cut.over} 台以上` : `完賽 ${cut.under} 台以下`;
        lose = side === 'OVER' ? `完賽 ${cut.under} 台以下` : `完賽 ${cut.over} 台以上`;
        if (cut.push != null) pushHtml = `<div class="push">若剛好 ${cut.push} 台 → 走水，退回本金 NT$${money(stake)}</div>`;
      }
      preview.className = 'qb-preview';
      preview.innerHTML = `
        <div>💰 若${F1.esc(win)} → 可領回 <strong>NT$${money(back)}</strong>（含本金，淨賺 <strong>+${money(back - stake)}</strong>）</div>
        <div class="loss">若${F1.esc(lose)} → 損失本金 NT$${money(stake)}</div>
        ${pushHtml}`;
    }

    function selectSide(s) {
      side = s;
      form.querySelectorAll('.qb-opt').forEach((el) => {
        const on = el.getAttribute('data-qb-side') === s;
        el.classList.toggle('selected', on);
        el.querySelector('input').checked = on;
      });
      // Each driver has their own price, so switching drivers swaps in that driver's reference odds.
      if (isH2H) oddsInp.value = optOf(s).odds.toFixed(2);
      refresh();
    }

    form.querySelectorAll('input[name="qbSide"]').forEach((r) => {
      r.addEventListener('change', () => { if (r.checked) selectSide(r.value); });
    });
    form.querySelectorAll('[data-qb-stake]').forEach((b) => {
      b.addEventListener('click', () => { stakeInp.value = b.getAttribute('data-qb-stake'); refresh(); });
    });
    [lineInp, oddsInp, stakeInp].forEach((inp) => { if (inp) inp.addEventListener('input', refresh); });
    // IME-safe: the Enter that confirms a 注音／倉頡 candidate in 備註 must not submit the form.
    form.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' && ev.target.tagName === 'INPUT' && !F1.isEnterSend(ev)) ev.preventDefault();
    });
    form.querySelector('[data-qb-cancel]').addEventListener('click', F1.closeModal);
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      refresh();
      if (saving || submitBtn.disabled) return;
      saving = true;
      submitBtn.disabled = true;
      submitBtn.textContent = '⏳ 儲存中…';
      const o = optOf(side);
      const ln = lineInp ? Number(lineInp.value) : 0;
      try {
        const res = await F1.apiPost('/api/bets/add', {
          tw_date: rc.tw_date,
          game_id: isH2H ? m.matchup_id : rc.game_id,
          matchup,
          market: isH2H ? 'H2H' : 'OU',
          pick_side: side,
          pick_label: isH2H ? `${o.zh} 勝出` : `完賽車數 ${side === 'OVER' ? '大於' : '小於'} ${ln} 台`,
          line: ln,
          odds_decimal: Number(oddsInp.value),
          stake: Number(stakeInp.value),
          note: document.getElementById('qbNote').value.trim(),
        });
        F1.bets = res.bets || [];
        F1.closeModal();
        F1.toast('✅ 已加入注單！正賽結束後會自動對獎，可到「📝 注單追蹤」查看');
      } catch (e) {
        saving = false;
        submitBtn.textContent = '💾 儲存注單';
        refresh();
        F1.toast('⚠️ ' + e.message);
      }
    });
    selectSide(recSide);
  };

  F1.openAiGameDive = async function (mid) {
    F1.openModal(
      `🤖 AI 賽道與配對深度解盤 · ${mid}`,
      `<div class="loading-box" style="padding:24px">🧠 正在透過 Jetski 語言伺服器結合賽道空力特性、排位配速與量化因子撰寫解盤報告（約需 8–18 秒）…</div>`
    );
    try {
      const st = await F1.apiPost('/api/ai/start', { kind: 'game_deep_dive', matchup_id: mid });
      const tid = st.task;
      for (let i = 0; i < 55; i++) {
        await new Promise((r) => setTimeout(r, 1200));
        const tk = await F1.apiGet(`/api/ai/task?id=${encodeURIComponent(tid)}`);
        if (tk.status === 'done' && tk.result) {
          const d = tk.result;
          document.getElementById('appModalBody').innerHTML = `
            <div style="display:flex;flex-direction:column;gap:12px">
              <div class="card" style="background:#fef2f2;border-color:#fca5a5">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
                  <strong style="font-size:15px;color:#991b1b">📌 ${F1.esc(d.headline || '本站實戰結論')}</strong>
                  <span class="chip strong">${F1.esc(d.risk_level || '量化評估')}</span>
                </div>
                <div style="font-size:13.5px;color:#1e293b">${F1.esc(d.summary || '')}</div>
              </div>
              ${d.ats_verdict ? `<div class="card"><strong>🏎️ 車手配對盤 (H2H) 深度分析</strong><p style="margin:6px 0 0;color:#334155">${F1.esc(d.ats_verdict)}</p></div>` : ''}
              ${d.ou_verdict ? `<div class="card"><strong>🚨 完賽車數大小盤／頒獎台價值分析</strong><p style="margin:6px 0 0;color:#334155">${F1.esc(d.ou_verdict)}</p></div>` : ''}
              ${d.injury_watch ? `<div class="card" style="background:#fffbeb;border-color:#fde68a"><strong>🔧 Parc Fermé 排位與罰退觀察重點</strong><p style="margin:6px 0 0;color:#78350f">${F1.esc(d.injury_watch)}</p></div>` : ''}
            </div>`;
          return;
        }
        if (tk.status === 'error') throw new Error(tk.error || 'AI 解盤失敗');
      }
      throw new Error('AI 回覆逾時，請稍後再試');
    } catch (e) {
      document.getElementById('appModalBody').innerHTML = `<div class="empty-box">⚠️ ${F1.esc(e.message)}</div>`;
    }
  };

  // --- Release Notes & Smart 1.x.x Publisher Modal (Pattern 164 / 173) ---
  let _publishConfirmArmed = false;
  F1.openReleaseModal = async function () {
    _publishConfirmArmed = false;
    const bd = document.getElementById('relModal');
    const ttl = document.getElementById('relModalTitle');
    const body = document.getElementById('relModalBody');
    if (ttl) {
      ttl.textContent = F1.isStatic ? '📜 F1 運彩智庫 · Release Notes' : '🚀 F1 運彩智庫 · 版本紀錄與發布中心';
    }
    bd.classList.remove('hidden');
    body.innerHTML = '<div class="loading-box">讀取版本更新紀錄中…</div>';
    try {
      const st = await F1.apiGet('/api/release_status');
      renderReleaseModalBody(st);
    } catch (_) {
      const rd = window.F1_RELEASES || { current_version: '1.0.0', releases: [] };
      renderReleaseModalBody({ static: true, current_version: rd.current_version, has_changes: false, changed_files: [], releases: rd.releases || [] });
    }
  };

  function renderReleaseModalBody(st) {
    const body = document.getElementById('relModalBody');
    const ttl = document.getElementById('relModalTitle');
    const isLocal = !F1.isStatic && !(st && st.static);
    if (ttl) {
      ttl.textContent = isLocal ? '🚀 F1 運彩智庫 · 版本紀錄與發布中心' : '📜 F1 運彩智庫 · Release Notes';
    }
    const dlHtml = isLocal
      ? `<div class="card" style="background:#f8fafc;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
          <div>
            <strong>📦 GitHub Pages 單一檔案匯出（免安裝靜態版）</strong>
            <div class="sec-sub">將最新 2026 F1 賽季快照、遙測與所有介面打包成單一 <code>index.html</code>，直接上傳 GitHub 即可公開瀏覽。</div>
          </div>
          <a class="btn btn-soft" href="/download/index.html" download="index.html">⬇️ 直接下載最新 index.html</a>
        </div>`
      : '';

    let dirtyHtml = '';
    if (isLocal && st.has_changes) {
      const rec = st.recommended_bump || 'patch';
      const nv = st.next_versions || {};
      dirtyHtml = `
        <div class="card" style="border-color:#fcd34d;background:#fffdf7;margin-bottom:16px">
          <div class="sec-hdr" style="margin-bottom:8px">
            <div>
              <strong style="font-size:15px">🛠️ 偵測到 ${st.changed_files.length} 個未發布檔案變更（+${st.total_added} / -${st.total_removed} 行）</strong>
              <div class="sec-sub">${F1.esc(st.recommend_reason || '')}</div>
            </div>
            <span class="chip warn">目前 v${F1.esc(st.current_version)}</span>
          </div>
          <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:10px">
            ${['patch', 'minor', 'major'].map((b) => `
              <label class="card" style="padding:9px 11px;cursor:pointer;background:${rec === b ? '#fef2f2' : '#fff'};border-color:${rec === b ? '#dc2626' : '#cbd5e1'}">
                <input type="radio" name="relBump" value="${b}" ${rec === b ? 'checked' : ''}>
                <strong>v${F1.esc(nv[b] || '')}</strong>
                <span class="chip ${rec === b ? 'strong' : 'muted'}" style="margin-left:4px">${b === 'major' ? '進第1位' : b === 'minor' ? '進第2位' : '進第3位'}</span>
                <div style="font-size:11.5px;color:#475569;margin-top:4px">${F1.esc((st.bump_descriptions || {})[b] || '')}</div>
              </label>
            `).join('')}
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px">
            <input class="inp" id="relTitleInp" value="${F1.esc(st.suggested_title || '')}" placeholder="版本標題">
            <textarea class="inp" id="relHlInp" rows="3" placeholder="每行一條更新重點">${F1.esc((st.suggested_highlights || []).join('\n'))}</textarea>
          </div>
          <div style="display:flex;justify-content:flex-end">
            <button type="button" class="btn btn-primary" id="relPublishBtn">🚀 發布新版本並同步重新打包</button>
          </div>
        </div>`;
    } else if (isLocal) {
      dirtyHtml = `<div class="card" style="background:#f0fdf4;border-color:#bbf7d0;margin-bottom:14px;font-size:13px;color:#166534">✅ 目前工作目錄所有程式碼皆與最新發布版 <strong>v${F1.esc(st.current_version)}</strong> 同步，無待發布修改。</div>`;
    }

    const histHtml = (st.releases || []).map((r) => `
      <div class="card" style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
          <div>
            <span class="chip strong">v${F1.esc(r.version)}</span>
            <strong style="margin-left:6px">${F1.esc(r.title || '')}</strong>
          </div>
          <span style="font-size:12px;color:#64748b">${F1.esc(r.date || '')}</span>
        </div>
        <ul style="margin:6px 0 0;padding-left:18px;color:#334155;font-size:13px">
          ${(r.highlights || []).map((h) => `<li style="margin-bottom:3px">${F1.esc(h)}</li>`).join('')}
        </ul>
      </div>`).join('');

    body.innerHTML = dlHtml + dirtyHtml + `<h4 style="margin:8px 0">📜 Release Notes 歷史版本紀錄</h4>` + histHtml;

    const pubBtn = document.getElementById('relPublishBtn');
    if (pubBtn) {
      pubBtn.onclick = async () => {
        const picked = (document.querySelector('input[name="relBump"]:checked') || {}).value || 'patch';
        const targetVer = (st.next_versions || {})[picked] || '';
        if (!_publishConfirmArmed) {
          _publishConfirmArmed = true;
          pubBtn.textContent = `⚠️ 確定發布 v${targetVer}？再按一次確認`;
          return;
        }
        pubBtn.disabled = true;
        pubBtn.textContent = '⏳ 正在寫入版本與打包單一 HTML…';
        try {
          const title = document.getElementById('relTitleInp').value;
          const highlights = document.getElementById('relHlInp').value.split('\n').map((s) => s.trim()).filter(Boolean);
          const nextSt = await F1.apiPost('/api/release_publish', { bump_type: picked, title, highlights });
          _publishConfirmArmed = false;
          updateHeaderBadges(nextSt.current_version, nextSt.has_changes);
          renderReleaseModalBody(nextSt);
          F1.toast(`🎉 已發布 v${nextSt.current_version}！`);
        } catch (e) {
          pubBtn.disabled = false;
          _publishConfirmArmed = false;
          F1.toast('⚠️ ' + e.message);
        }
      };
    }
  }

  function updateHeaderBadges(ver, hasChanges) {
    const vb = document.getElementById('verBadgeBtn');
    if (vb) {
      const showDot = !F1.isStatic && hasChanges;
      vb.className = 'ver-badge' + (showDot ? ' has-changes' : '');
      vb.title = F1.isStatic ? `版本 v${ver}（點擊查看 Release Notes）` : '查看版本更新紀錄與發布新版本';
      vb.innerHTML = `v${F1.esc(ver)}${showDot ? '<span class="ver-dot" title="有尚未發布的修改"></span>' : ''}`;
    }
    const mp = document.getElementById('hdrModelPill');
    if (mp && F1.snap && F1.snap.meta) {
      const k = F1.snap.kpi || {};
      mp.textContent = `Model ${F1.snap.meta.model_version} · 強推勝率 ${k.strong_win_rate || 0}% (${k.strong_w || 0}W-${k.strong_l || 0}L)`;
    }
  }

  function rebuildLookups() {
    F1.teamMap = {};
    for (const t of (F1.snap && F1.snap.teams) || []) F1.teamMap[t.abbr] = t;
    F1.driverMap = {};
    for (const d of (F1.snap && F1.snap.driver_stats) || []) F1.driverMap[d.code] = d;
    F1.raceMap = {};
    for (const r of (F1.snap && F1.snap.races) || []) F1.raceMap[r.round] = r;
    const meta = (F1.snap && F1.snap.meta) || {};
    if (!F1.state.picksRound) F1.state.picksRound = meta.default_round || 19;
  }

  F1.render = function () {
    const hash = (window.location.hash || '#/picks').replace(/^#\/?/, '');
    const parts = hash.split('?')[0].split('/').filter(Boolean);
    const route = parts[0] || 'picks';
    const sub = (parts[1] || '').toUpperCase();
    if (route === 'team' && sub && F1.teamMap[sub] && F1.state.activeTeam !== sub) {
      F1.state.activeTeam = sub;
      F1.state.teamGameId = '';
    }
    if (route === 'stats' && parts[1]) {
      const ent = parts[1].toLowerCase();
      if (['drivers', 'teams', 'leaders'].includes(ent)) F1.state.statsEntity = ent;
    }
    const prevRoute = F1.route;
    F1.route = F1.pages[route] ? route : 'picks';

    document.querySelectorAll('#mainNav .nav-item').forEach((a) => {
      a.classList.toggle('active', a.getAttribute('data-route') === F1.route);
    });

    const main = document.getElementById('appMain');
    if (!F1.snap) {
      main.innerHTML = '<div class="loading-box">載入 F1 運彩智庫資料中…</div>';
      return;
    }
    const prevScroll = document.documentElement.style.scrollBehavior;
    document.documentElement.style.scrollBehavior = 'auto';
    try {
      F1.pages[F1.route](main);
    } catch (err) {
      console.error('[F1.render error]', err);
      main.innerHTML = `<div class="empty-box">⚠️ 頁面渲染發生例外：${F1.esc(err && err.message ? err.message : String(err))}</div>`;
    }
    if (F1._rendered && prevRoute !== F1.route) window.scrollTo(0, 0);
    F1._rendered = true;
    document.documentElement.style.scrollBehavior = prevScroll;
  };

  F1.refreshAllData = async function () {
    const [snap, betsRes] = await Promise.all([
      F1.apiGet('/api/snapshot'),
      F1.apiGet('/api/bets').catch(() => ({ bets: [] })),
    ]);
    F1.snap = snap;
    F1.bets = betsRes.bets || [];
    rebuildLookups();
    updateHeaderBadges(F1.health.version || '1.0.0', Boolean(F1.relHasChanges));
    F1.render();
  };

  F1.openDisclaimerModal = function () {
    F1.openModal(
      '⚖️ 法律與運動彩券風險免責聲明（Disclaimer）',
      `
        <div style="display:flex;flex-direction:column;gap:12px;font-size:13.5px;line-height:1.7;color:#1e293b">
          <div class="card" style="background:#fffbeb;border-color:#fcd34d;color:#78350f;padding:12px 15px">
            <strong>⚠️ 核心免責原則：</strong>使用本網站（F1 運彩智庫）即表示您已詳閱並完全同意本聲明。<strong>任何參考本站數據或模型分析所進行之投注行為與資金配置，其一切盈虧結果、本金損失與風險均由使用者自行判斷並完全自負，概與本站及開發者無關。</strong>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">1. 純賽車遙測統計與研究性質（非投注建議或勸誘）</div>
            <div>本站所有 F1 車手配對盤（H2H）、奪冠／頒獎台合理賠率、完賽車數大小盤推估與 AI 分析文字，均由電腦程式依據公開賽車數據自動運算產生，純供個人賽車數據研究與觀賽娛樂參考，<strong>絕不構成任何形式之投注建議、明牌報牌、招攬、勸誘或獲利保證</strong>。</div>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">2. 賽車高度隨機性與資料延遲免責</div>
            <div>F1 賽事極易受起跑擦撞、機械與動力單元故障（DNF）、安全車／紅旗時機、進站失誤、驟雨天候與 FIA 賽會判罰影響，歷史回測勝率絕不代表未來表現；公開資料可能存在延遲或與台灣運彩實際開盤不同，本站不負即時性與正確性擔保責任。</div>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">3. 損益完全自負與遵守所在地法令</div>
            <div><strong>不論獲利或虧損，一切財務風險皆由使用者個人完全承擔，本站及開發者概不負責。</strong>於中華民國境內請僅透過合法授權之「台灣運彩」管道參與（未滿 18 歲不得購買或兌領彩券），並嚴格衡量自身財務能力、理性參與。</div>
          </div>
        </div>
      `,
      'modal-lg'
    );
  };

  async function boot() {
    document.getElementById('appModalClose').onclick = F1.closeModal;
    document.getElementById('appModalBd').onclick = (e) => { if (e.target.id === 'appModalBd') F1.closeModal(); };
    document.getElementById('relModalClose').onclick = () => document.getElementById('relModal').classList.add('hidden');
    document.getElementById('relModal').onclick = (e) => { if (e.target.id === 'relModal') e.target.classList.add('hidden'); };
    document.getElementById('verBadgeBtn').onclick = F1.openReleaseModal;
    const discBtn = document.getElementById('disclaimerBtn');
    if (discBtn) discBtn.onclick = F1.openDisclaimerModal;

    const syncBtn = document.getElementById('syncNowBtn');
    F1.syncStaticLive = async function (opts) {
      if (!F1.snap || !Array.isArray(F1.snap.races)) return { updated: 0 };
      const now = new Date();
      const twNow = new Date(now.getTime() + 8 * 3600 * 1000);
      const pad = (n) => String(n).padStart(2, '0');
      const nowTwStr = `${twNow.getUTCFullYear()}-${pad(twNow.getUTCMonth() + 1)}-${pad(twNow.getUTCDate())} ${pad(twNow.getUTCHours())}:${pad(twNow.getUTCMinutes())}`;
      let touched = 0;

      // Mark elapsed practice/qualifying sessions done in real time
      for (const rc of F1.snap.races) {
        for (const s of rc.sessions || []) {
          if (s.tw && s.tw <= nowTwStr && !s.done) {
            s.done = true;
            touched++;
          }
        }
      }

      // Query Jolpica Ergast public CORS API for the latest completed Grand Prix results
      const r = await fetch('https://api.jolpi.ca/ergast/f1/2026/last/results.json', { cache: 'no-store' }).catch(() => null);
      if (r && r.ok) {
        const data = await r.json().catch(() => null);
        const raceObj = (((data || {}).MRData || {}).RaceTable || {}).Races?.[0];
        if (raceObj && Array.isArray(raceObj.Results) && raceObj.Results.length) {
          const rnd = parseInt(raceObj.round, 10);
          const rc = F1.snap.races.find((x) => Number(x.round) === rnd);
          if (rc && rc.status !== 'FINAL') {
            const posByCode = {};
            let classified = 0;
            raceObj.Results.forEach((it) => {
              const code = String((it.Driver && it.Driver.code) || '').toUpperCase();
              const pos = parseInt(it.position, 10);
              const stTxt = String(it.status || '');
              const isFin = stTxt === 'Finished' || /^\+\d+\s*Lap/i.test(stTxt);
              if (isFin) classified++;
              if (code && !Number.isNaN(pos)) posByCode[code] = pos;
            });
            const winCode = String((raceObj.Results[0]?.Driver?.code) || '').toUpperCase();
            rc.status = 'FINAL';
            rc.winner_driver = winCode;
            rc.winner_zh = (F1.driverOf(winCode) || {}).zh || winCode;
            rc.classified_count = classified;
            rc.dnf_count = Math.max(0, raceObj.Results.length - classified);
            if (rc.finishers_line != null) {
              rc.ou_result = classified > rc.finishers_line ? 'OVER' : classified < rc.finishers_line ? 'UNDER' : 'PUSH';
            }
            for (const m of rc.h2h || []) {
              if (posByCode[m.driver_a] != null) m.pos_a = posByCode[m.driver_a];
              if (posByCode[m.driver_b] != null) m.pos_b = posByCode[m.driver_b];
            }
            touched++;
          }
        }
      }

      const stamp = `${nowTwStr} (即時連線同步)`;
      if (F1.snap.meta) {
        F1.snap.meta.updated_at = stamp;
        F1.snap.meta.completed_rounds = F1.snap.races.filter((x) => x.status === 'FINAL').length;
      }
      // Background polls only re-render when something actually changed (keeps scroll position and inputs).
      if (touched > 0 || (opts && opts.forceRender)) await F1.refreshAllData();
      return { updated: touched, stamp };
    };

    if (F1.isStatic) {
      syncBtn.style.display = '';
      syncBtn.textContent = '↻ 即時同步賽況';
      syncBtn.onclick = async () => {
        syncBtn.disabled = true;
        syncBtn.textContent = '⏳ 連線同步遙測中…';
        try {
          await F1.syncStaticLive({ forceRender: true });
          F1.toast(`✅ 已即時同步最新 2026 F1 分站賽況與注單對獎！`);
        } catch (e) {
          F1.toast('⚠️ 即時同步失敗：' + e.message);
        } finally {
          syncBtn.disabled = false;
          syncBtn.textContent = '↻ 即時同步賽況';
        }
      };
    } else {
      syncBtn.onclick = async () => {
        syncBtn.disabled = true;
        syncBtn.textContent = '⏳ 同步遙測中…';
        try {
          await F1.apiPost('/api/sync', { full: false });
          for (let i = 0; i < 45; i++) {
            await new Promise((r) => setTimeout(r, 1200));
            const st = await F1.apiGet('/api/sync_status');
            if (!st.running) break;
          }
          await F1.refreshAllData();
          F1.toast('✅ 已同步最新 2026 F1 排位、正賽遙測與模型對獎！');
        } catch (e) {
          F1.toast('⚠️ ' + e.message);
        } finally {
          syncBtn.disabled = false;
          syncBtn.textContent = '↻ 同步遙測與對獎';
        }
      };
    }

    window.addEventListener('hashchange', () => requestAnimationFrame(F1.render));

    document.addEventListener('click', (ev) => {
      const discTrigger = ev.target.closest('[data-open-disclaimer]');
      if (discTrigger) { ev.preventDefault(); F1.openDisclaimerModal(); return; }
      const boxBtn = ev.target.closest('[data-boxscore-gid]');
      if (boxBtn) { ev.preventDefault(); ev.stopPropagation(); F1.openGameBoxscoreModal(boxBtn.getAttribute('data-boxscore-gid')); return; }
      const plEl = ev.target.closest('[data-player-id]');
      if (plEl) { ev.preventDefault(); ev.stopPropagation(); F1.openPlayerModal(plEl.getAttribute('data-player-id')); return; }
      const tmEl = ev.target.closest('[data-team-link]');
      if (tmEl) {
        ev.preventDefault(); ev.stopPropagation();
        const ab = (tmEl.getAttribute('data-team-link') || '').toUpperCase();
        if (ab) {
          F1.closeModal();
          F1.state.activeTeam = ab;
          F1.state.teamGameId = '';
          if (window.location.hash === `#/team/${ab}`) F1.render();
          else window.location.hash = `#/team/${ab}`;
        }
      }
    });

    try {
      if (!F1.isStatic) {
        const [h, relSt] = await Promise.all([
          F1.apiGet('/api/health').catch(() => ({ version: '1.0.0', ai: false })),
          F1.apiGet('/api/release_status').catch(() => ({ current_version: '1.0.0', has_changes: false })),
        ]);
        F1.health = h;
        F1.relHasChanges = Boolean(relSt.has_changes);
        F1.health.version = relSt.current_version || h.version || '1.0.0';
      } else if (window.F1_RELEASES) {
        F1.health.version = window.F1_RELEASES.current_version || '1.0.0';
      }
      await F1.refreshAllData();
      if (F1.isStatic) {
        // Live polling only runs while the tab is visible; catch up at once when it comes back.
        let lastLiveSync = Date.now();
        const liveSync = () => { lastLiveSync = Date.now(); F1.syncStaticLive().catch(() => {}); };
        liveSync();
        setInterval(() => { if (!document.hidden) liveSync(); }, 120000);
        document.addEventListener('visibilitychange', () => {
          if (!document.hidden && Date.now() - lastLiveSync > 120000) liveSync();
        });
      }
      if (window.location.search.includes('releases=1')) F1.openReleaseModal();
    } catch (e) {
      document.getElementById('appMain').innerHTML = `<div class="empty-box">⚠️ 資料載入失敗：${F1.esc(e.message)}</div>`;
    }
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
