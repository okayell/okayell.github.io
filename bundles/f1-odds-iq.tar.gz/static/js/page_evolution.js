/* F1 運彩智庫 — Page 6: 逐站 Walk-Forward 檢討與進化中心 (#/evolution) */
(function () {
  'use strict';
  const F1 = window.F1;

  function renderCurveSvg(curve) {
    if (!curve || curve.length < 2) return '<div class="empty-box">累積完賽站數不足以繪製進化曲線</div>';
    const W = 820, H = 220, padL = 44, padR = 20, padT = 18, padB = 30;
    const minY = 35, maxY = 85;
    const xOf = (i) => padL + (i / (curve.length - 1)) * (W - padL - padR);
    const yOf = (v) => padT + (1 - (Math.max(minY, Math.min(maxY, v)) - minY) / (maxY - minY)) * (H - padT - padB);
    const linePts = (key) => curve.map((c, i) => `${xOf(i).toFixed(1)},${yOf(c[key] || 50).toFixed(1)}`).join(' ');
    const yBreak = yOf(52.38);

    return `
      <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;display:block">
        <line x1="${padL}" y1="${yBreak}" x2="${W - padR}" y2="${yBreak}" stroke="#f59e0b" stroke-dasharray="5,4" stroke-width="1.5"/>
        <text x="${W - padR - 4}" y="${yBreak - 5}" text-anchor="end" font-size="11" fill="#b45309" font-weight="700">-110 損益兩平線 52.38%</text>
        ${[40, 50, 60, 70, 80].map((v) => `
          <line x1="${padL}" y1="${yOf(v)}" x2="${W - padR}" y2="${yOf(v)}" stroke="#f1f5f9" stroke-width="1"/>
          <text x="${padL - 6}" y="${yOf(v) + 4}" text-anchor="end" font-size="10.5" fill="#64748b">${v}%</text>
        `).join('')}
        <polyline fill="none" stroke="#2563eb" stroke-width="2" points="${linePts('all_wr')}"/>
        <polyline fill="none" stroke="#dc2626" stroke-width="2.8" points="${linePts('strong_wr')}"/>
        ${curve.map((c, i) => `
          <circle cx="${xOf(i)}" cy="${yOf(c.strong_wr)}" r="3.5" fill="#dc2626">
            <title>R${c.round} ${c.gp_zh}：強推累積 ${c.strong_wr}% / 全推薦 ${c.all_wr}%</title>
          </circle>
          ${i % 2 === 0 || i === curve.length - 1 ? `<text x="${xOf(i)}" y="${H - 8}" text-anchor="middle" font-size="10" fill="#64748b">R${c.round}</text>` : ''}
        `).join('')}
      </svg>`;
  }

  F1.pages.evolution = function (el) {
    const snap = F1.snap || {};
    const kpi = snap.kpi || {};
    const evo = snap.evolution || {};
    const coach = snap.ai_coach;

    el.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h2 class="sec-title">🧠 賽後自動檢討與權重進化中心 (${F1.esc(snap.meta.model_version)})</h2>
          <div class="sec-sub">嚴格依 2026 分站時間序 Walk-Forward（R1 → R${snap.meta.completed_rounds} 零偷看回測），每站完賽自動歸因敗因並微調 6 大賽車因子權重</div>
        </div>
        ${!F1.isStatic ? `<button type="button" class="btn btn-primary" id="runCoachBtn">🤖 呼叫 AI 賽後深度檢討教練</button>` : ''}
      </div>

      <div class="kpi-grid">
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>🔥 強推精選勝率 (STRONG)</span></div>
          <div class="kpi-val" style="color:#dc2626">${kpi.strong_win_rate}%</div>
          <div class="kpi-sub">${kpi.strong_w}勝 - ${kpi.strong_l}敗 ｜ 投資報酬率 ROI ${kpi.roi_pct >= 0 ? '+' : ''}${kpi.roi_pct}%</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>✅ 全推薦出手勝率 (STRONG+LEAN)</span></div>
          <div class="kpi-val" style="color:#1d4ed8">${kpi.all_win_rate}%</div>
          <div class="kpi-sub">${kpi.all_w}勝 - ${kpi.all_l}敗（優於 52.38% 兩平線）</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>🚨 完賽車數大小盤命中率</span></div>
          <div class="kpi-val" style="color:#15803d">${kpi.ou_win_rate}%</div>
          <div class="kpi-sub">${kpi.ou_w}勝 - ${kpi.ou_l}敗（依安全車機率動態修正）</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>📏 損益兩平門檻 (-110 / 1.91)</span></div>
          <div class="kpi-val">${kpi.breakeven_pct}%</div>
          <div class="kpi-sub">強推超額勝率 +${(kpi.strong_win_rate - kpi.breakeven_pct).toFixed(1)}%</div>
        </div>
      </div>

      ${coach ? `
        <div class="card" style="margin-bottom:14px;background:linear-gradient(135deg,#fef2f2 0%,#ffffff 100%);border-color:#fca5a5">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <strong style="font-size:15.5px;color:#991b1b">🤖 AI 進化教練最新診斷：${F1.esc(coach.headline || '')}</strong>
            <span style="font-size:11.5px;color:#64748b">${F1.esc(coach.generated_at || '')}</span>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px;font-size:13px">
            <div><strong>🔍 敗因檢討重點</strong><ul style="margin:5px 0 0;padding-left:18px">${(coach.reflection_points || []).map((x) => `<li>${F1.esc(x)}</li>`).join('')}</ul></div>
            <div><strong>⚙️ 權重與紀律升級</strong><ul style="margin:5px 0 0;padding-left:18px">${(coach.strategy_upgrades || []).map((x) => `<li>${F1.esc(x)}</li>`).join('')}</ul></div>
            <div><strong>🎯 下一站切入點</strong><ul style="margin:5px 0 0;padding-left:18px">${(coach.tomorrow_best_angles || []).map((x) => `<li>${F1.esc(x)}</li>`).join('')}</ul></div>
          </div>
        </div>` : ''}

      <div class="card" style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:8px">
          <strong>📈 2026 逐站 Walk-Forward 累積勝率演進曲線</strong>
          <div style="display:flex;gap:14px;font-size:12px">
            <span style="color:#dc2626;font-weight:800">● 🔥 強推精選勝率</span>
            <span style="color:#2563eb;font-weight:800">● ✅ 全推薦勝率</span>
            <span style="color:#b45309;font-weight:800">-- 52.38% 兩平線</span>
          </div>
        </div>
        ${renderCurveSvg(evo.curve || [])}
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:14px;margin-bottom:14px">
        <div class="card">
          <h3 style="margin:0 0 10px;font-size:15px">🧬 6 大賽車量化因子演化權重與方向命中率</h3>
          <div class="tbl-wrap">
            <table class="data-tbl">
              <thead>
                <tr><th>量化因子</th><th class="num">目前權重</th><th class="num">單因子命中率</th><th class="num">有效樣本</th></tr>
              </thead>
              <tbody>
                ${(evo.factors || []).map((f) => `
                  <tr>
                    <td><strong>${F1.esc(f.zh)}</strong><div style="font-size:11.5px;color:#64748b">${F1.esc(f.desc)}</div></td>
                    <td class="num"><span class="chip strong">${f.weight.toFixed(2)}x</span></td>
                    <td class="num"><strong>${f.hit_rate}%</strong></td>
                    <td class="num">${f.samples}</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <h3 style="margin:0 0 10px;font-size:15px">🛡️ 失誤歸因統計與自動防呆護欄 (Guardrails)</h3>
          <div style="display:flex;flex-direction:column;gap:8px">
            ${(evo.error_breakdown || []).map((e) => `
              <div style="border:1px solid #e2e8f0;border-radius:9px;padding:9px 12px;background:#f8fafc">
                <div style="display:flex;justify-content:space-between;align-items:center">
                  <strong>${F1.esc(e.zh)}</strong>
                  <span class="chip ${e.count > 0 ? 'warn' : 'muted'}">累計 ${e.count} 次</span>
                </div>
                <div style="font-size:12px;color:#475569;margin-top:4px">🛡️ 護欄機制：${F1.esc(e.guardrail)}</div>
              </div>`).join('')}
          </div>
        </div>
      </div>

      <div class="card">
        <h3 style="margin:0 0 10px;font-size:15px">📜 逐站賽後對獎與權重更新日誌</h3>
        <div class="tbl-wrap">
          <table class="data-tbl">
            <thead>
              <tr><th>站別</th><th>大獎賽</th><th>全推薦戰績</th><th>強推戰績</th><th>累積強推勝率</th><th>完賽大小盤</th><th>演化摘要</th></tr>
            </thead>
            <tbody>
              ${(evo.round_log || []).map((r) => `
                <tr>
                  <td><strong>R${r.round}</strong></td>
                  <td>${F1.esc(r.gp_zh)} (${F1.esc(r.tw_date)})</td>
                  <td>${F1.esc(r.all_record)}</td>
                  <td><strong>${F1.esc(r.strong_record)}</strong></td>
                  <td><strong style="color:#dc2626">${r.cum_strong_wr}%</strong></td>
                  <td>${r.ou_result === 'WIN' ? '<span class="chip ok">命中</span>' : r.ou_result === 'LOSS' ? '<span class="chip bad">失利</span>' : '<span class="chip muted">觀望</span>'}</td>
                  <td style="font-size:12px;color:#475569">${F1.esc(r.note)}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    const cBtn = document.getElementById('runCoachBtn');
    if (cBtn) {
      cBtn.onclick = async () => {
        cBtn.disabled = true;
        cBtn.textContent = '⏳ AI 教練分析中…';
        try {
          const st = await F1.apiPost('/api/ai/start', { kind: 'coach_postmortem' });
          for (let i = 0; i < 55; i++) {
            await new Promise((r) => setTimeout(r, 1200));
            const tk = await F1.apiGet(`/api/ai/task?id=${encodeURIComponent(st.task)}`);
            if (tk.status === 'done') {
              await F1.refreshAllData();
              F1.toast('✅ AI 賽後檢討報告已更新！');
              return;
            }
            if (tk.status === 'error') throw new Error(tk.error || 'AI 分析失敗');
          }
        } catch (e) {
          F1.toast('⚠️ ' + e.message);
        } finally {
          cBtn.disabled = false;
          cBtn.textContent = '🤖 呼叫 AI 賽後深度檢討教練';
        }
      };
    }
  };
})();
