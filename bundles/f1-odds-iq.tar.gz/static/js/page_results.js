/* F1 運彩智庫 — Page 2: 分站賽果紀錄與過盤榜 (#/results) */
(function () {
  'use strict';
  const F1 = window.F1;

  F1.pages.results = function (el) {
    const snap = F1.snap || {};
    const doneRaces = (snap.races || []).filter((r) => r.status === 'FINAL').slice().reverse();
    const kpi = snap.kpi || {};
    const tab = F1.state.resultsTab || 'ledger';

    el.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h2 class="sec-title">📊 2026 F1 完賽分站賽果與過盤帳本</h2>
          <div class="sec-sub">共完賽 ${doneRaces.length} 站 ｜ 強推精選勝率 ${kpi.strong_win_rate}% (${kpi.strong_w}W-${kpi.strong_l}L) ｜ 完賽車數大小盤命中率 ${kpi.ou_win_rate}%</div>
        </div>
        <div class="sub-tabs" style="margin-bottom:0">
          <button type="button" class="sub-tab ${tab === 'ledger' ? 'active' : ''}" data-rtab="ledger">🏁 各站頒獎台與過盤紀錄</button>
          <button type="button" class="sub-tab ${tab === 'board' ? 'active' : ''}" data-rtab="board">🏆 車手 & 車隊 H2H 過盤榜</button>
        </div>
      </div>

      ${tab === 'ledger' ? `
        <div class="tbl-wrap">
          <table class="data-tbl">
            <thead>
              <tr>
                <th>站別 / 日期</th>
                <th>大獎賽與賽道</th>
                <th>⚡ 桿位 Pole</th>
                <th>🏆 頒獎台 Top 3</th>
                <th class="num">完賽車數 / 大小盤</th>
                <th class="num">模型 H2H 對獎</th>
                <th class="num">強推戰績</th>
                <th>遙測明細</th>
              </tr>
            </thead>
            <tbody>
              ${doneRaces.map((rc) => {
                const pod = (rc.podium || []).map((p, idx) => `${['🥇','🥈','🥉'][idx]} <span class="pl-link" data-player-id="${F1.esc(p.code)}" style="font-weight:700">${F1.esc(p.zh)}</span>`).join(' · ');
                return `
                  <tr>
                    <td><strong>R${rc.round}</strong><div style="font-size:11.5px;color:#64748b">${F1.esc(rc.tw_date)}</div></td>
                    <td>
                      <strong>${F1.esc(rc.gp_zh)}</strong>
                      <div style="font-size:11.5px;color:#64748b">${F1.esc(rc.circuit_zh)}</div>
                    </td>
                    <td><span class="pl-link" data-player-id="${F1.esc(rc.pole_driver)}" style="font-weight:700;color:#1d4ed8">${F1.esc(rc.pole_zh || rc.pole_driver)}</span></td>
                    <td>${pod}</td>
                    <td class="num">
                      <strong>${rc.classified_count} 台</strong> / 盤 ${rc.finishers_line}
                      <div><span class="chip ${rc.ou_result === 'OVER' ? 'strong' : 'info'}">${rc.ou_result === 'OVER' ? '大分 OVER' : '小分 UNDER'}</span></div>
                    </td>
                    <td class="num"><strong>${rc.h2h_w}勝 - ${rc.h2h_l}敗</strong></td>
                    <td class="num"><span class="chip ${rc.strong_w >= rc.strong_l ? 'ok' : 'bad'}">${rc.strong_w}W - ${rc.strong_l}L</span></td>
                    <td>
                      <button type="button" class="btn btn-sm" data-boxscore-gid="${F1.esc(rc.game_id)}">📊 22車遙測</button>
                      <button type="button" class="btn btn-ghost btn-sm" data-jump-rnd="${rc.round}">檢視解盤</button>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      ` : `
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:14px">
          <div class="card">
            <h3 style="margin:0 0 10px;font-size:15px">👨‍🚀 車手配對盤 (H2H) 勝率排行榜</h3>
            <div class="tbl-wrap">
              <table class="data-tbl">
                <thead>
                  <tr><th>#</th><th>車手</th><th>車隊</th><th class="num">配對戰績</th><th class="num">H2H 勝率</th><th class="num">完賽率</th></tr>
                </thead>
                <tbody>
                  ${(snap.driver_stats || []).slice().sort((a, b) => b.h2h_pct - a.h2h_pct || b.h2h_w - a.h2h_w).map((d, i) => `
                    <tr>
                      <td>${i + 1}</td>
                      <td><span class="pl-link" data-player-id="${F1.esc(d.code)}" style="font-weight:800;color:#1d4ed8">${F1.esc(d.zh)} (${F1.esc(d.code)})</span></td>
                      <td><span class="tm-link" data-team-link="${F1.esc(d.team)}" style="font-weight:700">${F1.esc(F1.teamOf(d.team).zh)}</span></td>
                      <td class="num">${d.h2h_w}勝 - ${d.h2h_l}敗</td>
                      <td class="num"><strong style="color:${d.h2h_pct >= 55 ? '#15803d' : d.h2h_pct < 45 ? '#b91c1c' : '#334155'}">${d.h2h_pct}%</strong></td>
                      <td class="num">${d.clean_pct}%</td>
                    </tr>`).join('')}
                </tbody>
              </table>
            </div>
          </div>

          <div class="card">
            <h3 style="margin:0 0 10px;font-size:15px">🏎️ 11 支車隊積分與跨隊配對榜</h3>
            <div class="tbl-wrap">
              <table class="data-tbl">
                <thead>
                  <tr><th>#</th><th>車隊</th><th class="num">年度積分</th><th class="num">勝 / 頒獎台</th><th class="num">退賽數</th><th class="num">雙積分連站</th></tr>
                </thead>
                <tbody>
                  ${(snap.teams || []).map((t) => `
                    <tr>
                      <td>${t.rank}</td>
                      <td><span class="tm-link" data-team-link="${F1.esc(t.abbr)}" style="font-weight:800;color:${F1.esc(t.color)}">${F1.esc(t.zh)} (${F1.esc(t.abbr)})</span></td>
                      <td class="num"><strong>${t.pts}</strong></td>
                      <td class="num">${t.wins} / ${t.podiums}</td>
                      <td class="num">${t.dnfs}</td>
                      <td class="num">${t.dbl_streak >= 2 ? `<span class="chip ok">連 ${t.dbl_streak} 站</span>` : `${t.dbl_streak} 站`}</td>
                    </tr>`).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      `}
    `;

    el.querySelectorAll('[data-rtab]').forEach((b) => {
      b.onclick = () => { F1.state.resultsTab = b.getAttribute('data-rtab'); F1.render(); };
    });
    el.querySelectorAll('[data-jump-rnd]').forEach((b) => {
      b.onclick = () => {
        F1.state.picksRound = Number(b.getAttribute('data-jump-rnd'));
        window.location.hash = '#/picks';
      };
    });
  };
})();
