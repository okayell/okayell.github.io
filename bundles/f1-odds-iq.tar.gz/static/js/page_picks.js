/* F1 運彩智庫 — Page 1: 本站解盤 (#/picks) */
(function () {
  'use strict';
  const F1 = window.F1;

  function tierChip(tier) {
    if (tier === 'STRONG') return '<span class="chip strong">🔥 強推精選 STRONG</span>';
    if (tier === 'LEAN') return '<span class="chip info">✅ 順勢價值 LEAN</span>';
    return '<span class="chip muted">⚖️ 觀望不碰 PASS</span>';
  }

  function resChip(res) {
    if (res === 'WIN') return '<span class="chip ok">✅ 命中過盤</span>';
    if (res === 'LOSS') return '<span class="chip bad">❌ 未過盤</span>';
    if (res === 'PASS') return '<span class="chip muted">觀望免戰</span>';
    return '<span class="chip warn">⏳ 待正賽對獎</span>';
  }

  F1.pages.picks = function (el) {
    const snap = F1.snap || {};
    const races = snap.races || [];
    const kpi = snap.kpi || {};
    const curRnd = Number(F1.state.picksRound || (snap.meta && snap.meta.default_round) || 19);
    const rc = races.find((r) => r.round === curRnd) || races[races.length - 1];
    if (!rc) {
      el.innerHTML = '<div class="empty-box">尚無賽程資料</div>';
      return;
    }

    const cp = rc.circuit_profile || {};
    const oup = rc.ou_pred || {};
    const h2hAll = rc.h2h || [];
    const q = (F1.state.picksSearch || '').trim().toLowerCase();
    const flt = F1.state.picksFilter || 'ALL';

    const filtered = h2hAll.filter((m) => {
      if (flt === 'STRONG' && m.tier !== 'STRONG') return false;
      if (flt === 'ACTION' && m.tier === 'PASS') return false;
      if (flt === 'TEAMMATE' && m.pair_type !== 'TEAMMATE') return false;
      if (flt === 'RIVAL' && m.pair_type !== 'RIVAL') return false;
      if (q) {
        const blob = `${m.driver_a} ${m.driver_a_zh} ${m.driver_b} ${m.driver_b_zh} ${m.team_a} ${m.team_b} ${m.label_zh}`.toLowerCase();
        if (!blob.includes(q)) return false;
      }
      return true;
    });

    const strongCnt = h2hAll.filter((m) => m.tier === 'STRONG').length;
    const actionCnt = h2hAll.filter((m) => m.tier !== 'PASS').length;
    const tmCnt = h2hAll.filter((m) => m.pair_type === 'TEAMMATE').length;

    el.innerHTML = `
      <div class="odds-rule-bar">
        <div>
          <strong>🔄 每日雙階段抓盤與變盤重析規範：</strong>車手配對盤（Driver H2H）與完賽車數大小盤於<strong>每天晚上 6 點（18:00 初盤）</strong>先抓一次並完成首輪解盤，<strong>晚上 11 點（23:00 尾盤定盤）</strong>再抓最後一次參考盤口、結合盤勢變化重新推演並鎖定對獎；排位與正賽時段持續更新遙測圈速與 FIA 罰退情報。
        </div>
        <span class="odds-rule-pill">🕕 18:00 初盤首析 · 🕚 23:00 變盤定盤</span>
      </div>

      <div class="inline-disc-bar">
        <span>⚖️ <strong>風險提示：</strong>本站所有車手配對合理賠率、期望值（EV）與完賽車數大小推估均為公開遙測程式統計，不構成投注建議；賽車退賽與安全車變數高，損益請自行承擔。</span>
        <button type="button" class="inline-disc-link" data-open-disclaimer="1">完整免責聲明 →</button>
      </div>

      <!-- Clickable KPI Filter Cards -->
      <div class="kpi-grid">
        <button type="button" class="kpi-card ${flt === 'ALL' ? 'active' : ''}" data-flt="ALL">
          <div class="kpi-lbl"><span>本站車手配對盤</span><span>全部顯示</span></div>
          <div class="kpi-val">${h2hAll.length} 組</div>
          <div class="kpi-sub">R${rc.round} ${F1.esc(rc.gp_zh)} 焦點對決</div>
        </button>
        <button type="button" class="kpi-card ${flt === 'STRONG' ? 'active' : ''}" data-flt="STRONG">
          <div class="kpi-lbl"><span>🔥 強推精選 (STRONG)</span><span>高期望值</span></div>
          <div class="kpi-val" style="color:#c2410c">${strongCnt} 組</div>
          <div class="kpi-sub">本季強推累積 ${kpi.strong_w}勝-${kpi.strong_l}敗 (${kpi.strong_win_rate}%)</div>
        </button>
        <button type="button" class="kpi-card ${flt === 'ACTION' ? 'active' : ''}" data-flt="ACTION">
          <div class="kpi-lbl"><span>✅ 推薦出手 (STRONG+LEAN)</span><span>正EV標的</span></div>
          <div class="kpi-val" style="color:#dc2626">${actionCnt} 組</div>
          <div class="kpi-sub">全推薦勝率 ${kpi.all_win_rate}% (優於 52.38% 兩平線)</div>
        </button>
        <button type="button" class="kpi-card ${flt === 'TEAMMATE' ? 'active' : ''}" data-flt="TEAMMATE">
          <div class="kpi-lbl"><span>🏎️ 同車隊內戰對決</span><span>排除賽車差距</span></div>
          <div class="kpi-val">${tmCnt} 組</div>
          <div class="kpi-sub">純拼車手排位單圈與保胎實力</div>
        </button>
      </div>

      <!-- 2026 Season Round Ribbon -->
      <div class="date-bar">
        <span style="font-size:12px;font-weight:800;color:#475569;margin-right:4px">2026 分站切換：</span>
        ${races.slice(Math.max(0, curRnd - 5), Math.min(races.length, curRnd + 4)).map((r) => `
          <button type="button" class="date-pill ${r.round === curRnd ? 'active' : ''}" data-rnd="${r.round}">
            <span>R${r.round} ${F1.esc(r.gp_zh.replace('大獎賽', ''))}</span>
            <span class="cnt">${r.status === 'FINAL' ? '完賽' : r.round === snap.meta.default_round ? '下一站' : r.tw_date.slice(5)}</span>
          </button>
        `).join('')}
        <select class="inp" id="picksRndSelect" style="margin-left:auto;padding:5px 9px;font-size:12.5px">
          ${races.map((r) => `<option value="${r.round}" ${r.round === curRnd ? 'selected' : ''}>R${r.round} · ${F1.esc(r.gp_zh)} (${r.status === 'FINAL' ? '已完賽' : r.tw_date})</option>`).join('')}
        </select>
        <input class="inp" id="picksSearchInp" value="${F1.esc(F1.state.picksSearch)}" placeholder="搜尋車手或車隊…" style="width:165px">
      </div>

      <!-- Grand Prix Circuit DNA & Weekend Timetable Hero Card -->
      <div class="card" style="margin-bottom:14px;background:linear-gradient(135deg,#ffffff 0%,#fef2f2 100%)">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap">
          <div>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <span class="chip strong">2026 Round ${rc.round} / ${races.length}</span>
              ${rc.has_sprint ? '<span class="chip warn">⚡ 衝刺賽週末 Sprint</span>' : ''}
              <span class="chip ${rc.status === 'FINAL' ? 'ok' : 'info'}">${rc.status === 'FINAL' ? '🏁 已完賽對獎' : '🟢 即將開跑'}</span>
            </div>
            <h2 style="margin:6px 0 3px;font-size:21px;font-weight:900">🏁 ${F1.esc(rc.gp_zh)} · ${F1.esc(rc.circuit_zh)}</h2>
            <div style="font-size:13px;color:#475569">${F1.esc(cp.type_zh || '')} ｜ 超車難度：<strong>${cp.overtake || 3} / 5</strong> ｜ 歷史安全車機率：<strong>${Math.round((cp.sc_rate || 0.5) * 100)}%</strong></div>
            <div style="font-size:12.5px;color:#64748b;margin-top:4px">💡 賽道解盤關鍵：${F1.esc(cp.note || '')}</div>
          </div>

          <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            ${rc.status === 'FINAL' ? `<button type="button" class="btn btn-primary btn-sm" data-boxscore-gid="${F1.esc(rc.game_id)}">📊 查看 22 車完整遙測成績</button>` : ''}
            ${!F1.isStatic ? `<button type="button" class="btn btn-soft btn-sm" data-ai-gp="${F1.esc(rc.game_id)}">🤖 AI 全站策略總評</button>` : ''}
          </div>
        </div>

        ${(rc.sessions && rc.sessions.length) ? `
          <div class="sess-strip">
            ${rc.sessions.map((s) => `
              <div class="sess-pill ${s.code === 'Race' ? 'is-race' : ''}">
                <span>${s.done ? '✅' : '🕒'} <strong>${F1.esc(s.zh)}</strong></span>
                <span style="color:#475569">台灣 ${F1.esc(s.tw)}</span>
              </div>
            `).join('')}
          </div>` : `<div style="margin-top:8px;font-size:12.5px;color:#475569">🕒 正賽台灣時間：<strong>${F1.esc(rc.race_tw)}</strong>${rc.qual_tw ? ` ｜ 排位賽：${F1.esc(rc.qual_tw)}` : ''}</div>`}

        <!-- Classified Finishers Over/Under & Outright Top-4 Value Strip -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:12px;margin-top:12px">
          <div class="pick-cell tier-${oup.tier || 'PASS'}" style="background:#ffffff">
            <div class="pick-hdr">
              <span>🚨 完賽車數大小盤 (Attrition O/U)</span>
              ${tierChip(oup.tier)}
            </div>
            <div class="pick-target">
              盤口 ${rc.finishers_line} 台 → 推薦：${oup.tier === 'PASS' ? `觀望（傾向${oup.lean_side === 'OVER' ? '大' : '小'}）` : (oup.pick === 'OVER' ? `大於 ${rc.finishers_line} 台 (少退賽)` : `小於 ${rc.finishers_line} 台 (多事故/SC)`)}
            </div>
            <div class="pick-edge" style="display:flex;justify-content:space-between;align-items:center;margin-top:5px">
              <span>模型預估完賽：<strong>${oup.pred_finishers || '—'} 台</strong>${rc.classified_count != null ? ` ｜ 實際完賽：<strong>${rc.classified_count} 台</strong>` : ''}</span>
              <button type="button" class="btn btn-sm" data-bet-ou="${F1.esc(rc.game_id)}">➕ 記單</button>
            </div>
          </div>

          <div class="card" style="padding:10px 12px;background:#ffffff">
            <div style="font-size:12px;font-weight:800;color:#475569;margin-bottom:6px">🏆 分站奪冠 & 頒獎台合理賠率價值雷達（Top 4 熱門車手）</div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px">
              ${(rc.outright_radar || []).slice(0, 4).map((r) => {
                const tm = F1.teamOf(r.team);
                return `
                  <div style="border:1px solid #e2e8f0;border-radius:8px;padding:7px 9px;background:#f8fafc">
                    <div style="display:flex;justify-content:space-between;align-items:center">
                      <span class="pl-link" data-player-id="${F1.esc(r.driver)}" style="font-weight:800;font-size:13px">${F1.esc(r.driver_zh)}</span>
                      <span style="font-size:11px;font-weight:700;color:${F1.esc(tm.color)}">${F1.esc(r.team)}</span>
                    </div>
                    <div style="font-size:11.5px;color:#334155;margin-top:3px">奪冠率 <strong>${r.model_win_pct}%</strong> · 頒獎台 <strong>${r.podium_pct}%</strong></div>
                    <div style="font-size:11px;color:#64748b">國際盤 ${r.book_win_odds} / 合理 ${r.fair_win_odds}</div>
                  </div>`;
              }).join('')}
            </div>
          </div>
        </div>
      </div>

      <!-- Driver Head-to-Head Matchup Cards -->
      <div class="games-grid">
        ${filtered.map((m) => {
          const ta = F1.teamOf(m.team_a);
          const tb = F1.teamOf(m.team_b);
          const da = F1.driverOf(m.driver_a);
          const db = F1.driverOf(m.driver_b);
          const facs = Object.values(m.factors || {});
          return `
            <div class="game-card ${m.tier === 'STRONG' ? 'has-strong' : ''}">
              <div class="gc-top">
                <span><strong>${m.pair_type === 'TEAMMATE' ? '🏎️ 同隊內戰' : '⚔️ 跨隊強強對決'}</strong> · ${F1.esc(m.label_zh)}</span>
                <div style="display:flex;gap:6px;align-items:center">
                  ${rc.status === 'FINAL' ? resChip(m.result) : tierChip(m.tier)}
                </div>
              </div>

              <div class="gc-teams">
                <div class="tm-side pl-link" data-player-id="${F1.esc(m.driver_a)}">
                  <img loading="lazy" decoding="async" class="tm-logo" src="${F1.esc(da.headshot || ta.logo)}" alt="">
                  <div style="min-width:0">
                    <div class="tm-name">${F1.esc(m.driver_a_zh)} (${F1.esc(m.driver_a)})</div>
                    <div class="tm-meta">
                      <span class="tm-link" data-team-link="${F1.esc(m.team_a)}" style="color:${F1.esc(ta.color)};font-weight:700">${F1.esc(ta.zh)}</span>
                      ${da.rank ? `<span>P${da.rank} · ${da.pts}分</span>` : ''}
                    </div>
                  </div>
                </div>

                <div class="vs-center">
                  ${m.pos_a != null && m.pos_b != null
                    ? `<div class="score-big">P${m.pos_a} : P${m.pos_b}</div>`
                    : `<div class="vs-tag">H2H 對決</div>`}
                </div>

                <div class="tm-side home pl-link" data-player-id="${F1.esc(m.driver_b)}">
                  <img loading="lazy" decoding="async" class="tm-logo" src="${F1.esc(db.headshot || tb.logo)}" alt="">
                  <div style="min-width:0">
                    <div class="tm-name">${F1.esc(m.driver_b_zh)} (${F1.esc(m.driver_b)})</div>
                    <div class="tm-meta">
                      <span class="tm-link" data-team-link="${F1.esc(m.team_b)}" style="color:${F1.esc(tb.color)};font-weight:700">${F1.esc(tb.zh)}</span>
                      ${db.rank ? `<span>P${db.rank} · ${db.pts}分</span>` : ''}
                    </div>
                  </div>
                </div>
              </div>

              <div class="odds-strip">
                <div class="odds-col">
                  <div class="odds-lbl">${F1.esc(m.driver_a_zh)} 盤口賠率</div>
                  <div class="odds-main">${m.close_odds_a.toFixed(2)} <span style="font-size:11.5px;color:#64748b">(開盤 ${m.open_odds_a.toFixed(2)})</span></div>
                  <div class="odds-sub">合理賠率 ${m.fair_odds_a.toFixed(2)} · 勝率 ${m.model_prob_a}%</div>
                </div>
                <div class="odds-col">
                  <div class="odds-lbl">${F1.esc(m.driver_b_zh)} 盤口賠率</div>
                  <div class="odds-main">${m.close_odds_b.toFixed(2)} <span style="font-size:11.5px;color:#64748b">(開盤 ${m.open_odds_b.toFixed(2)})</span></div>
                  <div class="odds-sub">合理賠率 ${m.fair_odds_b.toFixed(2)} · 勝率 ${(100 - m.model_prob_a).toFixed(1)}%</div>
                </div>
                <div class="odds-col">
                  <div class="odds-lbl">量化推薦方向 & 注碼</div>
                  <div class="odds-main" style="color:${m.tier === 'STRONG' ? '#c2410c' : m.tier === 'LEAN' ? '#1d4ed8' : '#64748b'}">
                    ${m.tier === 'PASS' ? '⚖️ 觀望 PASS' : `👉 ${F1.esc(m.pick_driver_zh)} 勝`}
                  </div>
                  <div class="odds-sub">Edge +${m.edge_pct}% ｜ 建議 ${m.kelly_units}u</div>
                </div>
              </div>

              <div class="rationale-bar">${F1.esc(m.postmortem_zh || m.rationale_zh)}</div>

              <details style="font-size:12px;color:#475569">
                <summary style="cursor:pointer;font-weight:700">展開 6 大賽車量化因子拆解（正值利於 ${F1.esc(m.driver_a_zh)}，負值利於 ${F1.esc(m.driver_b_zh)}）</summary>
                <div class="fac-list">
                  ${facs.map((f) => {
                    const w = Number(f.weighted || 0);
                    const pct = Math.min(100, Math.round(Math.abs(w) * 55));
                    const col = w >= 0 ? '#16a34a' : '#2563eb';
                    return `
                      <div class="fac-row">
                        <span>${F1.esc(f.zh)}</span>
                        <div class="fac-bar-track"><div class="fac-bar-fill" style="width:${pct}%;background:${col}"></div></div>
                        <span class="num" style="font-weight:700;color:${col}">${F1.fmtSigned(w, 2)}</span>
                      </div>`;
                  }).join('')}
                </div>
              </details>

              <div style="display:flex;justify-content:flex-end;gap:8px;border-top:1px solid #f1f5f9;padding-top:8px">
                <button type="button" class="btn btn-sm" data-bet-h2h="${F1.esc(m.matchup_id)}">➕ 加入注單</button>
                ${!F1.isStatic ? `<button type="button" class="btn btn-soft btn-sm" data-ai-h2h="${F1.esc(m.matchup_id)}">🤖 AI 單組深度解盤</button>` : ''}
              </div>
            </div>`;
        }).join('')}
      </div>
    `;

    el.querySelectorAll('[data-flt]').forEach((b) => {
      b.onclick = () => { F1.state.picksFilter = b.getAttribute('data-flt'); F1.render(); };
    });
    el.querySelectorAll('[data-rnd]').forEach((b) => {
      b.onclick = () => { F1.state.picksRound = Number(b.getAttribute('data-rnd')); F1.render(); };
    });
    const rndSel = document.getElementById('picksRndSelect');
    if (rndSel) rndSel.onchange = () => { F1.state.picksRound = Number(rndSel.value); F1.render(); };

    const sInp = document.getElementById('picksSearchInp');
    if (sInp) {
      sInp.onkeydown = (ev) => {
        if (F1.isEnterSend(ev)) { F1.state.picksSearch = sInp.value; F1.render(); }
      };
      sInp.onblur = () => {
        if (F1.state.picksSearch !== sInp.value) { F1.state.picksSearch = sInp.value; F1.render(); }
      };
    }

    el.querySelectorAll('[data-bet-h2h]').forEach((b) => {
      b.onclick = () => F1.openQuickBetModal(b.getAttribute('data-bet-h2h'), 'H2H');
    });
    el.querySelectorAll('[data-bet-ou]').forEach((b) => {
      b.onclick = () => F1.openQuickBetModal(b.getAttribute('data-bet-ou'), 'OU');
    });
    el.querySelectorAll('[data-ai-h2h]').forEach((b) => {
      b.onclick = () => F1.openAiGameDive(b.getAttribute('data-ai-h2h'));
    });
    el.querySelectorAll('[data-ai-gp]').forEach((b) => {
      b.onclick = () => F1.openAiGameDive(b.getAttribute('data-ai-gp'));
    });
  };
})();
