/* F1 運彩智庫 — Page 9: 三欄位極簡意見回饋 (#/feedback) */
(function () {
  'use strict';
  const F1 = window.F1;
  const KIND_OPTS = [
    ['feature', '✨ 功能許願'],
    ['bug', '🐞 問題回報'],
    ['ux', '🎨 介面建議'],
    ['other', '💬 其他回饋'],
  ];
  let _fbKind = 'feature';
  let _fbSending = false;

  function renderFallbackBox(kindLabel, title, description, note) {
    if (window.CampusNav && CampusNav.fallbackHtml) {
      return CampusNav.fallbackHtml({
        email: 'okayell@hotmail.com',
        tool: 'F1 運彩智庫',
        kindLabel,
        title,
        description,
        note,
      });
    }
    const mailto = `mailto:okayell@hotmail.com?subject=${encodeURIComponent(`[F1 運彩智庫 意見回饋] ${kindLabel} — ${title}`)}&body=${encodeURIComponent(description)}`;
    return `<div class="card" style="background:#fffbeb;border-color:#fde68a;font-size:12.5px">${F1.esc(note || '已儲存於本機紀錄，請點此寄出：')} <a href="${mailto}" style="font-weight:800">📧 直接開啟信箱寄送給維護者</a>。</div>`;
  }

  F1.pages.feedback = async function (el) {
    let items = [];
    if (F1.isStatic) {
      try { items = JSON.parse(localStorage.getItem('f1.feedback.v1') || '[]'); } catch (_) { items = []; }
    } else {
      try {
        const res = await F1.apiGet('/api/feedback');
        items = res.items || [];
      } catch (_) {
        try { items = JSON.parse(localStorage.getItem('f1.feedback.v1') || '[]'); } catch (e) { items = []; }
      }
    }

    el.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h2 class="sec-title">💬 意見回饋與功能許願</h2>
          <div class="sec-sub">任何關於 F1 分站數據、配對盤因子或介面體驗的建議，送出後將同步保存並寄達開發者信箱</div>
        </div>
      </div>

      <div class="fb-layout">
        <div class="card">
          <form id="fbForm" style="display:flex;flex-direction:column;gap:14px">
            <div>
              <label style="font-size:12.5px;font-weight:800;color:#334155">1. 回饋類型</label>
              <div class="fb-type-pills" id="fbKindPills">
                ${[
                  ['feature', '✨ 功能許願'],
                  ['bug', '🐞 問題回報'],
                  ['ux', '🎨 介面建議'],
                  ['other', '💬 其他回饋'],
                ].map(([k, lbl]) => `
                  <button type="button" class="fb-type-pill ${_fbKind === k ? 'active' : ''}" data-fbk="${k}">${lbl}</button>
                `).join('')}
              </div>
            </div>

            <div>
              <label style="font-size:12.5px;font-weight:800;color:#334155" for="fbTitleInp">2. 標題</label>
              <input class="inp" id="fbTitleInp" placeholder="請簡短描述您的建議或問題…" style="width:100%;margin-top:5px" required>
            </div>

            <div>
              <label style="font-size:12.5px;font-weight:800;color:#334155" for="fbDescInp">3. 內容描述</label>
              <textarea class="inp" id="fbDescInp" rows="5" placeholder="請填寫具體細節（例如希望新增的賽道指標、盤口玩法或異常畫面）…" style="width:100%;margin-top:5px" required></textarea>
            </div>

            <div id="fbStatusBanner"></div>

            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
              <span style="font-size:12px;color:#64748b">📩 送出後會自動通知站長</span>
              <button type="submit" class="btn btn-primary" id="fbSubmitBtn">📨 送出意見回饋</button>
            </div>
          </form>
        </div>

        <div class="card">
          <h3 style="margin:0 0 10px;font-size:15px">🗂️ 近期已收到的回饋紀錄 (${items.length})</h3>
          ${items.length ? `
            <div style="display:flex;flex-direction:column;gap:8px">
              ${items.slice(0, 12).map((x) => `
                <div style="border:1px solid #e2e8f0;border-radius:8px;padding:9px 12px;background:#f8fafc">
                  <div style="display:flex;justify-content:space-between;align-items:center;font-size:11.5px;color:#64748b">
                    <span>${F1.esc(x.kind_label)}</span>
                    <span>${F1.esc(x.created_at)}</span>
                  </div>
                  <div style="font-weight:800;margin-top:3px">${F1.esc(x.title)}</div>
                  <div style="font-size:12.5px;color:#475569;margin-top:3px;white-space:pre-wrap">${F1.esc(x.description)}</div>
                </div>`).join('')}
            </div>` : '<div class="empty-box" style="padding:24px">尚無歷史回饋紀錄，歡迎留下第一筆建議！</div>'}
        </div>
      </div>
    `;

    el.querySelectorAll('[data-fbk]').forEach((b) => {
      b.onclick = () => {
        _fbKind = b.getAttribute('data-fbk');
        el.querySelectorAll('[data-fbk]').forEach((x) => x.classList.toggle('active', x === b));
      };
    });

    const titleEl = document.getElementById('fbTitleInp');
    if (titleEl) {
      titleEl.addEventListener('keydown', (ev) => {
        const ok = F1.isEnterSend ? F1.isEnterSend(ev) : (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing && ev.keyCode !== 229);
        if (ev.key === 'Enter' && !ok) ev.preventDefault();
      });
    }

    document.getElementById('fbForm').onsubmit = async (ev) => {
      ev.preventDefault();
      if (_fbSending) return;
      const btn = document.getElementById('fbSubmitBtn');
      const title = document.getElementById('fbTitleInp').value.trim();
      const description = document.getElementById('fbDescInp').value.trim();
      if (!title || !description) return;
      const kPair = KIND_OPTS.find((x) => x[0] === _fbKind) || KIND_OPTS[0];
      const kindLabel = kPair[1];
      _fbSending = true;
      btn.disabled = true;
      btn.textContent = '⏳ 寄送中…';
      try {
        if (F1.isStatic) {
          const item = {
            id: 'FB-' + Date.now().toString(36).toUpperCase(),
            kind: _fbKind,
            kind_label: kindLabel,
            title,
            description,
            created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
          };
          let loc = [];
          try { loc = JSON.parse(localStorage.getItem('f1.feedback.v1') || '[]'); } catch (_) { loc = []; }
          loc.unshift(item);
          try { localStorage.setItem('f1.feedback.v1', JSON.stringify(loc.slice(0, 50))); } catch (_) {}
          let sent = false;
          if (window.CampusNav && CampusNav.sendStaticFeedback) {
            const mRes = await CampusNav.sendStaticFeedback({
              email: 'okayell@hotmail.com',
              tool: 'F1 運彩智庫',
              kindLabel,
              title,
              description,
              createdAt: item.created_at,
            });
            sent = !!(mRes && mRes.sent);
          }
          await F1.pages.feedback(el);
          const box = document.getElementById('fbStatusBanner');
          if (sent) {
            F1.toast('✅ 感謝回饋！已成功寄出');
            if (box) box.innerHTML = `<div class="card" style="background:#f0fdf4;border-color:#86efac;color:#166534;padding:10px 13px;font-size:13px">✅ 感謝回饋！意見已成功寄送給站長。</div>`;
          } else if (box) {
            box.innerHTML = renderFallbackBox(kindLabel, title, description);
          }
        } else {
          const res = await F1.apiPost('/api/feedback', { kind: _fbKind, title, description });
          const sentOk = !res || !res.item || res.item.mail_sent !== false;
          await F1.pages.feedback(el);
          const box = document.getElementById('fbStatusBanner');
          if (sentOk) {
            F1.toast('✅ 感謝回饋！已儲存並寄送通知信');
            if (box) box.innerHTML = `<div class="card" style="background:#f0fdf4;border-color:#86efac;color:#166534;padding:10px 13px;font-size:13px">✅ 已成功收到並寄送通知信給站長！</div>`;
          } else if (box) {
            box.innerHTML = renderFallbackBox(kindLabel, title, description, '✅ 回饋已儲存至伺服器紀錄；但自動寄信暫時忙碌，請任選下方一種方式一鍵寄達站長：');
          }
        }
      } catch (e) {
        const box = document.getElementById('fbStatusBanner');
        if (box) box.innerHTML = renderFallbackBox(kindLabel, title, description, `⚠️ 連線忙碌（${e.message || '無法自動送出'}），請任選下方一種方式一鍵寄達站長：`);
        else F1.toast('⚠️ ' + e.message);
      } finally {
        _fbSending = false;
        const b2 = document.getElementById('fbSubmitBtn');
        if (b2) {
          b2.disabled = false;
          b2.textContent = '📨 送出意見回饋';
        }
      }
    };
  };
})();
