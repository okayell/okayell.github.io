/* F1 運彩智庫 — Page 3: 11 支車隊與車手專區 (#/team/<ABBR>) */
(function () {
  'use strict';
  const F1 = window.F1;

  F1.pages.team = function (el) {
    const snap = F1.snap || {};
    const teams = snap.teams || [];
    const curAbbr = F1.state.activeTeam || (teams[0] && teams[0].abbr) || 'MER';
    const tm = teams.find((t) => t.abbr === curAbbr) || teams[0];
    if (!tm) {
      el.innerHTML = '<div class="empty-box">尚無車隊資料</div>';
      return;
    }

    const hotPod = teams.filter((t) => t.pod_streak >= 2);
    const hotDbl = teams.filter((t) => t.dbl_streak >= 2);
    const hotPts = teams.filter((t) => t.pts_streak >= 3);
    const coldPts = teams.filter((t) => t.cold_streak >= 3);

    const rlogs = (tm.round_logs || []).slice().reverse();
    const selGid = F1.state.teamGameId || (rlogs[0] ? `R${String(rlogs[0].round).padStart(2, '0')}` : '');

    el.innerHTML = `
      <!-- Constructor Selector Strip -->
      <div class="team-conf-strip">
        <div class="conf-row">
          <span class="conf-tag">爭冠與中游</span>
          ${teams.map((t) => `
            <a href="#/team/${F1.esc(t.abbr)}" class="tm-pill ${t.abbr === tm.abbr ? 'active' : ''}">
              <img src="${F1.esc(t.logo)}" alt="">
              <span>${F1.esc(t.zh)}</span>
              ${t.pod_streak >= 2 ? `<span class="tm-mini-stk ats-w">連${t.pod_streak}台</span>` : t.pts_streak >= 3 ? `<span class="tm-mini-stk ou-u">連${t.pts_streak}分</span>` : t.cold_streak >= 3 ? `<span class="tm-mini-stk ats-l">連${t.cold_streak}掛零</span>` : ''}
            </a>
          `).join('')}
        </div>
      </div>

      <!-- League Streak Radar -->
      <div class="streak-radar-card">
        <div style="font-size:13px;font-weight:800;color:#0f172a">📡 2026 F1 全場車隊連勝與取分雷達（點擊車隊切換）</div>
        <div class="streak-radar-grid">
          <div class="streak-radar-col">
            <div class="streak-radar-lbl"><span style="color:#15803d">🏆 連續登上頒獎台 (≥2站)</span></div>
            <div style="display:flex;gap:5px;flex-wrap:wrap">
              ${hotPod.length ? hotPod.map((t) => `<a href="#/team/${t.abbr}" class="streak-team-chip ${t.abbr === tm.abbr ? 'is-cur' : ''}">${F1.esc(t.zh)} 連${t.pod_streak}</a>`).join('') : '<span style="font-size:12px;color:#94a3b8">無</span>'}
            </div>
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl"><span style="color:#1d4ed8">✨ 雙車連續進積分圈 (≥2站)</span></div>
            <div style="display:flex;gap:5px;flex-wrap:wrap">
              ${hotDbl.length ? hotDbl.map((t) => `<a href="#/team/${t.abbr}" class="streak-team-chip ${t.abbr === tm.abbr ? 'is-cur' : ''}">${F1.esc(t.zh)} 連${t.dbl_streak}</a>`).join('') : '<span style="font-size:12px;color:#94a3b8">無</span>'}
            </div>
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl"><span style="color:#c2410c">🔥 連續分站得分 (≥3站)</span></div>
            <div style="display:flex;gap:5px;flex-wrap:wrap">
              ${hotPts.length ? hotPts.map((t) => `<a href="#/team/${t.abbr}" class="streak-team-chip ${t.abbr === tm.abbr ? 'is-cur' : ''}">${F1.esc(t.zh)} 連${t.pts_streak}</a>`).join('') : '<span style="font-size:12px;color:#94a3b8">無</span>'}
            </div>
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl"><span style="color:#9f1239">❄️ 連續未得分低潮 (≥3站)</span></div>
            <div style="display:flex;gap:5px;flex-wrap:wrap">
              ${coldPts.length ? coldPts.map((t) => `<a href="#/team/${t.abbr}" class="streak-team-chip ${t.abbr === tm.abbr ? 'is-cur' : ''}">${F1.esc(t.zh)} 連${t.cold_streak}</a>`).join('') : '<span style="font-size:12px;color:#94a3b8">無</span>'}
            </div>
          </div>
        </div>
      </div>

      <!-- Constructor Hero -->
      <div class="team-hero">
        <div class="team-hero-left">
          <img class="team-hero-logo" src="${F1.esc(tm.logo)}" alt="">
          <div>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <h2 style="margin:0;font-size:21px;font-weight:900">${F1.esc(tm.zh)} (${F1.esc(tm.abbr)})</h2>
              <span class="chip strong">車隊榜 P${tm.rank}</span>
              <span class="chip muted">動力單元：${F1.esc(tm.pu)}</span>
            </div>
            <div style="font-size:12.5px;color:#64748b;margin-top:3px">${F1.esc(tm.full_en)} ｜ ${(tm.strength_tags || []).map(F1.esc).join(' · ')}</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
              ${(tm.drivers || []).map((d) => `
                <span class="chip info pl-link" data-player-id="${F1.esc(d.code)}">👨‍🚀 #${F1.esc(d.num)} ${F1.esc(d.zh)} (P${d.rank} · ${d.pts}分)</span>
              `).join('')}
            </div>
          </div>
        </div>

        <div class="team-hero-stats">
          <div class="th-stat"><div class="th-stat-lbl">年度總積分</div><div class="th-stat-val" style="color:#dc2626">${tm.pts}</div></div>
          <div class="th-stat"><div class="th-stat-lbl">站均積分</div><div class="th-stat-val">${tm.pts_pg}</div></div>
          <div class="th-stat"><div class="th-stat-lbl">勝場 / 頒獎台</div><div class="th-stat-val">${tm.wins} / ${tm.podiums}</div></div>
          <div class="th-stat"><div class="th-stat-lbl">桿位 / 退賽</div><div class="th-stat-val">${tm.poles} / ${tm.dnfs}</div></div>
        </div>
      </div>

      <!-- 3-Column 10-GP Trend Strip -->
      <div class="trend-strip-grid">
        <div class="trend-box ${tm.pts_streak >= 3 ? 'alert-cover' : ''}">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <strong>📈 近 10 站取分趨勢</strong>
            <span class="stk-badge su-win">連 ${tm.pts_streak} 站得分</span>
          </div>
          <div class="trend-dots">
            ${(tm.last10_pts || []).map((x) => `<span class="t-dot ${x === 'W' ? 'w' : 'l'}">${x === 'W' ? '分' : '零'}</span>`).join('')}
          </div>
        </div>
        <div class="trend-box ${tm.pod_streak >= 2 ? 'alert-over' : ''}">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <strong>🏆 近 10 站頒獎台趨勢</strong>
            <span class="stk-badge hot-over">連 ${tm.pod_streak} 站登台</span>
          </div>
          <div class="trend-dots">
            ${(tm.last10_pod || []).map((x) => `<span class="t-dot ${x === 'W' ? 'o' : 'p'}">${x === 'W' ? '台' : '—'}</span>`).join('')}
          </div>
        </div>
        <div class="trend-box ${tm.dbl_streak >= 2 ? 'alert-under' : ''}">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <strong>✨ 近 10 站雙車前十趨勢</strong>
            <span class="stk-badge hot-under">連 ${tm.dbl_streak} 站雙積分</span>
          </div>
          <div class="trend-dots">
            ${(tm.last10_dbl || []).map((x) => `<span class="t-dot ${x === 'W' ? 'u' : 'p'}">${x === 'W' ? '雙' : '單'}</span>`).join('')}
          </div>
        </div>
      </div>

      <!-- Round-by-Round Constructor Table -->
      <div class="card" style="margin-bottom:14px">
        <h3 style="margin:0 0 10px;font-size:15px">📅 2026 各站完賽明細（點擊任一分站可於下方展開 22 車全場遙測）</h3>
        <div class="tbl-wrap">
          <table class="data-tbl">
            <thead>
              <tr>
                <th>站別</th>
                <th>大獎賽</th>
                <th>雙車手起跑 → 完賽名次</th>
                <th class="num">最佳名次</th>
                <th class="num">單站積分</th>
                <th>狀態標記</th>
              </tr>
            </thead>
            <tbody>
              ${rlogs.map((r) => {
                const gid = `R${String(r.round).padStart(2, '0')}`;
                const rc = F1.raceMap[r.round] || {};
                return `
                  <tr class="${gid === selGid ? 'game-row-sel' : ''}" data-sel-gid="${gid}" style="cursor:pointer">
                    <td><strong>R${r.round}</strong> (${F1.esc(rc.tw_date || '')})</td>
                    <td><strong>${F1.esc(rc.gp_zh || '')}</strong></td>
                    <td>
                      ${(r.drivers || []).map((d) => `
                        <span style="margin-right:12px">
                          <strong class="pl-link" data-player-id="${F1.esc(d.code)}">${F1.esc(d.zh)}</strong>: P${d.grid} → <strong>${F1.esc(d.pos_text)}</strong>
                        </span>
                      `).join('')}
                    </td>
                    <td class="num"><strong>P${r.best_pos}</strong></td>
                    <td class="num"><strong style="color:#dc2626">${r.pts}</strong></td>
                    <td>
                      ${r.podium ? '<span class="chip strong">🏆 頒獎台</span> ' : ''}
                      ${r.both_pts ? '<span class="chip ok">雙車取分</span> ' : ''}
                      ${r.dnfs > 0 ? `<span class="chip bad">${r.dnfs} 車退賽</span>` : ''}
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      ${selGid ? F1.renderRaceTelemetryHtml(selGid) : ''}
    `;

    el.querySelectorAll('[data-sel-gid]').forEach((tr) => {
      tr.onclick = () => {
        F1.state.teamGameId = tr.getAttribute('data-sel-gid');
        F1.render();
      };
    });
  };
})();
