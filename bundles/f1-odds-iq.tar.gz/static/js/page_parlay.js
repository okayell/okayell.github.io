/* F1 運彩智庫 — Page: 🎰 分站不重複車手配對串關推薦 & 3串4 防退賽容錯 (#/parlay) */
(function () {
  'use strict';
  const F1 = window.F1;

  F1.state.parlayRound = 0;
  F1.state.parlayStake = 500;
  F1.state.parlayCustom = {};

  function buildRoundParlays(rc) {
    if (!rc) return { candidates: [], packages: [] };
    const sorted = (rc.h2h || []).slice().sort((a, b) => {
      const ta = a.tier === 'STRONG' ? 20 : a.tier === 'LEAN' ? 8 : 0;
      const tb = b.tier === 'STRONG' ? 20 : b.tier === 'LEAN' ? 8 : 0;
      return (tb + Number(b.edge_pct || 0)) - (ta + Number(a.edge_pct || 0));
    });

    // Enforce strictly disjoint drivers across parlay legs (F1 sportsbook correlation rule!)
    const usedDrivers = new Set();
    const candidates = [];
    for (const m of sorted) {
      if (usedDrivers.has(m.driver_a) || usedDrivers.has(m.driver_b)) continue;
      usedDrivers.add(m.driver_a);
      usedDrivers.add(m.driver_b);
      const side = m.pick_side || (m.model_prob_a >= 50 ? 'A' : 'B');
      const odds = Number(side === 'A' ? m.close_odds_a : m.close_odds_b);
      const prob = Number(side === 'A' ? m.model_prob_a : 100 - m.model_prob_a);
      const pickZh = side === 'A' ? m.driver_a_zh : m.driver_b_zh;
      const oppZh = side === 'A' ? m.driver_b_zh : m.driver_a_zh;
      let legRes = 'PENDING';
      if (rc.status === 'FINAL' && m.pos_a != null && m.pos_b != null) {
        legRes = (side === 'A' && m.pos_a < m.pos_b) || (side === 'B' && m.pos_b < m.pos_a) ? 'WIN' : 'LOSS';
      }
      candidates.push({
        matchup_id: m.matchup_id,
        label_zh: m.label_zh,
        pick_label_zh: `${pickZh} 勝 ${oppZh}`,
        odds,
        prob_pct: +prob.toFixed(1),
        edge_pct: Number(m.edge_pct || 0),
        tier: m.tier || 'PASS',
        leg_result: legRes,
        pos_txt: m.pos_a != null ? `P${m.pos_a} vs P${m.pos_b}` : '待起跑',
      });
    }

    function gradeDirect(legs) {
      if (legs.some((l) => l.leg_result === 'PENDING')) return { status: 'PENDING', mult: 0 };
      if (legs.some((l) => l.leg_result === 'LOSS')) return { status: 'LOSS', mult: 0 };
      return { status: 'WIN', mult: legs.reduce((acc, l) => acc * l.odds, 1) };
    }

    const packages = [];
    if (candidates.length >= 2) {
      const l2 = candidates.slice(0, 2);
      const odds2 = +(l2[0].odds * l2[1].odds).toFixed(2);
      const jp2 = (l2[0].prob_pct / 100) * (l2[1].prob_pct / 100);
      const gr2 = gradeDirect(l2);
      packages.push({
        key: 'anchor_2x1',
        type: 'DIRECT',
        bets_count: 1,
        badge_zh: '⭐ 穩健首選 · 2 串 1 雙車手配對主推',
        title_zh: `R${rc.round} ${rc.gp_zh.replace('大獎賽', '')} 2 串 1`,
        subtitle_zh: '嚴選本站兩組互不重疊車手之最高期望值配對，避開同車隊連帶事故風險。',
        grade_zh: l2.every((x) => x.tier === 'STRONG') ? '🔥 雙強推 S 級' : '✅ 精選 A 級',
        grade_cls: l2.every((x) => x.tier === 'STRONG') ? 'strong' : 'ok',
        legs: l2,
        combined_odds: odds2,
        joint_prob_pct: +(jp2 * 100).toFixed(1),
        ev_pct: +((jp2 * odds2 - 1) * 100).toFixed(1),
        status: gr2.status,
        return_mult: gr2.mult,
      });
    }
    if (candidates.length >= 3) {
      const l3 = candidates.slice(0, 3);
      const odds3 = +(l3[0].odds * l3[1].odds * l3[2].odds).toFixed(2);
      const p1 = l3[0].prob_pct / 100, p2 = l3[1].prob_pct / 100, p3 = l3[2].prob_pct / 100;
      const jp3 = p1 * p2 * p3;
      const gr3 = gradeDirect(l3);
      packages.push({
        key: 'boost_3x1',
        type: 'DIRECT',
        bets_count: 1,
        badge_zh: '🚀 高賠進取 · 3 串 1 黃金三配對',
        title_zh: `R${rc.round} 黃金三星 3 串 1`,
        subtitle_zh: '串聯三組獨立車手對決衝刺高倍派彩，建議小額娛樂注碼配置。',
        grade_zh: '⚡ 高賠衝刺',
        grade_cls: 'info',
        legs: l3,
        combined_odds: odds3,
        joint_prob_pct: +(jp3 * 100).toFixed(1),
        ev_pct: +((jp3 * odds3 - 1) * 100).toFixed(1),
        status: gr3.status,
        return_mult: gr3.mult,
      });

      const combos = [[l3[0], l3[1]], [l3[0], l3[2]], [l3[1], l3[2]], [l3[0], l3[1], l3[2]]];
      const maxMult = +(l3[0].odds * l3[1].odds + l3[0].odds * l3[2].odds + l3[1].odds * l3[2].odds + odds3).toFixed(2);
      const minHit2 = +Math.min(l3[0].odds * l3[1].odds, l3[0].odds * l3[2].odds, l3[1].odds * l3[2].odds).toFixed(2);
      const pAtLeast2 = jp3 + p1 * p2 * (1 - p3) + p1 * (1 - p2) * p3 + (1 - p1) * p2 * p3;
      let cashed = 0, retMult = 0;
      const pend = l3.some((x) => x.leg_result === 'PENDING');
      if (!pend) {
        combos.forEach((cb) => {
          const g = gradeDirect(cb);
          if (g.status === 'WIN') { cashed += 1; retMult += g.mult; }
        });
      }
      packages.push({
        key: 'shield_3x4',
        type: 'COMBO',
        bets_count: 4,
        badge_zh: '🛡️ 防 DNF 退賽容錯 · 3 串 4 複式組合（Trixie）',
        title_zh: `R${rc.round} 防機械退賽 3 串 4（共 4 注）`,
        subtitle_zh: 'F1 正賽常因單一車手起跑擦撞或引擎故障退賽倒 1 關；3 串 4 只要 3 過 2 即可領回雙關派彩保本回血！',
        grade_zh: '🛡️ 防退賽推薦',
        grade_cls: 'ok',
        legs: l3,
        max_mult: maxMult,
        hit2_mult: minHit2,
        at_least_2_prob_pct: +(pAtLeast2 * 100).toFixed(1),
        status: pend ? 'PENDING' : cashed === 4 ? 'WIN' : cashed >= 1 ? 'PARTIAL' : 'LOSS',
        cashed_combos: cashed,
        return_mult: retMult,
      });
    }
    return { candidates, packages };
  }

  F1.pages.parlay = function (root) {
    const snap = F1.snap || {};
    const races = snap.races || [];
    const defRnd = Number((snap.meta && snap.meta.default_round) || 19);
    const curRnd = Number(F1.state.parlayRound || F1.state.picksRound || defRnd);
    const rc = races.find((r) => r.round === curRnd) || races[races.length - 1];
    const unitStake = Math.max(100, Number(F1.state.parlayStake || 500));
    const bundle = buildRoundParlays(rc);
    const pkgs = bundle.packages || [];

    const selMap = F1.state.parlayCustom || {};
    const selLegs = Object.values(selMap).filter((x) => x.round === curRnd);
    const customOdds = selLegs.length >= 2 ? +selLegs.reduce((a, x) => a * x.odds, 1).toFixed(2) : 0;
    const customProb = selLegs.reduce((a, x) => a * (x.prob / 100), 1) * 100;

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🎰 F1 分站車手配對串關推薦 · 防 DNF 機械退賽 3串4 試算</h1>
          <div class="sec-sub">嚴格排除重複車手關聯盤（Correlated Parlay Guard），專為 F1 排位後正賽 H2H 配對盤設計</div>
        </div>
        <label style="font-size:12.5px;font-weight:700;color:#475569;display:inline-flex;align-items:center;gap:6px">
          每注金額 NT$
          <input type="number" step="100" min="100" class="inp" id="f1ParlayStakeInp" value="${unitStake}" style="width:95px;padding:5px 8px">
        </label>
      </div>

      <div class="date-bar">
        <span style="font-size:12px;font-weight:800;color:#475569">🏁 選擇大獎賽站別：</span>
        ${races.slice(Math.max(0, curRnd - 4), Math.min(races.length, curRnd + 3)).map((r) => `
          <button type="button" class="date-pill ${r.round === curRnd ? 'active' : ''}" data-prnd="${r.round}">
            R${r.round} ${F1.esc(r.gp_zh.replace('大獎賽', ''))}
          </button>
        `).join('')}
        <select class="inp" id="f1ParlayRndSel" style="margin-left:auto;padding:5px 9px;font-size:12.5px">
          ${races.map((r) => `<option value="${r.round}" ${r.round === curRnd ? 'selected' : ''}>R${r.round} · ${F1.esc(r.gp_zh)}</option>`).join('')}
        </select>
      </div>

      <div class="parlay-pkg-grid">
        ${pkgs.map((pkg) => {
          const isCombo = pkg.type === 'COMBO';
          const totalStake = unitStake * (pkg.bets_count || 1);
          const maxGross = Math.round(unitStake * (isCombo ? pkg.max_mult : pkg.combined_odds));
          const maxNet = maxGross - totalStake;
          const hit2Gross = isCombo ? Math.round(unitStake * pkg.hit2_mult) : 0;
          let stBanner = '';
          if (pkg.status !== 'PENDING') {
            const gross = Math.round(unitStake * pkg.return_mult);
            const net = gross - totalStake;
            stBanner = pkg.status === 'WIN'
              ? `<div style="background:#dcfce7;border:1px solid #86efac;color:#14532d;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">🎉 正賽對獎：全關過盤！領回 NT$ ${gross.toLocaleString()}（淨利 +NT$ ${net.toLocaleString()}）</div>`
              : pkg.status === 'PARTIAL'
              ? `<div style="background:#eff6ff;border:1px solid #93c5fd;color:#1e3a8a;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">🛡️ 正賽對獎：3 過 2 觸發防退賽容錯（中 ${pkg.cashed_combos}/4 注）！領回 NT$ ${gross.toLocaleString()}</div>`
              : `<div style="background:#fee2e2;border:1px solid #fca5a5;color:#991b1b;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">❌ 正賽對獎：未過關，損益 -NT$ ${totalStake.toLocaleString()}</div>`;
          }
          return `
            <article class="parlay-card ${pkg.key === 'anchor_2x1' ? 'anchor' : isCombo ? 'combo' : ''}">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
                <div>
                  <div style="font-size:11.5px;font-weight:800;color:#dc2626">${F1.esc(pkg.badge_zh)}</div>
                  <h3 style="margin:2px 0 0;font-size:16.5px">${F1.esc(pkg.title_zh)}</h3>
                </div>
                <span class="chip ${F1.esc(pkg.grade_cls)}">${F1.esc(pkg.grade_zh)}</span>
              </div>
              <div style="font-size:12.5px;color:#475569">${F1.esc(pkg.subtitle_zh)}</div>
              <div class="parlay-leg-list">
                ${pkg.legs.map((lg, i) => `
                  <div class="parlay-leg-row ${lg.leg_result === 'WIN' ? 'leg-win' : lg.leg_result === 'LOSS' ? 'leg-loss' : ''}">
                    <div style="display:flex;justify-content:space-between;align-items:center;font-size:12px">
                      <span><strong>第 ${i + 1} 關</strong> · ${F1.esc(lg.label_zh)} (${F1.esc(lg.pos_txt)})</span>
                      <span class="chip ${lg.leg_result === 'WIN' ? 'ok' : lg.leg_result === 'LOSS' ? 'bad' : 'info'}">${lg.leg_result === 'WIN' ? '✅ 過關' : lg.leg_result === 'LOSS' ? '❌ 倒關' : `${lg.odds.toFixed(2)}x`}</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:2px">
                      <strong style="font-size:14px">${F1.esc(lg.pick_label_zh)}</strong>
                      <span style="font-size:12px;color:#475569">勝率 ${lg.prob_pct}% · Edge +${lg.edge_pct}%</span>
                    </div>
                  </div>`).join('')}
              </div>
              ${isCombo
                ? `<div class="parlay-payout-box">
                    <div><div style="font-size:11px;color:#64748b">總本金 (4注)</div><div style="font-weight:800">NT$ ${totalStake.toLocaleString()}</div></div>
                    <div><div style="font-size:11px;color:#64748b">3關全過領回</div><div style="font-weight:800;color:#15803d">NT$ ${maxGross.toLocaleString()}</div></div>
                    <div><div style="font-size:11px;color:#64748b">3過2最低回血</div><div style="font-weight:800;color:#1d4ed8">NT$ ${hit2Gross.toLocaleString()}</div></div>
                    <div><div style="font-size:11px;color:#64748b">至少過2關率</div><div style="font-weight:800">${pkg.at_least_2_prob_pct}%</div></div>
                  </div>`
                : `<div class="parlay-payout-box">
                    <div><div style="font-size:11px;color:#64748b">單注本金</div><div style="font-weight:800">NT$ ${totalStake.toLocaleString()}</div></div>
                    <div><div style="font-size:11px;color:#64748b">綜合賠率</div><div style="font-weight:800;color:#dc2626">${pkg.combined_odds}x</div></div>
                    <div><div style="font-size:11px;color:#64748b">過關領回</div><div style="font-weight:800;color:#15803d">NT$ ${maxGross.toLocaleString()} (+${maxNet.toLocaleString()})</div></div>
                    <div><div style="font-size:11px;color:#64748b">過關率 / EV</div><div style="font-weight:800">${pkg.joint_prob_pct}% (${pkg.ev_pct >= 0 ? '+' : ''}${pkg.ev_pct}%)</div></div>
                  </div>`}
              ${stBanner}
              <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:auto">
                <button type="button" class="btn btn-primary btn-sm" data-save-f1pkg="${F1.esc(pkg.key)}">➕ 一鍵加入注單追蹤</button>
              </div>
            </article>`;
        }).join('')}
      </div>

      <!-- Custom F1 H2H Parlay Builder -->
      <div class="card">
        <div class="sec-hdr">
          <div>
            <h2 class="sec-title">🧮 自選 F1 車手配對串關試算機（R${rc ? rc.round : ''} ${F1.esc(rc ? rc.gp_zh : '')}）</h2>
            <div class="sec-sub">自由點選任意 2～5 組車手對決試算過關總賠率與聯立勝率</div>
          </div>
        </div>
        <div class="parlay-builder-wrap">
          <div style="display:flex;flex-direction:column;gap:7px">
            ${((rc && rc.h2h) || []).map((m) => {
              const cur = selMap[m.matchup_id];
              return `
                <div class="pb-game-row">
                  <div style="font-weight:800;font-size:12.5px">${F1.esc(m.label_zh)}</div>
                  <button type="button" class="pb-pick-btn ${cur && cur.side === 'A' ? 'selected' : ''}" data-f1m="${F1.esc(m.matchup_id)}" data-side="A" data-lbl="${F1.esc(m.driver_a_zh + ' 勝 ' + m.driver_b_zh)}" data-odds="${m.close_odds_a}" data-prob="${m.model_prob_a}">
                    <span>🏎️ ${F1.esc(m.driver_a_zh)} 勝</span>
                    <strong>${m.close_odds_a.toFixed(2)}x</strong>
                  </button>
                  <button type="button" class="pb-pick-btn ${cur && cur.side === 'B' ? 'selected' : ''}" data-f1m="${F1.esc(m.matchup_id)}" data-side="B" data-lbl="${F1.esc(m.driver_b_zh + ' 勝 ' + m.driver_a_zh)}" data-odds="${m.close_odds_b}" data-prob="${(100 - m.model_prob_a).toFixed(1)}">
                    <span>🏎️ ${F1.esc(m.driver_b_zh)} 勝</span>
                    <strong>${m.close_odds_b.toFixed(2)}x</strong>
                  </button>
                </div>`;
            }).join('')}
          </div>
          <div class="card" style="background:#f8fafc;align-self:start">
            <h3 style="margin:0 0 8px;font-size:15px">📋 自選 F1 串關單（已選 ${selLegs.length} 關）</h3>
            ${selLegs.length < 2
              ? `<div class="empty-box" style="padding:20px">請從左側點選至少 <strong>2 組配對</strong> 試算串關賠率</div>`
              : `
                <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:12px">
                  ${selLegs.map((x, i) => `<div style="display:flex;justify-content:space-between;font-size:13px;padding:6px 9px;background:#fff;border-radius:7px;border:1px solid #e2e8f0"><span>#${i + 1} ${F1.esc(x.lbl)}</span><strong>${x.odds.toFixed(2)}x</strong></div>`).join('')}
                </div>
                <div class="parlay-payout-box" style="margin-bottom:12px">
                  <div><div style="font-size:11px;color:#64748b">綜合賠率</div><div style="font-size:16px;font-weight:900;color:#dc2626">${customOdds}x</div></div>
                  <div><div style="font-size:11px;color:#64748b">預估總領回</div><div style="font-size:16px;font-weight:900;color:#15803d">NT$ ${Math.round(unitStake * customOdds).toLocaleString()}</div></div>
                  <div><div style="font-size:11px;color:#64748b">聯立勝率</div><div style="font-size:15px;font-weight:800">${customProb.toFixed(1)}%</div></div>
                </div>
                <button type="button" class="btn btn-primary" style="width:100%" id="saveF1CustomParlay">➕ 加入注單追蹤</button>
              `}
          </div>
        </div>
      </div>
    `;

    const stInp = document.getElementById('f1ParlayStakeInp');
    if (stInp) stInp.onchange = () => { F1.state.parlayStake = Math.max(100, Number(stInp.value || 500)); F1.render(); };
    root.querySelectorAll('[data-prnd]').forEach((b) => {
      b.onclick = () => { F1.state.parlayRound = Number(b.getAttribute('data-prnd')); F1.render(); };
    });
    const rSel = document.getElementById('f1ParlayRndSel');
    if (rSel) rSel.onchange = () => { F1.state.parlayRound = Number(rSel.value); F1.render(); };

    root.querySelectorAll('[data-save-f1pkg]').forEach((btn) => {
      btn.onclick = async () => {
        const pkg = pkgs.find((x) => x.key === btn.getAttribute('data-save-f1pkg'));
        if (!pkg || !rc) return;
        const isCombo = pkg.type === 'COMBO';
        const res = await F1.apiPost('/api/bets/add', {
          tw_date: rc.tw_date,
          game_id: '',
          matchup: pkg.title_zh,
          market: 'PARLAY',
          pick_side: pkg.type,
          pick_label: pkg.legs.map((l) => l.pick_label_zh).join(' ＋ '),
          line: pkg.legs.length,
          odds_decimal: isCombo ? +(pkg.max_mult / 4).toFixed(2) : pkg.combined_odds,
          stake: isCombo ? unitStake * 4 : unitStake,
          note: 'F1 配對串關',
        });
        F1.bets = res.bets || [];
        F1.toast(`✅ 已將「${pkg.title_zh}」加入注單追蹤！`);
      };
    });

    root.querySelectorAll('[data-f1m]').forEach((btn) => {
      btn.onclick = () => {
        const mid = btn.getAttribute('data-f1m');
        const side = btn.getAttribute('data-side');
        const cur = F1.state.parlayCustom[mid];
        if (cur && cur.side === side) delete F1.state.parlayCustom[mid];
        else {
          F1.state.parlayCustom[mid] = {
            round: curRnd,
            mid,
            side,
            lbl: btn.getAttribute('data-lbl'),
            odds: Number(btn.getAttribute('data-odds')),
            prob: Number(btn.getAttribute('data-prob')),
          };
        }
        F1.render();
      };
    });

    const svCustom = document.getElementById('saveF1CustomParlay');
    if (svCustom && selLegs.length >= 2 && rc) {
      svCustom.onclick = async () => {
        const res = await F1.apiPost('/api/bets/add', {
          tw_date: rc.tw_date,
          game_id: '',
          matchup: `R${rc.round} 自選 ${selLegs.length} 串 1`,
          market: 'PARLAY',
          pick_side: 'DIRECT',
          pick_label: selLegs.map((l) => l.lbl).join(' ＋ '),
          line: selLegs.length,
          odds_decimal: customOdds,
          stake: unitStake,
          note: 'F1 自選串關',
        });
        F1.bets = res.bets || [];
        F1.toast('✅ 已加入注單追蹤！');
      };
    }
  };
})();
