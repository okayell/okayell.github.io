#!/usr/bin/env python3
"""F1 Technical Penalty / PU Wear Radar & Bilingual News Aggregator (ESPN F1 + Google News RSS)."""
from __future__ import annotations

import datetime as dt
import email.utils
import hashlib
import html
import re
import sqlite3
import urllib.parse
import xml.etree.ElementTree as ET

import config
import net
import teams

ESPN_F1_NEWS = 'https://site.api.espn.com/apis/site/v2/sports/racing/f1/news?limit=24'
GNEWS_ZH = (
    'https://news.google.com/rss/search?q='
    + urllib.parse.quote('F1 大獎賽 OR 排位賽 OR 法拉利 OR 賓士 OR 紅牛 OR 麥拉倫 when:7d')
    + '&hl=zh-TW&gl=TW&ceid=TW:zh-Hant'
)
GNEWS_EN = (
    'https://news.google.com/rss/search?q='
    + urllib.parse.quote('"Formula 1" (upgrade OR penalty OR qualifying OR Grand Prix) when:7d')
    + '&hl=en-US&gl=US&ceid=US:en'
)

TEAM_KEYWORDS: list[tuple[str, tuple[str, ...]]] = [
    ('MER', ('mercedes', 'antonelli', 'russell', '賓士', '安東內利', '羅素')),
    ('FER', ('ferrari', 'hamilton', 'leclerc', '法拉利', '漢米爾頓', '勒克萊爾')),
    ('RBR', ('red bull', 'verstappen', 'hadjar', '紅牛', '維斯塔潘', '哈賈爾')),
    ('MCL', ('mclaren', 'norris', 'piastri', '麥拉倫', '諾里斯', '皮亞斯特里')),
    ('RB', ('racing bulls', 'lawson', 'lindblad', 'tsunoda', '勞森', '角田')),
    ('ALP', ('alpine', 'gasly', 'colapinto', '阿爾派', '蓋斯利', '科拉平托')),
    ('HAA', ('haas', 'bearman', 'ocon', '哈斯', '貝爾曼', '奧康')),
    ('AUD', ('audi', 'hulkenberg', 'hülkenberg', 'bortoleto', '奧迪', '霍肯伯格')),
    ('WIL', ('williams', 'sainz', 'albon', '威廉斯', '賽恩斯', '阿爾本')),
    ('AMR', ('aston martin', 'alonso', 'stroll', '奧斯頓馬丁', '阿隆索')),
    ('CAD', ('cadillac', 'bottas', 'perez', 'pérez', '凱迪拉克', '博塔斯', '佩雷茲')),
]


def _detect_team(text: str) -> str:
  low = text.lower()
  for ab, kws in TEAM_KEYWORDS:
    if any(k in low for k in kws):
      return ab
  return ''


def _detect_cat(text: str) -> str:
  low = text.lower()
  if any(k in low for k in ('penalty', 'grid drop', 'engine', 'gearbox', 'fia', 'steward', '罰退', '更換動力', '判罰')):
    return 'PENALTY'
  if any(k in low for k in ('upgrade', 'floor', 'wing', 'aero', 'technical', '升級', '底板', '空力')):
    return 'UPGRADE'
  if any(k in low for k in ('odds', 'betting', 'favorite', 'prediction', '賠率', '奪冠', '預測', '盤口')):
    return 'BETTING'
  return 'RACE'


def _strip_tags(s: str) -> str:
  return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', s or ''))).strip()


def _rss_date_tw(pub: str) -> str:
  try:
    d = email.utils.parsedate_to_datetime(pub)
    if d.tzinfo is None:
      d = d.replace(tzinfo=config.TZ_UTC)
    return d.astimezone(config.TZ_TW).strftime('%Y-%m-%d %H:%M')
  except Exception:  # pylint: disable=broad-except
    return dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M')


def sync_news_and_tech_watch(conn: sqlite3.Connection) -> dict[str, int]:
  now_tw = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M')
  inserted = 0

  # 1. ESPN F1 News
  try:
    data = net.fetch_json(ESPN_F1_NEWS)
    for art in data.get('articles') or []:
      title = (art.get('headline') or '').strip()
      desc = (art.get('description') or '').strip()
      url = (((art.get('links') or {}).get('web') or {}).get('href') or '').strip()
      if not title or not url:
        continue
      pub_raw = art.get('published') or ''
      if pub_raw.endswith('Z'):
        pub_raw = pub_raw[:-1] + '+00:00'
      try:
        pub_tw = dt.datetime.fromisoformat(pub_raw).astimezone(config.TZ_TW).strftime('%Y-%m-%d %H:%M')
      except ValueError:
        pub_tw = now_tw
      nid = hashlib.sha1(url.encode('utf-8')).hexdigest()[:16]
      blob = f'{title} {desc}'
      conn.execute(
          """
          INSERT INTO news_items(news_id, published_tw, source, lang, category, team_abbr, title, summary, url)
          VALUES (?,?,?,?,?,?,?,?,?)
          ON CONFLICT(news_id) DO UPDATE SET
            published_tw=excluded.published_tw, title=excluded.title, summary=excluded.summary
          """,
          (nid, pub_tw, 'ESPN F1', 'EN', _detect_cat(blob), _detect_team(blob), title, desc[:260], url),
      )
      inserted += 1
  except Exception:  # pylint: disable=broad-except
    pass

  # 2. Google News RSS (ZH-TW & EN)
  for rss_url, lang, src_fallback in ((GNEWS_ZH, 'ZH', 'Google 新聞 F1'), (GNEWS_EN, 'EN', 'F1 Wire')):
    try:
      xml_txt = net.fetch_text(rss_url)
      root = ET.fromstring(xml_txt)
      for item in root.findall('.//item')[:18]:
        raw_title = (item.findtext('title') or '').strip()
        link = (item.findtext('link') or '').strip()
        desc = _strip_tags(item.findtext('description') or '')
        src_el = item.find('source')
        src = (src_el.text.strip() if src_el is not None and src_el.text else '') or src_fallback
        if ' - ' in raw_title:
          raw_title = raw_title.rsplit(' - ', 1)[0].strip()
        if not raw_title or not link:
          continue
        pub_tw = _rss_date_tw(item.findtext('pubDate') or '')
        nid = hashlib.sha1(raw_title.encode('utf-8')).hexdigest()[:16]
        blob = f'{raw_title} {desc}'
        conn.execute(
            """
            INSERT INTO news_items(news_id, published_tw, source, lang, category, team_abbr, title, summary, url)
            VALUES (?,?,?,?,?,?,?,?,?)
            ON CONFLICT(news_id) DO NOTHING
            """,
            (nid, pub_tw, src[:32], lang, _detect_cat(blob), _detect_team(blob), raw_title[:200], desc[:220], link),
        )
        inserted += 1
    except Exception:  # pylint: disable=broad-except
      pass

  # 3. Compute Empirical PU / Reliability / Penalty Watch per Driver & Constructor from 2026 Telemetry
  conn.execute('DELETE FROM tech_watch')
  rows = conn.execute(
      """
      SELECT driver_code, driver_zh, team_abbr,
             COUNT(*) AS starts,
             SUM(CASE WHEN classified = 0 THEN 1 ELSE 0 END) AS dnfs,
             SUM(CASE WHEN status LIKE '%Engine%' OR status LIKE '%Power%' OR status LIKE '%Gearbox%'
                        OR status LIKE '%Hydraulics%' OR status LIKE '%Brakes%' OR status LIKE '%Electrical%'
                        OR status = 'Retired' THEN 1 ELSE 0 END) AS mech_issues,
             AVG(CASE WHEN grid > 0 THEN grid - position ELSE 0 END) AS avg_gain
      FROM race_results
      GROUP BY driver_code
      ORDER BY dnfs DESC, starts DESC
      """
  ).fetchall()

  next_race = conn.execute(
      "SELECT round, gp_zh, circuit_id FROM races WHERE status != 'FINAL' ORDER BY round ASC LIMIT 1"
  ).fetchone()
  next_cid = (next_race['circuit_id'] if next_race else 'rodriguez')
  c_prof = teams.circuit_info(next_cid)

  watch_cnt = 0
  for r in rows:
    dnfs = int(r['dnfs'] or 0)
    mech = int(r['mech_issues'] or 0)
    starts = max(1, int(r['starts'] or 1))
    d_code = r['driver_code']
    t_ab = r['team_abbr']
    d_zh = r['driver_zh'] or d_code
    t_zh = teams.team_info(t_ab)['zh']

    # Estimate season-end PU pool quota pressure (after ~18 rounds, >=3 DNFs/retirements raises ICE/TC/MGU quota risk)
    risk_pct = min(85, 12 + dnfs * 16 + mech * 8)
    if risk_pct >= 52:
      st = 'WATCH'
      cat_zh = '⚠️ 動力單元配額警戒'
      hl = f'{d_zh} ({d_code}) 本季累計 {dnfs} 次未完賽，季末動力單元／變速箱配額接近罰退門檻'
      imp = f'於【{c_prof["gp_zh"]}】若排位前更換超額組件將面臨 5–10 位罰退，建議等 FP3／排位確認無罰退再進場 H2H 主推。'
    elif dnfs == 0 and starts >= 10:
      st = 'CLEAN'
      cat_zh = '✅ 100% 完賽高妥善率'
      hl = f'{d_zh} ({d_code}) 本季 {starts} 站全數完賽零退賽，長距離機械妥善率全場頂尖'
      imp = f'在退賽與安全車率 {int(c_prof["sc_rate"]*100)}% 的【{c_prof["gp_zh"]}】具備極高下限保護，車手對決盤穩定度加分。'
    elif float(r['avg_gain'] or 0) >= 1.8:
      st = 'UPGRADE'
      cat_zh = '🚀 正賽追擊強勢車手'
      hl = f'{d_zh} ({d_code}) 正賽場均淨推進 +{float(r["avg_gain"]):.1f} 個名次，長距離輪胎管理優於排位單圈'
      imp = f'若週六排位小幅落後隊友 1–2 位，週日正賽 H2H 受讓高賠端極具反超期望值。'
    elif dnfs >= 2:
      st = 'CAUTION'
      cat_zh = '🔧 完賽波動留意'
      hl = f'{t_zh} · {d_zh} ({d_code}) 本季已有 {dnfs} 站退賽紀錄（完賽率 {round((starts-dnfs)/starts*100)}%）'
      imp = f'配對盤若處低賠讓方（<1.65）須提防首圈擦撞或散熱異常造成爆冷。'
    else:
      continue

    conn.execute(
        """
        INSERT INTO tech_watch(item_id, team_abbr, driver_code, status, category_zh, headline_zh, impact_note, grid_risk_pct, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?)
        """,
        (f'TW-{d_code}', t_ab, d_code, st, cat_zh, hl, imp, risk_pct, now_tw),
    )
    watch_cnt += 1

  return {'news': inserted, 'tech_watch': watch_cnt}
