#!/usr/bin/env python3
"""Live 2026 Formula 1 Calendar, Qualifying, Sprint & Race Telemetry Ingestion (Jolpica + ESPN F1)."""
from __future__ import annotations

import datetime as dt
import json
import sqlite3
from typing import Any

import config
import net
import teams

JOLPICA_BASE = f'https://api.jolpi.ca/ergast/f1/{config.SEASON_YEAR}'
ESPN_SCOREBOARD = f'https://site.api.espn.com/apis/site/v2/sports/racing/f1/scoreboard?dates={config.SEASON_YEAR}'


def _parse_iso_to_tw(iso_str: str) -> tuple[str, str]:
  s = (iso_str or '').strip()
  if not s:
    return '', ''
  if s.endswith('Z'):
    s = s[:-1] + '+00:00'
  try:
    d_utc = dt.datetime.fromisoformat(s)
    if d_utc.tzinfo is None:
      d_utc = d_utc.replace(tzinfo=config.TZ_UTC)
    d_tw = d_utc.astimezone(config.TZ_TW)
    return d_tw.strftime('%Y-%m-%d %H:%M'), d_tw.strftime('%Y-%m-%d')
  except ValueError:
    return s[:16], s[:10]


def _lap_to_sec(lap_str: str | None) -> float | None:
  if not lap_str:
    return None
  s = str(lap_str).strip()
  if not s:
    return None
  try:
    if ':' in s:
      m_part, sec_part = s.split(':', 1)
      return round(int(m_part) * 60.0 + float(sec_part), 3)
    return round(float(s), 3)
  except ValueError:
    return None


def _fetch_paginated_races(endpoint: str) -> list[dict[str, Any]]:
  merged: dict[int, dict[str, Any]] = {}
  offset = 0
  limit = 100
  while offset < 700:
    url = f'{JOLPICA_BASE}/{endpoint}?limit={limit}&offset={offset}'
    data = net.fetch_json(url)
    mr = data.get('MRData') or {}
    total = int(mr.get('total') or 0)
    races = (mr.get('RaceTable') or {}).get('Races') or []
    if not races:
      break
    for r in races:
      rnd = int(r['round'])
      if rnd not in merged:
        merged[rnd] = dict(r)
      else:
        for k in ('Results', 'QualifyingResults', 'SprintResults'):
          if r.get(k):
            merged[rnd].setdefault(k, []).extend(r[k])
    offset += limit
    if offset >= total:
      break
  return [merged[k] for k in sorted(merged)]


def sync_f1_season(conn: sqlite3.Connection) -> dict[str, int]:
  now_str = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S')

  # 1. ESPN F1 calendar for exact session timestamps (FP1/FP2/FP3/Qual/Sprint/Race)
  espn_by_date: list[dict[str, Any]] = []
  try:
    espn_cal = net.fetch_json(ESPN_SCOREBOARD)
    espn_by_date = espn_cal.get('events') or []
  except Exception:  # pylint: disable=broad-except
    espn_by_date = []

  # 2. Jolpica official 2026 calendar
  cal_data = net.fetch_json(f'{JOLPICA_BASE}.json')
  cal_races = ((cal_data.get('MRData') or {}).get('RaceTable') or {}).get('Races') or []

  # 3. Bulk fetch Results, Qualifying, and Sprint
  res_races = {int(r['round']): r for r in _fetch_paginated_races('results.json')}
  qual_races = {int(r['round']): r for r in _fetch_paginated_races('qualifying.json')}
  spr_races = {int(r['round']): r for r in _fetch_paginated_races('sprint.json')}

  sess_labels = {
      'FP1': '一練 FP1', 'FP2': '二練 FP2', 'FP3': '三練 FP3',
      'SS': '衝刺排位 SQ', 'SR': '衝刺賽 Sprint', 'Qual': '排位賽 Qualifying', 'Race': '正賽 Grand Prix',
  }

  race_cnt = 0
  res_cnt = 0
  for r in cal_races:
    rnd = int(r['round'])
    race_name = r.get('raceName') or f'Round {rnd}'
    cir = r.get('Circuit') or {}
    cid = cir.get('circuitId') or 'circuit'
    loc = cir.get('Location') or {}
    c_prof = teams.circuit_info(cid, race_name)

    r_date = r.get('date') or ''
    r_time = r.get('time') or '13:00:00Z'
    race_utc = f'{r_date}T{r_time}'
    race_tw, tw_date = _parse_iso_to_tw(race_utc)

    qual_utc = ''
    if isinstance(r.get('Qualifying'), dict):
      q_d = r['Qualifying'].get('date') or ''
      q_t = r['Qualifying'].get('time') or '13:00:00Z'
      if q_d:
        qual_utc = f'{q_d}T{q_t}'
    qual_tw, _ = _parse_iso_to_tw(qual_utc) if qual_utc else ('', '')

    spr_utc = ''
    has_sprint = 0
    if isinstance(r.get('Sprint'), dict):
      s_d = r['Sprint'].get('date') or ''
      s_t = r['Sprint'].get('time') or '11:00:00Z'
      if s_d:
        spr_utc = f'{s_d}T{s_t}'
        has_sprint = 1
    sprint_tw, _ = _parse_iso_to_tw(spr_utc) if spr_utc else ('', '')

    # Match ESPN event within +/- 3 days of race date for full session timetable
    event_id = ''
    sessions: list[dict[str, str]] = []
    for ev in espn_by_date:
      ev_dt = (ev.get('date') or '')[:10]
      try:
        if ev_dt and r_date and abs((dt.date.fromisoformat(r_date) - dt.date.fromisoformat(ev_dt)).days) <= 4:
          event_id = str(ev.get('id') or '')
          for comp in ev.get('competitions') or []:
            ab = ((comp.get('type') or {}).get('abbreviation') or '').strip()
            c_tw, _ = _parse_iso_to_tw(comp.get('date') or '')
            st_nm = ((comp.get('status') or {}).get('type') or {}).get('name') or ''
            sessions.append({
                'code': ab,
                'zh': sess_labels.get(ab, ab),
                'tw': c_tw,
                'done': 'FINAL' in st_nm,
            })
            if ab == 'Qual' and c_tw and not qual_tw:
              qual_tw = c_tw
            if ab == 'SR' and c_tw:
              has_sprint = 1
              if not sprint_tw:
                sprint_tw = c_tw
          break
      except ValueError:
        continue

    # Parse Sprint results for this round first
    sprint_map: dict[str, tuple[int, float]] = {}
    if rnd in spr_races:
      has_sprint = 1
      for sr in spr_races[rnd].get('SprintResults') or []:
        drv = sr.get('Driver') or {}
        d_code = (drv.get('code') or drv.get('familyName', '')[:3]).upper()
        sprint_map[d_code] = (int(sr.get('position') or 0), float(sr.get('points') or 0.0))

    # Parse Qualifying results
    pole_driver = ''
    if rnd in qual_races:
      for qr in qual_races[rnd].get('QualifyingResults') or []:
        drv = qr.get('Driver') or {}
        con = qr.get('Constructor') or {}
        d_code = (drv.get('code') or drv.get('familyName', '')[:3]).upper()
        t_ab = teams.constructor_abbr(con.get('constructorId') or con.get('name') or '')
        qpos = int(qr.get('position') or 99)
        if qpos == 1:
          pole_driver = d_code
        q1, q2, q3 = qr.get('Q1') or '', qr.get('Q2') or '', qr.get('Q3') or ''
        secs = [x for x in (_lap_to_sec(q3), _lap_to_sec(q2), _lap_to_sec(q1)) if x is not None]
        best_sec = min(secs) if secs else None
        conn.execute(
            """
            INSERT INTO qual_results(round, driver_code, team_abbr, position, q1, q2, q3, best_sec)
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT(round, driver_code) DO UPDATE SET
              team_abbr=excluded.team_abbr, position=excluded.position,
              q1=excluded.q1, q2=excluded.q2, q3=excluded.q3, best_sec=excluded.best_sec
            """,
            (rnd, d_code, t_ab, qpos, q1, q2, q3, best_sec),
        )

    # Parse Grand Prix Results
    status = 'SCHEDULED'
    winner_driver = ''
    fastest_driver = ''
    classified_count = None
    dnf_count = None
    ou_result = ''
    f_line = float(c_prof.get('finishers_line') or 18.5)

    if rnd in res_races and (res_races[rnd].get('Results') or []):
      status = 'FINAL'
      r_list = res_races[rnd]['Results']
      cls_cnt = 0
      dnfs = 0
      for rr in r_list:
        drv = rr.get('Driver') or {}
        con = rr.get('Constructor') or {}
        t_ab = teams.constructor_abbr(con.get('constructorId') or con.get('name') or '')
        d_info = teams.driver_info(
            drv.get('code') or '',
            drv.get('givenName') or '',
            drv.get('familyName') or '',
            t_ab,
            str(rr.get('number') or drv.get('permanentNumber') or ''),
        )
        d_code = d_info['code']
        pos = int(rr.get('position') or 99)
        pos_txt = str(rr.get('positionText') or pos)
        grid = int(rr.get('grid') or 0)
        if grid == 1 and not pole_driver:
          pole_driver = d_code
        if pos == 1:
          winner_driver = d_code
        pts = float(rr.get('points') or 0.0)
        laps = int(rr.get('laps') or 0)
        st_txt = str(rr.get('status') or '')
        is_cls = 1 if (st_txt == 'Finished' or st_txt.startswith('+') or pos_txt.isdigit()) and st_txt not in ('Retired', 'Disqualified', 'Did not start', 'Withdrew') else 0
        # Stricter classified check: finished or +N Lap
        is_cls = 1 if (st_txt == 'Finished' or 'Lap' in st_txt) else 0
        if is_cls:
          cls_cnt += 1
        else:
          dnfs += 1
        t_str = ((rr.get('Time') or {}).get('time')) or st_txt
        fl = rr.get('FastestLap') or {}
        fl_rank = int(fl.get('rank') or 99)
        fl_time = ((fl.get('Time') or {}).get('time')) or ''
        if fl_rank == 1:
          fastest_driver = d_code
        s_pos, s_pts = sprint_map.get(d_code, (0, 0.0))

        conn.execute(
            """
            INSERT INTO race_results(
              round, driver_code, driver_id, driver_en, driver_zh, number, team_abbr,
              grid, position, pos_text, points, laps, status, classified, time_str,
              fastest_lap_rank, fastest_lap_time, sprint_points, sprint_pos
            ) VALUES (?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?,?,?)
            ON CONFLICT(round, driver_code) DO UPDATE SET
              team_abbr=excluded.team_abbr, grid=excluded.grid, position=excluded.position,
              pos_text=excluded.pos_text, points=excluded.points, laps=excluded.laps,
              status=excluded.status, classified=excluded.classified, time_str=excluded.time_str,
              fastest_lap_rank=excluded.fastest_lap_rank, fastest_lap_time=excluded.fastest_lap_time,
              sprint_points=excluded.sprint_points, sprint_pos=excluded.sprint_pos
            """,
            (
                rnd, d_code, drv.get('driverId') or d_code.lower(), d_info['en'], d_info['zh'],
                d_info['num'], t_ab, grid, pos, pos_txt, pts, laps, st_txt, is_cls, t_str,
                fl_rank, fl_time, s_pts, s_pos,
            ),
        )
        res_cnt += 1

      classified_count = cls_cnt
      dnf_count = dnfs
      ou_result = 'OVER' if cls_cnt > f_line else ('UNDER' if cls_cnt < f_line else 'PUSH')

    conn.execute(
        """
        INSERT INTO races(
          round, season, event_id, race_name, gp_zh, circuit_id, circuit_zh,
          country, locality, race_utc, race_tw, tw_date, qual_tw, sprint_tw,
          has_sprint, status, pole_driver, winner_driver, fastest_driver,
          classified_count, dnf_count, finishers_line, ou_result, sessions_json, updated_at
        ) VALUES (?,?,?,?,?,?,?, ?,?,?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,?)
        ON CONFLICT(round) DO UPDATE SET
          event_id=excluded.event_id, race_name=excluded.race_name, gp_zh=excluded.gp_zh,
          circuit_id=excluded.circuit_id, circuit_zh=excluded.circuit_zh,
          race_utc=excluded.race_utc, race_tw=excluded.race_tw, tw_date=excluded.tw_date,
          qual_tw=excluded.qual_tw, sprint_tw=excluded.sprint_tw, has_sprint=excluded.has_sprint,
          status=excluded.status, pole_driver=excluded.pole_driver, winner_driver=excluded.winner_driver,
          fastest_driver=excluded.fastest_driver, classified_count=excluded.classified_count,
          dnf_count=excluded.dnf_count, finishers_line=excluded.finishers_line,
          ou_result=excluded.ou_result, sessions_json=excluded.sessions_json, updated_at=excluded.updated_at
        """,
        (
            rnd, config.SEASON_YEAR, event_id, race_name, c_prof['gp_zh'], cid, c_prof['circuit_zh'],
            loc.get('country') or '', loc.get('locality') or '', race_utc, race_tw, tw_date,
            qual_tw, sprint_tw, has_sprint, status, pole_driver, winner_driver, fastest_driver,
            classified_count, dnf_count, f_line, ou_result, json.dumps(sessions, ensure_ascii=False), now_str,
        ),
    )
    race_cnt += 1

  return {'races': race_cnt, 'results': res_cnt}
