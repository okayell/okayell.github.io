#!/usr/bin/env python3
"""Global configuration for F1 運彩智庫 (Formula 1 Betting Analytics & Self-Evolving Studio)."""
from __future__ import annotations

import datetime as dt
import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')

DB_PATH = os.path.join(DATA_DIR, 'f1_betting.sqlite3')
SNAPSHOT_JSON = os.path.join(DATA_DIR, 'snapshot.json')
SYNC_LOCK = os.path.join(DATA_DIR, 'sync.lock')

SERVICE_SLUG = 'f1-betting'
TOOL_TITLE = 'F1 戰情室'
BACKEND_PORT = 8914
PROXY_PORT = 8915

SEASON_YEAR = 2026
TZ_TW = dt.timezone(dt.timedelta(hours=8))
TZ_UTC = dt.timezone.utc

# Standard -110 (1.9091 decimal) 2-way H2H & O/U sportsbook parameters
DEFAULT_AMERICAN_ODDS = -110
DEFAULT_DECIMAL_ODDS = 1.91
BREAKEVEN_WIN_RATE = 52.38
TAIWAN_LOTTERY_DECIMAL_ODDS = 1.75

# Taiwan-time daily auto-sync & two-stage odds schedule (18:00 early analysis + 23:00 final lock)
EARLY_ODDS_CAPTURE_TW_TIME = '18:00'
ODDS_CAPTURE_TW_TIME = '23:00'
ODDS_CAPTURE_SLOTS_TW = ('18:00', '23:00')
SCHEDULE_TW_TIMES = ('07:30', '12:30', '18:00', '23:00')
