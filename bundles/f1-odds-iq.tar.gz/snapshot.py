#!/usr/bin/env python3
"""Compiles <2ms cached JSON snapshot for F1 運彩智庫 SPA & static GitHub Pages export."""
from __future__ import annotations

import datetime as dt
import json
import os
import sqlite3
from typing import Any

import config
import db
import teams


def _streak_count(seq: list[str], target: str) -> int:
  n = 0
  for x in reversed(seq):
    if x == target:
      n += 1
    else:
      break
  return n


def build_and_save_snapshot(conn: sqlite3.Connection) -> dict[str, Any]:
  now_tw = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S')
  evo = db.get_state(conn, 'evolution_summary') or {}
  ai_coach = db.get_state(conn, 'latest_ai_coach') or None
  ou_preds = evo.get('ou_predictions') or {}
  radars = evo.get('outright_radars') or {}

  race_rows = [dict(r) for r in conn.execute('SELECT * FROM races ORDER BY round ASC').fetchall()]
  res_rows = [dict(r) for r in conn.execute('SELECT * FROM race_results ORDER BY round ASC, position ASC').fetchall()]
  qual_rows = [dict(r) for r in conn.execute('SELECT * FROM qual_results ORDER BY round ASC, position ASC').fetchall()]
  h2h_rows = [dict(r) for r in conn.execute('SELECT * FROM h2h_matchups ORDER BY round ASC, matchup_id ASC').fetchall()]

  qual_by_rk: dict[tuple[int, str], dict[str, Any]] = {
      (int(q['round']), q['driver_code']): q for q in qual_rows
  }

  # Build per-round H2H list
  h2h_by_round: dict[int, list[dict[str, Any]]] = {}
  drv_h2h_rec: dict[str, dict[str, int]] = {}
  team_h2h_seq: dict[str, list[str]] = {ab: [] for ab in teams.CONSTRUCTORS}

  for m in h2h_rows:
    rnd = int(m['round'])
    da, db_c = m['driver_a'], m['driver_b']
    ta, tb = m['team_a'], m['team_b']
    ia = teams.driver_info(da, team_abbr=ta)
    ib = teams.driver_info(db_c, team_abbr=tb)
    m_obj = {
        'matchup_id': m['matchup_id'],
        'round': rnd,
        'pair_type': m['pair_type'],
        'label_zh': m['label_zh'],
        'driver_a': da,
        'driver_a_zh': ia['zh'],
        'team_a': ta,
        'driver_b': db_c,
        'driver_b_zh': ib['zh'],
        'team_b': tb,
        'open_odds_a': m['open_odds_a'],
        'open_odds_b': m['open_odds_b'],
        'close_odds_a': m['close_odds_a'],
        'close_odds_b': m['close_odds_b'],
        'market_prob_a': m['market_prob_a'],
        'model_prob_a': m['model_prob_a'],
        'fair_odds_a': m['fair_odds_a'],
        'fair_odds_b': m['fair_odds_b'],
        'pick_side': m['pick_side'],
        'pick_driver': m['pick_driver'],
        'pick_driver_zh': ia['zh'] if m['pick_side'] == 'A' else ib['zh'],
        'tier': m['tier'],
        'edge_pct': m['edge_pct'],
        'kelly_units': m['kelly_units'],
        'factors': json.loads(m['factors_json'] or '{}'),
        'rationale_zh': m['rationale_zh'] or '',
        'pos_a': m['pos_a'],
        'pos_b': m['pos_b'],
        'result': m['result'],
        'error_tag': m['error_tag'] or '',
        'postmortem_zh': m['postmortem_zh'] or '',
    }
    h2h_by_round.setdefault(rnd, []).append(m_obj)

    if m['pos_a'] is not None and m['pos_b'] is not None:
      pa, pb = int(m['pos_a']), int(m['pos_b'])
      drv_h2h_rec.setdefault(da, {'w': 0, 'l': 0})
      drv_h2h_rec.setdefault(db_c, {'w': 0, 'l': 0})
      if pa < pb:
        drv_h2h_rec[da]['w'] += 1
        drv_h2h_rec[db_c]['l'] += 1
        if ta != tb:
          team_h2h_seq.setdefault(ta, []).append('W')
          team_h2h_seq.setdefault(tb, []).append('L')
      else:
        drv_h2h_rec[db_c]['w'] += 1
        drv_h2h_rec[da]['l'] += 1
        if ta != tb:
          team_h2h_seq.setdefault(tb, []).append('W')
          team_h2h_seq.setdefault(ta, []).append('L')

  # Build per-round race_telemetries (compact array rows for modal & Team Hub)
  # cols: [0:code, 1:zh, 2:en, 3:num, 4:team, 5:grid, 6:pos, 7:pos_text, 8:gain,
  #        9:points, 10:sprint_pts, 11:laps, 12:time_str, 13:classified, 14:fl_rank, 15:fl_time, 16:q_best]
  race_telemetries: dict[str, list[list[Any]]] = {}
  drv_agg: dict[str, dict[str, Any]] = {}
  team_round_pts: dict[str, list[dict[str, Any]]] = {ab: [] for ab in teams.CONSTRUCTORS}

  res_by_rnd: dict[int, list[dict[str, Any]]] = {}
  for rr in res_rows:
    res_by_rnd.setdefault(int(rr['round']), []).append(rr)

  for rnd, rlist in sorted(res_by_rnd.items()):
    gid = f'R{rnd:02d}'
    t_rows = []
    per_team_this_rnd: dict[str, dict[str, Any]] = {}
    for rr in rlist:
      dc = rr['driver_code']
      tab = rr['team_abbr']
      d_inf = teams.driver_info(dc, team_abbr=tab, num=rr['number'] or '')
      grid = int(rr['grid'] or 0)
      pos = int(rr['position'] or 99)
      gain = (grid - pos) if (grid > 0 and rr['classified']) else 0
      pts = float(rr['points'] or 0.0)
      s_pts = float(rr['sprint_points'] or 0.0)
      q_row = qual_by_rk.get((rnd, dc)) or {}
      q_best = q_row.get('q3') or q_row.get('q2') or q_row.get('q1') or ''

      t_rows.append([
          dc, d_inf['zh'], rr['driver_en'] or d_inf['en'], d_inf['num'], tab,
          grid, pos, rr['pos_text'] or str(pos), gain,
          pts, s_pts, int(rr['laps'] or 0), rr['time_str'] or rr['status'] or '',
          int(rr['classified'] or 0), int(rr['fastest_lap_rank'] or 99),
          rr['fastest_lap_time'] or '', q_best,
      ])

      st = drv_agg.setdefault(dc, {
          'pid': dc, 'code': dc, 'zh': d_inf['zh'], 'en': rr['driver_en'] or d_inf['en'],
          'name': f"{d_inf['zh']} {d_inf['en']}", 'num': d_inf['num'], 'team': tab,
          'country': d_inf['country'], 'headshot': d_inf['headshot'],
          'gp': 0, 'pts': 0.0, 'race_pts': 0.0, 'sprint_pts': 0.0,
          'wins': 0, 'podiums': 0, 'poles': 0, 'top10': 0, 'fl': 0, 'dnfs': 0,
          'grid_sum': 0.0, 'grid_n': 0, 'fin_sum': 0.0, 'fin_n': 0, 'gain_sum': 0.0,
      })
      st['team'] = tab
      st['headshot'] = teams.driver_info(dc, team_abbr=tab)['headshot']
      st['gp'] += 1
      st['race_pts'] += pts
      st['sprint_pts'] += s_pts
      st['pts'] += (pts + s_pts)
      if pos == 1:
        st['wins'] += 1
      if pos <= 3:
        st['podiums'] += 1
      if pos <= 10:
        st['top10'] += 1
      if grid == 1 or q_row.get('position') == 1:
        st['poles'] += 1
      if int(rr['fastest_lap_rank'] or 99) == 1:
        st['fl'] += 1
      if not rr['classified']:
        st['dnfs'] += 1
      if grid > 0:
        st['grid_sum'] += grid
        st['grid_n'] += 1
      if rr['classified']:
        st['fin_sum'] += pos
        st['fin_n'] += 1
        st['gain_sum'] += gain

      pt = per_team_this_rnd.setdefault(tab, {
          'round': rnd, 'pts': 0.0, 'best_pos': 99, 'both_pts': 0, 'podium': 0, 'dnfs': 0, 'drivers': [],
      })
      pt['pts'] += (pts + s_pts)
      pt['best_pos'] = min(pt['best_pos'], pos)
      if not rr['classified']:
        pt['dnfs'] += 1
      pt['drivers'].append({'code': dc, 'zh': d_inf['zh'], 'grid': grid, 'pos': pos, 'pos_text': rr['pos_text'], 'pts': pts + s_pts})

    for tab, pt in per_team_this_rnd.items():
      pt['podium'] = 1 if pt['best_pos'] <= 3 else 0
      pt['both_pts'] = 1 if sum(1 for d in pt['drivers'] if d['pos'] <= 10) >= 2 else 0
      team_round_pts.setdefault(tab, []).append(pt)

    race_telemetries[gid] = t_rows

  # Finalize driver_stats sorted by Championship points
  driver_stats = []
  for dc, st in drv_agg.items():
    gp = max(1, st['gp'])
    hrec = drv_h2h_rec.get(dc, {'w': 0, 'l': 0})
    htot = hrec['w'] + hrec['l']
    driver_stats.append({
        'pid': dc,
        'code': dc,
        'zh': st['zh'],
        'en': st['en'],
        'name': f"{st['zh']} ({dc})",
        'full_name': f"{st['zh']} · {st['en']}",
        'num': st['num'],
        'team': st['team'],
        'country': st['country'],
        'headshot': st['headshot'],
        'gp': st['gp'],
        'pts': round(st['pts'], 1),
        'pts_pg': round(st['pts'] / gp, 2),
        'race_pts': round(st['race_pts'], 1),
        'sprint_pts': round(st['sprint_pts'], 1),
        'wins': st['wins'],
        'podiums': st['podiums'],
        'poles': st['poles'],
        'top10': st['top10'],
        'fl': st['fl'],
        'dnfs': st['dnfs'],
        'clean_pct': round((st['gp'] - st['dnfs']) / gp * 100, 1),
        'avg_grid': round(st['grid_sum'] / max(1, st['grid_n']), 2),
        'avg_finish': round(st['fin_sum'] / max(1, st['fin_n']), 2),
        'avg_gain': round(st['gain_sum'] / max(1, st['fin_n']), 2),
        'h2h_w': hrec['w'],
        'h2h_l': hrec['l'],
        'h2h_pct': round(hrec['w'] / htot * 100, 1) if htot else 50.0,
    })
  driver_stats.sort(key=lambda x: (-x['pts'], -x['wins'], x['avg_finish']))
  for idx, d in enumerate(driver_stats, 1):
    d['rank'] = idx

  # Finalize Constructor list
  teams_out = []
  for ab in teams.CONSTRUCTORS:
    tinf = teams.team_info(ab)
    rlogs = team_round_pts.get(ab) or []
    t_drvs = [d for d in driver_stats if d['team'] == ab]
    pts = round(sum(r['pts'] for r in rlogs), 1)
    wins = sum(d['wins'] for d in t_drvs)
    podiums = sum(d['podiums'] for d in t_drvs)
    poles = sum(d['poles'] for d in t_drvs)
    dnfs = sum(d['dnfs'] for d in t_drvs)
    gp_cnt = len(rlogs)
    pts_seq = ['W' if r['pts'] > 0 else 'L' for r in rlogs]
    pod_seq = ['W' if r['podium'] else 'L' for r in rlogs]
    dbl_seq = ['W' if r['both_pts'] else 'L' for r in rlogs]
    hseq = team_h2h_seq.get(ab) or []
    hw = sum(1 for x in hseq if x == 'W')
    hl = sum(1 for x in hseq if x == 'L')
    teams_out.append({
        **tinf,
        'gp': gp_cnt,
        'pts': pts,
        'pts_pg': round(pts / max(1, gp_cnt), 2),
        'wins': wins,
        'podiums': podiums,
        'poles': poles,
        'dnfs': dnfs,
        'h2h_w': hw,
        'h2h_l': hl,
        'h2h_pct': round(hw / max(1, hw + hl) * 100, 1),
        'pts_streak': _streak_count(pts_seq, 'W'),
        'pod_streak': _streak_count(pod_seq, 'W'),
        'dbl_streak': _streak_count(dbl_seq, 'W'),
        'cold_streak': _streak_count(pts_seq, 'L'),
        'h2h_win_streak': _streak_count(hseq, 'W'),
        'h2h_loss_streak': _streak_count(hseq, 'L'),
        'last10_pts': pts_seq[-10:],
        'last10_pod': pod_seq[-10:],
        'last10_dbl': dbl_seq[-10:],
        'round_logs': rlogs,
        'drivers': [{'code': d['code'], 'zh': d['zh'], 'num': d['num'], 'pts': d['pts'], 'rank': d['rank']} for d in t_drvs],
    })
  teams_out.sort(key=lambda x: (-x['pts'], -x['wins'], x['abbr']))
  for idx, t in enumerate(teams_out, 1):
    t['rank'] = idx

  # Assemble races list
  races_out = []
  default_round = 1
  found_next = False
  for rc in race_rows:
    rnd = int(rc['round'])
    gid = f'R{rnd:02d}'
    c_prof = teams.circuit_info(rc['circuit_id'], rc['race_name'])
    if rc['status'] != 'FINAL' and not found_next:
      default_round = rnd
      found_next = True
    elif rc['status'] == 'FINAL' and not found_next:
      default_round = rnd

    hlist = h2h_by_round.get(rnd) or []
    w_cnt = sum(1 for m in hlist if m['result'] == 'WIN')
    l_cnt = sum(1 for m in hlist if m['result'] == 'LOSS')
    sw_cnt = sum(1 for m in hlist if m['tier'] == 'STRONG' and m['result'] == 'WIN')
    sl_cnt = sum(1 for m in hlist if m['tier'] == 'STRONG' and m['result'] == 'LOSS')

    podium_top3 = []
    for row in (race_telemetries.get(gid) or [])[:3]:
      podium_top3.append({'pos': row[6], 'code': row[0], 'zh': row[1], 'team': row[4], 'time': row[12]})

    races_out.append({
        'game_id': gid,
        'round': rnd,
        'race_name': rc['race_name'],
        'gp_zh': rc['gp_zh'],
        'circuit_id': rc['circuit_id'],
        'circuit_zh': rc['circuit_zh'],
        'country': rc['country'],
        'locality': rc['locality'],
        'race_tw': rc['race_tw'],
        'tw_date': rc['tw_date'],
        'qual_tw': rc['qual_tw'] or '',
        'sprint_tw': rc['sprint_tw'] or '',
        'has_sprint': bool(rc['has_sprint']),
        'status': rc['status'],
        'circuit_profile': c_prof,
        'pole_driver': rc['pole_driver'] or '',
        'pole_zh': teams.driver_info(rc['pole_driver'])['zh'] if rc['pole_driver'] else '',
        'winner_driver': rc['winner_driver'] or '',
        'winner_zh': teams.driver_info(rc['winner_driver'])['zh'] if rc['winner_driver'] else '',
        'fastest_driver': rc['fastest_driver'] or '',
        'fastest_zh': teams.driver_info(rc['fastest_driver'])['zh'] if rc['fastest_driver'] else '',
        'classified_count': rc['classified_count'],
        'dnf_count': rc['dnf_count'],
        'finishers_line': rc['finishers_line'],
        'ou_result': rc['ou_result'] or '',
        'ou_pred': ou_preds.get(str(rnd)) or {},
        'outright_radar': radars.get(str(rnd)) or [],
        'sessions': json.loads(rc['sessions_json'] or '[]'),
        'podium': podium_top3,
        'h2h': hlist,
        'h2h_w': w_cnt,
        'h2h_l': l_cnt,
        'strong_w': sw_cnt,
        'strong_l': sl_cnt,
    })

  tech_watch = [dict(r) for r in conn.execute('SELECT * FROM tech_watch ORDER BY grid_risk_pct DESC').fetchall()]
  news = [dict(r) for r in conn.execute('SELECT * FROM news_items ORDER BY published_tw DESC LIMIT 60').fetchall()]

  done_races = [r for r in races_out if r['status'] == 'FINAL']
  next_race_obj = next((r for r in races_out if r['round'] == default_round), races_out[-1] if races_out else {})

  snap = {
      'meta': {
          'tool': config.TOOL_TITLE,
          'season': config.SEASON_YEAR,
          'updated_at': now_tw,
          'model_version': evo.get('model_version') or 'v2.0',
          'default_round': default_round,
          'completed_rounds': len(done_races),
          'total_rounds': len(races_out),
          'next_gp_zh': next_race_obj.get('gp_zh') or '',
          'next_race_tw': next_race_obj.get('race_tw') or '',
      },
      'kpi': {
          'strong_w': evo.get('strong_w', 0),
          'strong_l': evo.get('strong_l', 0),
          'strong_win_rate': evo.get('strong_win_rate', 0.0),
          'all_w': evo.get('all_w', 0),
          'all_l': evo.get('all_l', 0),
          'all_win_rate': evo.get('all_win_rate', 0.0),
          'baseline_w': evo.get('baseline_w', 0),
          'baseline_l': evo.get('baseline_l', 0),
          'baseline_win_rate': evo.get('baseline_win_rate', 0.0),
          'ou_w': evo.get('ou_w', 0),
          'ou_l': evo.get('ou_l', 0),
          'ou_win_rate': evo.get('ou_win_rate', 0.0),
          'roi_pct': evo.get('roi_pct', 0.0),
          'breakeven_pct': config.BREAKEVEN_WIN_RATE,
      },
      'races': races_out,
      'race_telemetries': race_telemetries,
      'teams': teams_out,
      'driver_stats': driver_stats,
      'tech_watch': tech_watch,
      'news': news,
      'evolution': {
          'factors': evo.get('factors') or [],
          'error_breakdown': evo.get('error_breakdown') or [],
          'curve': evo.get('curve') or [],
          'round_log': evo.get('round_log') or [],
      },
      'ai_coach': ai_coach,
  }

  os.makedirs(config.DATA_DIR, exist_ok=True)
  tmp = config.SNAPSHOT_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(snap, f, ensure_ascii=False, separators=(',', ':'))
  os.replace(tmp, config.SNAPSHOT_JSON)
  return snap


def load_cached_snapshot() -> dict[str, Any]:
  if os.path.isfile(config.SNAPSHOT_JSON):
    try:
      with open(config.SNAPSHOT_JSON, encoding='utf-8') as f:
        return json.load(f)
    except (OSError, ValueError):
      pass
  conn = db.connect()
  try:
    return build_and_save_snapshot(conn)
  finally:
    conn.close()
