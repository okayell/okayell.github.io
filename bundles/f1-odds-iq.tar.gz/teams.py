#!/usr/bin/env python3
"""2026 Formula 1 Constructors, Drivers & Circuit DNA Profiles (Traditional Chinese)."""
from __future__ import annotations

from typing import Any
import urllib.parse


def _badge_svg_data_uri(code: str, bg: str, fg: str = '#ffffff') -> str:
  svg = (
      f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'>"
      f"<rect x='2' y='2' width='60' height='60' rx='14' fill='{bg}' stroke='#e2e8f0' stroke-width='2'/>"
      f"<path d='M8 46 L56 46' stroke='rgba(255,255,255,0.35)' stroke-width='3'/>"
      f"<text x='32' y='37' text-anchor='middle' font-family='Arial,sans-serif' "
      f"font-weight='900' font-size='19' fill='{fg}'>{code}</text></svg>"
  )
  return 'data:image/svg+xml;utf8,' + urllib.parse.quote(svg)


CONSTRUCTORS: dict[str, dict[str, Any]] = {
    'MER': {
        'abbr': 'MER', 'cid': 'mercedes', 'zh': '賓士車隊', 'en': 'Mercedes',
        'full_en': 'Mercedes-AMG PETRONAS F1 Team', 'pu': 'Mercedes', 'tier': '爭冠集團',
        'color': '#00a19c', 'strength_tags': ['動力單元效能頂尖', '高速與均衡賽道強勢', '雙車手排位穩定'],
    },
    'FER': {
        'abbr': 'FER', 'cid': 'ferrari', 'zh': '法拉利車隊', 'en': 'Ferrari',
        'full_en': 'Scuderia Ferrari HP', 'pu': 'Ferrari', 'tier': '爭冠集團',
        'color': '#dc0000', 'strength_tags': ['慢速彎機械抓地力強', '輪胎暖胎快、街道賽優勢', '雙世界冠軍級陣容'],
    },
    'RBR': {
        'abbr': 'RBR', 'cid': 'red_bull', 'zh': '紅牛車隊', 'en': 'Red Bull',
        'full_en': 'Oracle Red Bull Racing', 'pu': 'Red Bull Ford', 'tier': '爭冠集團',
        'color': '#1e41ff', 'strength_tags': ['空力效率極高', '高速彎穩定、進站策略犀利', '一號車手單圈極限高'],
    },
    'MCL': {
        'abbr': 'MCL', 'cid': 'mclaren', 'zh': '麥拉倫車隊', 'en': 'McLaren',
        'full_en': 'McLaren Formula 1 Team', 'pu': 'Mercedes', 'tier': '爭冠集團',
        'color': '#ff8000', 'strength_tags': ['中高速彎下壓力紮實', '正賽長距離保胎頂尖', '車手積分咬合度高'],
    },
    'RB': {
        'abbr': 'RB', 'cid': 'rb', 'zh': '紅牛二隊', 'en': 'Racing Bulls',
        'full_en': 'Visa Cash App Racing Bulls', 'pu': 'Red Bull Ford', 'tier': '中游領先',
        'color': '#2b4562', 'strength_tags': ['中游排位Q3常客', '街道與中下壓力表現亮眼', '新秀衝勁強'],
    },
    'ALP': {
        'abbr': 'ALP', 'cid': 'alpine', 'zh': '阿爾派車隊', 'en': 'Alpine',
        'full_en': 'BWT Alpine F1 Team', 'pu': 'Mercedes', 'tier': '中游集團',
        'color': '#0090ff', 'strength_tags': ['直線尾速優異', '換裝客製動力後妥善率提升', '混戰搶分能力強'],
    },
    'HAA': {
        'abbr': 'HAA', 'cid': 'haas', 'zh': '哈斯車隊', 'en': 'Haas',
        'full_en': 'MoneyGram Haas F1 Team', 'pu': 'Ferrari', 'tier': '中游集團',
        'color': '#475569', 'strength_tags': ['直線煞車穩定', '低阻高速賽道具黑馬潛力', '正賽策略偏保守穩健'],
    },
    'AUD': {
        'abbr': 'AUD', 'cid': 'audi', 'zh': '奧迪車隊', 'en': 'Audi',
        'full_en': 'Audi F1 Team', 'pu': 'Audi', 'tier': '中游集團',
        'color': '#b5121b', 'strength_tags': ['廠隊自研動力持續升級', '老將排位搾取單圈強', '濕地與混戰具韌性'],
    },
    'WIL': {
        'abbr': 'WIL', 'cid': 'williams', 'zh': '威廉斯車隊', 'en': 'Williams',
        'full_en': 'Atlassian Williams Racing', 'pu': 'Mercedes', 'tier': '中下游集團',
        'color': '#005aff', 'strength_tags': ['低風阻直線極速快', '蒙札／拉斯維加斯等高速站吃香', '雙車手經驗豐富'],
    },
    'AMR': {
        'abbr': 'AMR', 'cid': 'aston_martin', 'zh': '奧斯頓馬丁', 'en': 'Aston Martin',
        'full_en': 'Aston Martin Aramco F1 Team', 'pu': 'Honda', 'tier': '中下游集團',
        'color': '#006f62', 'strength_tags': ['新動力單元磨合期', '頭號老將正賽防守與起跑強', '高下壓力彎道升級中'],
    },
    'CAD': {
        'abbr': 'CAD', 'cid': 'cadillac', 'zh': '凱迪拉克車隊', 'en': 'Cadillac',
        'full_en': 'Cadillac Formula 1 Team', 'pu': 'Ferrari', 'tier': '新軍車隊',
        'color': '#1d3557', 'strength_tags': ['2026全新第11支車隊', '雙資深老將穩定完賽累積里程', '長距離抗耗損導向'],
    },
}

CID_TO_ABBR: dict[str, str] = {v['cid']: k for k, v in CONSTRUCTORS.items()}
CID_TO_ABBR.update({
    'sauber': 'AUD', 'kick_sauber': 'AUD', 'alphatauri': 'RB', 'racing_bulls': 'RB',
})

DRIVERS_ZH: dict[str, dict[str, Any]] = {
    'ANT': {'zh': '安東內利', 'en': 'Kimi Antonelli', 'num': '12', 'team': 'MER', 'country': '義大利'},
    'RUS': {'zh': '羅素', 'en': 'George Russell', 'num': '63', 'team': 'MER', 'country': '英國'},
    'HAM': {'zh': '漢米爾頓', 'en': 'Lewis Hamilton', 'num': '44', 'team': 'FER', 'country': '英國'},
    'LEC': {'zh': '勒克萊爾', 'en': 'Charles Leclerc', 'num': '16', 'team': 'FER', 'country': '摩納哥'},
    'VER': {'zh': '維斯塔潘', 'en': 'Max Verstappen', 'num': '1', 'team': 'RBR', 'country': '荷蘭'},
    'HAD': {'zh': '哈賈爾', 'en': 'Isack Hadjar', 'num': '6', 'team': 'RBR', 'country': '法國'},
    'NOR': {'zh': '諾里斯', 'en': 'Lando Norris', 'num': '4', 'team': 'MCL', 'country': '英國'},
    'PIA': {'zh': '皮亞斯特里', 'en': 'Oscar Piastri', 'num': '81', 'team': 'MCL', 'country': '澳洲'},
    'LAW': {'zh': '勞森', 'en': 'Liam Lawson', 'num': '30', 'team': 'RB', 'country': '紐西蘭'},
    'LIN': {'zh': '林德布拉德', 'en': 'Arvid Lindblad', 'num': '45', 'team': 'RB', 'country': '英國'},
    'TSU': {'zh': '角田裕毅', 'en': 'Yuki Tsunoda', 'num': '22', 'team': 'RB', 'country': '日本'},
    'GAS': {'zh': '蓋斯利', 'en': 'Pierre Gasly', 'num': '10', 'team': 'ALP', 'country': '法國'},
    'COL': {'zh': '科拉平托', 'en': 'Franco Colapinto', 'num': '43', 'team': 'ALP', 'country': '阿根廷'},
    'BEA': {'zh': '貝爾曼', 'en': 'Oliver Bearman', 'num': '87', 'team': 'HAA', 'country': '英國'},
    'OCO': {'zh': '奧康', 'en': 'Esteban Ocon', 'num': '31', 'team': 'HAA', 'country': '法國'},
    'HUL': {'zh': '霍肯伯格', 'en': 'Nico Hülkenberg', 'num': '27', 'team': 'AUD', 'country': '德國'},
    'BOR': {'zh': '博托萊托', 'en': 'Gabriel Bortoleto', 'num': '5', 'team': 'AUD', 'country': '巴西'},
    'SAI': {'zh': '賽恩斯', 'en': 'Carlos Sainz', 'num': '55', 'team': 'WIL', 'country': '西班牙'},
    'ALB': {'zh': '阿爾本', 'en': 'Alexander Albon', 'num': '23', 'team': 'WIL', 'country': '泰國'},
    'ALO': {'zh': '阿隆索', 'en': 'Fernando Alonso', 'num': '14', 'team': 'AMR', 'country': '西班牙'},
    'STR': {'zh': '斯托爾', 'en': 'Lance Stroll', 'num': '18', 'team': 'AMR', 'country': '加拿大'},
    'BOT': {'zh': '博塔斯', 'en': 'Valtteri Bottas', 'num': '77', 'team': 'CAD', 'country': '芬蘭'},
    'PER': {'zh': '佩雷茲', 'en': 'Sergio Pérez', 'num': '11', 'team': 'CAD', 'country': '墨西哥'},
}

CIRCUIT_PROFILES: dict[str, dict[str, Any]] = {
    'albert_park': {'gp_zh': '澳洲大獎賽', 'circuit_zh': '墨爾本阿爾伯特公園賽道', 'type': 'STREET_FAST', 'type_zh': '半街道高速賽道', 'overtake': 3, 'sc_rate': 0.68, 'finishers_line': 17.5, 'note': '路緣石與近牆容錯率低，安全車機率偏高'},
    'shanghai': {'gp_zh': '中國大獎賽', 'circuit_zh': '上海國際賽車場', 'type': 'BALANCED', 'type_zh': '長直線＋前輪磨耗均衡賽道', 'overtake': 4, 'sc_rate': 0.48, 'finishers_line': 18.5, 'note': '1.2km後大直線利於主動空力超車，前輪熱衰退關鍵'},
    'suzuka': {'gp_zh': '日本大獎賽', 'circuit_zh': '鈴鹿國際賽道', 'type': 'HIGH_DF', 'type_zh': '高速高下壓力技術賽道', 'overtake': 2, 'sc_rate': 0.52, 'finishers_line': 18.5, 'note': 'S彎吃重空力平衡與車手單圈極限，排位權重高'},
    'miami': {'gp_zh': '邁阿密大獎賽', 'circuit_zh': '邁阿密國際賽道', 'type': 'STREET_FAST', 'type_zh': '高溫街道複合賽道', 'overtake': 3, 'sc_rate': 0.62, 'finishers_line': 18.5, 'note': '路面溫度高且慢速彎接長直線，重視牽引力與尾速'},
    'villeneuve': {'gp_zh': '加拿大大獎賽', 'circuit_zh': '吉爾維倫紐夫賽道', 'type': 'POWER', 'type_zh': '重煞車減速彎＋動力賽道', 'overtake': 4, 'sc_rate': 0.72, 'finishers_line': 17.5, 'note': '冠軍牆與吃路緣石設定，安全車與煞車耗損高'},
    'monaco': {'gp_zh': '摩納哥大獎賽', 'circuit_zh': '蒙地卡羅市街賽道', 'type': 'STREET_TIGHT', 'type_zh': '極致窄街高下壓力賽道', 'overtake': 1, 'sc_rate': 0.65, 'finishers_line': 17.5, 'note': '排位賽幾乎決定80%完賽順位，進站Undercut與紅旗主導'},
    'catalunya': {'gp_zh': '巴塞隆納大獎賽', 'circuit_zh': '加泰隆尼亞賽道', 'type': 'HIGH_DF', 'type_zh': '空力基準中高下壓力賽道', 'overtake': 3, 'sc_rate': 0.35, 'finishers_line': 19.5, 'note': '純粹考驗賽車空力效率與長距離輪胎管理，退賽率低'},
    'red_bull_ring': {'gp_zh': '奧地利大獎賽', 'circuit_zh': '紅牛環賽道', 'type': 'POWER', 'type_zh': '短圈數高海拔動力賽道', 'overtake': 4, 'sc_rate': 0.50, 'finishers_line': 18.5, 'note': '單圈極短差距微小，三段直線纏鬥頻繁易生擦撞'},
    'silverstone': {'gp_zh': '英國大獎賽', 'circuit_zh': '銀石賽道', 'type': 'HIGH_DF', 'type_zh': '超高速彎高負載賽道', 'overtake': 4, 'sc_rate': 0.58, 'finishers_line': 18.5, 'note': 'Maggotts-Becketts高速彎群考驗底盤穩定與天候應變'},
    'spa': {'gp_zh': '比利時大獎賽', 'circuit_zh': '斯帕-弗朗科爾尚賽道', 'type': 'POWER', 'type_zh': '超長距離高速空力賽道', 'overtake': 5, 'sc_rate': 0.60, 'finishers_line': 18.5, 'note': 'Kemmel長直線極利超車，微氣候多變、排位罰退可追擊'},
    'hungaroring': {'gp_zh': '匈牙利大獎賽', 'circuit_zh': '亨格羅林賽道', 'type': 'HIGH_DF', 'type_zh': '連續彎道高下壓力賽道', 'overtake': 2, 'sc_rate': 0.40, 'finishers_line': 19.5, 'note': '外號無牆摩納哥，超車不易，排位與起跑卡位極關鍵'},
    'zandvoort': {'gp_zh': '荷蘭大獎賽', 'circuit_zh': '贊德沃特傾斜彎賽道', 'type': 'HIGH_DF', 'type_zh': '窄幅高傾角高下壓力賽道', 'overtake': 2, 'sc_rate': 0.55, 'finishers_line': 18.5, 'note': '海風與砂石緩衝區容錯小，排位領先優勢明顯'},
    'monza': {'gp_zh': '義大利大獎賽', 'circuit_zh': '蒙札速度殿堂賽道', 'type': 'POWER', 'type_zh': '極低風阻超高速殿堂', 'overtake': 4, 'sc_rate': 0.52, 'finishers_line': 18.5, 'note': '全季最低下壓力套件，第一減速彎起跑易擦撞'},
    'madring': {'gp_zh': '西班牙馬德里大獎賽', 'circuit_zh': '馬德里市街環形賽道', 'type': 'STREET_FAST', 'type_zh': '2026新世代混合街道賽道', 'overtake': 3, 'sc_rate': 0.64, 'finishers_line': 17.5, 'note': '新賽道抓地力演進劇烈，車手適應力與模擬器準備成勝負手'},
    'baku': {'gp_zh': '亞塞拜然大獎賽', 'circuit_zh': '巴庫市街賽道', 'type': 'STREET_FAST', 'type_zh': '城堡窄巷＋2.2km極速街道', 'overtake': 4, 'sc_rate': 0.78, 'finishers_line': 16.5, 'note': '全季混亂度與安全車最高分站之一，尾流超車極強'},
    'sepang': {'gp_zh': '馬來西亞雪邦大獎賽', 'circuit_zh': '雪邦國際賽道', 'type': 'BALANCED', 'type_zh': '高濕熱雙長直線技術賽道', 'overtake': 4, 'sc_rate': 0.56, 'finishers_line': 17.5, 'note': '酷熱考驗動力單元散熱與車手體能，午後雷陣雨變數大'},
    'marina_bay': {'gp_zh': '新加坡大獎賽', 'circuit_zh': '濱海灣夜間市街賽道', 'type': 'STREET_TIGHT', 'type_zh': '高溫高濕夜間街道賽道', 'overtake': 2, 'sc_rate': 0.82, 'finishers_line': 17.5, 'note': '全季體能與專注度最嚴苛夜戰，安全車出現率極高'},
    'americas': {'gp_zh': '美國大獎賽', 'circuit_zh': '奧斯汀美洲賽道 (COTA)', 'type': 'BALANCED', 'type_zh': '高低落差綜合型技術賽道', 'overtake': 4, 'sc_rate': 0.50, 'finishers_line': 18.5, 'note': 'T1上坡寬彎與後大直線超車點多，後輪熱磨耗顯著'},
    'rodriguez': {'gp_zh': '墨西哥城大獎賽', 'circuit_zh': '羅德里奎茲兄弟高海拔賽道', 'type': 'HIGH_ALT', 'type_zh': '2,285m高海拔稀薄空氣賽道', 'overtake': 3, 'sc_rate': 0.58, 'finishers_line': 17.5, 'note': '空氣密度低22%，最大下壓力仍似蒙札滑溜，渦輪與煞車散熱嚴苛'},
    'interlagos': {'gp_zh': '聖保羅大獎賽', 'circuit_zh': '英特拉格斯賽道', 'type': 'BALANCED', 'type_zh': '逆時針起伏短圈多變天候賽道', 'overtake': 5, 'sc_rate': 0.68, 'finishers_line': 17.5, 'note': '超車極為容易且常遇驟雨，排位落後強車仍具極強追擊力'},
    'vegas': {'gp_zh': '拉斯維加斯大獎賽', 'circuit_zh': '拉斯維加斯大道夜間街道', 'type': 'POWER', 'type_zh': '低溫夜間超長直線街道賽道', 'overtake': 5, 'sc_rate': 0.65, 'finishers_line': 17.5, 'note': '低溫路面易顆粒化(Graining)，賭城大道尾速對決超車極多'},
    'losail': {'gp_zh': '卡達大獎賽', 'circuit_zh': '盧賽爾國際賽道', 'type': 'HIGH_DF', 'type_zh': '連續中高速彎高橫向G力賽道', 'overtake': 3, 'sc_rate': 0.46, 'finishers_line': 18.5, 'note': '輪胎結構負荷極大，高速彎空力下壓力決定長距離配速'},
    'yas_marina': {'gp_zh': '阿布達比大獎賽', 'circuit_zh': '亞斯碼頭黃昏收官賽道', 'type': 'BALANCED', 'type_zh': '雙長直線＋飯店區慢彎收官站', 'overtake': 3, 'sc_rate': 0.45, 'finishers_line': 18.5, 'note': '日落溫降改變抓地力，季末車隊積分排名焦點戰'},
}


def constructor_abbr(cid_or_abbr: str) -> str:
  raw = (cid_or_abbr or '').strip()
  up = raw.upper()
  if up in CONSTRUCTORS:
    return up
  low = raw.lower()
  if low in CID_TO_ABBR:
    return CID_TO_ABBR[low]
  for k, v in CONSTRUCTORS.items():
    if low in v['en'].lower() or low in v['full_en'].lower():
      return k
  return up[:3] or 'F1'


def team_info(abbr_or_cid: str) -> dict[str, Any]:
  ab = constructor_abbr(abbr_or_cid)
  base = dict(CONSTRUCTORS.get(ab) or {
      'abbr': ab, 'cid': ab.lower(), 'zh': ab, 'en': ab, 'full_en': ab,
      'pu': 'F1 PU', 'tier': 'F1 車隊', 'color': '#334155', 'strength_tags': [],
  })
  base['logo'] = _badge_svg_data_uri(ab, base['color'])
  return base


def driver_info(code: str, given: str = '', family: str = '', team_abbr: str = '', num: str = '') -> dict[str, Any]:
  c = (code or '').upper().strip() or (family[:3].upper() if family else 'DRV')
  d = dict(DRIVERS_ZH.get(c) or {})
  en = d.get('en') or f'{given} {family}'.strip() or c
  zh = d.get('zh') or family or en
  tm = team_abbr or d.get('team') or 'MER'
  tinfo = team_info(tm)
  return {
      'code': c,
      'zh': zh,
      'en': en,
      'name_display': f'{zh} ({c})',
      'num': num or d.get('num') or '',
      'team': tinfo['abbr'],
      'country': d.get('country') or '',
      'headshot': _badge_svg_data_uri(c, tinfo['color']),
  }


def circuit_info(circuit_id: str, fallback_name: str = '') -> dict[str, Any]:
  cid = (circuit_id or '').lower().strip()
  p = dict(CIRCUIT_PROFILES.get(cid) or {
      'gp_zh': fallback_name or cid,
      'circuit_zh': fallback_name or cid,
      'type': 'BALANCED',
      'type_zh': '綜合型大獎賽賽道',
      'overtake': 3,
      'sc_rate': 0.52,
      'finishers_line': 18.5,
      'note': '兼顧排位單圈速度與正賽輪胎管理',
  })
  p['circuit_id'] = cid
  return p
