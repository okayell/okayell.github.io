#!/usr/bin/env python3
"""Flock-guarded Data Sync, Walk-Forward Evolution & Snapshot Builder for F1 運彩智庫."""
from __future__ import annotations

import datetime as dt
import fcntl
import os
import threading
from typing import Any

import config
import db
import model_engine
import snapshot
from sources import f1_data
from sources import f1_news

_STATE_LOCK = threading.Lock()
_SYNC_STATE: dict[str, Any] = {
    'running': False,
    'step': 'idle',
    'last_sync_tw': '',
    'error': '',
}


def get_sync_state() -> dict[str, Any]:
  with _STATE_LOCK:
    return dict(_SYNC_STATE)


def _set_sync(**kw: Any) -> None:
  with _STATE_LOCK:
    _SYNC_STATE.update(kw)


def evening_cycle_date(now_tw: dt.datetime | None = None) -> str:
  cur = now_tw or dt.datetime.now(config.TZ_TW)
  return (cur - dt.timedelta(hours=5)).strftime('%Y-%m-%d')


def is_early_odds_captured(conn, tw_date: str) -> bool:
  return bool(db.get_state(conn, f'odds_early_{tw_date}', False))


def is_daily_odds_captured(conn, tw_date: str) -> bool:
  return bool(db.get_state(conn, f'odds_lock_{tw_date}', False))


def sync_all(
    full_backfill: bool = False,
    update_odds: bool = False,
    odds_stage: str = 'auto',
) -> dict[str, Any]:
  os.makedirs(config.DATA_DIR, exist_ok=True)
  lock_fd = open(config.SYNC_LOCK, 'w', encoding='utf-8')
  try:
    try:
      fcntl.flock(lock_fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
      return get_sync_state()

    _set_sync(running=True, step='抓取 2026 F1 賽程、排位與完賽遙測數據…', error='')
    conn = db.connect()
    try:
      stats_f1 = f1_data.sync_f1_season(conn)
      conn.commit()

      _set_sync(step='更新 FIA 技術罰退雷達與中英文 F1 新聞…')
      stats_news = f1_news.sync_news_and_tech_watch(conn)
      conn.commit()

      _set_sync(step='執行逐站 Walk-Forward 賽後檢討與因子權重進化…')
      evo = model_engine.run_walk_forward(conn)
      now_tw = dt.datetime.now(config.TZ_TW)
      if update_odds:
        stage = odds_stage
        if stage == 'auto':
          hm_now = now_tw.strftime('%H:%M')
          stage = 'final' if (hm_now >= '22:30' or hm_now < '05:00') else 'early'
        if stage == 'early':
          db.set_state(conn, f'odds_early_{now_tw.strftime("%Y-%m-%d")}', True, now_tw.strftime('%Y-%m-%d %H:%M:%S'))
        else:
          cyc = evening_cycle_date(now_tw)
          db.set_state(conn, f'odds_lock_{cyc}', True, now_tw.strftime('%Y-%m-%d %H:%M:%S'))
      conn.commit()

      _set_sync(step='編譯毫秒級全站快取 Snapshot…')
      snapshot.build_and_save_snapshot(conn)
      conn.commit()

      done_ts = now_tw.strftime('%Y-%m-%d %H:%M:%S')
      _set_sync(running=False, step='done', last_sync_tw=done_ts, error='')
      return {'ok': True, 'f1': stats_f1, 'news': stats_news, 'model': evo.get('model_version')}
    except Exception as e:  # pylint: disable=broad-except
      _set_sync(running=False, step='error', error=str(e))
      raise
    finally:
      conn.close()
  finally:
    try:
      fcntl.flock(lock_fd.fileno(), fcntl.LOCK_UN)
    except OSError:
      pass
    lock_fd.close()


if __name__ == '__main__':
  res = sync_all(full_backfill=True, update_odds=True)
  print('Sync complete:', res)
