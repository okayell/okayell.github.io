#!/usr/bin/env python3
"""SQLite WAL schema & helpers for F1 運彩智庫."""
from __future__ import annotations

import json
import os
import sqlite3
from typing import Any

import config

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS races (
  round INTEGER PRIMARY KEY,
  season INTEGER NOT NULL,
  event_id TEXT,
  race_name TEXT NOT NULL,
  gp_zh TEXT NOT NULL,
  circuit_id TEXT NOT NULL,
  circuit_zh TEXT NOT NULL,
  country TEXT,
  locality TEXT,
  race_utc TEXT NOT NULL,
  race_tw TEXT NOT NULL,
  tw_date TEXT NOT NULL,
  qual_tw TEXT,
  sprint_tw TEXT,
  has_sprint INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'SCHEDULED',
  pole_driver TEXT,
  winner_driver TEXT,
  fastest_driver TEXT,
  classified_count INTEGER,
  dnf_count INTEGER,
  finishers_line REAL DEFAULT 18.5,
  ou_result TEXT,
  sessions_json TEXT DEFAULT '[]',
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS race_results (
  round INTEGER NOT NULL,
  driver_code TEXT NOT NULL,
  driver_id TEXT,
  driver_en TEXT,
  driver_zh TEXT,
  number TEXT,
  team_abbr TEXT NOT NULL,
  grid INTEGER DEFAULT 0,
  position INTEGER DEFAULT 99,
  pos_text TEXT,
  points REAL DEFAULT 0,
  laps INTEGER DEFAULT 0,
  status TEXT,
  classified INTEGER DEFAULT 0,
  time_str TEXT,
  fastest_lap_rank INTEGER DEFAULT 99,
  fastest_lap_time TEXT,
  sprint_points REAL DEFAULT 0,
  sprint_pos INTEGER DEFAULT 0,
  PRIMARY KEY (round, driver_code)
);

CREATE TABLE IF NOT EXISTS qual_results (
  round INTEGER NOT NULL,
  driver_code TEXT NOT NULL,
  team_abbr TEXT NOT NULL,
  position INTEGER NOT NULL,
  q1 TEXT,
  q2 TEXT,
  q3 TEXT,
  best_sec REAL,
  PRIMARY KEY (round, driver_code)
);

CREATE TABLE IF NOT EXISTS h2h_matchups (
  matchup_id TEXT PRIMARY KEY,
  round INTEGER NOT NULL,
  pair_type TEXT NOT NULL,
  label_zh TEXT NOT NULL,
  driver_a TEXT NOT NULL,
  team_a TEXT NOT NULL,
  driver_b TEXT NOT NULL,
  team_b TEXT NOT NULL,
  open_odds_a REAL NOT NULL,
  open_odds_b REAL NOT NULL,
  close_odds_a REAL NOT NULL,
  close_odds_b REAL NOT NULL,
  market_prob_a REAL NOT NULL,
  model_prob_a REAL NOT NULL,
  fair_odds_a REAL NOT NULL,
  fair_odds_b REAL NOT NULL,
  pick_side TEXT NOT NULL,
  pick_driver TEXT NOT NULL,
  tier TEXT NOT NULL,
  edge_pct REAL NOT NULL,
  kelly_units REAL DEFAULT 0,
  factors_json TEXT DEFAULT '{}',
  rationale_zh TEXT,
  pos_a INTEGER,
  pos_b INTEGER,
  result TEXT DEFAULT 'PENDING',
  error_tag TEXT DEFAULT '',
  postmortem_zh TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS tech_watch (
  item_id TEXT PRIMARY KEY,
  team_abbr TEXT NOT NULL,
  driver_code TEXT,
  status TEXT NOT NULL,
  category_zh TEXT NOT NULL,
  headline_zh TEXT NOT NULL,
  impact_note TEXT,
  grid_risk_pct INTEGER DEFAULT 0,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS news_items (
  news_id TEXT PRIMARY KEY,
  published_tw TEXT NOT NULL,
  source TEXT NOT NULL,
  lang TEXT NOT NULL,
  category TEXT NOT NULL,
  team_abbr TEXT,
  title TEXT NOT NULL,
  summary TEXT,
  url TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_bets (
  bet_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  tw_date TEXT NOT NULL,
  game_id TEXT,
  matchup TEXT NOT NULL,
  market TEXT NOT NULL,
  pick_side TEXT NOT NULL,
  pick_label TEXT NOT NULL,
  line REAL DEFAULT 0,
  odds_decimal REAL NOT NULL,
  stake REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING',
  pnl REAL DEFAULT 0,
  note TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS kv_state (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL,
  updated_at TEXT
);
"""


def connect() -> sqlite3.Connection:
  os.makedirs(config.DATA_DIR, exist_ok=True)
  conn = sqlite3.connect(config.DB_PATH, timeout=30.0)
  conn.row_factory = sqlite3.Row
  conn.execute('PRAGMA journal_mode=WAL;')
  conn.execute('PRAGMA synchronous=NORMAL;')
  conn.executescript(SCHEMA_SQL)
  return conn


def set_state(conn: sqlite3.Connection, key: str, val: Any, updated_at: str = '') -> None:
  conn.execute(
      'INSERT INTO kv_state(k, v, updated_at) VALUES (?,?,?) '
      'ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at',
      (key, json.dumps(val, ensure_ascii=False), updated_at),
  )


def get_state(conn: sqlite3.Connection, key: str, default: Any = None) -> Any:
  row = conn.execute('SELECT v FROM kv_state WHERE k = ?', (key,)).fetchone()
  if not row:
    return default
  try:
    return json.loads(row['v'])
  except ValueError:
    return default
