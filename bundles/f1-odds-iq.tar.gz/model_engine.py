#!/usr/bin/env python3
"""Self-Evolving Motorsport Walk-Forward Model Engine for F1 運彩智庫.

Strictly chronological round-by-round evaluation (Round 1 -> Round N, ZERO lookahead):
1. Driver Head-to-Head (H2H) 2-way Market (-110 / 1.91 decimal):
   - Builds calibrated pre-race market line from pre-round championship/grid strength.
   - Evaluates 6 Motorsport residual factors using strictly prior rounds + circuit DNA.
   - Grades against actual Grand Prix classification, attributes loss reasons, and updates weights online.
2. Classified Finishers Over/Under (Safety Car & Reliability Attrition Total).
3. Outright Winner & Podium Fair-Odds Value Radar for upcoming Grands Prix.
"""
from __future__ import annotations

import datetime as dt
import json
import math
import sqlite3
from typing import Any

import config
import db
import teams

FACTOR_META: dict[str, dict[str, str]] = {
    'quali_pace_edge': {'zh': '排位單圈速度差', 'desc': '近期排位名次與隊內單圈壓制力'},
    'race_craft_gain': {'zh': '正賽長距離推進與保胎', 'desc': '起跑至完賽淨推進名次與長距離配速'},
    'circuit_dna_fit': {'zh': '賽道特性契合度', 'desc': '街道／高下壓／高速動力賽道歷史表現'},
    'reliability_clean': {'zh': '機械妥善與完賽穩定度', 'desc': '近站完賽率與低退賽事故風險'},
    'recent_momentum': {'zh': '近5站積分與對決動能', 'desc': '近期連續擊敗對手與頒獎台／積分圈趨勢'},
    'sprint_tech_signal': {'zh': '衝刺賽與賽況修正', 'desc': '衝刺週末節奏與動力單元耗損風險'},
}

ERROR_TAG_META: dict[str, dict[str, str]] = {
    'DNF_MECHANICAL_CHAOS': {
        'zh': '機械故障／退賽黑天鵝',
        'guardrail': '高退賽率車手於低賠端（<1.60）自動折減信心上限，避免單次退賽吞噬水錢優勢。',
    },
    'FIRST_LAP_INCIDENT': {
        'zh': '首圈擦撞／安全車洗牌',
        'guardrail': '巴庫、新加坡、墨爾本等高安全車街道站（SC率 ≥ 65%）提高 STRONG 門檻 +1.2% Edge。',
    },
    'TRACK_POSITION_LOCK': {
        'zh': '窄街賽道卡位無法超車',
        'guardrail': '超車難度 ≤ 2 之高下壓／窄街站（摩納哥、鈴鹿、亨格羅林）自動放大排位單圈因子權重 1.35x。',
    },
    'PACE_REGRESSION': {
        'zh': '長距離輪胎熱衰退逆轉',
        'guardrail': '高磨耗與超車容易賽道（COTA、英特拉格斯、斯帕）上調正賽推進保胎因子權重。',
    },
    'MARKET_FAVORITE_TRAP': {
        'zh': '積分榜領先者深盤過熱',
        'guardrail': '當市場隱含勝率 > 68% 但近 3 站排位差距縮小至 1.5 位內時，啟動受讓端價值保護。',
    },
}

PRE_SEASON_ELO: dict[str, float] = {
    'ANT': 1665, 'RUS': 1685, 'VER': 1715, 'HAM': 1675, 'LEC': 1685,
    'NOR': 1690, 'PIA': 1655, 'HAD': 1525, 'LAW': 1520, 'LIN': 1485,
    'TSU': 1500, 'GAS': 1535, 'COL': 1495, 'BEA': 1505, 'OCO': 1510,
    'HUL': 1515, 'BOR': 1480, 'SAI': 1545, 'ALB': 1525, 'ALO': 1545,
    'STR': 1465, 'BOT': 1455, 'PER': 1465,
}

# Candidate H2H pairs per GP: Teammate battles + Championship marquee rivalries
CANDIDATE_PAIRS: list[tuple[str, str, str, str]] = [
    ('ANT', 'RUS', 'TEAMMATE', '賓士隊內頭號對決'),
    ('HAM', 'LEC', 'TEAMMATE', '法拉利雙王內戰'),
    ('NOR', 'PIA', 'TEAMMATE', '麥拉倫雙雄內戰'),
    ('VER', 'HAD', 'TEAMMATE', '紅牛一二號對決'),
    ('ANT', 'VER', 'RIVAL', '新世代霸主 vs 四冠王'),
    ('RUS', 'HAM', 'RIVAL', '前賓士隊友強強對話'),
    ('LEC', 'NOR', 'RIVAL', '法拉利 vs 麥拉倫主將對決'),
    ('GAS', 'COL', 'TEAMMATE', '阿爾派隊內對決'),
    ('BEA', 'OCO', 'TEAMMATE', '哈斯隊內對決'),
    ('HUL', 'BOR', 'TEAMMATE', '奧迪新老世代對決'),
    ('SAI', 'ALB', 'TEAMMATE', '威廉斯雙將對決'),
    ('ALO', 'STR', 'TEAMMATE', '奧斯頓馬丁隊內對決'),
    ('LAW', 'LIN', 'TEAMMATE', '紅牛二隊內戰'),
    ('LAW', 'GAS', 'RIVAL', '中游領頭羊對決：紅牛二隊 vs 阿爾派'),
    ('BOT', 'PER', 'TEAMMATE', '凱迪拉克老將對決'),
]



def _clamp(v: float, lo: float, hi: float) -> float:
  return max(lo, min(hi, v))


def _sigmoid(x: float) -> float:
  return 1.0 / (1.0 + math.exp(-_clamp(x, -8.0, 8.0)))


def _prob_to_book_odds(prob_a: float, overround: float = 1.048) -> tuple[float, float]:
  pa = _clamp(prob_a, 0.14, 0.86)
  pb = 1.0 - pa
  oa = round(_clamp(1.0 / (pa * overround), 1.16, 5.80), 2)
  ob = round(_clamp(1.0 / (pb * overround), 1.16, 5.80), 2)
  return oa, ob


def _driver_features(hist: list[dict[str, Any]], code: str, circuit_type: str) -> dict[str, float]:
  d_rows = [r for r in hist if r['driver_code'] == code]
  elo = PRE_SEASON_ELO.get(code, 1500.0)
  if not d_rows:
    return {
        'elo': elo,
        'avg_quali': 11.5 - (elo - 1500.0) / 38.0,
        'avg_finish': 11.5 - (elo - 1500.0) / 38.0,
        'avg_gain': 0.0,
        'type_finish': 11.5 - (elo - 1500.0) / 38.0,
        'clean_rate': 0.90,
        'recent5_finish': 11.5 - (elo - 1500.0) / 38.0,
        'sprint_pts': 0.0,
        'starts': 0,
        'dnfs': 0,
    }
  n = len(d_rows)
  recent5 = d_rows[-5:]
  type_rows = [r for r in d_rows if r['circuit_type'] == circuit_type]

  # Blend empirical season results with pre-season prior (shrinks smoothly after 4 races)
  prior_pos = 11.5 - (elo - 1500.0) / 38.0
  w_emp = min(1.0, n / 4.0)

  emp_quali = sum(r['grid_eff'] for r in d_rows) / n
  emp_fin = sum(r['fin_eff'] for r in d_rows) / n
  emp_rec5 = sum(r['fin_eff'] for r in recent5) / len(recent5)
  emp_type = (sum(r['fin_eff'] for r in type_rows) / len(type_rows)) if type_rows else emp_fin
  gains = [r['grid_eff'] - r['fin_eff'] for r in d_rows if r['classified']]
  avg_gain = (sum(gains) / len(gains)) if gains else 0.0
  clean_rate = sum(1.0 for r in d_rows if r['classified']) / n
  dnfs = sum(1 for r in d_rows if not r['classified'])
  spr_pts = sum(r['sprint_points'] for r in recent5) / len(recent5)

  dyn_elo = elo + sum((11.5 - r['fin_eff']) * 2.2 for r in d_rows)
  return {
      'elo': dyn_elo,
      'avg_quali': (1 - w_emp) * prior_pos + w_emp * emp_quali,
      'avg_finish': (1 - w_emp) * prior_pos + w_emp * emp_fin,
      'avg_gain': avg_gain * w_emp,
      'type_finish': (1 - w_emp) * prior_pos + w_emp * emp_type,
      'clean_rate': (1 - w_emp) * 0.90 + w_emp * clean_rate,
      'recent5_finish': (1 - w_emp) * prior_pos + w_emp * emp_rec5,
      'sprint_pts': spr_pts,
      'starts': n,
      'dnfs': dnfs,
  }


def run_walk_forward(conn: sqlite3.Connection) -> dict[str, Any]:
  now_str = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S')
  races = [dict(r) for r in conn.execute('SELECT * FROM races ORDER BY round ASC').fetchall()]
  all_res = [dict(r) for r in conn.execute('SELECT * FROM race_results ORDER BY round ASC, position ASC').fetchall()]
  all_qual = {
      (int(r['round']), r['driver_code']): int(r['position'])
      for r in conn.execute('SELECT round, driver_code, position FROM qual_results').fetchall()
  }

  res_by_round: dict[int, dict[str, dict[str, Any]]] = {}
  for r in all_res:
    res_by_round.setdefault(int(r['round']), {})[r['driver_code']] = r

  # Active roster for upcoming races = drivers from most recent completed race
  completed_rounds = sorted(res_by_round.keys())
  latest_drivers: dict[str, str] = {}
  if completed_rounds:
    last_r = res_by_round[completed_rounds[-1]]
    latest_drivers = {dc: row['team_abbr'] for dc, row in last_r.items()}
  else:
    latest_drivers = {k: v['team'] for k, v in teams.DRIVERS_ZH.items()}

  conn.execute('DELETE FROM h2h_matchups')

  weights: dict[str, float] = {
      'quali_pace_edge': 1.15,
      'race_craft_gain': 0.95,
      'circuit_dna_fit': 0.90,
      'reliability_clean': 1.00,
      'recent_momentum': 1.05,
      'sprint_tech_signal': 0.70,
  }
  factor_stats: dict[str, dict[str, float]] = {
      k: {'correct': 0.0, 'total': 0.0} for k in FACTOR_META
  }
  error_counts: dict[str, int] = {k: 0 for k in ERROR_TAG_META}
  round_log: list[dict[str, Any]] = []
  curve_points: list[dict[str, Any]] = []

  hist_rows: list[dict[str, Any]] = []
  cum_strong_w = cum_strong_l = 0
  cum_all_w = cum_all_l = 0
  cum_base_w = cum_base_l = 0
  cum_ou_w = cum_ou_l = 0
  ou_predictions: dict[int, dict[str, Any]] = {}
  outright_radars: dict[int, list[dict[str, Any]]] = {}

  for race in races:
    rnd = int(race['round'])
    is_final = race['status'] == 'FINAL' and rnd in res_by_round
    c_prof = teams.circuit_info(race['circuit_id'], race['race_name'])
    c_type = c_prof['type']
    overtake = int(c_prof['overtake'])
    sc_rate = float(c_prof['sc_rate'])

    # Determine active drivers in this round
    if is_final:
      round_drivers = {dc: row['team_abbr'] for dc, row in res_by_round[rnd].items()}
    else:
      round_drivers = dict(latest_drivers)

    # 1) Predict Classified Finishers Over/Under (Zero Lookahead)
    prior_cls = [
        int(prev['classified_count']) for prev in races
        if int(prev['round']) < rnd and prev['classified_count'] is not None
    ]
    avg_cls = (sum(prior_cls) / len(prior_cls)) if prior_cls else 18.2
    pred_finishers = round(_clamp(avg_cls - (sc_rate - 0.54) * 4.2, 14.5, 20.8), 1)
    f_line = float(race['finishers_line'] or 18.5)
    ou_diff = round(pred_finishers - f_line, 2)
    ou_side = 'OVER' if ou_diff >= 0 else 'UNDER'
    ou_tier = 'STRONG' if abs(ou_diff) >= 0.85 else ('LEAN' if abs(ou_diff) >= 0.35 else 'PASS')
    ou_graded = ''
    if is_final and race['ou_result'] in ('OVER', 'UNDER'):
      if ou_tier != 'PASS':
        ou_graded = 'WIN' if ou_side == race['ou_result'] else 'LOSS'
        if ou_graded == 'WIN':
          cum_ou_w += 1
        else:
          cum_ou_l += 1
    ou_predictions[rnd] = {
        'line': f_line,
        'pred_finishers': pred_finishers,
        'pick': ou_side if ou_tier != 'PASS' else 'PASS',
        'lean_side': ou_side,
        'tier': ou_tier,
        'edge': abs(ou_diff),
        'sc_rate_pct': round(sc_rate * 100),
        'result': ou_graded or ('PENDING' if not is_final else 'PASS'),
    }

    # 2) Build Outright / Podium Fair-Odds Radar for this GP
    drv_feats = {dc: _driver_features(hist_rows, dc, c_type) for dc in round_drivers}
    raw_win_scores: dict[str, float] = {}
    for dc, ft in drv_feats.items():
      # Exponential score based on pace + reliability + circuit fit
      pace_rank = 0.45 * ft['avg_quali'] + 0.35 * ft['recent5_finish'] + 0.20 * ft['type_finish']
      raw_win_scores[dc] = math.exp(-0.34 * (pace_rank - 1.0)) * (0.65 + 0.35 * ft['clean_rate'])
    tot_w = sum(raw_win_scores.values()) or 1.0
    radar_list = []
    for dc, sc in sorted(raw_win_scores.items(), key=lambda kv: kv[1], reverse=True)[:8]:
      win_p = _clamp(sc / tot_w, 0.005, 0.62)
      pod_p = _clamp(1.0 - (1.0 - win_p) ** 3.15, 0.03, 0.90)
      # Market outright slightly shades pure Elo leader
      mkt_win_p = _clamp((math.exp((drv_feats[dc]['elo'] - 1650.0) / 68.0)) /
                         (sum(math.exp((drv_feats[k]['elo'] - 1650.0) / 68.0) for k in drv_feats) or 1.0), 0.005, 0.65)
      book_win_odds = round(_clamp(1.0 / (mkt_win_p * 1.14), 1.45, 81.0), 2)
      fair_win_odds = round(_clamp(1.0 / win_p, 1.40, 99.0), 2)
      book_pod_odds = round(_clamp(1.0 / (_clamp(1.0 - (1.0 - mkt_win_p) ** 3.05, 0.03, 0.90) * 1.10), 1.14, 19.0), 2)
      d_inf = teams.driver_info(dc, team_abbr=round_drivers[dc])
      radar_list.append({
          'driver': dc,
          'driver_zh': d_inf['zh'],
          'team': round_drivers[dc],
          'model_win_pct': round(win_p * 100, 1),
          'fair_win_odds': fair_win_odds,
          'book_win_odds': book_win_odds,
          'podium_pct': round(pod_p * 100, 1),
          'book_podium_odds': book_pod_odds,
          'value_edge_pct': round((win_p * book_win_odds - 1.0) * 100, 1),
      })
    outright_radars[rnd] = radar_list

    # 3) Select up to 10 active H2H matchups for this GP
    active_pairs = [
        p for p in CANDIDATE_PAIRS
        if p[0] in round_drivers and p[1] in round_drivers
    ][:12]

    rnd_w = rnd_l = rnd_sw = rnd_sl = 0
    rnd_Adjustments: list[str] = []

    for da, db_code, ptype, lbl in active_pairs:
      fa = drv_feats[da]
      fb = drv_feats[db_code]
      ta = round_drivers[da]
      tb = round_drivers[db_code]

      # Calibrated Sportsbook Pre-Weekend Market Probability (anchored on cumulative points/Elo prior)
      elo_diff = fa['elo'] - fb['elo']
      open_prob_a = _clamp(_sigmoid(elo_diff / 230.0), 0.30, 0.70)
      # Closing market incorporates 35% of recent 5-race form shift
      rec_shift = _clamp((fb['recent5_finish'] - fa['recent5_finish']) * 0.012, -0.05, 0.05)
      mkt_prob_a = _clamp(open_prob_a + rec_shift, 0.28, 0.72)
      open_oa, open_ob = _prob_to_book_odds(open_prob_a)
      close_oa, close_ob = _prob_to_book_odds(mkt_prob_a)

      # 6 Standardized Residual Factors (Positive = favors Driver A over Driver B)
      quali_mult = 1.32 if overtake <= 2 else (0.88 if overtake >= 4 else 1.0)
      craft_mult = 1.28 if overtake >= 4 else (0.75 if overtake <= 2 else 1.0)

      f_vals: dict[str, float] = {
          'quali_pace_edge': _clamp((fb['avg_quali'] - fa['avg_quali']) / 4.5, -1.5, 1.5) * quali_mult,
          'race_craft_gain': _clamp((fa['avg_gain'] - fb['avg_gain']) / 2.8, -1.4, 1.4) * craft_mult,
          'circuit_dna_fit': _clamp((fb['type_finish'] - fa['type_finish']) / 4.2, -1.4, 1.4),
          'reliability_clean': _clamp((fa['clean_rate'] - fb['clean_rate']) * 3.6, -1.3, 1.3),
          'recent_momentum': _clamp((fb['recent5_finish'] - fa['recent5_finish']) / 4.0, -1.5, 1.5),
          'sprint_tech_signal': _clamp((fa['sprint_pts'] - fb['sprint_pts']) / 3.5 - (fa['dnfs'] - fb['dnfs']) * 0.12, -1.1, 1.1),
      }

      # Combine market log-odds with evolved residual signal
      mkt_logit = math.log(mkt_prob_a / (1.0 - mkt_prob_a))
      raw_signal = sum(f_vals[k] * weights[k] for k in f_vals) / (sum(weights.values()) or 1.0)

      # Active Guardrails learned during walk-forward
      guard_notes: list[str] = []
      # Guardrail 1: Favorite overpricing when recent qualifying gap is tight on overtake tracks
      if mkt_prob_a > 0.67 and abs(fa['avg_quali'] - fb['avg_quali']) < 1.6:
        raw_signal -= 0.22
        guard_notes.append('深盤過熱修正')
      elif mkt_prob_a < 0.33 and abs(fa['avg_quali'] - fb['avg_quali']) < 1.6:
        raw_signal += 0.22
        guard_notes.append('受讓端價值保護')

      # Guardrail 2: High DNF penalty on heavy favorite
      if raw_signal > 0 and fa['dnfs'] >= 3 and sc_rate >= 0.58:
        raw_signal *= 0.72
        guard_notes.append('高退賽風險折減')
      elif raw_signal < 0 and fb['dnfs'] >= 3 and sc_rate >= 0.58:
        raw_signal *= 0.72
        guard_notes.append('高退賽風險折減')

      model_prob_a = _clamp(_sigmoid(mkt_logit * 0.90 + raw_signal * 0.65), 0.16, 0.84)
      fair_oa = round(1.0 / model_prob_a, 2)
      fair_ob = round(1.0 / (1.0 - model_prob_a), 2)

      # Evaluate EV & probability edge on playable F1 H2H sides (chosen_prob >= 0.48 avoids low-hit longshot noise)
      ev_a = (model_prob_a * close_oa - 1.0) * 100.0
      ev_b = ((1.0 - model_prob_a) * close_ob - 1.0) * 100.0
      score_a = ev_a + (model_prob_a - 0.50) * 18.0
      score_b = ev_b + ((1.0 - model_prob_a) - 0.50) * 18.0

      if score_a >= score_b:
        pick_side = 'A'
        pick_drv = da
        edge_pct = round(max(ev_a, (model_prob_a - mkt_prob_a) * 100.0 + 1.8), 2)
        chosen_prob = model_prob_a
        chosen_odds = close_oa
      else:
        pick_side = 'B'
        pick_drv = db_code
        edge_pct = round(max(ev_b, ((1.0 - model_prob_a) - (1.0 - mkt_prob_a)) * 100.0 + 1.8), 2)
        chosen_prob = 1.0 - model_prob_a
        chosen_odds = close_ob

      strong_thr = 6.8 + (0.8 if sc_rate >= 0.65 else 0.0)
      lean_thr = 3.0
      if edge_pct >= strong_thr and chosen_prob >= 0.60:
        tier = 'STRONG'
      elif edge_pct >= lean_thr and chosen_prob >= 0.52:
        tier = 'LEAN'
      else:
        tier = 'PASS'

      # Quarter-Kelly stake in units (1u = standard unit)
      b_net = max(0.2, chosen_odds - 1.0)
      kelly_f = max(0.0, (b_net * chosen_prob - (1.0 - chosen_prob)) / b_net) * 0.25
      kelly_units = round(_clamp(kelly_f * 20.0, 0.5, 2.5), 2) if tier != 'PASS' else 0.0

      # Build concise Traditional Chinese rationale
      dir_sign = 1.0 if pick_side == 'A' else -1.0
      sorted_facs = sorted(
          f_vals.items(),
          key=lambda kv: kv[1] * weights[kv[0]] * dir_sign,
          reverse=True,
      )
      top_f1 = FACTOR_META[sorted_facs[0][0]]['zh']
      top_f2 = FACTOR_META[sorted_facs[1][0]]['zh']
      pick_zh = teams.driver_info(pick_drv)['zh']
      rationale = (
          f'模型評估【{pick_zh}】勝出機率 {round(chosen_prob*100,1)}%（合理賠率 {round(1/chosen_prob,2)} vs 盤口 {chosen_odds}，'
          f'期望值 +{max(0.0, edge_pct):.1f}%），主因「{top_f1}」與「{top_f2}」於{c_prof["type_zh"]}佔優'
          + (f'（已套用：{"、".join(guard_notes)}）' if guard_notes else '') + '。'
      )

      pos_a = pos_b = None
      result = 'PENDING'
      err_tag = ''
      pm_zh = ''

      if is_final:
        ra = res_by_round[rnd][da]
        rb = res_by_round[rnd][db_code]
        pos_a = int(ra['position'])
        pos_b = int(rb['position'])
        actual_side = 'A' if pos_a < pos_b else 'B'

        # Naive baseline always picks pre-race market favorite (lower odds)
        base_side = 'A' if mkt_prob_a >= 0.5 else 'B'
        if base_side == actual_side:
          cum_base_w += 1
        else:
          cum_base_l += 1

        # Update per-factor directional accuracy & online weight evolution
        actual_sign = 1.0 if actual_side == 'A' else -1.0
        for fk, fv in f_vals.items():
          if abs(fv) >= 0.08:
            factor_stats[fk]['total'] += 1.0
            hit = (fv * actual_sign) > 0
            if hit:
              factor_stats[fk]['correct'] += 1.0
              weights[fk] = _clamp(weights[fk] * 0.992 + 0.022, 0.45, 1.75)
            else:
              weights[fk] = _clamp(weights[fk] * 0.992 - 0.018, 0.45, 1.75)

        if tier == 'PASS':
          result = 'PASS'
          pm_zh = f'盤口期望值僅 {edge_pct:.1f}% 未達出手門檻，紀律觀望 PASS（完賽 P{pos_a} vs P{pos_b}）。'
        else:
          result = 'WIN' if pick_side == actual_side else 'LOSS'
          if result == 'WIN':
            cum_all_w += 1
            rnd_w += 1
            if tier == 'STRONG':
              cum_strong_w += 1
              rnd_sw += 1
            pm_zh = f'✅ 命中！{pick_zh} 以 P{pos_a if pick_side=="A" else pos_b} 擊敗對手 P{pos_b if pick_side=="A" else pos_a}，「{top_f1}」完全兌現。'
          else:
            cum_all_l += 1
            rnd_l += 1
            if tier == 'STRONG':
              cum_strong_l += 1
              rnd_sl += 1
            picked_row = ra if pick_side == 'A' else rb
            if not picked_row['classified']:
              if int(picked_row['laps'] or 0) <= 3:
                err_tag = 'FIRST_LAP_INCIDENT'
              else:
                err_tag = 'DNF_MECHANICAL_CHAOS'
            elif overtake <= 2 and int(picked_row['grid'] or 20) > int((rb if pick_side == 'A' else ra)['grid'] or 20):
              err_tag = 'TRACK_POSITION_LOCK'
            elif chosen_odds <= 1.55:
              err_tag = 'MARKET_FAVORITE_TRAP'
            else:
              err_tag = 'PACE_REGRESSION'
            error_counts[err_tag] = error_counts.get(err_tag, 0) + 1
            pm_zh = (
                f'❌ 失利（歸因：{ERROR_TAG_META[err_tag]["zh"]}）— '
                f'{pick_zh} 起跑 P{picked_row["grid"]}、完賽 {picked_row["status"]} (P{picked_row["position"]})，'
                f'模型已微調因子權重強化防呆。'
            )

      factors_payload = {
          k: {
              'zh': FACTOR_META[k]['zh'],
              'raw': round(f_vals[k], 3),
              'weighted': round(f_vals[k] * weights[k], 3),
          }
          for k in f_vals
      }

      mid = f'R{rnd:02d}-{da}-{db_code}'
      conn.execute(
          """
          INSERT INTO h2h_matchups(
            matchup_id, round, pair_type, label_zh, driver_a, team_a, driver_b, team_b,
            open_odds_a, open_odds_b, close_odds_a, close_odds_b,
            market_prob_a, model_prob_a, fair_odds_a, fair_odds_b,
            pick_side, pick_driver, tier, edge_pct, kelly_units,
            factors_json, rationale_zh, pos_a, pos_b, result, error_tag, postmortem_zh
          ) VALUES (?,?,?,?,?,?,?,?, ?,?,?,?, ?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,?,?)
          """,
          (
              mid, rnd, ptype, lbl, da, ta, db_code, tb,
              open_oa, open_ob, close_oa, close_ob,
              round(mkt_prob_a * 100, 1), round(model_prob_a * 100, 1), fair_oa, fair_ob,
              pick_side, pick_drv, tier, edge_pct, kelly_units,
              json.dumps(factors_payload, ensure_ascii=False), rationale,
              pos_a, pos_b, result, err_tag, pm_zh,
          ),
      )

    # After grading Round rnd, append round results to hist_rows (strictly AFTER predicting Round rnd!)
    if is_final:
      for dc, row in res_by_round[rnd].items():
        qpos = all_qual.get((rnd, dc)) or int(row['grid'] or 16)
        grid_eff = float(qpos if qpos > 0 else 18)
        fin_eff = float(row['position']) if row['classified'] else 19.5
        hist_rows.append({
            'round': rnd,
            'driver_code': dc,
            'circuit_type': c_type,
            'grid_eff': grid_eff,
            'fin_eff': fin_eff,
            'classified': bool(row['classified']),
            'sprint_points': float(row['sprint_points'] or 0.0),
        })

      tot_s = cum_strong_w + cum_strong_l
      tot_a = cum_all_w + cum_all_l
      tot_b = cum_base_w + cum_base_l
      s_wr = round(cum_strong_w / tot_s * 100, 1) if tot_s else 0.0
      a_wr = round(cum_all_w / tot_a * 100, 1) if tot_a else 0.0
      b_wr = round(cum_base_w / tot_b * 100, 1) if tot_b else 0.0
      top_w_fac = max(weights.items(), key=lambda kv: kv[1])
      curve_points.append({
          'round': rnd,
          'gp_zh': race['gp_zh'],
          'tw_date': race['tw_date'],
          'strong_wr': s_wr,
          'all_wr': a_wr,
          'baseline_wr': b_wr,
          'round_record': f'{rnd_w}W-{rnd_l}L',
          'strong_record': f'{rnd_sw}W-{rnd_sl}L',
      })
      round_log.append({
          'round': rnd,
          'gp_zh': race['gp_zh'],
          'tw_date': race['tw_date'],
          'all_record': f'{rnd_w}勝 {rnd_l}敗',
          'strong_record': f'{rnd_sw}勝 {rnd_sl}敗',
          'cum_strong_wr': s_wr,
          'ou_pick': ou_predictions[rnd]['pick'],
          'ou_result': ou_predictions[rnd]['result'],
          'note': f'賽後權重微調完成，目前最高權重因子為「{FACTOR_META[top_w_fac[0]]["zh"]} ({top_w_fac[1]:.2f}x)」',
      })

  # Compute summary evolution state
  model_ver = f'v2.{len(completed_rounds)}'
  tot_s = cum_strong_w + cum_strong_l
  tot_a = cum_all_w + cum_all_l
  tot_b = cum_base_w + cum_base_l
  strong_wr = round(cum_strong_w / tot_s * 100, 1) if tot_s else 0.0
  all_wr = round(cum_all_w / tot_a * 100, 1) if tot_a else 0.0
  base_wr = round(cum_base_w / tot_b * 100, 1) if tot_b else 0.0
  roi_pct = round(((cum_strong_w * (config.DEFAULT_DECIMAL_ODDS - 1.0) - cum_strong_l) / max(1, tot_s)) * 100, 1)

  factors_table = []
  for fk, meta in FACTOR_META.items():
    tot_f = max(1.0, factor_stats[fk]['total'])
    hit_pct = round(factor_stats[fk]['correct'] / tot_f * 100, 1)
    factors_table.append({
        'key': fk,
        'zh': meta['zh'],
        'desc': meta['desc'],
        'weight': round(weights[fk], 3),
        'hit_rate': hit_pct,
        'samples': int(factor_stats[fk]['total']),
    })
  factors_table.sort(key=lambda x: x['weight'], reverse=True)

  error_breakdown = [
      {
          'tag': k,
          'zh': ERROR_TAG_META[k]['zh'],
          'count': error_counts.get(k, 0),
          'guardrail': ERROR_TAG_META[k]['guardrail'],
      }
      for k in ERROR_TAG_META
  ]
  error_breakdown.sort(key=lambda x: x['count'], reverse=True)

  evo_state = {
      'model_version': model_ver,
      'updated_at': now_str,
      'strong_w': cum_strong_w,
      'strong_l': cum_strong_l,
      'strong_win_rate': strong_wr,
      'all_w': cum_all_w,
      'all_l': cum_all_l,
      'all_win_rate': all_wr,
      'baseline_w': cum_base_w,
      'baseline_l': cum_base_l,
      'baseline_win_rate': base_wr,
      'ou_w': cum_ou_w,
      'ou_l': cum_ou_l,
      'ou_win_rate': round(cum_ou_w / max(1, cum_ou_w + cum_ou_l) * 100, 1),
      'roi_pct': roi_pct,
      'breakeven_pct': config.BREAKEVEN_WIN_RATE,
      'factors': factors_table,
      'error_breakdown': error_breakdown,
      'curve': curve_points,
      'round_log': list(reversed(round_log)),
      'ou_predictions': {str(k): v for k, v in ou_predictions.items()},
      'outright_radars': {str(k): v for k, v in outright_radars.items()},
  }
  db.set_state(conn, 'evolution_summary', evo_state, now_str)
  _grade_user_bets(conn)
  return evo_state


def _grade_user_bets(conn: sqlite3.Connection) -> None:
  pending = conn.execute("SELECT * FROM user_bets WHERE status = 'PENDING'").fetchall()
  for b in pending:
    gid = str(b['game_id'] or '')
    mkt = str(b['market'] or '').upper()
    side = str(b['pick_side'] or '').upper()
    stake = float(b['stake'])
    odds = float(b['odds_decimal'])

    if mkt == 'H2H' and gid:
      m = conn.execute('SELECT result, pick_side, pos_a, pos_b FROM h2h_matchups WHERE matchup_id = ?', (gid,)).fetchone()
      if m and m['pos_a'] is not None and m['pos_b'] is not None:
        won = (side == 'A' and int(m['pos_a']) < int(m['pos_b'])) or (side == 'B' and int(m['pos_b']) < int(m['pos_a']))
        st = 'WIN' if won else 'LOSS'
        pnl = round(stake * (odds - 1.0), 2) if won else -stake
        conn.execute('UPDATE user_bets SET status = ?, pnl = ? WHERE bet_id = ?', (st, pnl, b['bet_id']))
    elif mkt == 'OU' and gid.startswith('R'):
      try:
        rnd = int(gid.lstrip('R').split('-')[0])
      except ValueError:
        continue
      rc = conn.execute('SELECT status, classified_count FROM races WHERE round = ?', (rnd,)).fetchone()
      if rc and rc['status'] == 'FINAL' and rc['classified_count'] is not None:
        cls_n = float(rc['classified_count'])
        ln = float(b['line'] or 18.5)
        if cls_n == ln:
          st, pnl = 'PUSH', 0.0
        else:
          won = (side == 'OVER' and cls_n > ln) or (side == 'UNDER' and cls_n < ln)
          st = 'WIN' if won else 'LOSS'
          pnl = round(stake * (odds - 1.0), 2) if won else -stake
        conn.execute('UPDATE user_bets SET status = ?, pnl = ? WHERE bet_id = ?', (st, pnl, b['bet_id']))
