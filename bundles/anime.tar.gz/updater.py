"""Weekly updater entrypoint for Anime & Subculture Academy (CI & campus_scheduler compatible)."""

from __future__ import annotations

import os
import sys

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

from tools import update_seasonal as _us  # noqa: E402


def sync_all(full_backfill: bool = False, update_odds: bool = False, odds_stage: str = 'auto') -> dict:
  del full_backfill, update_odds, odds_stage
  payload = _us.update_seasonal()
  return {
      'weekKey': payload.get('weekKey'),
      'seasonLabel': payload.get('seasonLabel'),
      'updatedAt': payload.get('updatedAt'),
      'count': payload.get('count', 0),
  }
