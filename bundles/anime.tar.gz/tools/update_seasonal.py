#!/usr/bin/env python3
"""Fetches current-season anime from AniList GraphQL + Bangumi calendar into data/seasonal.json & static/js/content/seasonal_data.js."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
import os
import re
import sys
import time
import urllib.request

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
SEASONAL_JSON = os.path.join(DATA_DIR, 'seasonal.json')
SEASONAL_JS = os.path.join(ROOT_DIR, 'static', 'js', 'content', 'seasonal_data.js')

sys.path.insert(0, ROOT_DIR)
from tools import s2tw  # noqa: E402

TZ_TW = timezone(timedelta(hours=8))
UA = 'HappyCampusAnimeAcademy/1.0 (https://okayell.github.io/anime/)'

ANILIST_QUERY = """
query ($season: MediaSeason, $year: Int, $page: Int, $perPage: Int) {
  Page(page: $page, perPage: $perPage) {
    pageInfo { hasNextPage currentPage }
    media(season: $season, seasonYear: $year, type: ANIME, sort: [POPULARITY_DESC], isAdult: false) {
      id
      title { romaji native english }
      format
      status
      episodes
      averageScore
      popularity
      genres
      description(asHtml: false)
      startDate { year month day }
      nextAiringEpisode { airingAt episode }
      coverImage { large color }
      studios(isMain: true) { nodes { name } }
    }
  }
}
"""

GENRE_ZH = {
    'Action': '動作熱血',
    'Adventure': '奇幻冒險',
    'Comedy': '喜劇搞笑',
    'Drama': '劇情群像',
    'Fantasy': '奇幻冒險',
    'Horror': '懸疑恐怖',
    'Mahou Shoujo': '魔法少女',
    'Mecha': '科幻機甲',
    'Music': '音樂藝術',
    'Mystery': '懸疑推理',
    'Psychological': '暗黑心理',
    'Romance': '戀愛喜劇',
    'Sci-Fi': '科幻機甲',
    'Slice of Life': '日常治癒',
    'Sports': '運動競技',
    'Supernatural': '奇幻超自然',
    'Thriller': '懸疑驚悚',
}

SEASON_ZH = {'WINTER': '冬番', 'SPRING': '春番', 'SUMMER': '夏番', 'FALL': '秋番'}
FORMAT_ZH = {'TV': 'TV 番組', 'ONA': '串流 ONA', 'MOVIE': '劇場版', 'OVA': 'OVA', 'TV_SHORT': '泡麵番', 'SPECIAL': '特別篇'}
STATUS_ZH = {'RELEASING': '熱播中', 'FINISHED': '本季完結', 'NOT_YET_RELEASED': '即將開播'}


def _current_season(now: datetime) -> tuple[str, int]:
  m = now.month
  if m in (1, 2, 3):
    return 'WINTER', now.year
  if m in (4, 5, 6):
    return 'SPRING', now.year
  if m in (7, 8, 9):
    return 'SUMMER', now.year
  return 'FALL', now.year


def _norm_key(s: str) -> str:
  return re.sub(r'[\s\W_]+', '', (s or '').lower())


def _clean_desc(text: str) -> str:
  if not text:
    return ''
  s = re.sub(r'<[^>]+>', ' ', text)
  s = re.sub(r'\(Source:[^)]*\)', '', s, flags=re.I)
  s = re.sub(r'\s+', ' ', s).strip()
  return s[:220] + ('…' if len(s) > 220 else '')


def _fetch_bangumi_calendar() -> dict[str, dict]:
  """Returns normalized native-name -> {titleZh, weekday} from Bangumi calendar."""
  out: dict[str, dict] = {}
  try:
    req = urllib.request.Request('https://api.bgm.tv/calendar', headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=15) as r:
      days = json.loads(r.read().decode('utf-8', 'replace'))
    if not isinstance(days, list):
      return out
    for d in days:
      wd = (d.get('weekday') or {}).get('id')  # 1=Mon .. 7=Sun
      for it in d.get('items') or []:
        nat = str(it.get('name') or '').strip()
        cn = str(it.get('name_cn') or '').strip()
        zh = s2tw.to_tw(cn) if cn else ''
        info = {'titleZh': zh, 'weekday': int(wd) if isinstance(wd, int) else 0, 'bgmId': it.get('id')}
        if nat:
          out[_norm_key(nat)] = info
        if cn:
          out[_norm_key(cn)] = info
  except Exception as exc:  # pylint: disable=broad-except
    sys.stderr.write(f'[update_seasonal] Bangumi calendar fallback skipped: {exc}\n')
  return out


def _fetch_anilist_season(season: str, year: int, max_pages: int = 3) -> list[dict]:
  items: list[dict] = []
  for page in range(1, max_pages + 1):
    body = json.dumps({
        'query': ANILIST_QUERY,
        'variables': {'season': season, 'year': year, 'page': page, 'perPage': 50},
    }).encode('utf-8')
    req = urllib.request.Request(
        'https://graphql.anilist.co',
        data=body,
        headers={'Content-Type': 'application/json', 'Accept': 'application/json', 'User-Agent': UA},
    )
    with urllib.request.urlopen(req, timeout=20) as r:
      resp = json.loads(r.read().decode('utf-8', 'replace'))
    pg = (resp.get('data') or {}).get('Page') or {}
    batch = pg.get('media') or []
    items.extend(batch)
    if not (pg.get('pageInfo') or {}).get('hasNextPage'):
      break
    time.sleep(0.35)
  return items


def _weekday_from_item(m: dict, bgm: dict | None) -> int:
  if bgm and bgm.get('weekday'):
    return bgm['weekday']
  nxt = m.get('nextAiringEpisode') or {}
  if nxt.get('airingAt'):
    dt_tw = datetime.fromtimestamp(int(nxt['airingAt']), tz=TZ_TW)
    return dt_tw.isoweekday()
  sd = m.get('startDate') or {}
  if sd.get('year') and sd.get('month') and sd.get('day'):
    try:
      return datetime(int(sd['year']), int(sd['month']), int(sd['day'])).isoweekday()
    except ValueError:
      pass
  return 0


def _load_previous() -> dict | None:
  if not os.path.isfile(SEASONAL_JSON):
    return None
  try:
    with open(SEASONAL_JSON, 'r', encoding='utf-8') as f:
      return json.load(f)
  except Exception:
    return None


def write_seasonal_files(payload: dict) -> None:
  os.makedirs(DATA_DIR, exist_ok=True)
  os.makedirs(os.path.dirname(SEASONAL_JS), exist_ok=True)
  tmp_json = f'{SEASONAL_JSON}.{os.getpid()}.tmp'
  with open(tmp_json, 'w', encoding='utf-8') as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)
  os.replace(tmp_json, SEASONAL_JSON)

  compact = json.dumps(payload, ensure_ascii=False)
  tmp_js = f'{SEASONAL_JS}.{os.getpid()}.tmp'
  with open(tmp_js, 'w', encoding='utf-8') as f:
    f.write(
        '/* Auto-generated by tools/update_seasonal.py — 每週自動同步當季新番表 */\n'
        f'window.ANI_SEASONAL = {compact};\n'
    )
  os.replace(tmp_js, SEASONAL_JS)


def update_seasonal() -> dict:
  now_tw = datetime.now(TZ_TW)
  season, year = _current_season(now_tw)
  prev = _load_previous()
  prev_cnt = len((prev or {}).get('items') or [])

  try:
    bgm_map = _fetch_bangumi_calendar()
    raw_items = _fetch_anilist_season(season, year, max_pages=2)
  except Exception as exc:  # pylint: disable=broad-except
    if prev and prev_cnt >= 15:
      print(f'GUARD: fetch failed ({exc}); keeping previous {prev_cnt} items')
      return prev
    raise

  cleaned: list[dict] = []
  seen_ids: set[int] = set()
  for m in raw_items:
    aid = m.get('id')
    if not aid or aid in seen_ids:
      continue
    fmt = str(m.get('format') or 'TV')
    if fmt not in ('TV', 'ONA', 'MOVIE', 'TV_SHORT', 'OVA'):
      continue
    seen_ids.add(aid)
    t = m.get('title') or {}
    native = str(t.get('native') or '').strip()
    romaji = str(t.get('romaji') or '').strip()
    english = str(t.get('english') or '').strip()
    bgm = bgm_map.get(_norm_key(native)) or bgm_map.get(_norm_key(romaji))
    title_zh = (bgm or {}).get('titleZh') or ''
    display = title_zh or native or english or romaji
    studios = [n.get('name') for n in ((m.get('studios') or {}).get('nodes') or []) if n.get('name')]
    genres_raw = m.get('genres') or []
    genres_zh = []
    for g in genres_raw:
      gz = GENRE_ZH.get(g)
      if gz and gz not in genres_zh:
        genres_zh.append(gz)
    sd = m.get('startDate') or {}
    air_date = ''
    if sd.get('year') and sd.get('month'):
      air_date = f"{sd['year']}-{int(sd['month']):02d}" + (f"-{int(sd['day']):02d}" if sd.get('day') else '')
    nxt = m.get('nextAiringEpisode') or {}
    cov = m.get('coverImage') or {}
    score = m.get('averageScore')
    cleaned.append({
        'id': f's-{aid}',
        'anilistId': aid,
        'title': display,
        'origTitle': native or romaji,
        'enTitle': english or romaji,
        'format': fmt,
        'formatLabel': FORMAT_ZH.get(fmt, fmt),
        'status': str(m.get('status') or 'RELEASING'),
        'statusLabel': STATUS_ZH.get(str(m.get('status') or ''), '播映中'),
        'episodes': m.get('episodes') or 0,
        'score': round(score / 10.0, 1) if isinstance(score, (int, float)) and score > 0 else None,
        'popularity': int(m.get('popularity') or 0),
        'studio': studios[0] if studios else '製作委員會',
        'genres': genres_zh[:3] or ['動畫'],
        'weekday': _weekday_from_item(m, bgm),
        'airDate': air_date,
        'nextEp': nxt.get('episode') or None,
        'cover': str(cov.get('large') or ''),
        'color': str(cov.get('color') or '#7c3aed'),
        'desc': _clean_desc(str(m.get('description') or '')),
    })

  min_keep = max(20, int(prev_cnt * 0.55))
  if len(cleaned) < min_keep:
    if prev and prev_cnt >= 15:
      print(f'GUARD: fetched only {len(cleaned)} items (< {min_keep}); keeping previous {prev_cnt} items')
      return prev
    raise RuntimeError(f'Seasonal anime fetch returned too few items: {len(cleaned)}')

  payload = {
      'updatedAt': now_tw.strftime('%Y-%m-%d %H:%M'),
      'weekKey': now_tw.strftime('%G-W%V'),
      'season': season,
      'year': year,
      'seasonLabel': f'{year} {SEASON_ZH.get(season, season)}',
      'source': 'AniList + Bangumi',
      'count': len(cleaned),
      'items': cleaned,
  }
  write_seasonal_files(payload)
  print(f'SEASONAL_OK: {payload["seasonLabel"]} count={len(cleaned)} week={payload["weekKey"]}')
  return payload


if __name__ == '__main__':
  update_seasonal()
