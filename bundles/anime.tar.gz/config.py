"""Configuration paths for 動漫與二次元學院 (Anime & Subculture Academy)."""

from __future__ import annotations

import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
SEASONAL_JSON = os.path.join(DATA_DIR, 'seasonal.json')
DB_PATH = SEASONAL_JSON
