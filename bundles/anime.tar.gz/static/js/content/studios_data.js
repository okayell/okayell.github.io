/* 🎨 動漫與二次元學院 — 動畫製作公司、傳奇監督與經典聲優檔案 */
window.ANI_STUDIOS = [
  {
    id: 'kyoto-animation',
    name: '京都動畫（Kyoto Animation）',
    founded: 1981,
    hq: '日本京都府宇治市',
    tag: '極致日常演技・光影抒情',
    style: '堅持正職培養制度與社內一條龍製作，擅長以細膩的肢體小動作、眼神微表情、逆光攝影與寫實背景描繪青春情感，將日常互動拍出電影級的溫度。',
    signature: '髮絲與裙襬物理動態、攝影光暈層次、極高完成度的角色日常演技',
    works: ['ani-violet-evergarden', 'ani-a-silent-voice', 'ani-hyouka', 'ani-euphonium', 'ani-clannad', 'ani-k-on', 'ani-haruhi', 'ani-nichijou']
  },
  {
    id: 'madhouse',
    name: 'MADHOUSE',
    founded: 1972,
    hq: '日本東京都中野區',
    tag: '大師搖籃・題材跨度最廣',
    style: '集結無數名導與作畫菁英的老牌名門，從硬派寫實懸疑、熱血英雄動作到靜謐奇幻旅途皆有傳世代表作，擅長為不同原作量身打造最高格調的視覺語言。',
    signature: '電影級構圖調度、克制與爆發兼具的節奏掌控、多元藝術風格實驗',
    works: ['ani-frieren', 'ani-hunter-x-hunter', 'ani-death-note', 'ani-monster', 'ani-one-punch-man', 'ani-a-place-further', 'ani-perfect-blue', 'ani-paprika', 'ani-summer-wars', 'ani-chihayafuru']
  },
  {
    id: 'ufotable',
    name: 'ufotable（幽浮桌）',
    founded: 2000,
    hq: '日本東京都中野區',
    tag: '3D 空間運鏡・特效合成天花板',
    style: '擁有強大的內部攝影部與 3D 團隊，將手繪原畫與立體數位攝影無縫融合，讓鏡頭在複雜建築與戰場中 360 度穿梭，把高速斬擊與粒子光效推向極致。',
    signature: '浮世繪水火粒子特效、流暢 3D 長鏡頭追焦、高對比打光與電影級質感',
    works: ['ani-demon-slayer', 'ani-fate-zero']
  },
  {
    id: 'mappa',
    name: 'MAPPA',
    founded: 2011,
    hq: '日本東京都中野區',
    tag: '高張力寫實動作・新世代霸權製造機',
    style: '由資深製片人丸山正雄創立，近年聚集大量頂尖原畫師與青年演出家，擅長處理高速肉搏打戲、暗黑群像劇與具電影攝影質感的寫實畫面。',
    signature: '近身武打流暢運鏡、高密度特效作畫回、深沉冷峻的現代都市色調',
    works: ['ani-jujutsu-kaisen', 'ani-chainsaw-man', 'ani-attack-on-titan', 'ani-vinland-saga']
  },
  {
    id: 'wit-studio',
    name: 'WIT STUDIO',
    founded: 2012,
    hq: '日本東京都武藏野市',
    tag: '立體機動長鏡頭・粗線條張力',
    style: '出身 Production I.G 體系，以充滿力量的粗鉛筆線條、立體空間穿梭長鏡頭與大膽色彩著稱，無論宏大史詩或療癒日常都能做出鮮明辨識度。',
    signature: 'Make-up 特寫質感、立體空間高速追蹤鏡頭、童話繪本般鮮活美術',
    works: ['ani-attack-on-titan', 'ani-spy-x-family', 'ani-vinland-saga', 'ani-vivy', 'ani-ranking-of-kings']
  },
  {
    id: 'bones',
    name: 'BONES（骨頭社）',
    founded: 1998,
    hq: '日本東京都杉並區',
    tag: '王道熱血動作・原畫師天堂',
    style: '重視手繪動作張力與原畫師個人風格的熱血名廠，長期集結中村豐等世界級動作原畫師，擅長把超能力對決與少年成長拍得拳拳到肉、流暢痛快。',
    signature: '黑白衝擊幀（Impact Frame）、方塊碎石特效、爆發力十足的動作分鏡',
    works: ['ani-fmab', 'ani-mob-psycho', 'ani-my-hero-academia', 'ani-eureka-seven']
  },
  {
    id: 'cloverworks',
    name: 'CloverWorks',
    founded: 2018,
    hq: '日本東京都杉並區',
    tag: '青春情緒・跨媒材創意演出',
    style: '由原 A-1 Pictures 高圓寺工作室獨立而成，擅長以充滿活力的角色演技、貼近當代年輕人的剪輯節奏，以及黏土／實拍／手繪混搭等破格演出打造話題神作。',
    signature: '破格跨媒材喜劇演出、細膩青春角色表情、高水準樂團演奏手部作畫',
    works: ['ani-bocchi-the-rock', 'ani-spy-x-family']
  },
  {
    id: 'ghibli',
    name: '吉卜力工作室（Studio Ghibli）',
    founded: 1985,
    hq: '日本東京都小金井市',
    tag: '手繪自然奇幻・世界動畫殿堂',
    style: '堅持全手繪賽璐璐與紙上作畫精神，將自然風物、飛行機械、食物香氣與人類和土地的關係化為跨世代共同語言，是全球認識日本動畫的首要門面。',
    signature: '水彩厚塗美術背景、充滿生命力的風水火動效、細膩食物與生活感描寫',
    works: ['ani-nausicaa', 'ani-laputa', 'ani-totoro', 'ani-princess-mononoke', 'ani-spirited-away', 'ani-boy-and-heron']
  },
  {
    id: 'production-ig',
    name: 'Production I.G',
    founded: 1987,
    hq: '日本東京都武藏野市',
    tag: '硬派科幻・熱血運動雙強',
    style: '兼具冷冽科幻美術與熱血運動張力的實力名門，既能拍出影響好萊塢的賽博龐克經典，也能在排球與籃球賽場上精準拿捏每一球落地的慢動作與節奏。',
    signature: '精密機械與城市透視、運動比賽關鍵球張力調度、冷冽科技感美術',
    works: ['ani-ghost-in-the-shell', 'ani-haikyuu', 'ani-psycho-pass', 'ani-kuroko', 'ani-heavenly-delusion']
  },
  {
    id: 'trigger',
    name: 'TRIGGER（扳機社）',
    founded: 2011,
    hq: '日本東京都中野區',
    tag: '極限誇張張力・霓虹爆發美學',
    style: '由原 GAINAX 核心班底創立，擁抱誇張變形、強烈撞色、高速剪輯與毫不妥協的熱血浪漫，每一部原創作品都帶著鮮明的反叛能量與狂放視覺奇觀。',
    signature: '極端廣角透視變形、螢光撞色閃光、招牌星芒特效與高燃動作橋段',
    works: ['ani-cyberpunk-edgerunners', 'ani-dungeon-meshi', 'ani-kill-la-kill']
  },
  {
    id: 'shaft',
    name: 'SHAFT（新房美學）',
    founded: 1975,
    hq: '日本東京都杉並區',
    tag: '前衛拼貼・字卡與幾何構圖',
    style: '與監督新房昭之深度合作形塑出獨步業界的前衛風格：大膽字卡閃切、45 度回眸、異空間拼貼美術與大量對話剪輯，讓靜態文戲同樣充滿張力。',
    signature: '招牌「新房角度」回眸、高速文字閃卡、劇團狗咖哩異質拼貼美術',
    works: ['ani-madoka', 'ani-bakemonogatari', 'ani-march-comes-in']
  },
  {
    id: 'science-saru',
    name: 'Science SARU（科學猴）',
    founded: 2013,
    hq: '日本東京都武藏野市',
    tag: '自由奔放線條・數位手繪革新',
    style: '由湯淺政明與崔恩映共同創立，靈活結合 Flash 數位原畫與傳統手繪表現力，畫面如水流般充滿彈性與音樂節奏感，是當代最具實驗精神的頂尖動畫社。',
    signature: '無拘束的變形與色彩切換、高節奏音樂同步剪輯、自由奔放線條美學',
    works: ['ani-dandadan', 'ani-devilman-crybaby']
  },
  {
    id: 'a1-pictures',
    name: 'A-1 Pictures',
    founded: 2005,
    hq: '日本東京都杉並區',
    tag: '精準商業大片・強大製片班底',
    style: '隸屬 Aniplex 體系，採製片人核心制整合跨社優秀人才，無論催淚青春群像、戀愛喜劇、戰爭機甲或爽快戰鬥都能交付極高水準的視覺與演出。',
    signature: '穩定精緻的角色人設、精準的流行演出節奏、大型專案資源整合能力',
    works: ['ani-kaguya-sama', 'ani-your-lie-in-april', 'ani-anohana', 'ani-eighty-six', 'ani-lycoris-recoil', 'ani-solo-leveling', 'ani-erased']
  },
  {
    id: 'sunrise',
    name: 'SUNRISE（日昇／萬代南夢宮影像）',
    founded: 1972,
    hq: '日本東京都杉並區',
    tag: '機甲王國・原創史詩殿堂',
    style: '孕育鋼彈與無數原創科幻經典的傳奇工作室，具備深厚的機械作畫底蘊與多線群像劇製作經驗，從硬派太空歌劇到無厘頭喜劇都能駕馭自如。',
    signature: '精密手繪機械作畫、龐大勢力群像劇編排、強大原創企劃底蘊',
    works: ['ani-cowboy-bebop', 'ani-code-geass', 'ani-gintama']
  },
  {
    id: 'toei-animation',
    name: '東映動畫（Toei Animation）',
    founded: 1956,
    hq: '日本東京都練馬區',
    tag: '日本動畫起點・長篇少年王座',
    style: '歷史最悠久的日本商業動畫巨擘，孕育無數跨世代國民長篇，近年更全面引入頂尖青年作畫師與電影級 3DCG 技術，展現驚人的老廠新氣象。',
    signature: '跨世代國民熱血長篇、近年劇場版級 TV 爆發作畫回、頂尖三渲二技術',
    works: ['ani-dragon-ball', 'ani-saint-seiya', 'ani-slam-dunk', 'ani-one-piece', 'ani-first-slam-dunk', 'ani-girls-band-cry']
  },
  {
    id: 'pa-works',
    name: 'P.A.WORKS',
    founded: 2000,
    hq: '日本富山縣南礪市',
    tag: '職人工作系列・寫實美術背景',
    style: '立足富山縣的地方實力派名廠，以「工作女孩」原創群像劇與細緻如實景的美術背景聞名，尤其擅長把動畫業界與真實職人的甘苦拍得動人又專業。',
    signature: '細緻寫實風景美術、扎實的職場群像刻畫、自然流暢的人物演出',
    works: ['ani-shirobako']
  }
];

window.ANI_DIRECTORS = [
  {
    id: 'dir-miyazaki',
    name: '宮﨑駿',
    role: '動畫電影大師',
    era: '1970s–2020s',
    signature: '飛行夢想、自然與文明對話、極具重量的手繪動作感',
    desc: '世界動畫史最具代表性的創作者之一，以驚人的空間想像力與手繪執念，把雲層、風勢、機械結構與少女的勇氣描繪得栩栩如生。',
    works: ['ani-nausicaa', 'ani-laputa', 'ani-totoro', 'ani-princess-mononoke', 'ani-spirited-away', 'ani-boy-and-heron']
  },
  {
    id: 'dir-anno',
    name: '庵野秀明',
    role: '特攝魂與心理剖析名導',
    era: '1980s–2020s',
    signature: '電線桿與列車長停格、爆炸特效、赤裸內心獨白',
    desc: '將特攝片寫實鏡頭語彙與深層心理創傷引入機械人動畫，徹底改寫 1990 年代以降深夜動畫的敘事邊界與產業結構。',
    works: ['ani-evangelion']
  },
  {
    id: 'dir-kon',
    name: '今敏',
    role: '剪輯魔術師',
    era: '1990s–2000s',
    signature: '無縫轉場剪輯、夢境與現實交疊、現代都市焦慮',
    desc: '以驚為天人的「匹配剪輯」打破時間、空間與虛實界線，僅以四部劇場版便深刻影響全球真人電影與動畫敘事文法。',
    works: ['ani-perfect-blue', 'ani-paprika']
  },
  {
    id: 'dir-watanabe',
    name: '渡邊信一郎',
    role: '音樂節奏大師',
    era: '1990s–2020s',
    signature: '爵士／嘻哈與打戲同步、灑脫公路電影氣質',
    desc: '把音樂當成劇本核心的鬼才監督，擅長讓鏡頭切換與角色拳腳精準踩在鼓點上，營造東西方文化混血的酷帥浪漫。',
    works: ['ani-cowboy-bebop', 'ani-samurai-champloo']
  },
  {
    id: 'dir-shinkai',
    name: '新海誠',
    role: '光影與距離詩人',
    era: '2000s–2020s',
    signature: '極致天空光影、電車擦身而過、青春與災難記憶',
    desc: '從一人獨立製作出發，以令人屏息的雲霞光影與細膩獨白開創現象級動畫電影浪潮，擅長以流行樂與蒙太奇推升情感高潮。',
    works: ['ani-your-name', 'ani-suzume']
  },
  {
    id: 'dir-yamada',
    name: '山田尚子',
    role: '微表情與腳步聲詩人',
    era: '2000s–2020s',
    signature: '低視角腿部鏡頭、淺景深光斑、克制而溫柔的情緒留白',
    desc: '擅長用鏡頭焦點、手指蜷曲、腳步節奏與環境音代替直白台詞，把青春期難以言說的脆弱與心動化為最純粹的影像詩。',
    works: ['ani-a-silent-voice', 'ani-k-on']
  },
  {
    id: 'dir-yuasa',
    name: '湯淺政明',
    role: '視覺實驗鬼才',
    era: '2000s–2020s',
    signature: '奔放變形透視、手繪粗線條、強烈情緒色彩爆發',
    desc: '拒絕被工整線條束縛的動畫藝術家，善用極度誇張的動態透視與色彩節奏，把角色的內心狂喜或恐懼直接畫進畫面結構裡。',
    works: ['ani-ping-pong', 'ani-devilman-crybaby']
  },
  {
    id: 'dir-imaishi',
    name: '今石洋之',
    role: '燃系超展開總司令',
    era: '2000s–2020s',
    signature: '反重力誇張演出、高速剪輯、熱血突破天際',
    desc: '把漫畫誇張張力與美式卡通節奏推到極限的熱血名導，總能在觀眾以為已經到頂的瞬間再往上翻十倍，娛樂張力無人能敵。',
    works: ['ani-gurren-lagann', 'ani-kill-la-kill', 'ani-cyberpunk-edgerunners']
  },
  {
    id: 'dir-otomo',
    name: '大友克洋',
    role: '賽博龐克視覺先驅',
    era: '1980s–2000s',
    signature: '極致寫實都市廢墟、機車光軌、精密建築透視',
    desc: '以驚人的分鏡與建築透視能力顛覆漫畫與動畫界，電影中那道經典的紅機車煞車滑行光軌至今仍被全球影視反覆致敬。',
    works: ['ani-akira']
  },
  {
    id: 'dir-oshii',
    name: '押井守',
    role: '哲學科幻巨匠',
    era: '1980s–2010s',
    signature: '低飽和冷色調都市、靜默長鏡頭、靈魂與機械之問',
    desc: '擅長以高度思辨的對話、城市水影與緩慢凝視的長鏡頭，探討記憶、身分與人類意識的本質，深刻影響全球科幻電影。',
    works: ['ani-ghost-in-the-shell']
  },
  {
    id: 'dir-shinbo',
    name: '新房昭之',
    role: '前衛演出總監督',
    era: '2000s–2020s',
    signature: '幾何空間、高速字卡、強反差氛圍切換',
    desc: '結合實驗劇場語彙與高密度文字蒙太奇，將原本偏向內心獨白的輕小說與漫畫轉化為極具藝術張力的視聽體驗。',
    works: ['ani-madoka', 'ani-bakemonogatari', 'ani-march-comes-in']
  },
  {
    id: 'dir-saito',
    name: '齋藤圭一郎',
    role: '新世代全能名導',
    era: '2020s',
    signature: '喜劇與抒情無縫切換、精準節奏與作畫資源調度',
    desc: '連續以風格截然不同的兩部作品震撼業界的新世代代表監督，既能玩出破格的跨媒材青春喜劇，也能駕馭宏大而靜謐的奇幻史詩。',
    works: ['ani-bocchi-the-rock', 'ani-frieren']
  }
];

window.ANI_SEIYUU = [
  {
    id: 'cv-tanezaki',
    name: '種崎敦美',
    jp: '種﨑敦美',
    tag: '千面變色龍・跨世代全能',
    desc: '聲線跨度令人難以置信的實力派，能在呆萌幼童、冷靜千年精靈與成熟御姐之間無縫切換，幾乎讓人聽不出是同一人配音。',
    works: ['ani-frieren', 'ani-spy-x-family', 'ani-vivy']
  },
  {
    id: 'cv-hanazawa',
    name: '花澤香菜',
    jp: '花澤香菜',
    tag: '透明感治癒聲線・反差演技',
    desc: '清澈柔軟的嗓音極具辨識度，從溫柔青梅竹馬、內斂少女到帶著病嬌或冷峻張力的反差角色都能演出強烈記憶點。',
    works: ['ani-steins-gate', 'ani-bakemonogatari', 'ani-psycho-pass', 'ani-march-comes-in', 'ani-a-place-further']
  },
  {
    id: 'cv-kamiya',
    name: '神谷浩史',
    jp: '神谷浩史',
    tag: '精準吐槽與冷峻王者',
    desc: '口條極度清晰且節奏感絕佳，既能扛下萬字高速吐槽台詞，也能壓低聲線詮釋背負沉重命運的戰場最強角色。',
    works: ['ani-attack-on-titan', 'ani-bakemonogatari', 'ani-natsume', 'ani-haikyuu']
  },
  {
    id: 'cv-miyano',
    name: '宮野真守',
    jp: '宮野真守',
    tag: '戲劇張力天花板・狂氣搞笑雙絕',
    desc: '從中二科學家、冷靜天才到徹底放飛自我的浮誇演出都收放自如，極具舞台劇般的爆發力與情緒感染力。',
    works: ['ani-death-note', 'ani-steins-gate', 'ani-fmab', 'ani-chihayafuru']
  },
  {
    id: 'cv-hayami',
    name: '早見沙織',
    jp: '早見沙織',
    tag: '絲絨溫柔・瞬間壓場反差',
    desc: '聲音自帶高雅沉靜的透明感，溫柔時如春風拂面，一旦切換成壓抑怒火或冷冽殺氣又能瞬間讓全場屏息。',
    works: ['ani-a-silent-voice', 'ani-spy-x-family', 'ani-demon-slayer', 'ani-dungeon-meshi']
  },
  {
    id: 'cv-nakamura',
    name: '中村悠一',
    jp: '中村悠一',
    tag: '從容強者・自然生活感',
    desc: '厚實卻毫不造作的青年聲線，詮釋最強導師、懶散天才與可靠隊友時都自帶令人信賴的從容氣場。',
    works: ['ani-jujutsu-kaisen', 'ani-hyouka', 'ani-clannad', 'ani-haikyuu', 'ani-frieren']
  },
  {
    id: 'cv-sugita',
    name: '杉田智和',
    jp: '杉田智和',
    tag: '靈魂吐槽王・關鍵時刻超帥',
    desc: '以極具個人特色的慵懶低沉吐槽聲線深植人心，平常看似散漫惡搞，關鍵時刻一秒切換認真語氣的反差魅力無可取代。',
    works: ['ani-gintama', 'ani-haruhi', 'ani-jojo', 'ani-haruhi']
  },
  {
    id: 'cv-sawashiro',
    name: '澤城美雪',
    jp: '沢城みゆき',
    tag: '魅惑與少年氣兼具的演技派',
    desc: '兼具磁性低音與細膩情感層次，無論冷酷女劍士、神祕姐姐或帶刺少年都能演繹出極高的角色說服力。',
    works: ['ani-hunter-x-hunter', 'ani-bakemonogatari', 'ani-psycho-pass']
  },
  {
    id: 'cv-tsuda',
    name: '津田健次郎',
    jp: '津田健次郎',
    tag: '低音砲魅力・滄桑大人感',
    desc: '低沉沙啞又帶點倦怠性感的大人聲線極具辨識度，無論冷酷上班族咒術師或深沉宿敵都能一句台詞鎖住全場焦點。',
    works: ['ani-jujutsu-kaisen', 'ani-golden-kamuy', 'ani-orb-movement']
  },
  {
    id: 'cv-kugimiya',
    name: '釘宮理惠',
    jp: '釘宮理恵',
    tag: '傲嬌女王・熱血少年音',
    desc: '以嬌蠻又藏不住溫柔的招牌聲線開創一整個世代的傲嬌文化，同時也能完美勝任誠懇堅毅的少年角色。',
    works: ['ani-toradora', 'ani-fmab', 'ani-gintama']
  },
  {
    id: 'cv-yuuki',
    name: '悠木碧',
    jp: '悠木碧',
    tag: '靈動鬼馬・極端情緒爆發',
    desc: '從純真少女、古靈精怪的藥師到壓抑崩潰的悲劇角色皆游刃有餘，對台詞節奏與角色內心戲的掌握極為精準。',
    works: ['ani-madoka', 'ani-apothecary-diaries', 'ani-erased', 'ani-cyberpunk-edgerunners']
  },
  {
    id: 'cv-kaji',
    name: '梶裕貴',
    jp: '梶裕貴',
    tag: '撕心裂肺吶喊・少年成長史',
    desc: '最擅長詮釋在絕望與憤怒中掙扎成長的少年，那份毫無保留、幾乎燃燒喉嚨的悲憤嘶吼極具震撼力。',
    works: ['ani-attack-on-titan', 'ani-my-hero-academia', 'ani-haikyuu']
  },
  {
    id: 'cv-hanae',
    name: '花江夏樹',
    jp: '花江夏樹',
    tag: '真摯溫柔少年・高壓爆發',
    desc: '清亮誠懇的嗓音天生帶著善良與堅韌氣質，溫柔共情時極具治癒感，危急時刻的吶喊與怪誕喜劇演出同樣出色。',
    works: ['ani-demon-slayer', 'ani-your-lie-in-april', 'ani-dandadan', 'ani-odd-taxi']
  },
  {
    id: 'cv-koyasu',
    name: '子安武人',
    jp: '子安武人',
    tag: '華麗反派宗師・磁性貴族音',
    desc: '辨識度百分百的華麗低音，舉手投足都帶著戲劇感與壓迫氣場，是日本動畫史上最具代表性的傳奇反派聲優之一。',
    works: ['ani-jojo', 'ani-attack-on-titan', 'ani-gintama', 'ani-re-zero']
  },
  {
    id: 'cv-hayashibara',
    name: '林原惠',
    jp: '林原めぐみ',
    tag: '90 年代聲優傳奇・多聲線始祖',
    desc: '橫跨冷漠少女、瀟灑女盜賊與熱血角色的一代宗師，開啟聲優跨界歌手與廣播主持的現代偶像化時代。',
    works: ['ani-evangelion', 'ani-cowboy-bebop', 'ani-paprika']
  },
  {
    id: 'cv-fukuyama',
    name: '福山潤',
    jp: '福山潤',
    tag: '中二智將與戲謔切換',
    desc: '華麗清亮的聲線能一秒拉出舞台劇般的智將氣場，演繹反叛皇子、毒舌老師與歡樂角色都充滿戲劇魅力。',
    works: ['ani-code-geass', 'ani-assassination-classroom', 'ani-spice-and-wolf']
  }
];
