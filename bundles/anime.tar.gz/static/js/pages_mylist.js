/* 📋 動漫與二次元學院 — 個人追番護照、統計與 JSON 匯出匯入 */
(function () {
  'use strict';
  var ANI = window.ANI;

  ANI.renderMyListPage = function (root) {
    var tab = ANI.state.myTab || 'watching';
    var wl = ANI.getWatchlist();
    var prog = ANI.getProgress();

    var watching = [], watchlist = [], done = [];
    Object.keys(prog).forEach(function (id) {
      var w = ANI.findWork(id);
      if (!w) return;
      if (prog[id].status === 'watching') watching.push(w);
      else if (prog[id].status === 'done') done.push(w);
    });
    Object.keys(wl).forEach(function (id) {
      var w = ANI.findWork(id);
      if (w) watchlist.push(w);
    });

    var list = tab === 'watchlist' ? watchlist : (tab === 'done' ? done : watching);

    var genreCounts = {};
    done.forEach(function (w) {
      (w.genres || []).forEach(function (g) {
        var lbl = ANI.GENRES[g] || g;
        genreCounts[lbl] = (genreCounts[lbl] || 0) + 1;
      });
    });
    var topGenres = Object.keys(genreCounts).sort(function (a, b) { return genreCounts[b] - genreCounts[a]; }).slice(0, 5);

    root.innerHTML =
      '<div class="ani-sec-hd">' +
        '<div><h2>📋 我的追番護照</h2><div class="ani-sec-sub">所有追番中、待看清單、已補完星等與心得筆記都自動儲存在本機瀏覽器中</div></div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
          '<button type="button" class="ani-btn ani-btn-sm" id="aniExportBtn">⬇️ 匯出備份</button>' +
          '<label class="ani-btn ani-btn-sm" style="display:inline-flex;align-items:center;cursor:pointer;">⬆️ 匯入備份<input type="file" id="aniImportFile" accept="application/json" style="display:none;" /></label>' +
        '</div>' +
      '</div>' +
      '<div class="ani-panel" style="margin-bottom:14px;">' +
        '<div style="display:flex;flex-wrap:wrap;gap:18px;align-items:center;">' +
          '<div><div class="ani-note">追番中</div><b style="font-size:22px;color:var(--accent-dark);">' + watching.length + '</b> 部</div>' +
          '<div><div class="ani-note">待看清單</div><b style="font-size:22px;color:var(--pink);">' + watchlist.length + '</b> 部</div>' +
          '<div><div class="ani-note">已補完</div><b style="font-size:22px;color:var(--green);">' + done.length + '</b> 部</div>' +
          (topGenres.length
            ? '<div style="flex:1;min-width:180px;"><div class="ani-note">最愛補番類型</div><div class="ani-pills" style="margin-top:4px;">' +
                topGenres.map(function (g) { return '<span class="ani-chip ani-chip-accent">' + ANI.esc(g) + ' ×' + genreCounts[g] + '</span>'; }).join('') +
              '</div></div>'
            : '<div class="ani-note">開始標記「✅ 已補完」後，這裡會自動分析你的動漫偏好圖譜！</div>') +
        '</div>' +
      '</div>' +
      '<div class="ani-pills" style="margin-bottom:14px;">' +
        '<button type="button" class="ani-pill ' + (tab === 'watching' ? 'active' : '') + '" data-mtab="watching">▶ 追番中 (' + watching.length + ')</button>' +
        '<button type="button" class="ani-pill ' + (tab === 'watchlist' ? 'active' : '') + '" data-mtab="watchlist">📋 待看清單 (' + watchlist.length + ')</button>' +
        '<button type="button" class="ani-pill ' + (tab === 'done' ? 'active' : '') + '" data-mtab="done">✅ 已補完 (' + done.length + ')</button>' +
      '</div>' +
      (list.length
        ? '<div class="ani-grid">' + list.map(function (w) { return ANI.renderWorkCard(w, String(w.id).indexOf('s-') === 0); }).join('') + '</div>'
        : '<div class="ani-empty"><b>這個分頁目前是空的</b>去「🗓️ 當季新番」或「📚 跨世代動漫庫」挑幾部心儀作品加入吧！<div style="margin-top:12px;"><button type="button" class="ani-btn ani-btn-primary ani-btn-sm" data-go-route="explore">探索動漫庫 →</button></div></div>');

    root.querySelectorAll('[data-mtab]').forEach(function (b) {
      b.onclick = function () { ANI.state.myTab = b.getAttribute('data-mtab'); ANI.renderMyListPage(root); };
    });

    document.getElementById('aniExportBtn').onclick = function () {
      var data = { exportedAt: new Date().toISOString(), watchlist: ANI.getWatchlist(), progress: ANI.getProgress() };
      var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'anime_passport_backup.json';
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
      ANI.toast('已匯出追番護照備份檔');
    };

    document.getElementById('aniImportFile').onchange = function (ev) {
      var file = ev.target.files && ev.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        try {
          var parsed = JSON.parse(String(reader.result || '{}'));
          if (parsed.watchlist && typeof parsed.watchlist === 'object') ANI.writeJson('ani.watchlist.v1', parsed.watchlist);
          if (parsed.progress && typeof parsed.progress === 'object') ANI.writeJson('ani.progress.v1', parsed.progress);
          ANI.syncHeaderBadges();
          ANI.toast('匯入成功！');
          ANI.renderMyListPage(root);
        } catch (e) {
          ANI.toast('備份檔格式錯誤，無法匯入');
        }
      };
      reader.readAsText(file);
    };
  };
})();
