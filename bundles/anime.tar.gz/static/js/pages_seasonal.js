/* 🗓️ 動漫與二次元學院 — 當季新番表（每週自動同步） */
(function () {
  'use strict';
  var ANI = window.ANI;

  ANI.renderSeasonalPage = function (root) {
    var payload = ANI.getSeasonalPayload();
    var all = payload.items || [];
    var f = ANI.state.seasonal;
    var q = String(f.q || '').trim().toLowerCase();

    var filtered = all.filter(function (it) {
      if (f.weekday !== 'all' && String(it.weekday || 0) !== String(f.weekday)) return false;
      if (f.format !== 'all' && it.format !== f.format) return false;
      if (q) {
        var hay = [it.title, it.origTitle, it.enTitle, it.studio, (it.genres || []).join(' ')].join(' ').toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });

    var dayButtons = [{ k: 'all', lbl: '全部星期 (' + all.length + ')' }]
      .concat([1, 2, 3, 4, 5, 6, 7].map(function (d) {
        var c = all.filter(function (x) { return x.weekday === d; }).length;
        return { k: String(d), lbl: ANI.WEEKDAYS[d] + ' (' + c + ')' };
      }))
      .map(function (d) {
        return '<button type="button" class="ani-pill ' + (String(f.weekday) === d.k ? 'active' : '') + '" data-swd="' + d.k + '">' + ANI.esc(d.lbl) + '</button>';
      }).join('');

    var fmtButtons = [
      { k: 'all', lbl: '全部格式' },
      { k: 'TV', lbl: '📺 TV 番組' },
      { k: 'ONA', lbl: '🌐 串流 ONA' },
      { k: 'MOVIE', lbl: '🎬 劇場版' }
    ].map(function (m) {
      return '<button type="button" class="ani-pill ' + (f.format === m.k ? 'active' : '') + '" data-sfmt="' + m.k + '">' + m.lbl + '</button>';
    }).join('');

    var syncBtn = !ANI.isStatic()
      ? '<button type="button" class="ani-btn ani-btn-primary ani-btn-sm" id="aniSyncSeasonalBtn">🔄 立即同步本季新番</button>'
      : '';

    root.innerHTML =
      '<div class="ani-sec-hd">' +
        '<div><h2>🗓️ ' + ANI.esc(payload.seasonLabel || '當季新番') + ' 熱播總表</h2>' +
          '<div class="ani-sec-sub">來源：' + ANI.esc(payload.source || 'AniList + Bangumi') + '　｜　最後同步：' + ANI.esc(payload.updatedAt || '尚未同步') + '（每週自動更新）</div>' +
        '</div>' +
        syncBtn +
      '</div>' +
      '<div class="ani-filter-panel">' +
        '<div class="ani-search-row">' +
          '<input id="aniSeasonalSearch" class="ani-input" placeholder="搜尋新番片名、日文原名、製作公司或類型…" value="' + ANI.esc(f.q) + '" />' +
          '<button type="button" class="ani-btn ani-btn-sm" id="aniSeasonalReset">重設篩選</button>' +
        '</div>' +
        '<div class="ani-pills">' + dayButtons + '</div>' +
        '<div class="ani-pills">' + fmtButtons + '</div>' +
      '</div>' +
      '<div class="ani-result-bar"><span>目前顯示 <b>' + filtered.length + '</b> / ' + all.length + ' 部當季新番</span><span class="ani-note">點擊海報可看詳細播映資訊並加入追番護照</span></div>' +
      (filtered.length
        ? '<div class="ani-grid">' + filtered.slice(0, 60).map(function (it) { return ANI.renderWorkCard(it, true); }).join('') + '</div>'
        : '<div class="ani-empty"><b>找不到符合條件的新番</b>試試看切換星期或清空關鍵字。</div>');

    root.querySelectorAll('[data-swd]').forEach(function (b) {
      b.onclick = function () { f.weekday = b.getAttribute('data-swd'); ANI.renderSeasonalPage(root); };
    });
    root.querySelectorAll('[data-sfmt]').forEach(function (b) {
      b.onclick = function () { f.format = b.getAttribute('data-sfmt'); ANI.renderSeasonalPage(root); };
    });
    var inp = document.getElementById('aniSeasonalSearch');
    var timer = null;
    if (inp) {
      inp.oninput = function () {
        f.q = inp.value;
        clearTimeout(timer);
        timer = setTimeout(function () { ANI.renderSeasonalPage(root); }, 220);
      };
    }
    var rst = document.getElementById('aniSeasonalReset');
    if (rst) rst.onclick = function () { f.weekday = 'all'; f.format = 'all'; f.q = ''; ANI.renderSeasonalPage(root); };

    var sbtn = document.getElementById('aniSyncSeasonalBtn');
    if (sbtn) {
      sbtn.onclick = function () {
        sbtn.disabled = true;
        sbtn.textContent = '⏳ 同步中…';
        fetch(ANI.apiBase() + 'seasonal/refresh', { method: 'POST' })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (res && res.ok && res.data) {
              window.ANI_SEASONAL = res.data;
              ANI.syncHeaderBadges();
              ANI.toast('已同步最新 ' + res.data.count + ' 部當季新番！');
              ANI.renderSeasonalPage(root);
            } else {
              ANI.toast((res && res.error) || '同步失敗');
              sbtn.disabled = false;
              sbtn.textContent = '🔄 立即同步本季新番';
            }
          })
          .catch(function () {
            ANI.toast('無法連線到本機伺服器');
            sbtn.disabled = false;
            sbtn.textContent = '🔄 立即同步本季新番';
          });
      };
    }
  };
})();
