/* ✧ 動漫與二次元學院主路由、事件委派、版本更新紀錄與意見回饋 */
(function () {
  'use strict';
  var ANI = window.ANI;
  var ROUTES = ['home', 'seasonal', 'explore', 'studios', 'my-list', 'guide', 'feedback'];

  function isEnterSend(ev) {
    return ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing && ev.keyCode !== 229;
  }

  function renderFeedbackPage(root) {
    root.innerHTML =
      '<div style="max-width:640px;margin:0 auto;">' +
        '<div class="ani-sec-hd"><div><h2>💬 意見回饋與作品許願池</h2><div class="ani-sec-sub">想看哪部動畫或漫畫的無雷導讀、資料勘誤或功能建議，都歡迎告訴我們</div></div></div>' +
        '<form id="aniFeedbackForm" class="ani-panel">' +
          '<div style="margin-bottom:12px;">' +
            '<label for="fbCategory" style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">類型</label>' +
            '<select id="fbCategory" class="ani-select">' +
              '<option value="作品許願">✧ 許願新增動畫／漫畫</option>' +
              '<option value="資料修正">📝 資料或無雷勘誤</option>' +
              '<option value="功能建議">✨ 功能與介面建議</option>' +
            '</select>' +
          '</div>' +
          '<div style="margin-bottom:12px;">' +
            '<label for="fbTitle" style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">標題</label>' +
            '<input id="fbTitle" class="ani-input" maxlength="80" placeholder="例：想看《某作品》的無雷入坑導讀" />' +
          '</div>' +
          '<div style="margin-bottom:12px;">' +
            '<label for="fbMessage" style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">內容</label>' +
            '<textarea id="fbMessage" class="ani-input" rows="5" maxlength="2000" placeholder="請描述你的建議（請勿透露劇情結局）" required></textarea>' +
          '</div>' +
          '<button type="submit" class="ani-btn ani-btn-primary" id="fbSubmitBtn">📮 送出</button>' +
        '</form>' +
      '</div>';

    var form = document.getElementById('aniFeedbackForm');
    var btn = document.getElementById('fbSubmitBtn');
    var titleInput = document.getElementById('fbTitle');
    if (titleInput) {
      titleInput.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' && !isEnterSend(ev)) ev.preventDefault();
      });
    }
    form.onsubmit = function (ev) {
      ev.preventDefault();
      var cat = document.getElementById('fbCategory').value;
      var title = document.getElementById('fbTitle').value.trim();
      var msg = document.getElementById('fbMessage').value.trim();
      if (!msg) return;
      var done = function (text) {
        ANI.toast(text);
        form.reset();
        btn.disabled = false;
        btn.textContent = '📮 送出';
      };
      btn.disabled = true;
      btn.textContent = '⏳ 傳送中…';
      if (!ANI.isStatic()) {
        fetch(ANI.apiBase() + 'feedback', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: cat, title: title, content: msg, page: window.location.hash })
        })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (res && res.ok) done('🎉 感謝回饋，我們收到了！');
            else { btn.disabled = false; btn.textContent = '📮 送出'; ANI.toast((res && res.error) || '送出失敗'); }
          })
          .catch(function () { btn.disabled = false; btn.textContent = '📮 送出'; ANI.toast('送出失敗，請稍後再試'); });
      } else if (window.CampusNav && typeof window.CampusNav.sendStaticFeedback === 'function') {
        window.CampusNav.sendStaticFeedback('anime', { kindLabel: cat, title: title || '意見回饋', description: msg })
          .then(function () { done('🎉 已收到你的回饋，系統將自動轉寄給站長！'); })
          .catch(function () { done('🎉 已收到你的回饋，恢復連線時將自動補寄！'); });
      } else {
        btn.disabled = false;
        btn.textContent = '📮 送出';
        ANI.toast('離線版無法送出回饋，請到線上版填寫');
      }
    };
  }

  function openReleaseModal() {
    var rel = window.ANI_RELEASES || { current_version: '1.0.0', releases: [] };
    var backdrop = document.getElementById('releaseModal');
    var card = document.getElementById('releaseModalCard');
    if (!backdrop || !card) return;
    var items = (rel.releases || []).map(function (r) {
      var lis = (r.changes || []).map(function (c) { return '<li>' + ANI.esc(c) + '</li>'; }).join('');
      return '<div class="ani-block"><h4>v' + ANI.esc(r.version) + '｜' + ANI.esc(r.title || '') + '　<span class="ani-note">' + ANI.esc(r.date || '') + '</span></h4><ul>' + lis + '</ul></div>';
    }).join('');
    card.innerHTML =
      '<button type="button" class="ani-modal-close" id="aniRelClose" aria-label="關閉">✕</button>' +
      '<div class="ani-modal-hero"><h2 id="releaseModalTitle">✧ 版本更新紀錄</h2></div>' +
      '<div class="ani-modal-body">' + items + '</div>';
    document.getElementById('aniRelClose').onclick = function () { backdrop.classList.remove('open'); };
    backdrop.classList.add('open');
  }

  function parseHash() {
    var h = String(window.location.hash || '').replace(/^#\/?/, '').split('?')[0].trim();
    var parts = h.split('/');
    if (parts[0] === 'a' && parts[1]) {
      var wid = decodeURIComponent(parts[1]);
      return { route: wid.indexOf('s-') === 0 ? 'seasonal' : 'explore', open: wid };
    }
    return { route: ROUTES.indexOf(parts[0]) !== -1 ? parts[0] : 'home', open: '' };
  }

  ANI.refreshCurrentView = function () {
    var route = parseHash().route;
    var root = document.getElementById('appRoot');
    if (!root) return;
    document.querySelectorAll('#mainNav .ani-tab').forEach(function (t) {
      t.classList.toggle('active', t.getAttribute('data-route') === route);
    });
    ANI.syncHeaderBadges();
    if (route === 'seasonal') ANI.renderSeasonalPage(root);
    else if (route === 'explore') ANI.renderExplorePage(root);
    else if (route === 'studios') ANI.renderStudiosPage(root);
    else if (route === 'my-list') ANI.renderMyListPage(root);
    else if (route === 'guide') ANI.renderGuidePage(root);
    else if (route === 'feedback') renderFeedbackPage(root);
    else ANI.renderHomePage(root);
  };

  function go(route) {
    if (parseHash().route === route && window.location.hash === '#/' + route) ANI.refreshCurrentView();
    else window.location.hash = '#/' + route;
  }

  function init() {
    var rel = window.ANI_RELEASES || { current_version: '1.0.0' };
    var vb = document.getElementById('verBadge');
    if (vb) {
      vb.textContent = 'v' + (rel.current_version || '1.0.0');
      vb.onclick = openReleaseModal;
    }
    var dl = document.getElementById('dlOfflineBtn');
    if (dl && !ANI.isStatic()) dl.classList.add('show');

    document.querySelectorAll('#mainNav .ani-tab').forEach(function (btn) {
      btn.onclick = function () { go(btn.getAttribute('data-route')); };
    });
    document.querySelectorAll('[data-hdr-tab]').forEach(function (btn) {
      btn.onclick = function () {
        ANI.state.myTab = btn.getAttribute('data-hdr-tab');
        go('my-list');
      };
    });

    document.addEventListener('click', function (ev) {
      var t = ev.target;
      if (!t || !t.closest) return;
      var wl = t.closest('[data-toggle-wl]');
      if (wl) {
        ev.preventDefault();
        ANI.toggleWatchlist(wl.getAttribute('data-toggle-wl'));
        ANI.refreshCurrentView();
        return;
      }
      var st = t.closest('[data-set-status]');
      if (st) {
        ev.preventDefault();
        ANI.setWorkStatus(st.getAttribute('data-set-status'), st.getAttribute('data-status-val'));
        ANI.refreshCurrentView();
        return;
      }
      var open = t.closest('[data-open-work]');
      if (open) {
        ev.preventDefault();
        ANI.openModal(open.getAttribute('data-open-work'));
        return;
      }
      var goEl = t.closest('[data-go-route]');
      if (goEl) {
        ev.preventDefault();
        go(goEl.getAttribute('data-go-route'));
        return;
      }
      if (t.id === 'animeModal') ANI.closeModal();
      if (t.id === 'releaseModal') t.classList.remove('open');
    });

    document.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Escape') return;
      ANI.closeModal();
      var rm = document.getElementById('releaseModal');
      if (rm) rm.classList.remove('open');
    });

    window.addEventListener('hashchange', function () {
      var ph = parseHash();
      window.scrollTo(0, 0);
      ANI.closeModal();
      ANI.refreshCurrentView();
      if (ph.open) ANI.openModal(ph.open);
    });

    ANI.resetExplore();
    ANI.refreshCurrentView();
    var first = parseHash();
    if (first.open) ANI.openModal(first.open);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
