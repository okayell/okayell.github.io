/* ✧ 動漫與二次元學院核心：常數、追番護照儲存、海報元件與無雷導讀彈窗 */
(function () {
  'use strict';

  var WL_KEY = 'ani.watchlist.v1';
  var PROG_KEY = 'ani.progress.v1';
  var QUIZ_KEY = 'ani.guide.quiz.v1';

  var MEDIAS = [
    { id: 'both', label: '動畫＆漫畫雙棲', icon: '🌟' },
    { id: 'anime', label: '動畫原創／主體', icon: '📺' },
    { id: 'movie', label: '動畫劇場版', icon: '🎬' },
    { id: 'manga', label: '漫畫原作必讀', icon: '📖' }
  ];

  var DECADES = [
    { id: '2020s', label: '2020s 新時代', sub: '全球同步與作畫黃金期' },
    { id: '2010s', label: '2010s 霸權期', sub: '分鏡與串流引爆現象級名作' },
    { id: '2000s', label: '2000s 黃金期', sub: '深夜動畫起飛與京阿尼崛起' },
    { id: '1990s', label: '1990s 革新期', sub: '世紀末哲思與熱血殿堂' },
    { id: '1980s', label: '1980s 黎明期', sub: '手繪細節怪物與經典起點' }
  ];

  var GENRES = {
    action: '熱血戰鬥',
    scifi: '科幻機甲',
    thriller: '懸疑心理',
    fantasy: '奇幻冒險',
    slice: '日常治癒',
    school: '青春校園',
    sports: '運動競技',
    music: '音樂藝術',
    dark: '暗黑哲思',
    romcom: '戀愛喜劇',
    drama: '劇情群像',
    comedy: '搞笑吐槽'
  };

  var PACE_LABEL = { slow: '慢熱鋪陳', steady: '穩定推進', fast: '開局高能' };
  var VERDICT_INFO = {
    perfect: { label: '🏆 神收尾', cls: 'ani-chip-green' },
    good: { label: '✅ 好好收尾', cls: 'ani-chip-cyan' },
    mixed: { label: '⚖️ 評價兩極', cls: 'ani-chip-gold' },
    open: { label: '🌌 開放餘韻', cls: 'ani-chip-accent' },
    ongoing: { label: '🔄 連載／續作中', cls: 'ani-chip-pink' }
  };
  var WEEKDAYS = { 1: '週一', 2: '週二', 3: '週三', 4: '週四', 5: '週五', 6: '週六', 7: '週日', 0: '未定／串流' };

  var PALETTES = [
    ['#4c1d95', '#7c3aed'],
    ['#831843', '#db2777'],
    ['#1e3a8a', '#2563eb'],
    ['#0f766e', '#0d9488'],
    ['#9a3412', '#ea580c'],
    ['#312e81', '#6366f1']
  ];

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function hashStr(s) {
    var h = 2166136261;
    var str = String(s || '');
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return Math.abs(h);
  }

  function isStatic() {
    if (window.ANI_STATIC_ONLY) return true;
    var proto = window.location.protocol;
    var host = window.location.hostname || '';
    if (proto === 'file:' || /(^|\.)github\.io$/i.test(host)) return true;
    return false;
  }

  function apiBase() {
    var p = window.location.pathname || '/';
    var m = p.match(/^\/([^/]+)\//);
    if (m && m[1] === 'anime') return '/anime/api/';
    return '/api/';
  }

  function readJson(key, fb) {
    try {
      var raw = localStorage.getItem(key);
      if (!raw) return fb;
      var parsed = JSON.parse(raw);
      return parsed && typeof parsed === 'object' ? parsed : fb;
    } catch (e) {
      return fb;
    }
  }

  function writeJson(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) { /* ignore */ }
  }

  function trackAct(kind) {
    if (window.CampusNav && typeof window.CampusNav.recordAction === 'function') {
      try { window.CampusNav.recordAction('anime', kind || 'study'); } catch (e) { /* ignore */ }
    }
  }

  var _catalogCache = null;
  function getCatalog() {
    if (!_catalogCache) {
      var raw = Array.isArray(window.ANI_WORKS) ? window.ANI_WORKS.slice() : [];
      var seen = {};
      _catalogCache = raw.filter(function (w) {
        if (!w || !w.id || seen[w.id]) return false;
        seen[w.id] = 1;
        return true;
      }).sort(function (a, b) {
        return (b.rating || 0) - (a.rating || 0) || (b.year || 0) - (a.year || 0);
      });
    }
    return _catalogCache;
  }

  function getSeasonalPayload() {
    var d = window.ANI_SEASONAL;
    return d && Array.isArray(d.items) ? d : { updatedAt: '', weekKey: '', seasonLabel: '當季新番', count: 0, items: [] };
  }

  function getSeasonalItems() {
    return getSeasonalPayload().items || [];
  }

  function findWork(id) {
    var list = getCatalog();
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    var seasonal = getSeasonalItems();
    for (var j = 0; j < seasonal.length; j++) if (seasonal[j].id === id) return seasonal[j];
    return null;
  }

  function posterUrlOf(item) {
    if (!item) return '';
    if (item.cover) return item.cover;
    var map = window.ANI_POSTERS || {};
    return map[item.id] || '';
  }

  function fallbackSvg(item) {
    var pal = PALETTES[hashStr(item.id || item.title) % PALETTES.length];
    var ch = Array.from(String(item.title || '✧'))[0] || '✧';
    return (
      '<svg class="ani-poster-svg" viewBox="0 0 320 190" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' +
        '<defs><linearGradient id="ag-' + esc(item.id) + '" x1="0" y1="0" x2="1" y2="1">' +
          '<stop offset="0%" stop-color="' + pal[0] + '"/>' +
          '<stop offset="100%" stop-color="' + pal[1] + '"/>' +
        '</linearGradient></defs>' +
        '<rect width="320" height="190" fill="url(#ag-' + esc(item.id) + ')"/>' +
        '<circle cx="265" cy="40" r="76" fill="#fff" opacity="0.09"/>' +
        '<circle cx="48" cy="155" r="54" fill="#fff" opacity="0.07"/>' +
        '<text x="242" y="138" text-anchor="middle" font-size="92" font-weight="900" fill="#fff" opacity="0.14">' + esc(ch) + '</text>' +
      '</svg>'
    );
  }

  /* Passport state: watchlist = { id: ts }, progress = { id: { status:'watching'|'done', rating:0..5, note:'', ep:0, updatedAt } } */
  function getWatchlist() { return readJson(WL_KEY, {}); }
  function getProgress() { return readJson(PROG_KEY, {}); }

  function statusOf(id) {
    var prog = getProgress()[id];
    if (prog && prog.status === 'done') return 'done';
    if (prog && prog.status === 'watching') return 'watching';
    if (getWatchlist()[id]) return 'watchlist';
    return '';
  }

  function toggleWatchlist(id) {
    var wl = getWatchlist();
    if (wl[id]) {
      delete wl[id];
      writeJson(WL_KEY, wl);
      toast('已從待看清單移除');
    } else {
      wl[id] = Date.now();
      writeJson(WL_KEY, wl);
      toast('已加入待看清單 📋');
      trackAct('watchlist');
    }
    syncHeaderBadges();
  }

  function setWorkStatus(id, st) {
    var prog = getProgress();
    var cur = prog[id] || { status: '', rating: 0, note: '', ep: 0 };
    if (cur.status === st) {
      delete prog[id];
      writeJson(PROG_KEY, prog);
      toast('已取消進度標記');
    } else {
      cur.status = st;
      cur.updatedAt = Date.now();
      prog[id] = cur;
      writeJson(PROG_KEY, prog);
      if (st === 'done') {
        var wl = getWatchlist();
        if (wl[id]) { delete wl[id]; writeJson(WL_KEY, wl); }
        toast('已標記為補完 ✅');
      } else {
        toast('已標記為追番中 ▶');
      }
      trackAct('progress');
    }
    syncHeaderBadges();
  }

  function saveWorkNote(id, rating, note) {
    var prog = getProgress();
    var cur = prog[id] || { status: 'done', rating: 0, note: '', ep: 0 };
    cur.rating = rating;
    cur.note = String(note || '').slice(0, 500);
    cur.updatedAt = Date.now();
    prog[id] = cur;
    writeJson(PROG_KEY, prog);
    toast('已儲存個人評價與筆記 ✨');
    trackAct('note');
  }

  var _toastTimer = null;
  function toast(msg) {
    var el = document.getElementById('aniToast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(_toastTimer);
    _toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2200);
  }

  function syncHeaderBadges() {
    var wl = getWatchlist();
    var prog = getProgress();
    var watching = 0, done = 0;
    Object.keys(prog).forEach(function (k) {
      if (prog[k] && prog[k].status === 'watching') watching++;
      else if (prog[k] && prog[k].status === 'done') done++;
    });
    var wlCnt = Object.keys(wl).length;
    var set = function (id, v) { var el = document.getElementById(id); if (el) el.textContent = String(v); };
    set('hdrWatchingCnt', watching);
    set('hdrWatchlistCnt', wlCnt);
    set('hdrDoneCnt', done);
    set('navSeasonalCnt', getSeasonalItems().length);
    set('navTotalCnt', getCatalog().length);
    set('navMyCnt', watching + wlCnt + done);
  }

  function mediaLabel(m) {
    for (var i = 0; i < MEDIAS.length; i++) if (MEDIAS[i].id === m) return MEDIAS[i].icon + ' ' + MEDIAS[i].label;
    return '📺 動畫';
  }

  function renderWorkCard(w, isSeasonal) {
    var st = statusOf(w.id);
    var wlOn = !!getWatchlist()[w.id];
    var pUrl = posterUrlOf(w);
    var scoreVal = isSeasonal ? (w.score ? '★ ' + w.score : '新番') : ('★ ' + Number(w.rating).toFixed(1));
    var topLeft = isSeasonal
      ? (WEEKDAYS[w.weekday || 0] + ' · ' + (w.formatLabel || 'TV'))
      : (w.year + ' · ' + (w.media === 'movie' ? '劇場版' : w.media === 'manga' ? '漫畫' : (w.episodes ? w.episodes + ' 集' : '動畫')));
    var chips = isSeasonal
      ? (w.genres || []).slice(0, 3).map(function (g) { return '<span class="ani-chip ani-chip-accent">' + esc(g) + '</span>'; }).join('')
      : (w.genres || []).slice(0, 3).map(function (g) { return '<span class="ani-chip ani-chip-accent">' + esc(GENRES[g] || g) + '</span>'; }).join('');
    var vBadge = !isSeasonal && w.ending && VERDICT_INFO[w.ending.verdict]
      ? '<span class="ani-chip ' + VERDICT_INFO[w.ending.verdict].cls + '">' + esc(VERDICT_INFO[w.ending.verdict].label) + '</span>'
      : (isSeasonal && w.statusLabel ? '<span class="ani-chip ani-chip-pink">' + esc(w.statusLabel) + '</span>' : '');
    var subText = isSeasonal ? (w.studio || '製作委員會') : ((w.studio || '') + ' · ' + (w.origTitle || ''));
    var tagline = isSeasonal ? (w.desc || '本季話題新作，點擊查看播映資訊並加入追番清單。') : (w.tagline || '');

    return (
      '<article class="ani-card">' +
        '<div class="ani-poster-wrap" data-open-work="' + esc(w.id) + '">' +
          fallbackSvg(w) +
          (pUrl ? '<img class="ani-poster-img" loading="lazy" referrerpolicy="no-referrer" alt="' + esc(w.title) + '" src="' + esc(pUrl) + '" onload="this.classList.add(\'loaded\')" onerror="this.remove()" />' : '') +
          '<div class="ani-poster-grad"></div>' +
          '<div class="ani-poster-top">' +
            '<span class="ani-badge-dark">' + esc(topLeft) + '</span>' +
            '<span class="ani-badge-score">' + esc(scoreVal) + '</span>' +
          '</div>' +
          '<div class="ani-poster-bot">' +
            '<div class="ani-poster-title">' + esc(w.title) + '</div>' +
            '<div class="ani-poster-sub">' + esc(subText) + '</div>' +
          '</div>' +
        '</div>' +
        '<div class="ani-card-body">' +
          '<div class="ani-card-tagline">' + esc(tagline) + '</div>' +
          '<div class="ani-card-meta">' + vBadge + chips + '</div>' +
          '<div class="ani-card-actions">' +
            '<button type="button" class="ani-act-btn ' + (wlOn ? 'on' : '') + '" data-toggle-wl="' + esc(w.id) + '">' + (wlOn ? '📋 已待看' : '➕ 待看') + '</button>' +
            '<button type="button" class="ani-act-btn ' + (st === 'watching' ? 'on' : '') + '" data-set-status="' + esc(w.id) + '" data-status-val="watching">' + (st === 'watching' ? '▶ 追番中' : '▶ 追番') + '</button>' +
            '<button type="button" class="ani-act-btn ' + (st === 'done' ? 'done' : '') + '" data-set-status="' + esc(w.id) + '" data-status-val="done">' + (st === 'done' ? '✅ 已補完' : '✅ 補完') + '</button>' +
          '</div>' +
        '</div>' +
      '</article>'
    );
  }

  function openModal(id) {
    var w = findWork(id);
    var bd = document.getElementById('animeModal');
    var card = document.getElementById('animeModalCard');
    if (!w || !bd || !card) return;
    trackAct('read_work');

    var isSeasonal = String(w.id).indexOf('s-') === 0;
    var pUrl = posterUrlOf(w);
    var st = statusOf(w.id);
    var wlOn = !!getWatchlist()[w.id];
    var myProg = getProgress()[w.id] || { rating: 0, note: '' };
    var ytUrl = 'https://www.youtube.com/results?search_query=' + encodeURIComponent((w.origTitle || w.title) + ' OP PV');

    var bodyHtml = '';
    if (isSeasonal) {
      bodyHtml =
        '<div class="ani-block"><h4>🗓️ 本季播映資訊</h4>' +
          '<p><b>製作公司：</b>' + esc(w.studio || '—') + '　｜　<b>格式：</b>' + esc(w.formatLabel || w.format) + '　｜　<b>狀態：</b>' + esc(w.statusLabel || w.status) + '</p>' +
          '<p><b>更新日：</b>' + esc(WEEKDAYS[w.weekday || 0]) + (w.airDate ? '（首播 ' + esc(w.airDate) + '）' : '') + (w.episodes ? '　｜　<b>預定集數：</b>' + w.episodes + ' 集' : '') + (w.nextEp ? '　｜　<b>下一集：</b>第 ' + w.nextEp + ' 集' : '') + '</p>' +
        '</div>' +
        '<div class="ani-block"><h4>📖 劇情簡介（英文官方摘要）</h4><p>' + esc(w.desc || '暫無官方簡介，可點擊下方按鈕搜尋正式預告片。') + '</p></div>';
    } else {
      var vInfo = (w.ending && VERDICT_INFO[w.ending.verdict]) || { label: '—', cls: '' };
      var hlLis = ((w.analysis && w.analysis.highlights) || []).map(function (h) { return '<li>' + esc(h) + '</li>'; }).join('');
      bodyHtml =
        '<div class="ani-block"><h4>📖 無雷劇情簡介</h4><p>' + esc(w.synopsis) + '</p>' +
          '<div class="ani-pills" style="margin-top:10px;">' +
            (w.mood || []).map(function (m) { return '<span class="ani-chip ani-chip-pink">#' + esc(m) + '</span>'; }).join('') +
          '</div>' +
        '</div>' +
        '<div class="ani-grid-2">' +
          '<div class="ani-block"><h4>🎯 入坑指南</h4>' +
            '<p><b>入戲點：</b>' + esc(w.entry && w.entry.hookBy) + '　｜　<b>節奏：</b>' + esc(PACE_LABEL[w.entry && w.entry.pace] || '穩定') + '</p>' +
            '<p style="margin-top:6px;">' + esc(w.entry && w.entry.tip) + '</p>' +
          '</div>' +
          '<div class="ani-block"><h4>🏁 收尾評價 <span class="ani-chip ' + vInfo.cls + '">' + esc(vInfo.label) + '</span></h4>' +
            '<p style="margin-top:6px;">' + esc(w.ending && w.ending.note) + '</p>' +
          '</div>' +
        '</div>' +
        '<div class="ani-block"><h4>✨ 三大看門道亮點</h4><ul>' + hlLis + '</ul></div>' +
        '<div class="ani-grid-2">' +
          '<div class="ani-block"><h4>🎨 作畫與分鏡美學</h4><p>' + esc(w.analysis && w.analysis.sakuga) + '</p></div>' +
          '<div class="ani-block"><h4>🎵 音樂 OP／ED 與劇伴</h4><p>' + esc(w.analysis && w.analysis.music) + '</p></div>' +
        '</div>' +
        '<div class="ani-block"><h4>📚 原作與動畫改編對照</h4><p>' + esc(w.adaptNote) + '</p>' +
          '<p class="ani-note" style="margin-top:8px;"><b>原作：</b>' + esc(w.creator) + '　｜　<b>監督：</b>' + esc(w.director) + '　｜　<b>聲優／代表角色：</b>' + esc((w.cast || []).join('、')) + '</p>' +
        '</div>';
    }

    var starsHtml = [1, 2, 3, 4, 5].map(function (n) {
      return '<button type="button" class="ani-star ' + (myProg.rating >= n ? 'on' : '') + '" data-star="' + n + '" aria-label="' + n + ' 星">★</button>';
    }).join('');

    card.innerHTML =
      '<button type="button" class="ani-modal-close" id="aniModalClose" aria-label="關閉">✕</button>' +
      '<div class="ani-modal-hero">' +
        (pUrl ? '<img class="ani-modal-cover" referrerpolicy="no-referrer" alt="' + esc(w.title) + '" src="' + esc(pUrl) + '" onerror="this.style.display=\'none\'" />' : '') +
        '<div style="flex:1;min-width:200px;">' +
          '<div style="font-size:12px;opacity:0.88;margin-bottom:4px;">' + esc(isSeasonal ? ('當季新番 · ' + (w.studio || '')) : (mediaLabel(w.media) + ' · ' + w.year + ' · ' + w.studio)) + '</div>' +
          '<h2 id="animeModalTitle" style="font-size:22px;font-weight:900;">' + esc(w.title) + '</h2>' +
          '<div style="font-size:13px;opacity:0.9;margin-top:2px;">' + esc(w.origTitle || '') + (w.enTitle ? ' / ' + esc(w.enTitle) : '') + '</div>' +
          '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;">' +
            '<button type="button" class="ani-btn ani-btn-sm ' + (wlOn ? 'ani-btn-primary' : '') + '" data-modal-wl="' + esc(w.id) + '">' + (wlOn ? '📋 已在待看' : '➕ 加入待看') + '</button>' +
            '<button type="button" class="ani-btn ani-btn-sm ' + (st === 'watching' ? 'ani-btn-primary' : '') + '" data-modal-st="watching">' + (st === 'watching' ? '▶ 追番中' : '▶ 標記追番中') + '</button>' +
            '<button type="button" class="ani-btn ani-btn-sm ' + (st === 'done' ? 'ani-btn-done' : '') + '" data-modal-st="done">' + (st === 'done' ? '✅ 已補完' : '✅ 標記已補完') + '</button>' +
            '<a class="ani-btn ani-btn-sm" href="' + esc(ytUrl) + '" target="_blank" rel="noopener noreferrer">🎬 搜尋 OP／PV ↗</a>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="ani-modal-body">' +
        bodyHtml +
        '<div class="ani-block">' +
          '<h4>📝 我的追番評分與心得筆記</h4>' +
          '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px;">' +
            '<span class="ani-note">個人星等：</span><div class="ani-stars" id="aniModalStars">' + starsHtml + '</div>' +
          '</div>' +
          '<textarea id="aniModalNote" class="ani-input" rows="2" maxlength="500" placeholder="寫下你的無雷心得、最喜歡的名場面或看到第幾集…">' + esc(myProg.note || '') + '</textarea>' +
          '<div style="margin-top:8px;display:flex;justify-content:flex-end;">' +
            '<button type="button" class="ani-btn ani-btn-primary ani-btn-sm" id="aniSaveNoteBtn">💾 儲存筆記</button>' +
          '</div>' +
        '</div>' +
      '</div>';

    var curRating = myProg.rating || 0;
    document.getElementById('aniModalClose').onclick = closeModal;
    card.querySelector('[data-modal-wl]').onclick = function () {
      toggleWatchlist(w.id);
      openModal(w.id);
      if (ANI.refreshCurrentView) ANI.refreshCurrentView();
    };
    card.querySelectorAll('[data-modal-st]').forEach(function (b) {
      b.onclick = function () {
        setWorkStatus(w.id, b.getAttribute('data-modal-st'));
        openModal(w.id);
        if (ANI.refreshCurrentView) ANI.refreshCurrentView();
      };
    });
    card.querySelectorAll('#aniModalStars [data-star]').forEach(function (sBtn) {
      sBtn.onclick = function () {
        curRating = Number(sBtn.getAttribute('data-star')) || 0;
        card.querySelectorAll('#aniModalStars [data-star]').forEach(function (x) {
          x.classList.toggle('on', Number(x.getAttribute('data-star')) <= curRating);
        });
      };
    });
    document.getElementById('aniSaveNoteBtn').onclick = function () {
      saveWorkNote(w.id, curRating, document.getElementById('aniModalNote').value);
      if (ANI.refreshCurrentView) ANI.refreshCurrentView();
    };
    bd.classList.add('open');
  }

  function closeModal() {
    var bd = document.getElementById('animeModal');
    if (bd) bd.classList.remove('open');
  }

  var state = {
    explore: { media: 'all', decade: 'all', genre: 'all', status: 'all', studio: 'all', q: '', sort: 'rating', page: 1 },
    seasonal: { weekday: 'all', format: 'all', q: '' },
    radar: { media: 'all', genre: 'all', pace: 'all', perfectOnly: false },
    studiosTab: 'studios',
    myTab: 'watching',
    guideTab: 'lessons'
  };

  function resetExplore() {
    state.explore = { media: 'all', decade: 'all', genre: 'all', status: 'all', studio: 'all', q: '', sort: 'rating', page: 1 };
  }

  var ANI = {
    MEDIAS: MEDIAS,
    DECADES: DECADES,
    GENRES: GENRES,
    WEEKDAYS: WEEKDAYS,
    VERDICT_INFO: VERDICT_INFO,
    PACE_LABEL: PACE_LABEL,
    QUIZ_KEY: QUIZ_KEY,
    esc: esc,
    isStatic: isStatic,
    apiBase: apiBase,
    readJson: readJson,
    writeJson: writeJson,
    trackAct: trackAct,
    getCatalog: getCatalog,
    getSeasonalPayload: getSeasonalPayload,
    getSeasonalItems: getSeasonalItems,
    findWork: findWork,
    getWatchlist: getWatchlist,
    getProgress: getProgress,
    statusOf: statusOf,
    toggleWatchlist: toggleWatchlist,
    setWorkStatus: setWorkStatus,
    syncHeaderBadges: syncHeaderBadges,
    renderWorkCard: renderWorkCard,
    openModal: openModal,
    closeModal: closeModal,
    toast: toast,
    state: state,
    resetExplore: resetExplore
  };

  window.ANI = ANI;
})();
