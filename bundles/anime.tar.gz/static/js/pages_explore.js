/* 📚 動漫與二次元學院 — 跨世代動漫庫（交叉篩選、搜尋、排序） */
(function () {
  'use strict';
  var ANI = window.ANI;
  var PAGE_SIZE = 36;

  ANI.renderExplorePage = function (root) {
    var all = ANI.getCatalog();
    var f = ANI.state.explore;
    var q = String(f.q || '').trim().toLowerCase();

    var studios = [];
    var stSeen = {};
    all.forEach(function (w) {
      if (w.studio && !stSeen[w.studio]) { stSeen[w.studio] = 1; studios.push(w.studio); }
    });
    studios.sort();

    var filtered = all.filter(function (w) {
      if (f.media !== 'all' && w.media !== f.media) return false;
      if (f.decade !== 'all' && w.decade !== f.decade) return false;
      if (f.genre !== 'all' && (w.genres || []).indexOf(f.genre) === -1) return false;
      if (f.studio !== 'all' && w.studio !== f.studio) return false;
      if (f.status === 'perfect' && (!w.ending || w.ending.verdict !== 'perfect')) return false;
      if (f.status === 'ended' && w.status !== 'ended' && w.status !== 'movie') return false;
      if (f.status === 'ongoing' && w.status !== 'ongoing') return false;
      if (f.status === 'unwatched' && ANI.statusOf(w.id) === 'done') return false;
      if (q) {
        var hay = [w.title, w.origTitle, w.enTitle, w.studio, w.creator, w.director, (w.cast || []).join(' '), w.tagline, (w.mood || []).join(' ')].join(' ').toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });

    if (f.sort === 'year-desc') filtered.sort(function (a, b) { return (b.year || 0) - (a.year || 0) || (b.rating || 0) - (a.rating || 0); });
    else if (f.sort === 'year-asc') filtered.sort(function (a, b) { return (a.year || 0) - (b.year || 0) || (b.rating || 0) - (a.rating || 0); });
    else filtered.sort(function (a, b) { return (b.rating || 0) - (a.rating || 0) || (b.year || 0) - (a.year || 0); });

    var shown = filtered.slice(0, f.page * PAGE_SIZE);

    var decPills = [{ id: 'all', label: '全年代' }].concat(ANI.DECADES.map(function (d) { return { id: d.id, label: d.id }; }))
      .map(function (d) { return '<button type="button" class="ani-pill ' + (f.decade === d.id ? 'active' : '') + '" data-ef="decade" data-val="' + d.id + '">' + ANI.esc(d.label) + '</button>'; }).join('');

    var mediaPills = [{ id: 'all', label: '全媒介' }].concat(ANI.MEDIAS.map(function (m) { return { id: m.id, label: m.icon + ' ' + m.label }; }))
      .map(function (m) { return '<button type="button" class="ani-pill ' + (f.media === m.id ? 'active' : '') + '" data-ef="media" data-val="' + m.id + '">' + ANI.esc(m.label) + '</button>'; }).join('');

    var genrePills = ['all'].concat(Object.keys(ANI.GENRES)).map(function (g) {
      return '<button type="button" class="ani-pill ' + (f.genre === g ? 'active' : '') + '" data-ef="genre" data-val="' + g + '">' + ANI.esc(g === 'all' ? '全類型' : ANI.GENRES[g]) + '</button>';
    }).join('');

    var studioOpts = '<option value="all">全部製作公司</option>' + studios.map(function (s) {
      return '<option value="' + ANI.esc(s) + '" ' + (f.studio === s ? 'selected' : '') + '>' + ANI.esc(s) + '</option>';
    }).join('');

    root.innerHTML =
      '<div class="ani-sec-hd"><div><h2>📚 跨世代動漫經典片庫</h2><div class="ani-sec-sub">1980s–2020s 動畫、劇場版與漫畫原作無雷深度導讀，點擊卡片展開作畫與音樂解析</div></div></div>' +
      '<div class="ani-filter-panel">' +
        '<div class="ani-search-row">' +
          '<input id="efSearch" class="ani-input" placeholder="搜尋片名、原作、監督、聲優、製作公司或情緒標籤…" value="' + ANI.esc(f.q) + '" />' +
          '<select id="efStudio" class="ani-select" aria-label="篩選製作公司">' + studioOpts + '</select>' +
          '<select id="efStatus" class="ani-select" aria-label="篩選狀態">' +
            '<option value="all" ' + (f.status === 'all' ? 'selected' : '') + '>全部狀態</option>' +
            '<option value="perfect" ' + (f.status === 'perfect' ? 'selected' : '') + '>🏆 只看神收尾</option>' +
            '<option value="ended" ' + (f.status === 'ended' ? 'selected' : '') + '>✅ 已完結／劇場版</option>' +
            '<option value="ongoing" ' + (f.status === 'ongoing' ? 'selected' : '') + '>🔄 連載／續作中</option>' +
            '<option value="unwatched" ' + (f.status === 'unwatched' ? 'selected' : '') + '>👀 只看我還沒補完</option>' +
          '</select>' +
          '<select id="efSort" class="ani-select" aria-label="排序方式">' +
            '<option value="rating" ' + (f.sort === 'rating' ? 'selected' : '') + '>依推薦指數排序</option>' +
            '<option value="year-desc" ' + (f.sort === 'year-desc' ? 'selected' : '') + '>依年份由新到舊</option>' +
            '<option value="year-asc" ' + (f.sort === 'year-asc' ? 'selected' : '') + '>依年份由舊到新</option>' +
          '</select>' +
          '<button type="button" class="ani-btn ani-btn-sm" id="efReset">重設</button>' +
        '</div>' +
        '<div class="ani-pills">' + decPills + '</div>' +
        '<div class="ani-pills">' + mediaPills + '</div>' +
        '<div class="ani-pills">' + genrePills + '</div>' +
      '</div>' +
      '<div class="ani-result-bar"><span>篩選結果：共 <b>' + filtered.length + '</b> 部作品</span><span class="ani-note">全部採無雷導讀，放心點開探索</span></div>' +
      (shown.length
        ? '<div class="ani-grid">' + shown.map(function (w) { return ANI.renderWorkCard(w, false); }).join('') + '</div>' +
          (shown.length < filtered.length
            ? '<div style="text-align:center;margin-top:18px;"><button type="button" class="ani-btn ani-btn-primary" id="efMoreBtn">載入更多（已顯示 ' + shown.length + ' / ' + filtered.length + '）</button></div>'
            : '')
        : '<div class="ani-empty"><b>找不到符合條件的作品</b>試試重設條件或換個關鍵字。</div>');

    root.querySelectorAll('[data-ef]').forEach(function (b) {
      b.onclick = function () {
        f[b.getAttribute('data-ef')] = b.getAttribute('data-val');
        f.page = 1;
        ANI.renderExplorePage(root);
      };
    });
    var inp = document.getElementById('efSearch');
    var timer = null;
    if (inp) {
      inp.oninput = function () {
        f.q = inp.value;
        f.page = 1;
        clearTimeout(timer);
        timer = setTimeout(function () { ANI.renderExplorePage(root); }, 220);
      };
    }
    document.getElementById('efStudio').onchange = function (e) { f.studio = e.target.value; f.page = 1; ANI.renderExplorePage(root); };
    document.getElementById('efStatus').onchange = function (e) { f.status = e.target.value; f.page = 1; ANI.renderExplorePage(root); };
    document.getElementById('efSort').onchange = function (e) { f.sort = e.target.value; ANI.renderExplorePage(root); };
    document.getElementById('efReset').onclick = function () { ANI.resetExplore(); ANI.renderExplorePage(root); };
    var more = document.getElementById('efMoreBtn');
    if (more) more.onclick = function () { f.page += 1; ANI.renderExplorePage(root); };
  };
})();
