/* 🧩 動漫與二次元學院 — 作畫分鏡課、二次元術語辭典與隨堂測驗 */
(function () {
  'use strict';
  var ANI = window.ANI;

  ANI.renderGuidePage = function (root) {
    var guide = window.ANI_GUIDE || { lessons: [], glossary: [], quiz: [] };
    var tab = ANI.state.guideTab || 'lessons';
    var qState = ANI.readJson(ANI.QUIZ_KEY, { answers: {} });
    if (!qState.answers) qState.answers = {};

    var body = '';
    if (tab === 'glossary') {
      body =
        '<div class="ani-search-row" style="margin-bottom:12px;">' +
          '<input id="aniGlossSearch" class="ani-input" placeholder="搜尋二次元術語（例：作畫、分鏡、劇伴、聖地巡禮）…" />' +
        '</div>' +
        '<div class="ani-grid-2" id="aniGlossGrid">' +
          (guide.glossary || []).map(function (g) {
            return '<div class="ani-studio-card" data-gloss="' + ANI.esc((g.term + ' ' + g.desc).toLowerCase()) + '"><b style="color:var(--accent-dark);font-size:15px;">' + ANI.esc(g.term) + '</b><p style="font-size:13.5px;color:var(--ink-muted);">' + ANI.esc(g.desc) + '</p></div>';
          }).join('') +
        '</div>';
    } else if (tab === 'quiz') {
      var qs = guide.quiz || [];
      var rightCnt = 0;
      var doneCnt = 0;
      qs.forEach(function (q, i) {
        if (qState.answers[i] != null) {
          doneCnt++;
          if (qState.answers[i] === q.ans) rightCnt++;
        }
      });
      body =
        '<div class="ani-panel" style="margin-bottom:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">' +
          '<div><b>🎯 作畫與二次元隨堂測驗</b>　已作答 <b>' + doneCnt + ' / ' + qs.length + '</b> 題，答對 <b style="color:var(--green);">' + rightCnt + '</b> 題</div>' +
          '<button type="button" class="ani-btn ani-btn-sm" id="aniQuizReset">🔄 重新測驗</button>' +
        '</div>' +
        qs.map(function (q, i) {
          var picked = qState.answers[i];
          var answered = picked != null;
          var optsHtml = q.opts.map(function (o, oi) {
            var cls = 'ani-quiz-opt';
            if (answered) {
              if (oi === q.ans) cls += ' correct';
              else if (oi === picked) cls += ' wrong';
            }
            return '<button type="button" class="' + cls + '" data-qi="' + i + '" data-oi="' + oi + '" ' + (answered ? 'disabled' : '') + '>' + String.fromCharCode(65 + oi) + '. ' + ANI.esc(o) + '</button>';
          }).join('');
          return (
            '<div class="ani-lesson">' +
              '<div style="font-weight:900;font-size:15px;">Q' + (i + 1) + '. ' + ANI.esc(q.q) + '</div>' +
              optsHtml +
              (answered ? '<div class="ani-plain-box" style="margin-top:10px;">' + (picked === q.ans ? '✅ 答對了！' : '💡 正解為 ' + String.fromCharCode(65 + q.ans) + '。') + ANI.esc(q.exp) + '</div>' : '') +
            '</div>'
          );
        }).join('');
    } else {
      body = (guide.lessons || []).map(function (l) {
        return (
          '<article class="ani-lesson">' +
            '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">' +
              '<span class="ani-chip ani-chip-accent">第 ' + ANI.esc(l.num) + ' 堂</span>' +
              '<h3 style="font-size:17px;font-weight:900;">' + ANI.esc(l.title) + '</h3>' +
            '</div>' +
            '<p class="ani-note" style="margin-top:5px;">' + ANI.esc(l.summary) + '</p>' +
            '<div class="ani-plain-box">🧒 <b>白話比喻：</b>' + ANI.esc(l.plain) + '</div>' +
            '<ul style="margin:8px 0 8px 18px;padding:0;font-size:14px;">' +
              (l.points || []).map(function (pt) { return '<li style="margin-bottom:4px;">' + ANI.esc(pt) + '</li>'; }).join('') +
            '</ul>' +
            '<div class="ani-takeaway-box">📝 一句話記住：' + ANI.esc(l.takeaway) + '</div>' +
          '</article>'
        );
      }).join('');
    }

    root.innerHTML =
      '<div class="ani-sec-hd"><div><h2>🧩 作畫分鏡與二次元文化課</h2><div class="ani-sec-sub">從零看懂原畫中割、分鏡演出、製作委員會與二次元社群術語</div></div></div>' +
      '<div class="ani-pills" style="margin-bottom:14px;">' +
        '<button type="button" class="ani-pill ' + (tab === 'lessons' ? 'active' : '') + '" data-gtab="lessons">📖 核心賞析課 (' + (guide.lessons || []).length + ')</button>' +
        '<button type="button" class="ani-pill ' + (tab === 'glossary' ? 'active' : '') + '" data-gtab="glossary">🗂️ 二次元辭典 (' + (guide.glossary || []).length + ')</button>' +
        '<button type="button" class="ani-pill ' + (tab === 'quiz' ? 'active' : '') + '" data-gtab="quiz">🎯 隨堂測驗 (' + (guide.quiz || []).length + ')</button>' +
      '</div>' +
      body;

    root.querySelectorAll('[data-gtab]').forEach(function (b) {
      b.onclick = function () { ANI.state.guideTab = b.getAttribute('data-gtab'); ANI.renderGuidePage(root); };
    });

    var gs = document.getElementById('aniGlossSearch');
    if (gs) {
      gs.oninput = function () {
        var q = gs.value.trim().toLowerCase();
        document.querySelectorAll('#aniGlossGrid [data-gloss]').forEach(function (el) {
          el.style.display = (!q || el.getAttribute('data-gloss').indexOf(q) !== -1) ? '' : 'none';
        });
      };
    }

    root.querySelectorAll('[data-qi]').forEach(function (b) {
      b.onclick = function () {
        var qi = Number(b.getAttribute('data-qi'));
        var oi = Number(b.getAttribute('data-oi'));
        qState.answers[qi] = oi;
        ANI.writeJson(ANI.QUIZ_KEY, qState);
        ANI.trackAct('quiz');
        ANI.renderGuidePage(root);
      };
    });

    var rst = document.getElementById('aniQuizReset');
    if (rst) {
      rst.onclick = function () {
        ANI.writeJson(ANI.QUIZ_KEY, { answers: {} });
        ANI.renderGuidePage(root);
      };
    }
  };
})();
