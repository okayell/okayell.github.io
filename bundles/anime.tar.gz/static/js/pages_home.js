/* 🎯 動漫與二次元學院 — 首頁入坑雷達與主題榜單 */
(function () {
  'use strict';
  var ANI = window.ANI;

  ANI.renderHomePage = function (root) {
    var catalog = ANI.getCatalog();
    var seasonal = ANI.getSeasonalPayload();
    var r = ANI.state.radar;

    var picks = catalog.filter(function (w) {
      if (ANI.statusOf(w.id) === 'done') return false;
      if (r.media !== 'all' && w.media !== r.media) return false;
      if (r.genre !== 'all' && (w.genres || []).indexOf(r.genre) === -1) return false;
      if (r.pace !== 'all' && (!w.entry || w.entry.pace !== r.pace)) return false;
      if (r.perfectOnly && (!w.ending || w.ending.verdict !== 'perfect')) return false;
      return true;
    }).slice(0, 8);

    var perfectList = catalog.filter(function (w) { return w.ending && w.ending.verdict === 'perfect'; }).slice(0, 4);
    var shortGems = catalog.filter(function (w) { return w.media !== 'manga' && w.episodes >= 10 && w.episodes <= 14; }).slice(0, 4);

    var mediaPills = [{ id: 'all', label: '全部媒介' }].concat(ANI.MEDIAS.map(function (m) { return { id: m.id, label: m.icon + ' ' + m.label }; }))
      .map(function (m) { return '<button type="button" class="ani-pill ' + (r.media === m.id ? 'active' : '') + '" data-rm="' + m.id + '">' + ANI.esc(m.label) + '</button>'; }).join('');

    var genreKeys = ['all', 'action', 'fantasy', 'thriller', 'scifi', 'slice', 'school', 'sports', 'music', 'dark', 'romcom'];
    var genrePills = genreKeys.map(function (g) {
      return '<button type="button" class="ani-pill ' + (r.genre === g ? 'active' : '') + '" data-rg="' + g + '">' + ANI.esc(g === 'all' ? '全部類型' : ANI.GENRES[g]) + '</button>';
    }).join('');

    var pacePills = [
      { id: 'all', label: '不限節奏' },
      { id: 'fast', label: '⚡ 開局高能' },
      { id: 'steady', label: '🎯 穩定推進' },
      { id: 'slow', label: '🍵 慢熱後勁' }
    ].map(function (p) {
      return '<button type="button" class="ani-pill ' + (r.pace === p.id ? 'active' : '') + '" data-rp="' + p.id + '">' + p.label + '</button>';
    }).join('');

    var decadeCards = ANI.DECADES.map(function (d) {
      var cnt = catalog.filter(function (w) { return w.decade === d.id; }).length;
      return (
        '<button type="button" class="ani-studio-card" style="text-align:left;" data-jump-decade="' + d.id + '">' +
          '<div style="display:flex;justify-content:space-between;align-items:center;">' +
            '<b style="font-size:16px;color:var(--accent-dark);">' + ANI.esc(d.label) + '</b>' +
            '<span class="ani-chip ani-chip-accent">' + cnt + ' 部</span>' +
          '</div>' +
          '<div class="ani-note">' + ANI.esc(d.sub) + '</div>' +
        '</button>'
      );
    }).join('');

    root.innerHTML =
      '<section class="ani-hero">' +
        '<h1>✧ 動漫與二次元學院</h1>' +
        '<p>每週自動同步當季新番表，橫跨 1980s–2020s 逾百部動畫＆漫畫無雷深度導讀；從作畫神回、監督分鏡到傳奇聲優，幫你精準挑出下一部停不下來的入坑神作。</p>' +
        '<div class="ani-hero-stats">' +
          '<div class="ani-hero-stat"><b>' + (seasonal.items || []).length + '</b> 部 ' + ANI.esc(seasonal.seasonLabel || '當季新番') + '</div>' +
          '<div class="ani-hero-stat"><b>' + catalog.length + '</b> 部跨世代無雷導讀</div>' +
          '<div class="ani-hero-stat"><b>' + (window.ANI_STUDIOS || []).length + '</b> 間頂尖動畫社檔案</div>' +
          '<div class="ani-hero-stat"><b>' + ((window.ANI_GUIDE && window.ANI_GUIDE.lessons) || []).length + '</b> 堂作畫分鏡課</div>' +
        '</div>' +
      '</section>' +

      '<section class="ani-radar-box">' +
        '<div class="ani-sec-hd" style="margin-top:0;"><div><h2>🎯 今天看什麼？入坑雷達</h2><div class="ani-sec-sub">自動避開你已補完的作品，點選條件即時推薦</div></div>' +
          '<button type="button" class="ani-link-btn" data-go-route="explore">瀏覽完整片庫 →</button>' +
        '</div>' +
        '<div class="ani-radar-row"><span class="ani-radar-lbl">媒介</span><div class="ani-pills">' + mediaPills + '</div></div>' +
        '<div class="ani-radar-row"><span class="ani-radar-lbl">類型</span><div class="ani-pills">' + genrePills + '</div></div>' +
        '<div class="ani-radar-row"><span class="ani-radar-lbl">節奏</span><div class="ani-pills">' + pacePills +
          '<button type="button" class="ani-pill ' + (r.perfectOnly ? 'active' : '') + '" id="aniRadarPerfect">🏆 只看神收尾</button>' +
        '</div></div>' +
        (picks.length
          ? '<div class="ani-grid" style="margin-top:14px;">' + picks.map(function (w) { return ANI.renderWorkCard(w, false); }).join('') + '</div>'
          : '<div class="ani-empty" style="margin-top:12px;"><b>沒有完全符合的作品</b>試著放寬一個篩選條件看看！</div>') +
      '</section>' +

      '<div class="ani-sec-hd"><div><h2>🕰️ 五個世代編年史入口</h2><div class="ani-sec-sub">點擊年代直接進入跨世代動漫庫</div></div></div>' +
      '<div class="ani-grid-3">' + decadeCards + '</div>' +

      '<div class="ani-sec-hd"><div><h2>🏆 零爛尾！公認神收尾必追榜</h2><div class="ani-sec-sub">結構完整、結局後勁滿分，放心一口氣追到底</div></div>' +
        '<button type="button" class="ani-link-btn" data-go-route="explore">看更多 →</button>' +
      '</div>' +
      '<div class="ani-grid">' + perfectList.map(function (w) { return ANI.renderWorkCard(w, false); }).join('') + '</div>' +

      '<div class="ani-sec-hd"><div><h2>⚡ 週末一口氣補完・一季 12 集精品</h2><div class="ani-sec-sub">篇幅精悍、密度極高，最適合週末兩天追完</div></div>' +
        '<button type="button" class="ani-link-btn" data-go-route="seasonal">去看當季新番 →</button>' +
      '</div>' +
      '<div class="ani-grid">' + shortGems.map(function (w) { return ANI.renderWorkCard(w, false); }).join('') + '</div>';

    root.querySelectorAll('[data-rm]').forEach(function (b) {
      b.onclick = function () { r.media = b.getAttribute('data-rm'); ANI.renderHomePage(root); };
    });
    root.querySelectorAll('[data-rg]').forEach(function (b) {
      b.onclick = function () { r.genre = b.getAttribute('data-rg'); ANI.renderHomePage(root); };
    });
    root.querySelectorAll('[data-rp]').forEach(function (b) {
      b.onclick = function () { r.pace = b.getAttribute('data-rp'); ANI.renderHomePage(root); };
    });
    var pf = document.getElementById('aniRadarPerfect');
    if (pf) pf.onclick = function () { r.perfectOnly = !r.perfectOnly; ANI.renderHomePage(root); };
    root.querySelectorAll('[data-jump-decade]').forEach(function (b) {
      b.onclick = function () {
        ANI.resetExplore();
        ANI.state.explore.decade = b.getAttribute('data-jump-decade');
        window.location.hash = '#/explore';
      };
    });
  };
})();
