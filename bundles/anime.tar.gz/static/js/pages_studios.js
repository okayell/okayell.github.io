/* 🎨 動漫與二次元學院 — 動畫製作公司、傳奇監督與聲優檔案 */
(function () {
  'use strict';
  var ANI = window.ANI;

  function workPills(ids) {
    var seen = {};
    return (ids || []).map(function (id) {
      if (seen[id]) return '';
      seen[id] = 1;
      var w = ANI.findWork(id);
      if (!w) return '';
      return '<button type="button" class="ani-work-link" data-open-work="' + ANI.esc(w.id) + '">《' + ANI.esc(w.title) + '》</button>';
    }).join('');
  }

  ANI.renderStudiosPage = function (root) {
    var tab = ANI.state.studiosTab || 'studios';
    var studios = window.ANI_STUDIOS || [];
    var dirs = window.ANI_DIRECTORS || [];
    var cvs = window.ANI_SEIYUU || [];

    var body = '';
    if (tab === 'directors') {
      body = '<div class="ani-grid-2">' + dirs.map(function (d) {
        return (
          '<article class="ani-studio-card">' +
            '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">' +
              '<h3 style="font-size:17px;font-weight:900;">🎬 ' + ANI.esc(d.name) + '</h3>' +
              '<span class="ani-chip ani-chip-pink">' + ANI.esc(d.role) + ' · ' + ANI.esc(d.era) + '</span>' +
            '</div>' +
            '<p style="font-size:13.8px;color:var(--ink);">' + ANI.esc(d.desc) + '</p>' +
            '<div class="ani-note"><b>招牌鏡頭語言：</b>' + ANI.esc(d.signature) + '</div>' +
            '<div class="ani-pills">' + workPills(d.works) + '</div>' +
          '</article>'
        );
      }).join('') + '</div>';
    } else if (tab === 'seiyuu') {
      body = '<div class="ani-grid-2">' + cvs.map(function (c) {
        return (
          '<article class="ani-studio-card">' +
            '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">' +
              '<h3 style="font-size:17px;font-weight:900;">🎙️ ' + ANI.esc(c.name) + ' <span class="ani-note">(' + ANI.esc(c.jp) + ')</span></h3>' +
              '<span class="ani-chip ani-chip-accent">' + ANI.esc(c.tag) + '</span>' +
            '</div>' +
            '<p style="font-size:13.8px;color:var(--ink);">' + ANI.esc(c.desc) + '</p>' +
            '<div class="ani-pills">' + workPills(c.works) + '</div>' +
          '</article>'
        );
      }).join('') + '</div>';
    } else {
      body = '<div class="ani-grid-2">' + studios.map(function (s) {
        return (
          '<article class="ani-studio-card">' +
            '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">' +
              '<h3 style="font-size:17px;font-weight:900;">🏢 ' + ANI.esc(s.name) + '</h3>' +
              '<span class="ani-chip ani-chip-accent">創立於 ' + s.founded + '</span>' +
            '</div>' +
            '<div><span class="ani-chip ani-chip-pink">' + ANI.esc(s.tag) + '</span> <span class="ani-note">' + ANI.esc(s.hq) + '</span></div>' +
            '<p style="font-size:13.8px;color:var(--ink);">' + ANI.esc(s.style) + '</p>' +
            '<div class="ani-note"><b>必看作畫特徵：</b>' + ANI.esc(s.signature) + '</div>' +
            '<div class="ani-pills">' + workPills(s.works) + '</div>' +
          '</article>'
        );
      }).join('') + '</div>';
    }

    root.innerHTML =
      '<div class="ani-sec-hd">' +
        '<div><h2>🎨 動畫製作公司、傳奇監督與聲優圖鑑</h2>' +
          '<div class="ani-sec-sub">記住這些神級團隊與創作者名字，以後挑新番一眼就能辨識作畫風格與品質保證；點作品名直接開導讀！</div>' +
        '</div>' +
      '</div>' +
      '<div class="ani-pills" style="margin-bottom:14px;">' +
        '<button type="button" class="ani-pill ' + (tab === 'studios' ? 'active' : '') + '" data-stab="studios">🏢 動畫製作公司 (' + studios.length + ')</button>' +
        '<button type="button" class="ani-pill ' + (tab === 'directors' ? 'active' : '') + '" data-stab="directors">🎬 傳奇監督 (' + dirs.length + ')</button>' +
        '<button type="button" class="ani-pill ' + (tab === 'seiyuu' ? 'active' : '') + '" data-stab="seiyuu">🎙️ 經典聲優 (' + cvs.length + ')</button>' +
      '</div>' +
      body;

    root.querySelectorAll('[data-stab]').forEach(function (b) {
      b.onclick = function () {
        ANI.state.studiosTab = b.getAttribute('data-stab');
        ANI.renderStudiosPage(root);
      };
    });
  };
})();
