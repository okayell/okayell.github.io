"""Analytics + API payload builders (universe, market, picks, industries, stock detail)."""
from __future__ import annotations

import datetime as dt
import json
import math
import os
import threading
import time
from typing import Any

import config
import db
import etf_hub
import morning
import scoring
import ta
from sources import news as news_src

TZ = dt.timezone(dt.timedelta(hours=8))

FIELDS = ['code', 'name', 'market', 'industry', 'type', 'close', 'chg', 'pct', 'open', 'high', 'low',
          'vol', 'value', 'r5', 'r20', 'r60', 'r120', 'r250', 'hi52', 'lo52', 'dist_hi52', 'ma_bits',
          'ma20', 'ma60', 'rsi', 'k', 'd', 'macd_hist', 'bias20', 'vol_ratio', 'atr_pct', 'pe', 'pb',
          'yld', 'eps_ttm', 'eps_q', 'eps_q_label', 'rev_ym', 'rev_yoy', 'rev_mom', 'rev_cum_yoy',
          'rev_high', 'f1', 't1', 'd1', 'f5', 't5', 'd5', 'f20', 't20', 'chip', 'streak_f', 'streak_t',
          'score', 'rank', 'f_chip', 'f_rev', 'f_mom', 'f_vol', 'f_val', 'tech_score', 'signals',
          'risk', 'mcap']

_LOCK = threading.RLock()
_MEM: dict[str, Any] = {'version': 0, 'rows': {}, 'payloads': {}, 'chains': None,
                        'chains_mtime': 0.0}
TAIEX = '發行量加權股價指數'


def _r(x: float | None, nd: int = 2) -> float | None:
  if x is None or not isinstance(x, (int, float)) or not math.isfinite(x):
    return None
  return round(float(x), nd)


def _now_iso() -> str:
  return dt.datetime.now(TZ).isoformat(timespec='seconds')


# ------------------------------------------------------------------ loading --

def adjust_rows(rows: list[tuple], exr: dict[str, float] | None = None) -> list[list]:
  """Back-adjusts (還原權息) rows (date, o, h, l, c, vol, value, chg).

  Returns [date, o, h, l, c, vol] with past prices scaled so ex-rights gaps vanish.
  """
  n = len(rows)
  factors = [1.0] * n
  for t in range(1, n):
    prev = rows[t - 1][4]
    c, chg = rows[t][4], rows[t][7]
    if not prev or prev <= 0:
      continue
    if chg is not None:
      ref = c - chg
    elif exr and rows[t][0] in exr:
      ref = prev - exr[rows[t][0]]
    else:
      continue
    f = ref / prev
    if abs(f - 1) > 0.002 and 0.2 < f < 5:
      factors[t] = f
  out: list[list] = [None] * n  # type: ignore
  cum = 1.0
  for t in range(n - 1, -1, -1):
    d, o, h, l, c, v = rows[t][:6]
    out[t] = [d, round(o * cum, 4), round(h * cum, 4), round(l * cum, 4), round(c * cum, 4), v]
    cum *= factors[t]
  return out


def load_all_bars(days: int = 320) -> tuple[list[str], dict[str, list[tuple]]]:
  dates = db.trading_dates()
  dates = dates[-days:]
  if not dates:
    return [], {}
  rows = db.query('SELECT code, date, open, high, low, close, vol, value, chg FROM daily '
                  'WHERE date >= ? ORDER BY code, date', (dates[0],))
  by: dict[str, list[tuple]] = {}
  for r in rows:
    by.setdefault(r[0], []).append(r[1:])
  return dates, by


def load_exrights() -> dict[str, dict[str, float]]:
  out: dict[str, dict[str, float]] = {}
  for code, date, _, amount in db.query('SELECT code, date, kind, amount FROM exrights'):
    if amount:
      out.setdefault(code, {})[date] = amount
  return out


def load_chains() -> dict[str, Any] | None:
  try:
    mt = os.path.getmtime(config.CHAINS_PATH)
  except OSError:
    return None
  with _LOCK:
    if _MEM['chains'] is not None and _MEM['chains_mtime'] == mt:
      return _MEM['chains']
  with open(config.CHAINS_PATH, encoding='utf-8') as f:
    data = json.load(f)
  with _LOCK:
    _MEM['chains'], _MEM['chains_mtime'] = data, mt
  return data


# ------------------------------------------------------------ build_all -----

def build_all(progress: Any = None, is_intraday: bool | None = None,
              quote_time: str | None = None) -> dict[str, Any]:
  """Recomputes every snapshot; writes JSON files and refreshes the memory cache."""
  t0 = time.time()

  def step(msg: str, p: float) -> None:
    if progress is not None:
      progress.set(step='計算指標與推薦', message=msg, progress=p)

  step('載入資料', 0.05)
  dates, bars_by = load_all_bars(320)
  if not dates:
    return {}
  data_date = dates[-1]
  exr = load_exrights()
  stocks = {r[0]: r for r in db.query(
      'SELECT code, name, market, type, industry, industry_code, shares FROM stocks')}
  # Industry fallback via industry_code mapping learned from revenue-derived names.
  code_map: dict[str, str] = {}
  for _, _, _, _, ind, icode, _ in stocks.values():
    if ind and icode and icode not in code_map:
      code_map[icode] = ind
  flags = db.get_kv('flags', {}) or {}
  inst_dates = [r[0] for r in db.query('SELECT DISTINCT date FROM inst ORDER BY date')][-60:]
  inst_by: dict[str, dict[str, tuple]] = {}
  if inst_dates:
    for code, date, f, t, d in db.query(
        'SELECT code, date, foreign_net, trust_net, dealer_net FROM inst WHERE date >= ?',
        (inst_dates[0],)):
      inst_by.setdefault(code, {})[date] = (f or 0.0, t or 0.0, d or 0.0)
  val_rows = db.query('SELECT v.code, v.pe, v.pb, v.yld FROM valuation v JOIN '
                      '(SELECT code, MAX(date) md FROM valuation GROUP BY code) m '
                      'ON v.code = m.code AND v.date = m.md')
  valuation = {r[0]: r[1:] for r in val_rows}
  revs_by: dict[str, list[tuple]] = {}
  for r in db.query('SELECT code, ym, rev, mom, yoy, cum_rev, cum_yoy FROM revenue ORDER BY code, ym'):
    revs_by.setdefault(r[0], []).append(r[1:])
  eps_by: dict[str, list[tuple]] = {}
  for r in db.query('SELECT code, q, cum_eps, cum_rev, cum_op, cum_ni FROM eps ORDER BY code, q'):
    eps_by.setdefault(r[0], []).append(r[1:])
  eps_single = {c: scoring.eps_singles(v) for c, v in eps_by.items()}

  step('計算技術指標', 0.15)
  rows: dict[str, dict[str, Any]] = {}
  adj_by: dict[str, list[list]] = {}
  for code, raw in bars_by.items():
    st = stocks.get(code)
    if not st or len(raw) < 5:
      continue
    adj = adjust_rows(raw, exr.get(code))
    adj_by[code] = adj
    row = _universe_row(code, st, raw, adj, data_date, inst_dates, inst_by.get(code, {}),
                        valuation.get(code), revs_by.get(code, []), eps_single.get(code, []),
                        flags.get(code, []), code_map)
    if row:
      rows[code] = row
  step('計算綜合分數', 0.55)
  ranked = scoring.score_universe(rows)
  n_elig = len(ranked)
  for c in ranked:
    rows[c]['_reasons'], rows[c]['_risks'] = scoring.reasons_for(rows[c], n_elig)

  step('產生今日推薦', 0.65)
  picks = _build_picks(rows, ranked, adj_by, data_date)
  step('回測模型績效', 0.75)
  bench = {d: c for d, c in db.query('SELECT date, close FROM index_daily WHERE name=?', (TAIEX,))}
  series = _backtest_series(rows, adj_by, inst_dates, inst_by, revs_by, eps_single, dates)
  bt = scoring.backtest(series, bench, dates) if series else {}
  picks_payload = _picks_payload(picks, bt, rows, adj_by, data_date, bench, dates)
  step('整理市場、ETF 與盤前資料', 0.88)
  etfs_payload = etf_hub.build_etfs_payload(rows, bars_by, data_date, dates)
  market = _market_payload(rows, data_date, dates)
  industries = _industries_payload(rows, data_date)
  morning_payload = morning.build_morning_briefing(rows, picks_payload, market, force_network=False)
  universe = {'date': data_date, 'fields': FIELDS,
              'rows': [[_jsonable(rows[c].get(f)) for f in FIELDS] for c in sorted(rows)]}
  meta_counts = {'stocks': sum(1 for r in rows.values() if r['type'] == '股票'),
                 'etfs': sum(1 for r in rows.values() if r['type'] == 'ETF'),
                 'eligible': n_elig, 'days': len(dates)}
  if is_intraday is None:
    today_s = dt.datetime.now(TZ).date().isoformat()
    is_intraday = bool(data_date == today_s and not db.fetched('twse_quotes', data_date))
  if is_intraday and not quote_time:
    prev_an = db.get_kv('analytics', {}) or {}
    if prev_an.get('data_date') == data_date and prev_an.get('quote_time'):
      quote_time = prev_an.get('quote_time')
  market['is_intraday'] = bool(is_intraday)
  if quote_time and is_intraday:
    market['quote_time'] = quote_time
  payloads = {'universe': universe, 'market': market, 'picks': picks_payload,
              'industries': industries, 'etfs': etfs_payload, 'morning': morning_payload}
  os.makedirs(config.SNAP_DIR, exist_ok=True)
  payloads_disk = dict(payloads)
  payloads_disk['reasons'] = {c: [rows[c].get('_reasons') or [], rows[c].get('_risks') or []]
                              for c in ranked}
  for k, v in payloads_disk.items():
    tmp = os.path.join(config.SNAP_DIR, f'{k}.json.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
      json.dump(v, f, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    os.replace(tmp, os.path.join(config.SNAP_DIR, f'{k}.json'))
  slim_rows = {c: dict(r) for c, r in rows.items()}
  with _LOCK:
    _MEM['rows'] = slim_rows
    _MEM['payloads'] = payloads
    _MEM['version'] += 1
  db.set_kv('analytics', {'data_date': data_date, 'updated_at': _now_iso(), 'counts': meta_counts,
                          'is_intraday': bool(is_intraday),
                          'quote_time': quote_time if is_intraday else None,
                          'seconds': round(time.time() - t0, 1)})
  step(f'完成（{time.time() - t0:.0f} 秒）', 1.0)
  return payloads


def _jsonable(v: Any) -> Any:
  if isinstance(v, float):
    return v if math.isfinite(v) else None
  if isinstance(v, set):
    return sorted(v)
  return v


def _ret(closes: list[float], n: int) -> float | None:
  if len(closes) <= n or not closes[-n - 1]:
    return None
  return _r((closes[-1] / closes[-n - 1] - 1) * 100)


def _universe_row(code, st, raw, adj, data_date, inst_dates, inst, val, revs, eps_s, flag_list,
                  code_map) -> dict[str, Any] | None:
  _, name, market, typ, industry, icode, shares = st
  last = raw[-1]
  date, o, h, l, c, vol, value, chg = last
  prev = raw[-2][4] if len(raw) > 1 else None
  if chg is None and prev:
    chg = c - prev
  base = (c - chg) if chg is not None else prev
  pct = (chg / base * 100) if chg is not None and base else None
  closes = [b[4] for b in adj]
  vols = [b[5] or 0.0 for b in adj]
  tail = adj[-260:]
  ind = ta.compute_indicators(tail)
  qs = ta.quick_signals(tail, ind)

  def lastv(key):
    arr = ind.get(key) or []
    return arr[-1] if arr else None

  hi52 = max(b[2] for b in adj[-250:])
  lo52 = min(b[3] for b in adj[-250:])
  v20 = vols[-20:]
  avg20 = sum(v20) / len(v20) if v20 else 0.0
  avg5 = sum(vols[-5:]) / min(5, len(vols)) if vols else 0.0
  ma20, ma60 = lastv('ma20'), lastv('ma60')
  ma20_arr = ind.get('ma20') or []
  ma20_slope = None
  if len(ma20_arr) > 5 and ma20_arr[-1] and ma20_arr[-6]:
    ma20_slope = (ma20_arr[-1] / ma20_arr[-6] - 1) * 100
  volat = scoring.rolling_volatility(closes[-21:], 20)[-1] if len(closes) > 21 else None
  row: dict[str, Any] = {
      'code': code, 'name': name, 'market': market, 'type': typ,
      'industry': industry or code_map.get(icode or '', '') or ('ETF' if typ == 'ETF' else '其他'),
      'close': _r(c), 'chg': _r(chg), 'pct': _r(pct), 'open': _r(o), 'high': _r(h), 'low': _r(l),
      'vol': round(vol or 0), 'value': _r((value or 0) / 1e8),
      'r5': _ret(closes, 5), 'r20': _ret(closes, 20), 'r60': _ret(closes, 60),
      'r120': _ret(closes, 120), 'r250': _ret(closes, 250),
      'hi52': _r(hi52), 'lo52': _r(lo52), 'dist_hi52': _r((closes[-1] / hi52 - 1) * 100) if hi52 else None,
      'ma_bits': qs.get('ma_bits'), 'ma20': _r(ma20), 'ma60': _r(ma60),
      'rsi': _r(lastv('rsi14'), 1), 'k': _r(lastv('k'), 1), 'd': _r(lastv('d'), 1),
      'macd_hist': _r(lastv('hist'), 3),
      'bias20': _r((closes[-1] / ma20 - 1) * 100) if ma20 else None,
      'vol_ratio': _r(avg5 / avg20) if avg20 else None,
      'atr_pct': _r((qs.get('atr') or 0) / c * 100) if c and qs.get('atr') else None,
      'tech_score': qs.get('tech_score'),
      '_avg_vol20': avg20, '_vol20_sum': sum(v20), '_bars': len(adj), '_last_date': date,
      '_ma20_slope': ma20_slope, '_volat20': volat,
      '_support': qs.get('support'), '_resistance': qs.get('resistance'),
  }
  if val:
    row['pe'], row['pb'], row['yld'] = _r(val[0]), _r(val[1]), _r(val[2])
  row.update({k: v for k, v in scoring.revenue_features(revs).items()})
  ef = scoring.eps_features(eps_s)
  row.update({k: v for k, v in ef.items() if k in ('eps_q', 'eps_q_label', 'eps_ttm')})
  # 法人
  f_arr = [inst.get(d, (0.0, 0.0, 0.0)) for d in inst_dates]
  if inst_dates:
    fs, ts, ds = [x[0] for x in f_arr], [x[1] for x in f_arr], [x[2] for x in f_arr]
    row.update({'f1': round(fs[-1]), 't1': round(ts[-1]), 'd1': round(ds[-1]),
                'f5': round(sum(fs[-5:])), 't5': round(sum(ts[-5:])), 'd5': round(sum(ds[-5:])),
                'f20': round(sum(fs[-20:])), 't20': round(sum(ts[-20:])),
                'streak_f': scoring.streak(fs), 'streak_t': scoring.streak(ts)})
    vsum = row['_vol20_sum']
    row['chip'] = _r((sum(fs[-20:]) + sum(ts[-20:])) / vsum * 100) if vsum else None
    row['_chip_raw'] = scoring.chip_raw(sum(fs[-20:]), sum(ts[-20:]), vsum)
  if shares and c:
    row['mcap'] = _r(c * shares * 0.1, 1)
  # Risk + extra signals
  risk = list(flag_list)
  if ((row.get('bias20') or 0) > 20 or (row.get('r5') or 0) > 25 or (row.get('rsi') or 0) > 85):
    risk.append('過熱')
  if avg20 < 100 and typ == '股票':
    risk.append('流動性不足')
  if row.get('eps_ttm') is not None and row['eps_ttm'] < 0:
    risk.append('虧損')
  row['risk'] = risk
  sig = list(qs.get('signals') or [])
  if (row.get('streak_f') or 0) >= 3:
    sig.append('外資連買')
  if (row.get('streak_t') or 0) >= 3:
    sig.append('投信連買')
  if (row.get('f5') or 0) > 0 and (row.get('t5') or 0) > 0:
    sig.append('法人同買')
  if (row.get('t1') or 0) > 0 and vol and row['t1'] / max(vol, 1) >= 0.05:
    sig.append('投信大買')
  if row.get('rev_high'):
    sig.append('營收創高')
  if (row.get('rev_yoy') or 0) >= 30:
    sig.append('營收高成長')
  if ef.get('eps_yoy_up'):
    sig.append('EPS成長')
  if (row.get('yld') or 0) >= 5:
    sig.append('高殖利率')
  row['signals'] = sig
  return row


# ------------------------------------------------------------------ picks ---

def _build_picks(rows, ranked, adj_by, data_date) -> list[dict[str, Any]]:
  picks, per_ind = [], {}
  for code in ranked:
    if len(picks) >= config.PICK_TOP_N:
      break
    r = rows[code]
    ind = r.get('industry') or ''
    if per_ind.get(ind, 0) >= 4:          # diversify: ≤ 4 picks per industry
      continue
    per_ind[ind] = per_ind.get(ind, 0) + 1
    adj = adj_by[code][-500:]
    try:
      an = ta.analyze(adj, tf='D')
    except Exception:  # pylint: disable=broad-except
      an = {}
    plan = an.get('plan') or {}
    sups = (an.get('levels') or {}).get('supports') or []
    ress = (an.get('levels') or {}).get('resistances') or []
    targets = [t for t in (plan.get('targets') or []) if t and t > (r['close'] or 0)]
    stop = plan.get('stop')
    close = r['close'] or 0
    target, rr = (targets[0] if targets else None), None
    if stop and close > stop:
      for t in targets:
        target = t
        rr = (t - close) / (close - stop)
        if rr >= 1.2:
          break
    levels = {'support': _r(sups[0]['price']) if sups else _r(r.get('_support')),
              'resistance': _r(ress[0]['price']) if ress else _r(r.get('_resistance')),
              'stop': _r(stop), 'target': _r(target), 'rr': _r(rr, 1)}
    picks.append({
        'code': code, 'name': r['name'], 'market': r['market'], 'industry': ind,
        'close': r['close'], 'pct': r['pct'], 'score': r['score'], 'rank': len(picks) + 1,
        'factors': {k: r.get(f'f_{k}') for k in ('chip', 'rev', 'mom', 'vol', 'val')},
        'reasons': r.get('_reasons') or [], 'risks': r.get('_risks') or [],
        'levels': levels,
        'tech': {'stance': an.get('stance'), 'score': an.get('score'), 'summary': an.get('summary')},
        'tech_score': r.get('tech_score'),
        'signals': r.get('signals') or [],
        'spark': [_r(b[4]) for b in adj_by[code][-60:]],
    })
  db.execute('DELETE FROM picks WHERE date=?', (data_date,))
  db.upsert_many('picks', ('date', 'rank', 'code', 'score', 'close', 'data'),
                 [(data_date, p['rank'], p['code'], p['score'], p['close'],
                   json.dumps({'name': p['name'], 'industry': p['industry']}, ensure_ascii=False))
                  for p in picks])
  return picks


def _backtest_series(rows, adj_by, inst_dates, inst_by, revs_by, eps_single, dates):
  # Full-history institutional data for the backtest window.
  all_inst: dict[str, dict[str, tuple]] = {}
  for code, date, f, t in db.query('SELECT code, date, foreign_net, trust_net FROM inst'):
    all_inst.setdefault(code, {})[date] = (f or 0.0, t or 0.0)
  series = {}
  for code, r in rows.items():
    if r['type'] != '股票' or code not in adj_by:
      continue
    adj = adj_by[code]
    ds = [b[0] for b in adj]
    inst = all_inst.get(code, {})
    series[code] = {'dates': ds, 'close': [b[4] for b in adj], 'vol': [b[5] or 0.0 for b in adj],
                    'f': [inst.get(d, (0.0, 0.0))[0] for d in ds],
                    't': [inst.get(d, (0.0, 0.0))[1] for d in ds],
                    'revs': revs_by.get(code, []), 'eps': eps_single.get(code, []), 'type': '股票'}
  # Only test the period that has institutional coverage.
  covered = sorted({d for v in all_inst.values() for d in v})
  if len(covered) < 90:
    return {}
  return series


def _picks_payload(picks, bt, rows, adj_by, data_date, bench, dates) -> dict[str, Any]:
  history = []
  live_dates = [r[0] for r in db.query('SELECT DISTINCT date FROM picks WHERE date < ? ORDER BY date DESC LIMIT 20', (data_date,))]

  def adj_close_on(code, d):
    for b in reversed(adj_by.get(code, [])):
      if b[0] <= d:
        return b[4]
    return None

  def hist_entry(d, codes, kind):
    items, rets = [], []
    for code in codes:
      if code not in rows:
        continue
      a, b = adj_close_on(code, d), (adj_by[code][-1][4] if adj_by.get(code) else None)
      ret = _r((b / a - 1) * 100) if a and b else None
      if ret is not None:
        rets.append(ret)
      items.append({'code': code, 'name': rows[code]['name'], 'entry': _r(a), 'last': _r(b), 'ret': ret})
    bm = None
    if bench.get(d) and bench.get(data_date):
      bm = _r((bench[data_date] / bench[d] - 1) * 100)
    return {'date': d, 'kind': kind, 'avg_ret': _r(sum(rets) / len(rets)) if rets else None,
            'bench_ret': bm, 'items': items}

  for d in live_dates:
    codes = [r[0] for r in db.query('SELECT code FROM picks WHERE date=? ORDER BY rank', (d,))]
    history.append(hist_entry(d, codes, '實盤'))
  sim = (bt or {}).get('_picks_by_day') or {}
  live_set = set(live_dates)
  sim_days = [d for d in sorted(sim) if d not in live_set and d < data_date][-max(0, 20 - len(history)):]
  for d in reversed(sim_days):
    history.append(hist_entry(d, sim[d], '回測'))
  history.sort(key=lambda h: h['date'], reverse=True)
  bt_out = {k: v for k, v in (bt or {}).items() if not k.startswith('_')}
  return {
      'date': data_date, 'picks': picks,
      'method': {
          'weights': config.WEIGHTS,
          'filters': [f'20 日均量 ≥ {config.MIN_AVG_VOL20} 張', f'股價 ≥ {config.MIN_PRICE:.0f} 元',
                      '僅普通股（排除 ETF、特別股、DR）', '排除處置 / 注意 / 全額交割股',
                      f'至少 {config.MIN_HISTORY} 個交易日資料', '同一產業最多 4 檔（分散風險）'],
          'text': ('每天收盤後，系統對所有上市櫃普通股計算因子並換算成全市場百分位：'
                   '① 籌碼強度 40%（近 20 日投信買超占成交量比例為主、外資為輔——投信研究團隊通常鎖定基本面轉強的中小型股）、'
                   '② 月營收動能 40%（最新月營收年增率、累計年增率、近 3 月營收是否創 12 個月新高）、'
                   '③ 技術趨勢 20%（距 52 週高點、月線斜率、是否站上月線，乖離過大扣分）。'
                   '「價值（本益比、殖利率）」與「穩定度（波動度）」只顯示供參考、不計分。'
                   '加權後扣除過熱與虧損的懲罰分數，取前 20 名（同產業最多 4 檔）作為「今日推薦」。'
                   '此組合源自 FinLab「籌碼強度 × 月營收動能」研究（單純追投信買超效果有限，加上營收創高把關才有顯著超額報酬），'
                   '並以本站 2026 年 3–10 月資料做逐日回測驗證：在多種權重組合中，此組合的超額報酬最高且最穩定。'),
      },
      'backtest': bt_out, 'history': history, 'disclaimer': config.DISCLAIMER,
  }


# --------------------------------------------------------------- market -----

def _market_payload(rows, data_date, dates) -> dict[str, Any]:
  idx = {}
  for name in (TAIEX, '櫃買指數'):
    ser = db.query('SELECT date, close, chg, pct FROM index_daily WHERE name=? ORDER BY date', (name,))
    if ser:
      last = ser[-1]
      idx[name] = {'close': _r(last[1]), 'chg': _r(last[2]), 'pct': _r(last[3]), 'date': last[0],
                   'series': [[d, _r(c)] for d, c, _, _ in ser[-250:]]}
  mrow = db.query_one('SELECT data FROM market WHERE date=?', (data_date,))
  m = json.loads(mrow[0]) if mrow else {}
  stocks = [r for r in rows.values() if r['type'] == '股票' and r.get('_last_date') == data_date]
  up = sum(1 for r in stocks if (r.get('pct') or 0) > 0)
  down = sum(1 for r in stocks if (r.get('pct') or 0) < 0)
  breadth = {'up': up, 'down': down, 'flat': len(stocks) - up - down,
             'limit_up': sum(1 for r in stocks if (r.get('pct') or 0) >= 9.5),
             'limit_down': sum(1 for r in stocks if (r.get('pct') or 0) <= -9.5)}
  it = m.get('inst_twse') or {}
  tp = m.get('inst_tpex') or {}
  inst_date = data_date
  if not it:
    for prev_d, prev_raw in db.query(
        'SELECT date, data FROM market WHERE date < ? ORDER BY date DESC LIMIT 5',
        (data_date,)):
      try:
        pm = json.loads(prev_raw) if prev_raw else {}
      except ValueError:
        pm = {}
      if pm.get('inst_twse'):
        it = pm.get('inst_twse') or {}
        tp = pm.get('inst_tpex') or {}
        inst_date = prev_d
        break
  inst = None
  if it:
    inst = {'date': inst_date, 'foreign': it.get('foreign'), 'trust': it.get('trust'),
            'dealer': it.get('dealer'), 'total': it.get('total'),
            'tpex': {k: tp.get(k) for k in ('foreign', 'trust', 'dealer', 'total')} if tp else None}
  sectors = _sector_stats(stocks)
  liquid = [r for r in stocks if (r.get('value') or 0) >= 1]
  hot = {
      'gainers': [_mini(r) for r in sorted(liquid, key=lambda r: -(r.get('pct') or 0))[:10]],
      'losers': [_mini(r) for r in sorted(liquid, key=lambda r: (r.get('pct') or 0))[:10]],
      'value': [_mini(r) for r in sorted(stocks, key=lambda r: -(r.get('value') or 0))[:10]],
  }
  return {'date': data_date, 'taiex': idx.get(TAIEX), 'otc': idx.get('櫃買指數'),
          'turnover': {'twse': _r((m.get('twse_value') or 0) / 1e8, 1),
                       'tpex': _r((m.get('tpex_value') or 0) / 1e8, 1)},
          'breadth': breadth, 'inst': inst, 'sectors': sectors, 'hot': hot,
          'news': market_news_cached()}


def _mini(r) -> dict[str, Any]:
  return {'code': r['code'], 'name': r['name'], 'close': r['close'], 'pct': r['pct'],
          'value': r['value'], 'industry': r.get('industry')}


def _wavg(items, key) -> float | None:
  num = den = 0.0
  for r in items:
    v, w = r.get(key), r.get('value') or 0
    if v is None:
      continue
    num += v * (w + 0.01)
    den += w + 0.01
  return _r(num / den) if den else None


def _sector_stats(stocks) -> list[dict[str, Any]]:
  by: dict[str, list] = {}
  for r in stocks:
    by.setdefault(r.get('industry') or '其他', []).append(r)
  total_value = sum(r.get('value') or 0 for r in stocks) or 1.0
  out = []
  for name, items in by.items():
    value = sum(r.get('value') or 0 for r in items)
    pes = sorted(r['pe'] for r in items if r.get('pe') and r['pe'] > 0)
    ylds = [r['yld'] for r in items if r.get('yld') is not None]
    leaders = sorted(items, key=lambda r: -(r.get('value') or 0))[:3]
    out.append({'name': name, 'count': len(items), 'pct_1d': _wavg(items, 'pct'),
                'pct_5d': _wavg(items, 'r5'), 'pct_20d': _wavg(items, 'r20'),
                'value': _r(value, 1), 'value_share': _r(value / total_value * 100, 1),
                'up': sum(1 for r in items if (r.get('pct') or 0) > 0),
                'down': sum(1 for r in items if (r.get('pct') or 0) < 0),
                'avg_pe': _r(pes[len(pes) // 2], 1) if pes else None,
                'avg_yld': _r(sum(ylds) / len(ylds)) if ylds else None,
                'leaders': [{'code': r['code'], 'name': r['name'], 'pct': r['pct']} for r in leaders],
                'top': [r['code'] for r in leaders]})
  out.sort(key=lambda s: -(s['value'] or 0))
  return out


_NEWS_CACHE: dict[str, Any] = {'t': 0.0, 'items': []}


def market_news_cached(max_age: float = 1800) -> list[dict[str, Any]]:
  if time.time() - _NEWS_CACHE['t'] < max_age and _NEWS_CACHE['items']:
    return _NEWS_CACHE['items']
  try:
    items = news_src.market_news(20)
    _NEWS_CACHE.update(t=time.time(), items=items)
  except Exception:  # pylint: disable=broad-except
    _NEWS_CACHE['t'] = time.time() - max_age + 300   # retry in 5 minutes
  return _NEWS_CACHE['items']


# ------------------------------------------------------------- industries ---

def _industries_payload(rows, data_date) -> dict[str, Any]:
  stocks = [r for r in rows.values() if r['type'] == '股票']
  cats = _sector_stats(stocks)
  chains_out = []
  ch = load_chains()
  if ch:
    for c in ch.get('chains', []):
      codes = set()
      for seg in (c.get('segments') or {}).values():
        for g in seg.get('groups') or []:
          for co in g.get('companies') or []:
            if co.get('code'):
              codes.add(co['code'])
      members = [rows[x] for x in codes if x in rows]
      chains_out.append({'id': c['id'], 'name': c['name'], 'companies': len(codes),
                         'listed': len(members), 'pct_1d': _wavg(members, 'pct'),
                         'pct_5d': _wavg(members, 'r5'), 'pct_20d': _wavg(members, 'r20'),
                         'value': _r(sum(m.get('value') or 0 for m in members), 1),
                         'streams': [s['name'] for s in c.get('streams') or []]})
  return {'date': data_date, 'categories': cats, 'chains': chains_out}


def chain_detail(chain_id: str) -> dict[str, Any] | None:
  ch = load_chains()
  if not ch:
    return None
  c = next((x for x in ch.get('chains', []) if x['id'] == chain_id), None)
  if not c:
    return None
  rows = get_rows()
  chain_names = {x['id']: x['name'] for x in ch.get('chains', [])}
  streams = []
  for s in c.get('streams') or []:
    segs = []
    for sid in s.get('segments') or []:
      seg = (c.get('segments') or {}).get(sid)
      if not seg:
        continue
      comps, others, seen = [], [], set()
      for g in seg.get('groups') or []:
        for co in g.get('companies') or []:
          code = co.get('code')
          if code and code in rows and code not in seen:
            seen.add(code)
            r = rows[code]
            comps.append({'code': code, 'name': r['name'], 'market': r['market'], 'group': g.get('label'),
                          'close': r['close'], 'pct': r['pct'], 'r20': r.get('r20'),
                          'value': r.get('value'), 'score': r.get('score')})
          elif not code or code not in rows:
            others.append({'name': co.get('name'), 'group': g.get('label')})
      comps.sort(key=lambda x: -(x.get('value') or 0))
      subs = []
      for sub in seg.get('subs') or []:
        scodes = []
        for g in sub.get('groups') or []:
          for co in g.get('companies') or []:
            if co.get('code') and co['code'] in rows:
              scodes.append(co['code'])
        subs.append({'id': sub.get('id'), 'name': sub.get('name'), 'codes': scodes})
      member_rows = [rows[x['code']] for x in comps]
      ref = seg.get('ref')
      segs.append({'id': sid, 'name': seg.get('name'), 'title': seg.get('title') or seg.get('name'),
                   'desc': seg.get('desc') or [], 'placeholder': bool(seg.get('placeholder')),
                   'ref': ref, 'ref_name': chain_names.get(ref) if ref else None,
                   'pct_1d': _wavg(member_rows, 'pct'), 'pct_20d': _wavg(member_rows, 'r20'),
                   'companies': comps, 'others': others[:80], 'subs': subs})
    streams.append({'name': s['name'], 'caption': s.get('caption') or '', 'desc': s.get('desc') or [],
                    'segments': segs})
  return {'id': c['id'], 'name': c['name'], 'url': c.get('url'),
          'source': ch.get('source') or '櫃買中心 產業價值鏈資訊平台',
          'intro': c.get('intro') or [], 'trends': c.get('trends') or [], 'streams': streams}


# ------------------------------------------------------------ memory API ----

def get_rows() -> dict[str, dict[str, Any]]:
  with _LOCK:
    rows = _MEM['rows']
  if not rows:
    _load_from_disk()
    with _LOCK:
      rows = _MEM['rows']
  return rows


def get_payload(name: str) -> dict[str, Any] | None:
  with _LOCK:
    p = _MEM['payloads'].get(name)
  if p is None:
    _load_from_disk()
    with _LOCK:
      p = _MEM['payloads'].get(name)
  return p


def version() -> int:
  with _LOCK:
    return _MEM['version']


def _load_from_disk() -> None:
  payloads = {}
  for k in ('universe', 'market', 'picks', 'industries', 'etfs', 'morning'):
    fp = os.path.join(config.SNAP_DIR, f'{k}.json')
    try:
      with open(fp, encoding='utf-8') as f:
        payloads[k] = json.load(f)
    except (OSError, ValueError):
      pass
  rows = {}
  u = payloads.get('universe')
  if u:
    fields = u['fields']
    for r in u['rows']:
      d = dict(zip(fields, r))
      rows[d['code']] = d
  try:
    with open(os.path.join(config.SNAP_DIR, 'reasons.json'), encoding='utf-8') as f:
      for code, (rs, rk) in json.load(f).items():
        if code in rows:
          rows[code]['_reasons'], rows[code]['_risks'] = rs, rk
  except (OSError, ValueError):
    pass
  if payloads:
    with _LOCK:
      if not _MEM['payloads']:
        _MEM['payloads'] = payloads
        _MEM['rows'] = rows
        _MEM['version'] += 1


# ----------------------------------------------------------- stock detail ---

RANGE_BARS = {'D': {'3m': 66, '6m': 130, '1y': 250, '2y': 500, '5y': 1250},
              'W': {'3m': 14, '6m': 27, '1y': 53, '2y': 105, '5y': 262},
              'M': {'3m': 4, '6m': 7, '1y': 13, '2y': 25, '5y': 61}}


def stock_bars(code: str, long: bool = False) -> list[list]:
  """Adjusted daily bars for one stock (optionally extended with FinMind history)."""
  if long:
    ensure_long_history(code)
  raw = db.query('SELECT date, open, high, low, close, vol, value, chg FROM daily '
                 'WHERE code=? ORDER BY date', (code,))
  exr = {d: a for d, a in db.query('SELECT date, amount FROM exrights WHERE code=?', (code,)) if a}
  return adjust_rows(raw, exr)


def ensure_long_history(code: str, years: int = 6) -> None:
  key = f'long_{code}'
  if db.fetched('finmind_long', key):
    return
  first = db.query_one('SELECT MIN(date) FROM daily WHERE code=?', (code,))
  start = (dt.date.today() - dt.timedelta(days=365 * years)).isoformat()
  if first and first[0] and first[0] <= start:
    db.mark_fetched('finmind_long', key)
    return
  try:
    js_rows = news_src.finmind_prices(code, start)
  except Exception:  # pylint: disable=broad-except
    return
  if not js_rows:
    return
  # FinMind has no official change column here; derive chg from the previous close so the
  # adjustment step treats these bars as continuous (ex-rights gaps are not adjusted).
  have = {r[0] for r in db.query('SELECT date FROM daily WHERE code=?', (code,))}
  rows = []
  for i, (d, o, h, l, c, v) in enumerate(js_rows):
    if d in have:
      continue
    rows.append((code, d, o, h, l, c, v, None, None, None))
  db.upsert_many('daily', ('code', 'date', 'open', 'high', 'low', 'close', 'vol', 'value', 'trades',
                           'chg'), rows)
  db.mark_fetched('finmind_long', key)


def stock_detail(code: str, tf: str = 'D', rng: str = '2y', network: bool = True) -> dict[str, Any] | None:
  tf = tf if tf in ('D', 'W', 'M') else 'D'
  rng = rng if rng in ('3m', '6m', '1y', '2y', '5y', 'max') else '2y'
  st = db.query_one('SELECT code, name, market, type, industry, full_name, chairman, gm, founded, '
                    'listed, capital, shares, address, phone, website, spokesman, auditor '
                    'FROM stocks WHERE code=?', (code,))
  if not st:
    return None
  daily = stock_bars(code, long=rng in ('5y', 'max'))
  if not daily:
    return None
  full = ta.resample(daily, tf) if tf != 'D' else daily
  ind = ta.compute_indicators(full)
  n = len(full) if rng == 'max' else RANGE_BARS[tf].get(rng, 500)
  bars = full[-n:]
  ind = {k: v[-n:] for k, v in ind.items()}
  rows = get_rows()
  u = rows.get(code, {})
  raw_last = db.query_one('SELECT date, open, high, low, close, vol, value, chg FROM daily '
                          'WHERE code=? ORDER BY date DESC LIMIT 1', (code,))
  quote = None
  if raw_last:
    d, o, h, l, c, v, val, chg = raw_last
    prev = db.query_one('SELECT close FROM daily WHERE code=? AND date<? ORDER BY date DESC LIMIT 1',
                        (code, d))
    if chg is None and prev:
      chg = c - prev[0]
    base = (c - chg) if chg is not None else None
    quote = {'date': d, 'close': _r(c), 'chg': _r(chg), 'pct': _r(chg / base * 100) if base else None,
             'open': _r(o), 'high': _r(h), 'low': _r(l), 'vol': round(v or 0),
             'value': _r((val or 0) / 1e8), 'hi52': u.get('hi52'), 'lo52': u.get('lo52'),
             'mcap': u.get('mcap') if u.get('mcap') is not None else (
                 _r(c * st[11] * 0.1, 1) if st[11] and c else None)}
  industry = u.get('industry') or st[4]
  peers_all = [r for r in rows.values() if r.get('industry') == industry and r['code'] != code
               and r.get('type') == '股票']
  peers = [{'code': r['code'], 'name': r['name'], 'close': r.get('close'), 'pct': r.get('pct'),
            'pe': r.get('pe'), 'yld': r.get('yld'), 'r20': r.get('r20'), 'score': r.get('score')}
           for r in sorted(peers_all, key=lambda r: -(r.get('value') or 0))[:10]]
  pes = sorted(r['pe'] for r in peers_all + ([u] if u else []) if r.get('pe') and r['pe'] > 0)
  revenue = [{'ym': ym, 'rev': rev, 'mom': _r(mom), 'yoy': _r(yoy), 'cum_yoy': _r(cy)}
             for ym, rev, mom, yoy, cy in db.query(
                 'SELECT ym, rev, mom, yoy, cum_yoy FROM revenue WHERE code=? ORDER BY ym', (code,))][-36:]
  cums = db.query('SELECT q, cum_eps, cum_rev, cum_op, cum_ni FROM eps WHERE code=? ORDER BY q', (code,))
  eps = [{'q': q, 'eps': _r(e), 'rev': r_, 'op': o_, 'ni': n_}
         for q, e, r_, o_, n_ in scoring.eps_singles(cums)][-12:]
  mg = db.query_one('SELECT q, gross, operating, net FROM margins WHERE code=?', (code,))
  inst = [[d, round(f or 0), round(t or 0), round(dd or 0), round(tot or 0)]
          for d, f, t, dd, tot in db.query(
              'SELECT date, foreign_net, trust_net, dealer_net, total_net FROM inst WHERE code=? '
              'ORDER BY date DESC LIMIT 120', (code,))][::-1]
  chains = []
  ch = load_chains()
  if ch:
    for m in (ch.get('by_code') or {}).get(code, []):
      chains.append({'id': m.get('chain'), 'name': m.get('chain_name'), 'stream': m.get('stream'),
                     'segment': m.get('segment_name')})
  score = None
  if u.get('score') is not None:
    full_row = get_full_row(code)
    score = {'score': u.get('score'), 'rank': u.get('rank'),
             'factors': {k: u.get(f'f_{k}') for k in ('chip', 'rev', 'mom', 'vol', 'val')},
             'reasons': (full_row or {}).get('_reasons') or [], 'risks': (full_row or {}).get('_risks') or []}
  return {
      'code': code, 'name': st[1], 'market': st[2], 'industry': industry, 'type': st[3],
      'tf': tf, 'range': rng, 'adjusted': True,
      'profile': {'full_name': st[5], 'chairman': st[6], 'gm': st[7], 'founded': st[8],
                  'listed': st[9], 'capital': st[10], 'shares': st[11], 'address': st[12],
                  'phone': st[13], 'website': st[14], 'spokesman': st[15], 'auditor': st[16]},
      'quote': quote, 'bars': [[b[0], _r(b[1], 3), _r(b[2], 3), _r(b[3], 3), _r(b[4], 3), round(b[5] or 0)]
                               for b in bars],
      'ind': ind,
      'valuation': {'pe': u.get('pe'), 'pb': u.get('pb'), 'yld': u.get('yld'),
                    'eps_ttm': u.get('eps_ttm'),
                    'pe_industry_median': _r(pes[len(pes) // 2], 1) if pes else None},
      'margins': {'q': mg[0], 'gross': mg[1], 'operating': mg[2], 'net': mg[3]} if mg else None,
      'revenue': revenue, 'eps': eps, 'dividends': dividends(code, network=network), 'inst': inst,
      'peers': peers, 'chains': chains, 'score': score,
      'signals': u.get('signals') or [], 'risk': u.get('risk') or [],
      'tech_score': u.get('tech_score'),
  }


def get_full_row(code: str) -> dict[str, Any] | None:
  with _LOCK:
    return _MEM['rows'].get(code)


_MORNING_REFRESHING = threading.Lock()


def morning_cached(force: bool = False) -> dict[str, Any]:
  """Returns pre-market US & catalyst briefing; uses stale-while-revalidate on GET."""
  cur = get_payload('morning')

  def _do_refresh(net_force: bool) -> dict[str, Any]:
    rows = get_rows()
    picks_p = get_payload('picks') or {}
    market_p = get_payload('market') or {}
    fresh = morning.build_morning_briefing(rows, picks_p, market_p, force_network=net_force)
    os.makedirs(config.SNAP_DIR, exist_ok=True)
    tmp = os.path.join(config.SNAP_DIR, 'morning.json.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
      json.dump(fresh, f, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    os.replace(tmp, os.path.join(config.SNAP_DIR, 'morning.json'))
    with _LOCK:
      _MEM['payloads']['morning'] = fresh
      _MEM['version'] += 1
    return fresh

  if force or not cur:
    with _MORNING_REFRESHING:
      return _do_refresh(net_force=force)

  # Stale-while-revalidate if older than 15 minutes
  kv = db.get_kv('morning_raw_cache') or {}
  age = time.time() - float(kv.get('fetched_at') or 0)
  if age > 900 and _MORNING_REFRESHING.acquire(blocking=False):
    def _bg():
      try:
        _do_refresh(net_force=True)
      except Exception:  # pylint: disable=broad-except
        pass
      finally:
        _MORNING_REFRESHING.release()
    threading.Thread(target=_bg, daemon=True, name='morning-swr').start()
  return cur


def dividends(code: str, network: bool = True) -> list[dict[str, Any]]:
  row = db.query_one('SELECT fetched_at, data FROM news_cache WHERE code=?', (f'div:{code}',))
  if row and (time.time() - row[0] < 7 * 86400 or not network):
    cached_items = json.loads(row[1])
    if cached_items or not code.startswith('00'):
      return cached_items
  items: list[dict[str, Any]] = []
  if network:
    try:
      items = news_src.finmind_dividends(code)
    except Exception:  # pylint: disable=broad-except
      items = []
  if not items:
    for y, p, cash, stock, ex, pay, _ in db.query(
        'SELECT year, period, cash, stock, ex_date, pay_date, board_date FROM dividends WHERE code=? '
        'ORDER BY year', (code,)):
      items.append({'year': y, 'period': p, 'cash': cash, 'stock': stock, 'ex_date': ex, 'pay_date': pay})
  if not items and code.startswith('00'):
    items = etf_hub.etf_dividends_for(code)
  if network and items:
    db.execute('INSERT OR REPLACE INTO news_cache VALUES (?,?,?)',
               (f'div:{code}', time.time(), json.dumps(items, ensure_ascii=False)))
  return items


def stock_analysis(code: str, tf: str = 'D') -> dict[str, Any] | None:
  st = db.query_one('SELECT name FROM stocks WHERE code=?', (code,))
  if not st:
    return None
  daily = stock_bars(code, long=(tf == 'M'))
  if not daily:
    return None
  bars = ta.resample(daily, tf) if tf in ('W', 'M') else daily[-500:]
  out = ta.analyze(bars, tf=tf if tf in ('D', 'W', 'M') else 'D')
  out['code'], out['name'] = code, st[0]
  return out


def stock_news(code: str) -> dict[str, Any] | None:
  st = db.query_one('SELECT name FROM stocks WHERE code=?', (code,))
  if not st:
    return None
  row = db.query_one('SELECT fetched_at, data FROM news_cache WHERE code=?', (f'news:{code}',))
  if row and time.time() - row[0] < 1800:
    items = json.loads(row[1])
    fetched = row[0]
  else:
    items = news_src.stock_news(code, st[0])
    fetched = time.time()
    db.execute('INSERT OR REPLACE INTO news_cache VALUES (?,?,?)',
               (f'news:{code}', fetched, json.dumps(items, ensure_ascii=False)))
  return {'code': code, 'fetched_at': dt.datetime.fromtimestamp(fetched, TZ).isoformat(timespec='seconds'),
          'items': items}
