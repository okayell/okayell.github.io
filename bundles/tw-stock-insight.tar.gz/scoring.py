"""Multi-factor stock scoring, daily picks and a walk-forward backtest.

Scored factors (cross-sectional percentiles among eligible stocks, 0..1):
  chip : 籌碼強度 40% — 20-day 投信 (80%) + 外資 (20%) net buy as a share of 20-day volume.
  rev  : 月營收動能 40% — latest YoY, cumulative YoY and "3-month avg at 12-month high".
  mom  : 技術趨勢 20% — distance to 52-week high, MA20 slope, close above MA20, overheat penalty.
Reference-only factors (weight 0, shown in the UI): vol 穩定度 (low volatility), val 價值 (1/PE, 殖利率).
This follows FinLab's 「籌碼強度 × 月營收動能」 research and was confirmed by a Mar–Oct 2026
walk-forward study on this site's own data (top-10 excess return vs the equal-weight universe
+1.7% per 5 days / +4.9% per 20 days, t≈2–2.8), where value/low-vol blends did not add value.
"""
from __future__ import annotations

import bisect
import datetime as dt
import math
from typing import Any, Sequence

import config


def pct_rank(values: dict[str, float | None]) -> dict[str, float]:
  """Percentile rank 0..1 for non-null values (ties share the average rank)."""
  items = [(v, k) for k, v in values.items() if v is not None and math.isfinite(v)]
  if not items:
    return {}
  items.sort()
  n = len(items)
  out: dict[str, float] = {}
  i = 0
  while i < n:
    j = i
    while j + 1 < n and items[j + 1][0] == items[i][0]:
      j += 1
    r = ((i + j) / 2) / (n - 1) if n > 1 else 0.5
    for t in range(i, j + 1):
      out[items[t][1]] = r
    i = j + 1
  return out


def rolling_sum(xs: Sequence[float], n: int) -> list[float | None]:
  out: list[float | None] = [None] * len(xs)
  s = 0.0
  for i, x in enumerate(xs):
    s += x
    if i >= n:
      s -= xs[i - n]
    if i >= n - 1:
      out[i] = s
  return out


def rolling_mean(xs: Sequence[float], n: int) -> list[float | None]:
  rs = rolling_sum(xs, n)
  return [None if v is None else v / n for v in rs]


def streak(xs: Sequence[float]) -> int:
  """Consecutive positive (>0) or negative (<0, returned negative) days at the end."""
  if not xs:
    return 0
  last = xs[-1]
  if last == 0:
    return 0
  sgn = 1 if last > 0 else -1
  n = 0
  for v in reversed(xs):
    if v * sgn > 0:
      n += 1
    else:
      break
  return n * sgn


# ----------------------------------------------------------------- inputs ----

def revenue_publish_date(ym: str) -> str:
  """Monthly revenue for YYYY-MM is public by the 10th of the next month."""
  y, m = int(ym[:4]), int(ym[5:7])
  y, m = (y + 1, 1) if m == 12 else (y, m + 1)
  return f'{y:04d}-{m:02d}-11'


def eps_publish_date(q: str) -> str:
  y, n = int(q[:4]), int(q[-1])
  return {1: f'{y}-05-16', 2: f'{y}-08-15', 3: f'{y}-11-15', 4: f'{y + 1}-04-01'}[n]


def revenue_features(revs: list[tuple], as_of: str | None = None) -> dict[str, Any]:
  """revs: [(ym, rev, mom, yoy, cum_rev, cum_yoy)] ascending."""
  if as_of:
    revs = [r for r in revs if revenue_publish_date(r[0]) <= as_of]
  if not revs:
    return {}
  last = revs[-1]
  feats = {'rev_ym': last[0], 'rev_yoy': last[3], 'rev_mom': last[2], 'rev_cum_yoy': last[5],
           'rev_high': False}
  vals = [r[1] for r in revs[-14:] if r[1] is not None]
  if len(vals) >= 6:
    avg3 = [sum(vals[i - 2:i + 1]) / 3 for i in range(2, len(vals))]
    feats['rev_high'] = bool(avg3) and avg3[-1] >= max(avg3[-12:]) and len(avg3) >= 4
  return feats


def eps_singles(cums: list[tuple]) -> list[tuple[str, float | None, float | None, float | None, float | None]]:
  """cums: [(q, cum_eps, cum_rev, cum_op, cum_ni)] -> single-quarter values."""
  by_q = {c[0]: c for c in cums}
  out = []
  for q, ce, cr, co, cn in sorted(cums):
    y, n = q[:4], int(q[-1])
    if n == 1:
      out.append((q, ce, cr, co, cn))
      continue
    prev = by_q.get(f'{y}Q{n - 1}')
    if not prev:
      continue

    def d(a, b):
      return None if a is None or b is None else round(a - b, 4)

    out.append((q, d(ce, prev[1]), d(cr, prev[2]), d(co, prev[3]), d(cn, prev[4])))
  return out


def eps_features(singles: list[tuple], as_of: str | None = None) -> dict[str, Any]:
  if as_of:
    singles = [s for s in singles if eps_publish_date(s[0]) <= as_of]
  singles = [s for s in singles if s[1] is not None]
  if not singles:
    return {}
  last = singles[-1]
  feats: dict[str, Any] = {'eps_q': round(last[1], 2), 'eps_q_label': last[0]}
  if len(singles) >= 4:
    feats['eps_ttm'] = round(sum(s[1] for s in singles[-4:]), 2)
  yago = f'{int(last[0][:4]) - 1}Q{last[0][-1]}'
  prev = next((s for s in singles if s[0] == yago), None)
  if prev and prev[1] is not None:
    feats['eps_yoy_up'] = last[1] > prev[1]
  return feats


# --------------------------------------------------------------- factors -----

def chip_raw(f20: float | None, t20: float | None, vol20: float | None) -> float | None:
  if not vol20 or vol20 <= 0:
    return None
  fi = (f20 or 0.0) / vol20
  ti = (t20 or 0.0) / vol20
  return 0.2 * fi + 0.8 * ti


def mom_raw(dist_hi52: float | None, ma20_slope: float | None, above20: bool | None,
            bias20: float | None) -> float | None:
  """Trend quality; inputs in % (dist_hi52 ≤ 0, ma20_slope = 5-day % change of MA20)."""
  parts = []
  if dist_hi52 is not None:
    parts.append(max(0.0, 1.0 + dist_hi52 / 30.0))
  if ma20_slope is not None:
    parts.append(math.tanh(ma20_slope * 0.3))
  if above20 is not None:
    parts.append(1.0 if above20 else 0.0)
  if bias20 is not None and bias20 > 15:
    parts.append(-1.0)
  return sum(parts) / len(parts) if parts else None


def stab_raw(volat20: float | None) -> float | None:
  """Low volatility is better: negative 20-day stdev of daily returns (%)."""
  return None if volat20 is None else -volat20


def val_raw(pe, yld, eps_ttm) -> float | None:
  if eps_ttm is not None and eps_ttm <= 0:
    return -1.0
  parts = []
  if pe and pe > 0:
    parts.append(min(0.25, 1.0 / pe) * 4)
  if yld is not None:
    parts.append(min(yld, 12.0) / 12.0)
  return sum(parts) / len(parts) if parts else None


def rev_raw(rev_yoy, rev_cum_yoy, rev_high) -> float | None:
  if rev_yoy is None:
    return None
  y = max(-100.0, min(300.0, rev_yoy))
  c = max(-100.0, min(300.0, rev_cum_yoy if rev_cum_yoy is not None else rev_yoy))
  return 0.6 * math.tanh(y / 50) + 0.25 * math.tanh(c / 50) + (0.35 if rev_high else 0.0)


def is_eligible(row: dict[str, Any]) -> bool:
  if row.get('type') != '股票':
    return False
  if (row.get('close') or 0) < config.MIN_PRICE:
    return False
  if (row.get('_avg_vol20') or 0) < config.MIN_AVG_VOL20:
    return False
  if (row.get('_bars') or 0) < config.MIN_HISTORY:
    return False
  if set(row.get('risk') or []) & {'處置', '注意', '全額交割'}:
    return False
  return True


def score_universe(rows: dict[str, dict[str, Any]]) -> list[str]:
  """Adds score/rank/f_* to eligible rows in-place; returns ranked codes."""
  elig = {c: r for c, r in rows.items() if is_eligible(r)}
  raws: dict[str, dict[str, float | None]] = {k: {} for k in config.WEIGHTS}
  for c, r in elig.items():
    raws['chip'][c] = r.get('_chip_raw')
    raws['rev'][c] = rev_raw(r.get('rev_yoy'), r.get('rev_cum_yoy'), r.get('rev_high'))
    bits = r.get('ma_bits')
    raws['mom'][c] = mom_raw(r.get('dist_hi52'), r.get('_ma20_slope'),
                             None if bits is None else bool(bits & 4), r.get('bias20'))
    raws['vol'][c] = stab_raw(r.get('_volat20'))
    raws['val'][c] = val_raw(r.get('pe'), r.get('yld'), r.get('eps_ttm'))
  ranks = {k: pct_rank(v) for k, v in raws.items()}
  scored = []
  for c, r in elig.items():
    total = 0.0
    for k, w in config.WEIGHTS.items():
      p = ranks[k].get(c, 0.3)       # missing data counts as below median
      r[f'f_{k}'] = round(p * 100)
      total += w * p
    pen = 0.0
    risk = set(r.get('risk') or [])
    if '過熱' in risk:
      pen += 0.08
    if '虧損' in risk:
      pen += 0.05
    r['score'] = round(max(0.0, min(1.0, total - pen)) * 100, 1)
    scored.append((r['score'], r.get('value') or 0, c))
  scored.sort(reverse=True)
  for i, (_, _, c) in enumerate(scored, 1):
    rows[c]['rank'] = i
  return [c for _, _, c in scored]


def reasons_for(r: dict[str, Any], n_elig: int) -> tuple[list[str], list[str]]:
  """Human-readable reasons (zh-TW) and risks for a scored row."""
  out: list[tuple[float, str]] = []
  vol20 = r.get('_vol20_sum') or 0
  if r.get('f_chip') is not None:
    t20, f20 = r.get('t20') or 0, r.get('f20') or 0
    ti = t20 / vol20 * 100 if vol20 else 0
    fi = f20 / vol20 * 100 if vol20 else 0
    if r['f_chip'] >= 70 and (t20 > 0 or f20 > 0):
      who = []
      if t20 > 0:
        who.append(f'投信近 20 日買超 {t20:,.0f} 張（占成交量 {ti:.1f}%）')
      if f20 > 0:
        who.append(f'外資近 20 日買超 {f20:,.0f} 張（占成交量 {fi:.1f}%）')
      tail = f'，籌碼強度全市場前 {max(1, 100 - r["f_chip"])}%'
      out.append((r['f_chip'], '、'.join(who) + tail))
    st = r.get('streak_t') or 0
    if st >= 3:
      out.append((60 + st, f'投信已連續 {st} 日買超'))
  if r.get('f_rev') is not None and r.get('rev_yoy') is not None and r['f_rev'] >= 65:
    def yoy_txt(v: float) -> str:
      return f'{v:.1f}%' if v < 500 else f'逾 {int(v // 100)} 倍（去年基期低）'

    s = f'{r.get("rev_ym", "")[-2:].lstrip("0")} 月營收年增 {yoy_txt(r["rev_yoy"])}'
    if r.get('rev_cum_yoy') is not None:
      s += f'、累計年增 {yoy_txt(r["rev_cum_yoy"])}'
    if r.get('rev_high'):
      s += '，近 3 個月營收創 12 個月新高'
    out.append((r['f_rev'], s))
  if r.get('f_mom') is not None and r['f_mom'] >= 65:
    bits = r.get('ma_bits') or 0
    parts = []
    if bits & 64:
      parts.append('均線多頭排列')
    elif bits & 4:
      parts.append('股價站上月線')
    if (r.get('_ma20_slope') or 0) > 0:
      parts.append(f'月線上揚（5 日 +{r["_ma20_slope"]:.1f}%）')
    if r.get('dist_hi52') is not None and r['dist_hi52'] > -8:
      parts.append('接近 52 週新高' if r['dist_hi52'] < 0 else '創 52 週新高')
    if parts:
      out.append((r['f_mom'], '技術趨勢偏多：' + '、'.join(parts)))
  if r.get('f_vol') is not None and r['f_vol'] >= 80 and r.get('_volat20') is not None:
    out.append((r['f_vol'] - 15, f'股價波動相對低（近 20 日日波動 {r["_volat20"]:.1f}%），走勢穩健'))
  if r.get('f_val') is not None and r['f_val'] >= 75:
    s = []
    if r.get('pe'):
      s.append(f'本益比 {r["pe"]:.1f} 倍')
    if r.get('yld'):
      s.append(f'殖利率 {r["yld"]:.1f}%')
    if s:
      out.append((r['f_val'] - 10, '評價相對便宜：' + '、'.join(s)))
  out.sort(reverse=True)
  reasons = [s for _, s in out[:4]]
  risks = []
  if (r.get('rsi') or 0) >= 75:
    risks.append(f'RSI {r["rsi"]:.0f} 偏高，短線可能震盪')
  if (r.get('bias20') or 0) >= 12:
    risks.append(f'股價高於月線 {r["bias20"]:.1f}%，留意乖離過大拉回')
  if r.get('eps_ttm') is not None and r['eps_ttm'] <= 0:
    risks.append('近四季 EPS 為負，基本面仍在虧損')
  if (r.get('streak_f') or 0) <= -3:
    risks.append(f'外資連續 {abs(r["streak_f"])} 日賣超')
  if r.get('rev_yoy') is not None and r['rev_yoy'] < 0:
    risks.append(f'最新月營收年減 {abs(r["rev_yoy"]):.1f}%')
  return reasons, risks[:3]


# -------------------------------------------------------------- backtest -----

def rolling_max(xs: Sequence[float], n: int) -> list[float]:
  """Max over the trailing window of n values (monotonic deque, O(len))."""
  from collections import deque  # pylint: disable=import-outside-toplevel
  out, dq = [], deque()
  for i, x in enumerate(xs):
    while dq and xs[dq[-1]] <= x:
      dq.pop()
    dq.append(i)
    if dq[0] <= i - n:
      dq.popleft()
    out.append(xs[dq[0]])
  return out


def rolling_volatility(closes: Sequence[float], n: int) -> list[float | None]:
  """Population stdev (%) of the last n daily returns."""
  rets = [0.0] + [((closes[i] / closes[i - 1] - 1) * 100 if closes[i - 1] else 0.0)
                  for i in range(1, len(closes))]
  out: list[float | None] = [None] * len(closes)
  s = s2 = 0.0
  for i, r in enumerate(rets):
    s += r
    s2 += r * r
    if i >= n:
      s -= rets[i - n]
      s2 -= rets[i - n] ** 2
    if i >= n:
      m = s / n
      out[i] = math.sqrt(max(0.0, s2 / n - m * m))
  return out


def _asof_table(items: list[tuple], pub, feat) -> tuple[list[str], list[dict[str, Any]]]:
  """Pre-computes features after each publication so lookups are a bisect."""
  keys, vals = [], []
  for i in range(len(items)):
    keys.append(pub(items[i][0]))
    vals.append(feat(items[:i + 1]))
  order = sorted(range(len(keys)), key=lambda k: keys[k])
  return [keys[k] for k in order], [vals[k] for k in order]


def _asof(table: tuple[list[str], list[dict[str, Any]]], d: str) -> dict[str, Any]:
  keys, vals = table
  i = bisect.bisect_right(keys, d) - 1
  return vals[i] if i >= 0 else {}


def backtest(series: dict[str, dict[str, Any]], bench: dict[str, float], dates: list[str],
             lookback: int = 130, top_n: int | None = None, hold: int | None = None) -> dict[str, Any]:
  """Walk-forward test of the same factor model on historical data.

  series[code] = {'dates': [...], 'close': [...adjusted], 'vol': [...],
                  'f': [...foreign net], 't': [...trust net], 'revs': [...], 'eps': [...],
                  'type': '股票', 'flags': set()}
  """
  top_n = top_n or config.BACKTEST_TOP_N
  hold = hold or config.BACKTEST_HOLD
  if len(dates) < 90:
    return {}
  horizons = (5, 10, 20)
  # Pre-compute per-stock arrays once.
  prep = {}
  for code, s in series.items():
    if s.get('type') != '股票' or len(s['close']) < 80:
      continue
    closes, vols = s['close'], s['vol']
    idx = {d: i for i, d in enumerate(s['dates'])}
    ma20 = rolling_mean(closes, 20)
    ma60 = rolling_mean(closes, 60)
    ma5 = rolling_mean(closes, 5)
    ma10 = rolling_mean(closes, 10)
    v20 = rolling_sum(vols, 20)
    v5 = rolling_mean(vols, 5)
    f20 = rolling_sum(s['f'], 20)
    t20 = rolling_sum(s['t'], 20)
    hi = rolling_max(closes, 250)
    volat = rolling_volatility(closes, 20)
    rev_t = _asof_table(s['revs'], revenue_publish_date, revenue_features)
    eps_t = _asof_table(s['eps'], eps_publish_date, eps_features)
    prep[code] = (idx, closes, vols, ma5, ma10, ma20, ma60, v20, v5, f20, t20, hi, rev_t, eps_t, volat)
  start = max(70, len(dates) - lookback - max(horizons))
  test_days = dates[start:len(dates) - 1]
  picks_by_day: dict[str, list[str]] = {}
  universe_by_day: dict[str, list[str]] = {}
  for d in test_days:
    raws: dict[str, dict[str, float | None]] = {k: {} for k in config.WEIGHTS}
    for code, (idx, closes, vols, ma5, ma10, ma20, ma60, v20, v5, f20, t20, hi, rev_t,
               eps_t, volat) in prep.items():
      i = idx.get(d)
      if i is None or i < 65 or closes[i] < config.MIN_PRICE:
        continue
      if (v20[i] or 0) / 20 < config.MIN_AVG_VOL20:
        continue
      c = closes[i]
      r5 = (c / closes[i - 5] - 1) * 100
      r20 = (c / closes[i - 20] - 1) * 100
      r60 = (c / closes[i - 60] - 1) * 100
      bias20 = (c / ma20[i] - 1) * 100 if ma20[i] else None
      dist = (c / hi[i] - 1) * 100 if hi[i] else None
      slope = (ma20[i] / ma20[i - 5] - 1) * 100 if ma20[i] and ma20[i - 5] else None
      raws['chip'][code] = chip_raw(f20[i], t20[i], v20[i])
      rf = _asof(rev_t, d)
      raws['rev'][code] = rev_raw(rf.get('rev_yoy'), rf.get('rev_cum_yoy'), rf.get('rev_high'))
      raws['mom'][code] = mom_raw(dist, slope, bool(ma20[i] and c > ma20[i]), bias20)
      raws['vol'][code] = stab_raw(volat[i])
      ttm = _asof(eps_t, d).get('eps_ttm')
      raws['val'][code] = val_raw(c / ttm if ttm and ttm > 0 else None, None, ttm)
    ranks = {k: pct_rank(v) for k, v in raws.items()}
    total = {}
    for code in raws['mom']:
      total[code] = sum(w * ranks[k].get(code, 0.3) for k, w in config.WEIGHTS.items())
    best = sorted(total, key=lambda c: -total[c])[:top_n]
    picks_by_day[d] = best
    universe_by_day[d] = list(total)

  # Signals use day-d closing data (法人 / 營收 are published after the close), so the
  # simulated entry is the NEXT day's close (no look-ahead), exit h days after entry.
  def fwd(code: str, d: str, h: int) -> float | None:
    idx, closes = prep[code][0], prep[code][1]
    i = idx.get(d)
    if i is None or i + 1 + h >= len(closes):
      return None
    return (closes[i + 1 + h] / closes[i + 1] - 1) * 100

  def bench_fwd(d: str, h: int) -> float | None:
    j = dates.index(d)
    if j + 1 + h >= len(dates):
      return None
    a, b = bench.get(dates[j + 1]), bench.get(dates[j + 1 + h])
    return None if not a or not b else (b / a - 1) * 100

  def ew_fwd(d: str, h: int) -> float | None:
    rs = [x for x in (fwd(c, d, h) for c in universe_by_day.get(d, [])) if x is not None]
    return sum(rs) / len(rs) if rs else None

  out_h = []
  for h in horizons:
    rets, wins, benches, ews = [], 0.0, [], []
    for d, codes in picks_by_day.items():
      rs = [x for x in (fwd(c, d, h) for c in codes) if x is not None]
      bm, ew = bench_fwd(d, h), ew_fwd(d, h)
      if not rs or bm is None or ew is None:
        continue
      rets.append(sum(rs) / len(rs))
      benches.append(bm)
      ews.append(ew)
      wins += sum(1 for x in rs if x > 0) / len(rs)
    if rets:
      out_h.append({'days': h, 'avg_ret': round(sum(rets) / len(rets), 2),
                    'win_rate': round(wins / len(rets) * 100, 1),
                    'bench': round(sum(benches) / len(benches), 2),
                    'ew': round(sum(ews) / len(ews), 2), 'samples': len(rets)})
  # Non-overlapping equity curve: rebalance every `hold` days.
  equity, nav, bnav, enav = [], 1.0, 1.0, 1.0
  days = [d for d in test_days if d in picks_by_day]
  for k in range(0, len(days), hold):
    d = days[k]
    rs = [x for x in (fwd(c, d, hold) for c in picks_by_day[d]) if x is not None]
    bm, ew = bench_fwd(d, hold), ew_fwd(d, hold)
    if not rs or bm is None or ew is None:
      break
    j = dates.index(d)
    nav *= 1 + (sum(rs) / len(rs) - 0.4) / 100   # ~0.4% round-trip cost (fee + tax)
    bnav *= 1 + bm / 100
    enav *= 1 + ew / 100
    equity.append([dates[min(j + 1 + hold, len(dates) - 1)], round(nav, 4), round(bnav, 4), round(enav, 4)])
  if equity:
    equity.insert(0, [dates[min(dates.index(days[0]) + 1, len(dates) - 1)], 1.0, 1.0, 1.0])
  h5 = next((h for h in out_h if h['days'] == hold), None) or (out_h[0] if out_h else {})
  return {
      'start': days[0] if days else None, 'end': dates[-1], 'top_n': top_n, 'hold_days': hold,
      'samples': h5.get('samples', 0), 'avg_ret': h5.get('avg_ret'), 'bench_avg_ret': h5.get('bench'),
      'win_rate': h5.get('win_rate'), 'ew_avg_ret': h5.get('ew'),
      'excess': round((h5.get('avg_ret') or 0) - (h5.get('bench') or 0), 2) if h5 else None,
      'excess_ew': round((h5.get('avg_ret') or 0) - (h5.get('ew') or 0), 2) if h5 else None,
      'equity': equity, 'horizons': out_h,
      'note': '回測使用與每日推薦相同的因子模型（以當時可得資料計算，月營收以次月 11 日、財報以法定期限後才納入），'
              '訊號日隔天收盤價進場，每 10 個交易日換股、等權持有前 10 名，淨值已扣除約 0.4% 來回交易成本。比較基準：加權指數（大型權值股主導）'
              '與「全體合格股票等權平均」（較能反映選股能力）。回測期間僅約半年，統計上仍有不確定性；歷史績效不代表未來報酬。',
      '_picks_by_day': picks_by_day,
  }
