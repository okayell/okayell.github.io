"""Small HTTP helper: browser UA, retries with backoff, per-host rate limiting."""
from __future__ import annotations

import gzip
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

import config

_LOCKS: dict[str, threading.Lock] = {}
_LAST: dict[str, float] = {}
_GLOBAL = threading.Lock()


class FetchError(RuntimeError):
  """Raised when a URL cannot be fetched after retries."""


def _host_lock(host: str) -> threading.Lock:
  with _GLOBAL:
    if host not in _LOCKS:
      _LOCKS[host] = threading.Lock()
    return _LOCKS[host]


def _throttle(host: str) -> None:
  interval = config.HOST_INTERVAL.get(host, config.DEFAULT_INTERVAL)
  wait = _LAST.get(host, 0.0) + interval - time.monotonic()
  if wait > 0:
    time.sleep(wait)
  _LAST[host] = time.monotonic()


def fetch_bytes(url: str, *, data: dict[str, Any] | None = None,
                headers: dict[str, str] | None = None, timeout: float = 45.0,
                retries: int = 3) -> bytes:
  """Fetches a URL (GET, or POST form when `data` is given) politely."""
  host = urllib.parse.urlparse(url).netloc
  hdrs = {
      'User-Agent': config.USER_AGENT,
      'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.6',
      'Accept-Encoding': 'gzip',
  }
  if headers:
    hdrs.update(headers)
  body = None
  if data is not None:
    body = urllib.parse.urlencode(data).encode()
    hdrs.setdefault('Content-Type', 'application/x-www-form-urlencoded')
  last_err: Exception | None = None
  for attempt in range(retries):
    with _host_lock(host):
      _throttle(host)
      try:
        req = urllib.request.Request(url, data=body, headers=hdrs)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
          raw = resp.read()
          if resp.headers.get('Content-Encoding') == 'gzip':
            raw = gzip.decompress(raw)
          return raw
      except urllib.error.HTTPError as e:
        last_err = e
        if e.code == 404:
          break
      except Exception as e:  # pylint: disable=broad-except
        last_err = e
    time.sleep(2.0 * (attempt + 1) + (6.0 if '429' in str(last_err) else 0.0))
  raise FetchError(f'{url}: {last_err!r}')


def fetch_text(url: str, encoding: str = 'utf-8', **kw: Any) -> str:
  return fetch_bytes(url, **kw).decode(encoding, errors='replace')


def fetch_json(url: str, **kw: Any) -> Any:
  raw = fetch_bytes(url, **kw)
  return json.loads(raw.decode('utf-8-sig', errors='replace'))
