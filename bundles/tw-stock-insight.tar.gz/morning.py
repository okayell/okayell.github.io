"""Pre-market (before 08:00 TW) US market digest, global/domestic event radar & TW action re-judger."""
from __future__ import annotations

import datetime as dt
import hashlib
import math
import re
import time
from typing import Any

import config
import db
from sources import global_market

TZ = dt.timezone(dt.timedelta(hours=8))

CAT_LABELS = {
    'geopolitics': '🌍 戰爭／地緣／關稅',
    'commodity_macro': '🛢️ 石油／原物料／匯率利率',
    'tech_giant': '🚀 科技巨頭發布／財報',
    'key_figure': '🎙️ 關鍵人物談話／央行',
    'domestic': '🇹🇼 國內政經／產業法說',
}

BULL_WORDS = (
    '大漲', '勁揚', '飆漲', '創高', '新高', '優於預期', '上修', '調升', '擴產', '大單', '追單', '滿載',
    '利多', '受惠', '突破', '降息', '停火', '和談', '緩解', '豁免', '買超', '強勁', '成長', '翻倍', '搶進',
    '加碼', '看旺', '報喜', '助攻', '反彈', '回升', '增溫',
)
BEAR_WORDS = (
    '大跌', '重挫', '暴跌', '崩跌', '跳水', '低於預期', '下修', '砍單', '調降', '裁員', '利空', '衝擊',
    '承壓', '破底', '升息', '通膨升溫', '開戰', '空襲', '飛彈', '封鎖', '制裁', '禁令', '加徵關稅', '關稅威脅',
    '賣超', '衰退', '虧損', '延後', '難產', '過熱', '泡沫', '罷工', '違約', '警告', '示警',
)

# Structured Event -> Taiwan Industry & Stock Knowledge Graph (verified codes & chain IDs).
EVENT_RULES: list[dict[str, Any]] = [
    {
        'id': 'war_geopolitics',
        'cat': 'geopolitics',
        'kw': ('戰爭', '開戰', '空襲', '飛彈', '轟炸', '中東', '以色列', '伊朗', '黎巴嫩', '烏俄', '烏克蘭',
               '俄羅斯', '紅海', '葉門', '胡塞', '台海', '軍演', '北韓', '地緣政治', '軍事衝突', '停火'),
        'us_syms': ['USO', 'BNO', 'GLD', 'VIXY'],
        'invert_on_peace': ('停火', '和談', '撤軍', '和平協議'),
        'explain_bull': '地緣衝突若趨緩或進入停火重建，有助降低市場風險溢價，並帶動散裝航運、鋼鐵水泥重建與航空旅遊復甦。',
        'explain_bear': '軍事與地緣衝突升溫會推升避險情緒、油價與航運繞道預期：軍工航太、貨櫃航運與黃金受資金青睞，高估值電子與航空成本則易承壓。',
        'default_polarity': 'mixed',
        'sectors_escalation': [
            {'name': '軍工航太與無人機', 'ind': '電機機械', 'chain_id': '4100', 'dir': 'beneficiary',
             'reason': '國防預算與無人機／航太防衛需求題材升溫'},
            {'name': '貨櫃航運（繞道運價）', 'ind': '航運業', 'chain_id': 'T000', 'dir': 'beneficiary',
             'reason': '紅海／中東航道風險支撐遠洋運價與繞道運力吸收'},
            {'name': '黃金與電信避險', 'ind': '通信網路業', 'chain_id': 'I000', 'dir': 'beneficiary',
             'reason': '市場波動放大時，防禦型高息電信與黃金 ETF 具避風港效果'},
            {'name': '航空客貨運', 'ind': '航運業', 'chain_id': 'T000', 'dir': 'headwind',
             'reason': '航線繞飛與油價走高推升燃油成本'},
        ],
        'stocks_escalation': [
            ('2634', 'beneficiary', '航太國防龍頭'), ('8033', 'beneficiary', '軍用商規無人機'),
            ('5284', 'beneficiary', '航太精密機構件'), ('2208', 'beneficiary', '國艦國造'),
            ('2603', 'beneficiary', '歐洲／紅海線貨櫃龍頭'), ('2609', 'beneficiary', '遠洋貨櫃運價連動'),
            ('00635U', 'beneficiary', '黃金避險 ETF'), ('2412', 'beneficiary', '內需電信防禦王'),
            ('2618', 'headwind', '燃油與航線成本敏感'), ('2610', 'headwind', '燃油成本占比較高'),
        ],
        'sectors_peace': [
            {'name': '鋼鐵與水泥重建', 'ind': '鋼鐵工業', 'chain_id': 'Q000', 'dir': 'beneficiary',
             'reason': '停火重建基礎建設帶動鋼材與水泥需求'},
            {'name': '散裝航運與航空', 'ind': '航運業', 'chain_id': 'T000', 'dir': 'beneficiary',
             'reason': '原物料運輸回溫且油價風險溢價回落'},
        ],
        'stocks_peace': [
            ('2002', 'beneficiary', '鋼鐵龍頭重建題材'), ('2027', 'beneficiary', '美國／重建不鏽鋼通路'),
            ('1101', 'beneficiary', '歐亞水泥布局'), ('2606', 'beneficiary', '散裝航運指標'),
            ('2637', 'beneficiary', '中小型散裝船隊'), ('2618', 'beneficiary', '航線恢復與油價回落受惠'),
        ],
    },
    {
        'id': 'tariff_trade',
        'cat': 'key_figure',
        'kw': ('關稅', '貿易戰', '出口管制', '晶片禁令', '實體清單', '制裁', '301條款', '232條款', '保護費',
               '美國製造', '對等關稅', '課稅'),
        'us_syms': ['SOX', 'TSM', 'NVDA'],
        'default_polarity': 'bear',
        'explain': '關稅與出口管制消息直接牽動台灣外銷供應鏈評價：具備美國在地廠房或高技術獨占議價力的龍頭抗跌，純組裝代工與高中國產能曝險族群短線承壓。',
        'sectors': [
            {'name': '美國設廠／高議價權龍頭', 'ind': '半導體業', 'chain_id': 'D000', 'dir': 'beneficiary',
             'reason': '擁有美國廠區或不可替代製程，可轉嫁關稅成本'},
            {'name': '重電美國基建與內需金融', 'ind': '電機機械', 'chain_id': 'AD10', 'dir': 'beneficiary',
             'reason': '美國製造回流推升電網設備需求；內需金融電信不受關稅直接衝擊'},
            {'name': '消費電子組裝與傳統外銷', 'ind': '電腦及週邊設備業', 'chain_id': 'F000', 'dir': 'headwind',
             'reason': '毛利率較薄之組裝與輸美傳產面臨關稅分攤與拉貨觀望壓力'},
        ],
        'stocks': [
            ('2330', 'beneficiary', '亞利桑那廠＋先進製程轉嫁力強'), ('2027', 'beneficiary', '美國在地鋼鋁製造廠受惠'),
            ('1519', 'beneficiary', '美國電網變壓器剛性需求'), ('2412', 'beneficiary', '純內需不受關稅影響'),
            ('2317', 'headwind', '全球組裝產能調配關注度高'), ('4938', 'headwind', '消費電子代工毛利敏感'),
            ('2303', 'headwind', '成熟製程報價與地緣競爭敏感'),
        ],
    },
    {
        'id': 'oil_commodity',
        'cat': 'commodity_macro',
        'kw': ('石油', '原油', '油價', '布蘭特', '西德州', 'WTI', 'OPEC', '產油國', '減產', '增產',
               '天然氣', '能源價格', '戰備儲油', '煉油'),
        'us_syms': ['USO', 'BNO'],
        'default_polarity': 'mixed',
        'explain_oil_up': '國際油價走揚有利塑化上游庫存評價回升與烯烴利差修復，原油 ETF 同步反映；但航空與海運燃油成本隨之墊高。',
        'explain_oil_down': '國際油價回落有助壓低通膨預期，直接減輕航空、海運與陸運燃油成本負擔；塑化上游與原油期貨 ETF 短線則受報價壓抑。',
        'sectors_oil_up': [
            {'name': '石化及塑橡膠上游', 'ind': '塑膠工業', 'chain_id': 'N000', 'dir': 'beneficiary',
             'reason': '油價上行帶動庫存回沖與石化產品報價支撐'},
            {'name': '油電燃氣與原油 ETF', 'ind': '油電燃氣業', 'chain_id': 'W000', 'dir': 'beneficiary',
             'reason': '直接連動布蘭特／西德州原油期貨走勢'},
            {'name': '航空與運輸業', 'ind': '航運業', 'chain_id': 'T000', 'dir': 'headwind',
             'reason': '航空燃油占營運成本約 25–30%，油價上漲壓抑獲利'},
        ],
        'stocks_oil_up': [
            ('6505', 'beneficiary', '煉油與烯烴利差指標'), ('1301', 'beneficiary', 'PVC／塑化龍頭'),
            ('1303', 'beneficiary', '塑膠加工與電子材料'), ('1326', 'beneficiary', '芳香烴報價連動'),
            ('00715L', 'beneficiary', '布蘭特原油正2 ETF'),
            ('2618', 'headwind', '航空燃油成本敏感'), ('2610', 'headwind', '航空客貨運成本承壓'),
        ],
        'sectors_oil_down': [
            {'name': '航空客貨運', 'ind': '航運業', 'chain_id': 'T000', 'dir': 'beneficiary',
             'reason': '燃油成本下降直接擴大航線營業利益率'},
            {'name': '石化塑化與原油 ETF', 'ind': '塑膠工業', 'chain_id': 'N000', 'dir': 'headwind',
             'reason': '原油跌價造成在途庫存跌價損失與買盤觀望'},
        ],
        'stocks_oil_down': [
            ('2618', 'beneficiary', '油價下跌直接受惠'), ('2610', 'beneficiary', '燃油成本減輕'),
            ('6505', 'headwind', '煉油庫存評價承壓'), ('1301', 'headwind', '塑化報價觀望'),
            ('00715L', 'headwind', '原油槓桿 ETF 隨油價回檔'),
        ],
    },
    {
        'id': 'ai_nvidia_csp',
        'cat': 'tech_giant',
        'kw': ('輝達', 'NVIDIA', 'NVDA', '黃仁勳', 'Blackwell', 'Rubin', 'GB200', 'GB300', 'AI伺服器',
               'AI晶片', '微軟', 'Microsoft', 'Google', 'Alphabet', 'Meta', '亞馬遜', 'AWS', 'OpenAI',
               'CSP', '雲端資本支出', '博通', 'Broadcom', 'AVGO', '超微', 'AMD', '蘇姿丰', 'ASIC', 'CoWoS', 'CPO'),
        'us_syms': ['NVDA', 'AVGO', 'AMD', 'MSFT', 'GOOGL', 'META', 'AMZN', 'TSM'],
        'default_polarity': 'bull',
        'explain': '美股 AI 晶片與四大雲端巨頭（CSP）的產品發布、財報與資本支出指引，是台股權值與高價股最核心的領先指標，直接牽動晶圓代工、CoWoS、AI 伺服器組裝、液冷散熱與高速光通訊。',
        'sectors': [
            {'name': '晶圓代工與先進封裝', 'ind': '半導體業', 'chain_id': 'D000', 'dir': 'same',
             'reason': 'AI GPU／ASIC 皆仰賴台積電先進製程與 CoWoS 封測產能'},
            {'name': 'AI 伺服器與機櫃組裝', 'ind': '電腦及週邊設備業', 'chain_id': '5300', 'dir': 'same',
             'reason': 'CSP 資本支出直接轉化為台灣 ODM 伺服器整機櫃出貨動能'},
            {'name': '液冷散熱、電源與高速網通 CPO', 'ind': '電子零組件業', 'chain_id': '5400', 'dir': 'same',
             'reason': '次世代晶片功耗與頻寬升級帶動水冷散熱、BBU／電源與矽光子需求'},
        ],
        'stocks': [
            ('2330', 'same', 'AI 晶片獨家先進製程代工'), ('2317', 'same', 'AI 伺服器機櫃主力供應商'),
            ('2382', 'same', 'CSP 雲端伺服器龍頭'), ('6669', 'same', '純 CSP 雲端伺服器大廠'),
            ('3231', 'same', 'GPU 基板與伺服器代工'), ('3017', 'same', '伺服器水冷散熱指標'),
            ('3324', 'same', '水冷板與分歧管供應商'), ('2308', 'same', 'AI 伺服器電源與散熱龍頭'),
            ('3661', 'same', 'CSP 自研 AI ASIC 設計'), ('2345', 'same', '800G／AI 交換器龍頭'),
        ],
    },
    {
        'id': 'memory_hbm',
        'cat': 'tech_giant',
        'kw': ('美光', 'Micron', 'HBM', 'DRAM', 'NAND', '記憶體', '海力士', 'SK海力士', '三星記憶體', 'DDR5', 'SSD報價'),
        'us_syms': ['MU'],
        'default_polarity': 'bull',
        'explain': '美光（Micron）與韓系大廠的財報、HBM 產能排擠效應與 DRAM／NAND 合約價走勢，直接決定台灣記憶體製造、控制 IC 與模組廠的庫存低價利益與毛利率表現。',
        'sectors': [
            {'name': '記憶體製造、控制 IC 與模組', 'ind': '半導體業', 'chain_id': 'D000', 'dir': 'same',
             'reason': '國際大廠產能轉向 HBM 帶動標準型／利基型 DRAM 與 NAND 報價連動'},
        ],
        'stocks': [
            ('2408', 'same', '台灣 DRAM 製造指標'), ('2344', 'same', '利基型 DRAM 與 Flash'),
            ('8299', 'same', 'NAND 控制 IC 與企業級 SSD 龍頭'), ('3260', 'same', '記憶體模組大廠'),
            ('4967', 'same', 'DDR5／電競記憶體模組'), ('2337', 'same', 'NOR Flash／ROM 指標'),
        ],
    },
    {
        'id': 'apple_mobile',
        'cat': 'tech_giant',
        'kw': ('蘋果', 'Apple', 'AAPL', 'iPhone', 'iPad', 'MacBook', 'Apple Intelligence', '庫克', 'WWDC', '蘋果發表會'),
        'us_syms': ['AAPL', 'TSM'],
        'default_polarity': 'bull',
        'explain': '蘋果新品發表、AI 手機換機潮與備貨量調整，直接影響台系處理器代工、高階光學鏡頭、HDI／軟板與組裝供應鏈拉貨節奏。',
        'sectors': [
            {'name': '光學鏡頭與感測', 'ind': '光電業', 'chain_id': 'D000', 'dir': 'same',
             'reason': '潛望式鏡頭與光學升級直接帶動高階鏡片稼動率'},
            {'name': 'PCB 軟硬板與 IC 載板', 'ind': '電子零組件業', 'chain_id': 'L000', 'dir': 'same',
             'reason': 'iPhone 主機板 HDI、軟板與 ABF／BT 載板主力供應鏈'},
            {'name': '手機晶片與終端組裝', 'ind': '電腦及週邊設備業', 'chain_id': 'F000', 'dir': 'same',
             'reason': 'A／M 系列晶片代工與 iPhone 整機組裝'},
        ],
        'stocks': [
            ('2330', 'same', 'A／M 系列處理器獨家代工'), ('3008', 'same', '高階手機鏡頭龍頭'),
            ('2317', 'same', 'iPhone 最大組裝廠'), ('4938', 'same', 'iPhone 組裝供應商'),
            ('2313', 'same', '蘋果 HDI 板與衛星板主力'), ('3037', 'same', 'ABF／BT 載板大廠'),
            ('6269', 'same', '美系手機軟板供應商'),
        ],
    },
    {
        'id': 'semi_foundry_asml',
        'cat': 'tech_giant',
        'kw': ('台積電', '魏哲家', '艾司摩爾', 'ASML', 'EUV', '晶圓代工', '2奈米', '先進製程', '成熟製程',
               '聯電', '日月光', '資本支出', '半導體設備', '費半'),
        'us_syms': ['TSM', 'ASML', 'ASX', 'UMC', 'SOX'],
        'default_polarity': 'bull',
        'explain': '晶圓代工龍頭與 ASML 的接單、資本支出及法說指引，牽動台灣半導體權值、先進封測與矽晶圓／設備廠務的整體評價。',
        'sectors': [
            {'name': '半導體晶圓製造與封測', 'ind': '半導體業', 'chain_id': 'D000', 'dir': 'same',
             'reason': '直接反映先進製程、封測稼動率與資本支出循環'},
        ],
        'stocks': [
            ('2330', 'same', '全球晶圓代工龍頭'), ('3711', 'same', '全球封測與先進封裝龍頭'),
            ('2454', 'same', '旗艦手機與邊緣 AI 晶片龍頭'), ('6488', 'same', '半導體矽晶圓指標'),
            ('2303', 'same', '成熟製程晶圓代工代表'), ('3034', 'same', '面板驅動與 ASIC 設計'),
        ],
    },
    {
        'id': 'tesla_ev_robot',
        'cat': 'tech_giant',
        'kw': ('特斯拉', 'Tesla', 'TSLA', '馬斯克', 'Musk', '電動車', '自駕車', 'Robotaxi', 'Optimus', '人形機器人', '機器人'),
        'us_syms': ['TSLA'],
        'default_polarity': 'bull',
        'explain': '特斯拉與馬斯克對自駕車（Robotaxi）、電動車交付量及人形機器人（Optimus）的最新進展，直接催化台股車電與精密傳動／機器人視覺概念股。',
        'sectors': [
            {'name': '電動車動力與充電供應鏈', 'ind': '汽車工業', 'chain_id': 'A300', 'dir': 'same',
             'reason': '車用電源、減速機與車電零組件供應鏈'},
            {'name': '機器人精密傳動與自動化', 'ind': '電機機械', 'chain_id': '6000', 'dir': 'same',
             'reason': '滾珠螺桿、線性滑軌、諧波減速機與光學感測鏡頭'},
        ],
        'stocks': [
            ('2308', 'same', '電動車動力系統與充電樁'), ('2049', 'same', '機器人滾珠螺桿與晶圓機器人'),
            ('1590', 'same', '氣動與線性自動化龍頭'), ('4576', 'same', '精密定位與伺服馬達'),
            ('2317', 'same', 'MIH 電動車與機器人布局'), ('2395', 'same', '工業電腦與邊緣自動化'),
        ],
    },
    {
        'id': 'fed_rates_cpi',
        'cat': 'key_figure',
        'kw': ('聯準會', 'Fed', 'FOMC', '鮑爾', 'Powell', '降息', '升息', '利率決策', 'CPI', 'PCE', '非農',
               '通膨', '美債殖利率', '公債殖利率', '葉倫', '央行總裁', '點陣圖'),
        'us_syms': ['TLT', 'IEF', 'USDTWD', 'SOX'],
        'default_polarity': 'mixed',
        'explain_dovish': '通膨降溫或聯準會釋出偏鴿／降息訊號，壓低美債殖利率，最有利長天期美債／投等債 ETF 價格反彈，並提升科技成長股評價倍數。',
        'explain_hawkish': '通膨黏著或官員談話偏鷹推升美債殖利率，短線壓抑長天期債券 ETF 與高本益比科技股，但高息銀行金控受惠利差維持高檔。',
        'sectors_dovish': [
            {'name': '長天期美債與投等債 ETF', 'ind': 'ETF', 'chain_id': 'U000', 'dir': 'beneficiary',
             'reason': '殖利率下行直接推升長存續期間債券價格'},
            {'name': '高成長半導體與 AI 權值', 'ind': '半導體業', 'chain_id': 'D000', 'dir': 'beneficiary',
             'reason': '折現率下降有利高成長科技股評價擴張'},
        ],
        'stocks_dovish': [
            ('00679B', 'beneficiary', '20年期以上美國公債指標'), ('00687B', 'beneficiary', '長天期美債高流動性標的'),
            ('00937B', 'beneficiary', '月配長天期 ESG 投等債'), ('2330', 'beneficiary', '外資回補權值首選'),
        ],
        'sectors_hawkish': [
            {'name': '金控與商業銀行', 'ind': '金融保險業', 'chain_id': 'U000', 'dir': 'beneficiary',
             'reason': '高利率環境延續支撐銀行淨利差（NIM）與外幣放款收益'},
            {'name': '長天期美債 ETF 與高估值股', 'ind': 'ETF', 'chain_id': 'U000', 'dir': 'headwind',
             'reason': '美債殖利率彈升對長天期債券淨值形成短線逆風'},
        ],
        'stocks_hawkish': [
            ('2891', 'beneficiary', '消金與外幣利差穩健'), ('2886', 'beneficiary', '官股外匯與企金龍頭'),
            ('2881', 'beneficiary', '金控獲利王'), ('2882', 'beneficiary', '壽險與資產管理龍頭'),
            ('00679B', 'headwind', '對長端殖利率彈升敏感'), ('00687B', 'headwind', '美債殖利率上行承壓'),
        ],
    },
    {
        'id': 'fx_twd_flow',
        'cat': 'commodity_macro',
        'kw': ('新台幣', '台幣升值', '台幣貶值', '美元指數', '日圓', '匯率', '外資匯出', '外資匯入', '熱錢', '台灣央行', '楊金龍'),
        'us_syms': ['USDTWD', 'USDJPY'],
        'default_polarity': 'mixed',
        'explain': '新台幣與亞幣匯率直接反映國際熱錢流向：台幣走升通常伴隨外資買超大型權值與內需資產股；台幣走貶雖帶來電子與工具機匯兌收益，但需提防外資提款權值股。',
        'sectors': [
            {'name': '大型權值與市值 ETF', 'ind': '半導體業', 'chain_id': 'D000', 'dir': 'beneficiary',
             'reason': '外資現貨買賣超與匯率高度連動，外銷大廠亦受美元計價營收影響'},
            {'name': '內需營建與航空旅遊', 'ind': '建材營造', 'chain_id': 'S000', 'dir': 'beneficiary',
             'reason': '台幣購買力與資金動能牽動資產股及出境旅遊需求'},
        ],
        'stocks': [
            ('2330', 'beneficiary', '外資控盤最大權值股'), ('0050', 'beneficiary', '大盤外資動向溫度計'),
            ('3008', 'beneficiary', '高美元現金部位匯兌敏感'), ('2618', 'beneficiary', '匯率與出國旅運連動'),
            ('2542', 'beneficiary', '內需資產營建代表'),
        ],
    },
    {
        'id': 'power_grid_tw',
        'cat': 'domestic',
        'kw': ('電價', '台電', '強韌電網', '重電', '變壓器', '缺電', '核電', '核能', '綠能', '離岸風電', '太陽能', '儲能', '資料中心用電'),
        'us_syms': [],
        'default_polarity': 'bull',
        'explain': 'AI 資料中心吃電激增、台電強韌電網計畫與美國電網汰舊換新，使重電變壓器、配電盤與線纜族群具備中長期在手訂單能見度。',
        'sectors': [
            {'name': '重電設備與智慧電網', 'ind': '電機機械', 'chain_id': 'AD10', 'dir': 'beneficiary',
             'reason': '台電電網強韌預算與北美變壓器外銷雙引擎'},
            {'name': '電線電纜與綠能儲能', 'ind': '電器電纜', 'chain_id': 'E000', 'dir': 'beneficiary',
             'reason': '高壓電纜標案與再生能源併網需求'},
        ],
        'stocks': [
            ('1519', 'beneficiary', '高壓變壓器外銷美國指標'), ('1513', 'beneficiary', 'GIS 氣體絕緣開關龍頭'),
            ('1503', 'beneficiary', '重電與變壓器老牌大廠'), ('1504', 'beneficiary', '馬達與綠能機電工程'),
            ('1609', 'beneficiary', '線纜與太陽能儲能案場'),
        ],
    },
    {
        'id': 'shipping_freight',
        'cat': 'domestic',
        'kw': ('運價', 'SCFI', 'BDI', '貨櫃', '散裝', '碼頭罷工', '塞港', '搶運', '長榮', '陽明', '萬海', '航空票價', '旅展'),
        'us_syms': ['USO'],
        'default_polarity': 'bull',
        'explain': 'SCFI／BDI 運價指數變化、歐美提前拉貨搶運或港口勞資談判，直接影響台灣貨櫃三雄與散裝航運的單季獲利與高配息預期。',
        'sectors': [
            {'name': '貨櫃與散裝航運', 'ind': '航運業', 'chain_id': 'T000', 'dir': 'same',
             'reason': '運價指數與旺季附加費直接反映於月營收'},
        ],
        'stocks': [
            ('2603', 'same', '全球前段班貨櫃龍頭'), ('2609', 'same', '歐美航線運價高彈性'),
            ('2615', 'same', '亞洲近洋與美東線代表'), ('2606', 'same', '海岬型散裝航運龍頭'),
            ('2637', 'same', '高殖利率散裝指標'), ('2618', 'same', '客貨運雙引擎龍頭'),
        ],
    },
    {
        'id': 'tw_policy_finance',
        'cat': 'domestic',
        'kw': ('國安基金', '金管會', '限空令', '當沖降稅', '打炒房', '信用管制', '新青安', '金控獲利', '法說會', '股利政策'),
        'us_syms': [],
        'default_polarity': 'mixed',
        'explain': '國內金管會／央行政策、金控自結獲利與法說會展望，直接影響本土壽險、銀行、營建與高股息存股資金配置。',
        'sectors': [
            {'name': '金融保險金控', 'ind': '金融保險業', 'chain_id': 'U000', 'dir': 'same',
             'reason': '金控獲利、資本適足與配息能力為內資與高息 ETF 核心持股'},
            {'name': '建材營造與房市', 'ind': '建材營造', 'chain_id': 'S000', 'dir': 'same',
             'reason': '央行房市信用管制與交屋入帳高峰直接連動'},
        ],
        'stocks': [
            ('2881', 'same', '金控獲利指標'), ('2882', 'same', '壽險與資產管理龍頭'),
            ('2891', 'same', '銀行型金控核心'), ('2886', 'same', '官股高息定存代表'),
            ('2542', 'same', '全台推案營建指標'), ('2548', 'same', '商辦與住宅績優建商'),
        ],
    },
]

# Direct US Stock / Index -> Taiwan Sector & Bellwether mapping for overnight impulse scoring.
US_SECTOR_IMPULSE: dict[str, list[tuple[str, float, list[str]]]] = {
    'SOX': [('半導體業', 0.45, ['2330', '2454', '3711', '3034', '6488'])],
    'TSM': [('半導體業', 0.55, ['2330', '3443', '3661', '3711'])],
    'NVDA': [('電腦及週邊設備業', 0.50, ['2317', '2382', '3231', '6669', '2376']),
             ('電子零組件業', 0.35, ['3017', '3324', '2308']),
             ('半導體業', 0.30, ['2330', '3711'])],
    'AVGO': [('通信網路業', 0.45, ['2345', '6442', '3081']),
             ('半導體業', 0.30, ['3661', '3443', '2454'])],
    'AMD': [('電腦及週邊設備業', 0.30, ['2376', '3231', '2382']),
            ('半導體業', 0.25, ['2330', '3711'])],
    'MU': [('半導體業', 0.25, ['2408', '2344', '8299', '3260', '4967', '2337'])],
    'ASX': [('半導體業', 0.20, ['3711'])],
    'UMC': [('半導體業', 0.15, ['2303'])],
    'ASML': [('半導體業', 0.25, ['2330', '6488'])],
    'AAPL': [('光電業', 0.40, ['3008']), ('電子零組件業', 0.25, ['2313', '6269', '3037']),
             ('其他電子業', 0.30, ['2317', '4938'])],
    'TSLA': [('汽車工業', 0.45, []), ('電機機械', 0.25, ['2049', '1590', '4576'])],
    'USO': [('塑膠工業', 0.50, ['1301', '1303', '1326']), ('油電燃氣業', 0.55, ['6505', '00715L']),
            ('航運業', -0.30, ['2618', '2610'])],
    'TLT': [('金融保險業', -0.20, ['2881', '2882', '2891']), ('ETF', 0.40, ['00679B', '00687B', '00937B'])],
}


def _r(x: float | None, nd: int = 2) -> float | None:
  if x is None or not isinstance(x, (int, float)) or not math.isfinite(x):
    return None
  return round(float(x), nd)


def _eff_pct(q: dict[str, Any] | None) -> float:
  """Combines regular session % with post-market move if significant."""
  if not q:
    return 0.0
  reg = float(q.get('pct') or 0.0)
  post = (q.get('post') or {}).get('post_pct')
  if isinstance(post, (int, float)) and abs(post) >= 0.4:
    return round(reg + float(post) * 0.85, 2)
  return reg


def _score_sentiment_words(text: str) -> tuple[int, int]:
  b = sum(1 for w in BULL_WORDS if w in text)
  s = sum(1 for w in BEAR_WORDS if w in text)
  return b, s


def _stock_card_mini(code: str, direction: str, role: str, rows: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
  r = rows.get(code)
  if not r:
    return None
  return {
      'code': code,
      'name': r['name'],
      'market': r['market'],
      'type': r.get('type'),
      'industry': r.get('industry'),
      'direction': direction,    # 'beneficiary' | 'headwind'
      'direction_zh': '受惠偏多' if direction == 'beneficiary' else '逆風承壓',
      'role': role,
      'close': r.get('close'),
      'pct': r.get('pct'),
      'r5': r.get('r5'),
      'r20': r.get('r20'),
      'f5': r.get('f5'),
      't5': r.get('t5'),
      'yld': r.get('yld'),
      'score': r.get('score'),
      'tech_score': r.get('tech_score'),
      'signals': (r.get('signals') or [])[:4],
  }


def _resolve_rule_impact(rule: dict[str, Any], text: str, us_by: dict[str, dict[str, Any]],
                         rows: dict[str, dict[str, Any]], sector_pct: dict[str, float | None]) -> dict[str, Any]:
  bull_n, bear_n = _score_sentiment_words(text)
  rid = rule['id']

  if rid == 'war_geopolitics':
    peace = any(w in text for w in rule['invert_on_peace']) and bear_n == 0
    polarity = 'bull' if peace else 'mixed'
    explain = rule['explain_bull'] if peace else rule['explain_bear']
    raw_secs = rule['sectors_peace'] if peace else rule['sectors_escalation']
    raw_stks = rule['stocks_peace'] if peace else rule['stocks_escalation']
  elif rid == 'oil_commodity':
    uso_pct = _eff_pct(us_by.get('USO')) or _eff_pct(us_by.get('BNO'))
    oil_down = ('跌' in text or '增產' in text or '回落' in text or '重挫' in text) and '大漲' not in text
    if not oil_down and ('漲' not in text and '減產' not in text) and uso_pct < -0.5:
      oil_down = True
    polarity = 'mixed'
    explain = rule['explain_oil_down'] if oil_down else rule['explain_oil_up']
    raw_secs = rule['sectors_oil_down'] if oil_down else rule['sectors_oil_up']
    raw_stks = rule['stocks_oil_down'] if oil_down else rule['stocks_oil_up']
  elif rid == 'fed_rates_cpi':
    tlt_pct = _eff_pct(us_by.get('TLT'))
    hawkish = any(w in text for w in ('升息', '偏鷹', '通膨升溫', '高於預期', '延後降息', '殖利率飆', '殖利率升'))
    if not hawkish and not any(w in text for w in ('降息', '偏鴿', '通膨降溫', '殖利率回落')) and tlt_pct < -0.4:
      hawkish = True
    polarity = 'bear' if hawkish else 'bull'
    explain = rule['explain_hawkish'] if hawkish else rule['explain_dovish']
    raw_secs = rule['sectors_hawkish'] if hawkish else rule['sectors_dovish']
    raw_stks = rule['stocks_hawkish'] if hawkish else rule['stocks_dovish']
  else:
    if bull_n > bear_n:
      polarity = 'bull'
    elif bear_n > bull_n:
      polarity = 'bear'
    else:
      # Fall back to overnight US symbols for this theme
      us_vals = [_eff_pct(us_by.get(s)) for s in rule.get('us_syms') or [] if s in us_by]
      avg_us = sum(us_vals) / len(us_vals) if us_vals else 0.0
      if avg_us >= 0.5:
        polarity = 'bull'
      elif avg_us <= -0.5:
        polarity = 'bear'
      else:
        polarity = rule.get('default_polarity', 'bull')
    explain = rule.get('explain', '')
    raw_secs = rule.get('sectors', [])
    raw_stks = rule.get('stocks', [])

  dir_for_same = 'headwind' if polarity == 'bear' else 'beneficiary'
  sectors_out = []
  for s in raw_secs:
    d = dir_for_same if s['dir'] == 'same' else s['dir']
    sectors_out.append({
        'name': s['name'],
        'industry': s['ind'],
        'chain_id': s.get('chain_id'),
        'direction': d,
        'direction_zh': '受惠產業' if d == 'beneficiary' else '承壓產業',
        'reason': s['reason'],
        'pct_1d': sector_pct.get(s['ind']),
    })

  stocks_out = []
  seen_c: set[str] = set()
  for code, d_raw, role in raw_stks:
    d = dir_for_same if d_raw == 'same' else d_raw
    card = _stock_card_mini(code, d, role, rows)
    if card and code not in seen_c:
      seen_c.add(code)
      stocks_out.append(card)

  us_triggers = []
  for sym in rule.get('us_syms') or []:
    q = us_by.get(sym)
    if q and q.get('pct') is not None:
      post = (q.get('post') or {}).get('post_pct')
      us_triggers.append({
          'symbol': sym, 'name': q['name'], 'price': q['price'], 'pct': q['pct'],
          'post_pct': post if isinstance(post, (int, float)) else None,
      })

  return {
      'polarity': polarity,
      'polarity_zh': {'bull': '偏多利多', 'bear': '偏空警戒', 'mixed': '多空分歧（資金輪動）'}[polarity],
      'why_it_matters': explain,
      'us_triggers': us_triggers,
      'affected_sectors': sectors_out,
      'affected_stocks': stocks_out,
  }


def _extract_events(news_items: list[dict[str, Any]], us_by: dict[str, dict[str, Any]],
                    rows: dict[str, dict[str, Any]], sector_pct: dict[str, float | None]) -> list[dict[str, Any]]:
  """Clusters raw global/domestic headlines into high-signal clickable Market Events."""
  events: list[dict[str, Any]] = []
  rule_counts: dict[str, int] = {}

  for it in news_items:
    text = f"{it.get('title', '')} {it.get('summary', '')}"
    best_rule = None
    best_hits = 0
    for rule in EVENT_RULES:
      hits = sum(1 for kw in rule['kw'] if kw.lower() in text.lower())
      if hits > best_hits:
        best_hits = hits
        best_rule = rule
    if not best_rule or best_hits == 0:
      continue
    rid = best_rule['id']
    if rule_counts.get(rid, 0) >= 3:
      continue
    rule_counts[rid] = rule_counts.get(rid, 0) + 1

    imp = _resolve_rule_impact(best_rule, text, us_by, rows, sector_pct)
    bull_n, bear_n = _score_sentiment_words(text)
    us_mag = max((abs(_eff_pct(us_by.get(s))) for s in (best_rule.get('us_syms') or [])), default=0.0)
    sev_score = best_hits * 1.4 + (bull_n + bear_n) * 0.9 + (1.8 if us_mag >= 2.0 else (0.8 if us_mag >= 1.0 else 0.0))
    severity = 'high' if sev_score >= 4.2 else ('medium' if sev_score >= 2.4 else 'watch')
    eid = 'ev_' + hashlib.sha1(it['title'].encode('utf-8')).hexdigest()[:10]
    cat = best_rule['cat']
    if it.get('region') == '國內' and cat == 'tech_giant' and '台股' in it['title']:
      cat = 'domestic'

    events.append({
        'id': eid,
        'theme_id': rid,
        'region': it.get('region') or '國際',
        'category': cat,
        'category_label': CAT_LABELS.get(cat, cat),
        'severity': severity,
        'severity_zh': {'high': '高波動', 'medium': '中波動', 'watch': '重點觀察'}[severity],
        'sev_score': round(sev_score, 2),
        'title': it['title'],
        'summary': it.get('summary') or '',
        'source': it.get('source') or '',
        'link': it.get('link') or '',
        'time': it.get('time') or '',
        **imp,
    })

  # Guarantee coverage of big overnight US market moves even if RSS headlines phrased them differently!
  synth_specs = [
      ('MU', 2.2, 'memory_hbm', '美光 Micron 隔夜股價顯著異動，牽動台股 DRAM／NAND 記憶體族群'),
      ('ASX', 2.2, 'semi_foundry_asml', '日月光 ADR 隔夜強勢表態，反映先進封測 CoWoS 資金熱度'),
      ('UMC', 2.2, 'semi_foundry_asml', '聯電 ADR 隔夜明顯波動，留意成熟製程今日開盤表現'),
      ('NVDA', 2.2, 'ai_nvidia_csp', '輝達 NVIDIA 隔夜股價波動，牽動台股 AI 伺服器與散熱供應鏈'),
      ('SOX', 1.5, 'semi_foundry_asml', '費城半導體指數隔夜顯著波動，直接引導今日台股半導體權值開盤方向'),
      ('USO', 1.5, 'oil_commodity', '國際原油指標隔夜明顯調整，關注塑化利差與航空燃油成本連動'),
      ('TSLA', 2.5, 'tesla_ev_robot', '特斯拉 Tesla 隔夜股價異動，留意車電與機器人概念股表現'),
  ]
  by_rule = {r['id']: r for r in EVENT_RULES}
  for sym, thresh, rid, base_title in synth_specs:
    q = us_by.get(sym)
    if not q or q.get('pct') is None:
      continue
    eff = _eff_pct(q)
    if abs(eff) < thresh:
      continue
    # Only synthesize if this theme isn't already prominent at the top
    if any(sym in [u['symbol'] for u in ev.get('us_triggers', [])] and ev['severity'] == 'high' for ev in events[:4]):
      continue
    rule = by_rule[rid]
    dir_word = '大漲' if eff > 0 else '拉回'
    post = (q.get('post') or {}).get('post_pct')
    post_txt = f'（盤後 {post:+.2f}%）' if isinstance(post, (int, float)) and abs(post) >= 0.4 else ''
    title = f'【美股隔夜指標】{q["name"]} ({sym}) {dir_word} {q["pct"]:+.2f}%{post_txt} — {base_title.split("，")[-1]}'
    imp = _resolve_rule_impact(rule, title, us_by, rows, sector_pct)
    if eff < 0 and rid not in ('oil_commodity', 'war_geopolitics'):
      # Flip direction to headwind when the US bellwether dropped!
      imp['polarity'] = 'bear'
      imp['polarity_zh'] = '偏空警戒'
      for s in imp['affected_sectors']:
        s['direction'], s['direction_zh'] = 'headwind', '承壓產業'
      for st in imp['affected_stocks']:
        st['direction'], st['direction_zh'] = 'headwind', '逆風承壓'
    events.append({
        'id': f'ev_us_{sym.lower()}',
        'theme_id': rid,
        'region': '國際',
        'category': rule['cat'],
        'category_label': CAT_LABELS[rule['cat']],
        'severity': 'high' if abs(eff) >= 2.8 else 'medium',
        'severity_zh': '高波動' if abs(eff) >= 2.8 else '中波動',
        'sev_score': round(3.0 + abs(eff), 2),
        'title': title,
        'summary': f'{q["name"]} 收報 {q["price"]}（漲跌 {q["chg"]:+} / {q["pct"]:+.2f}%）{post_txt}。',
        'source': '美股盤後即時行情彙整',
        'link': q.get('url') or '',
        'time': q.get('time') or dt.datetime.now(TZ).isoformat(timespec='seconds'),
        **imp,
    })

  events.sort(key=lambda e: (-e['sev_score'], e.get('time') or ''), reverse=False)
  events.sort(key=lambda e: (e['sev_score'], e.get('time') or ''), reverse=True)
  return events[:16]


def _rejudge_actions(us_by: dict[str, dict[str, Any]], events: list[dict[str, Any]],
                     rows: dict[str, dict[str, Any]], picks_payload: dict[str, Any]) -> dict[str, Any]:
  """Computes pre-market sentiment thermometer & re-judges today's TW buy/dip/catalyst/trim actions."""
  sox = _eff_pct(us_by.get('SOX'))
  ixic = _eff_pct(us_by.get('IXIC'))
  spx = _eff_pct(us_by.get('SPX'))
  tsm = _eff_pct(us_by.get('TSM'))
  vix = _eff_pct(us_by.get('VIXY'))
  usdtwd_q = us_by.get('USDTWD') or {}
  usdtwd_pct = float(usdtwd_q.get('pct') or 0.0)

  # TSM ADR conversion vs 2330 close (1 TSM ADR = 5 shares of 2330)
  tsm_q = us_by.get('TSM') or {}
  r2330 = rows.get('2330') or {}
  adr_spread_pct = None
  adr_twd_equiv = None
  if tsm_q.get('price') and usdtwd_q.get('price') and r2330.get('close'):
    adr_twd_equiv = round(float(tsm_q['price']) * float(usdtwd_q['price']) / 5.0, 1)
    adr_spread_pct = round((adr_twd_equiv / float(r2330['close']) - 1) * 100, 2)

  # News net sentiment (-25 .. +25)
  ev_net = 0.0
  for ev in events[:12]:
    w = 2.5 if ev['severity'] == 'high' else (1.5 if ev['severity'] == 'medium' else 0.8)
    if ev['polarity'] == 'bull':
      ev_net += w
    elif ev['polarity'] == 'bear':
      ev_net -= w
  ev_net = max(-25.0, min(25.0, ev_net * 2.2))

  # Composite Pre-Market Score (-100 .. +100)
  us_score = max(-55.0, min(55.0, tsm * 9.5 + sox * 7.5 + ixic * 4.5 + spx * 3.0))
  macro_score = max(-20.0, min(20.0, -vix * 2.2 - usdtwd_pct * 8.0))
  total_score = round(max(-100.0, min(100.0, us_score + macro_score + ev_net)), 1)

  if total_score >= 32:
    regime, regime_cls = '積極偏多 · 順勢布局主流', 'solid-bull'
    alloc = '建議持股水位 70%–85%'
    advice = '隔夜美股科技與費半明顯走強，有利台股電子權值與主流題材開高表態；操作上優先鎖定籌碼＋營收雙強且具隔夜順風催化的個股，但若個股開盤直接跳空逾 4% 宜等盤中回測均價線不破再介入。'
  elif total_score >= 10:
    regime, regime_cls = '震盪偏多 · 買黑不追高', 'bull'
    alloc = '建議持股水位 55%–70%'
    advice = '隔夜美股與台積電 ADR 溫和偏多，但族群表現分化；今日台股預估呈現指數有撐、個股輪動格局，宜聚焦美股強勢次產業（如封測、記憶體、AI 網通）分批布局，避開隔夜ADR走弱族群。'
  elif total_score > -12:
    regime, regime_cls = '中性震盪 · 汰弱留強選股不選市', ''
    alloc = '建議持股水位 45%–60%'
    advice = '國際股市與消息面多空交錯，大盤缺乏單邊突破動能；今日操作宜「買支撐、賣壓力」，嚴格篩選投信連買且營收創高之個股低接，對漲多乖離過大標的適度獲利調節。'
  elif total_score > -32:
    regime, regime_cls = '謹慎防禦 · 減碼高乖離、轉進避風港', 'bear'
    alloc = '建議持股水位 30%–45%'
    advice = '隔夜美股拉回或國際利空干擾升溫，台股開盤易受外資調節壓力測試支撐；今日不宜貿然追價電子高價股，建議拉高現金比重，或逢低觀察高殖利率／電信金融／事件受惠防禦標的。'
  else:
    regime, regime_cls = '高度警戒 · 嚴控部位、現金與避險優先', 'solid-bear'
    alloc = '建議持股水位 15%–30%'
    advice = '美股重挫或重大地緣／總經黑天鵝衝擊，今日台股面臨跳空回測壓力；開盤切忌急於搶短接刀，既有持股若跌破停損價應果斷執行紀律，待恐慌量縮止穩訊號浮現後再行布局。'

  # Estimated TAIEX opening point impulse (rough reference from TSM + SOX beta)
  taiex_row = db.query_one("SELECT close FROM index_daily WHERE name='發行量加權股價指數' ORDER BY date DESC LIMIT 1")
  taiex_close = float(taiex_row[0]) if taiex_row and taiex_row[0] else None
  est_open_pct = round(tsm * 0.42 + sox * 0.25 + ixic * 0.13, 2)
  est_open_pts = round(taiex_close * est_open_pct / 100.0) if taiex_close else None

  # Compute per-industry and per-stock overnight catalyst impulse
  ind_imp: dict[str, float] = {}
  stk_imp: dict[str, float] = {}
  stk_reasons: dict[str, list[str]] = {}

  for sym, mappings in US_SECTOR_IMPULSE.items():
    q = us_by.get(sym)
    eff = _eff_pct(q)
    if abs(eff) < 0.35 or not q:
      continue
    for ind_name, weight, codes in mappings:
      delta = eff * weight
      ind_imp[ind_name] = ind_imp.get(ind_name, 0.0) + delta
      for c in codes:
        stk_imp[c] = stk_imp.get(c, 0.0) + eff * (weight + 0.35)
        dir_str = '勁揚' if eff > 0 else '回檔'
        stk_reasons.setdefault(c, []).append(f'隔夜 {q["name"]} ({sym}) {dir_str} {eff:+.2f}%')

  for ev in events[:12]:
    w = 1.8 if ev['severity'] == 'high' else (1.1 if ev['severity'] == 'medium' else 0.6)
    for sec in ev.get('affected_sectors') or []:
      sgn = 1.0 if sec['direction'] == 'beneficiary' else -1.0
      ind_imp[sec['industry']] = ind_imp.get(sec['industry'], 0.0) + sgn * w * 0.7
    for st in ev.get('affected_stocks') or []:
      c = st['code']
      sgn = 1.0 if st['direction'] == 'beneficiary' else -1.0
      stk_imp[c] = stk_imp.get(c, 0.0) + sgn * w
      tag = f'事件{"受惠" if sgn > 0 else "逆風"}：{ev["title"][:28]}…' if len(ev['title']) > 28 else f'事件{"受惠" if sgn > 0 else "逆風"}：{ev["title"]}'
      if len(stk_reasons.get(c, [])) < 3 and tag not in stk_reasons.get(c, []):
        stk_reasons.setdefault(c, []).append(tag)

  # 1. Re-judge yesterday's quantitative `picks`
  orig_picks = (picks_payload or {}).get('picks') or []
  pick_codes = {p['code'] for p in orig_picks}
  buy_list: list[dict[str, Any]] = []
  dip_list: list[dict[str, Any]] = []
  trim_list: list[dict[str, Any]] = []

  for p in orig_picks:
    c = p['code']
    r = rows.get(c, {})
    imp = stk_imp.get(c, 0.0) + ind_imp.get(p.get('industry') or '', 0.0) * 0.65
    adj = max(-15.0, min(15.0, imp * 2.4))
    if total_score <= -25:
      adj -= 4.0
    pm_score = round(max(0.0, min(100.0, (p.get('score') or 70) + adj)), 1)
    bias20 = r.get('bias20') or 0.0
    rsi = r.get('rsi') or 50.0
    cats = stk_reasons.get(c, [])
    L = p.get('levels') or {}
    sup_txt = f'{L["support"]} 元' if L.get('support') else '月線支撐'
    res_txt = f'{L["resistance"]} 元' if L.get('resistance') else '前高壓力'
    stop_txt = f'{L["stop"]} 元' if L.get('stop') else '停損位'

    entry_obj = {
        'code': c, 'name': p['name'], 'market': p.get('market'), 'industry': p.get('industry'),
        'close': p.get('close'), 'pct': p.get('pct'),
        'orig_score': p.get('score'), 'orig_rank': p.get('rank'),
        'premarket_score': pm_score, 'score_delta': round(pm_score - (p.get('score') or 0), 1),
        'levels': L,
        'catalysts': cats[:3] or ['量化籌碼＋月營收動能居全市場前段班'],
        'reasons': (p.get('reasons') or [])[:2],
        'signals': (p.get('signals') or [])[:4],
    }

    if imp <= -1.8 or (total_score <= -30 and bias20 > 8):
      entry_obj['verdict'] = '逆風暫緩／減碼'
      entry_obj['plan'] = f'雖原列收盤量化推薦 #{p["rank"]}，但受隔夜美股／事件逆風影響，今日開盤不建議追買；若已持有且跌破 {stop_txt} 宜減碼因應。'
      trim_list.append(entry_obj)
    elif bias20 >= 12.0 or rsi >= 75.0 or imp < -0.35 or total_score <= -15:
      entry_obj['verdict'] = '拉回支撐低接'
      why_wait = f'短線乖離率 {bias20:.1f}%／RSI {rsi:.0f} 偏高' if (bias20 >= 12 or rsi >= 75) else '盤前國際氣氛偏震盪'
      entry_obj['plan'] = f'{why_wait}，切勿開盤追高；建議耐心等待盤中回測 {sup_txt} 附近量縮守穩再分批承接，跌破 {stop_txt} 停損。'
      dip_list.append(entry_obj)
    else:
      entry_obj['verdict'] = '順風首選買進'
      entry_obj['plan'] = f'基本面與法人籌碼強勁，加上盤前產業順風助攻；開盤若未過度跳空追高（留意上方壓力 {res_txt}），守穩 {sup_txt} 可順勢分批布局，停損設 {stop_txt}。'
      buy_list.append(entry_obj)

  buy_list.sort(key=lambda x: -x['premarket_score'])
  dip_list.sort(key=lambda x: -x['premarket_score'])

  # 2. Event-Driven Catalyst / Safe-Haven Opportunities outside `orig_picks`
  catalyst_list: list[dict[str, Any]] = []
  for c, imp in sorted(stk_imp.items(), key=lambda kv: -kv[1]):
    if c in pick_codes or imp < 1.2 or c not in rows:
      continue
    r = rows[c]
    if (r.get('value') or 0) < 0.8 and r.get('type') != 'ETF':
      continue
    if set(r.get('risk') or []) & {'處置', '全額交割'}:
      continue
    tscore = r.get('tech_score') or 50
    if tscore < 42 and r.get('type') == '股票':
      continue
    sup = r.get('_support') or r.get('ma20')
    res = r.get('_resistance') or r.get('hi52')
    catalyst_list.append({
        'code': c, 'name': r['name'], 'market': r['market'], 'industry': r.get('industry'),
        'type': r.get('type'),
        'close': r.get('close'), 'pct': r.get('pct'),
        'orig_score': r.get('score'), 'premarket_score': round(min(98.0, (r.get('score') or 60) + imp * 2.8), 1),
        'impulse': round(imp, 2),
        'verdict': '事件催化關注',
        'catalysts': stk_reasons.get(c, [])[:3],
        'levels': {'support': _r(sup), 'resistance': _r(res)},
        'plan': (f'受隔夜美股／重大事件直接催化，今日資金關注度高；'
                 f'建議觀察開盤量能與 {f"{_r(sup)} 元支撐" if sup else "均線支撐"}，順勢短打不追漲停。'),
        'signals': (r.get('signals') or [])[:4],
    })
    if len(catalyst_list) >= 10:
      break

  # 3. Additional Headwind / Avoid / Trim Watch stocks (major liquid stocks facing overnight headwinds)
  seen_trim = {x['code'] for x in trim_list}
  for c, imp in sorted(stk_imp.items(), key=lambda kv: kv[1]):
    if imp > -1.0 or c in seen_trim or c not in rows:
      continue
    r = rows[c]
    if (r.get('value') or 0) < 1.0:
      continue
    sup = r.get('_support') or r.get('ma20')
    trim_list.append({
        'code': c, 'name': r['name'], 'market': r['market'], 'industry': r.get('industry'),
        'close': r.get('close'), 'pct': r.get('pct'),
        'orig_score': r.get('score'),
        'premarket_score': round(max(10.0, (r.get('score') or 45) + imp * 2.5), 1),
        'verdict': '逆風減碼／避開',
        'catalysts': stk_reasons.get(c, [])[:3],
        'levels': {'support': _r(sup)},
        'plan': (f'隔夜對應美股 ADR 或事件面偏空承壓'
                 f'{"，且近期外資偏賣" if (r.get("f5") or 0) < 0 else ""}；'
                 f'今日開盤宜避開追買，持有者若反彈無力或跌破 {f"{_r(sup)} 元" if sup else "月線"} 建議減碼保護獲利。'),
        'signals': (r.get('signals') or [])[:4],
    })
    seen_trim.add(c)
    if len(trim_list) >= 10:
      break

  return {
      'sentiment_score': total_score,
      'regime': regime,
      'regime_cls': regime_cls,
      'allocation': alloc,
      'summary_advice': advice,
      'taiex_est': {
          'prev_close': taiex_close,
          'est_pct': est_open_pct,
          'est_pts': est_open_pts,
          'tsm_adr_twd': adr_twd_equiv,
          'tsm_adr_spread_pct': adr_spread_pct,
          '2330_close': r2330.get('close'),
      },
      'actions': {
          'buy': buy_list[:12],
          'dip': dip_list[:10],
          'catalyst': catalyst_list[:10],
          'trim': trim_list[:10],
      },
  }


_CACHE: dict[str, Any] = {'t': 0.0, 'ver': -1, 'payload': None}


def build_morning_briefing(rows: dict[str, dict[str, Any]], picks_payload: dict[str, Any],
                           market_payload: dict[str, Any], force_network: bool = False) -> dict[str, Any]:
  """Builds (or returns cached) complete Morning Pre-Market Briefing + Event Radar + Action Re-judgment."""
  now = dt.datetime.now(TZ)
  kv_cached = db.get_kv('morning_raw_cache') or {}
  age = time.time() - float(kv_cached.get('fetched_at') or 0)

  if force_network or age > 900 or not kv_cached.get('us'):
    us = global_market.fetch_us_quotes(include_extended=True)
    news = global_market.fetch_catalyst_news(max_age_hours=48)
    if us.get('by_symbol') or news:
      kv_cached = {
          'fetched_at': time.time(),
          'us': us if us.get('by_symbol') else (kv_cached.get('us') or us),
          'news': news if news else (kv_cached.get('news') or []),
      }
      db.set_kv('morning_raw_cache', kv_cached)

  us = kv_cached.get('us') or {'by_symbol': {}, 'indices': [], 'adrs': [], 'tech': [], 'macro': []}
  news = kv_cached.get('news') or []
  us_by = us.get('by_symbol') or {}

  sector_pct = {s['name']: s.get('pct_1d') for s in (market_payload or {}).get('sectors') or []}
  events = _extract_events(news, us_by, rows, sector_pct)
  decision = _rejudge_actions(us_by, events, rows, picks_payload)
  session = global_market.us_session_info(now)

  fetched_ts = float(kv_cached.get('fetched_at') or time.time())
  fetched_iso = dt.datetime.fromtimestamp(fetched_ts, TZ).isoformat(timespec='seconds')

  out = {
      'date': now.date().isoformat(),
      'data_date': (market_payload or {}).get('date'),
      'updated_at': fetched_iso,
      'us_session': session,
      'us_market': {
          'indices': us.get('indices') or [],
          'adrs': us.get('adrs') or [],
          'tech': us.get('tech') or [],
          'macro': us.get('macro') or [],
      },
      'decision': decision,
      'events': events,
      'raw_news_count': len(news),
      'schedule_note': '每個交易日早上 07:45 與 08:35 自動抓取美股收盤＋盤後異動與全球／國內重大新聞，重新研判今日台股買賣操作。',
      'disclaimer': config.DISCLAIMER,
  }
  return out
