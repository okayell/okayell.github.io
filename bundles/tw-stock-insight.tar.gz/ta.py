"""台股智慧選股站 — technical-analysis engine (SPEC.md §4).

Pure functions, Python standard library only.

* Indicator helpers: `sma`, `ema`, `rsi`, `kd`, `macd`, `bollinger`, `atr`,
  `adx`, `obv`, `resample` and `compute_indicators(bars)` (chart arrays).
* `analyze(bars, tf)` — full Traditional-Chinese technical analysis (§4.3):
  multi-horizon trend, support/resistance, trendlines, chart patterns,
  candlesticks, indicator signals, volume–price, score, trading plan,
  narrative and chart annotations.
* `quick_signals(bars, ind)` — compact signals for batch use (§4.4).

`bars` rows are `[date 'YYYY-MM-DD', open, high, low, close, volume(張)]`,
ascending.  Every output is JSON-safe (no NaN / inf).
"""

from __future__ import annotations

import datetime
import math
from typing import Any, Sequence

Series = list  # list[float | None], aligned with bars

STANCES = {2: "強勢多頭", 1: "偏多", 0: "中性", -1: "偏空", -2: "弱勢空頭"}
TREND_LABELS = {2: "多頭", 1: "偏多", 0: "盤整", -1: "偏空", -2: "空頭"}
LEVEL_KINDS = ("前波高點", "前波低點", "頸線", "箱型上緣", "箱型下緣", "缺口",
               "成交密集區", "整數關卡", "52週高點", "52週低點")
PATTERN_NAMES = ("W底", "M頭", "頭肩底", "頭肩頂", "上升三角形", "下降三角形",
                 "收斂三角形", "上升楔形", "下降楔形", "上升通道", "下降通道",
                 "箱型整理", "箱型突破", "箱型跌破")
PATTERN_STATUS = ("形成中", "已突破", "已跌破", "失效")
VOLUME_STATES = ("價漲量增", "價漲量縮", "價跌量增", "價跌量縮", "爆量", "量縮")
QUICK_TAGS = (
  "多頭排列", "空頭排列", "站上月線", "跌破月線", "站上季線", "跌破季線", "均線糾結",
  "創52週新高", "突破60日高", "跌破60日低", "突破箱型", "跳空上漲", "跳空下跌",
  "KD黃金交叉", "KD死亡交叉", "KD高檔鈍化", "KD低檔鈍化", "MACD黃金交叉",
  "MACD死亡交叉", "MACD翻紅", "MACD翻綠", "RSI超買", "RSI超賣", "布林突破上軌",
  "布林跌破下軌", "布林收斂", "爆量", "量增", "量縮", "價漲量增", "價跌量增",
  "長紅K", "長黑K", "多頭吞噬", "空頭吞噬", "錘子線", "十字線", "晨星", "夜星")
NARRATIVE_TITLES = ("📌 總結", "📈 趨勢判斷", "🧱 支撐與壓力", "🔺 型態辨識",
                    "📊 指標訊號", "🔊 量價關係", "🎯 操作參考",
                    "\u26a0\ufe0f 風險提示")
INDICATOR_KEYS = ("ma5", "ma10", "ma20", "ma60", "ma120", "ma240", "bb_up",
                  "bb_mid", "bb_lo", "k", "d", "dif", "dea", "hist", "rsi6",
                  "rsi14", "vol_ma5", "vol_ma20")
DISCLAIMER = "以上為技術面推演，非投資建議"

C_SUP = "#0284c7"      # support lines (blue)
C_RES = "#ea580c"      # resistance lines (orange)
C_BULL = "#dc2626"     # bullish = red (Taiwan convention)
C_BEAR = "#16a34a"     # bearish = green
C_NEUT = "#6b7280"     # neutral = gray
C_TL_SUP = "#2563eb"   # ascending trendline
C_TL_RES = "#ea580c"   # descending trendline
C_BROKEN = "#9ca3af"   # broken trendline
C_PAT = "#7c3aed"      # pattern outline / neckline

MIN_BARS = 30

# Per-timeframe parameters: bars per year, fractal half-width, look-backs …
_TF: dict[str, dict[str, Any]] = {
  "D": {"bpy": 250, "k": 3, "sr": 250, "tl": 250, "pat": 220, "recent": 60,
        "brk": 30, "box_min": 20, "box_lag": 15, "half": 120, "poc": 120,
        "gap": 120, "zz_lo": 0.03, "zz_hi": 0.15, "unit": "日", "big": 0.02},
  "W": {"bpy": 52, "k": 2, "sr": 156, "tl": 156, "pat": 130, "recent": 26,
        "brk": 12, "box_min": 10, "box_lag": 6, "half": 52, "poc": 52,
        "gap": 52, "zz_lo": 0.06, "zz_hi": 0.25, "unit": "週", "big": 0.04},
  "M": {"bpy": 12, "k": 2, "sr": 120, "tl": 120, "pat": 96, "recent": 12,
        "brk": 6, "box_min": 6, "box_lag": 4, "half": 24, "poc": 36,
        "gap": 24, "zz_lo": 0.10, "zz_hi": 0.35, "unit": "月", "big": 0.06},
}


# ───────────────────────────── numeric helpers ─────────────────────────────

def _clamp(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
  """Clamps x into [lo, hi]."""
  return lo if x < lo else hi if x > hi else x


def _ff(x: Any, default: float = 0.0) -> float:
  """Converts to a finite float, else returns default."""
  try:
    v = float(x)
  except (TypeError, ValueError):
    return default
  return v if math.isfinite(v) else default


def _first_valid(xs: Sequence[Any]) -> int:
  """Index of the first non-None element (len(xs) if none)."""
  for i, x in enumerate(xs):
    if x is not None:
      return i
  return len(xs)


def _at(xs: Sequence[Any] | None, i: int) -> Any:
  """xs[i] for 0 <= i < len(xs), else None."""
  if xs is None or i < 0 or i >= len(xs):
    return None
  return xs[i]


def _mean(xs: Sequence[float]) -> float:
  """Arithmetic mean (0.0 for an empty sequence)."""
  return sum(xs) / len(xs) if xs else 0.0


def _median(xs: Sequence[float]) -> float:
  """Median (0.0 for an empty sequence)."""
  s = sorted(xs)
  m = len(s)
  if not m:
    return 0.0
  return s[m // 2] if m % 2 else (s[m // 2 - 1] + s[m // 2]) / 2


def _tick(p: float) -> float:
  """Taiwan stock tick size for price p."""
  p = abs(p)
  if p < 10:
    return 0.01
  if p < 50:
    return 0.05
  if p < 100:
    return 0.1
  if p < 500:
    return 0.5
  if p < 1000:
    return 1.0
  return 5.0


def _rt(x: float | None, mode: int = 0) -> float | None:
  """Rounds to the Taiwan tick (mode -1 floor, 0 nearest, 1 ceil)."""
  if x is None or not math.isfinite(x):
    return None
  t = _tick(x)
  q = x / t
  if mode < 0:
    q = math.floor(q + 1e-9)
  elif mode > 0:
    q = math.ceil(q - 1e-9)
  else:
    q = math.floor(q + 0.5)
  return round(q * t, 2)


def _rp(x: float | None) -> float | None:
  """Display rounding for computed prices (MA, ATR …)."""
  if x is None or not math.isfinite(x):
    return None
  a = abs(x)
  nd = 1 if a >= 100 else 2 if a >= 1 else 4
  return round(x, nd)


def _r(x: float | None, nd: int = 2) -> float | None:
  """round() that maps None / NaN / inf to None."""
  if x is None or not math.isfinite(x):
    return None
  return round(x, nd)


def _fp(x: float | None) -> str:
  """Formats a price for narrative text (no trailing zeros)."""
  if x is None or not math.isfinite(x):
    return "—"
  a = abs(x)
  nd = 1 if a >= 100 else 2 if a >= 1 else 4
  s = f"{x:.{nd}f}"
  if "." in s:
    s = s.rstrip("0").rstrip(".")
  return s


def _ft(x: float | None) -> str:
  """Formats a price rounded to the Taiwan tick."""
  return _fp(_rt(x))


def _fn(vals: Sequence[float | None]) -> list[str]:
  """Formats a group of indicator values with shared decimals (e.g. DIF/DEA/OSC)."""
  ok = [abs(v) for v in vals if v is not None and math.isfinite(v)]
  m = max(ok) if ok else 0.0
  nd = 1 if m >= 100 else 2 if m >= 1 else 3 if m >= 0.1 else 4
  return ["—" if v is None or not math.isfinite(v) else f"{v:.{nd}f}" for v in vals]


def _fv(x: float | None) -> str:
  """Formats a volume (張) with thousands separators."""
  if x is None or not math.isfinite(x):
    return "—"
  return f"{x:,.0f}" if abs(x) >= 10 else f"{x:,.1f}"


def _pct(a: float, b: float) -> float:
  """Percent change from b to a (0 when b is 0)."""
  return (a / b - 1.0) * 100.0 if b else 0.0


def _sp(x: float, nd: int = 1) -> str:
  """Signed percent string, e.g. '+3.2%'."""
  return f"{x:+.{nd}f}%"


# ───────────────────────────── indicators (§4.2) ─────────────────────────────

def sma(xs: Sequence[float | None], n: int) -> Series:
  """Simple moving average; None during warm-up (leading None skipped)."""
  m = len(xs)
  out: Series = [None] * m
  s = _first_valid(xs)
  if n <= 0 or m - s < n:
    return out
  acc = 0.0
  for i in range(s, s + n):
    acc += xs[i]
  out[s + n - 1] = acc / n
  for i in range(s + n, m):
    acc += xs[i] - xs[i - n]
    out[i] = acc / n
  return out


def ema(xs: Sequence[float | None], n: int) -> Series:
  """Exponential MA (alpha 2/(n+1)) seeded with the SMA of the first n values."""
  m = len(xs)
  out: Series = [None] * m
  s = _first_valid(xs)
  if n <= 0 or m - s < n:
    return out
  a = 2.0 / (n + 1)
  e = sum(xs[s:s + n]) / n
  out[s + n - 1] = e
  for i in range(s + n, m):
    e += a * (xs[i] - e)
    out[i] = e
  return out


def _rsi_val(g: float, l: float) -> float:
  """RSI value from Wilder averages (50 when flat, 100 when no losses)."""
  if l <= 0:
    return 100.0 if g > 0 else 50.0
  return 100.0 - 100.0 / (1.0 + g / l)


def rsi(closes: Sequence[float], n: int = 14) -> Series:
  """Wilder RSI: first value at index n (simple average seed), then smoothed."""
  m = len(closes)
  out: Series = [None] * m
  if n <= 0 or m <= n:
    return out
  g = l = 0.0
  for i in range(1, n + 1):
    ch = closes[i] - closes[i - 1]
    if ch > 0:
      g += ch
    else:
      l -= ch
  g /= n
  l /= n
  out[n] = _rsi_val(g, l)
  k = n - 1
  for i in range(n + 1, m):
    ch = closes[i] - closes[i - 1]
    if ch > 0:
      g = (g * k + ch) / n
      l = l * k / n
    else:
      g = g * k / n
      l = (l * k - ch) / n
    out[i] = _rsi_val(g, l)
  return out


def kd(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float],
       n: int = 9) -> tuple[Series, Series]:
  """Taiwan KD: RSV over n bars, K = 2/3·K₋₁ + 1/3·RSV, D = 2/3·D₋₁ + 1/3·K, seed 50."""
  m = len(closes)
  ks: Series = [None] * m
  ds: Series = [None] * m
  if n <= 0 or m < n:
    return ks, ds
  k = d = 50.0
  for i in range(n - 1, m):
    hh = max(highs[i - n + 1:i + 1])
    ll = min(lows[i - n + 1:i + 1])
    rng = hh - ll
    rsv = 50.0 if rng <= 0 else _clamp((closes[i] - ll) / rng * 100.0, 0.0, 100.0)
    k = k * 2.0 / 3.0 + rsv / 3.0
    d = d * 2.0 / 3.0 + k / 3.0
    ks[i] = k
    ds[i] = d
  return ks, ds


def macd(closes: Sequence[float], fast: int = 12, slow: int = 26,
         signal: int = 9) -> tuple[Series, Series, Series]:
  """MACD: dif = EMAfast − EMAslow, dea = EMA(dif, signal), hist = dif − dea (OSC)."""
  ef = ema(closes, fast)
  es = ema(closes, slow)
  dif: Series = [None if a is None or b is None else a - b for a, b in zip(ef, es)]
  dea = ema(dif, signal)
  hist: Series = [None if a is None or b is None else a - b for a, b in zip(dif, dea)]
  return dif, dea, hist


def bollinger(closes: Sequence[float], n: int = 20,
              k: float = 2.0) -> tuple[Series, Series, Series]:
  """Bollinger bands (population std): returns (up, mid, lo)."""
  m = len(closes)
  up: Series = [None] * m
  mid: Series = [None] * m
  lo: Series = [None] * m
  if n <= 0 or m < n:
    return up, mid, lo
  base = closes[0]
  s1 = s2 = 0.0
  for i in range(m):
    y = closes[i] - base
    s1 += y
    s2 += y * y
    if i >= n:
      y0 = closes[i - n] - base
      s1 -= y0
      s2 -= y0 * y0
    if i >= n - 1:
      mu = s1 / n
      var = s2 / n - mu * mu
      sd = math.sqrt(var) if var > 0 else 0.0
      if sd < 1e-9 * (abs(base) + 1.0):
        sd = 0.0
      c = mu + base
      mid[i] = c
      up[i] = c + k * sd
      lo[i] = c - k * sd
  return up, mid, lo


def _true_range(highs: Sequence[float], lows: Sequence[float],
                closes: Sequence[float]) -> list[float]:
  """True range per bar (TR₀ = H₀ − L₀)."""
  m = len(closes)
  if not m:
    return []
  tr = [highs[0] - lows[0]]
  for i in range(1, m):
    pc = closes[i - 1]
    h = highs[i]
    l = lows[i]
    a = h - l
    b = h - pc if h > pc else pc - h
    c = l - pc if l > pc else pc - l
    tr.append(a if a >= b and a >= c else b if b >= c else c)
  return tr


def atr(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float],
        n: int = 14) -> Series:
  """Wilder ATR. TR₀ = H₀−L₀; first value = mean(TR[0:n]) at index n−1."""
  m = len(closes)
  out: Series = [None] * m
  if n <= 0 or m < n:
    return out
  tr = _true_range(highs, lows, closes)
  a = sum(tr[:n]) / n
  out[n - 1] = a
  k = n - 1
  for i in range(n, m):
    a = (a * k + tr[i]) / n
    out[i] = a
  return out


def adx(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float],
        n: int = 14) -> tuple[Series, Series, Series]:
  """Wilder DMI: returns (adx, +DI, −DI). DI from index n, ADX from 2n−1."""
  m = len(closes)
  ax: Series = [None] * m
  pdi: Series = [None] * m
  mdi: Series = [None] * m
  if n <= 0 or m < n + 1:
    return ax, pdi, mdi
  dx: list[float] = [0.0] * m
  tr_s = p_s = m_s = 0.0
  for i in range(1, m):
    up = highs[i] - highs[i - 1]
    dn = lows[i - 1] - lows[i]
    pdm = up if up > dn and up > 0 else 0.0
    mdm = dn if dn > up and dn > 0 else 0.0
    pc = closes[i - 1]
    tr = max(highs[i] - lows[i], abs(highs[i] - pc), abs(lows[i] - pc))
    if i <= n:
      tr_s += tr
      p_s += pdm
      m_s += mdm
      if i < n:
        continue
    else:
      tr_s += tr - tr_s / n
      p_s += pdm - p_s / n
      m_s += mdm - m_s / n
    p = 100.0 * p_s / tr_s if tr_s > 0 else 0.0
    q = 100.0 * m_s / tr_s if tr_s > 0 else 0.0
    pdi[i] = p
    mdi[i] = q
    dx[i] = 100.0 * abs(p - q) / (p + q) if p + q > 0 else 0.0
  if m >= 2 * n:
    a = sum(dx[n:2 * n]) / n
    ax[2 * n - 1] = a
    for i in range(2 * n, m):
      a = (a * (n - 1) + dx[i]) / n
      ax[i] = a
  return ax, pdi, mdi


def obv(closes: Sequence[float], vols: Sequence[float]) -> Series:
  """On-balance volume starting at 0 (no warm-up)."""
  m = len(closes)
  out: Series = [0.0] * m
  acc = 0.0
  for i in range(1, m):
    if closes[i] > closes[i - 1]:
      acc += vols[i]
    elif closes[i] < closes[i - 1]:
      acc -= vols[i]
    out[i] = acc
  return out


def resample(bars: Sequence[Sequence[Any]], tf: str) -> list[list[Any]]:
  """Resamples daily bars: 'W' = ISO week, 'M' = calendar month, else copy.

  The bar date of a weekly/monthly bar is its last trading day; open = first
  open, high = max, low = min, close = last close, volume = sum.
  """
  tf = (tf or "D").upper()
  if tf not in ("W", "M"):
    return [list(b) for b in bars]
  out: list[list[Any]] = []
  prev = None
  for b in bars:
    d = str(b[0])[:10]
    if tf == "W":
      key = datetime.date.fromisoformat(d).isocalendar()[:2]
    else:
      key = d[:7]
    o, h, l, c = b[1], b[2], b[3], b[4]
    v = (b[5] if len(b) > 5 else 0) or 0
    if key != prev:
      out.append([d, o, h, l, c, v])
      prev = key
    else:
      cur = out[-1]
      cur[0] = d
      if h > cur[2]:
        cur[2] = h
      if l < cur[3]:
        cur[3] = l
      cur[4] = c
      cur[5] = cur[5] + v
  return out


def _raw_indicators(h: Sequence[float], l: Sequence[float], c: Sequence[float],
                    v: Sequence[float]) -> dict[str, Series]:
  """Unrounded chart indicators keyed exactly like compute_indicators()."""
  bb_up, bb_mid, bb_lo = bollinger(c, 20, 2.0)
  ks, ds = kd(h, l, c, 9)
  dif, dea, hist = macd(c, 12, 26, 9)
  return {
    "ma5": sma(c, 5), "ma10": sma(c, 10), "ma20": bb_mid, "ma60": sma(c, 60),
    "ma120": sma(c, 120), "ma240": sma(c, 240),
    "bb_up": bb_up, "bb_mid": bb_mid, "bb_lo": bb_lo,
    "k": ks, "d": ds, "dif": dif, "dea": dea, "hist": hist,
    "rsi6": rsi(c, 6), "rsi14": rsi(c, 14),
    "vol_ma5": sma(v, 5), "vol_ma20": sma(v, 20),
  }


def _round_list(xs: Series, nd: int) -> Series:
  """Rounds every non-None value to nd decimals."""
  return [None if x is None else round(x, nd) for x in xs]


def compute_indicators(bars: Sequence[Sequence[Any]]) -> dict[str, Series]:
  """Chart indicators aligned 1:1 with bars (None during warm-up), rounded.

  Rows are never dropped: an invalid price is forward-filled from the previous
  valid close so the arrays always have len(bars) entries.
  """
  m = len(bars or ())
  closes: list[float | None] = []
  for b in bars or ():
    try:
      c = float(b[4])
    except (TypeError, ValueError, IndexError):
      c = math.nan
    closes.append(c if math.isfinite(c) and c > 0 else None)
  first = next((c for c in closes if c is not None), None)
  if first is None:
    return {k: [None] * m for k in INDICATOR_KEYS}
  h: list[float] = []
  l: list[float] = []
  c: list[float] = []
  v: list[float] = []
  prev = first
  for b, cl in zip(bars, closes):
    if cl is None:
      cl, hi, lo, vol = prev, prev, prev, 0.0
    else:
      hi = _ff(b[2], cl) if len(b) > 2 else cl
      lo = _ff(b[3], cl) if len(b) > 3 else cl
      op = _ff(b[1], cl) if len(b) > 1 else cl
      hi = max(hi if hi > 0 else cl, cl, op if op > 0 else cl)
      lo = min(lo if lo > 0 else cl, cl, op if op > 0 else cl)
      vol = _ff(b[5], 0.0) if len(b) > 5 else 0.0
    h.append(hi)
    l.append(lo)
    c.append(cl)
    v.append(vol if vol > 0 else 0.0)
    prev = cl
  raw = _raw_indicators(h, l, c, v)
  ref = _median(c[-60:])
  dp = 2 if ref >= 10 else 3 if ref >= 1 else 4
  dm = min(4, dp + 1)
  nds = {"k": 2, "d": 2, "rsi6": 2, "rsi14": 2, "vol_ma5": 1, "vol_ma20": 1,
         "dif": dm, "dea": dm, "hist": dm}
  return {k: _round_list(raw[k], nds.get(k, dp)) for k in INDICATOR_KEYS}


def _clean_bars(bars: Sequence[Sequence[Any]] | None) -> list[tuple]:
  """Validates rows → tuples (date, o, h, l, c, v); drops rows without a valid close."""
  out: list[tuple] = []
  for b in bars or ():
    try:
      d = str(b[0])[:10]
      c = float(b[4])
    except (TypeError, ValueError, IndexError):
      continue
    if not math.isfinite(c) or c <= 0:
      continue
    o = _ff(b[1], c)
    h = _ff(b[2], c)
    l = _ff(b[3], c)
    o = o if o > 0 else c
    h = h if h > 0 else c
    l = l if l > 0 else c
    hi = max(o, h, l, c)
    lo = min(o, h, l, c)
    v = _ff(b[5], 0.0) if len(b) > 5 else 0.0
    out.append((d, o, hi, lo, c, v if v > 0 else 0.0))
  if any(out[i][0] >= out[i + 1][0] for i in range(len(out) - 1)):
    dedup = {r[0]: r for r in out}
    out = [dedup[k] for k in sorted(dedup)]
  return out


# ───────────────────────────── shared internals ─────────────────────────────

def _slope(ys: Sequence[float]) -> float:
  """Least-squares slope of ys against 0..m-1 (0.0 when m < 2)."""
  m = len(ys)
  if m < 2:
    return 0.0
  mx = (m - 1) / 2.0
  my = sum(ys) / m
  num = 0.0
  for i, y in enumerate(ys):
    num += (i - mx) * (y - my)
  den = m * (m * m - 1) / 12.0
  return num / den if den else 0.0


def _linreg(ys: Sequence[float]) -> tuple[float, float, float]:
  """Returns (slope, intercept, r²) of ys against 0..m-1."""
  m = len(ys)
  if m < 3:
    return 0.0, (ys[0] if ys else 0.0), 0.0
  b = _slope(ys)
  my = sum(ys) / m
  a = my - b * (m - 1) / 2.0
  ss_tot = ss_res = 0.0
  for i, y in enumerate(ys):
    ss_tot += (y - my) ** 2
    ss_res += (y - a - b * i) ** 2
  r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
  return b, a, max(0.0, r2)


def _fit_line(pts: Sequence[tuple[int, float]]) -> tuple[float, float, float]:
  """Least-squares line through (x, y) points → (slope, intercept, max |residual|)."""
  m = len(pts)
  if m == 1:
    return 0.0, pts[0][1], 0.0
  mx = sum(p[0] for p in pts) / m
  my = sum(p[1] for p in pts) / m
  sxx = sum((p[0] - mx) ** 2 for p in pts)
  if sxx <= 0:
    return 0.0, my, max(abs(p[1] - my) for p in pts)
  b = sum((p[0] - mx) * (p[1] - my) for p in pts) / sxx
  a = my - b * mx
  res = max(abs(p[1] - (a + b * p[0])) for p in pts)
  return b, a, res


def _fractals(h: Sequence[float], l: Sequence[float], k: int,
              start: int = 0) -> tuple[list[int], list[int]]:
  """Swing pivots: bar i is a pivot high/low when it is the (first) extreme of
  the window [i−k, i+k]; near the end ≥ 2 confirming bars are required."""
  n = len(h)
  ph: list[int] = []
  pl: list[int] = []
  need = min(k, 2)
  for i in range(max(start, need), n - need):
    a = i - k if i - k > 0 else 0
    b = i + k + 1 if i + k + 1 < n else n
    hv = h[i]
    if hv >= max(h[a:b]) and h.index(hv, a, b) == i:
      ph.append(i)
    lv = l[i]
    if lv <= min(l[a:b]) and l.index(lv, a, b) == i:
      pl.append(i)
  return ph, pl


def _zigzag(h: Sequence[float], l: Sequence[float], thr: float,
            start: int = 0) -> list[tuple[int, float, str, bool]]:
  """Percent zigzag on highs/lows → alternating (idx, price, 'H'|'L', confirmed);
  the final extreme is appended unconfirmed."""
  n = len(h)
  out: list[tuple[int, float, str, bool]] = []
  if n - start < 3:
    return out
  trend = 0
  hi = lo = start
  for i in range(start + 1, n):
    if trend == 0:
      if h[i] > h[hi]:
        hi = i
      if l[i] < l[lo]:
        lo = i
      if h[hi] >= l[lo] * (1 + thr):
        if hi > lo:
          out.append((lo, l[lo], "L", True))
          trend = 1
        else:
          out.append((hi, h[hi], "H", True))
          trend = -1
    elif trend == 1:
      if h[i] >= h[hi]:
        hi = i
      elif l[i] <= h[hi] * (1 - thr):
        out.append((hi, h[hi], "H", True))
        trend = -1
        lo = i
    else:
      if l[i] <= l[lo]:
        lo = i
      elif h[i] >= l[lo] * (1 + thr):
        out.append((lo, l[lo], "L", True))
        trend = 1
        hi = i
  if trend == 1:
    out.append((hi, h[hi], "H", False))
  elif trend == -1:
    out.append((lo, l[lo], "L", False))
  return out


def _episodes(idx: Sequence[int], gap: int = 3) -> int:
  """Number of runs in an ascending index list separated by more than gap."""
  cnt = 0
  prev = -10 ** 9
  for j in idx:
    if j - prev > gap:
      cnt += 1
    prev = j
  return cnt


def _box_at(h: Sequence[float], l: Sequence[float], c: Sequence[float],
            av: float, minlen: int, e: int) -> dict | None:
  """Horizontal trading range (箱型) ending at bar e, or None."""
  if e < minlen - 1 or e >= len(c):
    return None
  ref = c[e]
  lim = _clamp(6.0 * av / ref, 0.08, 0.20) if ref > 0 else 0.1
  for ln in (minlen * 3, minlen * 2, minlen):
    s = e - ln + 1
    if s < 0:
      continue
    top = max(h[s:e + 1])
    bot = min(l[s:e + 1])
    width = top - bot
    mid = (top + bot) / 2.0
    if width <= 0 or mid <= 0 or width / mid > lim or width < 1.5 * av:
      continue
    if abs(_slope(c[s:e + 1])) * ln > 0.4 * width:
      continue
    tz = top - 0.2 * width
    bz = bot + 0.2 * width
    t_top = _episodes([j for j in range(s, e + 1) if h[j] >= tz])
    t_bot = _episodes([j for j in range(s, e + 1) if l[j] <= bz])
    if t_top < 2 or t_bot < 2:
      continue
    tol = 0.3 * av
    s2 = s
    while s2 > 0 and e - s2 < 250 and h[s2 - 1] <= top + tol and l[s2 - 1] >= bot - tol:
      s2 -= 1
    return {"s": s2, "e": e, "top": top, "bot": bot, "t_top": t_top, "t_bot": t_bot}
  return None


def _box_state(h: Sequence[float], l: Sequence[float], c: Sequence[float],
               av: float, minlen: int, max_lag: int) -> dict | None:
  """Box breakout/breakdown within the last max_lag bars, else an active box."""
  n = len(c)
  if n < minlen + 2:
    return None
  m = 0.1 * av
  for b in range(n - 1, max(minlen, n - 1 - max_lag), -1):
    box = _box_at(h, l, c, av, minlen, b - 1)
    if not box:
      continue
    if c[b] > box["top"] + m and c[n - 1] > box["top"]:
      box.update(state="up", b=b)
      return box
    if c[b] < box["bot"] - m and c[n - 1] < box["bot"]:
      box.update(state="down", b=b)
      return box
  box = _box_at(h, l, c, av, minlen, n - 1)
  if box and box["bot"] <= c[n - 1] <= box["top"]:
    box.update(state="in", b=None)
    return box
  return None


def _candle_hits(o: Sequence[float], h: Sequence[float], l: Sequence[float],
                 c: Sequence[float], i: int, av: float) -> list[tuple[str, str]]:
  """Candlestick patterns completed on bar i → [(name, type)]."""
  if i < 1:
    return []
  res: list[tuple[str, str]] = []
  oi, hi, li, ci = o[i], h[i], l[i], c[i]
  rng = hi - li
  body = abs(ci - oi)
  up_sh = hi - (ci if ci > oi else oi)
  lo_sh = (oi if ci > oi else ci) - li
  j0 = max(0, i - 20)
  avg_body = _mean([abs(c[j] - o[j]) for j in range(j0, i)])
  big = max(0.7 * av, 1.6 * avg_body)
  prior = c[i - 1] - c[max(0, i - 6)]
  down_ctx = prior < -0.5 * av
  up_ctx = prior > 0.5 * av
  if rng > 0:
    if ci > oi and body >= big and body >= 0.55 * rng:
      res.append(("長紅K", "bullish"))
    elif ci < oi and body >= big and body >= 0.55 * rng:
      res.append(("長黑K", "bearish"))
    if body <= 0.1 * rng and rng >= 0.4 * av:
      res.append(("十字線", "neutral"))
    elif (lo_sh >= 2 * body and lo_sh >= 0.6 * rng and rng >= 0.5 * av
          and up_sh <= max(0.25 * body, 0.1 * rng)):
      if down_ctx:
        res.append(("錘子線", "bullish"))
      elif up_ctx:
        res.append(("吊人線", "bearish"))
    elif (up_sh >= 2 * body and up_sh >= 0.6 * rng and rng >= 0.5 * av
          and lo_sh <= max(0.25 * body, 0.1 * rng)):
      if down_ctx:
        res.append(("倒鎚線", "bullish"))
      elif up_ctx:
        res.append(("射擊之星", "bearish"))
  po, pc = o[i - 1], c[i - 1]
  pbody = abs(pc - po)
  if (pc < po and ci > oi and oi <= pc and ci >= po and body > pbody
      and body >= 0.3 * av and prior < 0):
    res.append(("多頭吞噬", "bullish"))
  elif (pc > po and ci < oi and oi >= pc and ci <= po and body > pbody
        and body >= 0.3 * av and prior > 0):
    res.append(("空頭吞噬", "bearish"))
  if i >= 2:
    o2, c2 = o[i - 2], c[i - 2]
    b2 = abs(c2 - o2)
    o1, c1 = o[i - 1], c[i - 1]
    b1 = abs(c1 - o1)
    long2 = b2 >= max(0.6 * av, 1.2 * avg_body)
    if (long2 and c2 < o2 and b1 <= 0.4 * b2 and max(o1, c1) <= c2 + 0.1 * av
        and ci > oi and ci >= (o2 + c2) / 2):
      res.append(("晨星", "bullish"))
    elif (long2 and c2 > o2 and b1 <= 0.4 * b2 and min(o1, c1) >= c2 - 0.1 * av
          and ci < oi and ci <= (o2 + c2) / 2):
      res.append(("夜星", "bearish"))
    trio = range(i - 2, i + 1)
    if all(c[j] > o[j] and abs(c[j] - o[j]) >= 0.4 * av for j in trio) and \
        c[i - 2] < c[i - 1] < ci and all(o[j - 1] <= o[j] <= c[j - 1] for j in (i - 1, i)):
      res.append(("紅三兵", "bullish"))
    elif all(c[j] < o[j] and abs(c[j] - o[j]) >= 0.4 * av for j in trio) and \
        c[i - 2] > c[i - 1] > ci and all(c[j - 1] <= o[j] <= o[j - 1] for j in (i - 1, i)):
      res.append(("黑三兵", "bearish"))
  return res


def _cross(a: Series, b: Series | float, i: int, look: int) -> int:
  """Most recent cross of a over b within the last `look` bars ending at i.

  Returns +(bars_ago+1) for an upward cross, −(bars_ago+1) for a downward cross,
  0 when there is none.  b may be a series or a constant.
  """
  for j in range(i, max(0, i - look + 1) - 1, -1):
    if j < 1:
      break
    a0, a1 = a[j - 1], a[j]
    if isinstance(b, (int, float)):
      b0 = b1 = b
    else:
      b0, b1 = b[j - 1], b[j]
    if a0 is None or a1 is None or b0 is None or b1 is None:
      break
    if a0 <= b0 and a1 > b1:
      return i - j + 1
    if a0 >= b0 and a1 < b1:
      return -(i - j + 1)
  return 0


def _close_cross(c: Sequence[float], ma: Series, i: int, look: int = 3) -> int:
  """+1 if close crossed above ma within `look` bars and stays above; −1 mirror."""
  m = ma[i]
  if m is None:
    return 0
  x = _cross(c, ma, i, look)
  if x > 0 and c[i] > m:
    return 1
  if x < 0 and c[i] < m:
    return -1
  return 0


def _gap_recent(h: Sequence[float], l: Sequence[float], i: int,
                look: int = 3) -> tuple[int, int]:
  """Unfilled gap-up / gap-down bars within the last `look` bars → (j_up, j_dn) or −1."""
  up = dn = -1
  for j in range(i, max(0, i - look + 1) - 1, -1):
    if j < 1:
      break
    if up < 0 and l[j] > h[j - 1] and min(l[j:i + 1]) > h[j - 1]:
      up = j
    if dn < 0 and h[j] < l[j - 1] and max(h[j:i + 1]) < l[j - 1]:
      dn = j
  return up, dn


def _bb_squeeze(ind: dict[str, Series], i: int, look: int = 120) -> bool:
  """True when Bollinger bandwidth is in the lowest decile of the last `look` bars."""
  up, mid, lo = ind["bb_up"], ind["bb_mid"], ind["bb_lo"]
  if up[i] is None or not mid[i]:
    return False
  bws = []
  for j in range(max(0, i - look + 1), i + 1):
    if up[j] is not None and mid[j]:
      bws.append((up[j] - lo[j]) / mid[j])
  if len(bws) < 40:
    return False
  now = bws[-1]
  s = sorted(bws)
  return now <= s[max(0, len(s) // 10)]


def _quick_core(o: Sequence[float], h: Sequence[float], l: Sequence[float],
                c: Sequence[float], v: Sequence[float], ind: dict[str, Series],
                atr_now: float | None, bpy: int = 250, box_min: int = 20,
                levels: bool = True) -> dict[str, Any]:
  """Shared fast evaluation used by quick_signals() and analyze()."""
  n = len(c)
  i = n - 1
  x = c[i]
  pc = c[i - 1] if i >= 1 else x
  av = max(atr_now or 0.0, x * 0.005, 1e-9)
  g = {k: (ind[k][i] if len(ind[k]) > i else None) for k in INDICATOR_KEYS}
  mas = [g["ma5"], g["ma10"], g["ma20"], g["ma60"], g["ma120"], g["ma240"]]
  bits = 0
  for b, m in enumerate(mas):
    if m is not None and x > m:
      bits |= 1 << b
  m5, m10, m20, m60 = mas[0], mas[1], mas[2], mas[3]
  have4 = None not in (m5, m10, m20, m60)
  bull = have4 and m5 > m10 > m20 > m60
  bear = have4 and m5 < m10 < m20 < m60
  if bull:
    bits |= 64
  if bear:
    bits |= 128
  tags: list[str] = []
  if bull:
    tags.append("多頭排列")
  if bear:
    tags.append("空頭排列")
  x20 = _close_cross(c, ind["ma20"], i)
  x60 = _close_cross(c, ind["ma60"], i)
  if x20 > 0:
    tags.append("站上月線")
  elif x20 < 0:
    tags.append("跌破月線")
  if x60 > 0:
    tags.append("站上季線")
  elif x60 < 0:
    tags.append("跌破季線")
  tangle = have4 and (max(m5, m10, m20, m60) - min(m5, m10, m20, m60)) / x <= 0.02
  if tangle:
    tags.append("均線糾結")
  new52 = False
  if n >= 120:
    prior = max(h[max(0, n - bpy):i])
    new52 = h[i] > prior
    if new52:
      tags.append("創52週新高")
  brk60 = brk60d = False
  if n >= 63:
    brk60 = x > max(h[n - 63:n - 3])
    brk60d = x < min(l[n - 63:n - 3])
    if brk60:
      tags.append("突破60日高")
    elif brk60d:
      tags.append("跌破60日低")
  box = _box_state(h, l, c, av, box_min, 3) if n >= box_min + 5 else None
  box_up = bool(box and box["state"] == "up")
  if box_up:
    tags.append("突破箱型")
  gu, gd = _gap_recent(h, l, i, 3)
  if gu >= 0:
    tags.append("跳空上漲")
  if gd >= 0:
    tags.append("跳空下跌")
  kx = _cross(ind["k"], ind["d"], i, 3)
  if kx > 0 and g["k"] is not None and g["k"] > g["d"]:
    tags.append("KD黃金交叉")
  elif kx < 0 and g["k"] is not None and g["k"] < g["d"]:
    tags.append("KD死亡交叉")
  else:
    kx = 0
  ks = ind["k"][max(0, i - 2):i + 1]
  if not kx and len(ks) == 3 and None not in ks:
    if min(ks) > 80:
      tags.append("KD高檔鈍化")
    elif max(ks) < 20:
      tags.append("KD低檔鈍化")
  mx = _cross(ind["dif"], ind["dea"], i, 3)
  dif, dea, hist = g["dif"], g["dea"], g["hist"]
  if mx > 0 and dif is not None and dif > dea:
    tags.append("MACD黃金交叉")
  elif mx < 0 and dif is not None and dif < dea:
    tags.append("MACD死亡交叉")
  zx = _cross(ind["dif"], 0.0, i, 3)
  if zx > 0 and dif is not None and dif > 0:
    tags.append("MACD翻紅")
  elif zx < 0 and dif is not None and dif < 0:
    tags.append("MACD翻綠")
  r14 = g["rsi14"]
  if r14 is not None:
    if r14 >= 70:
      tags.append("RSI超買")
    elif r14 <= 30:
      tags.append("RSI超賣")
  if g["bb_up"] is not None:
    if x > g["bb_up"]:
      tags.append("布林突破上軌")
    elif x < g["bb_lo"]:
      tags.append("布林跌破下軌")
    if _bb_squeeze(ind, i):
      tags.append("布林收斂")
  vma20 = g["vol_ma20"]
  r20 = v[i] / vma20 if vma20 else None
  pct = _pct(x, pc)
  if r20 is not None:
    if r20 >= 2.5:
      tags.append("爆量")
    elif r20 >= 1.5:
      tags.append("量增")
    elif r20 <= 0.5:
      tags.append("量縮")
    if pct >= 1.0 and r20 >= 1.3:
      tags.append("價漲量增")
    elif pct <= -1.0 and r20 >= 1.3:
      tags.append("價跌量增")
  candles = _candle_hits(o, h, l, c, i, av)
  for name, _ in candles:
    if name in QUICK_TAGS:
      tags.append(name)

  # ── score (0–100, 50 = neutral) ──
  wsum = ssum = 0.0
  for m, w in zip(mas, (1.0, 1.0, 1.5, 1.5, 1.0, 1.0)):
    if m is not None:
      wsum += w
      ssum += w if x > m else -w
  pos = ssum / wsum if wsum else 0.0
  align = 1.0 if bull else -1.0 if bear else (
    0.5 if (m20 is not None and m60 is not None and m20 > m60) else
    -0.5 if (m20 is not None and m60 is not None and m20 < m60) else 0.0)
  m20p = _at(ind["ma20"], i - 5)
  m60p = _at(ind["ma60"], i - 10)
  sl20 = _clamp((m20 - m20p) / av) if m20 is not None and m20p is not None else 0.0
  sl60 = _clamp((m60 - m60p) / av) if m60 is not None and m60p is not None else 0.0
  hp = _at(ind["hist"], i - 1)
  if hist is not None and hp is not None and dif is not None:
    mom = (0.4 if hist > 0 else -0.4) + (0.3 if hist > hp else -0.3) + \
        (0.3 if dif > 0 else -0.3)
  else:
    mom = 0.0
  kk, dd = g["k"], g["d"]
  kds = ((0.5 if kk > dd else -0.5) + 0.5 * _clamp((kk - 50) / 40)) \
      if kk is not None and dd is not None else 0.0
  rs = _clamp((r14 - 50) / 20) if r14 is not None else 0.0
  brk = 0.0
  if brk60 or box_up:
    brk += 0.6
  if brk60d or (box and box["state"] == "down"):
    brk -= 0.6
  if n >= 60:
    w52 = h[max(0, n - bpy):]
    l52 = l[max(0, n - bpy):]
    if x >= 0.97 * max(w52):
      brk += 0.4
    if x <= 1.03 * min(l52):
      brk -= 0.4
  brk = _clamp(brk)
  vs = 0.0
  if r20 is not None and r20 >= 1.2:
    if pct > 0.5:
      vs = min(1.0, r20 - 1.0)
    elif pct < -0.5:
      vs = -min(1.0, r20 - 1.0)
  cval = {"長紅K": 1.0, "長黑K": -1.0, "多頭吞噬": 0.7, "空頭吞噬": -0.7, "晨星": 0.7,
          "夜星": -0.7, "錘子線": 0.4, "吊人線": -0.4, "倒鎚線": 0.2, "射擊之星": -0.4,
          "紅三兵": 0.6, "黑三兵": -0.6}
  cs = _clamp(sum(cval.get(nm, 0.0) for nm, _ in candles))
  heat = 0.0
  if m20:
    bias = (x / m20 - 1) * 100
    if bias > 12:
      heat -= min(1.0, (bias - 12) / 12)
    elif bias < -12:
      heat += 0.5 * min(1.0, (-bias - 12) / 12)
  if r14 is not None and r14 > 85:
    heat -= 0.5
  score = (50 + 10 * pos + 7 * align + 5 * sl20 + 3 * sl60 + 7 * mom + 5 * kds
           + 4 * rs + 5 * brk + 3 * vs + 3 * cs + 4 * _clamp(heat))
  score = _clamp(score, 0.0, 100.0)
  out: dict[str, Any] = {
    "score": score, "ma_bits": bits, "tags": tags, "candles": candles, "box": box,
    "bull": bull, "bear": bear, "tangle": tangle, "new52": new52,
    "brk60": brk60, "brk60d": brk60d, "r20": r20, "pct": pct, "av": av,
    "parts": {"pos": pos, "align": align, "sl20": sl20, "sl60": sl60, "mom": mom,
              "kd": kds, "rsi": rs, "brk": brk, "vol": vs, "candle": cs,
              "heat": heat},
  }
  if levels:
    out["support"], out["resistance"] = _quick_levels(h, l, c, av)
  return out


def _quick_levels(h: Sequence[float], l: Sequence[float], c: Sequence[float],
                  av: float) -> tuple[float | None, float | None]:
  """Nearest swing-pivot support below / resistance above the last close."""
  n = len(c)
  x = c[-1]
  s0 = max(0, n - 120)
  sup = res = None
  eps = av * 0.05
  for j in range(s0 + 2, n - 2):
    a = j - 3 if j - 3 > s0 else s0
    b = j + 4 if j + 4 < n else n
    lv = l[j]
    hv = h[j]
    if lv <= min(l[a:b]):
      if lv < x - eps and (sup is None or lv > sup):
        sup = lv
      elif lv > x + eps and (res is None or lv < res):
        res = lv
    if hv >= max(h[a:b]):
      if hv > x + eps and (res is None or hv < res):
        res = hv
      elif hv < x - eps and (sup is None or hv > sup):
        sup = hv
  if sup is None and n >= 2:
    lo = min(l[max(0, n - 20):])
    sup = lo if lo < x else None
  if res is None and n >= 2:
    hi = max(h[max(0, n - 60):])
    res = hi if hi > x else None
  sup_r = _rt(sup, -1) if sup is not None else None
  res_r = _rt(res, 1) if res is not None else None
  if sup_r is not None and sup_r >= x:
    sup_r = None
  if res_r is not None and res_r <= x:
    res_r = None
  return sup_r, res_r


def _stance_level(score: float) -> int:
  """Maps a 0–100 score to stance level 2..−2."""
  if score >= 75:
    return 2
  if score >= 58:
    return 1
  if score > 42:
    return 0
  if score > 25:
    return -1
  return -2


def quick_signals(bars: Sequence[Sequence[Any]],
                  ind: dict[str, Series] | None = None) -> dict[str, Any]:
  """Fast per-stock signals for batch screening (§4.4).

  Reuses a precomputed `ind` (compute_indicators output aligned with bars) when
  given.  Tags come only from QUICK_TAGS.
  """
  out: dict[str, Any] = {"tech_score": 50, "stance_level": 0, "ma_bits": 0,
                         "signals": [], "support": None, "resistance": None,
                         "atr": None}
  if not bars:
    return out
  try:
    o = [float(b[1]) for b in bars]
    h = [float(b[2]) for b in bars]
    l = [float(b[3]) for b in bars]
    c = [float(b[4]) for b in bars]
    v = [float(b[5] or 0) for b in bars]
    ok = all(math.isfinite(x) and x > 0 for x in c) and all(
      math.isfinite(x) for x in v)
  except (TypeError, ValueError, IndexError):
    ok = False
  if not ok:
    bs = _clean_bars(bars)
    if not bs:
      return out
    o = [b[1] for b in bs]
    h = [b[2] for b in bs]
    l = [b[3] for b in bs]
    c = [b[4] for b in bs]
    v = [b[5] for b in bs]
    ind = None
  n = len(c)
  for i in range(n):
    if h[i] < c[i] or h[i] < o[i] or l[i] > c[i] or l[i] > o[i]:
      h[i] = max(o[i], h[i], l[i], c[i])
      l[i] = min(o[i], h[i], l[i], c[i])
  if (ind is None or any(len(ind.get(k) or ()) != n for k in INDICATOR_KEYS)):
    ind = _raw_indicators(h, l, c, v)
  a = atr(h, l, c, 14)
  atr_now = a[-1] if a[-1] is not None else (_mean(_true_range(h, l, c)) if n else None)
  q = _quick_core(o, h, l, c, v, ind, atr_now)
  score = int(round(q["score"]))
  out.update(tech_score=score, stance_level=_stance_level(score),
             ma_bits=q["ma_bits"], signals=q["tags"], support=q["support"],
             resistance=q["resistance"],
             atr=_r(atr_now, 2 if (atr_now or 0) < 10 else 1))
  return out


# ───────────────────────────── analysis context ─────────────────────────────

_GLOSS = {
  "ma": "均線（過去 N 根K棒收盤價的平均，可視為市場平均持有成本）",
  "月線": "月線（20 日均線）",
  "季線": "季線（60 日均線）",
  "半年線": "半年線（120 日均線）",
  "年線": "年線（240 日均線）",
  "多頭排列": "多頭排列（短天期均線依序在長天期均線之上，代表各週期買方都獲利、趨勢向上）",
  "空頭排列": "空頭排列（短天期均線依序在長天期均線之下，代表各週期持有者普遍套牢、趨勢向下）",
  "均線糾結": "均線糾結（多條均線擠在一起，代表多空成本接近，常是大行情發動前的醞釀）",
  "ADX": "ADX（平均趨向指標，衡量趨勢強弱而非方向，高於 25 代表趨勢明確、低於 20 偏盤整）",
  "DI": "+DI／−DI（買方／賣方趨向指標，+DI 較高代表買方較強）",
  "迴歸": "線性迴歸斜率（用統計方法擬合走勢，代表平均每根K棒的漲跌幅）",
  "結構": "波段結構（比較最近兩個波段高點與低點的位置）",
  "趨勢線": "趨勢線（連接兩個轉折低點或高點的斜線，股價沿線運行代表趨勢延續）",
  "支撐": "支撐（股價回檔時容易有買盤承接的價位）",
  "壓力": "壓力（股價上漲時容易遇到賣壓的價位）",
  "成交密集區": "成交密集區（一段期間內成交量最集中的價位，代表多數人的持股成本，常形成支撐或壓力）",
  "缺口": "缺口（相鄰兩根K棒的價格區間沒有重疊的跳空區，未回補前常扮演支撐或壓力）",
  "頸線": "頸線（型態中段轉折點的連線，收盤突破或跌破頸線才算型態完成）",
  "整數關卡": "整數關卡（如 100、500、1000 元等整數價位，常有心理性買賣盤）",
  "52週": "52 週高低點（近一年的最高價與最低價）",
  "前波": "前波高低點（過去股價轉折的高點或低點，常是套牢或承接的價位）",
  "箱型": "箱型（股價在固定上下區間來回震盪的整理區）",
  "KD": "KD 指標（以近 9 日高低區間衡量收盤的相對位置，0–100，80 以上為高檔、20 以下為低檔）",
  "黃金交叉": "黃金交叉（短線指標由下往上穿越長線指標，代表買盤轉強）",
  "死亡交叉": "死亡交叉（短線指標由上往下跌破長線指標，代表賣壓轉強）",
  "鈍化": "鈍化（KD 連續停留在高檔或低檔，代表趨勢強勁，此時指標的轉折訊號較不可靠）",
  "MACD": "MACD（以 12 日與 26 日指數均線的差距 DIF 及其 9 日平均 DEA 判斷中期動能，柱狀體 OSC = DIF − DEA，紅柱代表多方動能）",
  "RSI": "RSI（相對強弱指標，衡量一段期間內上漲力道的占比，70 以上為超買、30 以下為超賣）",
  "布林": "布林通道（以 20 日均線為中軸、上下各加減 2 倍標準差的通道，股價多數時間在通道內波動）",
  "背離": "背離（股價創新高或新低，但指標沒有同步創高或創低，代表動能減弱，常是轉折前兆）",
  "OBV": "OBV 能量潮（上漲日加上成交量、下跌日減去成交量的累計值，用來觀察資金流向）",
  "ATR": "ATR（平均真實波幅，近 14 根K棒的平均波動幅度）",
  "風險報酬比": "風險報酬比（預期獲利空間 ÷ 停損虧損空間，大於 2 較划算）",
  "乖離": "乖離率（股價偏離均線的百分比，過大時容易拉回修正）",
}
_PAT_GLOSS = {
  "W底": "W底（雙重底：股價兩度探底但第二次未明顯破底，形似字母 W 的打底型態）",
  "M頭": "M頭（雙重頂：股價兩度上攻同一高點附近失敗，形似字母 M 的做頭型態）",
  "頭肩底": "頭肩底（三個低點中間最低、兩側相近，形如倒立人像的打底型態）",
  "頭肩頂": "頭肩頂（三個高點中間最高、兩側相近，形如人像頭與肩膀的做頭型態）",
  "上升三角形": "上升三角形（高點大致持平、低點逐步墊高，買方越來越積極，多為向上突破）",
  "下降三角形": "下降三角形（低點大致持平、高點逐步降低，賣壓越來越重，多為向下跌破）",
  "收斂三角形": "收斂三角形（高點降低、低點墊高，波動越來越小，等待方向選擇）",
  "上升楔形": "上升楔形（高低點同步上升但漲勢收斂，常見於上漲末端，跌破下緣偏空）",
  "下降楔形": "下降楔形（高低點同步下降但跌勢收斂，常見於下跌末端，突破上緣偏多）",
  "上升通道": "上升通道（股價在兩條平行的上升斜線間運行，趨勢向上）",
  "下降通道": "下降通道（股價在兩條平行的下降斜線間運行，趨勢向下）",
  "箱型整理": "箱型整理（股價在固定的上下區間來回震盪）",
  "箱型突破": "箱型突破（股價收盤站上整理區間上緣，脫離盤整）",
  "箱型跌破": "箱型跌破（股價收盤跌破整理區間下緣，轉弱訊號）",
}
_CANDLE_GLOSS = {
  "長紅K": "長紅K（實體很長的紅K棒，代表買方強勢主導）",
  "長黑K": "長黑K（實體很長的黑K棒，代表賣方強勢主導）",
  "十字線": "十字線（開盤價與收盤價幾乎相同，代表多空拉鋸、可能變盤）",
  "錘子線": "錘子線（下影線很長、實體小，出現在跌勢中代表低檔有買盤承接）",
  "吊人線": "吊人線（形狀同錘子線但出現在漲勢高檔，暗示賣壓開始湧現）",
  "倒鎚線": "倒鎚線（上影線很長、實體小，出現在跌勢中代表買方開始試探）",
  "射擊之星": "射擊之星（上影線很長、實體小，出現在漲勢高檔代表追價力道不足）",
  "多頭吞噬": "多頭吞噬（紅K實體完全包覆前一根黑K實體，跌勢中出現代表買方反攻）",
  "空頭吞噬": "空頭吞噬（黑K實體完全包覆前一根紅K實體，漲勢中出現代表賣方反撲）",
  "晨星": "晨星（長黑K、小實體K、長紅K三根組合，常見於底部反轉）",
  "夜星": "夜星（長紅K、小實體K、長黑K三根組合，常見於頭部反轉）",
  "紅三兵": "紅三兵（連續三根收盤墊高的紅K，買盤持續進場）",
  "黑三兵": "黑三兵（連續三根收盤走低的黑K，賣壓持續湧現）",
}
_VOL_GLOSS = {
  "價漲量增": "價漲量增（股價上漲且成交量放大，買盤積極追價，屬健康的上漲）",
  "價漲量縮": "價漲量縮（股價上漲但成交量萎縮，追價意願不足，漲勢續航力待觀察）",
  "價跌量增": "價跌量增（股價下跌且成交量放大，代表賣壓沉重或有人急於出場）",
  "價跌量縮": "價跌量縮（股價下跌但成交量萎縮，賣壓逐漸減輕，屬量縮整理）",
  "爆量": "爆量（成交量達 20 期均量 2.5 倍以上，多空激烈交戰，常是行情轉折或加速的訊號）",
  "量縮": "量縮（成交量明顯低於均量，市場觀望氣氛濃厚）",
}
_KIND_GLOSS = {"缺口": "缺口", "成交密集區": "成交密集區", "整數關卡": "整數關卡", "頸線": "頸線",
               "52週高點": "52週", "52週低點": "52週", "箱型上緣": "箱型", "箱型下緣": "箱型",
               "前波高點": "前波", "前波低點": "前波"}
_KIND_PRI = {"頸線": 7, "箱型上緣": 6, "箱型下緣": 6, "52週高點": 5, "52週低點": 5,
             "前波高點": 4, "前波低點": 4, "缺口": 3, "成交密集區": 2, "整數關卡": 1}
_BULLISH_PATS = {"W底", "頭肩底", "上升三角形", "下降楔形", "上升通道", "箱型突破"}
_BEARISH_PATS = {"M頭", "頭肩頂", "下降三角形", "上升楔形", "下降通道", "箱型跌破"}


class _Ctx:
  """Arrays, indicators and pivots shared by the analysis components."""

  def __init__(self, bs: list[tuple], tf: str):
    self.tf = tf
    self.P = _TF[tf]
    self.d = [b[0] for b in bs]
    self.o = [b[1] for b in bs]
    self.h = [b[2] for b in bs]
    self.l = [b[3] for b in bs]
    self.c = [b[4] for b in bs]
    self.v = [b[5] for b in bs]
    n = self.n = len(bs)
    self.i = n - 1
    self.price = self.c[-1]
    self.ind = _raw_indicators(self.h, self.l, self.c, self.v)
    self.atr = atr(self.h, self.l, self.c, 14)
    a = self.atr[-1]
    self.atr_now = a if a is not None else _mean(_true_range(self.h, self.l, self.c))
    self.av = max(self.atr_now, self.price * 0.005, 1e-9)
    self.tol = max(0.6 * self.av, 0.012 * self.price)
    self.adx, self.pdi, self.mdi = adx(self.h, self.l, self.c, 14)
    self.obv = obv(self.c, self.v)
    P = self.P
    self.fh, self.fl = _fractals(self.h, self.l, P["k"], max(0, n - P["sr"] - 5))
    aps = [self.atr[j] / self.c[j] for j in range(max(0, n - 120), n)
           if self.atr[j] is not None]
    med = _median(aps) if aps else self.av / self.price
    self.zz_thr = _clamp(2.2 * med, P["zz_lo"], P["zz_hi"])
    start = max(0, n - max(P["sr"], P["tl"], P["pat"]) - 20)
    self.zz = _zigzag(self.h, self.l, self.zz_thr, start)
    if self.zz and self.zz[0][0] <= start + 1:
      self.zz = self.zz[1:]  # the window's first bar is not a real swing
    self.year = self.d[-1][:4]
    self.unit = P["unit"]
    self.bar_word = {"D": "今日", "W": "本週", "M": "本月"}[tf]
    self.partial = False  # last W/M bar still in progress
    try:
      last = datetime.date.fromisoformat(self.d[-1])
      if tf == "W":
        self.partial = last.weekday() < 4
      elif tf == "M":
        self.partial = last.day < 25
    except ValueError:
      pass
    self.explained: set[str] = set()

  def a_at(self, j: int) -> float:
    """ATR at bar j (falls back to the current scale ATR)."""
    a = self.atr[j] if 0 <= j < self.n else None
    return a if a else self.av

  def fd(self, j: int | str | None) -> str:
    """Formats a bar index or ISO date as 'MM/DD' (adds the year when needed)."""
    if j is None:
      return "—"
    ds = self.d[j] if isinstance(j, int) else str(j)
    if len(ds) < 10:
      return ds
    if self.tf == "M":
      return f"{ds[:4]}/{ds[5:7]}"
    if ds[:4] == self.year:
      return f"{ds[5:7]}/{ds[8:10]}"
    return f"{ds[:4]}/{ds[5:7]}/{ds[8:10]}"

  def ma_name(self, m: int, nick: bool = True) -> str:
    """'20 日均線' / '月線（20 日均線）' (first time) …"""
    base = f"{m} {self.unit}均線"
    if self.tf != "D" or not nick:
      return base
    nk = {20: "月線", 60: "季線", 120: "半年線", 240: "年線"}.get(m)
    if not nk:
      return base
    return self.term(nk)

  def term(self, key: str, table: dict[str, str] | None = None) -> str:
    """Returns the explained term the first time, the bare term afterwards."""
    tbl = table if table is not None else _GLOSS
    txt = tbl.get(key)
    if txt is None:
      return key
    tag = f"{id(tbl)}:{key}"
    if tag in self.explained:
      return txt.split("（", 1)[0] if key not in ("ma",) else "均線"
    self.explained.add(tag)
    if self.tf != "D" and key in ("MACD", "KD", "布林"):
      txt = txt.replace("日", self.unit)
    return txt


def _label(t: float, hi: float = 0.5, lo: float = 0.18) -> int:
  """Maps a trend score in [−1, 1] to level 2..−2."""
  if t >= hi:
    return 2
  if t >= lo:
    return 1
  if t > -lo:
    return 0
  if t > -hi:
    return -1
  return -2


def _dir_word(delta: float, thr: float) -> str:
  """上揚 / 下彎 / 走平 for a moving-average change."""
  return "上揚" if delta > thr else "下彎" if delta < -thr else "走平"


def _structure(ctx: _Ctx) -> tuple[int, str, list, list]:
  """Swing structure from the zigzag: (+1 HH/HL, −1 LH/LL, 0 mixed), text, highs, lows."""
  hs = [p for p in ctx.zz if p[2] == "H"][-2:]
  ls = [p for p in ctx.zz if p[2] == "L"][-2:]
  if len(hs) < 2 or len(ls) < 2:
    return 0, "結構不明（波段轉折點不足）", hs, ls
  eps = 0.3 * ctx.av
  dh = hs[1][1] - hs[0][1]
  dl = ls[1][1] - ls[0][1]
  ht = "高點墊高" if dh > eps else "高點降低" if dh < -eps else "高點持平"
  lt = "低點墊高" if dl > eps else "低點降低" if dl < -eps else "低點持平"
  s = 0
  if dh > eps and dl > eps:
    s = 1
  elif dh < -eps and dl < -eps:
    s = -1
  elif dh > eps or dl > eps:
    s = 0.5 if dh >= -eps and dl >= -eps else 0
  elif dh < -eps or dl < -eps:
    s = -0.5 if dh <= eps and dl <= eps else 0
  txt = f"{ht}、{lt}"
  if dh < -eps and dl > eps:
    txt += "（收斂）"
  elif dh > eps and dl < -eps:
    txt += "（擴散）"
  return s, txt, hs, ls


def _trend(ctx: _Ctx) -> dict[str, Any]:
  """Short / mid / long trend labels with reasons, ADX strength and structure."""
  c, i, n, x, av, ind = ctx.c, ctx.i, ctx.n, ctx.price, ctx.av, ctx.ind
  u = ctx.unit

  def g(key: str, j: int = i) -> float | None:
    return _at(ind[key], j)

  # short ≈ 5–20 bars
  mas = [(m, g(f"ma{m}")) for m in (5, 10, 20)]
  mas = [(m, val) for m, val in mas if val is not None]
  pos = sum(1 if x > val else -1 for _, val in mas) / len(mas) if mas else 0.0
  above = [str(m) for m, val in mas if x > val]
  below = [str(m) for m, val in mas if x <= val]
  if mas and not below:
    r1 = f"收盤 {_fp(x)} 站上 {'、'.join(above)} {u}均線"
  elif mas and not above:
    r1 = f"收盤 {_fp(x)} 位於 {'、'.join(below)} {u}均線之下"
  elif mas:
    r1 = f"收盤 {_fp(x)} 站上 {'、'.join(above)} {u}均線，但仍在 {'、'.join(below)} {u}均線之下"
  else:
    r1 = f"收盤 {_fp(x)}"
  m5, m5p = g("ma5"), g("ma5", i - 3)
  s5 = (m5 - m5p) if m5 is not None and m5p is not None else 0.0
  m10, m10p = g("ma10"), g("ma10", i - 3)
  s10 = (m10 - m10p) if m10 is not None and m10p is not None else 0.0
  k10 = min(10, i)
  lin10 = _slope(c[i - k10:i + 1]) * k10 if k10 >= 3 else 0.0
  r10 = _pct(x, c[i - k10]) if k10 else 0.0
  k3 = min(3, i)
  t_s = (0.45 * pos + 0.12 * _clamp(s5 / av) + 0.08 * _clamp(s10 / av)
         + 0.1 * _clamp((x - c[i - k10]) / (3 * av)) + 0.1 * _clamp(lin10 / (3 * av))
         + 0.15 * _clamp((x - c[i - k3]) / (1.5 * av)))
  short_reason = (f"{r1}；5 {u}均線{_dir_word(s5, 0.15 * av)}，近 {k10} {u}"
                  f"{'上漲' if r10 >= 0 else '下跌'} {abs(r10):.1f}%")

  # mid ≈ 20–60 bars
  m20, m60 = g("ma20"), g("ma60")
  m20p, m60p = g("ma20", i - 10), g("ma60", i - 20)
  parts = []
  if m20 is not None:
    parts.append(1 if x > m20 else -1)
  if m60 is not None:
    parts.append(1 if x > m60 else -1)
  if m20 is not None and m60 is not None:
    parts.append(1 if m20 > m60 else -1)
  pos_m = sum(parts) / len(parts) if parts else 0.0
  s20 = (m20 - m20p) if m20 is not None and m20p is not None else 0.0
  s60 = (m60 - m60p) if m60 is not None and m60p is not None else 0.0
  k60 = min(60, n)
  b60, _, r2_60 = _linreg(c[n - k60:])
  lin60 = _clamp(b60 * (k60 - 1) / (4 * av)) * (0.5 + 0.5 * r2_60)
  st, st_txt, hs, ls = _structure(ctx)
  adx_now, pdi_now, mdi_now = _at(ctx.adx, i), _at(ctx.pdi, i), _at(ctx.mdi, i)
  adx_s = 0.0
  if adx_now is not None and adx_now >= 20 and pdi_now is not None:
    adx_s = (1 if pdi_now > mdi_now else -1) * min(1.0, (adx_now - 15) / 20)
  t_m = (0.25 * pos_m + 0.15 * _clamp(s20 / (1.5 * av)) + 0.1 * _clamp(s60 / (2 * av))
         + 0.2 * lin60 + 0.2 * st + 0.1 * adx_s)
  mid_bits = []
  if m20 is not None:
    seg = f"20 {u}均線 {_fp(m20)} {_dir_word(s20, 0.3 * av)}"
    if m60 is not None:
      rel = "高於" if m20 > m60 else "低於"
      seg += f"、{rel} 60 {u}均線 {_fp(m60)}"
    mid_bits.append(seg)
  mean60 = _mean(c[n - k60:]) or x
  mid_bits.append(f"近 {k60} {u}迴歸斜率每{u} {b60 / mean60 * 100:+.2f}%")
  if hs and ls and st != 0:
    mid_bits.append(f"波段{st_txt.split('（')[0]}")
  mid_reason = "；".join(mid_bits)

  # long ≈ 120–240 bars
  m120, m240 = g("ma120"), g("ma240")
  lparts = []
  if m120 is not None:
    lparts.append(1 if x > m120 else -1)
  if m240 is not None:
    lparts.append(1 if x > m240 else -1)
  if m120 is not None and m240 is not None:
    lparts.append(1 if m120 > m240 else -1)
  if not lparts and m60 is not None:
    lparts.append(1 if x > m60 else -1)
  pos_l = sum(lparts) / len(lparts) if lparts else 0.0
  s120 = (m120 - g("ma120", i - 20)) if m120 is not None and g("ma120", i - 20) is not None else 0.0
  s240 = (m240 - g("ma240", i - 20)) if m240 is not None and g("ma240", i - 20) is not None else 0.0
  k240 = min(240, n)
  bl, _, r2l = _linreg(c[n - k240:])
  meanl = _mean(c[n - k240:]) or x
  lin_l = _clamp(bl * (k240 - 1) / meanl / 0.3) * (0.5 + 0.5 * r2l)
  bpy = ctx.P["bpy"]
  hi52 = max(ctx.h[max(0, n - bpy):])
  lo52 = min(ctx.l[max(0, n - bpy):])
  p52 = (x - lo52) / (hi52 - lo52) if hi52 > lo52 else 0.5
  k120 = min(120, i)
  ret = _pct(x, c[i - k120]) if k120 else 0.0
  t_l = (0.3 * pos_l + 0.1 * _clamp(s120 / (2 * av)) + 0.1 * _clamp(s240 / (1.5 * av))
         + 0.2 * lin_l + 0.15 * (2 * p52 - 1) + 0.15 * _clamp(ret / 30))
  lb = []
  if m120 is not None or m240 is not None:
    ab = [str(m) for m, val in ((120, m120), (240, m240)) if val is not None and x > val]
    bl_ = [str(m) for m, val in ((120, m120), (240, m240)) if val is not None and x <= val]
    if ab and not bl_:
      lb.append(f"股價站上 {'、'.join(ab)} {u}均線")
    elif bl_ and not ab:
      lb.append(f"股價位於 {'、'.join(bl_)} {u}均線之下")
    else:
      lb.append(f"股價站上 {'、'.join(ab)} {u}均線、但低於 {'、'.join(bl_)} {u}均線")
    if m240 is not None:
      lb.append(f"240 {u}均線{_dir_word(s240, 0.3 * av)}")
    elif m120 is not None:
      lb.append(f"120 {u}均線{_dir_word(s120, 0.3 * av)}")
  span_txt = "52 週" if n >= bpy else f"近 {n} {u}"
  sep = " " if n >= bpy else ""
  lb.append(f"位於{sep}{span_txt}區間（{_fp(lo52)}–{_fp(hi52)}）的 {p52 * 100:.0f}% 位置")
  long_reason = "；".join(lb)
  if n < 120:
    long_reason = f"資料僅 {n} 根K棒，長期判斷參考性有限；" + long_reason

  ls_ = _label(t_s, 0.6, 0.2)
  lm = _label(t_m)
  ll = _label(t_l)
  if adx_now is None:
    strength = "不明"
  elif adx_now < 20:
    strength = "弱"
  elif adx_now < 25:
    strength = "中"
  elif adx_now < 40:
    strength = "強"
  else:
    strength = "極強"
  ctx.t_scores = (t_s, t_m, t_l)
  ctx.struct = (st, st_txt, hs, ls)
  return {
    "short": {"label": TREND_LABELS[ls_], "level": ls_, "reason": short_reason},
    "mid": {"label": TREND_LABELS[lm], "level": lm, "reason": mid_reason},
    "long": {"label": TREND_LABELS[ll], "level": ll, "reason": long_reason},
    "adx": _r(adx_now, 1), "strength": strength, "structure": st_txt,
  }


# ───────────────────────────── support / resistance ─────────────────────────

def _gaps(ctx: _Ctx) -> list[tuple[str, int, float, float]]:
  """Unfilled gaps in the look-back → (dir 'up'|'down', bar, zone_lo, zone_hi)."""
  n, h, l = ctx.n, ctx.h, ctx.l
  s0 = max(1, n - ctx.P["gap"])
  sufmin = [0.0] * (n + 1)
  sufmax = [0.0] * (n + 1)
  sufmin[n] = math.inf
  sufmax[n] = -math.inf
  for j in range(n - 1, s0 - 2 if s0 >= 2 else -1, -1):
    sufmin[j] = min(l[j], sufmin[j + 1])
    sufmax[j] = max(h[j], sufmax[j + 1])
  out = []
  minsz = max(0.1 * ctx.av, 0.002 * ctx.price)
  for j in range(s0, n):
    if l[j] > h[j - 1]:
      bot, top = h[j - 1], l[j]
      after = sufmin[j + 1]
      if after <= bot:
        continue
      top = min(top, after)
      if top - bot >= minsz:
        out.append(("up", j, bot, top))
    elif h[j] < l[j - 1]:
      bot, top = h[j], l[j - 1]
      after = sufmax[j + 1]
      if after >= top:
        continue
      bot = max(bot, after)
      if top - bot >= minsz:
        out.append(("down", j, bot, top))
  return out[-4:]


def _poc(ctx: _Ctx) -> tuple[float | None, int]:
  """Volume-profile point of control over the last P['poc'] bars."""
  n = ctx.n
  look = min(n, ctx.P["poc"])
  s0 = n - look
  lo = min(ctx.l[s0:])
  hi = max(ctx.h[s0:])
  if hi - lo <= 0:
    return ctx.price, look
  nb = 48
  step = (hi - lo) / nb
  bins = [0.0] * nb
  use_v = sum(ctx.v[s0:]) > 0
  for j in range(s0, n):
    vol = ctx.v[j] if use_v else 1.0
    if vol <= 0:
      continue
    a = int((ctx.l[j] - lo) / step)
    b = int((ctx.h[j] - lo) / step)
    a = 0 if a < 0 else nb - 1 if a >= nb else a
    b = 0 if b < 0 else nb - 1 if b >= nb else b
    share = vol / (b - a + 1)
    for k in range(a, b + 1):
      bins[k] += share
  k = max(range(nb), key=bins.__getitem__)
  return lo + (k + 0.5) * step, look


def _round_steps(p: float) -> float:
  """Psychological round-number step for price p."""
  if p < 10:
    return 1.0
  if p < 50:
    return 5.0
  if p < 100:
    return 10.0
  if p < 500:
    return 50.0
  if p < 1000:
    return 100.0
  if p < 5000:
    return 500.0
  return 1000.0


def _levels(ctx: _Ctx, pats: list[dict], box: dict | None) -> dict[str, Any]:
  """Clustered swing levels + specials → supports / resistances / dynamic / poc."""
  n, i, x, av, tol = ctx.n, ctx.i, ctx.price, ctx.av, ctx.tol
  P = ctx.P
  s0 = max(0, n - P["sr"])
  zz_set = {p[0] for p in ctx.zz}
  avg_v = _mean(ctx.v[s0:])
  half = P["half"]

  def w_of(j: int) -> float:
    rec = 0.25 + 0.75 * 0.5 ** ((i - j) / half)
    vw = 1.0
    if avg_v > 0:
      vw = _clamp(math.sqrt(ctx.v[j] / avg_v), 0.7, 1.5) if ctx.v[j] > 0 else 0.7
    return (1.6 if j in zz_set else 1.0) * rec * vw

  pts = [(ctx.h[j], w_of(j), j, "H") for j in ctx.fh if j >= s0]
  pts += [(ctx.l[j], w_of(j), j, "L") for j in ctx.fl if j >= s0]
  fh, fl = set(ctx.fh), set(ctx.fl)
  for j, p, k, _ in ctx.zz:
    if s0 <= j < i and ((k == "H" and j not in fh) or (k == "L" and j not in fl)):
      pts.append((p, w_of(j), j, k))
      (fh if k == "H" else fl).add(j)
  k5 = min(5, i)
  if k5 >= 2:
    seg_l = ctx.l[i - k5:i]
    seg_h = ctx.h[i - k5:i]
    jl = i - k5 + seg_l.index(min(seg_l))
    jh = i - k5 + seg_h.index(max(seg_h))
    if jl not in fl and ctx.l[jl] < x:
      pts.append((ctx.l[jl], w_of(jl), jl, "L"))
    if jh not in fh and ctx.h[jh] > x:
      pts.append((ctx.h[jh], w_of(jh), jh, "H"))
  pts.sort()
  clusters: list[dict] = []
  for p, w, j, k in pts:
    if clusters and p - clusters[-1]["c"] <= tol:
      cl = clusters[-1]
      cl["ws"] += w
      cl["pw"] += p * w
      cl["c"] = cl["pw"] / cl["ws"]
      cl["m"].append((p, w, j, k))
    else:
      clusters.append({"c": p, "ws": w, "pw": p * w, "m": [(p, w, j, k)]})
  levels: list[dict] = []
  for cl in clusters:
    ms = cl["m"]
    wh = sum(m[1] for m in ms if m[3] == "H")
    kind = "前波高點" if wh >= cl["ws"] - wh else "前波低點"
    last = max(m[2] for m in ms)
    word = "高點" if kind == "前波高點" else "低點"
    t = len(ms)
    txt = f"{ctx.fd(last)} 等 {t} 次轉折{word}" if t > 1 else f"{ctx.fd(last)} 轉折{word}"
    levels.append({"p": cl["c"], "lo": min(m[0] for m in ms), "hi": max(m[0] for m in ms),
                   "score": cl["ws"], "kind": kind, "touches": t, "last": last,
                   "tags": [txt], "kinds": {kind}})

  def add(kind: str, p: float, j: int | None, s: float, txt: str, zone=None,
          touches: int = 0) -> None:
    if p is None or not math.isfinite(p) or p <= 0:
      return
    best = None
    for L in levels:
      dd = abs(L["p"] - p)
      if dd <= tol and (best is None or dd < abs(best["p"] - p)):
        best = L
    if best is not None:
      best["score"] += s
      if kind in ("52週高點", "52週低點") and best["touches"] <= 1 and best["last"] == j:
        best["tags"] = [txt]
        best["kinds"].add(kind)
      elif kind not in best["kinds"]:
        best["tags"].append(txt)
        best["kinds"].add(kind)
      if _KIND_PRI[kind] > _KIND_PRI[best["kind"]]:
        best["kind"] = kind
        if kind in ("頸線", "箱型上緣", "箱型下緣", "52週高點", "52週低點"):
          best["p"] = p
      best["touches"] = max(best["touches"], touches)
      if j is not None and (best["last"] is None or j > best["last"]):
        best["last"] = j
      if zone:
        best["lo"] = min(best["lo"], zone[0])
        best["hi"] = max(best["hi"], zone[1])
      return
    lo, hi = zone if zone else (p, p)
    levels.append({"p": p, "lo": lo, "hi": hi, "score": s, "kind": kind,
                   "touches": touches, "last": j, "tags": [txt], "kinds": {kind}})

  bpy = P["bpy"]
  if n >= 60:
    w0 = max(0, n - bpy)
    hseg = ctx.h[w0:]
    lseg = ctx.l[w0:]
    hi52 = max(hseg)
    lo52 = min(lseg)
    jh = w0 + hseg.index(hi52)
    jl = w0 + lseg.index(lo52)
    lbl = "52 週" if n >= bpy else f"近 {n} {ctx.unit}"
    add("52週高點", hi52, jh, 1.5, f"{lbl}最高價（{ctx.fd(jh)}）", touches=1)
    add("52週低點", lo52, jl, 1.5, f"{lbl}最低價（{ctx.fd(jl)}）", touches=1)
  for dr, j, zl, zh in _gaps(ctx):
    word = "向上" if dr == "up" else "向下"
    add("缺口", (zl + zh) / 2, j, 0.8,
        f"{ctx.fd(j)} {word}跳空缺口 {_fp(zl)}–{_fp(zh)} 尚未回補", zone=(zl, zh), touches=1)
  poc, look = _poc(ctx)
  if poc is not None:
    add("成交密集區", poc, None, 1.2, f"近 {look} {ctx.unit}成交量最密集價位")
  step = _round_steps(x)
  for r in (math.floor(x / step) * step, math.ceil(x / step) * step,
            math.floor(x / step) * step - step, math.ceil(x / step) * step + step):
    if r > 0 and abs(r - x) <= 0.12 * x and abs(r - x) > 1e-9:
      add("整數關卡", float(r), None, 0.5, f"{_fp(r)} 元整數關卡")
  if box:
    add("箱型上緣", box["top"], box["e"], 2.0,
        f"{ctx.fd(box['s'])}～{ctx.fd(box['e'])} 箱型區間上緣", touches=box["t_top"])
    add("箱型下緣", box["bot"], box["e"], 2.0,
        f"{ctx.fd(box['s'])}～{ctx.fd(box['e'])} 箱型區間下緣", touches=box["t_bot"])
  for pt in pats:
    nk = pt.get("_neck_now")
    if nk is not None and pt["name"] in ("W底", "M頭", "頭肩底", "頭肩頂"):
      add("頸線", nk, None, 2.0, f"{pt['name']}頸線", touches=2)

  hw = max(0.2 * av, 0.003 * x)

  def pick(below: bool) -> list[dict]:
    maxd = max(0.25 * x, 10 * av)
    cand = [L for L in levels if (L["p"] < x if below else L["p"] > x)
            and abs(L["p"] - x) <= maxd]
    if not cand:
      return []
    cand.sort(key=lambda L: abs(L["p"] - x))
    chosen = []
    for L in cand:
      if L["score"] >= 0.8 or _KIND_PRI[L["kind"]] >= 5:
        chosen.append(L)
        break
    ranked = sorted(cand, key=lambda L: -L["score"] / (1 + abs(L["p"] - x) / (5 * av)))
    for L in ranked:
      if len(chosen) >= 4:
        break
      if L not in chosen:
        chosen.append(L)
    chosen.sort(key=lambda L: abs(L["p"] - x))
    return chosen

  def fmt(L: dict, below: bool) -> dict | None:
    p = _rt(L["p"])
    if p is not None and ((below and p >= x) or (not below and p <= x)):
      p = _rt(L["p"], -1 if below else 1)
    if p is None or (below and p >= x) or (not below and p <= x):
      return None
    lo = min(L["lo"], L["p"] - hw)
    hi = max(L["hi"], L["p"] + hw)
    if below:
      hi = min(hi, x)
    else:
      lo = max(lo, x)
    st = 3 if L["score"] >= 4.0 else 2 if L["score"] >= 2.0 else 1
    if L["kind"] in ("頸線", "箱型上緣", "箱型下緣", "52週高點", "52週低點"):
      st = max(st, 2)
    if L["kind"] in ("前波高點",) and below:
      desc = f"前波高點 {_fp(p)} 已被突破、壓力轉支撐（{'；'.join(L['tags'])}）"
    elif L["kind"] in ("前波低點",) and not below:
      desc = f"前波低點 {_fp(p)} 已跌破、支撐轉壓力（{'；'.join(L['tags'])}）"
    else:
      desc = "；".join(L["tags"])
    return {"price": p, "low": _rt(lo, -1), "high": _rt(hi, 1), "strength": st,
            "kind": L["kind"], "touches": int(L["touches"]),
            "last_date": ctx.d[L["last"]] if L["last"] is not None else None,
            "desc": desc, "_score": L["score"]}

  sups = [s for s in (fmt(L, True) for L in pick(True)) if s]
  ress = [r for r in (fmt(L, False) for L in pick(False)) if r]
  dyn = []
  for name, key in (("MA5", "ma5"), ("MA10", "ma10"), ("MA20", "ma20"), ("MA60", "ma60"),
                    ("MA120", "ma120"), ("MA240", "ma240"), ("布林上軌", "bb_up"),
                    ("布林下軌", "bb_lo")):
    val = ctx.ind[key][i]
    if val is not None:
      dyn.append({"name": name, "price": _rp(val), "role": "support" if val <= x else "resistance"})
  if poc is not None:
    where = "位於股價下方，具支撐意義" if poc < x else "位於股價上方，形成套牢壓力"
    poc_out = {"price": _rt(poc), "desc": f"近 {look} {ctx.unit}成交最密集價位，{where}"}
  else:
    poc_out = {"price": None, "desc": "資料不足"}
  return {"supports": sups, "resistances": ress, "dynamic": dyn, "poc": poc_out}


# ───────────────────────────── trendlines ─────────────────────────────

def _best_line(ctx: _Ctx, kind: str) -> dict | None:
  """Best unviolated trendline through two ascending lows / descending highs."""
  n, i, c, h, l, av = ctx.n, ctx.i, ctx.c, ctx.h, ctx.l, ctx.av
  look = ctx.P["tl"]
  s0 = max(0, n - look)
  sup = kind == "support"
  want = "L" if sup else "H"
  piv = [p for p in ctx.zz if p[2] == want and p[0] >= s0 and i - p[0] >= 3][-8:]
  fr = ctx.fl if sup else ctx.fh
  best = None
  best_sc = -1e9
  for a in range(len(piv)):
    i1, y1 = piv[a][0], piv[a][1]
    for b in range(a + 1, len(piv)):
      i2, y2 = piv[b][0], piv[b][1]
      if (sup and y2 - y1 < 0.5 * ctx.a_at(i2)) or (not sup and y1 - y2 < 0.5 * ctx.a_at(i2)) \
          or i2 - i1 < 5:
        continue
      sl = (y2 - y1) / (i2 - i1)
      if abs(sl) * (i - i1) > 0.6 * y1:
        continue
      ok = True
      brk = None
      for j in range(i1 + 1, n):
        lv = y1 + sl * (j - i1)
        aj = ctx.atr[j] or av
        if sup:
          if j < i2:
            if c[j] < lv - 0.5 * aj or l[j] < lv - 1.0 * aj:
              ok = False
              break
          elif j > i2 and c[j] < lv - 1.0 * aj:
            brk = j
            break
        else:
          if j < i2:
            if c[j] > lv + 0.5 * aj or h[j] > lv + 1.0 * aj:
              ok = False
              break
          elif j > i2 and c[j] > lv + 1.0 * aj:
            brk = j
            break
      if not ok or (brk is not None and i - brk > 10):
        continue
      vnow = y1 + sl * (i - i1)
      if vnow <= 0 or abs(vnow - c[i]) > max(3 * av, min(8 * av, 0.15 * c[i])):
        continue
      broken = brk is not None or (c[i] < vnow - 0.25 * av if sup else c[i] > vnow + 0.25 * av)
      t = 2
      for j in fr:
        if j <= i1 or j == i2 or j > i:
          continue
        lv = y1 + sl * (j - i1)
        pj = l[j] if sup else h[j]
        if abs(pj - lv) <= 0.4 * (ctx.atr[j] or av):
          t += 1
      rec = 1.0 - min(1.0, (i - i2) / look)
      sc = (t + 1.5 * (i - i1) / look + 2.0 * rec - (0.8 if broken else 0.0)
            - abs(vnow - c[i]) / (4 * av))
      if sc > best_sc:
        best_sc = sc
        best = (i1, y1, i2, y2, vnow, broken, t, sl)
  if not best:
    return None
  i1, y1, i2, y2, vnow, broken, t, sl = best
  brk = None
  if broken:
    j = i
    while j > i2:
      lv = y1 + sl * (j - i1)
      m = 0.25 * ctx.a_at(j)
      if (sup and c[j] < lv - m) or (not sup and c[j] > lv + m):
        j -= 1
      else:
        break
    brk = min(j + 1, i)
  name = "上升趨勢線" if sup else "下降趨勢線"
  word = "低點" if sup else "高點"
  state = ("已跌破" if sup else "已突破") if broken else ("股價仍在線上方" if sup else "股價仍在線下方")
  desc = (f"{name}（{ctx.fd(i1)} {word} {_fp(y1)} → {ctx.fd(i2)} {word} {_fp(y2)}，"
          f"{ctx.bar_word}約 {_ft(vnow)}，{state}）")
  return {"kind": kind, "p1": [ctx.d[i1], _rt(y1)], "p2": [ctx.d[i2], _rt(y2)],
          "end": [ctx.d[i], _rp(vnow)], "value_now": _rp(vnow), "broken": bool(broken),
          "desc": desc, "_touches": t, "_brk": brk, "_i1": i1}


def _trendlines(ctx: _Ctx) -> list[dict]:
  """Best support (ascending) and resistance (descending) trendlines."""
  out = []
  for kind in ("support", "resistance"):
    tl = _best_line(ctx, kind)
    if tl:
      out.append(tl)
  return out


# ───────────────────────────── chart patterns ─────────────────────────────

def _brk_scan(ctx: _Ctx, start: int, level, up: bool) -> int | None:
  """First bar after `start` closing beyond level(j) by 0.1 ATR (up or down)."""
  c = ctx.c
  for j in range(start + 1, ctx.n):
    lv = level(j)
    m = 0.1 * ctx.a_at(j)
    if (up and c[j] > lv + m) or (not up and c[j] < lv - m):
      return j
  return None


def _vol_ok(ctx: _Ctx, j: int | None, mult: float = 1.3) -> bool:
  """True when bar j traded at least mult × its 20-bar average volume."""
  if j is None:
    return False
  vm = ctx.ind["vol_ma20"][j]
  return bool(vm) and ctx.v[j] >= mult * vm


def _pt(ctx: _Ctx, j: int, p: float) -> list:
  """[date, tick-rounded price] point."""
  return [ctx.d[j], _rt(p)]


def _poly(ctx: _Ctx, pts: list[tuple[int, float]]) -> list[list]:
  """Segment points with strictly ascending bar indices."""
  out = []
  last = -1
  for j, p in pts:
    if j > last:
      out.append([ctx.d[j], _rp(p)])
      last = j
  return out


def _status_text(ctx: _Ctx, status: str, brk: int | None, level: float,
                 up: bool, vol: bool) -> str:
  """Plain-language pattern status clause."""
  if status in ("已突破", "已跌破") and brk is not None:
    word = "突破" if up else "跌破"
    return (f"{ctx.fd(brk)} 收盤 {_fp(ctx.c[brk])} {'帶量' if vol else ''}{word}"
            f" {_ft(level)}，型態確認")
  if status == "失效":
    return "其後價格反向越過型態極值，型態已失效"
  return f"目前股價 {_fp(ctx.price)} 尚未{'突破' if up else '跌破'} {_ft(level)}，仍在形成中"


def _reached(ctx: _Ctx, brk: int | None, target: float | None, up: bool) -> bool:
  """True when price already hit the measured-move target after the breakout."""
  if brk is None or target is None:
    return False
  return max(ctx.h[brk:]) >= target if up else min(ctx.l[brk:]) <= target


def _pat_double(ctx: _Ctx, bottom: bool) -> dict | None:
  """W底 (bottom=True) / M頭 from the last zigzag swings."""
  zz, n, i, c, P = ctx.zz, ctx.n, ctx.i, ctx.c, ctx.P
  want = "L" if bottom else "H"
  for k in range(len(zz) - 1, 1, -1):
    i2, y2, kd2, _ = zz[k]
    if kd2 != want:
      continue
    if i - i2 > P["recent"]:
      break
    im, ym = zz[k - 1][0], zz[k - 1][1]
    i1, y1 = zz[k - 2][0], zz[k - 2][1]
    a2 = ctx.a_at(i2)
    eq = max(a2, 0.03 * y1)
    if abs(y1 - y2) > eq or not (max(6, P["box_min"] // 2) <= i2 - i1 <= P["pat"]):
      continue
    ext = min(y1, y2) if bottom else max(y1, y2)
    depth = (ym - ext) if bottom else (ext - ym)
    if depth < max(1.5 * a2, 0.5 * ctx.zz_thr * ext):
      continue
    neck = ym
    brk = _brk_scan(ctx, i2, lambda j: neck, bottom)
    fail = None
    for j in range((brk if brk is not None else i2) + 1, n):
      aj = ctx.a_at(j)
      if (bottom and c[j] < ext - 0.5 * aj) or (not bottom and c[j] > ext + 0.5 * aj):
        fail = j
        break
    still_failed = (bottom and c[i] < ext) or (not bottom and c[i] > ext)
    if brk is not None:
      if i - brk > P["brk"]:
        return None
      if fail is not None and not still_failed:
        return None
      status = "失效" if fail is not None else ("已突破" if bottom else "已跌破")
    elif fail is not None:
      if i - fail > 5 or not still_failed:
        return None
      status = "失效"
    else:
      prog = (c[i] - y2) / (neck - y2) if bottom else (y2 - c[i]) / (y2 - neck)
      if i - i2 < 3 or prog < 0.25:
        return None
      status = "形成中"
    target = neck + depth if bottom else neck - depth
    conf = 0.5
    if (bottom and y2 >= y1) or (not bottom and y2 <= y1):
      conf += 0.1
    if abs(y1 - y2) <= 0.5 * eq:
      conf += 0.05
    if k >= 3 and ((bottom and zz[k - 3][1] > neck) or (not bottom and zz[k - 3][1] < neck)):
      conf += 0.1
    vol = _vol_ok(ctx, brk)
    if brk is not None:
      conf += 0.1 + (0.1 if vol else 0.0)
    if status == "失效":
      conf = 0.4
    name = "W底" if bottom else "M頭"
    typ = ("bullish" if bottom else "bearish") if status != "失效" else (
      "bearish" if bottom else "bullish")
    word = "低點" if bottom else "高點"
    mid_word = "反彈高點" if bottom else "回檔低點"
    reached = status != "失效" and _reached(ctx, brk, target, bottom)
    desc = (f"{ctx.fd(i1)} {word} {_fp(y1)} 與 {ctx.fd(i2)} {word} {_fp(y2)} 形成兩個相近的"
            f"{'底部' if bottom else '頭部'}，中間{mid_word} {_ft(neck)} 為頸線；"
            + _status_text(ctx, status, brk, neck, bottom, vol)
            + (f"，依量幅（頸線{'＋' if bottom else '－'}"
               f"{'底部' if bottom else '頭部'}深度 {_ft(depth)}）推算目標約 {_ft(target)}"
               if status != "失效" else "")
            + ("，且已達目標" if reached else "") + "。")
    end_j = brk if brk is not None else i
    segs = [{"points": _poly(ctx, [(i1, y1), (im, ym), (i2, y2), (end_j, c[end_j])]),
             "color": C_PAT, "title": name},
            {"points": _poly(ctx, [(im, neck), (i, neck)]), "color": C_PAT,
             "title": f"{name}頸線"}]
    return {"name": name, "type": typ, "status": status,
            "confidence": round(_clamp(conf, 0.3, 0.9), 2),
            "start": ctx.d[i1], "end": ctx.d[end_j], "neckline": _rt(neck),
            "target": _rt(target) if status != "失效" else None,
            "points": [_pt(ctx, i1, y1), _pt(ctx, im, ym), _pt(ctx, i2, y2)],
            "desc": desc, "_segs": segs, "_neck_now": neck, "_brk": brk, "_reached": reached,
            "_piv": {i1, im, i2}, "_s": i1, "_e": end_j}
  return None


def _pat_hs(ctx: _Ctx, bottom: bool) -> dict | None:
  """頭肩底 (bottom=True) / 頭肩頂 from five alternating zigzag swings."""
  zz, n, i, c, P = ctx.zz, ctx.n, ctx.i, ctx.c, ctx.P
  want = "L" if bottom else "H"
  for k in range(len(zz) - 1, 3, -1):
    if zz[k][2] != want:
      continue
    if i - zz[k][0] > P["recent"]:
      break
    (i1, y1), (ia, ya), (i2, y2), (ib, yb), (i3, y3) = [(p[0], p[1]) for p in zz[k - 4:k + 1]]
    a = ctx.a_at(i2)
    gap = max(0.5 * a, 0.015 * y2)
    if bottom and not y2 < min(y1, y3) - gap:
      continue
    if not bottom and not y2 > max(y1, y3) + gap:
      continue
    if abs(y1 - y3) > max(1.5 * a, 0.04 * y2) or abs(ya - yb) > max(2 * a, 0.06 * ya):
      continue
    t1, t2 = i2 - i1, i3 - i2
    if t1 <= 0 or t2 <= 0 or not (0.4 <= t1 / t2 <= 2.5) or i3 - i1 > P["pat"]:
      continue
    sl = (yb - ya) / (ib - ia) if ib != ia else 0.0
    depth0 = (min(ya, yb) - y2) if bottom else (y2 - max(ya, yb))
    if depth0 < 1.5 * a or abs(sl) * (i3 - ib) > 0.35 * depth0:
      continue
    nlo, nhi = min(ya, yb) - 0.2 * depth0, max(ya, yb) + 0.2 * depth0

    def nv(j: int, ya=ya, ia=ia, sl=sl, nlo=nlo, nhi=nhi) -> float:
      return _clamp(ya + sl * (j - ia), nlo, nhi)

    depth = (nv(i2) - y2) if bottom else (y2 - nv(i2))
    if (bottom and y3 - nv(i3) > -0.5 * depth) or (not bottom and y3 - nv(i3) < 0.5 * depth):
      continue
    brk = _brk_scan(ctx, i3, nv, bottom)
    fail = None
    for j in range((brk if brk is not None else i3) + 1, n):
      aj = ctx.a_at(j)
      lim = y3 - (0.0 if brk is not None else 0.5 * aj) if bottom else y3 + (
        0.0 if brk is not None else 0.5 * aj)
      if (bottom and c[j] < lim) or (not bottom and c[j] > lim):
        fail = j
        break
    still_failed = (bottom and c[i] < y3) or (not bottom and c[i] > y3)
    if brk is not None:
      if i - brk > P["brk"]:
        return None
      if fail is not None and not still_failed:
        return None
      status = "失效" if fail is not None else ("已突破" if bottom else "已跌破")
    elif fail is not None:
      if i - fail > 5 or not still_failed:
        return None
      status = "失效"
    else:
      prog = (c[i] - y3) / (nv(i) - y3) if bottom else (y3 - c[i]) / (y3 - nv(i))
      if i - i3 < 3 or prog < 0.25:
        return None
      status = "形成中"
    ref = brk if brk is not None else i
    target = nv(ref) + depth if bottom else nv(ref) - depth
    vol = _vol_ok(ctx, brk)
    conf = 0.55 + (0.1 if brk is not None else 0.0) + (0.1 if vol else 0.0)
    if abs(y1 - y3) <= max(0.75 * a, 0.02 * y2):
      conf += 0.05
    if status == "失效":
      conf = 0.4
    name = "頭肩底" if bottom else "頭肩頂"
    typ = ("bullish" if bottom else "bearish") if status != "失效" else (
      "bearish" if bottom else "bullish")
    word = "低點" if bottom else "高點"
    reached = status != "失效" and _reached(ctx, brk, target, bottom)
    desc = (f"左肩 {ctx.fd(i1)} {_fp(y1)}、頭部 {ctx.fd(i2)} {_fp(y2)}、右肩 {ctx.fd(i3)} "
            f"{_fp(y3)}（三個{word}中間最{'低' if bottom else '高'}），頸線連接 {_fp(ya)} 與 "
            f"{_fp(yb)}，目前約 {_ft(nv(i))}；"
            + _status_text(ctx, status, brk, nv(ref), bottom, vol)
            + (f"，量幅目標約 {_ft(target)}" if status != "失效" else "")
            + ("，且已達目標" if reached else "") + "。")
    end_j = brk if brk is not None else i
    segs = [{"points": _poly(ctx, [(i1, y1), (ia, ya), (i2, y2), (ib, yb), (i3, y3),
                                   (end_j, c[end_j])]), "color": C_PAT, "title": name},
            {"points": _poly(ctx, [(ia, ya), (i, nv(i))]), "color": C_PAT,
             "title": f"{name}頸線"}]
    return {"name": name, "type": typ, "status": status,
            "confidence": round(_clamp(conf, 0.3, 0.9), 2),
            "start": ctx.d[i1], "end": ctx.d[end_j], "neckline": _rt(nv(i)),
            "target": _rt(target) if status != "失效" else None,
            "points": [_pt(ctx, j, p)
                       for j, p in ((i1, y1), (ia, ya), (i2, y2), (ib, yb), (i3, y3))],
            "desc": desc, "_segs": segs, "_neck_now": nv(i), "_brk": brk, "_reached": reached,
            "_piv": {i1, ia, i2, ib, i3}, "_s": i1, "_e": end_j}
  return None


def _pat_lines(ctx: _Ctx) -> dict | None:
  """Triangles, wedges, channels and line-fitted boxes from recent swings."""
  zz = [p for p in ctx.zz if p[3]]
  n, i, c, P, av, x = ctx.n, ctx.i, ctx.c, ctx.P, ctx.av, ctx.price
  for K in (6, 5):
    if len(zz) < K:
      continue
    sel = zz[-K:]
    lp = sel[-1][0]
    if i - lp > P["recent"]:
      return None
    i0 = sel[0][0]
    span = i - i0
    if span < P["box_min"] or i0 < n - P["pat"] - 1:
      continue
    hs = [(p[0], p[1]) for p in sel if p[2] == "H"]
    ls = [(p[0], p[1]) for p in sel if p[2] == "L"]
    if len(hs) < 2 or len(ls) < 2:
      continue
    bu, au, ru = _fit_line(hs)
    bl, al, rl = _fit_line(ls)
    lim = max(0.8 * av, 0.02 * x)
    if ru > lim or rl > lim:
      continue

    def u(j: int, au=au, bu=bu) -> float:
      return au + bu * j

    def lo(j: int, al=al, bl=bl) -> float:
      return al + bl * j

    w0 = u(i0) - lo(i0)
    wl = u(lp) - lo(lp)
    if w0 <= 0 or wl <= 0 or w0 < max(2 * av, 0.04 * x):
      continue
    if any(c[j] > u(j) + 0.5 * ctx.a_at(j) or c[j] < lo(j) - 0.5 * ctx.a_at(j)
           for j in range(i0, lp + 1)):
      continue
    flat = max(1.2 * av, 0.03 * x)
    du, dl = bu * span, bl * span
    up_u, dn_u, up_l, dn_l = du > flat, du < -flat, dl > flat, dl < -flat
    ratio = wl / w0
    conv, par = ratio < 0.7, 0.7 <= ratio <= 1.35
    name = None
    if not up_u and not dn_u and up_l and conv:
      name = "上升三角形"
    elif dn_u and not up_l and not dn_l and conv:
      name = "下降三角形"
    elif dn_u and up_l:
      name = "收斂三角形"
    elif up_u and up_l and conv and bl > bu:
      name = "上升楔形"
    elif dn_u and dn_l and conv and bu < bl:
      name = "下降楔形"
    elif up_u and up_l and par:
      name = "上升通道"
    elif dn_u and dn_l and par:
      name = "下降通道"
    elif not (up_u or dn_u or up_l or dn_l) and par:
      name = "箱型整理"
    if not name:
      continue
    un, ln_ = u(i), lo(i)
    a_i = ctx.a_at(i)
    if c[i] > un + 0.1 * a_i:
      status = "已突破"
      side = 1
    elif c[i] < ln_ - 0.1 * a_i:
      status = "已跌破"
      side = -1
    else:
      status = "形成中"
      side = 0
    brk = None
    if side:
      for j in range(lp + 1, i + 1):
        aj = ctx.a_at(j)
        if (side > 0 and c[j] > u(j) + 0.1 * aj) or (side < 0 and c[j] < lo(j) - 0.1 * aj):
          brk = j
          break
      if brk is None or i - brk > P["brk"]:
        continue
    elif un <= ln_:
      continue
    if name == "箱型整理" and side:
      name = "箱型突破" if side > 0 else "箱型跌破"
    if side > 0:
      typ = "bullish"
    elif side < 0:
      typ = "bearish"
    else:
      typ = ("bullish" if name in _BULLISH_PATS else
             "bearish" if name in _BEARISH_PATS else "neutral")
    if side > 0:
      target = max(u(i0), un + wl) if name == "下降楔形" else un + (wl if "通道" in name else w0)
      neck = un
    elif side < 0:
      target = min(lo(i0), ln_ - wl) if name == "上升楔形" else ln_ - (wl if "通道" in name else w0)
      neck = ln_
    elif typ == "bullish":
      target = un if "通道" in name else (u(i0) if name == "下降楔形" else un + w0)
      neck = un
    elif typ == "bearish":
      target = ln_ if "通道" in name else (lo(i0) if name == "上升楔形" else ln_ - w0)
      neck = ln_
    else:
      target = None
      neck = un
    vol = _vol_ok(ctx, brk, 1.5)
    conf = 0.45 + 0.05 * (K - 4) + (0.1 if max(ru, rl) < 0.4 * av else 0.0) + (
      0.1 if vol else 0.0)
    ej = brk if brk is not None else i
    if brk is not None:
      neck = u(brk) if side > 0 else lo(brk)

    def mv(a: float, b: float) -> str:
      return "持平" if abs(b - a) <= flat else ("上升" if b > a else "下降")

    base = name[:2] + "整理" if name.startswith("箱型") else name
    hit = bool(side) and _reached(ctx, brk, target, side > 0)
    reached = "，且已達型態目標" if hit else ""
    desc = (f"{ctx.fd(i0)} 起 {K} 個波段轉折構成{base}：上緣由 {_ft(u(i0))} {mv(u(i0), u(ej))}至 "
            f"{_ft(u(ej))}、下緣由 {_ft(lo(i0))} {mv(lo(i0), lo(ej))}至 {_ft(lo(ej))}"
            f"（{ctx.fd(ej)}）；"
            + _status_text(ctx, status, brk, neck, side >= 0 if side else typ != "bearish", vol)
            + (f"，型態目標約 {_ft(target)}{reached}" if target is not None else "，等待方向表態")
            + "。")
    segs = [{"points": _poly(ctx, [(i0, u(i0)), (ej, u(ej))]), "color": C_PAT,
             "title": f"{base}上緣"},
            {"points": _poly(ctx, [(i0, lo(i0)), (ej, lo(ej))]), "color": C_PAT,
             "title": f"{base}下緣"}]
    return {"name": name, "type": typ, "status": status,
            "confidence": round(_clamp(conf, 0.3, 0.85), 2),
            "start": ctx.d[i0], "end": ctx.d[brk if brk is not None else i],
            "neckline": _rt(neck), "target": _rt(target) if target is not None else None,
            "points": [_pt(ctx, p[0], p[1]) for p in sel], "desc": desc, "_segs": segs,
            "_neck_now": None, "_brk": brk, "_reached": hit, "_piv": {p[0] for p in sel}, "_s": i0,
            "_e": i}
  return None


def _pat_box(ctx: _Ctx) -> tuple[dict | None, dict | None]:
  """Bar-based 箱型整理 / 箱型突破 / 箱型跌破."""
  P = ctx.P
  bx = _box_state(ctx.h, ctx.l, ctx.c, ctx.av, P["box_min"], P["box_lag"])
  if not bx:
    return None, None
  top, bot, s, e = bx["top"], bx["bot"], bx["s"], bx["e"]
  w = top - bot
  b = bx["b"]
  vol = _vol_ok(ctx, b, 1.5)
  if bx["state"] == "up":
    name, status, typ, target, neck = "箱型突破", "已突破", "bullish", top + w, top
  elif bx["state"] == "down":
    name, status, typ, target, neck = "箱型跌破", "已跌破", "bearish", bot - w, bot
  else:
    name, status, typ, target, neck = "箱型整理", "形成中", "neutral", None, top
  conf = 0.5 + 0.05 * min(4, bx["t_top"] + bx["t_bot"] - 4) + (0.15 if vol else 0.0)
  if bx["state"] == "in":
    conf -= 0.05
  ln = e - s + 1
  desc = (f"{ctx.fd(s)}～{ctx.fd(e)} 約 {ln} {ctx.unit}股價在 {_fp(bot)}–{_fp(top)} 區間整理"
          f"（上緣觸及 {bx['t_top']} 次、下緣 {bx['t_bot']} 次，區間幅度 {w / ((top + bot) / 2) * 100:.1f}%）；")
  hit = b is not None and _reached(ctx, b, target, bx["state"] == "up")
  if status == "已突破":
    desc += (f"{ctx.fd(b)} 收盤 {_fp(ctx.c[b])} {'帶量' if vol else ''}突破上緣 {_fp(top)}，"
             f"脫離整理，依箱型高度推算目標約 {_ft(target)}{'（已達成）' if hit else ''}；"
             f"回測 {_fp(top)} 不破可視為支撐。")
  elif status == "已跌破":
    desc += (f"{ctx.fd(b)} 收盤 {_fp(ctx.c[b])} {'帶量' if vol else ''}跌破下緣 {_fp(bot)}，"
             f"整理失敗轉弱，依箱型高度推算下檔約 {_ft(target)}{'（已達成）' if hit else ''}；"
             f"{_fp(bot)} 轉為壓力。")
  else:
    desc += f"目前 {_fp(ctx.price)} 位於區間內，等待帶量突破 {_fp(top)} 或跌破 {_fp(bot)} 表態。"
  pts = []
  for j in range(s, e + 1):
    if ctx.h[j] >= top - 1e-9 or ctx.l[j] <= bot + 1e-9:
      pts.append(_pt(ctx, j, ctx.h[j] if ctx.h[j] >= top - 1e-9 else ctx.l[j]))
  end_j = b if b is not None else ctx.i
  segs = [{"points": _poly(ctx, [(s, top), (end_j, top)]), "color": C_PAT, "title": "箱型上緣"},
          {"points": _poly(ctx, [(s, bot), (end_j, bot)]), "color": C_PAT, "title": "箱型下緣"}]
  pat = {"name": name, "type": typ, "status": status,
         "confidence": round(_clamp(conf, 0.3, 0.9), 2),
         "start": ctx.d[s], "end": ctx.d[end_j], "neckline": _rt(neck),
         "target": _rt(target) if target is not None else None, "points": pts[:8],
         "desc": desc, "_segs": segs, "_neck_now": None, "_brk": b, "_reached": hit, "_piv": set(),
         "_s": s, "_e": end_j}
  return pat, bx


def _patterns(ctx: _Ctx) -> tuple[list[dict], dict | None]:
  """All detected chart patterns (≤ 4, most relevant first) and the active box."""
  box_pat, box = _pat_box(ctx)
  hs_b, hs_t = _pat_hs(ctx, True), _pat_hs(ctx, False)
  db, dt = _pat_double(ctx, True), _pat_double(ctx, False)
  ln = _pat_lines(ctx)
  for hs in (hs_b, hs_t):
    if hs and db and hs["_piv"] & db["_piv"]:
      db = None
    if hs and dt and hs["_piv"] & dt["_piv"]:
      dt = None
  if db and dt and db["_piv"] & dt["_piv"]:
    if max(db["_piv"]) >= max(dt["_piv"]):
      dt = None
    else:
      db = None
  if hs_b and hs_t and hs_b["_piv"] & hs_t["_piv"]:
    if max(hs_b["_piv"]) >= max(hs_t["_piv"]):
      hs_t = None
    else:
      hs_b = None
  if ln and box_pat:
    if ln["name"].startswith("箱型"):
      ln = None
    else:
      ov = min(ln["_e"], box_pat["_e"]) - max(ln["_s"], box_pat["_s"])
      shorter = min(ln["_e"] - ln["_s"], box_pat["_e"] - box_pat["_s"]) or 1
      if ov / shorter > 0.5:
        if ln["confidence"] > box_pat["confidence"]:
          box_pat = None
        else:
          ln = None
  def covered(pt: dict | None) -> bool:
    """True when a W/M or H&S is just a sub-structure of a box / line pattern."""
    if not pt:
      return False
    pv = pt["_piv"]
    if box_pat and box_pat["_s"] <= min(pv) and max(pv) <= box_pat["_e"]:
      return True
    return bool(ln and min(pv) >= ln["_s"])

  hs_b, hs_t, db, dt = [None if covered(pt) else pt for pt in (hs_b, hs_t, db, dt)]
  pats = [p for p in (box_pat, hs_b, hs_t, db, dt, ln) if p]
  rank = {"已突破": 0, "已跌破": 0, "形成中": 1, "失效": 2}
  pats.sort(key=lambda p: (rank[p["status"]], -p["_e"], -p["confidence"]))
  return pats[:4], (box if box_pat else None)


def _pat_label(p: dict) -> str:
  """'W底已突破' / '箱型突破' (box names already carry their status)."""
  return p["name"] if p["name"] in ("箱型突破", "箱型跌破") else f"{p['name']}{p['status']}"


# ───────────────────────────── candles / signals / volume ─────────────────────

def _candle_desc(ctx: _Ctx, name: str, i: int) -> str:
  """Specific description (prices, %) for a candlestick pattern on bar i."""
  o, h, l, c = ctx.o, ctx.h, ctx.l, ctx.c
  pc = c[i - 1]
  rng = h[i] - l[i] or 1e-9
  body = abs(c[i] - o[i])
  up_sh = h[i] - max(o[i], c[i])
  lo_sh = min(o[i], c[i]) - l[i]
  day = ctx.fd(i)
  chg = _pct(c[i], pc)
  if name in ("長紅K", "長黑K"):
    return (f"{day} 開盤 {_fp(o[i])}、收盤 {_fp(c[i])}（{_sp(chg, 2)}），實體占當根振幅 "
            f"{body / rng * 100:.0f}%，{'買方' if name == '長紅K' else '賣方'}強勢主導")
  if name == "十字線":
    return (f"{day} 開盤 {_fp(o[i])} 與收盤 {_fp(c[i])} 幾乎相同，上影線 {_fp(up_sh)}、"
            f"下影線 {_fp(lo_sh)}，多空拉鋸，留意變盤")
  if name in ("錘子線", "吊人線"):
    tail = "低檔有買盤承接" if name == "錘子線" else "漲勢中出現，留意高檔賣壓"
    return f"{day} 盤中最低 {_fp(l[i])} 後收回 {_fp(c[i])}，下影線長 {_fp(lo_sh)}，{tail}"
  if name in ("倒鎚線", "射擊之星"):
    tail = "跌勢中買方開始試探" if name == "倒鎚線" else "漲勢中追價力道不足"
    return f"{day} 盤中最高 {_fp(h[i])} 後拉回至 {_fp(c[i])}，上影線長 {_fp(up_sh)}，{tail}"
  if name in ("多頭吞噬", "空頭吞噬"):
    a, b = ("紅", "黑") if name == "多頭吞噬" else ("黑", "紅")
    return (f"{day} {a}K（{_fp(o[i])}→{_fp(c[i])}）實體完全包覆前一根{b}K"
            f"（{_fp(o[i - 1])}→{_fp(c[i - 1])}），{'買方反攻' if a == '紅' else '賣方反撲'}")
  if name in ("晨星", "夜星"):
    return (f"{ctx.fd(i - 2)}～{day} 三根K棒依序為長{'黑' if name == '晨星' else '紅'}、"
            f"小實體、長{'紅' if name == '晨星' else '黑'}，收盤 {_fp(c[i])}，"
            f"{'底部反轉' if name == '晨星' else '頭部反轉'}訊號")
  if name in ("紅三兵", "黑三兵"):
    return (f"{ctx.fd(i - 2)}～{day} 連續三根{'紅' if name == '紅三兵' else '黑'}K，收盤由 "
            f"{_fp(c[i - 2])} {'墊高' if name == '紅三兵' else '走低'}至 {_fp(c[i])}")
  return f"{day} 出現{name}"


def _candles(ctx: _Ctx, q: dict) -> list[dict]:
  """Candlestick patterns completed on the last bar."""
  i = ctx.i
  return [{"name": nm, "type": tp, "date": ctx.d[i], "desc": _candle_desc(ctx, nm, i)}
          for nm, tp in q["candles"]]


def _divergences(ctx: _Ctx) -> list[tuple[str, str, int, str]]:
  """RSI / MACD divergences between the last two swing pivots (≤ 60 bars)."""
  out = []
  i, av, h, l = ctx.i, ctx.av, ctx.h, ctx.l
  rs, dif = ctx.ind["rsi14"], ctx.ind["dif"]
  hs = [j for j in ctx.fh if i - j <= 60]
  ls = [j for j in ctx.fl if i - j <= 60]
  if len(hs) >= 2:
    j1, j2 = hs[-2], hs[-1]
    if i - j2 <= 15 and j2 - j1 >= 5 and h[j2] > h[j1] + 0.2 * av:
      if rs[j1] is not None and rs[j2] is not None and rs[j2] < rs[j1] - 3:
        out.append(("RSI頂背離", "bearish", j2,
                    f"股價高點由 {ctx.fd(j1)} {_fp(h[j1])} 墊高至 {ctx.fd(j2)} {_fp(h[j2])}，"
                    f"RSI(14) 卻由 {rs[j1]:.1f} 降至 {rs[j2]:.1f}，上漲動能減弱"))
      if dif[j1] is not None and dif[j2] is not None and dif[j2] < dif[j1] - 0.05 * av:
        out.append(("MACD頂背離", "bearish", j2,
                    f"股價創波段新高 {_fp(h[j2])}，MACD 的 DIF 卻由 {_fp(dif[j1])} 降至 "
                    f"{_fp(dif[j2])}，中期動能未同步走強"))
  if len(ls) >= 2:
    j1, j2 = ls[-2], ls[-1]
    if i - j2 <= 15 and j2 - j1 >= 5 and l[j2] < l[j1] - 0.2 * av:
      if rs[j1] is not None and rs[j2] is not None and rs[j2] > rs[j1] + 3:
        out.append(("RSI底背離", "bullish", j2,
                    f"股價低點由 {ctx.fd(j1)} {_fp(l[j1])} 降至 {ctx.fd(j2)} {_fp(l[j2])}，"
                    f"RSI(14) 卻由 {rs[j1]:.1f} 升至 {rs[j2]:.1f}，下跌動能減弱"))
      if dif[j1] is not None and dif[j2] is not None and dif[j2] > dif[j1] + 0.05 * av:
        out.append(("MACD底背離", "bullish", j2,
                    f"股價創波段新低 {_fp(l[j2])}，MACD 的 DIF 卻由 {_fp(dif[j1])} 升至 "
                    f"{_fp(dif[j2])}，空方動能鈍化"))
  return out


def _signals(ctx: _Ctx, q: dict) -> list[dict]:
  """Indicator events (dated) for the analysis page."""
  ind, i, c, x, u = ctx.ind, ctx.i, ctx.c, ctx.price, ctx.unit
  out: list[dict] = []

  def add(name: str, group: str, typ: str, j: int, desc: str) -> None:
    out.append({"name": name, "group": group, "type": typ, "date": ctx.d[j], "desc": desc,
                "_j": j})

  def g(key: str, j: int = i) -> float | None:
    return _at(ind[key], j)

  m5, m10, m20, m60 = g("ma5"), g("ma10"), g("ma20"), g("ma60")
  if q["bull"]:
    add("多頭排列", "均線", "bullish", i,
        f"5、10、20、60 {u}均線由上而下依序排列（{_fp(m5)}＞{_fp(m10)}＞{_fp(m20)}＞{_fp(m60)}），"
        "各週期持有者皆獲利，趨勢向上")
  elif q["bear"]:
    add("空頭排列", "均線", "bearish", i,
        f"5、10、20、60 {u}均線由下而上依序排列（{_fp(m5)}＜{_fp(m10)}＜{_fp(m20)}＜{_fp(m60)}），"
        "各週期持有者普遍套牢，反彈易遇賣壓")
  if q["tangle"]:
    add("均線糾結", "均線", "neutral", i,
        f"5／10／20／60 {u}均線差距不到 2%（{_fp(min(m5, m10, m20, m60))}–"
        f"{_fp(max(m5, m10, m20, m60))}），多空成本接近，常是變盤前兆")
  for a, b, look in ((5, 20, 5), (20, 60, 10)):
    xx = _cross(ind[f"ma{a}"], ind[f"ma{b}"], i, look)
    if xx:
      j = i - abs(xx) + 1
      up = xx > 0
      add(f"均線{'黃金' if up else '死亡'}交叉({a}/{b})", "均線", "bullish" if up else "bearish", j,
          f"{ctx.fd(j)} {a} {u}均線（{_fp(g(f'ma{a}', j))}）由{'下往上穿越' if up else '上往下跌破'} "
          f"{b} {u}均線（{_fp(g(f'ma{b}', j))}），{'買盤轉強' if up else '賣壓轉強'}")
  names = {20: ("月線", "季線"), 60: ("季線", "季線")}
  for m in (20, 60):
    xc = _close_cross(c, ind[f"ma{m}"], i)
    if xc:
      j = i - abs(_cross(c, ind[f"ma{m}"], i, 3)) + 1
      nick = names[m][0] if ctx.tf == "D" else f"{m}{u}均線"
      nm = f"{'站上' if xc > 0 else '跌破'}{nick}"
      add(nm, "均線", "bullish" if xc > 0 else "bearish", j,
          f"{ctx.fd(j)} 收盤 {_fp(c[j])} {'站上' if xc > 0 else '跌破'} {m} {u}均線 "
          f"{_fp(g(f'ma{m}', j))}，{'短中期轉強' if xc > 0 else '短中期轉弱'}")
  if q["new52"]:
    add("創52週新高", "價格", "bullish", i,
        f"{ctx.fd(i)} 最高 {_fp(ctx.h[i])} 創近一年新高，上方已無套牢壓力")
  if ctx.n >= 63:
    lvl_h = max(ctx.h[ctx.n - 63:ctx.n - 3])
    lvl_l = min(ctx.l[ctx.n - 63:ctx.n - 3])
    if q["brk60"]:
      j = next((k for k in range(ctx.n - 3, ctx.n) if c[k] > lvl_h), i)
      add(f"突破60{u}高", "價格", "bullish", j,
          f"{ctx.fd(j)} 收盤 {_fp(c[j])} 突破前 60 {u}最高價 {_fp(lvl_h)}，創波段新高")
    elif q["brk60d"]:
      j = next((k for k in range(ctx.n - 3, ctx.n) if c[k] < lvl_l), i)
      add(f"跌破60{u}低", "價格", "bearish", j,
          f"{ctx.fd(j)} 收盤 {_fp(c[j])} 跌破前 60 {u}最低價 {_fp(lvl_l)}，創波段新低")
  gu, gd = _gap_recent(ctx.h, ctx.l, i, 3)
  if gu >= 0:
    add("跳空上漲", "缺口", "bullish", gu,
        f"{ctx.fd(gu)} 最低 {_fp(ctx.l[gu])} 高於前一根最高 {_fp(ctx.h[gu - 1])}，留下向上跳空缺口，"
        "未回補前為支撐")
  if gd >= 0:
    add("跳空下跌", "缺口", "bearish", gd,
        f"{ctx.fd(gd)} 最高 {_fp(ctx.h[gd])} 低於前一根最低 {_fp(ctx.l[gd - 1])}，留下向下跳空缺口，"
        "未回補前為壓力")
  dif, dea, hist = ind["dif"], ind["dea"], ind["hist"]
  mx = _cross(dif, dea, i, 3)
  if mx and ((mx > 0 and dif[i] > dea[i]) or (mx < 0 and dif[i] < dea[i])):
    j = i - abs(mx) + 1
    up = mx > 0
    add(f"MACD{'黃金' if up else '死亡'}交叉", "MACD", "bullish" if up else "bearish", j,
        f"{ctx.fd(j)} DIF {_fp(dif[j])} 由{'下往上穿越' if up else '上往下跌破'} DEA {_fp(dea[j])}，"
        f"柱狀體由{'綠翻紅' if up else '紅翻綠'}，中期動能{'轉強' if up else '轉弱'}")
  else:
    mx = 0
  zx = _cross(dif, 0.0, i, 3)
  if zx and ((zx > 0 and dif[i] > 0) or (zx < 0 and dif[i] < 0)):
    j = i - abs(zx) + 1
    up = zx > 0
    add(f"MACD{'翻紅' if up else '翻綠'}", "MACD", "bullish" if up else "bearish", j,
        f"{ctx.fd(j)} DIF 由{'負轉正、站上' if up else '正轉負、跌破'}零軸（{_fp(dif[j])}），"
        f"中期{'多方' if up else '空方'}動能確立")
  if not mx and i >= 2 and None not in (hist[i], hist[i - 1], hist[i - 2]):
    if hist[i] < 0 and hist[i] > hist[i - 1] > hist[i - 2]:
      add("MACD綠柱縮短", "MACD", "bullish", i,
          f"柱狀體仍為負值但連續縮短（{_fp(hist[i - 2])}→{_fp(hist[i])}），空方動能減弱")
    elif hist[i] > 0 and hist[i] < hist[i - 1] < hist[i - 2]:
      add("MACD紅柱縮短", "MACD", "bearish", i,
          f"柱狀體仍為正值但連續縮短（{_fp(hist[i - 2])}→{_fp(hist[i])}），多方動能減弱")
  ks, ds = ind["k"], ind["d"]
  kx = _cross(ks, ds, i, 3)
  if kx and ((kx > 0 and ks[i] > ds[i]) or (kx < 0 and ks[i] < ds[i])):
    j = i - abs(kx) + 1
    up = kx > 0
    zone = "低檔" if ks[j] < 20 else "高檔" if ks[j] > 80 else ""
    tail = ("低檔交叉、反彈訊號較可靠" if up and zone == "低檔" else
            "高檔交叉、留意追高風險" if up and zone == "高檔" else
            "高檔交叉、回檔訊號較可靠" if not up and zone == "高檔" else
            "低檔交叉、可能只是弱勢延續" if not up and zone == "低檔" else
            ("短線買盤轉強" if up else "短線賣壓轉強"))
    add(f"KD{'黃金' if up else '死亡'}交叉", "KD", "bullish" if up else "bearish", j,
        f"{ctx.fd(j)} K 值 {ks[j]:.1f} 由{'下往上穿越' if up else '上往下跌破'} D 值 {ds[j]:.1f}，{tail}")
  elif "KD高檔鈍化" in q["tags"]:
    add("KD高檔鈍化", "KD", "bullish", i,
        f"K 值連續 3 根以上維持在 80 以上（目前 {ks[i]:.1f}），強勢股特徵，暫不宜以 KD 高檔判斷賣點")
  elif "KD低檔鈍化" in q["tags"]:
    add("KD低檔鈍化", "KD", "bearish", i,
        f"K 值連續 3 根以上低於 20（目前 {ks[i]:.1f}），弱勢延續，暫不宜以 KD 低檔判斷買點")
  r14, r6 = g("rsi14"), g("rsi6")
  if r14 is not None and r14 >= 70:
    add("RSI超買", "RSI", "bearish", i,
        f"RSI(14) {r14:.1f}、RSI(6) {r6:.1f}，進入 70 以上超買區，短線漲多易拉回")
  elif r14 is not None and r14 <= 30:
    add("RSI超賣", "RSI", "bullish", i,
        f"RSI(14) {r14:.1f}、RSI(6) {r6:.1f}，進入 30 以下超賣區，跌多可能出現反彈")
  for nm, tp, j, desc in _divergences(ctx):
    add(nm, "背離", tp, j, desc)
  up_, mid_, lo_ = g("bb_up"), g("bb_mid"), g("bb_lo")
  if up_ is not None:
    if x > up_:
      add("布林突破上軌", "布林通道", "bullish", i,
          f"收盤 {_fp(x)} 高於布林上軌 {_fp(up_)}，走勢強勁但短線偏離中軌較大")
    elif x < lo_:
      add("布林跌破下軌", "布林通道", "bearish", i,
          f"收盤 {_fp(x)} 低於布林下軌 {_fp(lo_)}，賣壓沉重，但短線也可能超跌")
    if "布林收斂" in q["tags"]:
      add("布林收斂", "布林通道", "neutral", i,
          f"布林通道寬度縮至 {(up_ - lo_) / mid_ * 100:.1f}%（近 120 根最窄的一成），波動壓縮，"
          "常預示即將出現較大行情")
  if q["r20"] is not None and q["r20"] >= 2.5:
    up = c[i] >= ctx.o[i]
    add("爆量", "量能", "bullish" if up and q["pct"] >= 0 else "bearish", i,
        f"{ctx.bar_word}成交 {_fp(ctx.v[i])} 張，達 20 {u}均量的 {q['r20']:.1f} 倍，"
        f"{'收紅代表買盤積極' if up else '收黑代表賣壓湧現'}")
  out.sort(key=lambda s: -s["_j"])
  return out


def _volume(ctx: _Ctx) -> dict[str, Any]:
  """Volume–price state, ratios and OBV trend."""
  v, c, i, u, ind = ctx.v, ctx.c, ctx.i, ctx.unit, ctx.ind
  vm5, vm20 = ind["vol_ma5"][i], ind["vol_ma20"][i]
  r520 = vm5 / vm20 if vm5 is not None and vm20 else None
  today = v[i] / vm20 if vm20 else None
  chg = _pct(c[i], c[i - 1])
  ch5 = _pct(c[i], c[max(0, i - 5)])
  direction = 1 if chg > 0.2 else -1 if chg < -0.2 else (1 if ch5 > 1 else -1 if ch5 < -1 else 0)
  prev5 = _mean(v[max(0, i - 5):i])
  if not vm20 or today is None:
    state = "量縮"
  elif today >= 2.5:
    state = "爆量"
  elif direction == 0:
    state = "量縮" if today < 1.0 else ("價漲量增" if c[i] >= ctx.o[i] else "價跌量增")
  else:
    vol_up = v[i] > prev5 if prev5 > 0 else today >= 1.0
    if direction > 0:
      state = "價漲量增" if vol_up else "價漲量縮"
    else:
      state = "價跌量增" if vol_up else "價跌量縮"
  k = min(20, i)
  scale = sum(v[i - k + 1:i + 1])
  ob = (ctx.obv[i] - ctx.obv[i - k]) / scale if scale > 0 and k > 0 else 0.0
  obv_trend = "上升" if ob > 0.15 else "下降" if ob < -0.15 else "持平"
  bw = ctx.bar_word
  if vm20:
    desc = (f"{bw}成交 {_fv(v[i])} 張（{_sp(chg, 2)}），為 20 {u}均量 {_fv(vm20)} 張的 "
            f"{today:.2f} 倍；5 {u}均量／20 {u}均量 = {r520:.2f}，")
    if r520 is not None and r520 >= 1.3:
      desc += "近期量能明顯放大。"
    elif r520 is not None and r520 <= 0.7:
      desc += "近期量能明顯萎縮。"
    else:
      desc += "近期量能持平。"
  else:
    desc = "成交量資料不足或長期無成交，量價分析參考性有限。"
  if ctx.partial:
    desc += f"（{bw}K棒尚未收完，成交量偏低屬正常，量能比較僅供參考）"
  return {"ratio5_20": _r(r520, 2), "today_vs_ma20": _r(today, 2), "state": state,
          "obv_trend": obv_trend, "desc": desc, "_obv_r": ob}


# ───────────────────────────── score / plan / risks ─────────────────────────

def _final_score(q: dict, trend: dict, pats: list[dict], tls: list[dict],
                 sigs: list[dict]) -> tuple[int, float]:
  """quick_core score refined by patterns, trendlines, divergences and mid trend."""
  adj = 0.0
  sgn = {"bullish": 1.0, "bearish": -1.0, "neutral": 0.0}
  for p in pats:
    w = {"已突破": 6.0, "已跌破": 6.0, "形成中": 2.0, "失效": 3.0}[p["status"]]
    adj += w * p["confidence"] * sgn[p["type"]]
  for tl in tls:
    if tl["broken"]:
      adj += -3.0 if tl["kind"] == "support" else 3.0
  for s in sigs:
    if s["group"] == "背離":
      adj += 2.5 if s["type"] == "bullish" else -2.5
  adj += 1.5 * trend["mid"]["level"]
  adj = _clamp(adj, -10.0, 10.0)
  return int(round(_clamp(q["score"] + adj, 0.0, 100.0))), adj


def _plan(ctx: _Ctx, sl: int, sups: list[dict], ress: list[dict],
          pats: list[dict]) -> dict[str, Any]:
  """Entry zone / stop / targets / risk-reward for a hypothetical long trade."""
  x, av = ctx.price, ctx.av
  S1 = sups[0] if sups else None
  R1 = ress[0] if ress else None
  ma20 = ctx.ind["ma20"][ctx.i]
  m20name = "月線" if ctx.tf == "D" else f"20 {ctx.unit}均線"
  basis = None
  if sl >= 1:
    bias = "偏多操作"
    if S1 and x - S1["price"] <= 3 * av:
      lo, basis, why = S1["price"], S1, f"{S1['kind']} {_fp(S1['price'])}"
    elif ma20 is not None and ma20 < x and x - ma20 <= 3 * av:
      lo, why = ma20, f"{m20name} {_fp(ma20)}"
    else:
      lo, why = x - av, "回檔約 1 個 ATR 處"
    hi = x
  elif sl == 0:
    bias = "區間操作"
    if S1 and x - S1["price"] <= 4 * av:
      lo, basis, why = S1["price"], S1, f"{S1['kind']} {_fp(S1['price'])}"
      hi = min(x, S1["price"] + 0.5 * av)
    else:
      lo, hi, why = x - av, x, "回檔約 1 個 ATR 處"
  else:
    bias = "偏空觀望"
    if R1 and R1["price"] - x <= 4 * av:
      lo, hi, why = R1["price"], R1["price"] + 0.5 * av, f"{R1['kind']} {_fp(R1['price'])}"
    else:
      lo, hi, why = x + av, x + 1.5 * av, "止跌回升約 1 個 ATR 處"
  lo = _rt(lo, -1)
  hi = _rt(hi, 1)
  if hi < lo:
    lo, hi = hi, lo
  if basis is not None:
    k = 0.5 if basis["strength"] >= 3 else 0.75
    stop = basis["low"] - k * av
    stop_why = f"跌破{basis['kind']}區間下緣 {_fp(basis['low'])} 再預留約 {k:g} 個 ATR"
  elif sl >= 0:
    cand = [sp for sp in sups if sp["price"] < lo and lo - sp["price"] <= 3 * av]
    if cand:
      k = 0.5
      stop = cand[0]["low"] - k * av
      stop_why = f"跌破下一道支撐 {_fp(cand[0]['price'])} 再預留約 {k:g} 個 ATR"
    else:
      k = 1.5
      stop = lo - k * av
      stop_why = f"進場區下緣再預留約 {k:g} 個 ATR"
  else:
    k = 1.2
    stop = lo - k * av
    stop_why = f"跌回突破價下方約 {k:g} 個 ATR"
  stop = _rt(max(stop, lo * 0.5), -1)
  if stop >= lo:
    stop = _rt(lo - av, -1)
  mid = (lo + hi) / 2
  tg: list[tuple[float, str]] = []
  for r in ress:
    if r["price"] >= mid + av and r["price"] > hi:
      tg.append((r["price"], r["kind"]))
  for p in pats:
    t = p.get("target")
    if t and p["type"] == "bullish" and p["status"] != "失效" and t >= mid + av and t > hi:
      tg.append((t, f"{p['name']}目標"))
  tg.sort()
  targets: list[tuple[float, str]] = []
  for t, why_t in tg:
    if not targets or t - targets[-1][0] >= 0.5 * av:
      targets.append((t, why_t))
    if len(targets) >= 2:
      break
  if not targets:
    targets = [(_rt(hi + 2 * av), "約 2 個 ATR 的波動空間"),
               (_rt(hi + 3.5 * av), "約 3.5 個 ATR 的波動空間")]
  elif len(targets) == 1:
    t0 = targets[0][0]
    targets.append((_rt(max(t0 + 1.5 * av, hi + 3 * av)), "延伸目標，約再 1.5 個 ATR"))
  tk = _tick(hi)
  clean: list[tuple[float, str]] = []
  for t, why_t in targets:
    t = _rt(t, 1)
    floor_t = (clean[-1][0] if clean else hi) + tk
    if t < floor_t - 1e-9:
      t = _rt(floor_t, 1)
    clean.append((t, why_t))
  targets = clean
  rr = None
  risk = mid - stop
  for t, _ in targets:
    if t > mid and risk > 0:
      rr = round((t - mid) / risk, 1)
      break
  tv = [t for t, _ in targets]
  t_txt = "、".join(f"{_fp(t)}（{w}）" for t, w in targets)
  rr_txt = ""
  if rr is not None:
    rr_txt = f"，以進場區中間價估算風險報酬比約 {rr}"
    if rr < 1:
      rr_txt += "（偏低，宜耐心等待更接近支撐的價位）"
  if sl >= 1:
    desc = (f"{bias}：可在 {_fp(lo)}–{_fp(hi)} 區間（靠近{why}）分批布局，不追高；停損設 {_fp(stop)}"
            f"（{stop_why}）；目標依序為 {t_txt}{rr_txt}。")
  elif sl == 0:
    desc = (f"{bias}：趨勢尚未表態，可在{why}附近（{_fp(lo)}–{_fp(hi)}）小量承接、接近壓力時減碼；"
            f"跌破 {_fp(stop)} 停損（{stop_why}）；上檔目標 {t_txt}{rr_txt}。")
  else:
    desc = (f"{bias}：目前趨勢偏弱，不建議提前摸底；待股價帶量站回{why}（{_fp(lo)}–{_fp(hi)}）"
            f"確認轉強再考慮，失敗跌回 {_fp(stop)} 以下應停損；目標 {t_txt}{rr_txt}。"
            "手中持股者可趁反彈至壓力區減碼。")
  desc += DISCLAIMER
  return {"bias": bias, "entry": [lo, hi], "stop": stop, "targets": tv, "rr": rr,
          "desc": desc, "_k": k}


def _risks(ctx: _Ctx, q: dict, trend: dict, levels: dict, pats: list[dict],
           tls: list[dict], sigs: list[dict], vol: dict, sl: int) -> list[str]:
  """Risk bullet list (most important first)."""
  x, i, ind, u = ctx.price, ctx.i, ctx.ind, ctx.unit
  out: list[str] = []
  r14 = ind["rsi14"][i]
  m20 = ind["ma20"][i]
  if r14 is not None and r14 >= 75:
    out.append(f"RSI(14) 達 {r14:.1f}，短線過熱，追高風險升高")
  if m20:
    bias = (x / m20 - 1) * 100
    if bias > 10:
      out.append(f"股價高於 20 {u}均線 {bias:.1f}%，乖離偏大，留意拉回修正")
    elif bias < -10:
      out.append(f"股價低於 20 {u}均線 {abs(bias):.1f}%，跌深但趨勢未止穩，勿急於摸底")
  for s in sigs:
    if s["group"] == "背離" and s["type"] == "bearish":
      out.append(f"出現{s['name']}（{ctx.fd(s['_j'])}），上漲動能減弱")
    if s["name"] == "KD死亡交叉" and "高檔" in s["desc"]:
      out.append("KD 高檔死亡交叉，短線動能轉弱")
  for tl in tls:
    if tl["broken"] and tl["kind"] == "support":
      out.append(f"已跌破上升趨勢線（約 {_ft(tl['value_now'])}），短線趨勢轉弱")
  for p in pats:
    if p["type"] == "bearish" and p["status"] in ("已跌破", "形成中", "失效"):
      lbl = _pat_label(p).replace("形成中", "成形中")
      if p.get("_reached"):
        out.append(f"{lbl}，下檔量幅目標 {_fp(p['target'])} 已達成，留意是否止跌")
        continue
      tgt = f"，型態目標約 {_fp(p['target'])}" if p.get("target") else ""
      out.append(f"{lbl}{tgt}，留意下檔風險")
  if vol["state"] == "價漲量縮":
    out.append("上漲但量能萎縮，追價力道不足，漲勢可能放緩")
  elif vol["state"] == "價跌量增":
    out.append("下跌時量能放大，賣壓沉重")
  if levels["resistances"]:
    R1 = levels["resistances"][0]
    d = (R1["price"] / x - 1) * 100
    if d <= 3:
      out.append(f"上方 {_fp(R1['price'])} 為{R1['kind']}壓力（距離 {d:.1f}%），短線可能遇壓震盪")
  if levels["supports"]:
    S1 = levels["supports"][0]
    d = (1 - S1["price"] / x) * 100
    if d >= 8:
      out.append(f"下方最近支撐 {_fp(S1['price'])} 距離 {d:.1f}%，回檔空間較大")
  else:
    out.append("下方缺乏明確支撐，回檔時跌幅可能擴大")
  ap = ctx.atr_now / x * 100 if x else 0
  if ap >= 4 and ctx.tf == "D":
    out.append(f"ATR 約為股價的 {ap:.1f}%，日波動劇烈，部位宜縮小")
  vm20 = ind["vol_ma20"][i]
  if ctx.tf == "D" and vm20 is not None and vm20 < 500:
    out.append(f"20 日均量僅約 {_fv(vm20)} 張，流動性偏低，進出可能有滑價")
  if sl <= -1:
    out.append("整體技術面偏空，反彈容易遇到解套賣壓")
  if ctx.n < ctx.P["bpy"]:
    out.append(f"資料僅 {ctx.n} 根K棒，長期趨勢判斷參考性有限")
  seen = set()
  uniq = []
  for r in out:
    if r not in seen:
      seen.add(r)
      uniq.append(r)
  uniq = uniq[:7]
  uniq.append("技術分析依據歷史價量推估，無法預測財報、法說會、國際情勢等突發消息造成的跳空風險")
  return uniq


def _summary(ctx: _Ctx, trend: dict, stance: str, sl: int, score: int, pats: list[dict],
             tls: list[dict], sigs: list[dict], vol: dict,
             cands: Sequence[tuple[str, str]] = ()) -> str:
  """One-sentence summary, e.g. 「中期多頭、短線突破箱型整理且量價配合，技術面偏多（78 分）。」"""
  lt, mt, st = trend["long"], trend["mid"], trend["short"]
  head = f"中期{mt['label']}"
  if lt["level"] != mt["level"] and abs(lt["level"]) == 2:
    head = f"長線{lt['label']}、" + head
  i = ctx.i
  good_vol = vol["state"] in ("價漲量增", "爆量")
  events: list[tuple[float, str, str]] = []
  for p in pats:
    bi = p.get("_brk")
    if (p["status"] in ("已突破", "已跌破") and bi is not None and i - bi <= 10
        and not p.get("_reached")):
      up = p["status"] == "已突破"
      if p["name"] in ("箱型突破", "箱型跌破"):
        txt = f"{p['name'][2:]}箱型整理"
      elif p["name"] in ("W底", "M頭", "頭肩底", "頭肩頂"):
        txt = f"{p['name']}{'突破' if up else '跌破'}頸線"
      else:
        txt = f"{'突破' if up else '跌破'}{p['name']}"
      if up and good_vol:
        txt += "且量價配合"
      events.append((6.0 - 0.4 * (i - bi), txt, p["type"]))
  for tl in tls:
    if tl["broken"]:
      bi = tl["_brk"] if tl.get("_brk") is not None else i
      sup = tl["kind"] == "support"
      events.append((4.0 - 0.4 * (i - bi), "跌破上升趨勢線" if sup else "突破下降趨勢線",
                     "bearish" if sup else "bullish"))
  key = ("MACD黃金交叉", "MACD死亡交叉", "KD黃金交叉", "KD死亡交叉", "創52週新高", "MACD翻紅",
         "MACD翻綠", "RSI頂背離", "RSI底背離", "MACD頂背離", "MACD底背離", "爆量")
  for sg in sigs:
    nm = sg["name"]
    if nm in key or nm.startswith(("突破60", "跌破60", "站上", "跌破", "均線黃金", "均線死亡")):
      events.append((2.0 - 0.3 * (i - sg["_j"]), nm, sg["type"]))
  for nm, tp in cands:
    if nm in ("長紅K", "長黑K", "多頭吞噬", "空頭吞噬", "晨星", "夜星"):
      events.append((2.5, f"收{nm}" if nm in ("長紅K", "長黑K") else f"出現{nm}", tp))
  if events:
    events.sort(key=lambda e: -e[0])
    _, txt, typ = events[0]
    opp = (sl >= 1 and typ == "bearish") or (sl <= -1 and typ == "bullish")
    body = f"{head}，但短線{txt}" if opp else f"{head}、短線{txt}"
  else:
    body = f"{head}、短線{st['label']}"
    if vol["state"] in ("價漲量增", "價跌量增", "價漲量縮", "價跌量縮"):
      body += f"、{vol['state']}"
  return f"{body}，技術面{stance}（{score} 分）。"


# ───────────────────────────── narrative / annotations ─────────────────────

_HORIZONS = {
  "D": ("短線（5–20 日）", "中期（20–60 日）", "長期（120–240 日）"),
  "W": ("短線（5–20 週）", "中期（20–60 週）", "長期（120 週以上）"),
  "M": ("短線（5–20 個月）", "中期（20–60 個月）", "長期（10 年以上）"),
}
_STATE_SIGNALS = {"多頭排列", "空頭排列", "均線糾結", "KD高檔鈍化", "KD低檔鈍化", "RSI超買",
                  "RSI超賣", "布林收斂", "MACD綠柱縮短", "MACD紅柱縮短"}
_MARK_TEXT = {"MACD黃金交叉": "MACD金叉", "MACD死亡交叉": "MACD死叉", "KD黃金交叉": "KD金叉",
              "KD死亡交叉": "KD死叉", "均線黃金交叉(5/20)": "5/20金叉",
              "均線死亡交叉(5/20)": "5/20死叉", "均線黃金交叉(20/60)": "20/60金叉",
              "均線死亡交叉(20/60)": "20/60死叉", "跳空上漲": "跳空↑", "跳空下跌": "跳空↓",
              "布林突破上軌": "突破上軌", "布林跌破下軌": "跌破下軌", "創52週新高": "52週新高"}


def _kterm(ctx: _Ctx, kind: str) -> str:
  """Level kind with a one-time explanation, e.g. 缺口（…）."""
  key = _KIND_GLOSS.get(kind)
  if not key:
    return kind
  tag = f"{id(_GLOSS)}:{key}"
  if tag in ctx.explained:
    return kind
  ctx.explained.add(tag)
  txt = _GLOSS[key]
  expl = txt.split("（", 1)[1][:-1] if "（" in txt else ""
  return f"{kind}（{expl}）" if expl else kind


def _dedupe(xs: list[str]) -> list[str]:
  """Removes duplicates, keeping the first occurrence."""
  seen: set[str] = set()
  return [x for x in xs if not (x in seen or seen.add(x))]


def _narrative(ctx: _Ctx, res: dict, q: dict) -> list[dict]:
  """Ordered zh-TW narrative sections (beginner friendly, specific)."""
  T = ctx.term
  x, i, ind, u, c = ctx.price, ctx.i, ctx.ind, ctx.unit, ctx.c
  tr, lv, pats, cds = res["trend"], res["levels"], res["patterns"], res["candles"]
  sigs, vol, plan = res["signals"], res["volume"], res["plan"]
  sups, ress = lv["supports"], lv["resistances"]
  S1 = sups[0] if sups else None
  R1 = ress[0] if ress else None
  secs: list[dict] = []

  # 1. 總結
  chg = _pct(x, c[i - 1])
  it = [res["summary"],
        f"截至 {ctx.d[i]}，收盤 {_fp(x)}（{_sp(chg, 2)}）；技術面評分 {res['score']} 分"
        f"（0–100 分，50 分為中性），整體判斷為「{res['stance']}」。"]
  sb: list[str] = []
  sr: list[str] = []
  bits = q["ma_bits"]
  nma = sum(1 for m in (5, 10, 20, 60, 120, 240) if ind[f"ma{m}"][i] is not None)
  if nma >= 3 and bits & 63 == (1 << nma) - 1:
    sb.append("股價站上所有均線")
  elif nma >= 3 and bits & 63 == 0:
    sr.append("股價位於所有均線之下")
  if tr["mid"]["level"] >= 1:
    sb.append(f"中期趨勢{tr['mid']['label']}")
  elif tr["mid"]["level"] <= -1:
    sr.append(f"中期趨勢{tr['mid']['label']}")
  st0 = ctx.struct[0]
  if st0 >= 1:
    sb.append("波段高低點墊高")
  elif st0 <= -1:
    sr.append("波段高低點降低")
  if vol["obv_trend"] == "上升":
    sb.append("OBV 上升（資金流入）")
  elif vol["obv_trend"] == "下降":
    sr.append("OBV 下降（資金流出）")
  if vol["state"] == "價漲量增":
    sb.append("價漲量增")
  elif vol["state"] in ("價跌量增", "價漲量縮"):
    sr.append(vol["state"])
  bulls = _dedupe([_pat_label(p) for p in pats if p["type"] == "bullish"]
                  + [s["name"] for s in sigs if s["type"] == "bullish"]
                  + [cd["name"] for cd in cds if cd["type"] == "bullish"] + sb)
  bears = _dedupe([_pat_label(p) for p in pats if p["type"] == "bearish"]
                  + [s["name"] for s in sigs if s["type"] == "bearish"]
                  + [cd["name"] for cd in cds if cd["type"] == "bearish"] + sr)
  if bulls:
    it.append("多方訊號：" + "、".join(bulls[:6]) + "。")
  if bears:
    it.append("空方訊號：" + "、".join(bears[:6]) + "。")
  if bulls and not bears and len(res["risks"]) > 1:
    it.append(f"需留意：{res['risks'][0]}。")
  elif bears and not bulls:
    pos = []
    r14 = ind["rsi14"][i]
    if r14 is not None and r14 < 35:
      pos.append(f"RSI(14) {r14:.1f} 已偏低，短線有跌深反彈機會")
    if S1:
      pos.append(f"下方 {_fp(S1['price'])} 有{S1['kind']}支撐")
    if pos:
      it.append("正面因素：" + "；".join(pos) + "。")
  if not bulls and not bears:
    it.append("近期沒有明顯的多空指標訊號，走勢以整理為主。")
  key = []
  if S1:
    key.append(f"下方{T('支撐')}看 {_fp(S1['price'])}（{S1['kind']}）")
  if R1:
    key.append(f"上方{T('壓力')}看 {_fp(R1['price'])}（{R1['kind']}）")
  if key:
    tail = ""
    if S1:
      nxt = f"下一道支撐 {_fp(sups[1]['price'])}" if len(sups) > 1 else "更低價位"
      keep = ("可維持多方格局" if res["stance_level"] >= 1 else
              "可維持區間整理" if res["stance_level"] == 0 else "才有止跌機會")
      tail += f"守住 {_fp(S1['price'])} {keep}，跌破恐回測{nxt}"
    if R1:
      if len(ress) > 1:
        up2 = f" {_fp(ress[1]['price'])}"
      else:
        up2 = f" {_fp(plan['targets'][-1])}" if plan["targets"] else ""
      tail += ("；" if tail else "") + f"有效站上 {_fp(R1['price'])} 才有機會挑戰{up2}"
    it.append("關鍵價位：" + "、".join(key) + "。" + (tail + "。" if tail else ""))
  secs.append({"title": NARRATIVE_TITLES[0], "items": it})

  # 2. 趨勢判斷
  hz = _HORIZONS[ctx.tf]
  it = [f"判斷方式：綜合{T('ma')}的位置與方向、{T('迴歸')}、{T('結構')}與趨勢強度。"]
  for name, key_ in zip(hz, ("short", "mid", "long")):
    t = tr[key_]
    it.append(f"{name}：{t['label']} — {t['reason']}。")
  adx_now = tr["adx"]
  if adx_now is not None:
    p, m = _at(ctx.pdi, i), _at(ctx.mdi, i)
    sw = {"弱": "趨勢不明顯（偏盤整）", "中": "中等強度的趨勢", "強": "趨勢明確且強勁",
          "極強": "趨勢極強"}.get(tr["strength"], tr["strength"])
    s = f"{T('ADX')}為 {adx_now:.1f}，{sw}"
    if p is not None and m is not None:
      s += (f"；{T('DI')}：+DI {p:.1f} {'高於' if p > m else '低於'} −DI {m:.1f}，"
            f"{'買方' if p > m else '賣方'}力道較強")
    it.append(s + "。")
  st, st_txt, hs, ls = ctx.struct
  if len(hs) == 2 and len(ls) == 2:
    kind_txt = "，屬多頭結構" if st >= 1 else "，屬空頭結構" if st <= -1 else ""
    it.append(f"波段結構：{st_txt}——最近兩個波段高點 {_fp(hs[0][1])}（{ctx.fd(hs[0][0])}）→ "
              f"{_fp(hs[1][1])}（{ctx.fd(hs[1][0])}），低點 {_fp(ls[0][1])}（{ctx.fd(ls[0][0])}）→ "
              f"{_fp(ls[1][1])}（{ctx.fd(ls[1][0])}）{kind_txt}。")
  for tl in res["trendlines"]:
    it.append(f"{T('趨勢線')}：{tl['desc']}。")
  secs.append({"title": NARRATIVE_TITLES[1], "items": it})

  # 3. 支撐與壓力
  it = []
  stars = lambda s: "★" * s + "☆" * (3 - s)  # noqa: E731
  if sups:
    for k, s in enumerate(sups, 1):
      it.append(f"支撐{k}：{_fp(s['price'])}（區間 {_fp(s['low'])}–{_fp(s['high'])}，"
                f"{_kterm(ctx, s['kind'])}，強度 {stars(s['strength'])}）— {s['desc']}。")
  else:
    it.append(f"下方近期沒有明確的前波{T('支撐')}，可參考均線與整數關卡。")
  if ress:
    for k, r in enumerate(ress, 1):
      it.append(f"壓力{k}：{_fp(r['price'])}（區間 {_fp(r['low'])}–{_fp(r['high'])}，"
                f"{_kterm(ctx, r['kind'])}，強度 {stars(r['strength'])}）— {r['desc']}。")
  else:
    it.append(f"上方沒有明顯的前波{T('壓力')}（股價位於近一年相對高檔），可留意整數關卡與型態量幅目標。")
  poc = lv["poc"]
  if poc.get("price") is not None:
    it.append(f"{T('成交密集區')}：{_fp(poc['price'])}，{poc['desc']}。")
  nick = {"MA5": f"5 {u}線", "MA10": f"10 {u}線", "MA20": f"20 {u}線", "MA60": f"60 {u}線",
          "MA120": f"120 {u}線", "MA240": f"240 {u}線"}
  if ctx.tf == "D":
    nick.update({"MA20": "月線", "MA60": "季線", "MA120": "半年線", "MA240": "年線"})
  def dname(dd: dict) -> str:
    nm = nick.get(dd["name"], dd["name"])
    nm = T(nm) if nm in _GLOSS else nm
    return f"{nm}{'' if nm.endswith('）') else ' '}{_fp(dd['price'])}"

  dyn_ma = [dd for dd in lv["dynamic"] if dd["name"].startswith("MA")]
  dyn_ma.sort(key=lambda dd: dd["price"])
  dsup = [dname(dd) for dd in reversed(dyn_ma) if dd["role"] == "support"]
  dres = [dname(dd) for dd in dyn_ma if dd["role"] == "resistance"]
  if dsup or dres:
    s = f"{T('ma')}動態價位："
    if dsup:
      s += "下方支撐 " + "、".join(dsup)
    if dres:
      s += ("；" if dsup else "") + "上方壓力 " + "、".join(dres)
    it.append(s + "。")
  secs.append({"title": NARRATIVE_TITLES[2], "items": it})

  # 4. 型態辨識
  it = []
  for p in pats:
    conf = f"信心 {p['confidence'] * 100:.0f}%"
    it.append(f"{T(p['name'], _PAT_GLOSS)}｜{p['status']}（{conf}）：{p['desc']}")
  if not pats:
    it.append(f"近期未出現明確的經典價格型態（如 W底、M頭、頭肩、三角形、箱型等），"
              f"目前波段結構為「{st_txt}」。")
  for cd in cds:
    it.append(f"K線：{T(cd['name'], _CANDLE_GLOSS)} — {cd['desc']}。")
  if not cds:
    o_, h_, l_ = ctx.o[i], ctx.h[i], ctx.l[i]
    rng = h_ - l_
    body = abs(x - o_)
    it.append(f"最新K棒（{ctx.fd(i)}）{'收紅' if x >= o_ else '收黑'}（{_sp(chg, 2)}），"
              f"實體約占振幅 {body / rng * 100 if rng > 0 else 0:.0f}%，無特殊K線組合。")
  secs.append({"title": NARRATIVE_TITLES[3], "items": it})

  # 5. 指標訊號
  it = []
  m5, m10, m20, m60 = (ind[f"ma{m}"][i] for m in (5, 10, 20, 60))
  if m20 is not None:
    vals = "／".join(_fp(m) for m in (m5, m10, m20, m60) if m is not None)
    pairs = ((5, m5), (10, m10), (20, m20), (60, m60))
    lbl = "／".join(str(m) for m, val in pairs if val is not None)
    s = f"均線：{lbl} {u}均線為 {vals}"
    if q["bull"]:
      s += f"，呈{T('多頭排列')}"
    elif q["bear"]:
      s += f"，呈{T('空頭排列')}"
    if q["tangle"]:
      s += f"，且{T('均線糾結')}"
    s += f"；股價與 20 {u}均線的{T('乖離')}為 {(x / m20 - 1) * 100:+.1f}%。"
    it.append(s)
  dif, dea, hist = ind["dif"][i], ind["dea"][i], ind["hist"][i]
  if hist is not None:
    hp = ind["hist"][i - 1]
    grow = hp is not None and abs(hist) > abs(hp)
    f_dif, f_dea, f_hist = _fn([dif, dea, hist])
    it.append(f"{T('MACD')}：DIF {f_dif}、DEA {f_dea}、柱狀體 {'+' if hist >= 0 else ''}{f_hist}"
              f"（{'紅柱' if hist >= 0 else '綠柱'}{'擴大' if grow else '縮小'}），DIF 位於零軸"
              f"{'之上，中期動能偏多' if dif > 0 else '之下，中期動能偏空'}。")
  kk, dd_ = ind["k"][i], ind["d"][i]
  if kk is not None:
    if kk > 80:
      zone = "位於 80 以上高檔區，短線強勢但留意過熱"
    elif kk < 20:
      zone = "位於 20 以下低檔區，短線超跌"
    else:
      zone = f"位於中間區域，K 值{'高於' if kk > dd_ else '低於'} D 值，短線{'偏多' if kk > dd_ else '偏弱'}"
    s = f"{T('KD')}：K {kk:.1f}、D {dd_:.1f}，{zone}"
    xk = _cross(ind["k"], ind["d"], i, 20)
    if xk:
      j = i - abs(xk) + 1
      s += f"；最近一次{T('黃金交叉') if xk > 0 else T('死亡交叉')}在 {ctx.fd(j)}"
    it.append(s + "。")
  r6, r14 = ind["rsi6"][i], ind["rsi14"][i]
  if r14 is not None:
    zone = ("超買區，短線漲多" if r14 >= 70 else "偏強區" if r14 >= 55 else "中性區" if r14 > 45
            else "偏弱區" if r14 > 30 else "超賣區，短線跌多")
    it.append(f"{T('RSI')}：RSI(6) {r6:.1f}、RSI(14) {r14:.1f}，屬{zone}。")
  up_, mid_, lo_ = ind["bb_up"][i], ind["bb_mid"][i], ind["bb_lo"][i]
  if up_ is not None and mid_:
    if x > up_:
      ptxt = "上軌之上（強勢但偏離大）"
    elif x > mid_:
      ptxt = "中軌與上軌之間（偏強）"
    elif x >= lo_:
      ptxt = "中軌與下軌之間（偏弱）"
    else:
      ptxt = "下軌之下（弱勢但可能超跌）"
    bw = (up_ - lo_) / mid_ * 100
    it.append(f"{T('布林')}：上軌 {_fp(up_)}、中軌 {_fp(mid_)}、下軌 {_fp(lo_)}，股價位於{ptxt}，"
              f"通道寬度 {bw:.1f}%{'，正處於收斂階段' if '布林收斂' in q['tags'] else ''}。")
  ev = [s for s in sigs if s["name"] not in _STATE_SIGNALS or s["group"] == "背離"]
  if ev:
    it.append("近期訊號：" + "；".join(f"{ctx.fd(s['_j'])} {s['name']}" for s in ev[:6]) + "。")
  for s in sigs:
    if s["group"] == "背離":
      it.append(f"{T('背離')}：{s['desc']}。")
    elif s["name"] in ("KD高檔鈍化", "KD低檔鈍化"):
      it.append(f"KD {T('鈍化')}：{s['desc']}。")
  secs.append({"title": NARRATIVE_TITLES[4], "items": it})

  # 6. 量價關係
  it = [vol["desc"], f"量價狀態：{T(vol['state'], _VOL_GLOSS)}。"]
  ob = vol["obv_trend"]
  it.append(f"{T('OBV')}近 20 {u}{ob}，"
            f"{'資金持續流入' if ob == '上升' else '資金持續流出' if ob == '下降' else '資金進出大致平衡'}"
            + ("；但股價上漲而 OBV 下降，量價背離需留意" if ob == "下降" and tr["short"]["level"] > 0 else "")
            + "。")
  ups = [ctx.v[j] for j in range(max(1, i - 9), i + 1) if c[j] > c[j - 1]]
  dns = [ctx.v[j] for j in range(max(1, i - 9), i + 1) if c[j] < c[j - 1]]
  if ups and dns:
    mu, md = _mean(ups), _mean(dns)
    judge = ("買盤較積極" if mu > md * 1.1 else "賣壓較重" if md > mu * 1.1 else "多空量能相當")
    it.append(f"近 10 {u}上漲 {len(ups)} 根、下跌 {len(dns)} 根；上漲時平均量 {_fv(mu)} 張、"
              f"下跌時 {_fv(md)} 張，{judge}。")
  elif ups or dns:
    it.append(f"近 10 {u}{'全數收漲' if ups else '全數收跌'}（{len(ups or dns)} 根），"
              f"{'買盤持續主導' if ups else '賣壓持續主導'}。")
  secs.append({"title": NARRATIVE_TITLES[5], "items": it})

  # 7. 操作參考
  it = [plan["desc"]]
  tg = " / ".join(_fp(t) for t in plan["targets"])
  rr = plan["rr"]
  it.append(f"進場參考 {_fp(plan['entry'][0])}–{_fp(plan['entry'][1])}｜停損 {_fp(plan['stop'])}｜"
            f"目標 {tg}｜{T('風險報酬比')} {rr if rr is not None else '—'}。")
  ap = ctx.atr_now / x * 100 if x else 0.0
  mid_e = (plan["entry"][0] + plan["entry"][1]) / 2
  dist = (mid_e - plan["stop"]) / ctx.av if ctx.av else 0.0
  it.append(f"{T('ATR')}約 {_fp(res['atr'])}（股價的 {ap:.1f}%），停損距離約 {dist:.1f} 個 ATR；"
            "建議以「單筆最大虧損不超過總資金 1–2%」回推部位大小。")
  cond = []
  if S1:
    cond.append(f"若收盤跌破 {_fp(S1['price'])}，代表{S1['kind']}支撐失守，應降低持股或停損")
  if R1:
    cond.append(f"若帶量站上 {_fp(R1['price'])}，可視為轉強訊號")
  if cond:
    it.append("；".join(cond) + "。")
  secs.append({"title": NARRATIVE_TITLES[6], "items": it})

  # 8. 風險提示
  it = list(res["risks"])
  it.append("本分析由程式依技術指標自動產生，僅供研究參考，不構成投資建議；投資有風險，請自行判斷。")
  secs.append({"title": NARRATIVE_TITLES[7], "items": it})
  return secs


def _marker(date: str, typ: str, text: str) -> dict:
  """Chart marker coloured by the Taiwan convention (bullish red, bearish green)."""
  if typ == "bullish":
    return {"date": date, "position": "belowBar", "shape": "arrowUp", "color": C_BULL, "text": text}
  if typ == "bearish":
    return {"date": date, "position": "aboveBar", "shape": "arrowDown", "color": C_BEAR,
            "text": text}
  return {"date": date, "position": "aboveBar", "shape": "circle", "color": C_NEUT, "text": text}


def _annotations(ctx: _Ctx, res: dict) -> dict[str, list]:
  """Chart overlays: horizontal lines, segments and markers (sorted by date)."""
  lines = []
  for s in res["levels"]["supports"]:
    lines.append({"price": s["price"], "color": C_SUP, "title": f"支撐 {_fp(s['price'])}",
                  "style": "solid" if s["strength"] >= 3 else "dashed"})
  for r in res["levels"]["resistances"]:
    lines.append({"price": r["price"], "color": C_RES, "title": f"壓力 {_fp(r['price'])}",
                  "style": "solid" if r["strength"] >= 3 else "dashed"})
  segs = []
  for tl in res["trendlines"]:
    sup = tl["kind"] == "support"
    title = "上升趨勢線" if sup else "下降趨勢線"
    if tl["broken"]:
      title += "（已跌破）" if sup else "（已突破）"
    col = C_BROKEN if tl["broken"] else (C_TL_SUP if sup else C_TL_RES)
    pts = [tl["p1"], tl["p2"], tl["end"]]
    pts = [p for k, p in enumerate(pts) if k == 0 or p[0] > pts[k - 1][0]]
    segs.append({"points": pts, "color": col, "title": title})
  for p in res["patterns"]:
    for sg in p.get("_segs", ()):
      if len(sg["points"]) >= 2:
        segs.append(sg)
  marks = []
  for s in res["signals"]:
    if s["name"] in _STATE_SIGNALS:
      continue
    marks.append(_marker(s["date"], s["type"], _MARK_TEXT.get(s["name"], s["name"])))
  for cd in res["candles"]:
    marks.append(_marker(cd["date"], cd["type"], cd["name"]))
  for p in res["patterns"]:
    b = p.get("_brk")
    if b is not None and p["status"] in ("已突破", "已跌破"):
      word = "突破" if p["status"] == "已突破" else "跌破"
      nm = p["name"] if p["name"].startswith("箱型") else f"{p['name']}{word}"
      marks.append(_marker(ctx.d[b], p["type"], nm))
  marks.sort(key=lambda m: m["date"])
  return {"lines": lines, "segments": segs, "markers": marks[-12:]}


# ───────────────────────────── entry points ─────────────────────────────

_STRICT = False  # tests set True to surface internal exceptions


def _strip(o: Any) -> Any:
  """Drops private '_' keys and maps NaN/inf to None (JSON-safe copy)."""
  if isinstance(o, dict):
    return {k: _strip(v) for k, v in o.items() if not (isinstance(k, str) and k.startswith("_"))}
  if isinstance(o, (list, tuple)):
    return [_strip(v) for v in o]
  if isinstance(o, float):
    return o if math.isfinite(o) else None
  if isinstance(o, set):
    return sorted(o)
  return o


def _ensure_tf(bs: list[tuple], tf: str) -> list[tuple]:
  """Resamples daily rows when analyze() is asked for W/M but receives daily bars."""
  if len(bs) < 3:
    return bs
  try:
    ds = [datetime.date.fromisoformat(b[0]) for b in bs[-30:]]
  except ValueError:
    return bs
  med = _median([(ds[k + 1] - ds[k]).days for k in range(len(ds) - 1)])
  if (tf == "W" and med < 4) or (tf == "M" and med < 20):
    return [tuple(r) for r in resample([list(b) for b in bs], tf)]
  return bs


def _empty_levels() -> dict[str, Any]:
  """Empty levels block with a placeholder POC."""
  return {"supports": [], "resistances": [], "dynamic": [],
          "poc": {"price": None, "desc": "資料不足"}}


def _short(bs: list[tuple], tf: str, error: bool = False) -> dict[str, Any]:
  """Valid but mostly empty analysis for short histories (or internal errors)."""
  n = len(bs)
  last = bs[-1] if bs else None
  price = last[4] if last else None
  tr_ = _true_range([b[2] for b in bs], [b[3] for b in bs], [b[4] for b in bs]) if bs else []
  a = _mean(tr_[-14:]) if len(tr_) >= 2 else None
  if n == 0:
    msg = "沒有可用的價格資料，無法進行技術分析。"
  elif error:
    msg = "技術分析計算時發生例外，暫時僅提供基本資訊，請稍後再試。"
  else:
    msg = (f"資料僅 {n} 根K棒（少於 {MIN_BARS} 根），技術指標尚未成形，"
           "無法進行完整技術分析，以下僅供參考。")
  levels = _empty_levels()
  if n >= 5 and price:
    lows = [b[3] for b in bs]
    highs = [b[2] for b in bs]
    lo, hi = min(lows), max(highs)
    jl, jh = lows.index(lo), highs.index(hi)
    if lo < price and _rt(lo, -1) < price:
      levels["supports"].append({"price": _rt(lo, -1), "low": _rt(lo, -1), "high": _rt(lo, 1),
                                 "strength": 1, "kind": "前波低點", "touches": 1,
                                 "last_date": bs[jl][0], "desc": f"近 {n} 根K棒最低價"})
    if hi > price and _rt(hi, 1) > price:
      levels["resistances"].append({"price": _rt(hi, 1), "low": _rt(hi, -1), "high": _rt(hi, 1),
                                    "strength": 1, "kind": "前波高點", "touches": 1,
                                    "last_date": bs[jh][0], "desc": f"近 {n} 根K棒最高價"})
    closes = [b[4] for b in bs]
    for m in (5, 10, 20):
      if n >= m:
        val = _mean(closes[-m:])
        levels["dynamic"].append({"name": f"MA{m}", "price": _rp(val),
                                  "role": "support" if val <= price else "resistance"})
  state = "量縮"
  if n >= 2:
    vs = [b[5] for b in bs]
    prev = _mean(vs[:-1])
    up = bs[-1][4] >= bs[-2][4]
    vol_up = prev > 0 and vs[-1] > prev
    state = ("價漲量增" if vol_up else "價漲量縮") if up else ("價跌量增" if vol_up else "價跌量縮")
  plan_desc = "資料不足，暫不提供進出場價位，建議待K棒累積後再評估。" + DISCLAIMER
  risks = ["上市（櫃）時間較短或資料不足，技術指標尚未成形，波動風險較高",
           "技術分析依據歷史價量推估，無法預測突發消息造成的跳空風險"]
  info = [msg]
  if price is not None:
    info.append(f"最新收盤 {_fp(price)}（{last[0]}）。")
  narrative = [{"title": NARRATIVE_TITLES[0], "items": info}]
  for t in NARRATIVE_TITLES[1:6]:
    narrative.append({"title": t, "items": ["資料不足，暫無判斷。"]})
  narrative.append({"title": NARRATIVE_TITLES[6], "items": [plan_desc]})
  narrative.append({"title": NARRATIVE_TITLES[7], "items": risks + [
    "本分析由程式依技術指標自動產生，僅供研究參考，不構成投資建議；投資有風險，請自行判斷。"]})
  flat = {"label": "盤整", "level": 0, "reason": "資料不足"}
  return {
    "as_of": last[0] if last else None, "tf": tf, "price": price,
    "atr": _r(a, 2 if (a or 0) < 10 else 1), "score": 50, "stance": STANCES[0],
    "stance_level": 0, "summary": msg,
    "trend": {"short": dict(flat), "mid": dict(flat), "long": dict(flat), "adx": None,
              "strength": "不明", "structure": "資料不足"},
    "levels": levels, "trendlines": [], "patterns": [], "candles": [], "signals": [],
    "volume": {"ratio5_20": None, "today_vs_ma20": None, "state": state, "obv_trend": "持平",
               "desc": "資料不足，量價分析參考性有限。"},
    "plan": {"bias": "觀望", "entry": [], "stop": None, "targets": [], "rr": None,
             "desc": plan_desc},
    "risks": risks, "narrative": narrative,
    "annotations": {"lines": [], "segments": [], "markers": []},
  }


def _analyze(bs: list[tuple], tf: str) -> dict[str, Any]:
  """Full analysis for ≥ MIN_BARS cleaned rows (may raise; see analyze())."""
  ctx = _Ctx(bs, tf)
  P = ctx.P
  q = _quick_core(ctx.o, ctx.h, ctx.l, ctx.c, ctx.v, ctx.ind, ctx.atr_now, P["bpy"],
                  P["box_min"], levels=False)
  trend = _trend(ctx)
  pats, box = _patterns(ctx)
  levels = _levels(ctx, pats, box)
  tls = _trendlines(ctx)
  cds = _candles(ctx, q)
  sigs = _signals(ctx, q)
  vol = _volume(ctx)
  score, _ = _final_score(q, trend, pats, tls, sigs)
  sl = _stance_level(score)
  stance = STANCES[sl]
  plan = _plan(ctx, sl, levels["supports"], levels["resistances"], pats)
  risks = _risks(ctx, q, trend, levels, pats, tls, sigs, vol, sl)
  summary = _summary(ctx, trend, stance, sl, score, pats, tls, sigs, vol, q["candles"])
  res: dict[str, Any] = {
    "as_of": ctx.d[-1], "tf": tf, "price": ctx.price,
    "atr": _r(ctx.atr_now, 2 if ctx.atr_now < 10 else 1),
    "score": score, "stance": stance, "stance_level": sl, "summary": summary,
    "trend": trend, "levels": levels, "trendlines": tls, "patterns": pats,
    "candles": cds, "signals": sigs, "volume": vol, "plan": plan, "risks": risks,
  }
  res["narrative"] = _narrative(ctx, res, q)
  res["annotations"] = _annotations(ctx, res)
  return _strip(res)


def analyze(bars: Sequence[Sequence[Any]], tf: str = "D") -> dict[str, Any]:
  """Full technical analysis (SPEC §4.3); every key is always present.

  `bars` should already be resampled to `tf`; daily bars passed with tf W/M
  are resampled automatically.  Never raises: short histories (< 30 bars) or
  unexpected errors return a valid, mostly empty analysis.
  """
  tf = str(tf or "D").upper()
  if tf not in _TF:
    tf = "D"
  try:
    bs = _clean_bars(bars)
    if tf != "D":
      bs = _ensure_tf(bs, tf)
  except Exception:  # pylint: disable=broad-except
    if _STRICT:
      raise
    bs = []
  if len(bs) < MIN_BARS:
    return _short(bs, tf)
  try:
    return _analyze(bs, tf)
  except Exception:  # pylint: disable=broad-except
    if _STRICT:
      raise
    return _short(bs, tf, error=True)
