"""TWSE (臺灣證券交易所, 上市) data adapters: fetch + parse into plain tuples."""
from __future__ import annotations

import re
from typing import Any

import net

RWD = 'https://www.twse.com.tw/rwd/zh'
OPENAPI = 'https://openapi.twse.com.tw/v1'


def num(s: Any) -> float | None:
  """Parses '1,234.5' / '--' / '' / 'X0.00' into float or None."""
  if s is None:
    return None
  if isinstance(s, (int, float)):
    return float(s)
  t = str(s).strip().replace(',', '')
  t = re.sub(r'<[^>]+>', '', t)
  if not t or t in ('--', '---', '-', 'N/A', '除權息', '除息', '除權'):
    return None
  t = t.lstrip('X+').strip()
  try:
    return float(t)
  except ValueError:
    m = re.search(r'-?\d+(?:\.\d+)?', t)
    return float(m.group()) if m else None


def sign_of(html_sign: str) -> int:
  """MI_INDEX 漲跌(+/-) column is HTML like <p style= color:red>+</p>."""
  t = re.sub(r'<[^>]+>', '', str(html_sign or '')).strip()
  if t.startswith('-'):
    return -1
  if t.startswith('+'):
    return 1
  return 0


def ymd(date: str) -> str:
  return date.replace('-', '')


def roc_to_iso(s: str) -> str | None:
  """'1151027' / '115/10/27' / '115年10月27日' -> '2026-10-27'."""
  t = re.sub(r'[^0-9/]', '/', str(s or '')).strip('/')
  parts = [p for p in t.split('/') if p]
  if len(parts) == 1 and len(parts[0]) in (6, 7):
    p = parts[0]
    parts = [p[:-4], p[-4:-2], p[-2:]]
  if len(parts) != 3:
    return None
  try:
    y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
  except ValueError:
    return None
  if y < 1911:
    y += 1911
  return f'{y:04d}-{m:02d}-{d:02d}'


def _find_table(tables: list[dict], key: str) -> dict | None:
  for t in tables or []:
    if key in str(t.get('title') or ''):
      return t
  return None


def parse_mi_index(js: dict, date: str) -> dict | None:
  """Parses MI_INDEX?type=ALLBUT0999 JSON into quotes, indices, stats."""
  if not js or js.get('stat') not in (None, 'OK') or not js.get('tables'):
    return None
  quotes_t = _find_table(js['tables'], '每日收盤行情')
  if not quotes_t or not quotes_t.get('data'):
    return None
  f = {k: i for i, k in enumerate(quotes_t['fields'])}
  quotes = []
  for r in quotes_t['data']:
    code = str(r[f['證券代號']]).strip()
    name = str(r[f['證券名稱']]).strip()
    close = num(r[f['收盤價']])
    vol = num(r[f['成交股數']]) or 0.0
    if close is None:
      continue
    o, h, l = num(r[f['開盤價']]), num(r[f['最高價']]), num(r[f['最低價']])
    diff = num(r[f['漲跌價差']])
    chg = None if diff is None else sign_of(r[f['漲跌(+/-)']]) * diff
    quotes.append((code, name, o or close, h or close, l or close, close,
                   round(vol / 1000.0, 3), num(r[f['成交金額']]) or 0.0,
                   int(num(r[f['成交筆數']]) or 0), chg))
  indices = []
  for t in js['tables']:
    title = str(t.get('title') or '')
    if '價格指數' not in title or not t.get('data'):
      continue
    for r in t['data']:
      close = num(r[1])
      if close is None:
        continue
      sg = sign_of(r[2])
      pts = num(r[3]) or 0.0
      pct = num(r[4]) or 0.0
      indices.append((str(r[0]).strip(), close, sg * abs(pts), sg * abs(pct)))
  stats: dict[str, Any] = {'date': date}
  st = _find_table(js['tables'], '大盤統計資訊')
  if st:
    for r in st.get('data') or []:
      label = str(r[0])
      if label.startswith('總計'):
        stats['value'] = num(r[1])
        stats['shares'] = num(r[2])
        stats['trades'] = num(r[3])
      elif label.startswith('1.一般股票'):
        stats['stock_value'] = num(r[1])
  bt = _find_table(js['tables'], '漲跌證券數合計')
  if bt:
    for r in bt.get('data') or []:
      label = str(r[0])
      cell = str(r[2] if len(r) > 2 else r[1])
      m = re.match(r'([\d,]+)(?:\(([\d,]+)\))?', cell.strip())
      if not m:
        continue
      n = int(m.group(1).replace(',', ''))
      lim = int(m.group(2).replace(',', '')) if m.group(2) else 0
      if label.startswith('上漲'):
        stats['up'], stats['limit_up'] = n, lim
      elif label.startswith('下跌'):
        stats['down'], stats['limit_down'] = n, lim
      elif label.startswith('持平'):
        stats['flat'] = n
  return {'quotes': quotes, 'indices': indices, 'stats': stats}


def daily_quotes(date: str) -> dict | None:
  js = net.fetch_json(f'{RWD}/afterTrading/MI_INDEX?date={ymd(date)}&type=ALLBUT0999&response=json')
  if js.get('date') and js['date'] != ymd(date):
    return None
  return parse_mi_index(js, date)


def parse_t86(js: dict) -> list[tuple]:
  if not js or js.get('stat') != 'OK' or not js.get('data'):
    return []
  f = {k: i for i, k in enumerate(js['fields'])}

  def col(row, *names):
    for n in names:
      if n in f:
        return num(row[f[n]]) or 0.0
    return 0.0

  out = []
  for r in js['data']:
    code = str(r[f['證券代號']]).strip()
    foreign = col(r, '外陸資買賣超股數(不含外資自營商)') + col(r, '外資自營商買賣超股數')
    trust = col(r, '投信買賣超股數')
    dealer = col(r, '自營商買賣超股數')
    total = col(r, '三大法人買賣超股數')
    out.append((code, round(foreign / 1000, 3), round(trust / 1000, 3),
                round(dealer / 1000, 3), round(total / 1000, 3)))
  return out


def inst(date: str) -> list[tuple] | None:
  js = net.fetch_json(f'{RWD}/fund/T86?date={ymd(date)}&selectType=ALLBUT0999&response=json')
  if js.get('stat') != 'OK':
    return None
  if js.get('date') and js['date'] != ymd(date):
    return None
  return parse_t86(js)


def inst_amount(date: str) -> dict | None:
  """Market-wide 三大法人買賣金額 (億元)."""
  js = net.fetch_json(f'{RWD}/fund/BFI82U?type=day&dayDate={ymd(date)}&response=json')
  if js.get('stat') != 'OK' or not js.get('data'):
    return None
  out = {'foreign': 0.0, 'trust': 0.0, 'dealer': 0.0, 'total': 0.0}
  for r in js['data']:
    label = str(r[0])
    net_amt = (num(r[3]) or 0.0) / 1e8
    if label.startswith('自營商'):
      out['dealer'] += net_amt
    elif label.startswith('投信'):
      out['trust'] += net_amt
    elif label.startswith('外資'):
      out['foreign'] += net_amt
    elif label.startswith('合計'):
      out['total'] = net_amt
  return {k: round(v, 2) for k, v in out.items()}


def valuation(date: str) -> list[tuple] | None:
  js = net.fetch_json(f'{RWD}/afterTrading/BWIBBU_d?date={ymd(date)}&selectType=ALL&response=json')
  if js.get('stat') != 'OK' or not js.get('data'):
    return None
  f = {k: i for i, k in enumerate(js['fields'])}
  out = []
  for r in js['data']:
    out.append((str(r[f['證券代號']]).strip(), num(r[f['本益比']]),
                num(r[f['股價淨值比']]), num(r[f['殖利率(%)']])))
  return out


def profiles() -> list[dict]:
  rows = net.fetch_json(f'{OPENAPI}/opendata/t187ap03_L')
  out = []
  for r in rows:
    cap = num(r.get('實收資本額'))
    out.append({
        'code': str(r.get('公司代號') or '').strip(),
        'name': str(r.get('公司簡稱') or '').strip(),
        'full_name': str(r.get('公司名稱') or '').strip(),
        'industry_code': str(r.get('產業別') or '').strip(),
        'chairman': (r.get('董事長') or '').strip(),
        'gm': (r.get('總經理') or '').strip(),
        'founded': roc_or_ad(r.get('成立日期')),
        'listed': roc_or_ad(r.get('上市日期')),
        'capital': round(cap / 1e8, 2) if cap else None,
        'shares': round(cap / 10 / 1e7, 2) if cap else None,   # 萬張 (face value 10)
        'address': (r.get('住址') or '').strip(),
        'phone': (r.get('總機電話') or '').strip(),
        'website': (r.get('網址') or '').strip(),
        'spokesman': (r.get('發言人') or '').strip(),
        'auditor': (r.get('簽證會計師事務所') or '').strip(),
    })
  return out


def roc_or_ad(s: Any) -> str | None:
  t = re.sub(r'\D', '', str(s or ''))
  if len(t) == 8:
    return f'{t[:4]}-{t[4:6]}-{t[6:]}'
  if len(t) in (6, 7):
    return roc_to_iso(t)
  return None


def margins() -> list[tuple]:
  """Latest-quarter 營益分析: (code, q, gross, operating, net)."""
  rows = net.fetch_json(f'{OPENAPI}/opendata/t187ap17_L')
  out = []
  for r in rows:
    y, s = r.get('年度'), r.get('季別')
    q = f'{int(y) + 1911}Q{int(s)}' if y and s else None
    out.append((str(r.get('公司代號') or '').strip(), q,
                num(r.get('毛利率(%)(營業毛利)/(營業收入)')),
                num(r.get('營業利益率(%)(營業利益)/(營業收入)')),
                num(r.get('稅後純益率(%)(稅後純益)/(營業收入)'))))
  return out


def dividends() -> list[tuple]:
  """(code, year, period, cash, stock, ex_date, pay_date, board_date)."""
  rows = net.fetch_json(f'{OPENAPI}/opendata/t187ap45_L')
  out = []
  for r in rows:
    code = str(r.get('公司代號') or '').strip()
    year = str(r.get('股利年度') or '').strip()
    if not code or not year:
      continue
    period = str(r.get('股利所屬年(季)度') or '年度').strip()
    if period != '年度':
      period = f'{period}{r.get("期別") or ""}'
    cash = sum(num(v) or 0.0 for k, v in r.items()
               if k.startswith('股東配發') and '現金' in k and '元/股' in k)
    stock = sum(num(v) or 0.0 for k, v in r.items()
                if k.startswith('股東配發') and ('配股' in k or '轉增資' in k) and '元/股' in k)
    try:
      yr = str(int(year) + 1911)
    except ValueError:
      yr = year
    out.append((code, yr, period, round(cash, 4), round(stock, 4), None, None,
                roc_or_ad(r.get('董事會（擬議）股利分派日'))))
  return out


def exrights(start: str, end: str) -> list[tuple]:
  """Ex-rights/dividend results in [start, end]: (code, date, kind, amount)."""
  js = net.fetch_json(f'{RWD}/exRight/TWT49U?startDate={ymd(start)}&endDate={ymd(end)}&response=json')
  if js.get('stat') != 'OK':
    return []
  f = {k: i for i, k in enumerate(js['fields'])}
  out = []
  for r in js.get('data') or []:
    out.append((str(r[f['股票代號']]).strip(), roc_to_iso(r[f['資料日期']]),
                str(r[f['權/息']]).strip(), num(r[f['權值+息值']])))
  return out


def upcoming_exrights() -> list[dict]:
  rows = net.fetch_json(f'{OPENAPI}/exchangeReport/TWT48U_ALL')
  out = []
  for r in rows:
    out.append({'code': str(r.get('Code') or '').strip(), 'date': roc_to_iso(r.get('Date')),
                'kind': r.get('Exdividend') or '', 'cash': num(r.get('CashDividend'))})
  return out


def punish() -> list[dict]:
  rows = net.fetch_json(f'{OPENAPI}/announcement/punish')
  return [{'code': str(r.get('Code') or '').strip(), 'name': r.get('Name'),
           'period': r.get('DispositionPeriod'), 'reason': r.get('ReasonsOfDisposition')}
          for r in rows if r.get('Code')]


def notice() -> list[dict]:
  rows = net.fetch_json(f'{OPENAPI}/announcement/notice')
  return [{'code': str(r.get('Code') or '').strip(), 'name': r.get('Name'),
           'info': r.get('TradingInfoForAttention')} for r in rows if r.get('Code')]


def holidays() -> set[str]:
  rows = net.fetch_json(f'{OPENAPI}/holidaySchedule/holidaySchedule')
  out = set()
  for r in rows:
    name = str(r.get('Name') or '')
    if '開始交易' in name or '最後交易' in name:
      continue
    d = roc_to_iso(r.get('Date'))
    if d:
      out.add(d)
  return out
