"""Global/US market quotes, US DST session clock, and global/domestic catalyst news."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import html
import re
from typing import Any
from zoneinfo import ZoneInfo

import net
from sources import news as news_src

TZ_TW = dt.timezone(dt.timedelta(hours=8))
TZ_ET = ZoneInfo('America/New_York')

CNYES_QUOTE_URL = 'https://ws.api.cnyes.com/ws/api/v1/quote/quotes/'
NASDAQ_EXT_URL = 'https://api.nasdaq.com/api/quote/{sym}/extended-trading?assetclass=stocks&markettype={mtype}'

# Ordered watchlists for the pre-market dashboard & TW stock correlation model.
US_WATCHLIST: list[tuple[str, str, str, str]] = [
    # (cnyes_code, symbol, zh_name, group)
    ('GI:SOX:INDEX', 'SOX', '費城半導體', 'indices'),
    ('GI:IXIC:INDEX', 'IXIC', '那斯達克', 'indices'),
    ('GI:INX:INDEX', 'SPX', '標普 500', 'indices'),
    ('GI:DJI:INDEX', 'DJI', '道瓊工業', 'indices'),
    ('USS:VIXY:STOCK', 'VIXY', 'VIX 恐慌指標', 'indices'),
    # Taiwan ADRs
    ('USS:TSM:STOCK', 'TSM', '台積電 ADR', 'adrs'),
    ('USS:ASX:STOCK', 'ASX', '日月光 ADR', 'adrs'),
    ('USS:UMC:STOCK', 'UMC', '聯電 ADR', 'adrs'),
    ('USS:CHT:STOCK', 'CHT', '中華電 ADR', 'adrs'),
    # US Tech Giants & AI / Semi Bellwethers
    ('USS:NVDA:STOCK', 'NVDA', '輝達 NVIDIA', 'tech'),
    ('USS:AAPL:STOCK', 'AAPL', '蘋果 Apple', 'tech'),
    ('USS:MSFT:STOCK', 'MSFT', '微軟 Microsoft', 'tech'),
    ('USS:GOOGL:STOCK', 'GOOGL', 'Google Alphabet', 'tech'),
    ('USS:META:STOCK', 'META', 'Meta', 'tech'),
    ('USS:AMZN:STOCK', 'AMZN', '亞馬遜 Amazon', 'tech'),
    ('USS:AVGO:STOCK', 'AVGO', '博通 Broadcom', 'tech'),
    ('USS:AMD:STOCK', 'AMD', '超微 AMD', 'tech'),
    ('USS:MU:STOCK', 'MU', '美光 Micron', 'tech'),
    ('USS:ASML:STOCK', 'ASML', '艾司摩爾 ASML', 'tech'),
    ('USS:TSLA:STOCK', 'TSLA', '特斯拉 Tesla', 'tech'),
    ('USS:SMCI:STOCK', 'SMCI', '美超微 SMCI', 'tech'),
    # Commodities, FX & Treasury Bond Proxies
    ('FX:USDTWD:FOREX', 'USDTWD', '美元／台幣', 'macro'),
    ('FX:USDJPY:FOREX', 'USDJPY', '美元／日圓', 'macro'),
    ('USS:USO:STOCK', 'USO', 'WTI 原油指標 (USO)', 'macro'),
    ('USS:BNO:STOCK', 'BNO', '布蘭特原油 (BNO)', 'macro'),
    ('USS:GLD:STOCK', 'GLD', '黃金指標 (GLD)', 'macro'),
    ('USS:TLT:STOCK', 'TLT', '20年美債 (TLT)', 'macro'),
]

EXTENDED_TICKERS = ('NVDA', 'TSM', 'AAPL', 'MSFT', 'GOOGL', 'META', 'AMZN', 'AVGO', 'AMD', 'MU', 'TSLA')

CNYES_NEWS_CATS: list[tuple[str, str]] = [
    ('us_stock', '國際'),
    ('wd_macro', '國際'),
    ('headline', '國際'),
    ('future', '國際'),
    ('forex', '國際'),
    ('tw_stock', '國內'),
]

GNEWS_TOPICS: list[tuple[str, str]] = [
    ('(戰爭 OR 中東 OR 烏俄 OR 紅海 OR 關稅 OR 制裁) (股市 OR 油價 OR 航運 OR 半導體)', '國際'),
    ('(原油 OR 油價 OR OPEC OR 黃金 OR 聯準會 OR 降息 OR 美債殖利率)', '國際'),
    ('(輝達 OR 蘋果 OR 微軟 OR Google OR Meta OR 博通 OR 美光 OR OpenAI) (財報 OR 發布 OR 晶片 OR AI)', '國際'),
    ('(川普 OR 鮑爾 OR 黃仁勳 OR 蘇姿丰 OR 魏哲家 OR 馬斯克) (談話 OR 表示 OR 關稅 OR AI OR 利率)', '國際'),
    ('(台股 OR 台積電 OR 央行 OR 電價 OR 法說會 OR 國安基金 OR 伺服器) (展望 OR 政策 OR 營收 OR 出貨)', '國內'),
]


def _nth_weekday(year: int, month: int, weekday: int, n: int) -> dt.date:
  """Returns the n-th occurrence (1-based) of `weekday` (0=Mon..6=Sun) in `year`-`month`."""
  d = dt.date(year, month, 1)
  shift = (weekday - d.weekday()) % 7
  return d + dt.timedelta(days=shift + (n - 1) * 7)


def us_session_info(now: dt.datetime | None = None) -> dict[str, Any]:
  """Computes US DST (夏令/冬令) schedule in Taiwan time and current market session state."""
  now_tw = (now or dt.datetime.now(TZ_TW)).astimezone(TZ_TW)
  et = now_tw.astimezone(TZ_ET)
  is_dst = bool(et.dst())
  yr = et.year
  dst_start = _nth_weekday(yr, 3, 6, 2)   # 2nd Sunday of March
  dst_end = _nth_weekday(yr, 11, 6, 1)    # 1st Sunday of November
  if et.date() < dst_start:
    next_sw, next_mode = dst_start, '夏令時間'
  elif et.date() < dst_end:
    next_sw, next_mode = dst_end, '冬令時間'
  else:
    next_sw, next_mode = _nth_weekday(yr + 1, 3, 6, 2), '夏令時間'
  days_to_switch = (next_sw - et.date()).days

  hm = et.hour * 60 + et.minute
  if et.weekday() >= 5:
    state, state_zh = 'closed', '週末休市（顯示最近一交易日收盤與盤後）'
  elif 4 * 60 <= hm < 9 * 60 + 30:
    state, state_zh = 'pre', '美股盤前交易中'
  elif 9 * 60 + 30 <= hm < 16 * 60:
    state, state_zh = 'regular', '美股正規開盤交易中'
  elif 16 * 60 <= hm < 20 * 60:
    state, state_zh = 'post', '美股盤後交易中（正規盤已收盤）'
  else:
    state, state_zh = 'closed', '美股已收盤（含盤後結算）'

  if is_dst:
    hours = {'season': '夏令時間 (EDT)', 'pre_tw': '16:00 ～ 21:30',
             'regular_tw': '21:30 ～ 隔日 04:00', 'post_tw': '04:00 ～ 08:00',
             'morning_check_note': '夏令時間美股 04:00 收盤、盤後至 08:00；系統於 07:45 自動彙整美股收盤＋盤後財報異動與國際新聞。'}
  else:
    hours = {'season': '冬令時間 (EST)', 'pre_tw': '17:00 ～ 22:30',
             'regular_tw': '22:30 ～ 隔日 05:00', 'post_tw': '05:00 ～ 09:00',
             'morning_check_note': '冬令時間美股 05:00 收盤、盤後至 09:00；系統於 07:45 與 08:35 自動彙整美股收盤＋盤後異動與國際新聞。'}

  return {
      'is_dst': is_dst,
      **hours,
      'state': state,
      'state_zh': state_zh,
      'et_time': et.strftime('%Y-%m-%d %H:%M ET'),
      'tw_time': now_tw.strftime('%Y-%m-%d %H:%M'),
      'next_switch_date': next_sw.isoformat(),
      'next_switch_mode': next_mode,
      'days_to_switch': days_to_switch,
      'schedules': {
          'summer': {'label': '夏令時間（3月第2個週日 ～ 11月第1個週日）',
                     'pre': '16:00 ～ 21:30', 'regular': '21:30 ～ 04:00', 'post': '04:00 ～ 08:00'},
          'winter': {'label': '冬令時間（11月第1個週日 ～ 隔年3月第2個週日）',
                     'pre': '17:00 ～ 22:30', 'regular': '22:30 ～ 05:00', 'post': '05:00 ～ 09:00'},
      },
  }


def _parse_money(s: Any) -> float | None:
  if s is None:
    return None
  t = re.sub(r'[^0-9.+-]', '', str(s))
  if not t or t in ('+', '-', '.'):
    return None
  try:
    return float(t)
  except ValueError:
    return None


def _fetch_one_ext(sym: str) -> tuple[str, dict[str, Any] | None]:
  """Fetches Nasdaq post-market latest trade price vs regular market close if available."""
  try:
    js = net.fetch_json(NASDAQ_EXT_URL.format(sym=sym, mtype='post'), timeout=8)
    data = js.get('data') or {}
    m_close = _parse_money(data.get('previousInfo'))
    rows = ((data.get('tradeDetailTable') or {}).get('rows') or [])
    if not rows or not m_close:
      return sym, None
    p_post = _parse_money(rows[0].get('price'))
    if not p_post or p_post <= 0:
      return sym, None
    chg = round(p_post - m_close, 4)
    pct = round((p_post / m_close - 1) * 100, 2)
    return sym, {'post_price': round(p_post, 2), 'post_chg': round(chg, 2), 'post_pct': pct,
                 'reg_close': round(m_close, 2)}
  except Exception:  # pylint: disable=broad-except
    return sym, None


def fetch_us_quotes(include_extended: bool = True) -> dict[str, Any]:
  """Fetches US indices, Taiwan ADRs, US tech giants, and macro/commodity proxies."""
  codes = [c[0] for c in US_WATCHLIST]
  meta_map = {c[0]: (c[1], c[2], c[3]) for c in US_WATCHLIST}
  raw_items: dict[str, dict[str, Any]] = {}
  try:
    js = net.fetch_json(CNYES_QUOTE_URL + ','.join(codes), timeout=15)
    for d in js.get('data') or []:
      cid = str(d.get('0') or d.get('800013') or '')
      if cid not in meta_map:
        continue
      sym, zh_name, grp = meta_map[cid]
      price = d.get('6')
      chg = d.get('11')
      pct = d.get('56')
      prev = d.get('21')
      if price is None and prev is not None:
        price, chg, pct = prev, 0.0, 0.0
      ts = d.get('200007')
      iso_t = (dt.datetime.fromtimestamp(int(ts), tz=dt.timezone.utc).astimezone(TZ_TW).isoformat(timespec='seconds')
               if isinstance(ts, (int, float)) and ts > 0 else None)
      raw_items[sym] = {
          'symbol': sym, 'name': zh_name, 'group': grp,
          'price': round(float(price), 3) if isinstance(price, (int, float)) else None,
          'chg': round(float(chg), 3) if isinstance(chg, (int, float)) else None,
          'pct': round(float(pct), 2) if isinstance(pct, (int, float)) else None,
          'high': round(float(d['12']), 3) if isinstance(d.get('12'), (int, float)) else None,
          'low': round(float(d['13']), 3) if isinstance(d.get('13'), (int, float)) else None,
          'prev_close': round(float(prev), 3) if isinstance(prev, (int, float)) else None,
          'time': iso_t,
          'url': d.get('800043') or f'https://www.google.com/finance/quote/{sym}',
      }
  except Exception:  # pylint: disable=broad-except
    pass

  if include_extended and raw_items:
    with ThreadPoolExecutor(max_workers=4) as ex:
      for sym, ext in ex.map(_fetch_one_ext, [s for s in EXTENDED_TICKERS if s in raw_items]):
        if ext and sym in raw_items:
          raw_items[sym]['post'] = ext

  grouped: dict[str, list[dict[str, Any]]] = {'indices': [], 'adrs': [], 'tech': [], 'macro': []}
  for _, sym, _, grp in US_WATCHLIST:
    if sym in raw_items:
      grouped[grp].append(raw_items[sym])
  return {'by_symbol': raw_items, **grouped}


def _clean_html_excerpt(raw: str, max_len: int = 160) -> str:
  text = html.unescape(raw or '')
  text = re.sub(r'<[^>]+>', ' ', text)
  text = html.unescape(text)
  text = re.sub(r'\s+', ' ', text).strip()
  return text[:max_len] + ('…' if len(text) > max_len else '')


def _fetch_cnyes_cat(cat: str, region: str, limit: int = 15) -> list[dict[str, Any]]:
  url = f'https://api.cnyes.com/media/api/v1/newslist/category/{cat}?limit={limit}'
  js = net.fetch_json(url, timeout=12)
  out = []
  for r in ((js.get('items') or {}).get('data') or [])[:limit]:
    try:
      t = dt.datetime.fromtimestamp(int(r.get('publishAt')), tz=dt.timezone.utc).astimezone(TZ_TW)
    except (TypeError, ValueError):
      continue
    title = news_src._clean_title(r.get('title', ''))  # pylint: disable=protected-access
    if not title:
      continue
    summary = _clean_html_excerpt(r.get('summary') or r.get('content') or '', 180)
    out.append({
        'title': title,
        'summary': summary,
        'link': f'https://news.cnyes.com/news/id/{r.get("newsId")}',
        'source': '鉅亨網',
        'region': region,
        'cat_raw': cat,
        'time': t.replace(microsecond=0).isoformat(),
    })
  return out


def _fetch_gnews_topic(query: str, region: str, limit: int = 10) -> list[dict[str, Any]]:
  items = news_src.google_news(query, limit=limit)
  out = []
  for it in items:
    if news_src._low_quality(it):  # pylint: disable=protected-access
      continue
    out.append({
        'title': it['title'],
        'summary': '',
        'link': it['link'],
        'source': it.get('source') or 'Google 新聞',
        'region': region,
        'cat_raw': 'gnews',
        'time': it['time'],
    })
  return out


def fetch_catalyst_news(max_age_hours: int = 48) -> list[dict[str, Any]]:
  """Fetches & deduplicates global + domestic market-moving news from the last `max_age_hours`."""
  cutoff = (dt.datetime.now(TZ_TW) - dt.timedelta(hours=max_age_hours)).isoformat()
  tasks = [(lambda c=cat, rg=reg: _fetch_cnyes_cat(c, rg, 15)) for cat, reg in CNYES_NEWS_CATS]
  tasks += [(lambda q=q, rg=reg: _fetch_gnews_topic(q, rg, 10)) for q, reg in GNEWS_TOPICS]

  merged: list[dict[str, Any]] = []
  with ThreadPoolExecutor(max_workers=4) as ex:
    futs = [ex.submit(fn) for fn in tasks]
    for f in futs:
      try:
        merged.extend(f.result())
      except Exception:  # pylint: disable=broad-except
        continue

  merged.sort(key=lambda x: x.get('time') or '', reverse=True)
  seen_keys: set[str] = set()
  out: list[dict[str, Any]] = []
  for it in merged:
    if (it.get('time') or '') < cutoff:
      continue
    norm = re.sub(r'[^\w\u4e00-\u9fff]', '', it['title'])[:26]
    if len(norm) < 6 or norm in seen_keys:
      continue
    seen_keys.add(norm)
    out.append(it)
  return out[:80]
