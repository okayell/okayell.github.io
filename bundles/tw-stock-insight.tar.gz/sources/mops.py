"""公開資訊觀測站 (mopsov.twse.com.tw) adapters: monthly revenue + quarterly EPS."""
from __future__ import annotations

import html
import re
from html.parser import HTMLParser

import net
from sources.twse import num

MOPS = 'https://mopsov.twse.com.tw'


class _TableParser(HTMLParser):
  """Collects every <table> as a list of rows of cell texts."""

  def __init__(self) -> None:
    super().__init__(convert_charrefs=True)
    self.tables: list[list[list[str]]] = []
    self._stack: list[list[list[str]]] = []
    self._row: list[str] | None = None
    self._cell: list[str] | None = None

  def handle_starttag(self, tag, attrs):
    if tag == 'table':
      self._stack.append([])
    elif tag == 'tr' and self._stack:
      self._row = []
    elif tag in ('td', 'th') and self._row is not None:
      self._cell = []
    elif tag == 'br' and self._cell is not None:
      self._cell.append(' ')

  def handle_endtag(self, tag):
    if tag in ('td', 'th') and self._cell is not None and self._row is not None:
      self._row.append(re.sub(r'\s+', ' ', ''.join(self._cell)).strip())
      self._cell = None
    elif tag == 'tr' and self._row is not None and self._stack:
      if self._row:
        self._stack[-1].append(self._row)
      self._row = None
    elif tag == 'table' and self._stack:
      self.tables.append(self._stack.pop())

  def handle_data(self, data):
    if self._cell is not None:
      self._cell.append(data)


def tables_of(doc: str) -> list[list[list[str]]]:
  p = _TableParser()
  p.feed(doc)
  return p.tables


CODE_RE = re.compile(r'^[0-9]{4}[0-9A-Z]{0,2}$')


def parse_revenue(doc: str) -> list[tuple]:
  """t21sc03 page -> (code, name, industry, rev, mom, yoy, cum_rev, cum_yoy)."""
  out = []
  # Industry headers appear before each table: 產業別：水泥工業
  pieces = re.split(r'產業別：', doc)
  for piece in pieces[1:]:
    m = re.match(r'\s*([^\s<]+)', piece)
    industry = html.unescape(m.group(1)).strip() if m else ''
    for table in tables_of(piece):
      for r in table:
        if len(r) < 10 or not CODE_RE.match(r[0]):
          continue
        out.append((r[0], r[1], industry, num(r[2]), num(r[5]), num(r[6]),
                    num(r[7]), num(r[9])))
  seen, uniq = set(), []
  for row in out:
    if row[0] not in seen:
      seen.add(row[0])
      uniq.append(row)
  return uniq


def revenue_month(market: str, year: int, month: int) -> list[tuple] | None:
  """market: 'sii' (上市) | 'otc' (上櫃); western year."""
  url = f'{MOPS}/nas/t21/{market}/t21sc03_{year - 1911}_{month}_0.html'
  try:
    doc = net.fetch_bytes(url).decode('big5', errors='replace')
  except net.FetchError as e:
    if '404' in str(e):
      return None
    raise
  rows = parse_revenue(doc)
  return rows or None


EPS_COLS = ('基本每股盈餘（元）', '基本每股盈餘(元)', '每股盈餘')
REV_COLS = ('營業收入', '收益', '淨收益', '收入', '營業收入淨額')
OP_COLS = ('營業利益（損失）', '營業利益', '營業利益(損失)')
NI_COLS = ('淨利（淨損）歸屬於母公司業主', '本期淨利（淨損）', '本期稅後淨利（淨損）',
           '本期淨利(淨損)')


def _pick(header: list[str], names: tuple[str, ...]) -> int | None:
  for n in names:
    for i, h in enumerate(header):
      if h == n:
        return i
  for n in names:
    for i, h in enumerate(header):
      if n in h:
        return i
  return None


def parse_eps(doc: str) -> list[tuple]:
  """ajax_t163sb04 page -> (code, cum_eps, cum_rev, cum_op, cum_ni) (YTD, 千元)."""
  out = {}
  for table in tables_of(doc):
    header = None
    for r in table:
      if any(c in ('公司代號', '公司 代號', '代號') for c in r):
        header = r
        continue
      if header is None or not r or not CODE_RE.match(r[0]):
        continue
      ie = _pick(header, EPS_COLS)
      if ie is None or ie >= len(r):
        continue
      ir, io, ini = _pick(header, REV_COLS), _pick(header, OP_COLS), _pick(header, NI_COLS)

      def cell(i):
        return num(r[i]) if i is not None and i < len(r) else None

      out[r[0]] = (r[0], cell(ie), cell(ir), cell(io), cell(ini))
  return list(out.values())


def eps_quarter(market: str, year: int, season: int) -> list[tuple] | None:
  data = {'encodeURIComponent': 1, 'step': 1, 'firstin': 1, 'off': 1, 'isQuery': 'Y',
          'TYPEK': market, 'year': str(year - 1911), 'season': f'{season:02d}'}
  doc = net.fetch_bytes(f'{MOPS}/mops/web/ajax_t163sb04', data=data,
                        headers={'Referer': f'{MOPS}/mops/web/t163sb04'}).decode('utf-8', errors='replace')
  if '查詢無資料' in doc or 'hasBorder' not in doc:
    return None
  rows = parse_eps(doc)
  return rows or None
