"""TPEx (證券櫃檯買賣中心, 上櫃) data adapters."""
from __future__ import annotations

from typing import Any

import net
from sources.twse import num, roc_or_ad, roc_to_iso

WWW = 'https://www.tpex.org.tw/www/zh-tw'
OPENAPI = 'https://www.tpex.org.tw/openapi/v1'


def slash(date: str) -> str:
  return date.replace('-', '/')


def parse_daily_quotes(js: dict, date: str) -> dict | None:
  if not js or str(js.get('date') or '') != date.replace('-', ''):
    return None
  quotes, managed, shares = [], set(), {}
  total_value = 0.0
  for t in js.get('tables') or []:
    if not t or not t.get('data'):
      continue
    is_managed = '管理股票' in str(t.get('title') or '')
    f = {k.replace(' ', ''): i for i, k in enumerate(t.get('fields') or [])}
    for r in t['data']:
      code = str(r[f['代號']]).strip()
      name = str(r[f['名稱']]).strip()
      close = num(r[f['收盤']])
      if close is None:
        continue
      vol = num(r[f['成交股數']]) or 0.0
      value = num(r[f['成交金額(元)']]) or 0.0
      o, h, l = num(r[f['開盤']]), num(r[f['最高']]), num(r[f['最低']])
      chg = num(r[f['漲跌']])
      quotes.append((code, name, o or close, h or close, l or close, close,
                     round(vol / 1000.0, 3), value, int(num(r[f['成交筆數']]) or 0), chg))
      if '發行股數' in f:
        sh = num(r[f['發行股數']])
        if sh:
          shares[code] = round(sh / 1e7, 3)   # 萬張
      if is_managed:
        managed.add(code)
      if len(code) == 4 and code.isdigit():
        total_value += value
  if not quotes:
    return None
  return {'quotes': quotes, 'managed': sorted(managed), 'shares': shares,
          'stats': {'date': date, 'value': total_value}}


def daily_quotes(date: str) -> dict | None:
  js = net.fetch_json(f'{WWW}/afterTrading/dailyQuotes?date={slash(date)}&type=EW&response=json')
  return parse_daily_quotes(js, date)


def parse_inst(js: dict, date: str) -> list[tuple] | None:
  if not js or str(js.get('date') or '') != date.replace('-', ''):
    return None
  tables = [t for t in js.get('tables') or [] if t and t.get('data')]
  if not tables:
    return None
  out = []
  for r in tables[0]['data']:
    if len(r) < 24:
      continue
    code = str(r[0]).strip()
    foreign = num(r[10]) or 0.0
    trust = num(r[13]) or 0.0
    dealer = num(r[22]) or 0.0
    total = num(r[23]) or 0.0
    out.append((code, round(foreign / 1000, 3), round(trust / 1000, 3),
                round(dealer / 1000, 3), round(total / 1000, 3)))
  return out


def inst(date: str) -> list[tuple] | None:
  js = net.fetch_json(f'{WWW}/insti/dailyTrade?type=Daily&sect=EW&date={slash(date)}&response=json')
  return parse_inst(js, date)


def inst_amount_latest() -> dict | None:
  rows = net.fetch_json(f'{OPENAPI}/tpex_3insti_summary')
  if not rows:
    return None
  out: dict[str, Any] = {'date': roc_to_iso(rows[0].get('Date'))}
  for r in rows:
    label = str(r.get('Investor') or '').strip()
    v = round((num(r.get('Net')) or 0.0) / 1e8, 2)
    if label == '外資及陸資合計':
      out['foreign'] = v
    elif label == '投信':
      out['trust'] = v
    elif label == '自營商合計':
      out['dealer'] = v
    elif label.startswith('合計') or label.startswith('三大法人'):
      out['total'] = v
  if 'total' not in out:
    out['total'] = round(sum(out.get(k, 0.0) for k in ('foreign', 'trust', 'dealer')), 2)
  return out


def valuation_latest() -> tuple[str | None, list[tuple]]:
  rows = net.fetch_json(f'{OPENAPI}/tpex_mainboard_peratio_analysis')
  date = roc_to_iso(rows[0].get('Date')) if rows else None
  out = [(str(r.get('SecuritiesCompanyCode') or '').strip(), num(r.get('PriceEarningRatio')),
          num(r.get('PriceBookRatio')), num(r.get('YieldRatio'))) for r in rows]
  return date, out


def profiles() -> list[dict]:
  rows = net.fetch_json(f'{OPENAPI}/mopsfin_t187ap03_O')
  out = []
  for r in rows:
    cap = num(r.get('Paidin.Capital.NTDollars'))
    issued = num(r.get('IssueShares'))
    out.append({
        'code': str(r.get('SecuritiesCompanyCode') or '').strip(),
        'name': str(r.get('CompanyAbbreviation') or '').strip(),
        'full_name': str(r.get('CompanyName') or '').strip(),
        'industry_code': str(r.get('SecuritiesIndustryCode') or '').strip(),
        'chairman': (r.get('Chairman') or '').strip(),
        'gm': (r.get('GeneralManager') or '').strip(),
        'founded': roc_or_ad(r.get('DateOfIncorporation')),
        'listed': roc_or_ad(r.get('DateOfListing')),
        'capital': round(cap / 1e8, 2) if cap else None,
        'shares': round(issued / 1e7, 3) if issued else (round(cap / 10 / 1e7, 3) if cap else None),
        'address': (r.get('Address') or '').strip(),
        'phone': (r.get('Telephone') or '').strip(),
        'website': (r.get('WebAddress') or '').strip().strip('\u3000').strip(),
        'spokesman': (r.get('Spokesman') or '').strip(),
        'auditor': (r.get('AccountingFirm') or '').strip(),
    })
  return out


def margins() -> list[tuple]:
  rows = net.fetch_json(f'{OPENAPI}/mopsfin_187ap17_O')
  out = []
  for r in rows:
    y, s = r.get('Year'), r.get('季別')
    q = f'{int(y) + 1911}Q{int(s)}' if y and s else None
    out.append((str(r.get('SecuritiesCompanyCode') or '').strip(), q,
                num(r.get('毛利率')), num(r.get('營業利益率')), num(r.get('稅後純益率'))))
  return out


def exrights(start: str, end: str) -> list[tuple]:
  """Ex-rights/dividend results in [start, end]: (code, date, kind, amount)."""
  js = net.fetch_json(f'{WWW}/bulletin/exDailyQ?startDate={slash(start)}&endDate={slash(end)}&response=json')
  tables = [t for t in js.get('tables') or [] if t and t.get('data')]
  if not tables:
    return []
  f = {k: i for i, k in enumerate(tables[0]['fields'])}
  out = []
  for r in tables[0]['data']:
    out.append((str(r[f['代號']]).strip(), roc_to_iso(r[f['除權息日期']]),
                str(r[f['權/息']]).strip(), num(r[f['權值+息值']])))
  return out


def exrights_latest() -> list[tuple]:
  rows = net.fetch_json(f'{OPENAPI}/tpex_exright_daily')
  return [(str(r.get('SecuritiesCompanyCode') or '').strip(), roc_to_iso(r.get('Date')),
           str(r.get('ExRightsDiviend') or '').strip(), num(r.get('StockDividendPlusCashDividend')))
          for r in rows]


def upcoming_exrights() -> list[dict]:
  rows = net.fetch_json(f'{OPENAPI}/tpex_exright_prepost')
  return [{'code': str(r.get('SecuritiesCompanyCode') or '').strip(),
           'date': roc_to_iso(r.get('ExRrightsExDividendDate')),
           'kind': r.get('ExRrightsExDividend') or '', 'cash': num(r.get('CashDividend'))}
          for r in rows]


def disposal() -> list[dict]:
  rows = net.fetch_json(f'{OPENAPI}/tpex_disposal_information')
  return [{'code': str(r.get('SecuritiesCompanyCode') or '').strip(), 'name': r.get('CompanyName'),
           'period': r.get('DispositionPeriod'), 'reason': r.get('DispositionReasons')}
          for r in rows if r.get('SecuritiesCompanyCode')]


def warning() -> list[dict]:
  rows = net.fetch_json(f'{OPENAPI}/tpex_trading_warning_information')
  return [{'code': str(r.get('SecuritiesCompanyCode') or '').strip(), 'name': r.get('CompanyName')}
          for r in rows if r.get('SecuritiesCompanyCode')]


def index_month(year: int | None = None, month: int | None = None) -> list[tuple]:
  """櫃買指數 daily closes for one month: (date, close, chg). Defaults to current month."""
  if year is None or month is None:
    rows = net.fetch_json(f'{OPENAPI}/tpex_index')
    out = []
    for r in rows:
      d = str(r.get('Date') or '')
      if len(d) == 8:
        out.append((f'{d[:4]}-{d[4:6]}-{d[6:]}', num(r.get('Close')), num(r.get('Change'))))
    return out
  js = net.fetch_json(f'{WWW}/indexInfo/inx?date={year}/{month:02d}/01&response=json')
  tables = [t for t in js.get('tables') or [] if t and t.get('data')]
  if not tables:
    return []
  out = []
  for r in tables[0]['data']:
    d = str(r[0]).replace('/', '-')
    if len(d) == 10:
      out.append((d, num(r[4]), num(r[5])))
  return out
