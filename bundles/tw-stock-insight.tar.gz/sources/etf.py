"""Taiwan ETF data adapters (TWSE etfDiv, ETFortune, and MIS real-time/daily NAV & AUM)."""
from __future__ import annotations

import datetime as dt
import re
from typing import Any

import net
from sources.twse import num, roc_to_iso


def _clean_issuer(raw: str) -> str:
  s = (raw or '').strip()
  for suf in ('證券投資信託股份有限公司', '投信股份有限公司', '期貨信託股份有限公司', '股份有限公司', '證券投資信託', '投信'):
    s = s.replace(suf, '')
  return s.strip()


def fetch_twse_etf_dividends(start_year: int = 2021) -> list[dict[str, Any]]:
  """Official TWSE ETF distributions (including upcoming announced ex-div & pay dates)."""
  end_y = dt.date.today().year + 1
  url = f'https://www.twse.com.tw/rwd/zh/ETF/etfDiv?startDate={start_year}0101&endDate={end_y}1231&response=json'
  js = net.fetch_json(url, timeout=25)
  out: list[dict[str, Any]] = []
  for r in js.get('data') or []:
    if len(r) < 6:
      continue
    code = str(r[0] or '').strip()
    ex_date = roc_to_iso(str(r[2] or ''))
    if not code or not ex_date:
      continue
    rec_date = roc_to_iso(str(r[3] or ''))
    pay_date = roc_to_iso(str(r[4] or ''))
    cash = num(r[5])
    yr_raw = str(r[7] if len(r) > 7 else '')
    yr = str(int(yr_raw) + 1911) if yr_raw.isdigit() and int(yr_raw) < 1911 else (ex_date[:4])
    out.append({
        'code': code,
        'name': str(r[1] or '').strip(),
        'ex_date': ex_date,
        'record_date': rec_date,
        'pay_date': pay_date,
        'cash': round(cash, 4) if cash is not None else None,
        'year': yr,
    })
  return out


def fetch_twse_etf_fortune() -> dict[str, dict[str, Any]]:
  """TWSE e添富 metadata: AUM (totalAv, 億), holders (受益人數), tracking index, issuer."""
  js = net.fetch_json('https://www.twse.com.tw/zh/ETFortune/ajaxProductsResult', timeout=20)
  out: dict[str, dict[str, Any]] = {}
  for r in js.get('data') or []:
    code = str(r.get('stockNo') or '').strip()
    if not code:
      continue
    listed_raw = str(r.get('listingDate') or '').strip().replace('.', '-')
    listed = listed_raw if re.fullmatch(r'\d{4}-\d{2}-\d{2}', listed_raw) else None
    aum = num(r.get('totalAv'))
    holders = num(r.get('holders'))
    issuer_full = str(r.get('issuer') or '').strip()
    out[code] = {
        'code': code,
        'listed': listed,
        'index_name': (str(r.get('indexName') or '').strip() or None),
        'aum': round(aum, 2) if aum is not None else None,
        'holders': int(holders) if holders is not None else None,
        'issuer_full': issuer_full or None,
        'issuer': _clean_issuer(issuer_full) or None,
    }
  return out


def fetch_mis_all_etf() -> dict[str, dict[str, Any]]:
  """TWSE/TPEx MIS all_etf.txt: covers both 上市 and 上櫃 ETFs with NAV, premium/discount & units."""
  js = net.fetch_json('https://mis.twse.com.tw/stock/data/all_etf.txt', timeout=20)
  out: dict[str, dict[str, Any]] = {}
  for val in js.values():
    if not isinstance(val, list):
      continue
    for block in val:
      if not isinstance(block, dict):
        continue
      for m in block.get('msgArray') or []:
        code = str(m.get('a') or '').strip()
        if not code:
          continue
        units = num(m.get('c'))
        unit_diff = num(m.get('d'))
        px = num(m.get('e'))
        nav = num(m.get('f'))
        prem = num(m.get('g'))
        prev_nav = num(m.get('h'))
        aum_est = round(units * nav / 1e8, 2) if (units and nav and units > 0 and nav > 0) else None
        out[code] = {
            'code': code,
            'full_name': str(m.get('b') or '').strip() or None,
            'issued_units': int(units) if units else None,
            'unit_diff': int(unit_diff) if unit_diff is not None else None,
            'mis_price': round(px, 3) if px else None,
            'nav': round(nav, 4) if nav else (round(prev_nav, 4) if prev_nav else None),
            'premium_pct': round(prem, 2) if prem is not None and abs(prem) < 50 else None,
            'aum_est': aum_est,
        }
  return out
