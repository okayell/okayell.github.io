"""Intraday bulk quote adapter for Taiwan listed (TWSE) & OTC (TPEx) securities.

During Taiwan trading hours (09:00–13:30 Asia/Taipei), TWSE `MI_INDEX` and TPEx
`dailyQuotes` only publish post-market settlement data after ~14:30. This module
fetches live intraday OHLCV quotes + TAIEX / TPEx indices in ~8–11s via Anue
(`ws.api.cnyes.com`) so scheduled intraday runs (10:30 / 12:30) can refresh the
entire war room without marking `fetch_log` (`twse_quotes` / `tpex_quotes`),
allowing official post-market runs (14:50 / 16:10) to overwrite cleanly.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import json
import math
import re
import urllib.request
from typing import Any

import config

TZ = dt.timezone(dt.timedelta(hours=8))
QUOTE_URL = 'https://ws.api.cnyes.com/ws/api/v1/quote/quotes/{symbols}?column=I'
CHUNK_SIZE = 75
TAIEX_NAME = '發行量加權股價指數'
TPEX_NAME = '櫃買指數'
_COMMON_RE = re.compile(r'^\d{4}$')


def _num(v: Any) -> float | None:
  if v is None or isinstance(v, bool):
    return None
  try:
    f = float(v)
  except (TypeError, ValueError):
    return None
  return f if math.isfinite(f) else None


def _ts_date_hm(ts: Any) -> tuple[str | None, str | None]:
  f = _num(ts)
  if not f or f <= 0:
    return None, None
  try:
    d = dt.datetime.fromtimestamp(f, TZ)
    return d.date().isoformat(), d.strftime('%H:%M')
  except (OverflowError, OSError, ValueError):
    return None, None


def parse_cnyes_quotes(
    items: list[dict[str, Any]],
    stock_meta: dict[str, tuple[str, str]],
    target_date: str,
) -> dict[str, Any] | None:
  """Parses cnyes column=I quote items for `target_date` (YYYY-MM-DD).

  Returns None if the exchange has not opened on `target_date` (e.g., holiday,
  typhoon closure, or pre-open call) or if insufficient quotes are returned.
  """
  by_sym: dict[str, dict[str, Any]] = {}
  for it in items or []:
    if isinstance(it, dict) and it.get('0'):
      by_sym[str(it['0'])] = it

  tse_it = by_sym.get('TWS:TSE01:INDEX') or {}
  otc_it = by_sym.get('TWS:OTC01:INDEX') or {}
  tse_date, tse_hm = _ts_date_hm(tse_it.get('200007'))
  otc_date, otc_hm = _ts_date_hm(otc_it.get('200007'))

  dated_today = sum(
      1 for k, it in by_sym.items()
      if k.endswith(':STOCK') and _ts_date_hm(it.get('200007'))[0] == target_date
  )
  market_open_today = (
      tse_date == target_date or otc_date == target_date or dated_today >= 100
  )
  if not market_open_today:
    return None

  quote_times = [hm for d, hm in ((tse_date, tse_hm), (otc_date, otc_hm))
                 if d == target_date and hm]
  indices: list[tuple[str, float, float, float]] = []
  for sym_it, idx_name, idx_d in (
      (tse_it, TAIEX_NAME, tse_date),
      (otc_it, TPEX_NAME, otc_date),
  ):
    c = _num(sym_it.get('6'))
    if c is None or c <= 0 or (idx_d and idx_d != target_date):
      continue
    prev = _num(sym_it.get('21'))
    chg = _num(sym_it.get('11'))
    if chg is None and prev:
      chg = round(c - prev, 2)
    pct = _num(sym_it.get('56'))
    if pct is None and chg is not None and prev:
      pct = round(chg / prev * 100.0, 2)
    indices.append((idx_name, round(c, 2), round(chg or 0.0, 2), round(pct or 0.0, 2)))

  twse_quotes: list[tuple] = []
  tpex_quotes: list[tuple] = []
  up = down = flat = limit_up = limit_down = 0
  twse_val_sum = tpex_val_sum = 0.0

  for sym, it in by_sym.items():
    if not (sym.startswith('TWS:') and sym.endswith(':STOCK')):
      continue
    code = str(it.get('200010') or sym.split(':')[1]).strip()
    if not code:
      continue
    it_date, it_hm = _ts_date_hm(it.get('200007'))
    if it_date and it_date != target_date:
      continue
    if it_date == target_date and it_hm:
      quote_times.append(it_hm)
    c = _num(it.get('6'))
    vol = _num(it.get('200013'))
    if c is None or c <= 0:
      continue
    if it_date is None and (vol is None or vol <= 0):
      continue
    prev = _num(it.get('21'))
    chg = _num(it.get('11'))
    if chg is None and prev:
      chg = round(c - prev, 4)
    pct = _num(it.get('56'))
    if pct is None and chg is not None and prev:
      pct = chg / prev * 100.0
    o = _num(it.get('19')) or c
    h = _num(it.get('12')) or max(o, c)
    l = _num(it.get('13')) or min(o, c)
    h = max(h, o, c)
    l = min(l, o, c)
    vol_lots = round(float(vol or 0.0), 3)
    val_ntd = float(_num(it.get('200067')) or round(c * vol_lots * 1000.0, 0))

    meta = stock_meta.get(code)
    name = (meta[0] if meta and meta[0] else str(it.get('200009') or '').strip()) or code
    mkt = meta[1] if meta and meta[1] in ('上市', '上櫃') else '上市'
    row = (code, name, o, h, l, c, vol_lots, val_ntd, 0, chg)
    if mkt == '上櫃':
      tpex_quotes.append(row)
      tpex_val_sum += val_ntd
    else:
      twse_quotes.append(row)
      twse_val_sum += val_ntd
      if _COMMON_RE.match(code) and not name.endswith('-DR'):
        if (chg or 0) > 0:
          up += 1
          if (pct or 0) >= 9.5:
            limit_up += 1
        elif (chg or 0) < 0:
          down += 1
          if (pct or 0) <= -9.5:
            limit_down += 1
        else:
          flat += 1

  if len(twse_quotes) + len(tpex_quotes) < 100:
    return None

  tse_val = _num(tse_it.get('200067')) if tse_date == target_date else None
  otc_val = _num(otc_it.get('200067')) if otc_date == target_date else None
  return {
      'date': target_date,
      'quote_time': max(quote_times) if quote_times else dt.datetime.now(TZ).strftime('%H:%M'),
      'twse_quotes': twse_quotes,
      'tpex_quotes': tpex_quotes,
      'indices': indices,
      'stats': {
          'twse_value': tse_val if (tse_val and tse_val > 0) else twse_val_sum,
          'tpex_value': otc_val if (otc_val and otc_val > 0) else tpex_val_sum,
          'up': up,
          'down': down,
          'flat': flat,
          'limit_up': limit_up,
          'limit_down': limit_down,
      },
  }


def _fetch_chunk(syms: list[str]) -> list[dict[str, Any]]:
  url = QUOTE_URL.format(symbols=','.join(syms))
  hdrs = {
      'User-Agent': config.USER_AGENT,
      'Accept': 'application/json',
      'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.6',
  }
  last_err: Exception | None = None
  for attempt in range(2):
    try:
      req = urllib.request.Request(url, headers=hdrs)
      with urllib.request.urlopen(req, timeout=10.0) as resp:
        payload = json.loads(resp.read().decode('utf-8', errors='replace'))
      data = payload.get('data') if isinstance(payload, dict) else None
      if isinstance(data, list):
        return data
      if isinstance(data, dict) and isinstance(data.get('items'), list):
        return data['items']
      return []
    except Exception as e:  # pylint: disable=broad-except
      last_err = e
      if attempt == 0:
        import time  # pylint: disable=import-outside-toplevel
        time.sleep(0.5)
  if last_err:
    return []
  return []


def fetch_intraday_snapshot(
    stock_meta: dict[str, tuple[str, str]],
    target_date: str,
) -> dict[str, Any] | None:
  """Fetches intraday quotes for all `stock_meta` codes + TAIEX / TPEx indices."""
  codes = sorted(stock_meta.keys())
  if not codes:
    return None
  syms = ['TWS:TSE01:INDEX', 'TWS:OTC01:INDEX'] + [f'TWS:{c}:STOCK' for c in codes]
  chunks = [syms[i:i + CHUNK_SIZE] for i in range(0, len(syms), CHUNK_SIZE)]
  items: list[dict[str, Any]] = []
  with ThreadPoolExecutor(max_workers=3) as ex:
    for part in ex.map(_fetch_chunk, chunks):
      if part:
        items.extend(part)
  return parse_cnyes_quotes(items, stock_meta, target_date)
