"""Industry-chain (產業鏈 上/中/下游) scraper for 櫃買中心 產業價值鏈資訊平台.

Source pages: ``https://ic.tpex.org.tw/introduce.php?ic=<ID>`` (UTF-8 HTML).
Output: ``data/industry_chains.json`` with the schema of SPEC.md section 5.

* `list_chains`, `parse_chain` and `build_by_code` are pure functions (no I/O).
* `fetch_all` downloads every chain politely (browser User-Agent, at most one
  request per second, retries with exponential backoff), caches the raw HTML
  under ``data/raw/ic/<ID>.html`` and writes the JSON atomically.

Page anatomy (as of 2026):
* ``#ic_option`` dropdown: the list of chains.
* ``#main_ic_panel``: ``.chain`` blocks (one per stream, titled by
  ``.chain-title-panel`` such as 上游/中游/下游) holding segment boxes
  ``#ic_link_<SEG>``; a few chains are flat (boxes without blocks) and some
  boxes are text-only placeholders (``.company-chain-panel-blank``).
* ``#companyList_<SEG>``: per-segment company tables; segments with
  sub-categories list them as ``#sc_link_<SUB>`` with tables
  ``#sc_company_<SUB>``. Every list appears twice (again inside
  ``<noscript>``); the first copy wins.
* ``#intro-content``: free-form paragraphs (chain overview, per-stream
  sections such as 「一、上游：」, recent trends). They carry no ids, so they
  are attributed with heading / segment-name heuristics (`_assign_text`).

Standard library only.
"""
from __future__ import annotations

import argparse
import gzip
import html as html_lib
import json
import logging
import os
import re
import sys
import tempfile
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from typing import Any, Callable, Iterator

log = logging.getLogger(__name__)

SOURCE_NAME = '櫃買中心 產業價值鏈資訊平台'
SOURCE_URL = 'https://ic.tpex.org.tw/'
CHAIN_URL = SOURCE_URL + 'introduce.php?ic={id}'
USER_AGENT = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36')
FIRST_CHAIN = 'D000'  # Every chain page carries the full `#ic_option` list.

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.environ.get('TW_STOCK_DATA_DIR',
                          os.path.join(PROJECT_DIR, 'data'))
DEFAULT_OUT = os.path.join(DATA_DIR, 'industry_chains.json')
RAW_DIR = os.path.join(DATA_DIR, 'raw', 'ic')

TPE = timezone(timedelta(hours=8))

FLAT_STREAM = '次產業'      # Stream name for chains without 上/中/下游 blocks.
ORPHAN_STREAM = '其他'      # Boxes / lists found outside every block.
GROUP_ORDER = ('本國上市公司', '外國上市公司', '本國上櫃公司', '外國上櫃公司',
               '本國興櫃公司', '外國興櫃公司', '創櫃公司', '知名外國企業')

# --------------------------------------------------------------------------
# Text helpers
# --------------------------------------------------------------------------

# Zero-width / BOM / soft-hyphen / bidi control characters.
_INVISIBLE_RE = re.compile('[\u00ad\u180e\u200b-\u200f\u202a-\u202e'
                           '\u2060-\u2064\ufeff]')
_WS_RE = re.compile(r'\s+')
_ASCII_END_RE = re.compile(r'[A-Za-z0-9]$')
_ASCII_START_RE = re.compile(r'^[A-Za-z0-9]')


def clean_text(text: str | None) -> str:
  """Normalises scraped text: entities, nbsp, zero-width chars, whitespace."""
  if not text:
    return ''
  if '&' in text:
    text = html_lib.unescape(text)
  text = text.replace('\xa0', ' ').replace('\u3000', ' ')
  return _WS_RE.sub(' ', _INVISIBLE_RE.sub('', text)).strip()


def _join_parts(parts: list[str]) -> str:
  """Joins `<br/>`-separated label parts ("IP設計", "/IC設計" -> "IP設計/IC設計")."""
  out = ''
  for part in (clean_text(p) for p in parts):
    if not part:
      continue
    if out and _ASCII_END_RE.search(out) and _ASCII_START_RE.search(part):
      out += ' '
    out += part
  return out


def _has_word(text: str) -> bool:
  """True when `text` holds at least one CJK character or ASCII letter/digit."""
  return bool(re.search(r'[\u3400-\u9fffA-Za-z0-9]', text))


# --------------------------------------------------------------------------
# Minimal tolerant DOM (html.parser based)
# --------------------------------------------------------------------------

_VOID = frozenset('area base br col embed hr img input keygen link meta param '
                  'source track wbr'.split())
_P_CLOSERS = frozenset('address article aside blockquote center details dialog '
                       'dir div dl fieldset figcaption figure footer form h1 h2 '
                       'h3 h4 h5 h6 header hgroup hr main menu nav ol p pre '
                       'section table ul'.split())
_SCOPE = frozenset('applet button caption html marquee object table td template '
                   'th'.split())
_SKIP_TEXT = frozenset({'script', 'style', 'template'})


class _Node:
  """A DOM element: tag, attributes, children (elements or text strings)."""

  __slots__ = ('tag', 'attrs', 'children', 'parent')

  def __init__(self, tag: str, attrs: dict[str, str],
               parent: _Node | None) -> None:
    self.tag = tag
    self.attrs = attrs
    self.children: list[_Node | str] = []
    self.parent = parent

  @property
  def id(self) -> str:
    return self.attrs.get('id', '')

  def classes(self) -> list[str]:
    return self.attrs.get('class', '').split()

  def has_class(self, name: str) -> bool:
    return name in self.classes()

  def iter(self) -> Iterator[_Node]:
    """Yields all descendant elements in document order."""
    stack = [c for c in reversed(self.children) if isinstance(c, _Node)]
    while stack:
      node = stack.pop()
      yield node
      stack.extend(c for c in reversed(node.children) if isinstance(c, _Node))

  def ancestors(self) -> Iterator[_Node]:
    node = self.parent
    while node is not None:
      yield node
      node = node.parent

  def in_tag(self, tag: str) -> bool:
    return any(a.tag == tag for a in self.ancestors())

  def text_parts(self) -> list[str]:
    """Raw text split at `<br>` boundaries (script/style skipped)."""
    parts = ['']

    def walk(node: _Node) -> None:
      for child in node.children:
        if isinstance(child, str):
          parts[-1] += child
        elif child.tag == 'br':
          parts.append('')
        elif child.tag not in _SKIP_TEXT:
          walk(child)

    walk(self)
    return parts

  def text(self) -> str:
    return clean_text(' '.join(self.text_parts()))


class _TreeBuilder(HTMLParser):
  """Builds a `_Node` tree, applying the common implicit end-tag rules."""

  def __init__(self) -> None:
    super().__init__(convert_charrefs=True)
    self.root = _Node('#root', {}, None)
    self.cur = self.root

  def _close_open(self, tags: frozenset[str], boundary: frozenset[str]) -> None:
    node: _Node | None = self.cur
    while node is not None and node is not self.root:
      if node.tag in tags:
        self.cur = node.parent or self.root
        return
      if node.tag in boundary:
        return
      node = node.parent

  def handle_starttag(self, tag: str,
                      attrs: list[tuple[str, str | None]]) -> None:
    if tag in _P_CLOSERS:
      self._close_open(frozenset({'p'}), _SCOPE)
    if tag == 'li':
      self._close_open(frozenset({'li'}), frozenset({'ul', 'ol', 'table'}))
    elif tag in ('dt', 'dd'):
      self._close_open(frozenset({'dt', 'dd'}), frozenset({'dl', 'table'}))
    elif tag in ('td', 'th'):
      self._close_open(frozenset({'td', 'th'}), frozenset({'tr', 'table'}))
    elif tag == 'tr':
      self._close_open(frozenset({'tr'}),
                       frozenset({'table', 'tbody', 'thead', 'tfoot'}))
    elif tag == 'option':
      self._close_open(frozenset({'option'}), frozenset({'select', 'datalist'}))
    node = _Node(tag, {k: v or '' for k, v in attrs}, self.cur)
    self.cur.children.append(node)
    if tag not in _VOID:
      self.cur = node

  def handle_startendtag(self, tag: str,
                         attrs: list[tuple[str, str | None]]) -> None:
    self.cur.children.append(
        _Node(tag, {k: v or '' for k, v in attrs}, self.cur))

  def handle_endtag(self, tag: str) -> None:
    if tag in _VOID:
      return
    node: _Node | None = self.cur
    while node is not None and node is not self.root:
      if node.tag == tag:
        self.cur = node.parent or self.root
        return
      node = node.parent
    # Stray end tag: ignored.

  def handle_data(self, data: str) -> None:
    self.cur.children.append(data)


def _parse_html(html: str) -> _Node:
  builder = _TreeBuilder()
  builder.feed(html)
  builder.close()
  return builder.root


def _by_id(root: _Node, node_id: str) -> _Node | None:
  return next((n for n in root.iter() if n.attrs.get('id') == node_id), None)


def _direct_child(node: _Node, tags: tuple[str, ...]) -> _Node | None:
  return next((c for c in node.children
               if isinstance(c, _Node) and c.tag in tags), None)


# --------------------------------------------------------------------------
# Chain list
# --------------------------------------------------------------------------


def _chain_options(root: _Node) -> list[tuple[str, str]]:
  select = _by_id(root, 'ic_option')
  out: list[tuple[str, str]] = []
  if select is None:
    return out
  seen: set[str] = set()
  for opt in select.iter():
    if opt.tag != 'option':
      continue
    cid = clean_text(opt.attrs.get('value'))
    name = opt.text()
    if cid and name and cid not in seen:
      seen.add(cid)
      out.append((cid, name))
  return out


def list_chains(html: str) -> list[tuple[str, str]]:
  """Returns `[(chain_id, chain_name), ...]` from the `#ic_option` dropdown."""
  return _chain_options(_parse_html(html))


# --------------------------------------------------------------------------
# Chain diagram: streams and segment boxes
# --------------------------------------------------------------------------

_STREAM_WORDS = ('上游', '中游', '下游')


def _block_title(block: _Node) -> tuple[str, str]:
  """Returns `(name, caption)` of a `.chain` block, e.g. ("上游", "發電")."""
  panel = next((n for n in block.iter() if n.has_class('chain-title-panel')),
               None)
  name = caption = ''
  if panel is not None:
    word = next((n for n in panel.iter()
                 if any(c.startswith('chain-title-') for c in n.classes())),
                None)
    head = next((n for n in panel.iter()
                 if n.tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6')), None)
    caption = head.text() if head is not None else ''
    name = word.text() if word is not None else panel.text()
    if caption and name.endswith(caption) and name != caption:
      name = name[:-len(caption)].strip()
  if not caption:
    head = _direct_child(block, ('h3', 'h4', 'h5'))
    caption = head.text() if head is not None else ''
  return name, caption


def _is_blank_box(node: _Node) -> bool:
  return any(c.startswith('company-chain-panel') and c.endswith('blank')
             for c in node.classes())


def _parse_panel(root: _Node, chain_id: str
                 ) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
  """Returns `(streams, boxes)` from `#main_ic_panel` in page order.

  `streams`: `[{"name", "caption", "desc": [], "segments": [ids]}]`.
  `boxes`: `{seg_id: {"name": str, "placeholder": bool}}`.
  """
  panel = _by_id(root, 'main_ic_panel')
  streams: list[dict[str, Any]] = []
  boxes: dict[str, dict[str, Any]] = {}
  if panel is None:
    return streams, boxes
  seen_nodes: set[int] = set()

  def collect(container: _Node, stream: dict[str, Any]) -> None:
    for node in container.iter():
      if id(node) in seen_nodes:
        continue
      if node.id.startswith('ic_link_'):
        seen_nodes.add(id(node))
        sid = clean_text(node.id[len('ic_link_'):])
        if sid and sid not in boxes:
          boxes[sid] = {'name': _join_parts(node.text_parts()) or sid,
                        'placeholder': False}
          stream['segments'].append(sid)
      elif _is_blank_box(node):
        seen_nodes.add(id(node))
        label = _join_parts(node.text_parts())
        if _has_word(label):
          sid = f'{chain_id}-X{sum(b["placeholder"] for b in boxes.values()) + 1}'
          boxes[sid] = {'name': label, 'placeholder': True}
          stream['segments'].append(sid)

  blocks = [n for n in panel.iter() if n.has_class('chain')]
  blocks = [b for b in blocks
            if not any(a.has_class('chain') for a in b.ancestors())]
  for block in blocks:
    name, caption = _block_title(block)
    stream = {'name': name, 'caption': caption, 'desc': [], 'segments': []}
    collect(block, stream)
    streams.append(stream)
  rest = {'name': FLAT_STREAM if not streams else ORPHAN_STREAM, 'caption': '',
          'desc': [], 'segments': []}
  collect(panel, rest)
  if rest['segments']:
    streams.append(rest)
  # Untitled blocks get positional names (上游/中游/下游 for three blocks).
  missing = [s for s in streams if not s['name']]
  if missing:
    n = len(streams)
    for i, stream in enumerate(streams):
      if stream['name']:
        continue
      if n == 3:
        stream['name'] = _STREAM_WORDS[i]
      elif n == 2:
        stream['name'] = ('上游', '下游')[i]
      else:
        stream['name'] = f'第{i + 1}層'
  return streams, boxes


# --------------------------------------------------------------------------
# Company lists
# --------------------------------------------------------------------------

_GROUP_RE = re.compile(r'^(.*?)\s*[（(]\s*(\d+)\s*家\s*[)）]$')
_GROUP_WORD_RE = re.compile(r'^(?:本國|外國|知名|創櫃|興櫃|上市|上櫃).{0,8}'
                            r'(?:公司|企業|機構)$')
_STK_RE = re.compile(r'stk_code=([0-9A-Za-z]+)')
_CODE_RE = re.compile(r'^[0-9]{4,6}[A-Z]?$')
_SUB_NAME_RE = re.compile(r'^[\s►▶▸▷•·\-]*(.*?)\s*(?:[（(]\s*\d+\s*家\s*[)）])?$')


def _company_list_nodes(root: _Node) -> dict[str, _Node]:
  """Maps segment id -> its `#companyList_<SEG>` (first non-noscript copy)."""
  found: dict[str, _Node] = {}
  for node in root.iter():
    if not node.id.startswith('companyList_'):
      continue
    sid = clean_text(node.id[len('companyList_'):])
    if not sid:
      continue
    if sid not in found or (found[sid].in_tag('noscript')
                            and not node.in_tag('noscript')):
      found[sid] = node
  return found


def _company_from_link(link: _Node) -> dict[str, Any] | None:
  href = link.attrs.get('href', '')
  if href.startswith(('javascript:', '#')):
    return None
  name = link.text() or clean_text(link.attrs.get('title'))
  if not name:
    return None
  m = _STK_RE.search(href)
  code = m.group(1).upper() if m else None
  if code and not _CODE_RE.match(code):
    code = None
  return {'code': code, 'name': name}


def _group_label(text: str) -> tuple[str, int | None]:
  """("本國上市公司", 6) for 「本國上市公司(6家)」; ("", None) if not a header."""
  m = _GROUP_RE.match(text)
  if m:
    return clean_text(m.group(1)), int(m.group(2))
  return (text, None) if _GROUP_WORD_RE.match(text) else ('', None)


def _parse_groups(container: _Node, counts: dict[str, list[int]] | None = None
                  ) -> list[dict[str, Any]]:
  """Parses `<b>本國上市公司(6家)</b>` headers and company cells in order.

  Company cells are `td.company` (a link, or plain text for some foreign
  firms); without such cells every `<a>` is taken. `counts`, when given,
  receives `label -> [declared, entries seen]` so callers can detect markup
  drift (duplicates are still removed from the output).
  """
  units: list[tuple[str, Any]] = []
  cells = [n for n in container.iter()
           if n.tag in ('td', 'th') and n.has_class('company')]
  if cells:
    for cell in cells:
      head = next((b for b in cell.iter() if b.tag in ('b', 'strong')), None)
      if head is not None and _group_label(head.text())[0]:
        units.append(('group', _group_label(head.text())))
        continue
      links = [a for a in cell.iter() if a.tag == 'a']
      if links:
        units.extend(('company', _company_from_link(a)) for a in links)
      elif _has_word(cell.text()):
        units.append(('company', {'code': None, 'name': cell.text()}))
  else:
    for node in container.iter():
      if node.tag in ('b', 'strong') and _group_label(node.text())[0]:
        units.append(('group', _group_label(node.text())))
      elif node.tag == 'a':
        units.append(('company', _company_from_link(node)))
  groups: list[dict[str, Any]] = []
  by_label: dict[str, dict[str, Any]] = {}
  cur: dict[str, Any] | None = None
  for kind, value in units:
    if kind == 'group':
      label, declared = value
      if label not in by_label:
        by_label[label] = {'label': label, 'companies': []}
        groups.append(by_label[label])
      cur = by_label[label]
      if declared is not None and counts is not None:
        counts.setdefault(label, [0, 0])[0] += declared
      continue
    if value is None:
      continue
    if cur is None:
      cur = by_label.setdefault('其他', {'label': '其他', 'companies': []})
      groups.append(cur)
    if counts is not None:
      counts.setdefault(cur['label'], [0, 0])[1] += 1
    if value not in cur['companies']:
      cur['companies'].append(value)
  return groups


def _group_rank(label: str) -> int:
  return GROUP_ORDER.index(label) if label in GROUP_ORDER else len(GROUP_ORDER)


def _merge_groups(group_lists: list[list[dict[str, Any]]]
                  ) -> list[dict[str, Any]]:
  """Union of several group lists (deduped; listed companies sorted by code)."""
  merged: dict[str, list[dict[str, Any]]] = {}
  for groups in group_lists:
    for group in groups:
      bucket = merged.setdefault(group['label'], [])
      for company in group['companies']:
        if company not in bucket:
          bucket.append(company)
  first = {label: i for i, label in enumerate(merged)}
  out = []
  for label in sorted(merged, key=lambda lb: (_group_rank(lb), first[lb])):
    coded = sorted((c for c in merged[label] if c['code']),
                   key=lambda c: c['code'])
    named = [c for c in merged[label] if not c['code']]
    out.append({'label': label, 'companies': coded + named})
  return out


def _preceding_bold(node: _Node) -> str:
  """Text of the `<b>` right before `node` among its siblings (noscript copy)."""
  parent = node.parent
  if parent is None:
    return ''
  prev = None
  for child in parent.children:
    if child is node:
      break
    if isinstance(child, _Node):
      prev = child
  return prev.text() if prev is not None and prev.tag in ('b', 'strong') else ''


def _parse_company_list(node: _Node, seg_id: str
                        ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
  """Returns `(groups, subs)` of one `#companyList_<SEG>` element."""
  tables: dict[str, _Node] = {}
  for n in node.iter():
    if n.tag == 'table' and n.id.startswith('sc_company_'):
      tables.setdefault(clean_text(n.id[len('sc_company_'):]), n)
  if not tables:
    counts: dict[str, list[int]] = {}
    groups = _parse_groups(node, counts)
    _check_counts(seg_id, counts)
    return groups, []
  names: dict[str, str] = {}
  for n in node.iter():
    if n.id.startswith('sc_link_'):
      sub_id = clean_text(n.id[len('sc_link_'):])
      m = _SUB_NAME_RE.match(n.text())
      if sub_id and sub_id not in names:
        names[sub_id] = clean_text(m.group(1) if m else n.text())
  subs = []
  for sub_id in list(names) + [s for s in tables if s not in names]:
    table = tables.get(sub_id)
    counts = {}
    groups = _parse_groups(table, counts) if table is not None else []
    _check_counts(f'{seg_id}/{sub_id}', counts)
    name = names.get(sub_id) or (
        _preceding_bold(table) if table is not None else '') or sub_id
    subs.append({'id': sub_id, 'name': name, 'groups': groups})
  return _merge_groups([s['groups'] for s in subs]), subs


def _check_counts(where: str, counts: dict[str, list[int]]) -> None:
  """Logs groups whose link count differs from the page's 「(N家)」 header."""
  for label, (declared, seen) in counts.items():
    if declared and declared != seen:
      log.warning('%s %s: %d links, page says %d', where, label, seen, declared)


# --------------------------------------------------------------------------
# Intro / description text
# --------------------------------------------------------------------------

_BLOCK_TAGS = frozenset('address article aside blockquote center dd div dl dt '
                        'figcaption figure footer form h1 h2 h3 h4 h5 h6 header '
                        'hr li main nav ol p pre section table tbody td tfoot '
                        'th thead tr ul'.split())
_INDENT_RE = re.compile(r'(?:margin|padding)-left\s*:\s*(\d+(?:\.\d+)?)\s*'
                        r'(px|em|rem|pt)?', re.I)
_ORD_TOP_RE = re.compile(r'^(?:[一二三四五六七八九十]{1,3}\s*[、.．]|'
                         r'\d{1,2}\s*[、.．](?!\d))\s*')
_ORD_ANY_RE = re.compile(r'^(?:[一二三四五六七八九十]{1,3}\s*[、.．]|'
                         r'\d{1,2}\s*[、.．)）](?!\d)|'
                         r'[(（]\s*(?:[一二三四五六七八九十]{1,3}|\d{1,2})\s*[)）]|'
                         r'[A-Za-z]\s*[.、)）](?![A-Za-z]))\s*')
_TRAIL_RE = re.compile(r'[\s：:。．.，,、;；]+$')
_YEAR_RE = re.compile(r'(?<![\d.])(20\d\d)\s*(?:年|上半|下半|[Qq][1-4]|H[12])')
_ROC_YEAR_RE = re.compile(r'(?<![\d.])(1[01]\d)\s*年')
_TREND_HEAD_RE = re.compile(r'趨勢|展望|前景|機會與挑戰|發展現況|近況|動態|未來發展')
_FILLER_RE = re.compile(r'^(?:目前|現今|當前|國內|我國|另外|此外|其中|至於|而|另)+')
_HEADING_MAX = 30


def _indent_of(node: _Node) -> int:
  m = _INDENT_RE.search(node.attrs.get('style', ''))
  if not m:
    return 40 if node.tag == 'blockquote' else 0
  scale = {'em': 16.0, 'rem': 16.0, 'pt': 4 / 3}.get((m.group(2) or '').lower(),
                                                     1.0)
  return int(float(m.group(1)) * scale)


def _intro_paragraphs(root: _Node) -> list[dict[str, Any]]:
  """Splits `#intro-content` into paragraphs `{"text", "indent", "bold"}`."""
  container = _by_id(root, 'intro-content')
  if container is None:
    return []
  tokens: list[tuple[str, int, bool] | None] = []  # None = paragraph break.

  def flatten(node: _Node, indent: int, bold: bool) -> None:
    for child in node.children:
      if isinstance(child, str):
        tokens.append((child, indent, bold))
      elif child.tag in ('br', 'hr'):
        tokens.append(None)
      elif child.tag not in _SKIP_TEXT:
        block = child.tag in _BLOCK_TAGS
        if block:
          tokens.append(None)
        flatten(child, indent + _indent_of(child) if block else indent,
                bold or child.tag in ('b', 'strong'))
        if block:
          tokens.append(None)

  flatten(container, 0, False)
  paras: list[dict[str, Any]] = []
  run: list[tuple[str, int, bool]] = []
  for tok in tokens + [None]:
    if tok is not None:
      run.append(tok)
      continue
    text = clean_text(''.join(t for t, _, _ in run))
    if text:
      total = sum(len(t.strip()) for t, _, _ in run) or 1
      bold = sum(len(t.strip()) for t, _, b in run if b)
      indent = next((i for t, i, _ in run if t.strip()), run[0][1])
      paras.append({'text': text, 'indent': indent, 'bold': bold >= 0.9 * total})
    run = []
  return paras


def _norm(text: str) -> str:
  return re.sub(r'[^\w]', '', text.lower())


def _bigrams(text: str) -> set[str]:
  out: set[str] = set()
  for tok in re.sub(r'[^\w]', ' ', text.lower()).split():
    if len(tok) == 1:
      out.add(tok)
    out.update(tok[i:i + 2] for i in range(len(tok) - 1))
  return out


def _sim(a: str, b: str) -> float:
  """Similarity of two short labels in [0, 1] (exact > containment > bigrams)."""
  na, nb = _norm(a), _norm(b)
  if not na or not nb:
    return 0.0
  if na == nb:
    return 1.0
  if min(len(na), len(nb)) >= 2 and (na in nb or nb in na):
    return 0.9
  ga, gb = _bigrams(a), _bigrams(b)
  if not ga or not gb:
    return 0.0
  return len(ga & gb) / min(len(ga), len(gb))


def _heading_core(text: str) -> str:
  core = _ORD_ANY_RE.sub('', text.strip(), count=1)
  return _TRAIL_RE.sub('', core).strip()


def _cjk_len(text: str) -> int:
  return len(re.findall(r'[\u3400-\u9fff]', text))


def _segment_aliases(seg: dict[str, Any], chain_name: str = '') -> list[str]:
  """Names a paragraph may start with: name, title, de-parenthesised forms,
  "/"- or "、"-separated parts (only when every part has >= 3 chars) and the
  same without a trailing 業/產業. Aliases that merely repeat the chain name
  (segment 觸控面板 in chain 觸控面板) are dropped: such text is chain-wide.
  """
  out: list[str] = []
  chain_key = _norm(chain_name)
  for name in (seg.get('name'), seg.get('title')):
    if not name:
      continue
    base = re.sub(r'[（(][^）)]*[）)]?', '', name).strip() or name
    cands = [name, base]
    parts = [p.strip() for p in re.split(r'[/／、，,]', base)]
    if len(parts) > 1 and all(len(p) >= 3 for p in parts):
      cands += parts
    for cand in cands:
      for alias in (cand, re.sub(r'(?:產業|業)$', '', cand)):
        ok = _cjk_len(alias) >= 2 or len(re.findall(r'[A-Za-z0-9]', alias)) >= 3
        key = _norm(alias)
        if (not ok or alias.startswith(('其他', '其它')) or alias in out
            or (chain_key and chain_key.startswith(key))):
          continue
        out.append(alias)
  return out


def _start_match(text: str, aliases: list[str]) -> int:
  """Length of the longest alias that `text` starts with (0 = none)."""
  return max((len(a) for a in aliases if text.startswith(a)), default=0)


def _page_year(html: str) -> int:
  """Reference year for "recent" detection: page copyright year, else now."""
  m = re.search(r'(?:©|&copy;|&#169;)\s*\d{4}\s*[-–~]\s*(\d{4})', html)
  return int(m.group(1)) if m else datetime.now(TPE).year


def _trend_score(text: str, year: int) -> int:
  """How much a paragraph reads like recent news: 0 none, 1 weak, 2 strong.

  Counts mentions of recent/future years (western >= year - 3, ROC years
  too). Strong: 「展望」, a mention within the first 40 characters, three or
  more mentions, or two mentions in <= 400 characters. A single passing
  mention deep inside a descriptive paragraph is only weak.
  """
  if '展望' in text:
    return 2
  hits = [m.start() for m in _YEAR_RE.finditer(text)
          if year - 3 <= int(m.group(1)) <= year + 30]
  hits += [m.start() for m in _ROC_YEAR_RE.finditer(text)
           if year - 3 <= int(m.group(1)) + 1911 <= year + 5]
  if not hits:
    return 0
  hits.sort()
  if hits[0] < 40 or len(hits) >= 3 or (len(hits) == 2 and len(text) <= 400):
    return 2
  return 1


def _is_trend(text: str, year: int) -> bool:
  """True when a paragraph strongly reads like recent news / outlook."""
  return _trend_score(text, year) >= 2


def _assign_text(paras: list[dict[str, Any]], streams: list[dict[str, Any]],
                 segments: dict[str, dict[str, Any]], chain_name: str,
                 year: int) -> tuple[list[str], list[str]]:
  """Distributes intro paragraphs; returns `(intro, trends)`.

  Fills `streams[*]["desc"]` and `segments[*]["desc"]` in place.

  Heuristics (the page has no ids around the text):
  * the leading bold title (「半導體產業鏈」) is dropped;
  * short headings such as 「一、上游：」 open a stream section (matched by
    name/caption similarity, then by elimination); headings naming a segment
    open a segment section; other top-level headings (「產業發展趨勢」) open
    a trends section;
  * a paragraph that starts with a segment name (「IC通路業僅負責…」,
    「（五）電信服務業：…」) goes to that segment;
  * paragraphs that strongly read like news (`_trend_score` == 2) go to
    trends, and in stream sections every following paragraph up to the next
    heading as well (trend tails are unmarked) - unless a paragraph opens
    with the current stream's name (「汽車業的下游則為…」);
  * other paragraphs go to the current section: intro, the stream's only
    real segment, or the stream itself (`streams[*]["desc"]`); in flat
    chains (no stream headings) text after the first segment paragraph that
    cannot be attributed goes to trends;
  * short sub-headings travel with the next paragraph.
  """
  intro: list[str] = []
  trends: list[str] = []
  if paras and paras[0]['bold'] and len(paras[0]['text']) <= _HEADING_MAX:
    paras = paras[1:]  # Chain title.
  seg_stream: dict[str, int] = {}
  for i, stream in enumerate(streams):
    for sid in stream['segments']:
      seg_stream[sid] = i
  real = {sid for sid, seg in segments.items()
          if not seg.get('placeholder') and not seg.get('ref')}
  aliases = {sid: _segment_aliases(seg, chain_name)
             for sid, seg in segments.items() if not seg.get('placeholder')}

  def is_short(p: dict[str, Any]) -> bool:
    text = p['text']
    return len(text) <= _HEADING_MAX and not text.endswith(('。', '；', ';'))

  def stream_score(core: str, stream: dict[str, Any]) -> float:
    words = [w for w in _STREAM_WORDS if w in core]
    if len(words) == 1:
      return 1.0 if words[0] in stream['name'] else 0.0
    return max(_sim(core, stream['name']),
               _sim(core, stream['caption']) if stream['caption'] else 0.0)

  def segment_of_heading(core: str) -> str | None:
    best, best_sid = 0, None
    for sid, als in aliases.items():
      n = _start_match(core, als)
      if n and n >= 0.6 * len(core) and n > best:
        best, best_sid = n, sid
    return best_sid

  # Pass 1: classify headings.
  kinds: list[tuple[str, Any]] = []  # (kind, payload) per paragraph.
  top_unmatched: list[int] = []
  used: set[int] = set()
  for idx, p in enumerate(paras):
    if not is_short(p):
      kinds.append(('body', None))
      continue
    core = _heading_core(p['text'])
    ordinal_top = bool(_ORD_TOP_RE.match(p['text'])) and p['indent'] == 0
    top_level = p['indent'] == 0 and (
        ordinal_top or p['bold'] or core in _STREAM_WORDS
        or (p['text'].rstrip().endswith(('：', ':')) and len(core) <= 12))
    if top_level and streams:
      scores = [stream_score(core, s) for s in streams]
      best = max(range(len(streams)), key=lambda i: scores[i])
      if scores[best] >= 0.5:
        kinds.append(('stream', best))
        used.add(best)
        continue
    sid = segment_of_heading(core) if (top_level or _ORD_ANY_RE.match(
        p['text'])) else None
    if sid is not None:
      kinds.append(('segment', sid))
      continue
    if top_level and (ordinal_top or p['bold'] or p['text'].endswith(('：', ':'))):
      kinds.append(('other', None))
      if ordinal_top:
        top_unmatched.append(idx)
      continue
    kinds.append(('sub', None))
  free = [i for i in range(len(streams)) if i not in used]
  if top_unmatched and len(top_unmatched) == len(free):
    for idx, si in zip(top_unmatched, free):
      kinds[idx] = ('stream', si)
  flat = not any(kind == 'stream' for kind, _ in kinds)

  # Pass 2: assign paragraphs.
  section, cur_stream, cur_seg = 'intro', None, None
  trend_mode = False
  left_intro = False
  pending: list[str] = []

  def put(bucket: list[str], text: str | None = None) -> None:
    """Appends pending sub-headings, then `text`, to `bucket` (deduped)."""
    for item in pending + ([text] if text else []):
      if item not in bucket:
        bucket.append(item)
    pending.clear()

  def default_bucket() -> list[str]:
    if section == 'segment' and cur_seg in segments:
      return segments[cur_seg]['desc']
    if section == 'stream' and cur_stream is not None:
      stream = streams[cur_stream]
      reals = [s for s in stream['segments'] if s in real]
      if len(reals) == 1:
        return segments[reals[0]]['desc']
      return stream['desc']
    if section == 'intro' and not left_intro:
      return intro
    return trends

  def start_segment(text: str, weak: bool) -> str | None:
    probe = _ORD_ANY_RE.sub('', text, count=1)  # 「（五）電信服務業：…」
    if weak:
      stripped = _FILLER_RE.sub('', probe)
      if stripped == probe:
        return None
      probe = stripped
    best, best_sid = 0, None
    for sid, als in aliases.items():
      n = _start_match(probe, als)
      in_stream = cur_stream is not None and seg_stream.get(sid) == cur_stream
      if n and (n > best or (n == best and in_stream)):
        best, best_sid = n, sid
    return best_sid

  def names_current_stream(text: str) -> bool:
    """「汽車業的下游則為…」: the paragraph introduces the current stream."""
    if section != 'stream' or cur_stream is None:
      return False
    head = text[:30]
    stream = streams[cur_stream]
    return any(label and label in head
               for label in (stream['name'], stream['caption']))

  for p, (kind, payload) in zip(paras, kinds):
    text = p['text']
    if kind in ('stream', 'segment', 'other'):
      if pending:
        put(default_bucket())
      left_intro = True
      trend_mode = kind == 'other'
      if kind == 'stream':
        section, cur_stream, cur_seg = 'stream', payload, None
      elif kind == 'segment':
        section, cur_seg = 'segment', payload
        cur_stream = seg_stream.get(payload)
      else:
        section, cur_stream, cur_seg = 'other', None, None
        pending.append(text)
      continue
    if kind == 'sub':
      pending.append(text)
      if _TREND_HEAD_RE.search(text) or _is_trend(text, year):
        trend_mode = True
      continue
    trendy = _is_trend(text, year)
    sid = start_segment(text, weak=False)
    if sid is None and not trendy and not trend_mode:
      sid = start_segment(text, weak=True)
    if sid is not None:
      put(segments[sid]['desc'], text)
      if section == 'intro' and flat:
        left_intro = True
      elif section != 'intro' and trendy:
        trend_mode = True
      continue
    if names_current_stream(text):
      trend_mode = False
      put(default_bucket(), text)
      continue
    if trendy or trend_mode:
      put(trends, text)
      if section != 'intro':
        trend_mode = True
      continue
    put(default_bucket(), text)
  if pending:
    put(default_bucket())
  return intro, trends


# --------------------------------------------------------------------------
# Chain page
# --------------------------------------------------------------------------


def parse_chain(html: str, chain_id: str, chain_name: str) -> dict[str, Any]:
  """Parses one `introduce.php?ic=<ID>` page into the SPEC section 5 chain dict.

  Keys: id, name, url, intro, trends, streams, segments. Each stream is
  `{"name", "caption", "desc", "segments": [ids]}`; each segment is
  `{"id", "name", "title", "desc", "groups", "subs"}` plus `"placeholder":
  true` for text-only boxes or `"ref": "<chain id>"` for boxes that stand for
  another whole chain.
  """
  root = _parse_html(html)
  known = {cid for cid, _ in _chain_options(root)}
  streams, boxes = _parse_panel(root, chain_id)
  lists = _company_list_nodes(root)
  orphans = [sid for sid in lists if sid not in boxes]
  if orphans:
    extra = {'name': ORPHAN_STREAM, 'caption': '', 'desc': [], 'segments': []}
    for sid in orphans:
      boxes[sid] = {'name': clean_text(lists[sid].attrs.get('title')) or sid,
                    'placeholder': False}
      extra['segments'].append(sid)
    streams.append(extra)
  segments: dict[str, dict[str, Any]] = {}
  for stream in streams:
    for sid in stream['segments']:
      box = boxes[sid]
      node = lists.get(sid)
      title = clean_text(node.attrs.get('title')) if node is not None else ''
      name = box['name']
      if title and title != name and title.startswith(name):
        name = title  # Box label truncated (e.g. 生產製程及檢測 -> …設備).
      seg: dict[str, Any] = {'id': sid, 'name': name, 'title': title or name,
                             'desc': [], 'groups': [], 'subs': []}
      if node is not None:
        seg['groups'], seg['subs'] = _parse_company_list(node, sid)
      if box['placeholder']:
        seg['placeholder'] = True
      elif node is None and sid in known and sid != chain_id:
        seg['ref'] = sid
      segments[sid] = seg
  intro, trends = _assign_text(_intro_paragraphs(root), streams, segments,
                               chain_name, _page_year(html))
  return {'id': chain_id, 'name': chain_name,
          'url': CHAIN_URL.format(id=chain_id), 'intro': intro,
          'trends': trends, 'streams': streams, 'segments': segments}


def segment_codes(segment: dict[str, Any]) -> list[str]:
  """Distinct stock codes of a segment (its groups already include subs)."""
  out: list[str] = []
  for group in segment.get('groups', []):
    for company in group['companies']:
      if company['code'] and company['code'] not in out:
        out.append(company['code'])
  return out


def build_by_code(chains: list[dict[str, Any]]) -> dict[str, list[dict[str, str]]]:
  """Reverse index code -> chain/stream/segment memberships (SPEC section 5)."""
  index: dict[str, list[dict[str, str]]] = {}
  for chain in chains:
    for stream in chain['streams']:
      for sid in stream['segments']:
        seg = chain['segments'][sid]
        for code in segment_codes(seg):
          entry = {'chain': chain['id'], 'chain_name': chain['name'],
                   'stream': stream['name'], 'segment': sid,
                   'segment_name': seg['name']}
          bucket = index.setdefault(code, [])
          if entry not in bucket:
            bucket.append(entry)
  return dict(sorted(index.items()))


def chain_stats(chains: list[dict[str, Any]]) -> dict[str, int]:
  """Counts used by the CLI summary and the JSON `stats` block."""
  segs = [s for c in chains for s in c['segments'].values()]
  codes = {code for s in segs for code in segment_codes(s)}
  return {
      'chains': len(chains),
      'streams': sum(len(c['streams']) for c in chains),
      'segments': sum(1 for s in segs if not s.get('placeholder')),
      'placeholders': sum(1 for s in segs if s.get('placeholder')),
      'subs': sum(len(s['subs']) for s in segs),
      'companies': sum(len(g['companies']) for s in segs for g in s['groups']),
      'memberships': sum(len(segment_codes(s)) for s in segs),
      'codes': len(codes),
  }


# --------------------------------------------------------------------------
# Network (polite fetch + raw cache)
# --------------------------------------------------------------------------


class FetchError(RuntimeError):
  """Raised when a page cannot be fetched after all retries."""


class _Fetcher:
  """Sequential HTTP GET with a minimum interval and exponential backoff."""

  def __init__(self, delay: float = 1.0, retries: int = 3,
               timeout: float = 30.0, backoff: float = 2.0) -> None:
    self.delay = max(1.0, delay)  # Never faster than one request per second.
    self.retries = retries
    self.timeout = timeout
    self.backoff = backoff
    self.requests = 0
    self._last = 0.0

  def _throttle(self) -> None:
    wait = self._last + self.delay - time.monotonic()
    if wait > 0:
      time.sleep(wait)
    self._last = time.monotonic()

  def get(self, url: str) -> str:
    """Returns the decoded body of `url`; raises `FetchError` on failure."""
    headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,'
                  '*/*;q=0.8',
        'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.6',
        'Accept-Encoding': 'gzip',
        'Referer': SOURCE_URL,
    }
    last_err: Exception | None = None
    for attempt in range(self.retries + 1):
      if attempt:
        time.sleep(self.backoff * (2 ** (attempt - 1)))
      self._throttle()
      self.requests += 1
      try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
          raw = resp.read()
          if resp.headers.get('Content-Encoding', '').lower() == 'gzip':
            raw = gzip.decompress(raw)
          charset = resp.headers.get_content_charset() or 'utf-8'
        try:
          return raw.decode(charset, errors='replace')
        except LookupError:
          return raw.decode('utf-8', errors='replace')
      except urllib.error.HTTPError as e:
        last_err = e
        if e.code in (400, 401, 403, 404, 410):
          break
      except Exception as e:  # pylint: disable=broad-except
        last_err = e
      log.info('attempt %d/%d for %s failed: %r', attempt + 1,
               self.retries + 1, url, last_err)
    raise FetchError(f'{url}: {last_err!r}')


def _looks_like_chain_page(html: str) -> bool:
  return 'id="main_ic_panel"' in html or "id='main_ic_panel'" in html


def _atomic_write(path: str, data: str) -> None:
  """Writes `data` to `path` via a temp file + `os.replace` (mode 0644)."""
  folder = os.path.dirname(os.path.abspath(path))
  os.makedirs(folder, exist_ok=True)
  fd, tmp = tempfile.mkstemp(prefix='.tmp_', suffix='.part', dir=folder)
  try:
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
      f.write(data)
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)
  except BaseException:
    if os.path.exists(tmp):
      os.unlink(tmp)
    raise


def fetch_page(chain_id: str, fetcher: _Fetcher | None = None,
               max_age: float = 0.0, raw_dir: str = RAW_DIR
               ) -> tuple[str, str, float]:
  """Returns `(html, origin, timestamp)` for a chain page.

  `origin` is "network", "cache" (cached copy younger than `max_age`
  seconds, or `fetcher` is None) or "stale" (network failed, old copy used).
  """
  path = os.path.join(raw_dir, f'{chain_id}.html')
  cached: str | None = None
  mtime = 0.0
  if os.path.exists(path):
    with open(path, encoding='utf-8', errors='replace') as f:
      cached = f.read()
    mtime = os.path.getmtime(path)
    if not _looks_like_chain_page(cached):
      cached = None
    elif fetcher is None or (max_age > 0 and time.time() - mtime < max_age):
      return cached, 'cache', mtime
  if fetcher is None:
    raise FetchError(f'{chain_id}: offline and no cached page in {raw_dir}')
  try:
    html = fetcher.get(CHAIN_URL.format(id=chain_id))
    if not _looks_like_chain_page(html):
      raise FetchError(f'{chain_id}: unexpected page ({len(html)} chars)')
  except FetchError as e:
    if cached is not None:
      log.warning('%s; using cached copy', e)
      return cached, 'stale', mtime
    raise
  _atomic_write(path, html)
  return html, 'network', time.time()


def fetch_all(out_path: str = DEFAULT_OUT, delay: float = 1.0, *,
              max_age: float = 0.0, offline: bool = False,
              raw_dir: str = RAW_DIR,
              progress: Callable[[int, int, str], None] | None = None
              ) -> dict[str, Any]:
  """Fetches + parses every chain and writes `out_path` atomically.

  Args:
    out_path: JSON destination.
    delay: seconds between requests (clamped to >= 1.0).
    max_age: reuse cached raw pages younger than this many seconds.
    offline: parse cached raw pages only (no network).
    raw_dir: raw HTML cache directory.
    progress: optional callback `(done, total, chain_id)`.

  Chains that fail are reported in `errors` and, when possible, carried over
  from the previous JSON so one bad page never wipes existing data.
  """
  fetcher = None if offline else _Fetcher(delay=delay)
  first_html, _, first_ts = fetch_page(FIRST_CHAIN, fetcher, max_age, raw_dir)
  options = list_chains(first_html)
  if not options:
    raise FetchError('chain dropdown #ic_option not found')
  chains: list[dict[str, Any]] = []
  errors: list[dict[str, str]] = []
  stamps: list[float] = []
  for i, (cid, name) in enumerate(options):
    try:
      if cid == FIRST_CHAIN:
        html, ts = first_html, first_ts
      else:
        html, _, ts = fetch_page(cid, fetcher, max_age, raw_dir)
      chains.append(parse_chain(html, cid, name))
      stamps.append(ts)
    except Exception as e:  # pylint: disable=broad-except
      log.error('chain %s %s failed: %r', cid, name, e)
      errors.append({'id': cid, 'name': name, 'error': repr(e)})
    if progress is not None:
      progress(i + 1, len(options), cid)
  if errors and os.path.exists(out_path):
    try:
      with open(out_path, encoding='utf-8') as f:
        previous = {c['id']: c for c in json.load(f).get('chains', [])}
    except (OSError, ValueError):
      previous = {}
    order = {cid: i for i, (cid, _) in enumerate(options)}
    for err in errors:
      if err['id'] in previous:
        chains.append(previous[err['id']])
        err['error'] += ' (kept previous data)'
    chains.sort(key=lambda c: order.get(c['id'], len(order)))
  if not chains:
    raise FetchError('no chain could be fetched or parsed')
  fetched = datetime.fromtimestamp(min(stamps) if stamps else time.time(), TPE)
  data = {
      'source': SOURCE_NAME,
      'source_url': SOURCE_URL,
      'fetched_at': fetched.isoformat(timespec='seconds'),
      'stats': chain_stats(chains),
      'errors': errors,
      'chains': chains,
      'by_code': build_by_code(chains),
  }
  _atomic_write(out_path, json.dumps(data, ensure_ascii=False,
                                     separators=(',', ':')))
  return data


def main(argv: list[str] | None = None) -> int:
  """CLI: fetch everything and print a summary."""
  parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
  parser.add_argument('--out', default=DEFAULT_OUT, help='output JSON path')
  parser.add_argument('--delay', type=float, default=1.0,
                      help='seconds between requests (>= 1)')
  parser.add_argument('--max-age', type=float, default=0.0,
                      help='reuse cached pages younger than N seconds')
  parser.add_argument('--offline', action='store_true',
                      help='parse cached raw pages only')
  args = parser.parse_args(argv)
  logging.basicConfig(level=logging.WARNING, format='%(levelname)s %(message)s')

  def progress(done: int, total: int, cid: str) -> None:
    print(f'\r[{done:>2}/{total}] {cid}', end='', file=sys.stderr, flush=True)

  t0 = time.time()
  data = fetch_all(args.out, args.delay, max_age=args.max_age,
                   offline=args.offline, progress=progress)
  print(file=sys.stderr)
  st = data['stats']
  print(f'chains={st["chains"]} streams={st["streams"]} '
        f'segments={st["segments"]} placeholders={st["placeholders"]} '
        f'subs={st["subs"]} companies={st["companies"]} '
        f'memberships_with_code={st["memberships"]} codes={st["codes"]} '
        f'errors={len(data["errors"])} ({time.time() - t0:.1f}s)')
  for chain in data['chains']:
    streams = ' / '.join(f'{s["name"]}({len(s["segments"])})'
                         for s in chain['streams'])
    print(f'  {chain["id"]} {chain["name"]}: {streams}; '
          f'codes={len({c for s in chain["segments"].values() for c in segment_codes(s)})}')
  for err in data['errors']:
    print(f'  ERROR {err["id"]} {err["name"]}: {err["error"]}')
  print(f'wrote {args.out}')
  return 1 if data['errors'] else 0


if __name__ == '__main__':
  sys.exit(main())
