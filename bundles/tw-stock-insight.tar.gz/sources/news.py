"""News adapters: FinMind per-stock news, Google News RSS, 鉅亨網 market news."""
from __future__ import annotations

import datetime as dt
import email.utils
import html
import re
import urllib.parse
from typing import Any

import net

TZ = dt.timezone(dt.timedelta(hours=8))


def _iso(d: dt.datetime) -> str:
  return d.astimezone(TZ).replace(microsecond=0).isoformat()


def _clean_title(t: str) -> str:
  t = html.unescape(re.sub(r'<[^>]+>', '', t or '')).strip()
  return re.sub(r'\s+', ' ', t)


def finmind_news(code: str, days: int = 14) -> list[dict]:
  start = (dt.date.today() - dt.timedelta(days=days)).isoformat()
  js = net.fetch_json('https://api.finmindtrade.com/api/v4/data?dataset=TaiwanStockNews'
                      f'&data_id={urllib.parse.quote(code)}&start_date={start}', timeout=20)
  out = []
  for r in js.get('data') or []:
    try:
      t = dt.datetime.strptime(r['date'], '%Y-%m-%d %H:%M:%S').replace(tzinfo=dt.timezone.utc)
    except (KeyError, ValueError):
      continue
    title = _clean_title(r.get('title', ''))
    title = re.sub(r'\s+-\s+[^-]{1,12}$', '', title)
    out.append({'title': title, 'link': r.get('link') or '', 'source': r.get('source') or '',
                'time': _iso(t)})
  return out


def google_news(query: str, limit: int = 20) -> list[dict]:
  url = ('https://news.google.com/rss/search?q=' + urllib.parse.quote(query) +
         '&hl=zh-TW&gl=TW&ceid=TW:zh-Hant')
  doc = net.fetch_text(url, timeout=20)
  out = []
  for item in re.findall(r'<item>(.*?)</item>', doc, flags=re.S)[:limit]:
    title = _clean_title((re.findall(r'<title>(.*?)</title>', item, flags=re.S) or [''])[0])
    link = html.unescape((re.findall(r'<link>(.*?)</link>', item, flags=re.S) or [''])[0]).strip()
    src = _clean_title((re.findall(r'<source[^>]*>(.*?)</source>', item, flags=re.S) or [''])[0])
    pub = (re.findall(r'<pubDate>(.*?)</pubDate>', item, flags=re.S) or [''])[0]
    try:
      t = email.utils.parsedate_to_datetime(pub)
    except (TypeError, ValueError):
      continue
    if src and title.endswith(' - ' + src):
      title = title[: -len(src) - 3]
    out.append({'title': title, 'link': link, 'source': src, 'time': _iso(t)})
  return out


_LOW_QUALITY = ('股市爆料同學會', '同學會', '操作明細', '操作日報', 'PTT', '批踢踢', '討論區', 'Dcard')


def _low_quality(it: dict) -> bool:
  """Drops forum posts / ETF daily holdings notes that crowd out real news."""
  text = f"{it.get('title', '')} {it.get('source', '')}"
  return any(k in text for k in _LOW_QUALITY)


def stock_news(code: str, name: str) -> list[dict]:
  items: list[dict] = []
  errors = []
  for fn in (lambda: finmind_news(code), lambda: google_news(f'{name} {code}')):
    try:
      items.extend(fn())
    except Exception as e:  # pylint: disable=broad-except
      errors.append(str(e)[:120])
  prefix = re.compile(rf'^\s*(?:{re.escape(code)}\s*)?{re.escape(name)}\s*[-－–|｜:：]\s*')
  for it in items:
    t = prefix.sub('', it['title']).strip()
    if it.get('source'):
      t = re.sub(rf'\s*[-－–|｜]\s*{re.escape(it["source"])}\s*$', '', t)
    it['title'] = t or it['title']
  seen, out = set(), []
  for it in sorted(items, key=lambda x: x['time'], reverse=True):
    key = re.sub(r'\W', '', it['title'])[:40]
    if not it['title'] or key in seen or _low_quality(it):
      continue
    seen.add(key)
    out.append(it)
  return out[:40]


def market_news(limit: int = 20) -> list[dict]:
  js = net.fetch_json(f'https://api.cnyes.com/media/api/v1/newslist/category/tw_stock?limit={limit}',
                      timeout=20)
  out = []
  for r in ((js.get('items') or {}).get('data') or [])[:limit]:
    try:
      t = dt.datetime.fromtimestamp(int(r.get('publishAt')), tz=dt.timezone.utc)
    except (TypeError, ValueError):
      continue
    out.append({'title': _clean_title(r.get('title', '')),
                'link': f'https://news.cnyes.com/news/id/{r.get("newsId")}',
                'source': '鉅亨網', 'time': _iso(t)})
  return out


def finmind_dividends(code: str) -> list[dict[str, Any]]:
  """Dividend policy history from FinMind TaiwanStockDividend (newest last)."""
  js = net.fetch_json('https://api.finmindtrade.com/api/v4/data?dataset=TaiwanStockDividend'
                      f'&data_id={urllib.parse.quote(code)}&start_date=2015-01-01', timeout=20)
  out = []
  for r in js.get('data') or []:
    year = str(r.get('year') or '')
    m = re.match(r'(\d+)年(.*)', year)
    if m:
      label = str(int(m.group(1)) + 1911)
      period = m.group(2).strip() or '年度'
    else:
      label, period = year, '年度'
    cash = (r.get('CashEarningsDistribution') or 0) + (r.get('CashStatutorySurplus') or 0)
    stock = (r.get('StockEarningsDistribution') or 0) + (r.get('StockStatutorySurplus') or 0)
    out.append({'year': label, 'period': period, 'cash': round(float(cash), 4),
                'stock': round(float(stock), 4),
                'ex_date': r.get('CashExDividendTradingDate') or r.get('StockExDividendTradingDate') or None,
                'pay_date': r.get('CashDividendPaymentDate') or None})
  return out


def finmind_prices(code: str, start: str) -> list[list]:
  """Daily bars [date, o, h, l, c, vol張] from FinMind (for long ranges)."""
  js = net.fetch_json('https://api.finmindtrade.com/api/v4/data?dataset=TaiwanStockPrice'
                      f'&data_id={urllib.parse.quote(code)}&start_date={start}', timeout=30)
  out = []
  for r in js.get('data') or []:
    if not r.get('close'):
      continue
    out.append([r['date'], float(r['open'] or r['close']), float(r['max'] or r['close']),
                float(r['min'] or r['close']), float(r['close']),
                round((r.get('Trading_Volume') or 0) / 1000.0, 3)])
  return out
