#!/usr/bin/env python3
"""Builds the GitHub Pages single-file HTML (static data snapshot) of 台股智慧選股.

Output: dist/index.html — CSS, Lightweight Charts, every page script and an API snapshot
(`window.__STATIC_API__`) inlined into one file that works from file:// or any static host.
Contents: meta / universe (all securities, screener works fully) / market / picks /
industries / all industry chains / full daily K-line + analysis for picks + the most traded
stocks and ETFs. Indicators are recomputed client-side to keep the file small.

CLI: python3 tools/build_dist.py [--force]
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import json
import os
import re
import sys
import threading
import time
from typing import Any

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

import config  # noqa: E402  pylint: disable=wrong-import-position
import release_mgr  # noqa: E402  pylint: disable=wrong-import-position
import snapshot  # noqa: E402  pylint: disable=wrong-import-position

DIST_DIR = os.path.join(ROOT_DIR, 'dist')
OUT_HTML = os.path.join(DIST_DIR, 'index.html')
INFO_JSON = os.path.join(DIST_DIR, 'build_info.json')
TOP_STOCKS = 180          # most traded common stocks with full K-line + analysis
TOP_ETFS = 20
NETWORK_DIVIDEND_BUDGET = 40   # FinMind dividend lookups allowed per build (rest from cache/DB)
_LOCK = threading.Lock()
_FORBIDDEN = re.compile(
    '|'.join(
        re.escape(base64.b64decode(b).decode())
        for b in (
            b'Z29vZ2xlcnMuY29t',
            b'Y29ycC5nb29nbGUuY29t',
            b'Z29vZ2xlcGxleA==',
            b'aHVhbmd5aWNoYW8=',
            b'L2dvb2dsZS9zcmMv',
            b'QGdvb2dsZS5jb20=',
        )
    ),
    re.I,
)


def _static_files() -> list[str]:
  out = [os.path.join(config.STATIC_DIR, 'index.html'), os.path.join(config.STATIC_DIR, 'app.css')]
  js_dir = os.path.join(config.STATIC_DIR, 'js')
  out += [os.path.join(js_dir, f) for f in sorted(os.listdir(js_dir)) if f.endswith('.js')]
  return out


def _code_hash() -> str:
  h = hashlib.sha1()
  for fp in _static_files() + [os.path.abspath(__file__)]:
    with open(fp, 'rb') as f:
      h.update(f.read())
  return h.hexdigest()[:16]


def info() -> dict[str, Any] | None:
  """Last build info plus `fresh` (matches current version, data date and code)."""
  try:
    with open(INFO_JSON, encoding='utf-8') as f:
      data = json.load(f)
  except (OSError, ValueError):
    return None
  if not os.path.isfile(OUT_HTML):
    return None
  meta = snapshot.get_payload('universe') or {}
  an = snapshot.db.get_kv('analytics', {}) or {}
  data['fresh'] = (data.get('version') == release_mgr.current_version()
                   and data.get('data_date') == meta.get('date')
                   and data.get('data_updated_at') == an.get('updated_at')
                   and data.get('code_hash') == _code_hash())
  return data


def _full_codes(rows: dict[str, dict[str, Any]], picks: dict[str, Any]) -> list[str]:
  codes: list[str] = []
  for p in (picks or {}).get('picks') or []:
    if p['code'] not in codes:
      codes.append(p['code'])
  stocks = sorted((r for r in rows.values() if r.get('type') == '股票'),
                  key=lambda r: -(r.get('value') or 0))
  etfs = sorted((r for r in rows.values() if r.get('type') == 'ETF'), key=lambda r: -(r.get('value') or 0))
  for r in stocks[:TOP_STOCKS] + etfs[:TOP_ETFS]:
    if r['code'] not in codes:
      codes.append(r['code'])
  return codes


def _api_snapshot() -> tuple[dict[str, Any], list[str], str | None]:
  rows = snapshot.get_rows()
  universe = snapshot.get_payload('universe') or {}
  market = dict(snapshot.get_payload('market') or {})
  market['news'] = snapshot.market_news_cached()
  picks = snapshot.get_payload('picks') or {}
  industries = snapshot.get_payload('industries') or {}
  etfs = snapshot.get_payload('etfs') or {}
  morning_data = snapshot.morning_cached(force=False) or {}
  data_date = universe.get('date')
  an = snapshot.db.get_kv('analytics', {}) or {}
  rel = release_mgr.load_releases()
  api: dict[str, Any] = {
      '/api/meta': {'version': rel['current_version'], 'data_date': data_date,
                    'updated_at': an.get('updated_at'), 'static': True,
                    'is_intraday': bool(an.get('is_intraday')), 'quote_time': an.get('quote_time'),
                    'status': {'state': 'idle', 'step': '', 'progress': 1.0, 'message': '', 'errors': []},
                    'counts': an.get('counts') or {}, 'next_update': None,
                    'schedule': config.SCHEDULE_TEXT, 'schedule_slots': config.SCHEDULE_SLOTS,
                    'disclaimer': config.DISCLAIMER},
      '/api/universe': universe, '/api/market': market, '/api/picks': picks,
      '/api/industries': industries, '/api/etfs': etfs, '/api/morning': morning_data,
      '/api/release_status': {'static': True, 'current_version': rel['current_version'],
                              'has_changes': False, 'releases': rel['releases']},
  }
  api.update(_extra_endpoints())
  for ch in industries.get('chains') or []:
    detail = snapshot.chain_detail(ch['id'])
    if detail:
      api[f'/api/industry/{ch["id"]}'] = detail
  codes = _full_codes(rows, picks)
  budget = NETWORK_DIVIDEND_BUDGET
  done = []
  for code in codes:
    try:
      net_ok = budget > 0
      detail = snapshot.stock_detail(code, 'D', '1y', network=net_ok)
      if not detail or not detail.get('bars'):
        continue
      if net_ok:
        budget -= 1
      detail.pop('ind', None)
      api[f'/api/stock/{code}'] = detail
      analysis = snapshot.stock_analysis(code, 'D')
      if analysis:
        api[f'/api/stock/{code}/analysis'] = analysis
      done.append(code)
    except Exception:  # pylint: disable=broad-except
      continue
  return api, done, data_date


# Optional feature endpoints (added by other modules) embedded when the backend serves them.
EXTRA_ENDPOINTS = ('/api/morning', '/api/etfs')


def _extra_endpoints() -> dict[str, Any]:
  import urllib.request  # pylint: disable=import-outside-toplevel
  out = {}
  for path in EXTRA_ENDPOINTS:
    try:
      with urllib.request.urlopen(f'http://127.0.0.1:{config.BACKEND_PORT}{path}', timeout=20) as r:
        if r.status == 200 and 'json' in (r.headers.get('Content-Type') or ''):
          out[path] = json.loads(r.read().decode('utf-8'))
    except Exception:  # pylint: disable=broad-except
      continue
  # No local backend (e.g. GitHub Actions): read the snapshot payloads written by the analytics run.
  for path in EXTRA_ENDPOINTS:
    if path not in out:
      payload = snapshot.get_payload(path.rsplit('/', 1)[1])
      if payload:
        out[path] = payload
  return out


def _js_json(obj: Any) -> str:
  text = json.dumps(obj, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
  return text.replace('</', '<\\/').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


def _assemble(api: dict[str, Any], static_info: dict[str, Any]) -> str:
  with open(os.path.join(config.STATIC_DIR, 'index.html'), encoding='utf-8') as f:
    html = f.read()
  with open(os.path.join(config.STATIC_DIR, 'app.css'), encoding='utf-8') as f:
    css = f.read()
  html = re.sub(r'<link[^>]+href="[^"]*app\.css[^"]*"[^>]*>', lambda _: f'<style>\n{css}\n</style>', html)
  srcs = re.findall(r'<script\s+src="([^"]+)"\s*>\s*</script>', html)
  blocks = [
      '<script>window.TW_STATIC = ' + _js_json(static_info) + ';</script>',
      '<script>window.__STATIC_API__ = ' + _js_json(api) + ';</script>',
  ]
  for src in srcs:
    rel = src.split('?')[0].lstrip('/')
    rel = rel[len('static/'):] if rel.startswith('static/') else rel
    with open(os.path.join(config.STATIC_DIR, rel), encoding='utf-8') as f:
      code = f.read().replace('</script', '<\\/script')
    blocks.append(f'<script>/* {rel} */\n{code}\n</script>')
  first = re.search(r'<script\s+src="[^"]+"\s*>\s*</script>', html)
  html = re.sub(r'\s*<script\s+src="[^"]+"\s*>\s*</script>', '', html)
  if first:
    idx = html.find('</body>')
    html = html[:idx] + '\n'.join(blocks) + '\n' + html[idx:]
  html = html.replace('<head>', '<head>\n  <meta name="generator" content="台股智慧選股 static build">', 1)
  return html


def build(force: bool = False) -> dict[str, Any]:
  """Builds dist/index.html unless the existing bundle is already fresh."""
  with _LOCK:
    cur = info()
    if cur and cur.get('fresh') and not force:
      return cur
    t0 = time.time()
    api, codes, data_date = _api_snapshot()
    version = release_mgr.current_version()
    built_at = dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat(timespec='seconds')
    static_info = {'version': version, 'built_at': built_at, 'data_date': data_date,
                   'stocks_full': len(codes), 'full_codes': codes}
    html = _assemble(api, static_info)
    leak = _FORBIDDEN.search(html)
    if leak:
      raise RuntimeError(f'靜態檔含有內部網址或帳號字串：{leak.group(0)}，已停止打包')
    os.makedirs(DIST_DIR, exist_ok=True)
    tmp = OUT_HTML + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
      f.write(html)
    os.replace(tmp, OUT_HTML)
    data = {'version': version, 'data_date': data_date, 'built_at': built_at,
            'data_updated_at': (api.get('/api/meta') or {}).get('updated_at'),
            'bytes': os.path.getsize(OUT_HTML), 'stocks_full': len(codes),
            'code_hash': _code_hash(), 'seconds': round(time.time() - t0, 1)}
    with open(INFO_JSON, 'w', encoding='utf-8') as f:
      json.dump(data, f, ensure_ascii=False, indent=2)
    data['fresh'] = True
    return data


if __name__ == '__main__':
  print(json.dumps(build(force='--force' in sys.argv), ensure_ascii=False, indent=2))
