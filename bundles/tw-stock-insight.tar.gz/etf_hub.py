"""Taiwan ETF Intelligence Hub: dividend calendar, TTM & annualized yields, fill-days, NAV/AUM."""
from __future__ import annotations

import bisect
import datetime as dt
import json
import math
import statistics
import time
from typing import Any

import db
from sources import etf as etf_src
from sources import news as news_src

TZ = dt.timezone(dt.timedelta(hours=8))

ISSUER_PREFIXES = (
    '元大', '國泰', '群益', '富邦', '復華', '中信', '凱基', '統一', '大華優利', '大華', '野村',
    '永豐', '兆豐', '台新', '第一金', '新光', '保德信', 'FT', '富蘭克林', '貝萊德', '摩根',
    '安聯', '聯博', '街口', '玉山', '台企銀',
)

FREQ_MULT = {'月配': 12, '雙月配': 6, '季配': 4, '半年配': 2, '年配': 1, '不配息': 0}


def _r(x: float | None, nd: int = 2) -> float | None:
  if x is None or not isinstance(x, (int, float)) or not math.isfinite(x):
    return None
  return round(float(x), nd)


def classify_etf(code: str, name: str, full_name: str = '') -> str:
  """Classifies a Taiwan ETF into an investor-friendly category."""
  s = f'{name} {full_name}'
  if code.endswith(('L', 'R', 'U')) or any(k in name for k in ('正2', '反1', '黃金', '原油', '石油', '黃豆', '白銀', '日圓')):
    return '槓桿／反向／期貨'
  if code.endswith(('A', 'D')) or name.startswith('主動'):
    return '主動式 ETF'
  if code.endswith('T') or name.startswith('平衡') or '多重資產' in s:
    return '多資產／平衡'
  if code.endswith('B') or '債' in name:
    if any(k in s for k in ('非投等', '高收益', '新興債', 'EM主權債', '新興市場債')):
      return '非投等／新興債'
    if (any(k in s for k in ('美債', '美國公債', '美公債', '政府債', '國債'))
        and not any(k in s for k in ('公司', '金融債', '投等', 'A債', 'B債', '電信債', '醫療債', '科技債'))):
      return '美國公債'
    return '投資級公司債'
  if any(k in name for k in ('高股息', '高息', '優息', '股息', '低波高息', '價值高息', '高填息', '存股', '永續高息')):
    return '高股息'
  if any(k in s for k in ('美國', '美股', 'S&P', '標普', '那斯達克', 'NASDAQ', '費城', 'FANG', '日本', '日經', '東證',
                          '印度', '越南', '歐洲', '全球', '世界', '中國', '上証', '滬深', '恒生', '香港', '韓國', 'KOSPI')):
    return '海外股票'
  if any(k in s for k in ('半導體', '科技', 'AI', '5G', '電動車', 'IC設計', '通訊', '網通', 'PCB', '算力', '晶圓', '資安')):
    return '科技／半導體'
  if any(k in name for k in ('50', '100', '加權', '市值', '摩台', 'MSCI台灣', '公司治理', 'ESG', '低碳', '龍頭', '動能')):
    return '市值型'
  return '產業／主題型'


def infer_issuer(name: str, fortune_issuer: str | None) -> str:
  if fortune_issuer:
    return fortune_issuer
  clean = name.removeprefix('主動').removeprefix('平衡').removeprefix('期')
  for p in ISSUER_PREFIXES:
    if clean.startswith(p):
      return '大華銀' if p in ('大華優利', '大華') else ('富蘭克林華美' if p == 'FT' else p)
  return '其他投信'


def sync_etf_external(force: bool = False) -> None:
  """Downloads TWSE ETF dividends, ETFortune metadata & MIS NAV/AUM into SQLite kv."""
  last = db.get_kv('etf_sync_at', 0)
  if not force and time.time() - last < 4 * 3600 and db.get_kv('etf_mis'):
    return
  try:
    divs = etf_src.fetch_twse_etf_dividends(2021)
    if divs:
      db.set_kv('etf_twse_divs', divs)
  except Exception:  # pylint: disable=broad-except
    pass
  try:
    fort = etf_src.fetch_twse_etf_fortune()
    if fort:
      db.set_kv('etf_fortune', fort)
  except Exception:  # pylint: disable=broad-except
    pass
  try:
    mis = etf_src.fetch_mis_all_etf()
    if mis:
      db.set_kv('etf_mis', mis)
  except Exception:  # pylint: disable=broad-except
    pass

  # Backfill pay_date via FinMind for top traded TPEx ETFs (polite small budget).
  try:
    tpex_etfs = db.query(
        "SELECT s.code FROM stocks s JOIN daily d ON s.code=d.code "
        "WHERE s.type='ETF' AND s.market='上櫃' AND d.date=(SELECT MAX(date) FROM daily) "
        "ORDER BY d.value DESC LIMIT 25")
    budget = 10
    for (code,) in tpex_etfs:
      if budget <= 0:
        break
      row = db.query_one('SELECT fetched_at FROM news_cache WHERE code=?', (f'div:{code}',))
      if row and time.time() - row[0] < 14 * 86400:
        continue
      budget -= 1
      items = news_src.finmind_dividends(code)
      db.execute('INSERT OR REPLACE INTO news_cache VALUES (?,?,?)',
                 (f'div:{code}', time.time(), json.dumps(items, ensure_ascii=False)))
  except Exception:  # pylint: disable=broad-except
    pass

  db.set_kv('etf_sync_at', time.time())


def _infer_freq(ex_dates: list[str], code: str, name: str, cat: str) -> str:
  if cat == '槓桿／反向／期貨' and not ex_dates:
    return '不配息'
  if not ex_dates:
    if '月配' in name:
      return '月配'
    if '季' in name:
      return '季配'
    return '不配息'
  ds = sorted({dt.date.fromisoformat(d) for d in ex_dates if len(d) == 10})
  recent = [d for d in ds if (dt.date.today() - d).days <= 550]
  use = recent if len(recent) >= 2 else ds[-6:]
  if len(use) >= 2:
    gaps = [(use[i] - use[i - 1]).days for i in range(1, len(use)) if 12 <= (use[i] - use[i - 1]).days <= 420]
    if gaps:
      med = statistics.median(gaps)
      if med <= 45:
        return '月配'
      if med <= 72:
        return '雙月配'
      if med <= 125:
        return '季配'
      if med <= 240:
        return '半年配'
      return '年配'
  # Single distribution so far (newly listed ETF)
  if any(k in name for k in ('月配', '優息', '收益', '非投', '公債', '公司債', '投等債')) or code in ('00929', '00939', '00940'):
    return '月配' if code.startswith(('0093', '0094', '0095', '0096', '0098', '0099')) else '季配'
  return '季配' if cat in ('高股息', '美國公債', '投資級公司債', '非投等／新興債') else '年配'


def _compute_fills(divs: list[dict[str, Any]], raw_bars: list[tuple], today_iso: str) -> list[dict[str, Any]]:
  """Enriches ascending dividend events with prev_close, period_yld, filled, and fill_days."""
  bar_dates = [b[0] for b in raw_bars]
  out: list[dict[str, Any]] = []
  n_divs = len(divs)
  for idx_d, d in enumerate(divs):
    ex_d = d['ex_date']
    cash = d.get('cash')
    item = dict(d)
    if ex_d > today_iso:
      item.update({'status': '即將除息', 'filled': None, 'fill_days': None, 'prev_close': None, 'period_yld': None})
      out.append(item)
      continue
    pos = bisect.bisect_left(bar_dates, ex_d)
    prev_close = raw_bars[pos - 1][4] if pos > 0 else None
    item['prev_close'] = _r(prev_close, 2)
    item['period_yld'] = _r(cash / prev_close * 100, 2) if (cash and prev_close and prev_close > 0) else None
    if not prev_close or pos >= len(raw_bars) or not cash or cash <= 0:
      item.update({'status': '已除息', 'filled': None, 'fill_days': None})
      out.append(item)
      continue
    # Search up to the next ex-dividend date (or latest bar) for high >= prev_close.
    next_ex = divs[idx_d + 1]['ex_date'] if idx_d + 1 < n_divs else '9999-12-31'
    end_pos = bisect.bisect_left(bar_dates, next_ex)
    filled_days = None
    for j in range(pos, min(end_pos, len(raw_bars))):
      high = raw_bars[j][2]
      if high is not None and high >= prev_close - 1e-4:
        filled_days = j - pos + 1
        break
    if filled_days is not None:
      item.update({'status': '已填息', 'filled': True, 'fill_days': filled_days})
    else:
      is_latest = (idx_d == n_divs - 1) or (next_ex > today_iso)
      item.update({'status': '貼息中' if is_latest else '未填息', 'filled': False, 'fill_days': None})
    out.append(item)
  return out


def _prev_trading_day(ex_date: str, trading_dates: list[str]) -> str | None:
  """Returns the last buy date (最後買進日 = trading day strictly before ex_date)."""
  if not ex_date:
    return None
  idx = bisect.bisect_left(trading_dates, ex_date)
  if idx > 0 and ex_date <= trading_dates[-1]:
    return trading_dates[idx - 1]
  # Future date beyond latest trading_dates: step back 1 weekday skipping known holidays.
  hol = set(db.get_kv(f'holidays_{ex_date[:4]}', []) or [])
  d = dt.date.fromisoformat(ex_date) - dt.timedelta(days=1)
  for _ in range(14):
    if d.weekday() < 5 and d.isoformat() not in hol:
      return d.isoformat()
    d -= dt.timedelta(days=1)
  return None


def build_etfs_payload(rows: dict[str, dict[str, Any]], bars_by: dict[str, list[tuple]],
                       data_date: str, trading_dates: list[str]) -> dict[str, Any]:
  """Builds the `/api/etfs` payload and updates `rows[code]['yld']` for ETFs in-place."""
  sync_etf_external(force=False)
  today_iso = dt.datetime.now(TZ).date().isoformat()
  d_1y_ago = (dt.date.fromisoformat(data_date) - dt.timedelta(days=370)).isoformat()

  twse_divs = db.get_kv('etf_twse_divs', []) or []
  fortune = db.get_kv('etf_fortune', {}) or {}
  mis = db.get_kv('etf_mis', {}) or {}
  upcoming_kv = db.get_kv('upcoming_exrights', []) or []

  # Index dividend events by (code, ex_date) merging all sources.
  by_code_div: dict[str, dict[str, dict[str, Any]]] = {}

  def put_div(code: str, ex_d: str, cash: float | None, pay_d: str | None = None,
              rec_d: str | None = None) -> None:
    if not code or not ex_d:
      return
    cur = by_code_div.setdefault(code, {}).setdefault(
        ex_d, {'ex_date': ex_d, 'cash': None, 'pay_date': None, 'record_date': None})
    if cash is not None and (cur['cash'] is None or cash > 0):
      cur['cash'] = round(float(cash), 4)
    if pay_d and not cur.get('pay_date'):
      cur['pay_date'] = pay_d
    if rec_d and not cur.get('record_date'):
      cur['record_date'] = rec_d

  for r in twse_divs:
    put_div(r.get('code', ''), r.get('ex_date', ''), r.get('cash'), r.get('pay_date'), r.get('record_date'))

  for code, date, _, amount in db.query(
      "SELECT e.code, e.date, e.kind, e.amount FROM exrights e JOIN stocks s ON e.code=s.code WHERE s.type='ETF'"):
    put_div(code, date, amount)

  for u in upcoming_kv:
    c = u.get('code') or ''
    if c.startswith('00'):
      put_div(c, u.get('date') or '', u.get('cash'))

  for cache_key, raw_json in db.query("SELECT code, data FROM news_cache WHERE code LIKE 'div:00%'"):
    c = cache_key[4:]
    try:
      for it in json.loads(raw_json):
        if it.get('ex_date'):
          put_div(c, it['ex_date'], it.get('cash'), it.get('pay_date'))
    except Exception:  # pylint: disable=broad-except
      continue

  etf_codes = sorted(c for c, r in rows.items() if r.get('type') == 'ETF')
  etf_items: list[dict[str, Any]] = []
  upcoming_list: list[dict[str, Any]] = []
  recent_ex_list: list[dict[str, Any]] = []

  for code in etf_codes:
    r = rows[code]
    ft = fortune.get(code) or {}
    ms = mis.get(code) or {}
    full_name = ms.get('full_name') or ''
    cat = classify_etf(code, r['name'], full_name)
    issuer = infer_issuer(r['name'], ft.get('issuer'))
    close = r.get('close')
    aum = ft.get('aum') if ft.get('aum') is not None else ms.get('aum_est')
    holders = ft.get('holders')
    nav = ms.get('nav')
    prem = ms.get('premium_pct')
    if prem is None and close and nav and nav > 0:
      p_calc = round((close / nav - 1) * 100, 2)
      if abs(p_calc) < 30:
        prem = p_calc

    div_map = by_code_div.get(code, {})
    divs_sorted = [div_map[d] for d in sorted(div_map)]
    enriched = _compute_fills(divs_sorted, bars_by.get(code, []), today_iso)

    past = [d for d in enriched if d['ex_date'] <= today_iso and (d.get('cash') or 0) > 0]
    future = [d for d in enriched if d['ex_date'] > today_iso]

    ex_dates_all = [d['ex_date'] for d in enriched]
    freq = _infer_freq(ex_dates_all, code, r['name'], cat)

    # Dividend months from recent 2 years
    recent_2y = [d for d in enriched if d['ex_date'] >= f'{int(data_date[:4]) - 1}-01-01']
    ex_months = sorted({int(d['ex_date'][5:7]) for d in (recent_2y or enriched) if len(d['ex_date']) >= 7})

    # TTM cash dividend & TTM yield
    ttm_divs = [d for d in past if d['ex_date'] >= d_1y_ago]
    div_ttm = round(sum(d['cash'] for d in ttm_divs), 4) if ttm_divs else 0.0
    yld_ttm = _r(div_ttm / close * 100, 2) if (div_ttm > 0 and close and close > 0) else None

    last_d = past[-1] if past else None
    last_cash = last_d['cash'] if last_d else None
    last_yld = _r(last_cash / close * 100, 2) if (last_cash and close and close > 0) else None
    mult = FREQ_MULT.get(freq, 0)
    yld_ann = _r(last_cash * mult / close * 100, 2) if (last_cash and mult > 0 and close and close > 0) else yld_ttm

    # Backfill universe row's `yld` so screener & stock detail also get ETF yields!
    if yld_ttm is not None:
      r['yld'] = yld_ttm
      if yld_ttm >= 5 and '高殖利率' not in (r.get('signals') or []):
        r.setdefault('signals', []).append('高殖利率')

    # Fill statistics over recent 3 years (up to 16 distributions)
    eval_fills = [d for d in past[-16:] if d.get('filled') is not None]
    filled_ok = [d for d in eval_fills if d.get('filled') is True]
    fill_rate = _r(len(filled_ok) / len(eval_fills) * 100, 1) if eval_fills else None
    avg_fill_days = _r(sum(d['fill_days'] for d in filled_ok) / len(filled_ok), 1) if filled_ok else None

    next_d = future[0] if future else None
    upcoming_info = None
    if next_d:
      last_buy = _prev_trading_day(next_d['ex_date'], trading_dates)
      ncash = next_d.get('cash')
      nyld = _r(ncash / close * 100, 2) if (ncash and close and close > 0) else None
      days_left = (dt.date.fromisoformat(next_d['ex_date']) - dt.date.fromisoformat(today_iso)).days
      upcoming_info = {
          'ex_date': next_d['ex_date'],
          'last_buy_date': last_buy,
          'pay_date': next_d.get('pay_date'),
          'cash': ncash if (ncash and ncash > 0) else None,
          'prev_cash': _r(last_cash, 4) if last_cash else None,
          'period_yld': nyld,
          'days_left': days_left,
      }
      upcoming_list.append({
          'code': code, 'name': r['name'], 'market': r['market'], 'cat': cat, 'freq': freq,
          'close': close, 'premium_pct': prem, 'yld_ttm': yld_ttm, **upcoming_info,
      })

    if last_d and (dt.date.fromisoformat(data_date) - dt.date.fromisoformat(last_d['ex_date'])).days <= 21:
      recent_ex_list.append({
          'code': code, 'name': r['name'], 'cat': cat, 'freq': freq, 'close': close,
          'ex_date': last_d['ex_date'], 'pay_date': last_d.get('pay_date'),
          'cash': last_d['cash'], 'period_yld': last_d.get('period_yld'),
          'status': last_d.get('status'), 'fill_days': last_d.get('fill_days'),
      })

    hist_slim = [{
        'ex_date': d['ex_date'],
        'pay_date': d.get('pay_date'),
        'cash': d.get('cash'),
        'prev_close': d.get('prev_close'),
        'period_yld': d.get('period_yld'),
        'status': d.get('status'),
        'fill_days': d.get('fill_days'),
    } for d in reversed(enriched[-16:])]

    etf_items.append({
        'code': code,
        'name': r['name'],
        'market': r['market'],
        'cat': cat,
        'issuer': issuer,
        'index_name': ft.get('index_name'),
        'listed': ft.get('listed'),
        'close': close,
        'chg': r.get('chg'),
        'pct': r.get('pct'),
        'nav': _r(nav, 2),
        'premium_pct': prem,
        'aum': aum,
        'holders': holders,
        'vol': r.get('vol'),
        'value': r.get('value'),
        'r5': r.get('r5'),
        'r20': r.get('r20'),
        'r60': r.get('r60'),
        'r250': r.get('r250'),
        'f5': r.get('f5'),
        't5': r.get('t5'),
        'f20': r.get('f20'),
        'freq': freq,
        'ex_months': ex_months,
        'div_ttm': _r(div_ttm, 3) if div_ttm > 0 else None,
        'div_count_ttm': len(ttm_divs),
        'yld_ttm': yld_ttm,
        'yld_ann': yld_ann,
        'last_cash': _r(last_cash, 4) if last_cash is not None else None,
        'last_yld': last_yld,
        'last_ex_date': last_d['ex_date'] if last_d else None,
        'last_pay_date': last_d.get('pay_date') if last_d else None,
        'last_fill_status': last_d.get('status') if last_d else None,
        'last_fill_days': last_d.get('fill_days') if last_d else None,
        'fill_rate': fill_rate,
        'avg_fill_days': avg_fill_days,
        'upcoming': upcoming_info,
        'history': hist_slim,
    })

  etf_items.sort(key=lambda x: -(x.get('aum') or x.get('value') or 0))
  upcoming_list.sort(key=lambda x: (x['ex_date'], -(x.get('yld_ttm') or 0)))
  recent_ex_list.sort(key=lambda x: x['ex_date'], reverse=True)

  # Category summary counts
  cat_counts: dict[str, int] = {}
  freq_counts: dict[str, int] = {}
  for it in etf_items:
    cat_counts[it['cat']] = cat_counts.get(it['cat'], 0) + 1
    freq_counts[it['freq']] = freq_counts.get(it['freq'], 0) + 1

  total_aum = round(sum(it['aum'] for it in etf_items if it.get('aum')), 1)
  high_yld_cnt = sum(1 for it in etf_items if (it.get('yld_ttm') or 0) >= 5.0)

  return {
      'date': data_date,
      'updated_at': dt.datetime.now(TZ).isoformat(timespec='seconds'),
      'summary': {
          'total_etfs': len(etf_items),
          'total_aum': total_aum,
          'upcoming_count': len(upcoming_list),
          'high_yield_count': high_yld_cnt,
          'categories': cat_counts,
          'frequencies': freq_counts,
      },
      'upcoming': upcoming_list[:40],
      'recent_ex': recent_ex_list[:25],
      'etfs': etf_items,
  }


def etf_dividends_for(code: str) -> list[dict[str, Any]]:
  """Returns dividend rows for a single ETF code from cached TWSE etfDiv + exrights."""
  by_d: dict[str, dict[str, Any]] = {}
  for r in db.get_kv('etf_twse_divs', []) or []:
    if r.get('code') == code and r.get('ex_date'):
      d = r['ex_date']
      by_d[d] = {'year': d[:4], 'period': d[5:7] + '月', 'cash': r.get('cash'), 'stock': 0.0,
                 'ex_date': d, 'pay_date': r.get('pay_date')}
  for d, amt in db.query('SELECT date, amount FROM exrights WHERE code=? ORDER BY date', (code,)):
    if d and amt and d not in by_d:
      by_d[d] = {'year': d[:4], 'period': d[5:7] + '月', 'cash': round(float(amt), 4), 'stock': 0.0,
                 'ex_date': d, 'pay_date': None}
  return [by_d[d] for d in sorted(by_d)]
