"""Configuration constants for 台股戰情室 (TW Stock War Room)."""
from __future__ import annotations

import os

VERSION = '1.0.0'   # initial version only; the live version lives in releases.json (release_mgr)
TOOL_NAME = '台股戰情室'

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
DATA_DIR = os.environ.get('TW_STOCK_DATA_DIR', os.path.join(ROOT_DIR, 'data'))
RAW_DIR = os.path.join(DATA_DIR, 'raw')
DB_PATH = os.path.join(DATA_DIR, 'stock.db')
STATE_PATH = os.path.join(DATA_DIR, 'state.json')
SNAP_DIR = os.path.join(DATA_DIR, 'snapshots')
CHAINS_PATH = os.path.join(DATA_DIR, 'industry_chains.json')

BACKEND_PORT = 8904
PUBLIC_PORT = 8905

# How much history to keep / backfill.
BACKFILL_DAYS = int(os.environ.get('TW_STOCK_BACKFILL_DAYS', '300'))  # trading days
INST_BACKFILL_DAYS = int(os.environ.get('TW_STOCK_INST_DAYS', '300'))
REVENUE_MONTHS = 36
EPS_QUARTERS = 13

# Polite per-host minimum interval between requests (seconds).
HOST_INTERVAL = {
    'www.twse.com.tw': 2.2,
    'openapi.twse.com.tw': 0.6,
    'mis.twse.com.tw': 1.0,
    'www.tpex.org.tw': 0.8,
    'mopsov.twse.com.tw': 2.0,
    'api.finmindtrade.com': 0.5,
    'news.google.com': 0.5,
    'api.cnyes.com': 0.5,
    'ws.api.cnyes.com': 0.4,
    'api.nasdaq.com': 0.4,
    'ic.tpex.org.tw': 1.0,
}
DEFAULT_INTERVAL = 0.5

# Daily update schedule (Asia/Taipei local time, trading days only).
MORNING_TIMES = ('07:45', '08:35')
INTRADAY_TIMES = ('10:30', '12:30')
UPDATE_TIMES = ('14:50', '16:10', '18:30', '21:30')
SCHEDULE_TEXT = (
    '交易日盤前 07:45 / 08:35 美股與事件研判；'
    '盤中 10:30 / 12:30 即時行情更新；'
    '盤後 14:50 / 16:10 / 18:30 / 21:30 行情更新'
)
# Structured schedule for the 「🔄 資料更新頻率」 strip at the top of every page (/api/meta and the
# GitHub build). Notes = what a slot usually picks up: TWSE / TPEx publish each dataset at a
# different time, so the post-market runs fill the data in batches (observed in fetch_log).
SCHEDULE_SLOTS = {
    'morning': list(MORNING_TIMES),
    'intraday': list(INTRADAY_TIMES),
    'update': list(UPDATE_TIMES),
    'notes': {
        '07:45': '美股收盤、盤後異動與國際重大事件', '08:35': '開盤前再研判一次',
        '10:30': '早盤上市櫃即時行情、類股強弱與選股重算', '12:30': '午盤上市櫃即時行情、量價指標與選股更新',
        '14:50': '上市收盤行情', '16:10': '上櫃收盤行情、三大法人買賣金額',
        '18:30': '上市個股三大法人、本益比／殖利率', '21:30': '補抓前面還沒公布的資料',
    },
}

# Recommendation model.
PICK_TOP_N = 20
MIN_AVG_VOL20 = 500        # 張
MIN_PRICE = 10.0
MIN_HISTORY = 60           # trading days
WEIGHTS = {'chip': 0.40, 'rev': 0.40, 'mom': 0.20, 'vol': 0.0, 'val': 0.0}
BACKTEST_TOP_N = 10
BACKTEST_HOLD = 10

DISCLAIMER = (
    '本站所有量化評分、今日推薦、盤前戰情、選股篩選與技術指標分析，均由程式依公開歷史資料自動運算，'
    '純供個人量化研究參考，絕不構成任何證券投資顧問建議、買賣邀約或獲利保證；投資人應獨立判斷並自行查證，'
    '任何投資決策之盈虧、投資失敗或財務損失皆由投資人完全自負，概與本站及開發者無關。'
)

USER_AGENT = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/124.0 Safari/537.36')
