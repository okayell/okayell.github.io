"""Data pipeline: first-time backfill + incremental daily updates.

Run standalone:  python3 updater.py [--quick] [--no-analytics]
The server imports `run_update()` and calls it from its scheduler thread.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable

import config
import db
import net
from sources import intraday, mops, tpex, twse

TZ = dt.timezone(dt.timedelta(hours=8))
CODE_OK = re.compile(r'^(\d{4}|00\d{2,4}[A-Z]?|\d{4}[A-Z])$')
_RUN_LOCK = threading.Lock()


def now_tw() -> dt.datetime:
  return dt.datetime.now(TZ)


def today_tw() -> str:
  return now_tw().date().isoformat()


class Progress:
  """Thread-safe progress state shared with the HTTP server (/api/meta)."""

  def __init__(self) -> None:
    self._lock = threading.Lock()
    self.state: dict[str, Any] = {'state': 'idle', 'step': '', 'progress': 1.0,
                                  'message': '', 'errors': [], 'started_at': None,
                                  'finished_at': None}
    try:
      with open(config.STATE_PATH, encoding='utf-8') as f:
        saved = json.load(f)
      self.state.update({k: saved[k] for k in ('finished_at',) if k in saved})
    except (OSError, ValueError):
      pass

  def set(self, **kw: Any) -> None:
    with self._lock:
      self.state.update(kw)
      snap = dict(self.state)
    try:
      os.makedirs(config.DATA_DIR, exist_ok=True)
      tmp = config.STATE_PATH + '.tmp'
      with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(snap, f, ensure_ascii=False)
      os.replace(tmp, config.STATE_PATH)
    except OSError:
      pass

  def error(self, msg: str) -> None:
    with self._lock:
      errs = (self.state.get('errors') or [])[-19:]
      errs.append(f'{now_tw():%H:%M:%S} {msg[:300]}')
      self.state['errors'] = errs

  def get(self) -> dict[str, Any]:
    with self._lock:
      return dict(self.state)


PROGRESS = Progress()


# ---------------------------------------------------------------- calendar ---

def holidays() -> set[str]:
  year = now_tw().year
  cached = db.get_kv(f'holidays_{year}')
  if cached:
    return set(cached)
  try:
    hs = twse.holidays()
    db.set_kv(f'holidays_{year}', sorted(hs))
    return hs
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'休市日資料取得失敗：{e}')
    return set()


def is_trading_day(d: dt.date, hol: set[str] | None = None) -> bool:
  hol = holidays() if hol is None else hol
  return d.weekday() < 5 and d.isoformat() not in hol


def candidate_dates(n: int) -> list[str]:
  """Most recent n weekday non-holiday dates (ascending), today only after 14:00."""
  hol = holidays()
  now = now_tw()
  d = now.date()
  if now.hour < 14:
    d -= dt.timedelta(days=1)
  out = []
  while len(out) < n:
    if is_trading_day(d, hol):
      out.append(d.isoformat())
    d -= dt.timedelta(days=1)
  return sorted(out)


# ---------------------------------------------------------------- writers ----

def _stock_type(code: str, name: str) -> str:
  if code.startswith('00'):
    return 'ETF'
  if re.fullmatch(r'\d{4}', code) and not name.endswith('-DR'):
    return '股票'
  return '其他'


def _save_quotes(date: str, market: str, quotes: list[tuple]) -> int:
  rows, stocks = [], []
  for (code, name, o, h, l, c, vol, value, trades, chg) in quotes:
    if not CODE_OK.match(code):
      continue
    rows.append((code, date, o, h, l, c, vol, value, trades, chg))
    stocks.append((code, name, market, _stock_type(code, name)))
  db.upsert_many('daily', ('code', 'date', 'open', 'high', 'low', 'close', 'vol', 'value',
                           'trades', 'chg'), rows)
  with db._WRITE_LOCK:  # pylint: disable=protected-access
    conn = db.connect()
    conn.executemany(
        'INSERT INTO stocks (code, name, market, type) VALUES (?,?,?,?) '
        'ON CONFLICT(code) DO UPDATE SET name=excluded.name, market=excluded.market, '
        'type=excluded.type', stocks)
    conn.commit()
  return len(rows)


def _merge_market(date: str, data: dict[str, Any]) -> None:
  row = db.query_one('SELECT data FROM market WHERE date=?', (date,))
  cur = json.loads(row[0]) if row else {}
  cur.update({k: v for k, v in data.items() if v is not None})
  db.execute('INSERT OR REPLACE INTO market VALUES (?,?)',
             (date, json.dumps(cur, ensure_ascii=False)))


def _should_mark_nodata(date: str) -> bool:
  return date < today_tw() or now_tw().hour >= 22


# ---------------------------------------------------------------- tasks ------

def task_twse_quotes(date: str) -> None:
  if db.fetched('twse_quotes', date):
    return
  res = twse.daily_quotes(date)
  if res is None:
    if _should_mark_nodata(date):
      db.mark_fetched('twse_quotes', date, 'nodata')
    return
  _save_quotes(date, '上市', res['quotes'])
  db.upsert_many('index_daily', ('name', 'date', 'close', 'chg', 'pct'),
                 [(n, date, c, ch, p) for (n, c, ch, p) in res['indices']])
  st = res['stats']
  _merge_market(date, {'twse_value': st.get('value'), 'twse_up': st.get('up'),
                       'twse_down': st.get('down'), 'twse_flat': st.get('flat'),
                       'twse_limit_up': st.get('limit_up'), 'twse_limit_down': st.get('limit_down')})
  db.mark_fetched('twse_quotes', date)


def task_tpex_quotes(date: str) -> None:
  if db.fetched('tpex_quotes', date):
    return
  res = tpex.daily_quotes(date)
  if res is None:
    if _should_mark_nodata(date):
      db.mark_fetched('tpex_quotes', date, 'nodata')
    return
  _save_quotes(date, '上櫃', res['quotes'])
  if res.get('shares'):
    with db._WRITE_LOCK:  # pylint: disable=protected-access
      conn = db.connect()
      conn.executemany('UPDATE stocks SET shares=? WHERE code=?',
                       [(v, k) for k, v in res['shares'].items()])
      conn.commit()
  if res.get('managed'):
    db.set_kv('tpex_managed', res['managed'])
  _merge_market(date, {'tpex_value': res['stats'].get('value')})
  db.mark_fetched('tpex_quotes', date)


def _save_inst(date: str, rows: list[tuple]) -> None:
  db.upsert_many('inst', ('code', 'date', 'foreign_net', 'trust_net', 'dealer_net', 'total_net'),
                 [(c, date, f, t, d, tot) for (c, f, t, d, tot) in rows if CODE_OK.match(c)])


def task_twse_inst(date: str) -> None:
  if db.fetched('twse_inst', date):
    return
  rows = twse.inst(date)
  if rows is None:
    if _should_mark_nodata(date):
      db.mark_fetched('twse_inst', date, 'nodata')
    return
  _save_inst(date, rows)
  db.mark_fetched('twse_inst', date)


def task_tpex_inst(date: str) -> None:
  if db.fetched('tpex_inst', date):
    return
  rows = tpex.inst(date)
  if rows is None:
    if _should_mark_nodata(date):
      db.mark_fetched('tpex_inst', date, 'nodata')
    return
  _save_inst(date, rows)
  db.mark_fetched('tpex_inst', date)


def task_market_inst(date: str) -> None:
  if db.fetched('twse_inst_amt', date):
    return
  amt = twse.inst_amount(date)
  if amt:
    _merge_market(date, {'inst_twse': amt})
    db.mark_fetched('twse_inst_amt', date)
  try:
    tp = tpex.inst_amount_latest()
    if tp and tp.get('date') == date:
      _merge_market(date, {'inst_tpex': tp})
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'上櫃法人金額：{e}')


def task_valuation(date: str) -> None:
  if not db.fetched('twse_val', date):
    rows = twse.valuation(date)
    if rows:
      db.upsert_many('valuation', ('code', 'date', 'pe', 'pb', 'yld'),
                     [(c, date, pe, pb, y) for (c, pe, pb, y) in rows])
      db.mark_fetched('twse_val', date)
  d2, rows2 = tpex.valuation_latest()
  if d2 and rows2:
    db.upsert_many('valuation', ('code', 'date', 'pe', 'pb', 'yld'),
                   [(c, d2, pe, pb, y) for (c, pe, pb, y) in rows2])


def _clean_industry(name: str) -> str:
  name = re.sub(r'[（(].*$', '', name or '').strip()
  return name


def _fetched_age(source: str, key: str) -> float:
  row = db.query_one('SELECT fetched_at FROM fetch_log WHERE source=? AND key=?', (source, key))
  return time.time() - row[0] if row and row[0] else 1e12


def task_revenue(market: str, year: int, month: int, force: bool = False) -> None:
  key = f'{market}_{year}-{month:02d}'
  status = db.fetched('revenue', key)
  if status == 'ok' and not force:
    return
  if status and _fetched_age('revenue', key) < 4 * 3600:
    return
  rows = mops.revenue_month(market, year, month)
  if not rows:
    return
  ym = f'{year}-{month:02d}'
  db.upsert_many('revenue', ('code', 'ym', 'rev', 'mom', 'yoy', 'cum_rev', 'cum_yoy'),
                 [(c, ym, rev, mom, yoy, cr, cy) for (c, _, _, rev, mom, yoy, cr, cy) in rows])
  ind = {c: _clean_industry(i) for (c, _, i, *_rest) in rows if i}
  if ind:
    with db._WRITE_LOCK:  # pylint: disable=protected-access
      conn = db.connect()
      conn.executemany('UPDATE stocks SET industry=? WHERE code=? AND (industry IS NULL OR ?)',
                       [(v, k, 1) for k, v in ind.items()])
      conn.commit()
  # Finished months (older than the current-1) are final after the 15th.
  today = now_tw().date()
  final = (year, month) < ((today.year, today.month - 1) if today.month > 1 else (today.year - 1, 12))
  db.mark_fetched('revenue', key, 'ok' if final or today.day > 15 else 'partial')


def task_eps(market: str, year: int, season: int, force: bool = False) -> None:
  key = f'{market}_{year}Q{season}'
  status = db.fetched('eps', key)
  if status == 'ok' and not force:
    return
  if status and _fetched_age('eps', key) < 20 * 3600:
    return
  rows = mops.eps_quarter(market, year, season)
  if not rows:
    return
  q = f'{year}Q{season}'
  db.upsert_many('eps', ('code', 'q', 'cum_eps', 'cum_rev', 'cum_op', 'cum_ni'),
                 [(c, q, e, r, o, n) for (c, e, r, o, n) in rows])
  deadline = {1: (5, 31), 2: (8, 31), 3: (11, 30), 4: (4, 15)}[season]
  dyear = year + 1 if season == 4 else year
  final = now_tw().date() > dt.date(dyear, *deadline)
  db.mark_fetched('eps', key, 'ok' if final else 'partial')


def task_profiles() -> None:
  last = db.get_kv('profiles_at', 0)
  if time.time() - last < 6 * 86400 and db.query_one('SELECT 1 FROM stocks WHERE full_name IS NOT NULL'):
    return
  rows = []
  for p in twse.profiles() + tpex.profiles():
    if p['code']:
      rows.append(p)
  cols = ('code', 'name', 'full_name', 'industry_code', 'chairman', 'gm', 'founded', 'listed',
          'capital', 'shares', 'address', 'phone', 'website', 'spokesman', 'auditor')
  with db._WRITE_LOCK:  # pylint: disable=protected-access
    conn = db.connect()
    for p in rows:
      vals = [p.get(c) for c in cols]
      conn.execute(
          f'INSERT INTO stocks ({",".join(cols)}) VALUES ({",".join("?" * len(cols))}) '
          'ON CONFLICT(code) DO UPDATE SET ' +
          ', '.join(f'{c}=COALESCE(excluded.{c}, {c})' for c in cols[2:]), vals)
    conn.commit()
  db.set_kv('profiles_at', time.time())


def task_margins_dividends() -> None:
  last = db.get_kv('fund_at', 0)
  if time.time() - last < 2 * 86400:
    return
  rows = twse.margins() + tpex.margins()
  db.upsert_many('margins', ('code', 'q', 'gross', 'operating', 'net'),
                 [r for r in rows if r[0] and r[1]])
  db.upsert_many('dividends', ('code', 'year', 'period', 'cash', 'stock', 'ex_date', 'pay_date',
                               'board_date'), twse.dividends())
  db.set_kv('fund_at', time.time())


def task_exrights() -> None:
  today = now_tw().date()
  for y in range(today.year - 4, today.year + 1):
    key = str(y)
    if y < today.year and db.fetched('exrights', key):
      continue
    if y == today.year and time.time() - db.get_kv('exrights_cur_at', 0) < 86400:
      continue
    start, end = f'{y}-01-01', min(f'{y}-12-31', today.isoformat())
    rows = twse.exrights(start, end) + tpex.exrights(start, end)
    db.upsert_many('exrights', ('code', 'date', 'kind', 'amount'),
                   [r for r in rows if r[0] and r[1]])
    if y < today.year:
      db.mark_fetched('exrights', key)
    else:
      db.set_kv('exrights_cur_at', time.time())


def task_flags() -> None:
  flags: dict[str, list[str]] = {}

  def add(code, tag):
    if code and tag not in flags.setdefault(code, []):
      flags[code].append(tag)

  for fn, tag in ((twse.punish, '處置'), (twse.notice, '注意'), (tpex.disposal, '處置'),
                  (tpex.warning, '注意')):
    try:
      for r in fn():
        add(r['code'], tag)
    except Exception as e:  # pylint: disable=broad-except
      PROGRESS.error(f'{tag}股清單：{e}')
  for code in db.get_kv('tpex_managed', []) or []:
    add(code, '全額交割')
  db.set_kv('flags', flags)
  try:
    up = twse.upcoming_exrights() + tpex.upcoming_exrights()
    db.set_kv('upcoming_exrights', [u for u in up if u['date'] and u['date'] >= today_tw()])
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'除權息預告：{e}')


def task_tpex_index() -> None:
  today = now_tw().date()
  months = []
  y, m = today.year, today.month
  for _ in range(14):
    months.append((y, m))
    y, m = (y - 1, 12) if m == 1 else (y, m - 1)
  out = []
  for (y, m) in months:
    key = f'{y}-{m:02d}'
    current = (y, m) == (today.year, today.month)
    if not current and db.fetched('tpex_index', key):
      continue
    try:
      rows = tpex.index_month(y, m)
    except Exception as e:  # pylint: disable=broad-except
      PROGRESS.error(f'櫃買指數 {key}：{e}')
      continue
    for d, c, ch in rows:
      if c is None:
        continue
      pct = (ch / (c - ch) * 100) if ch is not None and c - ch else None
      out.append(('櫃買指數', d, c, ch, round(pct, 2) if pct is not None else None))
    if rows and not current:
      db.mark_fetched('tpex_index', key)
  db.upsert_many('index_daily', ('name', 'date', 'close', 'chg', 'pct'), out)


def task_chains() -> None:
  if os.path.exists(config.CHAINS_PATH) and time.time() - os.path.getmtime(config.CHAINS_PATH) < 25 * 86400:
    return
  try:
    from sources import industry_chain  # pylint: disable=import-outside-toplevel
    industry_chain.fetch_all(config.CHAINS_PATH)
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'產業鏈資料：{e}')


def task_etf_external() -> None:
  try:
    import etf_hub  # pylint: disable=import-outside-toplevel
    etf_hub.sync_etf_external(force=False)
  except Exception as e:  # pylint: disable=broad-except
    PROGRESS.error(f'ETF 配息與規模：{e}')


# ---------------------------------------------------------------- runner -----

def _run_group(name: str, tasks: list[tuple[str, Callable[[], None]]], done: list[int],
               total: int) -> None:
  for label, fn in tasks:
    try:
      fn()
    except net.FetchError as e:
      PROGRESS.error(f'{label}：連線失敗 {str(e)[-120:]}')
    except Exception as e:  # pylint: disable=broad-except
      PROGRESS.error(f'{label}：{e!r}'[:300])
      traceback.print_exc()
    done[0] += 1
    PROGRESS.set(progress=round(min(0.99, done[0] / max(1, total)), 3),
                 message=f'{label}（{done[0]}/{total}）')


def _run_parallel(groups: dict[str, list[tuple[str, Callable[[], None]]]]) -> None:
  total = sum(len(v) for v in groups.values())
  done = [0]
  with ThreadPoolExecutor(max_workers=max(1, len(groups))) as ex:
    futs = [ex.submit(_run_group, k, v, done, total) for k, v in groups.items() if v]
    for f in futs:
      f.result()


def _months_back(n: int) -> list[tuple[int, int]]:
  today = now_tw().date()
  y, m = today.year, today.month - 1
  out = []
  for _ in range(n):
    if m == 0:
      y, m = y - 1, 12
    out.append((y, m))
    m -= 1
  return out


def _quarters_back(n: int) -> list[tuple[int, int]]:
  today = now_tw().date()
  y, q = today.year, (today.month - 1) // 3 + 1
  out = []
  for _ in range(n):
    out.append((y, q))
    q -= 1
    if q == 0:
      y, q = y - 1, 4
  return out


def build_groups(days: int, inst_days: int, months: int, quarters: int) -> dict[str, list]:
  dates = candidate_dates(days)
  inst_dates = dates[-inst_days:]
  newest_first = list(reversed(dates))
  today = now_tw().date()
  twse_tasks, tpex_tasks, mops_tasks, misc_tasks = [], [], [], []
  for d in newest_first:
    twse_tasks.append((f'上市行情 {d}', lambda d=d: task_twse_quotes(d)))
    tpex_tasks.append((f'上櫃行情 {d}', lambda d=d: task_tpex_quotes(d)))
  for d in reversed(inst_dates):
    twse_tasks.append((f'上市法人 {d}', lambda d=d: task_twse_inst(d)))
    tpex_tasks.append((f'上櫃法人 {d}', lambda d=d: task_tpex_inst(d)))
  last = dates[-1]
  twse_tasks.insert(1, (f'上市本益比 {last}', lambda: task_valuation(last)))
  twse_tasks.insert(2, (f'法人買賣金額 {last}', lambda: task_market_inst(last)))
  for i, (y, m) in enumerate(_months_back(months)):
    force = i < 2 and today.day <= 16
    for mk in ('sii', 'otc'):
      mops_tasks.append((f'月營收 {mk} {y}-{m:02d}', lambda mk=mk, y=y, m=m, f=force: task_revenue(mk, y, m, f)))
  for i, (y, q) in enumerate(_quarters_back(quarters)):
    for mk in ('sii', 'otc'):
      mops_tasks.append((f'財報 {mk} {y}Q{q}', lambda mk=mk, y=y, q=q, f=(i < 2): task_eps(mk, y, q, f)))
  misc_tasks += [('公司基本資料', task_profiles), ('處置/注意股', task_flags),
                 ('櫃買指數', task_tpex_index), ('營益/股利', task_margins_dividends),
                 ('除權息歷史', task_exrights), ('ETF 配息與規模', task_etf_external),
                 ('產業鏈', task_chains)]
  return {'twse': twse_tasks, 'tpex': tpex_tasks, 'mops': mops_tasks, 'misc': misc_tasks}


def _try_file_lock():
  """Cross-process exclusive lock so CLI runs and the server never overlap."""
  import fcntl  # pylint: disable=import-outside-toplevel
  os.makedirs(config.DATA_DIR, exist_ok=True)
  fh = open(os.path.join(config.DATA_DIR, 'update.lock'), 'a+')
  try:
    fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
  except OSError:
    fh.close()
    return None
  return fh


def _release_file_lock(fh) -> None:
  import fcntl  # pylint: disable=import-outside-toplevel
  try:
    fcntl.flock(fh, fcntl.LOCK_UN)
  finally:
    fh.close()


def is_running_here() -> bool:
  return _RUN_LOCK.locked()


def lock_held_elsewhere() -> bool:
  if is_running_here():
    return False
  fh = _try_file_lock()
  if fh is None:
    return True
  _release_file_lock(fh)
  return False


def run_analytics_only() -> bool:
  if not _RUN_LOCK.acquire(blocking=False):
    return False
  fh = _try_file_lock()
  if fh is None:
    _RUN_LOCK.release()
    return False
  try:
    PROGRESS.set(state='running', step='計算指標與推薦', progress=0.0, errors=[])
    _analytics()
    return True
  finally:
    PROGRESS.set(state='idle', step='', progress=1.0,
                 finished_at=now_tw().isoformat(timespec='seconds'))
    _release_file_lock(fh)
    _RUN_LOCK.release()


def run_morning_update(reason: str = '') -> bool:
  """Refreshes pre-market US quotes, global/domestic catalyst news & TW action re-judgment."""
  if not _RUN_LOCK.acquire(blocking=False):
    return False
  fh = _try_file_lock()
  if fh is None:
    _RUN_LOCK.release()
    return False
  try:
    PROGRESS.set(state='running', step='盤前美股與重大事件研判', progress=0.3, message=reason)
    import snapshot  # pylint: disable=import-outside-toplevel
    snapshot.morning_cached(force=True)
    return True
  except Exception as e:  # pylint: disable=broad-except
    traceback.print_exc()
    PROGRESS.error(f'盤前戰情更新失敗：{e!r}')
    return False
  finally:
    PROGRESS.set(state='idle', step='', progress=1.0,
                 finished_at=now_tw().isoformat(timespec='seconds'))
    _release_file_lock(fh)
    _RUN_LOCK.release()


def run_intraday_update(reason: str = '') -> bool:
  """Fetches live intraday TWSE/TPEx quotes & recomputes analytics without locking fetch_log."""
  if not _RUN_LOCK.acquire(blocking=False):
    return False
  fh = _try_file_lock()
  if fh is None:
    _RUN_LOCK.release()
    return False
  try:
    db.init()
    today = now_tw().date()
    today_s = today.isoformat()
    if not is_trading_day(today):
      return False
    if db.fetched('twse_quotes', today_s) and db.fetched('tpex_quotes', today_s):
      return False
    PROGRESS.set(state='running', step='下載盤中即時行情', progress=0.1, errors=[],
                 started_at=now_tw().isoformat(timespec='seconds'), message=reason)
    stock_rows = db.query('SELECT code, name, market FROM stocks')
    stock_meta = {c: (n or c, m or '上市') for c, n, m in stock_rows if c}
    snap = intraday.fetch_intraday_snapshot(stock_meta, today_s)
    if not snap:
      PROGRESS.error(f'盤中即時行情尚未開盤或無有效報價（{today_s}）')
      return False
    PROGRESS.set(step='寫入盤中行情快照', progress=0.35,
                 message=f'上市 {len(snap["twse_quotes"])} 檔・上櫃 {len(snap["tpex_quotes"])} 檔')
    if snap['twse_quotes']:
      _save_quotes(today_s, '上市', snap['twse_quotes'])
    if snap['tpex_quotes']:
      _save_quotes(today_s, '上櫃', snap['tpex_quotes'])
    if snap['indices']:
      db.upsert_many('index_daily', ('name', 'date', 'close', 'chg', 'pct'),
                     [(n, today_s, c, ch, p) for (n, c, ch, p) in snap['indices']])
    st = snap['stats']
    _merge_market(today_s, {
        'twse_value': st.get('twse_value'),
        'tpex_value': st.get('tpex_value'),
        'twse_up': st.get('up'),
        'twse_down': st.get('down'),
        'twse_flat': st.get('flat'),
        'twse_limit_up': st.get('limit_up'),
        'twse_limit_down': st.get('limit_down'),
    })
    _analytics(is_intraday=True, quote_time=snap.get('quote_time'))
    return True
  except Exception as e:  # pylint: disable=broad-except
    traceback.print_exc()
    PROGRESS.error(f'盤中行情更新失敗：{e!r}')
    return False
  finally:
    PROGRESS.set(state='idle', step='', progress=1.0,
                 finished_at=now_tw().isoformat(timespec='seconds'))
    _release_file_lock(fh)
    _RUN_LOCK.release()


def run_update(quick: bool = False, analytics: bool = True, reason: str = '') -> bool:
  """Fetches everything missing, then rebuilds analytics. Returns False if busy."""
  if not _RUN_LOCK.acquire(blocking=False):
    return False
  fh = _try_file_lock()
  if fh is None:
    _RUN_LOCK.release()
    return False
  try:
    db.init()
    first = db.query_one('SELECT COUNT(DISTINCT date) FROM daily')[0] < 30
    state = 'backfill' if first else 'running'
    PROGRESS.set(state=state, step='下載資料', progress=0.0, errors=[],
                 started_at=now_tw().isoformat(timespec='seconds'), message=reason)
    if first or quick:
      # Phase A: enough recent history for a first usable snapshot.
      _run_parallel(build_groups(70, 25, 13, 5))
      if analytics:
        _analytics()
      if quick:
        return True
      PROGRESS.set(state=state, step='回補歷史資料', progress=0.0)
    _run_parallel(build_groups(config.BACKFILL_DAYS, config.INST_BACKFILL_DAYS,
                               config.REVENUE_MONTHS, config.EPS_QUARTERS))
    if analytics:
      _analytics()
    return True
  finally:
    PROGRESS.set(state='idle', step='', progress=1.0,
                 finished_at=now_tw().isoformat(timespec='seconds'))
    _release_file_lock(fh)
    _RUN_LOCK.release()


def _analytics(is_intraday: bool | None = None, quote_time: str | None = None) -> None:
  PROGRESS.set(step='計算指標與推薦', message='')
  t0 = time.time()
  try:
    import snapshot  # pylint: disable=import-outside-toplevel
    snapshot.build_all(progress=PROGRESS, is_intraday=is_intraday, quote_time=quote_time)
    PROGRESS.set(step='打包 GitHub 靜態版', message='')
    try:
      from tools import build_dist  # pylint: disable=import-outside-toplevel
      build_dist.build(force=True)
    except Exception as e:  # pylint: disable=broad-except
      PROGRESS.error(f'GitHub 靜態版打包失敗：{e!r}')
    PROGRESS.set(message=f'分析完成（{time.time() - t0:.0f} 秒）')
  except Exception as e:  # pylint: disable=broad-except
    traceback.print_exc()
    PROGRESS.error(f'分析計算失敗：{e!r}')


def main() -> None:
  ap = argparse.ArgumentParser()
  ap.add_argument('--quick', action='store_true', help='only recent 70 days')
  ap.add_argument('--no-analytics', action='store_true')
  args = ap.parse_args()
  t0 = time.time()
  run_update(quick=args.quick, analytics=not args.no_analytics, reason='CLI')
  st = PROGRESS.get()
  print(f'done in {time.time() - t0:.0f}s; errors={len(st.get("errors") or [])}')
  for e in st.get('errors') or []:
    print('  ', e)


if __name__ == '__main__':
  main()
