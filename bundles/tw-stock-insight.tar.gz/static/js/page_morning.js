/* 盤前戰情室 (#/morning) — 美股夏冬令時制、隔夜收盤與盤後異動、全球／國內重大波動事件雷達（點擊看受影響台股產業與個股）、今日台股買賣操作重判 */
(function () {
  'use strict';
  var S = {
    el: null, alive: false, data: null, uni: null, refreshing: false,
    usTab: 'focus', cat: 'all', evId: '', actTab: 'buy', onlyWatch: false
  };

  var US_TABS = [
    ['focus', '重點指標'],
    ['indices', '美股指數＋恐慌'],
    ['adrs', '台灣 ADR'],
    ['tech', '科技巨頭＆AI半導體'],
    ['macro', '石油・黃金・匯率・美債'],
    ['all', '全部 26 檔']
  ];
  var FOCUS_SYMS = ['SOX', 'IXIC', 'SPX', 'DJI', 'TSM', 'ASX', 'UMC', 'NVDA', 'MU', 'AAPL', 'USO', 'USDTWD'];

  var EV_CATS = [
    ['all', '全部重大事件'],
    ['geopolitics', '🌍 戰爭／地緣／關稅'],
    ['commodity_macro', '🛢️ 石油／原物料／匯率利率'],
    ['tech_giant', '🚀 科技巨頭發布／財報'],
    ['key_figure', '🎙️ 關鍵人物談話／央行'],
    ['domestic', '🇹🇼 國內政經／產業法說']
  ];

  var ACT_TABS = [
    ['buy', '🟢 順風首選買進', '量化籌碼＋月營收雙強，且獲隔夜美股或事件順風助攻'],
    ['dip', '🟡 拉回支撐低接', '基本面與籌碼佳，惟短線乖離偏高或盤前震盪，切忌開盤追高、宜等回測支撐'],
    ['catalyst', '🔵 事件催化／避風港', '受隔夜美股或重大新聞直接催化的高流動性標的與防禦型配置'],
    ['trim', '🔴 逆風減碼／避開', '隔夜對應 ADR 或事件面偏空承壓，宜避開追價並留意停損防守位'],
    ['watch', '⭐ 自選股盤前診斷', '針對您加入自選股的標的，比對今日重大事件受惠／承壓與支撐壓力位']
  ];

  function applyQuery(q) {
    q = q || {};
    if (q.cat && EV_CATS.some(function (c) { return c[0] === q.cat; })) S.cat = q.cat;
    if (q.ev) S.evId = q.ev;
    if (q.act && ACT_TABS.some(function (t) { return t[0] === q.act; })) S.actTab = q.act;
  }

  function syncUrl() {
    replaceHash('#/morning' + buildQuery({
      cat: S.cat !== 'all' ? S.cat : '',
      ev: S.evId || '',
      act: S.actTab !== 'buy' ? S.actTab : ''
    }));
  }

  function render(params, el) {
    S.el = el;
    S.alive = true;
    applyQuery((params && params.query) || {});
    setTitle('盤前戰情');
    el.innerHTML = '<div class="ph"><h1>🌅 盤前美股與重大事件戰情</h1>' +
      '<span class="sub">整合隔夜美股收盤＋盤後異動、全球與國內重大新聞催化，重新研判今日台股買賣策略</span></div>' +
      skeleton(2, 180) + '<div class="mt">' + skeleton(2, 260) + '</div>';
    el.addEventListener('click', onClick);
    document.addEventListener('tw:watch', onWatchChange);
    return load(false);
  }

  function onWatchChange() {
    if (!S.alive || !S.data) return;
    var actBox = document.getElementById('pmActBox');
    if (actBox) setHtml(actBox, actionsSectionInner());
  }

  function load(forceNet) {
    var pMorning = forceNet
      ? api('/api/morning/refresh', {method: 'POST', cache: false}).then(function (r) { return r.morning || r; })
      : api('/api/morning');
    return Promise.all([
      pMorning,
      getUniverse().catch(function () { return null; })
    ]).then(function (res) {
      if (!S.alive) return;
      S.data = res[0];
      S.uni = res[1];
      if (isEmptyPayload(S.data)) {
        S.el.innerHTML = '<div class="ph"><h1>🌅 盤前美股與重大事件戰情</h1></div>' + buildingHtml(S.data && S.data.message);
        return;
      }
      ensureSelectedEvent();
      paint();
    });
  }

  function filteredEvents() {
    var evs = (S.data && S.data.events) || [];
    if (S.cat === 'all') return evs;
    return evs.filter(function (e) { return e.category === S.cat; });
  }

  function ensureSelectedEvent() {
    var list = filteredEvents();
    if (!list.length) { S.evId = ''; return; }
    if (!S.evId || !list.some(function (e) { return e.id === S.evId; })) {
      S.evId = list[0].id;
    }
  }

  function paint() {
    var d = S.data || {};
    var upd = d.updated_at ? d.updated_at.replace('T', ' ').slice(0, 16) : '—';
    var refreshBtn = App.isStatic ? '' :
      '<button type="button" class="btn sm primary" id="btnMorningRefresh" data-act="refresh-morning"' +
      (S.refreshing ? ' disabled' : '') + '>' +
      (S.refreshing ? '<span class="spin"></span> 更新美股與新聞中…' : '↻ 立即更新美股與新聞') + '</button>';

    S.el.innerHTML =
      '<div class="ph"><h1>🌅 盤前美股與重大事件戰情</h1>' +
      '<span class="sub">更新於 ' + esc(upd) + ' · 台股收盤基準 ' + esc(d.data_date || '—') + '</span>' +
      '<span class="sp"></span>' + refreshBtn + '</div>' +
      '<div class="campus-acad-bar"><b>🏛️ 財經學院 · 消息面與總經對照教學：</b>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/news" href="https://okayell.github.io/finance/#/track/news">📰 消息面學院（重大訊息／法說會／CPI／FOMC 總經數據）</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/glossary" href="https://okayell.github.io/finance/#/glossary">📖 財經術語百科</a></div>' +
      heroHtml(d) +
      '<section class="card mt" id="pmUsBox">' + usMarketInner(d) + '</section>' +
      '<section class="mt" id="pmEvSec">' + eventsSectionHtml(d) + '</section>' +
      '<section class="card mt" id="pmActBox">' + actionsSectionInner() + '</section>' +
      disclaimerHtml('盤前開盤推估、事件受惠／承壓產業映射與買賣操作重判皆由程式依公開新聞與歷史關聯自動推算，盤中仍須視實際開盤量價與法人動向靈活調整。');
  }

  // ------------------------------------------------------------------ Hero: Sentiment + US DST Schedule
  function heroHtml(d) {
    var dec = d.decision || {}, est = dec.taiex_est || {}, ses = d.us_session || {};
    var sc = isNum(dec.sentiment_score) ? dec.sentiment_score : 0;
    var pinPct = Math.max(2, Math.min(98, (sc + 100) / 2));
    var scCol = sc >= 15 ? 'var(--up)' : (sc <= -15 ? 'var(--down)' : '#ca8a04');
    var regCls = dec.regime_cls || '';

    var adrSpread = est.tsm_adr_spread_pct;
    var tsmUs = ((d.us_market || {}).adrs || []).find(function (q) { return q.symbol === 'TSM'; }) || {};
    var tsmPost = (tsmUs.post || {}).post_pct;
    var adrHtml = isNum(est.tsm_adr_twd)
      ? '<div class="pm-kpi"><div class="kpi-l">台積電 ADR 折合台幣 <span class="muted">（1 ADR = 5 股）</span></div>' +
        '<div class="kpi-v num ' + clsUpDown(adrSpread) + '">NT$ ' + fmtNum(est.tsm_adr_twd, 1) +
        ' <small class="muted" style="font-size:13px">（較現股溢價 ' + fmtPct(adrSpread) + '）</small></div>' +
        '<div class="kpi-s">2330 昨收 ' + fmtPrice(est['2330_close']) + ' 元 · ADR 隔夜 <b class="' + clsUpDown(tsmUs.pct) + '">' + fmtPct(tsmUs.pct) + '</b>' +
        (isNum(tsmPost) && Math.abs(tsmPost) >= 0.05 ? '（盤後 <b class="' + clsUpDown(tsmPost) + '">' + fmtPct(tsmPost) + '</b>）' : '') + '</div></div>'
      : '<div class="pm-kpi"><div class="kpi-l">台積電 ADR 折合台幣</div><div class="kpi-v muted">—</div><div class="kpi-s">等待匯率與 ADR 報價</div></div>';

    var openPts = est.est_pts, openPct = est.est_pct;
    var openHtml = isNum(openPct)
      ? '<div class="pm-kpi"><div class="kpi-l">加權指數開盤動能推估</div>' +
        '<div class="kpi-v num ' + clsUpDown(openPct) + '">' + (isNum(openPts) ? (openPts > 0 ? '+' : '') + fmtInt(openPts) + ' 點' : fmtPct(openPct)) +
        ' <small class="' + clsUpDown(openPct) + '" style="font-size:13px">（' + fmtPct(openPct) + '）</small></div>' +
        '<div class="kpi-s">前日收盤 ' + fmtNum(est.prev_close, 2) + ' · 依 TSM ADR＋費半＋那指權重推算</div></div>'
      : '<div class="pm-kpi"><div class="kpi-l">加權指數開盤動能推估</div><div class="kpi-v muted">—</div></div>';

    var isDst = !!ses.is_dst;
    var swNote = (isNum(ses.days_to_switch) && ses.days_to_switch >= 0 && ses.days_to_switch <= 25)
      ? '<div class="pm-dst-alert">⏰ <b>時制切換提醒：</b>將於 <b>' + esc(ses.next_switch_tw || '') + '</b>（約 ' +
        fmtInt(ses.days_to_switch) + ' 天後）切換為<b>美股' + esc(ses.next_season || '') + '</b>！屆時正規收盤與盤後結束時間將順延 1 小時。</div>'
      : '';

    return '<div class="grid pm-hero">' +
      '<div class="card pm-therm-card">' +
        '<div class="card-h"><h2>🧭 今日盤前多空溫度計與操作總綱</h2>' +
        '<span class="chip lg ' + esc(regCls) + '">' + esc(dec.regime || '中性震盪') + '</span>' +
        (dec.allocation ? '<span class="chip info">' + esc(dec.allocation) + '</span>' : '') + '</div>' +
        '<div class="pm-meter-wrap">' +
          '<div class="pm-meter-top"><span class="down">−100 恐慌避險</span>' +
          '<span class="pm-score-num" style="color:' + scCol + '">盤前情緒指數 <b>' + (sc > 0 ? '+' : '') + fmtNum(sc, 1) + '</b></span>' +
          '<span class="up">+100 積極偏多</span></div>' +
          '<div class="pm-meter"><span class="pm-pin" style="left:' + pinPct.toFixed(1) + '%"></span></div>' +
        '</div>' +
        '<p class="pm-advice">' + esc(dec.summary_advice || '') + '</p>' +
        '<div class="grid g2 mt-s">' + adrHtml + openHtml + '</div>' +
      '</div>' +
      '<div class="card pm-clock-card">' +
        '<div class="card-h"><h2>🕒 美股交易時間（台灣時間）</h2><span class="sp"></span>' +
        '<span class="chip info">' + (isDst ? '🌞 ' : '❄️ ') + esc(ses.season || '美股時制') + '</span>' +
        '<span class="chip">' + esc(ses.session_zh || '') + '</span></div>' +
        swNote +
        '<div class="pm-sched-grid">' +
          '<div class="pm-sched-box' + (isDst ? ' active' : '') + '">' +
            '<div class="hd"><b>🌞 夏令時間 EDT</b><span>3月第2個週日 ～ 11月第1個週日</span>' + (isDst ? '<em class="chip ok">目前適用</em>' : '') + '</div>' +
            '<ul><li><span>盤前交易</span><b class="num">16:00 ～ 21:30</b></li>' +
            '<li><span>正規開盤</span><b class="num">21:30 ～ 隔日 04:00</b></li>' +
            '<li><span>盤後交易</span><b class="num">04:00 ～ 08:00</b></li></ul>' +
          '</div>' +
          '<div class="pm-sched-box' + (!isDst ? ' active' : '') + '">' +
            '<div class="hd"><b>❄️ 冬令時間 EST</b><span>11月第1個週日 ～ 隔年3月第2個週日</span>' + (!isDst ? '<em class="chip ok">目前適用</em>' : '') + '</div>' +
            '<ul><li><span>盤前交易</span><b class="num">17:00 ～ 22:30</b></li>' +
            '<li><span>正規開盤</span><b class="num">22:30 ～ 隔日 05:00</b></li>' +
            '<li><span>盤後交易</span><b class="num">05:00 ～ 09:00</b></li></ul>' +
          '</div>' +
        '</div>' +
        '<div class="small muted mt-s">💡 系統於每個台股交易日早上 <b>07:45</b>（台股開盤前 1 小時，涵蓋美股收盤與絕大多數盤後財報異動）與 <b>08:35</b>（台指期開盤前）自動重抓並更新今日買賣策略；冬令盤後至 09:00 收盤前亦可隨時點右上角立即更新。</div>' +
      '</div>' +
    '</div>';
  }

  // ------------------------------------------------------------------ Section 1: US Overnight Quotes
  function usItemsForTab(us) {
    var all = [].concat(us.indices || [], us.adrs || [], us.tech || [], us.macro || []);
    if (S.usTab === 'indices') return us.indices || [];
    if (S.usTab === 'adrs') return us.adrs || [];
    if (S.usTab === 'tech') return us.tech || [];
    if (S.usTab === 'macro') return us.macro || [];
    if (S.usTab === 'all') return all;
    var by = {};
    all.forEach(function (q) { by[q.symbol] = q; });
    return FOCUS_SYMS.map(function (s) { return by[s]; }).filter(Boolean);
  }

  function usMarketInner(d) {
    var us = d.us_market || {};
    var list = usItemsForTab(us);
    return '<div class="card-h"><h2>🇺🇸 隔夜美股收盤與盤後即時行情</h2>' +
      '<span class="sub">含財報／突發新聞引發之盤後交易（After-Hours）漲跌</span><span class="sp"></span>' +
      '<div class="seg pm-us-seg" role="tablist">' + US_TABS.map(function (t) {
        return '<button type="button" class="' + (S.usTab === t[0] ? 'on' : '') + '" data-ustab="' + t[0] + '">' + t[1] + '</button>';
      }).join('') + '</div></div>' +
      (list.length ? '<div class="us-grid">' + list.map(usTileHtml).join('') + '</div>'
        : '<div class="empty">暫無美股報價資料</div>');
  }

  function usTileHtml(q) {
    var post = q.post || {};
    var hasPost = isNum(post.post_pct) && Math.abs(post.post_pct) >= 0.05;
    var dec = q.symbol === 'USDTWD' || q.symbol === 'USDJPY' ? 3 : 2;
    return '<div class="us-tile">' +
      '<div class="ut-top"><span class="ut-nm">' + esc(q.name) + '</span><span class="ut-sym">' + esc(q.symbol) + '</span></div>' +
      '<div class="ut-mid"><span class="ut-px num">' + fmtNum(q.price, dec) + '</span>' +
      '<span class="ut-pct num ' + clsUpDown(q.pct) + '">' + arrow(q.pct) + ' ' + fmtPct(q.pct) + '</span></div>' +
      (hasPost
        ? '<div class="ut-post"><span>盤後</span> <b class="num ' + clsUpDown(post.post_pct) + '">' +
          fmtPct(post.post_pct) + '</b> <span class="muted num">(' + fmtNum(post.post_price, 2) + ')</span></div>'
        : (q.note ? '<div class="ut-note muted">' + esc(q.note) + '</div>' : '')) +
    '</div>';
  }

  // ------------------------------------------------------------------ Section 2: Clickable Event Radar
  function polarityChip(pol, zh) {
    var cls = pol === 'bull' ? 'bull' : (pol === 'bear' ? 'bear' : 'info');
    return '<span class="chip ' + cls + '">' + esc(zh || '') + '</span>';
  }

  function severityChip(sev, zh) {
    var cls = sev === 'high' ? 'bad' : (sev === 'medium' ? 'warn' : 'ghost');
    return '<span class="chip ' + cls + '">' + esc(zh || '') + '</span>';
  }

  function eventsSectionHtml(d) {
    var allEvs = d.events || [];
    var counts = {all: allEvs.length};
    allEvs.forEach(function (e) { counts[e.category] = (counts[e.category] || 0) + 1; });
    var list = filteredEvents();

    var catBar = '<div class="presets card" style="padding:10px 12px;margin-bottom:12px">' +
      '<span class="small muted" style="margin-right:2px">🔎 事件分類篩選</span>' +
      EV_CATS.map(function (c) {
        var cnt = counts[c[0]] || 0;
        return '<button type="button" class="preset' + (S.cat === c[0] ? ' on' : '') + '" data-evcat="' + c[0] + '">' +
          c[1] + ' <span class="num" style="opacity:.75">(' + cnt + ')</span></button>';
      }).join('') + '</div>';

    var body;
    if (!list.length) {
      body = '<div class="card empty"><div class="big">📡</div><h3>此分類目前無重大波動事件</h3>' +
        '<p>可切換至「全部重大事件」檢視其他國際與國內焦點新聞。</p></div>';
    } else {
      var cur = list.find(function (e) { return e.id === S.evId; }) || list[0];
      body = '<div class="ev-layout">' +
        '<div class="ev-list" id="pmEvList">' + list.map(function (ev) { return eventCardHtml(ev, ev.id === cur.id); }).join('') + '</div>' +
        '<div class="card ev-detail" id="pmEvDetail">' + eventDetailHtml(cur) + '</div>' +
      '</div>';
    }

    return '<div class="sec-title"><h2>🌍 全球與國內重大波動事件雷達</h2>' +
      '<span class="sub">點擊左側任一事件，右側即時顯示該事件對台股哪些產業鏈與代表個股造成受惠或承壓</span></div>' +
      catBar + body;
  }

  function eventCardHtml(ev, active) {
    var benCnt = (ev.affected_stocks || []).filter(function (s) { return s.direction === 'beneficiary'; }).length;
    var hwCnt = (ev.affected_stocks || []).filter(function (s) { return s.direction === 'headwind'; }).length;
    var secNames = (ev.affected_sectors || []).slice(0, 3).map(function (s) { return s.name; }).join('、');
    return '<article class="ev-card' + (active ? ' on' : '') + '" data-ev="' + esc(ev.id) + '" tabindex="0" role="button">' +
      '<div class="ev-meta">' +
        '<span class="chip ' + (ev.region === '國內' ? 'fund' : 'ghost') + '">' + esc(ev.region || '國際') + '</span>' +
        '<span class="chip">' + esc(ev.category_label || '') + '</span>' +
        severityChip(ev.severity, ev.severity_zh) +
        polarityChip(ev.polarity, ev.polarity_zh) +
        '<span class="sp"></span>' +
        '<span class="small muted">' + esc(ev.source || '') + (ev.time ? ' · ' + esc(relTime(ev.time)) : '') + '</span>' +
      '</div>' +
      '<h3 class="ev-title">' + esc(ev.title) + '</h3>' +
      '<div class="ev-foot">' +
        '<span class="small muted">牽動產業：<b>' + esc(secNames || '台股相關供應鏈') + '</b></span>' +
        '<span class="sp"></span>' +
        (benCnt ? '<span class="small up">▲ 受惠 ' + benCnt + ' 檔</span>' : '') +
        (hwCnt ? '<span class="small down">▼ 承壓 ' + hwCnt + ' 檔</span>' : '') +
        '<span class="ev-arrow">查看影響 →</span>' +
      '</div>' +
    '</article>';
  }

  function eventDetailHtml(ev) {
    if (!ev) return '<div class="empty">請點擊左側事件查看受影響台股</div>';
    var triggers = ev.us_triggers || [];
    var secs = ev.affected_sectors || [];
    var stks = ev.affected_stocks || [];
    var benStks = stks.filter(function (s) { return s.direction === 'beneficiary'; });
    var hwStks = stks.filter(function (s) { return s.direction === 'headwind'; });

    var trigHtml = triggers.length
      ? '<div class="ev-trigs"><span class="small muted">隔夜美股連動指標：</span>' + triggers.map(function (u) {
          var ptxt = isNum(u.post_pct) && Math.abs(u.post_pct) >= 0.1 ? ' · 盤後 ' + fmtPct(u.post_pct) : '';
          return '<span class="chip ghost num"><b>' + esc(u.name) + '</b> (' + esc(u.symbol) + ') ' +
            '<span class="' + clsUpDown(u.pct) + '">' + fmtPct(u.pct) + ptxt + '</span></span>';
        }).join('') + '</div>'
      : '';

    var secHtml = secs.length
      ? '<div class="subh">🏭 受影響台股產業鏈（' + secs.length + '）</div><div class="ev-secs">' +
        secs.map(function (s) {
          var isBen = s.direction === 'beneficiary';
          return '<div class="ev-sec-item ' + (isBen ? 'ben' : 'hw') + '">' +
            '<div class="row wrap">' +
              '<span class="chip ' + (isBen ? 'bull' : 'bear') + '">' + (isBen ? '📈 受惠產業' : '📉 承壓產業') + '</span>' +
              '<b>' + esc(s.name) + '</b>' +
              (isNum(s.pct_1d) ? '<span class="small num">類股昨收 ' + pctSpan(s.pct_1d) + '</span>' : '') +
              '<span class="sp"></span>' +
              (s.chain_id ? '<a class="btn xs" href="#/industry/' + encodeURIComponent(s.chain_id) + '">🔗 產業鏈圖譜</a>' : '') +
              (s.industry ? '<a class="btn xs ghost" href="#/screener?ind=' + encodeURIComponent(s.industry) + '">🔍 篩選' + esc(s.industry) + '</a>' : '') +
            '</div>' +
            '<div class="small muted mt-xs">' + esc(s.reason || '') + '</div>' +
          '</div>';
        }).join('') + '</div>'
      : '';

    function stkTable(items, title, isBen) {
      if (!items.length) return '';
      return '<div class="subh">' + (isBen ? '📈 受惠偏多代表台股（' : '📉 逆風承壓警戒台股（') + items.length + ' 檔）</div>' +
        '<div class="tbl-wrap"><table class="tbl dense">' +
        '<thead><tr><th class="c" style="width:30px"></th><th class="l">代號／名稱</th><th class="l">受影響供應鏈角色</th>' +
        '<th>收盤</th><th>漲跌%</th><th>5日%</th><th>法人5日(張)</th><th>量化分</th></tr></thead><tbody>' +
        items.map(function (s) {
          var href = '#/stock/' + encodeURIComponent(s.code);
          var inst5 = (s.f5 || 0) + (s.t5 || 0);
          return '<tr data-href="' + href + '">' +
            '<td class="c">' + starBtn(s.code, 'icon') + '</td>' +
            '<td class="l"><a class="nm" href="' + href + '">' + esc(s.name) + '</a> <span class="code">' + esc(s.code) + '</span></td>' +
            '<td class="l wrap"><span class="small">' + esc(s.role || s.industry || '') + '</span></td>' +
            '<td>' + fmtPrice(s.close) + '</td>' +
            '<td class="' + clsUpDown(s.pct) + '">' + fmtPct(s.pct) + '</td>' +
            '<td class="' + clsUpDown(s.r5) + '">' + fmtPct(s.r5) + '</td>' +
            '<td class="' + clsUpDown(inst5) + '">' + (inst5 > 0 ? '+' : '') + fmtInt(inst5) + '</td>' +
            '<td><b style="color:' + scoreColor(s.score) + '">' + (isNum(s.score) ? Math.round(s.score) : '—') + '</b></td>' +
          '</tr>';
        }).join('') + '</tbody></table></div>';
    }

    return '<div class="ev-det-hd">' +
        '<div class="row wrap">' +
          '<span class="chip ' + (ev.region === '國內' ? 'fund' : 'ghost') + '">' + esc(ev.region || '國際') + '</span>' +
          '<span class="chip">' + esc(ev.category_label || '') + '</span>' +
          polarityChip(ev.polarity, ev.polarity_zh) +
          severityChip(ev.severity, ev.severity_zh) +
          '<span class="sp"></span>' +
          (ev.link ? '<a class="btn xs" href="' + esc(ev.link) + '" target="_blank" rel="noopener noreferrer">📰 閱讀新聞原文 ↗</a>' : '') +
        '</div>' +
        '<h3 class="ev-det-title">' + esc(ev.title) + '</h3>' +
        (ev.summary && ev.summary !== ev.title ? '<p class="small muted">' + esc(ev.summary) + '</p>' : '') +
      '</div>' +
      '<div class="ev-why"><b>🧠 台股傳導邏輯分析：</b>' + esc(ev.why_it_matters || '') + '</div>' +
      trigHtml + secHtml +
      stkTable(benStks, '受惠', true) +
      stkTable(hwStks, '承壓', false);
  }

  // ------------------------------------------------------------------ Section 3: Re-judged Actions
  function buildWatchlistDiagnostics() {
    var codes = watchList();
    if (!codes.length || !S.uni || !S.uni.by) return [];
    var evs = (S.data && S.data.events) || [];
    return codes.map(function (c) {
      var r = S.uni.by[c];
      if (!r) return null;
      var hits = [];
      var net = 0;
      evs.forEach(function (ev) {
        (ev.affected_stocks || []).forEach(function (st) {
          if (st.code === c) {
            var ben = st.direction === 'beneficiary';
            net += ben ? 1 : -1;
            hits.push((ben ? '📈 事件受惠（' + st.role + '）：' : '📉 事件逆風（' + st.role + '）：') + ev.title);
          }
        });
      });
      if (!hits.length) {
        evs.forEach(function (ev) {
          (ev.affected_sectors || []).forEach(function (sec) {
            if (sec.industry && sec.industry === r.industry && hits.length < 2) {
              var ben = sec.direction === 'beneficiary';
              net += ben ? 0.5 : -0.5;
              hits.push((ben ? '📈 所屬產業順風：' : '📉 所屬產業承壓：') + sec.name + ' — ' + ev.title.slice(0, 30));
            }
          });
        });
      }
      var verdict = net >= 1 ? '順風偏多續抱／布局' : (net <= -1 ? '逆風警戒／守停損' : ((r.bias20 || 0) > 12 ? '乖離偏大勿追高' : '依技術均線操作'));
      var sup = r.ma20 ? fmtPrice(r.ma20, r.close) + ' 元（月線）' : '近期支撐';
      var plan = net >= 1
        ? '今日具隔夜事件或產業順風催化，守穩 ' + sup + ' 可偏多看待。'
        : (net <= -1
          ? '受國際／產業事件逆風干擾，開盤不宜貿然加碼，留意 ' + sup + ' 防守力道。'
          : '目前無直接重大事件衝擊，建議觀察法人買賣超（近5日外資＋投信 ' + fmtInt((r.f5 || 0) + (r.t5 || 0)) + ' 張）並以 ' + sup + ' 為操作依據。');
      return {
        code: c, name: r.name, market: r.market, industry: r.industry,
        close: r.close, pct: r.pct, orig_score: r.score, premarket_score: r.score,
        verdict: verdict,
        levels: {support: r.ma20, resistance: r.hi52},
        catalysts: hits.slice(0, 3),
        plan: plan,
        signals: (r.signals || []).slice(0, 4)
      };
    }).filter(Boolean);
  }

  function actionsSectionInner() {
    var dec = (S.data && S.data.decision) || {};
    var acts = dec.actions || {};
    var watchItems = buildWatchlistDiagnostics();
    var counts = {
      buy: (acts.buy || []).length,
      dip: (acts.dip || []).length,
      catalyst: (acts.catalyst || []).length,
      trim: (acts.trim || []).length,
      watch: watchItems.length
    };
    var curMeta = ACT_TABS.find(function (t) { return t[0] === S.actTab; }) || ACT_TABS[0];
    var list = S.actTab === 'watch' ? watchItems : (acts[S.actTab] || []);

    var tabsHtml = '<div class="tabs pm-act-tabs" role="tablist">' + ACT_TABS.map(function (t) {
      return '<button type="button" class="' + (S.actTab === t[0] ? 'on' : '') + '" data-acttab="' + t[0] + '">' +
        t[1] + ' <span class="num muted">(' + (counts[t[0]] || 0) + ')</span></button>';
    }).join('') + '</div>';

    var body;
    if (!list.length) {
      body = S.actTab === 'watch'
        ? '<div class="empty"><div class="big">⭐</div><h3>尚未加入自選股</h3><p>在任一個股或推薦卡片點擊「☆ 加自選」，即可在此查看專屬盤前事件診斷！</p></div>'
        : '<div class="empty"><div class="big">🧭</div><h3>目前此類別無符合條件之標的</h3><p>可切換至其他策略分頁檢視操作建議。</p></div>';
    } else {
      body = '<div class="picks-grid mt">' + list.map(function (it) { return actionCardHtml(it, S.actTab); }).join('') + '</div>';
    }

    return '<div class="card-h"><h2>🧭 今日台股買賣操作重新研判</h2>' +
      '<span class="sub">結合「收盤多因子量化分數」＋「隔夜美股 ADR／費半連動」＋「重大新聞事件衝擊」重新分流今日操作</span></div>' +
      tabsHtml +
      '<div class="small muted mt-s">' + esc(curMeta[2]) + '</div>' +
      body;
  }

  function actionCardHtml(it, mode) {
    var href = '#/stock/' + encodeURIComponent(it.code);
    var L = it.levels || {};
    var vCls = mode === 'buy' ? 'bull' : (mode === 'trim' ? 'bear' : (mode === 'catalyst' ? 'info' : 'warn'));
    var delta = it.score_delta;
    var deltaHtml = isNum(delta) && Math.abs(delta) >= 0.3
      ? '<span class="small num ' + clsUpDown(delta) + '" data-tip="盤前重判分數較收盤量化分數之調整幅度">' +
        (delta > 0 ? '▲+' : '▼') + fmtNum(delta, 1) + '</span>'
      : '';
    var cats = (it.catalysts && it.catalysts.length) ? it.catalysts : (it.reasons || []);

    return '<article class="pick act-card">' +
      '<div class="pick-hd">' +
        '<div class="pick-id">' +
          '<a class="pick-name" href="' + href + '">' + esc(it.name) + ' <span class="code">' + esc(it.code) + '</span></a>' +
          '<div class="pick-meta">' +
            '<span class="chip ' + vCls + '">' + esc(it.verdict || '') + '</span>' +
            (it.market ? '<span class="chip">' + esc(it.market) + '</span>' : '') +
            (it.industry ? '<span class="chip">' + esc(it.industry) + '</span>' : '') +
            (isNum(it.orig_rank) ? '<span class="chip ghost">原推薦 #' + fmtInt(it.orig_rank) + '</span>' : '') +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;align-items:center;gap:2px">' +
          scoreRing(it.premarket_score, 48) + deltaHtml +
        '</div>' +
      '</div>' +
      '<div class="pick-px">' +
        '<span class="px ' + clsUpDown(it.pct) + '">' + fmtPrice(it.close) + '</span>' +
        '<span class="chg ' + clsUpDown(it.pct) + '">' + arrow(it.pct) + ' ' + fmtPct(it.pct) + '</span>' +
        '<span class="sp"></span>' +
        (isNum(L.support) ? '<span class="small num">支撐 <b class="sup">' + fmtPrice(L.support, it.close) + '</b></span>' : '') +
        (isNum(L.resistance) ? '<span class="small num">壓力 <b class="res">' + fmtPrice(L.resistance, it.close) + '</b></span>' : '') +
        (isNum(L.stop) ? '<span class="small num">停損 <b class="down">' + fmtPrice(L.stop, it.close) + '</b></span>' : '') +
        (isNum(L.target) ? '<span class="small num">目標 <b class="up">' + fmtPrice(L.target, it.close) + '</b></span>' : '') +
      '</div>' +
      (cats.length ? '<ul class="reasons" style="padding:8px 16px 6px;border-top:1px solid var(--line)">' +
        cats.map(function (c) { return '<li>' + esc(c) + '</li>'; }).join('') + '</ul>' : '') +
      '<div class="act-plan"><b>📋 今日操作策略：</b>' + esc(it.plan || '') + '</div>' +
      '<div class="pick-ft">' +
        ((it.signals || []).length ? '<div class="chips">' + it.signals.map(sigChip).join('') + '</div>' : '<span class="sp"></span>') +
        '<a class="btn sm primary" href="' + href + '">K 線與技術分析 →</a>' + starBtn(it.code) +
      '</div>' +
    '</article>';
  }

  // ------------------------------------------------------------------ Events
  function onClick(ev) {
    var t = ev.target;
    if (t.closest('[data-act="refresh-morning"]')) {
      if (S.refreshing || App.isStatic) return;
      S.refreshing = true;
      paint();
      load(true).then(function () {
        S.refreshing = false;
        if (S.alive) { paint(); toast('已更新最新美股報價與全球新聞催化', 'ok'); }
      }, function (e) {
        S.refreshing = false;
        if (S.alive) { paint(); toast((e && e.message) || '更新失敗', 'err'); }
      });
      return;
    }
    var ut = t.closest('[data-ustab]');
    if (ut) {
      S.usTab = ut.getAttribute('data-ustab');
      var ubox = document.getElementById('pmUsBox');
      if (ubox && S.data) setHtml(ubox, usMarketInner(S.data));
      return;
    }
    var ec = t.closest('[data-evcat]');
    if (ec) {
      S.cat = ec.getAttribute('data-evcat');
      ensureSelectedEvent();
      syncUrl();
      var esec = document.getElementById('pmEvSec');
      if (esec && S.data) setHtml(esec, eventsSectionHtml(S.data));
      return;
    }
    var card = t.closest('[data-ev]');
    if (card && !t.closest('a,button')) {
      S.evId = card.getAttribute('data-ev');
      syncUrl();
      $$('#pmEvList .ev-card', S.el).forEach(function (c) {
        c.classList.toggle('on', c.getAttribute('data-ev') === S.evId);
      });
      var cur = filteredEvents().find(function (e) { return e.id === S.evId; });
      var det = document.getElementById('pmEvDetail');
      if (det && cur) {
        setHtml(det, eventDetailHtml(cur));
        if (window.innerWidth <= 960) det.scrollIntoView({behavior: 'instant', block: 'nearest'});
      }
      return;
    }
    var at = t.closest('[data-acttab]');
    if (at) {
      S.actTab = at.getAttribute('data-acttab');
      syncUrl();
      var abox = document.getElementById('pmActBox');
      if (abox && S.data) setHtml(abox, actionsSectionInner());
    }
  }

  window.Pages.morning = {
    render: render,
    update: function (params) {
      if (!S.alive || !S.data) return false;
      applyQuery((params && params.query) || {});
      ensureSelectedEvent();
      paint();
      return true;
    },
    refresh: function () {
      if (!S.alive) return false;
      load(false);
      return true;
    },
    destroy: function () {
      S.alive = false;
      document.removeEventListener('tw:watch', onWatchChange);
      if (S.el) S.el.removeEventListener('click', onClick);
    }
  };
})();
