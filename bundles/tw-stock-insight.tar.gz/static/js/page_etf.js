/* 台股 ETF 與股利專區 (#/etf) — 除息預告行事曆（最後買進日）、近12月與年化殖利率、歷次填息率與填息天數、折溢價、規模與領息現金流試算 */
(function () {
  'use strict';
  var CATS = [
    '全部', '高股息', '市值型', '科技／半導體', '美國公債', '投資級公司債',
    '非投等／新興債', '海外股票', '主動式 ETF', '多資產／平衡', '產業／主題型', '槓桿／反向／期貨'
  ];
  var FREQS = [
    ['', '全部頻率'], ['月配', '月配'], ['雙月配', '雙月配'], ['季配', '季配'],
    ['半年配', '半年配'], ['年配', '年配'], ['不配息', '不配息']
  ];
  var COLS = [
    {k: 'star', t: '', s: false, c: true},
    {k: 'code', t: '代號', l: true},
    {k: 'name', t: 'ETF 名稱', l: true},
    {k: 'cat', t: '分類', l: true},
    {k: 'freq', t: '配息頻率', c: true},
    {k: 'close', t: '市價'},
    {k: 'pct', t: '漲跌%'},
    {k: 'premium_pct', t: '折溢價%'},
    {k: 'yld_ttm', t: '近12月殖利率'},
    {k: 'yld_ann', t: '年化配息率'},
    {k: 'div_ttm', t: '近12月股息'},
    {k: 'last_cash', t: '最近配息'},
    {k: 'last_ex_date', t: '最近除息日', c: true},
    {k: 'fill_rate', t: '填息率'},
    {k: 'avg_fill_days', t: '均填息天數'},
    {k: 'est_div', t: '試算年領息'},
    {k: 'aum', t: '規模(億)'}
  ];

  var PAGE = 150;
  var S = {
    el: null, alive: false, data: null, rows: [], limit: PAGE,
    calTab: 'upcoming', kpiFilter: 'all',
    q: '', cat: '全部', freq: '', month: 0, noPrem: false, onlyWatch: false,
    capitalWan: 100, sort: 'aum', dir: 'desc', modalCode: ''
  };

  function applyQuery(q) {
    q = q || {};
    S.cat = q.cat && CATS.indexOf(q.cat) >= 0 ? q.cat : '全部';
    S.freq = q.freq || '';
    S.month = parseInt(q.m || '0', 10) || 0;
    S.q = q.q || '';
    S.kpiFilter = q.kpi || 'all';
    S.sort = q.sort || 'aum';
    S.dir = q.dir === 'asc' ? 'asc' : 'desc';
    S.modalCode = q.code ? String(q.code).toUpperCase() : '';
  }

  function syncUrl() {
    replaceHash('#/etf' + buildQuery({
      cat: S.cat !== '全部' ? S.cat : '',
      freq: S.freq,
      m: S.month || '',
      q: S.q.trim(),
      kpi: S.kpiFilter !== 'all' ? S.kpiFilter : '',
      sort: S.sort !== 'aum' ? S.sort : '',
      dir: S.dir !== 'desc' ? S.dir : '',
      code: S.modalCode || ''
    }));
  }

  function render(params, el) {
    S.el = el;
    S.alive = true;
    S.limit = PAGE;
    applyQuery((params && params.query) || {});
    setTitle('ETF 與股利專區');
    el.innerHTML = '<div class="ph"><h1>💰 台股 ETF 與股利專區</h1>' +
      '<span class="sub">彙整全台股上市櫃 ETF 除息行事曆、最後買進日、近12月／年化殖利率、填息勝率與折溢價</span></div>' +
      skeleton(3, 140) + '<div class="mt">' + skeleton(1, 360) + '</div>';
    el.addEventListener('click', onClick);
    el.addEventListener('input', onInput);
    el.addEventListener('change', onChange);
    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('tw:watch', onWatchChange);
    return api('/api/etfs').then(function (d) {
      if (!S.alive) return;
      S.data = d;
      if (isEmptyPayload(d)) {
        S.el.innerHTML = '<div class="ph"><h1>💰 台股 ETF 與股利專區</h1></div>' + buildingHtml(d && d.message);
        return;
      }
      paint();
      if (S.modalCode) openEtfModal(S.modalCode, true);
    });
  }

  function onWatchChange() {
    if (!S.alive || !S.data) return;
    if (S.onlyWatch) filterAndPaintTable();
  }

  function fmtAumTotal(yi) {
    if (!isNum(yi)) return '—';
    return yi >= 10000 ? fmtNum(yi / 10000, 2) + ' 兆' : fmtYi(yi) + ' 億';
  }

  function estAnnualDiv(it) {
    var yld = isNum(it.yld_ttm) ? it.yld_ttm : (isNum(it.yld_ann) ? it.yld_ann : null);
    if (!isNum(yld) || yld <= 0 || !isNum(S.capitalWan) || S.capitalWan <= 0) return null;
    return Math.round(S.capitalWan * 10000 * yld / 100);
  }

  function paint() {
    var d = S.data || {}, sum = d.summary || {};
    var etfs = d.etfs || [];
    var fill80Cnt = etfs.filter(function (x) { return isNum(x.fill_rate) && x.fill_rate >= 80 && (x.div_count_ttm || 0) >= 1; }).length;
    var mqCnt = (sum.frequencies && ((sum.frequencies['月配'] || 0) + (sum.frequencies['季配'] || 0))) || 0;

    S.el.innerHTML =
      '<div class="ph"><h1>💰 台股 ETF 與股利專區</h1>' +
      '<span class="sub">資料日期 ' + esc(d.date || '—') + ' · 收錄上市櫃 ' + fmtInt(sum.total_etfs || etfs.length) +
      ' 檔 ETF（點擊任一列可查看歷次除息、發放日、填息天數與領息試算）</span></div>' +

      // KPI filter cards
      '<div class="kpis etf-kpis" id="etfKpis">' +
        kpiCard('all', '📊 全台股 ETF 總覽', fmtInt(sum.total_etfs || etfs.length) + ' 檔', '總資產規模 ' + fmtAumTotal(sum.total_aum) + ' · 點擊顯示全部') +
        kpiCard('high_yld', '💰 高殖利率（≥ 5%）', fmtInt(sum.high_yield_count || 0) + ' 檔', '近12月現金殖利率 ≥ 5% · 點擊依殖利率排序') +
        kpiCard('upcoming', '📅 即將除息預告', fmtInt((d.upcoming || []).length) + ' 檔', '已公告除息日與最後買進日 · 點擊篩選搶息標的') +
        kpiCard('mq', '🗓️ 月配＋季配熱門', fmtInt(mqCnt) + ' 檔', '月配 ' + fmtInt((sum.frequencies || {})['月配'] || 0) + ' · 季配 ' + fmtInt((sum.frequencies || {})['季配'] || 0) + ' · 打造穩定現金流') +
        kpiCard('fill80', '⚡ 高填息勝率（≥ 80%）', fmtInt(fill80Cnt) + ' 檔', '真正把股息放進口袋、不賺股息賠價差') +
      '</div>' +

      // Dividend Calendar Card
      '<section class="card mt" id="etfCalBox">' + calendarInner(d) + '</section>' +

      // Filter + Cashflow Calculator Card
      '<section class="card mt etf-ctrl">' + controlsInner(sum) + '</section>' +

      // Main ETF Table
      '<section class="card flush mt" id="etfRes">' +
        '<div class="res-h" id="etfResHead"></div>' +
        '<div class="tbl-wrap etf-tbl-wrap" id="etfTblBox"></div>' +
      '</section>' +

      disclaimerHtml('ETF 配息率與過去填息表現不代表未來配息保證；買進前請特別留意「折溢價%」（溢價超過 1% 代表市價高於淨值，有追高收斂風險）與配息組成。') +
      '<div class="modal-bd hidden" id="etfModal" role="dialog" aria-modal="true" aria-label="ETF 股利明細"></div>';

    filterAndPaintTable();
  }

  function kpiCard(id, label, val, sub) {
    return '<button type="button" class="kpi etf-kpi-btn' + (S.kpiFilter === id ? ' on' : '') + '" data-kpi="' + id + '">' +
      '<div class="kpi-l">' + label + '</div><div class="kpi-v num">' + val + '</div><div class="kpi-s">' + esc(sub) + '</div></button>';
  }

  // ------------------------------------------------------------------ Dividend Calendar
  function calendarInner(d) {
    var up = d.upcoming || [], rec = d.recent_ex || [];
    var isUp = S.calTab === 'upcoming';
    var head = '<div class="card-h"><h2>📅 ETF 除息與領息行事曆</h2>' +
      '<span class="sub">' + (isUp ? '欲參與配息請於「最後買進日」收盤前買進；除息日當日買進不享本次配息' : '追蹤近 3 週除息 ETF 之填息進度與股利發放日') + '</span>' +
      '<span class="sp"></span><div class="seg" role="tablist">' +
        '<button type="button" class="' + (isUp ? 'on' : '') + '" data-caltab="upcoming">即將除息預告 (' + up.length + ')</button>' +
        '<button type="button" class="' + (!isUp ? 'on' : '') + '" data-caltab="recent">近期已除息 (' + rec.length + ')</button>' +
      '</div></div>';

    if (isUp) {
      if (!up.length) return head + '<div class="empty">目前尚無已公告之即將除息 ETF 預告</div>';
      return head + '<div class="tbl-wrap"><table class="tbl dense">' +
        '<thead><tr><th class="c">倒數</th><th class="c">最後買進日</th><th class="c">除息交易日</th>' +
        '<th class="l">代號／名稱</th><th class="l">分類 · 頻率</th><th>市價</th><th>每單位配息</th>' +
        '<th>每張領息</th><th>單次配息率</th><th>近12月殖利率</th><th class="c">發放日</th><th>折溢價%</th></tr></thead><tbody>' +
        up.slice(0, 25).map(function (u) {
          var cashTxt = isNum(u.cash)
            ? '<b class="up">' + fmtNum(u.cash, 3) + ' 元</b>'
            : '<span class="muted small">待二階確認' + (isNum(u.prev_cash) ? '（前次 ' + fmtNum(u.prev_cash, 3) + '）' : '') + '</span>';
          var sheetTxt = isNum(u.cash) ? 'NT$ ' + fmtInt(Math.round(u.cash * 1000)) : '—';
          var premWarn = isNum(u.premium_pct) && u.premium_pct > 1.0;
          var dLeft = isNum(u.days_left) ? (u.days_left <= 2 ? '<span class="chip bad">' + u.days_left + ' 天</span>' : '<span class="chip info">' + u.days_left + ' 天</span>') : '—';
          return '<tr class="etf-row-click" data-etf="' + esc(u.code) + '">' +
            '<td class="c">' + dLeft + '</td>' +
            '<td class="c"><b style="color:var(--accent)">' + esc(u.last_buy_date || '—') + '</b></td>' +
            '<td class="c">' + esc(u.ex_date || '—') + '</td>' +
            '<td class="l"><span class="nm">' + esc(u.name) + '</span> <span class="code">' + esc(u.code) + '</span></td>' +
            '<td class="l"><span class="chip">' + esc(u.cat) + '</span> <span class="chip ghost">' + esc(u.freq) + '</span></td>' +
            '<td>' + fmtPrice(u.close) + '</td>' +
            '<td>' + cashTxt + '</td>' +
            '<td>' + sheetTxt + '</td>' +
            '<td>' + (isNum(u.period_yld) ? fmtPct(u.period_yld, 2, true) : '—') + '</td>' +
            '<td><b class="' + ((u.yld_ttm || 0) >= 5 ? 'up' : '') + '">' + (isNum(u.yld_ttm) ? fmtPct(u.yld_ttm, 2, true) : '—') + '</b></td>' +
            '<td class="c">' + esc(u.pay_date || '待公告') + '</td>' +
            '<td class="' + (premWarn ? 'up' : clsUpDown(u.premium_pct)) + '">' +
              (isNum(u.premium_pct) ? fmtPct(u.premium_pct) + (premWarn ? ' ⚠' : '') : '—') + '</td>' +
          '</tr>';
        }).join('') + '</tbody></table></div>';
    }

    if (!rec.length) return head + '<div class="empty">近 21 日無除息紀錄</div>';
    return head + '<div class="tbl-wrap"><table class="tbl dense">' +
      '<thead><tr><th class="c">除息日</th><th class="l">代號／名稱</th><th class="l">分類 · 頻率</th>' +
      '<th>最新市價</th><th>每單位配息</th><th>每張領息</th><th>單次配息率</th><th class="c">股利發放日</th><th class="c">填息進度</th></tr></thead><tbody>' +
      rec.map(function (r) {
        var stChip = r.status === '已填息'
          ? '<span class="chip ok">✓ 已填息（' + fmtInt(r.fill_days) + ' 天）</span>'
          : '<span class="chip warn">⏳ ' + esc(r.status || '貼息中') + '</span>';
        return '<tr class="etf-row-click" data-etf="' + esc(r.code) + '">' +
          '<td class="c">' + esc(r.ex_date || '—') + '</td>' +
          '<td class="l"><span class="nm">' + esc(r.name) + '</span> <span class="code">' + esc(r.code) + '</span></td>' +
          '<td class="l"><span class="chip">' + esc(r.cat) + '</span> <span class="chip ghost">' + esc(r.freq) + '</span></td>' +
          '<td>' + fmtPrice(r.close) + '</td>' +
          '<td><b>' + (isNum(r.cash) ? fmtNum(r.cash, 3) + ' 元' : '—') + '</b></td>' +
          '<td>' + (isNum(r.cash) ? 'NT$ ' + fmtInt(Math.round(r.cash * 1000)) : '—') + '</td>' +
          '<td>' + (isNum(r.period_yld) ? fmtPct(r.period_yld, 2, true) : '—') + '</td>' +
          '<td class="c">' + esc(r.pay_date || '待公告') + '</td>' +
          '<td class="c">' + stChip + '</td>' +
        '</tr>';
      }).join('') + '</tbody></table></div>';
  }

  // ------------------------------------------------------------------ Controls + Cashflow Calculator
  function controlsInner(sum) {
    var catCounts = (sum && sum.categories) || {};
    var months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    return '<div class="etf-ctrl-grid">' +
      '<div class="row wrap">' +
        '<span class="small muted" style="min-width:60px">ETF 類型</span>' +
        '<div class="chips" id="etfCatBar">' + CATS.map(function (c) {
          var cnt = c === '全部' ? (sum.total_etfs || 0) : (catCounts[c] || 0);
          return '<button type="button" class="preset' + (S.cat === c ? ' on' : '') + '" data-ecat="' + esc(c) + '">' +
            esc(c) + ' <span class="num" style="opacity:.7">(' + cnt + ')</span></button>';
        }).join('') + '</div>' +
      '</div>' +

      '<div class="row wrap">' +
        '<span class="small muted" style="min-width:60px">配息頻率</span>' +
        '<div class="seg" id="etfFreqBar">' + FREQS.map(function (f) {
          return '<button type="button" class="' + (S.freq === f[0] ? 'on' : '') + '" data-efreq="' + esc(f[0]) + '">' + f[1] + '</button>';
        }).join('') + '</div>' +
        '<span class="small muted" style="margin-left:8px">除息月份（組月月領息）</span>' +
        '<div class="chips" id="etfMonthBar">' +
          '<button type="button" class="chip tag-toggle' + (S.month === 0 ? ' on' : '') + '" data-emonth="0">不限</button>' +
          months.map(function (m) {
            return '<button type="button" class="chip tag-toggle' + (S.month === m ? ' on' : '') + '" data-emonth="' + m + '">' + m + '月</button>';
          }).join('') +
        '</div>' +
      '</div>' +

      '<div class="row wrap etf-calc-row">' +
        '<input class="input" id="etfQ" type="search" placeholder="搜尋 ETF 代號、名稱、投信或追蹤指數…" value="' + esc(S.q) + '" autocomplete="off" style="width:250px;max-width:100%">' +
        '<label class="check"><input type="checkbox" id="etfNoPrem"' + (S.noPrem ? ' checked' : '') + '> 排除溢價 &gt; 1%</label>' +
        '<label class="check"><input type="checkbox" id="etfOnlyWatch"' + (S.onlyWatch ? ' checked' : '') + '> 只看自選 ETF</label>' +
        '<span class="sp"></span>' +
        '<div class="etf-calc-box">' +
          '<span>💰 存股領息試算：投入</span>' +
          '<input class="input num" id="etfCapInput" type="number" min="1" max="99999" step="10" value="' + esc(S.capitalWan) + '" aria-label="投入本金萬元" style="width:78px;height:28px;text-align:right;font-weight:700">' +
          '<span>萬元</span>' +
          '<div class="chips">' + [10, 50, 100, 300].map(function (w) {
            return '<button type="button" class="chip' + (S.capitalWan === w ? ' info' : ' ghost') + '" data-cap="' + w + '">' + w + '萬</button>';
          }).join('') + '</div>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  // ------------------------------------------------------------------ Table Filtering & Sorting
  function filterAndPaintTable() {
    var list = ((S.data && S.data.etfs) || []).slice();
    var q = S.q.trim().toLowerCase();

    if (S.kpiFilter === 'high_yld') list = list.filter(function (x) { return (x.yld_ttm || 0) >= 5.0; });
    else if (S.kpiFilter === 'upcoming') list = list.filter(function (x) { return !!x.upcoming; });
    else if (S.kpiFilter === 'mq') list = list.filter(function (x) { return x.freq === '月配' || x.freq === '季配'; });
    else if (S.kpiFilter === 'fill80') list = list.filter(function (x) { return isNum(x.fill_rate) && x.fill_rate >= 80 && (x.div_count_ttm || 0) >= 1; });

    if (S.cat !== '全部') list = list.filter(function (x) { return x.cat === S.cat; });
    if (S.freq) list = list.filter(function (x) { return x.freq === S.freq; });
    if (S.month > 0) list = list.filter(function (x) { return (x.ex_months || []).indexOf(S.month) >= 0; });
    if (S.noPrem) list = list.filter(function (x) { return !isNum(x.premium_pct) || x.premium_pct <= 1.0; });
    if (S.onlyWatch) list = list.filter(function (x) { return watchHas(x.code); });
    if (q) {
      list = list.filter(function (x) {
        var hay = (x.code + ' ' + (x.name || '') + ' ' + (x.issuer || '') + ' ' + (x.index_name || '') + ' ' + (x.cat || '')).toLowerCase();
        return hay.indexOf(q) >= 0;
      });
    }

    var sk = S.sort, mul = S.dir === 'asc' ? 1 : -1;
    list.sort(function (a, b) {
      var va = sk === 'est_div' ? estAnnualDiv(a) : a[sk];
      var vb = sk === 'est_div' ? estAnnualDiv(b) : b[sk];
      var na = va === null || va === undefined || va === '';
      var nb = vb === null || vb === undefined || vb === '';
      if (na && nb) return 0;
      if (na) return 1;
      if (nb) return -1;
      if (typeof va === 'string' || typeof vb === 'string') return String(va).localeCompare(String(vb)) * mul;
      return (va - vb) * mul;
    });

    S.rows = list;
    paintResHead();
    paintTable();
  }

  function paintResHead() {
    var h = document.getElementById('etfResHead');
    if (!h) return;
    var active = [];
    if (S.kpiFilter !== 'all') {
      var kNames = {high_yld: '高殖利率 ≥5%', upcoming: '即將除息', mq: '月配＋季配', fill80: '填息率 ≥80%'};
      active.push('<span class="chip info" data-clear="kpi">' + esc(kNames[S.kpiFilter] || S.kpiFilter) + '</span>');
    }
    if (S.cat !== '全部') active.push('<span class="chip info" data-clear="cat">' + esc(S.cat) + '</span>');
    if (S.freq) active.push('<span class="chip info" data-clear="freq">' + esc(S.freq) + '</span>');
    if (S.month > 0) active.push('<span class="chip info" data-clear="month">' + S.month + '月除息</span>');
    if (S.noPrem) active.push('<span class="chip info" data-clear="noPrem">排除溢價&gt;1%</span>');
    if (S.onlyWatch) active.push('<span class="chip info" data-clear="onlyWatch">自選 ETF</span>');
    if (S.q.trim()) active.push('<span class="chip info" data-clear="q">關鍵字：' + esc(S.q.trim()) + '</span>');

    setHtml(h,
      '<span class="count">符合條件 <b>' + fmtInt(S.rows.length) + '</b> 檔 ETF</span>' +
      '<div class="active-f">' + active.join('') + '</div>' +
      (active.length ? '<button type="button" class="btn xs" data-act="reset-etf">重設篩選</button>' : '') +
      '<span class="small muted">💡 點擊任一 ETF 列開啟「歷次股利、填息天數與領息試算」明細</span>');
  }

  function paintTable() {
    var box = document.getElementById('etfTblBox');
    if (!box) return;
    if (!S.rows.length) {
      setHtml(box, '<div class="empty"><div class="big">🔍</div><h3>沒有符合篩選條件的 ETF</h3><p>請放寬配息頻率、月份或關鍵字條件再試一次。</p></div>');
      return;
    }
    var shown = S.rows.slice(0, S.limit);
    var thead = '<thead><tr>' + COLS.map(function (c) {
      var cls = [c.l ? 'l' : (c.c ? 'c' : ''), c.s === false ? '' : 'sortable', S.sort === c.k ? 'sorted' + (S.dir === 'asc' ? ' asc' : '') : ''].filter(Boolean).join(' ');
      return '<th' + (cls ? ' class="' + cls + '"' : '') + (c.s === false ? '' : ' data-esort="' + c.k + '"') + '>' + esc(c.t) + '</th>';
    }).join('') + '</tr></thead>';

    var tbody = '<tbody>' + shown.map(function (it) {
      var annCash = estAnnualDiv(it);
      var premWarn = isNum(it.premium_pct) && it.premium_pct > 1.0;
      var freqCls = it.freq === '月配' ? 'fund' : (it.freq === '季配' ? 'info' : 'ghost');
      var upBadge = it.upcoming ? ' <span class="chip bad" data-tip="即將除息：' + esc(it.upcoming.ex_date) + '（最後買進 ' + esc(it.upcoming.last_buy_date || '') + '）">即將除息</span>' : '';
      return '<tr class="etf-row-click" data-etf="' + esc(it.code) + '">' +
        '<td class="c">' + starBtn(it.code, 'icon') + '</td>' +
        '<td class="l"><span class="code">' + esc(it.code) + '</span></td>' +
        '<td class="l"><span class="nm">' + esc(it.name) + '</span>' + upBadge + '</td>' +
        '<td class="l"><span class="chip">' + esc(it.cat) + '</span></td>' +
        '<td class="c"><span class="chip ' + freqCls + '">' + esc(it.freq) + '</span></td>' +
        '<td>' + fmtPrice(it.close) + '</td>' +
        '<td class="' + clsUpDown(it.pct) + '">' + fmtPct(it.pct) + '</td>' +
        '<td class="' + (premWarn ? 'up' : clsUpDown(it.premium_pct)) + '">' +
          (isNum(it.premium_pct) ? fmtPct(it.premium_pct) + (premWarn ? ' ⚠' : '') : '—') + '</td>' +
        '<td><b class="' + ((it.yld_ttm || 0) >= 5 ? 'up' : '') + '">' + (isNum(it.yld_ttm) ? fmtPct(it.yld_ttm, 2, true) : '—') + '</b></td>' +
        '<td>' + (isNum(it.yld_ann) ? fmtPct(it.yld_ann, 2, true) : '—') + '</td>' +
        '<td>' + (isNum(it.div_ttm) ? fmtNum(it.div_ttm, 2) + ' 元' : '—') + '</td>' +
        '<td>' + (isNum(it.last_cash) ? fmtNum(it.last_cash, 3) + ' 元' : '—') + '</td>' +
        '<td class="c">' + esc(it.last_ex_date || '—') + '</td>' +
        '<td>' + (isNum(it.fill_rate) ? '<span class="' + (it.fill_rate >= 80 ? 'up' : '') + '">' + fmtNum(it.fill_rate, 0) + '%</span>' : '—') + '</td>' +
        '<td>' + (isNum(it.avg_fill_days) ? fmtNum(it.avg_fill_days, 1) + ' 天' : '—') + '</td>' +
        '<td>' + (isNum(annCash) ? '<b class="up">NT$ ' + fmtInt(annCash) + '</b>' : '—') + '</td>' +
        '<td>' + (isNum(it.aum) ? fmtYi(it.aum) : '—') + '</td>' +
      '</tr>';
    }).join('') + '</tbody>';

    var more = S.rows.length > S.limit
      ? '<div class="more-row"><button type="button" class="btn sm" data-act="more-etf">載入更多（尚有 ' + fmtInt(S.rows.length - S.limit) + ' 檔）</button></div>'
      : '';
    setHtml(box, '<table class="tbl dense">' + thead + tbody + '</table>' + more);
  }

  // ------------------------------------------------------------------ ETF Dividend Detail Modal
  function openEtfModal(code, silentHash) {
    if (!S.data) return;
    var it = (S.data.etfs || []).find(function (x) { return x.code === code; });
    var bd = document.getElementById('etfModal');
    if (!it || !bd) return;
    S.modalCode = code;
    if (!silentHash) syncUrl();

    var annCash = estAnnualDiv(it);
    var monCash = isNum(annCash) ? Math.round(annCash / 12) : null;
    var sheets = (isNum(it.close) && it.close > 0 && isNum(S.capitalWan))
      ? (S.capitalWan * 10000 / (it.close * 1000))
      : null;

    var hist = (it.history || []).slice();
    var chartChrono = hist.filter(function (h) { return isNum(h.cash) && h.cash > 0; }).slice().reverse();
    var chartHtml = chartChrono.length >= 2
      ? '<div class="subh">📈 歷次配息金額（左軸：元）與單次配息率（右軸：%）</div>' +
        '<div class="legend-row"><span><i style="background:#3b82f6"></i>每單位現金股利 (元)</span>' +
        '<span><i class="ln" style="background:#f59e0b"></i>單次配息率 (%)</span></div>' +
        svgBarLine({
          w: 760, h: 210,
          labels: chartChrono.map(function (h) { return h.ex_date; }),
          bars: chartChrono.map(function (h) { return h.cash; }),
          barColor: function () { return '#60a5fa'; },
          barFmt: function (v) { return fmtNum(v, 2); },
          line: chartChrono.map(function (h) { return h.period_yld; }),
          lineColor: '#f59e0b',
          lineFmt: function (v) { return fmtNum(v, 1) + '%'; },
          xLabel: function (i) { return chartChrono[i].ex_date.slice(2, 7); },
          tip: function (i) {
            var h = chartChrono[i];
            return h.ex_date + '\n配息：' + fmtNum(h.cash, 3) + ' 元' +
              (isNum(h.period_yld) ? '\n單次配息率：' + fmtPct(h.period_yld, 2, true) : '') +
              (h.status ? '\n填息狀態：' + h.status + (isNum(h.fill_days) ? '（' + h.fill_days + ' 天）' : '') : '');
          }
        })
      : '';

    var upBanner = '';
    if (it.upcoming) {
      var u = it.upcoming;
      upBanner = '<div class="etf-up-banner">' +
        '<b>📅 即將除息預告：</b>除息日 <b>' + esc(u.ex_date) + '</b>（最後買進日 <b style="color:var(--accent)">' +
        esc(u.last_buy_date || '—') + '</b>）· 每單位配息 ' +
        (isNum(u.cash) ? '<b class="up">' + fmtNum(u.cash, 3) + ' 元</b>（每張領 NT$ ' + fmtInt(Math.round(u.cash * 1000)) + '）'
          : '<b>待第二階段確認公告</b>') +
        (u.pay_date ? ' · 股利發放日 ' + esc(u.pay_date) : '') + '</div>';
    }

    var premWarn = isNum(it.premium_pct) && it.premium_pct > 1.0;
    var exMonthsTxt = (it.ex_months || []).length ? it.ex_months.map(function (m) { return m + '月'; }).join('、') : '不固定／無紀錄';

    var histTbl = hist.length
      ? '<div class="subh">📋 歷次除息、發放日與填息天數明細（近 ' + hist.length + ' 次）</div>' +
        '<div class="tbl-wrap"><table class="tbl dense">' +
        '<thead><tr><th class="c">除息交易日</th><th class="c">股利發放日</th><th>每單位配息</th><th>每張領息</th>' +
        '<th>除息前收盤</th><th>單次配息率</th><th class="c">填息狀態</th><th>填息天數</th></tr></thead><tbody>' +
        hist.map(function (h) {
          var stChip = h.status === '已填息'
            ? '<span class="chip ok">✓ 已填息</span>'
            : (h.status === '即將除息' ? '<span class="chip info">即將除息</span>'
              : (h.status === '貼息中' ? '<span class="chip warn">⏳ 貼息中</span>' : '<span class="chip ghost">' + esc(h.status || '已除息') + '</span>'));
          return '<tr>' +
            '<td class="c">' + esc(h.ex_date || '—') + '</td>' +
            '<td class="c">' + esc(h.pay_date || '—') + '</td>' +
            '<td><b>' + (isNum(h.cash) ? fmtNum(h.cash, 4) + ' 元' : '待確認') + '</b></td>' +
            '<td>' + (isNum(h.cash) ? 'NT$ ' + fmtInt(Math.round(h.cash * 1000)) : '—') + '</td>' +
            '<td>' + fmtPrice(h.prev_close) + '</td>' +
            '<td>' + (isNum(h.period_yld) ? fmtPct(h.period_yld, 2, true) : '—') + '</td>' +
            '<td class="c">' + stChip + '</td>' +
            '<td>' + (isNum(h.fill_days) ? fmtInt(h.fill_days) + ' 個交易日' : '—') + '</td>' +
          '</tr>';
        }).join('') + '</tbody></table></div>'
      : '<div class="empty">此 ETF 為不配息型或掛牌後尚無除息紀錄</div>';

    bd.innerHTML =
      '<div class="modal" tabindex="-1">' +
        '<div class="modal-h">' +
          '<div class="modal-ttl">' +
            '<div class="row wrap">' +
              '<h2>' + esc(it.name) + ' <span class="mono muted" style="font-size:15px">' + esc(it.code) + '</span></h2>' +
              '<span class="chip">' + esc(it.market) + '</span>' +
              '<span class="chip info">' + esc(it.cat) + '</span>' +
              '<span class="chip fund">' + esc(it.freq) + '</span>' +
            '</div>' +
            '<p class="small muted">' +
              '發行投信：<b>' + esc(it.issuer || '—') + '</b>' +
              (it.index_name ? ' · 追蹤指數：<b>' + esc(it.index_name) + '</b>' : '') +
              (it.listed ? ' · 掛牌日期：' + esc(it.listed) : '') +
            '</p>' +
          '</div>' +
          starBtn(it.code) +
          '<a class="btn sm primary" href="#/stock/' + encodeURIComponent(it.code) + '">📈 K 線與技術分析 →</a>' +
          '<button type="button" class="btn sm" data-act="close-etf-modal" aria-label="關閉">✕</button>' +
        '</div>' +
        '<div class="modal-b">' +
          upBanner +
          '<div class="val-cards">' +
            '<div class="val-card"><div class="l">市價 ／ 淨值 (NAV)</div>' +
              '<div class="v ' + clsUpDown(it.pct) + '">' + fmtPrice(it.close) + ' <small style="font-size:13px">(' + fmtPct(it.pct) + ')</small></div>' +
              '<div class="s">淨值 ' + (isNum(it.nav) ? fmtNum(it.nav, 2) : '—') + ' · 折溢價 <b class="' + (premWarn ? 'up' : clsUpDown(it.premium_pct)) + '">' +
              (isNum(it.premium_pct) ? fmtPct(it.premium_pct) + (premWarn ? '（溢價偏高）' : '') : '—') + '</b></div></div>' +
            '<div class="val-card"><div class="l">近 12 月殖利率</div>' +
              '<div class="v ' + ((it.yld_ttm || 0) >= 5 ? 'up' : '') + '">' + (isNum(it.yld_ttm) ? fmtPct(it.yld_ttm, 2, true) : '—') + '</div>' +
              '<div class="s">近 12 月合計配息 <b>' + (isNum(it.div_ttm) ? fmtNum(it.div_ttm, 3) + ' 元' : '—') + '</b>（' + fmtInt(it.div_count_ttm || 0) + ' 次）</div></div>' +
            '<div class="val-card"><div class="l">最新年化配息率</div>' +
              '<div class="v">' + (isNum(it.yld_ann) ? fmtPct(it.yld_ann, 2, true) : '—') + '</div>' +
              '<div class="s">除息月份：' + esc(exMonthsTxt) + '</div></div>' +
            '<div class="val-card"><div class="l">歷史填息勝率</div>' +
              '<div class="v">' + (isNum(it.fill_rate) ? fmtNum(it.fill_rate, 0) + '%' : '—') + '</div>' +
              '<div class="s">平均填息花費 <b>' + (isNum(it.avg_fill_days) ? fmtNum(it.avg_fill_days, 1) + ' 交易日' : '—') + '</b></div></div>' +
            '<div class="val-card"><div class="l">資產規模 ／ 受益人數</div>' +
              '<div class="v">' + (isNum(it.aum) ? fmtYi(it.aum) + ' 億' : '—') + '</div>' +
              '<div class="s">受益人 ' + (isNum(it.holders) ? fmtCompact(it.holders) + ' 人' : '—') + '</div></div>' +
            '<div class="val-card" style="background:#f8fafc;border-color:#bfdbfe"><div class="l">💰 投入 ' + fmtInt(S.capitalWan) + ' 萬元領息試算</div>' +
              '<div class="v up">' + (isNum(annCash) ? 'NT$ ' + fmtInt(annCash) + ' /年' : '不適用') + '</div>' +
              '<div class="s">' + (isNum(monCash) ? '約可買 ' + fmtNum(sheets, 1) + ' 張 · 平均月領 <b>NT$ ' + fmtInt(monCash) + '</b>' : '無配息紀錄') + '</div></div>' +
          '</div>' +
          chartHtml +
          histTbl +
        '</div>' +
      '</div>';

    bd.classList.remove('hidden');
    document.body.classList.add('modal-open');
  }

  function closeEtfModal() {
    var bd = document.getElementById('etfModal');
    if (bd) bd.classList.add('hidden');
    document.body.classList.remove('modal-open');
    if (S.modalCode) {
      S.modalCode = '';
      syncUrl();
    }
  }

  // ------------------------------------------------------------------ Event Handlers
  function onKeyDown(ev) {
    if (ev.key === 'Escape' && S.modalCode) closeEtfModal();
  }

  function refreshControlsOnly() {
    $$('#etfKpis [data-kpi]', S.el).forEach(function (b) {
      b.classList.toggle('on', b.getAttribute('data-kpi') === S.kpiFilter);
    });
    $$('#etfCatBar [data-ecat]', S.el).forEach(function (b) {
      b.classList.toggle('on', b.getAttribute('data-ecat') === S.cat);
    });
    $$('#etfFreqBar [data-efreq]', S.el).forEach(function (b) {
      b.classList.toggle('on', b.getAttribute('data-efreq') === S.freq);
    });
    $$('#etfMonthBar [data-emonth]', S.el).forEach(function (b) {
      b.classList.toggle('on', (+b.getAttribute('data-emonth')) === S.month);
    });
  }

  function onClick(ev) {
    var t = ev.target;
    if (t.id === 'etfModal' || t.closest('[data-act="close-etf-modal"]')) {
      closeEtfModal();
      return;
    }
    var kpi = t.closest('[data-kpi]');
    if (kpi) {
      var id = kpi.getAttribute('data-kpi');
      S.kpiFilter = (S.kpiFilter === id && id !== 'all') ? 'all' : id;
      if (S.kpiFilter === 'high_yld') { S.sort = 'yld_ttm'; S.dir = 'desc'; }
      else if (S.kpiFilter === 'fill80') { S.sort = 'fill_rate'; S.dir = 'desc'; }
      else if (S.kpiFilter === 'all') { S.cat = '全部'; S.freq = ''; S.month = 0; S.sort = 'aum'; S.dir = 'desc'; }
      S.limit = PAGE;
      refreshControlsOnly();
      syncUrl();
      filterAndPaintTable();
      return;
    }
    var ct = t.closest('[data-caltab]');
    if (ct) {
      S.calTab = ct.getAttribute('data-caltab');
      var cbox = document.getElementById('etfCalBox');
      if (cbox && S.data) setHtml(cbox, calendarInner(S.data));
      return;
    }
    var ec = t.closest('[data-ecat]');
    if (ec) {
      S.cat = ec.getAttribute('data-ecat');
      S.limit = PAGE;
      refreshControlsOnly();
      syncUrl();
      filterAndPaintTable();
      return;
    }
    var ef = t.closest('[data-efreq]');
    if (ef) {
      S.freq = ef.getAttribute('data-efreq');
      S.limit = PAGE;
      refreshControlsOnly();
      syncUrl();
      filterAndPaintTable();
      return;
    }
    var em = t.closest('[data-emonth]');
    if (em) {
      var m = +em.getAttribute('data-emonth');
      S.month = (S.month === m) ? 0 : m;
      S.limit = PAGE;
      refreshControlsOnly();
      syncUrl();
      filterAndPaintTable();
      return;
    }
    var cap = t.closest('[data-cap]');
    if (cap) {
      S.capitalWan = +cap.getAttribute('data-cap');
      var inp = document.getElementById('etfCapInput');
      if (inp) inp.value = String(S.capitalWan);
      $$('[data-cap]', S.el).forEach(function (b) {
        var on = (+b.getAttribute('data-cap')) === S.capitalWan;
        b.className = 'chip ' + (on ? 'info' : 'ghost');
      });
      filterAndPaintTable();
      return;
    }
    var clr = t.closest('[data-clear]');
    if (clr) {
      var k = clr.getAttribute('data-clear');
      if (k === 'kpi') S.kpiFilter = 'all';
      else if (k === 'cat') S.cat = '全部';
      else if (k === 'freq') S.freq = '';
      else if (k === 'month') S.month = 0;
      else if (k === 'noPrem') { S.noPrem = false; var cb1 = document.getElementById('etfNoPrem'); if (cb1) cb1.checked = false; }
      else if (k === 'onlyWatch') { S.onlyWatch = false; var cb2 = document.getElementById('etfOnlyWatch'); if (cb2) cb2.checked = false; }
      else if (k === 'q') { S.q = ''; var qi = document.getElementById('etfQ'); if (qi) qi.value = ''; }
      refreshControlsOnly();
      syncUrl();
      filterAndPaintTable();
      return;
    }
    if (t.closest('[data-act="reset-etf"]')) {
      S.kpiFilter = 'all'; S.cat = '全部'; S.freq = ''; S.month = 0; S.noPrem = false; S.onlyWatch = false; S.q = '';
      var qEl = document.getElementById('etfQ'); if (qEl) qEl.value = '';
      var pEl = document.getElementById('etfNoPrem'); if (pEl) pEl.checked = false;
      var wEl = document.getElementById('etfOnlyWatch'); if (wEl) wEl.checked = false;
      refreshControlsOnly();
      syncUrl();
      filterAndPaintTable();
      return;
    }
    var srt = t.closest('[data-esort]');
    if (srt) {
      var sk = srt.getAttribute('data-esort');
      if (S.sort === sk) S.dir = S.dir === 'desc' ? 'asc' : 'desc';
      else { S.sort = sk; S.dir = sk === 'code' || sk === 'name' || sk === 'avg_fill_days' ? 'asc' : 'desc'; }
      syncUrl();
      filterAndPaintTable();
      return;
    }
    if (t.closest('[data-act="more-etf"]')) {
      S.limit += PAGE;
      paintTable();
      return;
    }
    var row = t.closest('[data-etf]');
    if (row && !t.closest('a,button,input')) {
      openEtfModal(row.getAttribute('data-etf'), false);
    }
  }

  var onSearchDebounced = debounce(function () {
    S.limit = PAGE;
    syncUrl();
    filterAndPaintTable();
  }, 120);

  function onInput(ev) {
    if (ev.target.id === 'etfQ') {
      S.q = ev.target.value;
      onSearchDebounced();
    } else if (ev.target.id === 'etfCapInput') {
      var v = parseFloat(ev.target.value);
      if (isFinite(v) && v > 0) {
        S.capitalWan = v;
        $$('[data-cap]', S.el).forEach(function (b) {
          b.className = 'chip ' + ((+b.getAttribute('data-cap')) === S.capitalWan ? 'info' : 'ghost');
        });
        paintTable();
      }
    }
  }

  function onChange(ev) {
    if (ev.target.id === 'etfNoPrem') {
      S.noPrem = ev.target.checked;
      filterAndPaintTable();
    } else if (ev.target.id === 'etfOnlyWatch') {
      S.onlyWatch = ev.target.checked;
      filterAndPaintTable();
    }
  }

  window.Pages.etf = {
    render: render,
    update: function (params) {
      if (!S.alive || !S.data) return false;
      var prevModal = S.modalCode;
      applyQuery((params && params.query) || {});
      refreshControlsOnly();
      filterAndPaintTable();
      if (S.modalCode && S.modalCode !== prevModal) openEtfModal(S.modalCode, true);
      else if (!S.modalCode && prevModal) closeEtfModal();
      return true;
    },
    destroy: function () {
      S.alive = false;
      document.body.classList.remove('modal-open');
      document.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('tw:watch', onWatchChange);
      if (S.el) {
        S.el.removeEventListener('click', onClick);
        S.el.removeEventListener('input', onInput);
        S.el.removeEventListener('change', onChange);
      }
    }
  };
})();
