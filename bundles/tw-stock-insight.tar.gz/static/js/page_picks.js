/* 績效追蹤 (#/picks) — backtest KPIs, equity curve, horizons, live pick history, method. */
(function () {
  'use strict';
  var P = {el: null, alive: false, chart: null, ro: null, d: null, showN: 10};
  var LINES = [['策略（每期前 N 名等權）', '#2563eb', 1], ['加權指數', '#94a3b8', 2], ['全市場等權', '#f59e0b', 3]];

  function isNum(v) { return App.isNum(v); }
  function kpi(label, val, sub, cls, tip) {
    return '<div class="kpi"' + (tip ? ' data-tip="' + esc(tip) + '"' : '') + '><div class="kpi-l">' + label + '</div><div class="kpi-v ' + (cls || '') + '">' + val + '</div>' +
      (sub ? '<div class="kpi-s">' + sub + '</div>' : '') + '</div>';
  }
  function pctCls(v) { return clsUpDown(v); }

  function render(params, el) {
    P.el = el;
    P.alive = true;
    P.showN = 10;
    setTitle('績效追蹤');
    el.innerHTML = head() + skeleton(3, 140);
    el.addEventListener('click', onClick);
    return api('/api/picks').then(function (d) {
      if (!P.alive) return;
      P.d = d;
      paint();
    });
  }
  function head() {
    return '<div class="ph"><h1>績效追蹤</h1><span class="sub">用歷史資料檢驗「今日推薦」模型：如果每期都買進推薦股，表現如何？</span></div>';
  }
  function paint() {
    var d = P.d;
    if (isEmptyPayload(d)) { P.el.innerHTML = head() + buildingHtml(d.message); return; }
    var bt = d.backtest || {}, hasBt = bt && isNum(bt.avg_ret);
    var html = head();
    if (hasBt) {
      html += '<div class="kpis">' +
        kpi('回測期間', esc(App.fmtMD(bt.start) + ' – ' + App.fmtMD(bt.end)), esc((bt.start || '').slice(0, 4)) + ' 年起・' + fmtInt(bt.samples) + ' 期樣本') +
        kpi('策略平均報酬', fmtPct(bt.avg_ret), '每期持有 ' + fmtInt(bt.hold_days) + ' 個交易日・前 ' + fmtInt(bt.top_n) + ' 名', pctCls(bt.avg_ret), '每期等權買進推薦前 N 名，持有固定天數的平均報酬') +
        (isNum(bt.ew_avg_ret) ? kpi('全市場等權平均', fmtPct(bt.ew_avg_ret), '同期間所有合格股票', pctCls(bt.ew_avg_ret), '比較基準：同一期間所有合格股票的等權平均報酬，比加權指數更公平') : '') +
        kpi('加權指數平均', fmtPct(bt.bench_avg_ret), '同期間大盤', pctCls(bt.bench_avg_ret)) +
        (isNum(bt.excess_ew) ? kpi('超額報酬（vs 等權）', fmtPct(bt.excess_ew), 'vs 加權指數 ' + fmtPct(bt.excess), pctCls(bt.excess_ew)) :
          kpi('超額報酬（vs 大盤）', fmtPct(bt.excess), '', pctCls(bt.excess))) +
        kpi('勝率', isNum(bt.win_rate) ? fmtNum(bt.win_rate, 1) + '%' : '—', '報酬為正的比例', bt.win_rate >= 50 ? 'up' : 'down') + '</div>' +
        (bt.note ? '<div class="small muted mt-s">ℹ️ ' + esc(bt.note) + '</div>' : '') +
        '<section class="card mt"><div class="card-h"><h2>📈 累積報酬曲線</h2><span class="sub">起點 = 0%，滑鼠移到圖上看每期數值</span><span class="sp"></span>' +
        '<div class="legend-row" style="margin:0">' + LINES.filter(function (l) { return hasCol(bt, l[2]); }).map(function (l) {
          return '<span><i class="ln" style="background:' + l[1] + '"></i>' + l[0].replace('N', bt.top_n || 'N') + '</span>';
        }).join('') + '</div></div><div style="position:relative"><div class="eq-chart" id="eqChart"></div><div class="kc-legend" id="eqLegend"></div></div></section>' +
        horizonsHtml(bt);
    } else {
      html += '<div class="card empty"><div class="big">⏳</div><h3>回測資料累積中</h3><p>需要足夠的歷史資料才能計算回測績效，資料建立完成後會自動顯示。</p></div>';
    }
    html += historyHtml(d.history || []) + methodHtml(d.method || {}) +
      '<div class="footer-note">⚠️ ' + esc(d.disclaimer || App.disclaimer()) + '<br>回測結果為歷史模擬，未來市場狀況可能完全不同；過去績效不代表未來報酬。</div>';
    P.el.innerHTML = html;
    if (hasBt) drawEquity(bt);
  }
  function hasCol(bt, i) { return (bt.equity || []).some(function (r) { return isNum(r[i]); }); }
  function horizonsHtml(bt) {
    var hz = bt.horizons || [];
    if (!hz.length) return '';
    var hasEw = hz.some(function (h) { return isNum(h.ew); });
    return '<section class="card mt"><div class="card-h"><h2>⏱ 不同持有天數</h2><span class="sub">持有越久，報酬與勝率怎麼變化？</span></div><div class="tbl-wrap"><table class="tbl"><thead><tr>' +
      '<th class="l">持有天數</th><th>策略平均報酬</th><th>勝率</th>' + (hasEw ? '<th>全市場等權</th><th>超額（vs 等權）</th>' : '') + '<th>加權指數</th><th>超額（vs 大盤）</th><th>樣本數</th></tr></thead><tbody>' +
      hz.map(function (h) {
        var exEw = isNum(h.ew) && isNum(h.avg_ret) ? h.avg_ret - h.ew : null, ex = isNum(h.bench) && isNum(h.avg_ret) ? h.avg_ret - h.bench : null;
        return '<tr><td class="l"><b>' + fmtInt(h.days) + ' 日</b></td><td class="' + pctCls(h.avg_ret) + '"><b>' + fmtPct(h.avg_ret) + '</b></td><td>' +
          (isNum(h.win_rate) ? fmtNum(h.win_rate, 1) + '%' : '—') + '</td>' + (hasEw ? '<td class="' + pctCls(h.ew) + '">' + fmtPct(h.ew) + '</td><td class="' + pctCls(exEw) + '">' + fmtPct(exEw) + '</td>' : '') +
          '<td class="' + pctCls(h.bench) + '">' + fmtPct(h.bench) + '</td><td class="' + pctCls(ex) + '">' + fmtPct(ex) + '</td><td>' + fmtInt(h.samples) + '</td></tr>';
      }).join('') + '</tbody></table></div></section>';
  }
  function historyHtml(hist) {
    var head = '<section class="card mt"><div class="card-h"><h2>🗂 歷史推薦清單</h2><span class="sub">每天的推薦股從推薦日收盤到最新收盤的報酬</span></div>';
    if (!hist.length) return head + '<div class="empty">尚無歷史推薦紀錄（網站啟用後每天會累積一筆）。</div></section>';
    var list = hist.slice(0, P.showN);
    return head + '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="l">推薦日</th><th class="c">類型</th><th>平均報酬</th><th>大盤</th><th>超額</th><th class="l">個股報酬（推薦日收盤 → 最新）</th></tr></thead><tbody>' +
      list.map(function (h) {
        var ex = isNum(h.avg_ret) && isNum(h.bench_ret) ? h.avg_ret - h.bench_ret : null;
        var items = (h.items || []).slice().sort(function (a, b) { return (b.ret || 0) - (a.ret || 0); });
        return '<tr><td class="l"><b>' + esc(h.date) + '</b></td><td class="c"><span class="chip ' + (h.kind === '實盤' ? 'info' : 'ghost') + '" data-tip="' +
          (h.kind === '實盤' ? '網站當天實際產生的推薦' : '網站啟用前，以相同模型回推的推薦') + '">' + esc(h.kind || '—') + '</span></td><td class="' + pctCls(h.avg_ret) + '"><b>' + fmtPct(h.avg_ret) +
          '</b></td><td class="' + pctCls(h.bench_ret) + '">' + fmtPct(h.bench_ret) + '</td><td class="' + pctCls(ex) + '">' + fmtPct(ex) + '</td><td class="l wrap"><div class="hist-items">' +
          items.map(function (it) {
            return '<a href="#/stock/' + encodeURIComponent(it.code) + '" data-tip="' + esc(it.code + ' ' + it.name + '\n推薦日 ' + fmtPrice(it.entry) + ' → 最新 ' + fmtPrice(it.last)) + '">' +
              esc(it.name) + ' <span class="' + pctCls(it.ret) + '">' + fmtPct(it.ret, 1) + '</span></a>';
          }).join('') + '</div></td></tr>';
      }).join('') + '</tbody></table></div>' +
      (hist.length > P.showN ? '<div class="more-row"><button type="button" class="btn sm" data-act="more-hist">顯示更多（' + P.showN + ' / ' + hist.length + '）</button></div>' : '') + '</section>';
  }
  function methodHtml(m) {
    var w = m.weights || {}, names = App.FACTOR_NAME || {};
    var keys = (App.FACTORS || []).map(function (f) { return f[0]; }).filter(function (k) { return k in w || true; });
    keys.sort(function (a, b) { return (w[b] || 0) - (w[a] || 0); });
    var maxW = Math.max.apply(null, keys.map(function (k) { return w[k] || 0; }).concat([0.01]));
    return '<section class="card mt"><div class="card-h"><h2>🧠 選股方法</h2><span class="sub">參考 FinLab「籌碼強度 × 月營收動能」研究</span></div>' +
      '<div class="grid g2"><div>' + (m.text ? '<p style="line-height:1.8;color:var(--text-2)">' + esc(m.text) + '</p>' : '') +
      ((m.filters || []).length ? '<div class="subh">篩選條件</div><ul class="risk-list">' + m.filters.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ul>' : '') +
      '</div><div><div class="subh" style="margin-top:0">因子權重</div><div class="wbars">' + keys.map(function (k) {
        var wt = w[k] || 0;
        return '<div class="wbar' + (wt ? '' : ' ref') + '"><span>' + esc(names[k] || k) + '</span><span class="tr"><span class="fl" style="width:' +
          (wt ? Math.max(4, wt * 100 / maxW) : 0).toFixed(0) + '%"></span></span><b>' + (wt ? Math.round(wt * 100) + '%' : '<span class="chip ghost" style="height:18px">參考</span>') + '</b></div>';
      }).join('') + '</div><p class="small muted mt">各因子先換算成全市場百分位（0–100），再依權重加總成綜合分數；權重 0% 的因子只顯示供參考，不影響排名。</p></div></div></section>';
  }
  function drawEquity(bt) {
    var box = document.getElementById('eqChart'), LC = window.LightweightCharts;
    if (!box || !LC) return;
    var rows = (bt.equity || []).filter(function (r) { return r && r[0]; });
    if (rows.length < 2) { box.innerHTML = '<div class="empty">資料點不足</div>'; return; }
    var chart = LC.createChart(box, {
      width: box.clientWidth || 800, height: 320,
      layout: {background: {type: 'solid', color: '#fff'}, textColor: '#475569', fontSize: 11, fontFamily: getComputedStyle(document.body).fontFamily, attributionLogo: false},
      grid: {vertLines: {color: '#f3f5f8'}, horzLines: {color: '#f3f5f8'}},
      rightPriceScale: {borderColor: '#e5e7eb'},
      timeScale: {borderColor: '#e5e7eb', fixLeftEdge: true, fixRightEdge: true, tickMarkFormatter: function (t, type) {
        var y = typeof t === 'string' ? +t.slice(0, 4) : t.year, m = typeof t === 'string' ? +t.slice(5, 7) : t.month, d = typeof t === 'string' ? +t.slice(8, 10) : t.day;
        return type === 0 ? y + '年' : (type === 1 ? m + '月' : m + '/' + d);
      }},
      localization: {locale: 'zh-TW', dateFormat: 'yyyy-MM-dd'}, crosshair: {mode: LC.CrosshairMode.Normal},
      handleScroll: false, handleScale: false
    });
    var fmt = {type: 'custom', minMove: 0.01, formatter: function (v) { return (v > 0 ? '+' : '') + v.toFixed(1) + '%'; }};
    var series = [];
    LINES.forEach(function (l) {
      if (!hasCol(bt, l[2])) return;
      var s = chart.addLineSeries({color: l[1], lineWidth: l[2] === 1 ? 3 : 2, priceFormat: fmt, priceLineVisible: false, lastValueVisible: true});
      s.setData(rows.filter(function (r) { return isNum(r[l[2]]); }).map(function (r) { return {time: r[0], value: (r[l[2]] - 1) * 100}; }));
      series.push([l, s]);
    });
    series[0][1].createPriceLine({price: 0, color: '#cbd5e1', lineWidth: 1, lineStyle: LC.LineStyle.Dashed, axisLabelVisible: false, title: ''});
    chart.timeScale().fitContent();
    var legend = document.getElementById('eqLegend');
    var show = function (i) {
      var r = rows[i];
      if (!r || !legend) return;
      legend.innerHTML = '<span class="t">' + esc(r[0]) + '</span>' + series.map(function (x) {
        var v = r[x[0][2]];
        return isNum(v) ? '<span style="color:' + x[0][1] + '">' + esc(x[0][0].split('（')[0]) + ' <b>' + fmtPct((v - 1) * 100, 1) + '</b></span>' : '';
      }).join('');
    };
    var byTime = {};
    rows.forEach(function (r, i) { byTime[r[0]] = i; });
    chart.subscribeCrosshairMove(function (p) {
      var t = p && p.time;
      var key = typeof t === 'string' ? t : (t && t.year ? t.year + '-' + String(t.month).padStart(2, '0') + '-' + String(t.day).padStart(2, '0') : null);
      show(key && byTime[key] !== undefined ? byTime[key] : rows.length - 1);
    });
    show(rows.length - 1);
    P.chart = chart;
    P.ro = new ResizeObserver(App.debounce(function () { if (P.chart) P.chart.resize(box.clientWidth, 320); }, 60));
    P.ro.observe(box);
  }

  function onClick(ev) {
    if (ev.target.closest('[data-act="more-hist"]')) {
      P.showN += 10;
      var y = window.scrollY;
      destroyChart();
      paint();
      window.scrollTo({top: y, left: 0, behavior: 'instant'});
    }
  }
  function destroyChart() {
    if (P.ro) { P.ro.disconnect(); P.ro = null; }
    if (P.chart) { try { P.chart.remove(); } catch (e) { /* ignore */ } P.chart = null; }
  }

  window.Pages.picks = {
    render: render,
    destroy: function () {
      P.alive = false;
      destroyChart();
      if (P.el) P.el.removeEventListener('click', onClick);
    }
  };
})();
