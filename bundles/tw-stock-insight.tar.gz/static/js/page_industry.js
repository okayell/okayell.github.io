/* 產業 (#/industry) — 類股表現 + 產業鏈 list; chain detail (#/industry/<id>) with upstream → downstream flow. */
(function () {
  'use strict';
  var PERIODS = [['1d', '今日', 'pct_1d'], ['5d', '5日', 'pct_5d'], ['20d', '20日', 'pct_20d']];
  var PFIELD = {'1d': 'pct_1d', '5d': 'pct_5d', '20d': 'pct_20d'};
  var I = {el: null, alive: false, data: null, tab: 'sectors', p: '1d', sort: 'value', dir: 'desc', cq: '', csort: 'default'};

  function isNum(v) { return App.isNum(v); }
  function segBtns(attr, opts, cur) {
    return '<div class="seg">' + opts.map(function (o) {
      return '<button type="button" class="' + (o[0] === cur ? 'on' : '') + '" data-' + attr + '="' + o[0] + '">' + o[1] + '</button>';
    }).join('') + '</div>';
  }

  // ================================================================== #/industry
  function render(params, el) {
    var q = params.query || {};
    I.el = el;
    I.alive = true;
    I.tab = q.tab === 'chains' ? 'chains' : 'sectors';
    I.p = PFIELD[q.p] ? q.p : '1d';
    setTitle('產業');
    el.innerHTML = head() + skeleton(2, 220);
    el.addEventListener('click', onClick);
    el.addEventListener('input', onInput);
    return api('/api/industries').then(function (d) {
      if (!I.alive) return;
      I.data = d;
      paint();
    });
  }
  function head() {
    return '<div class="ph"><h1>產業</h1><span class="sub">官方產業類股的漲跌與資金流向，以及櫃買中心整理的上中下游產業鏈</span></div>';
  }
  function paint() {
    var d = I.data;
    if (isEmptyPayload(d)) { I.el.innerHTML = head() + buildingHtml(d.message); return; }
    I.el.innerHTML = head() + '<div class="card flush"><div class="tabs" style="padding:0 8px">' +
      '<button type="button" class="' + (I.tab === 'sectors' ? 'on' : '') + '" data-itab="sectors">📊 類股表現</button>' +
      '<button type="button" class="' + (I.tab === 'chains' ? 'on' : '') + '" data-itab="chains">🔗 產業鏈（' + (d.chains || []).length + '）</button></div>' +
      '<div style="padding:16px" id="indBody"></div></div>' + disclaimerHtml();
    paintBody();
  }
  function syncUrl() {
    App.replaceHash('#/industry' + buildQuery({tab: I.tab === 'chains' ? 'chains' : '', p: I.p !== '1d' ? I.p : ''}));
  }
  function paintBody() {
    var body = document.getElementById('indBody');
    if (!body) return;
    setHtml(body, I.tab === 'sectors' ? sectorsHtml() : chainsHtml());
    if (I.tab === 'sectors') layoutHeat();
    syncUrl();
  }

  // ------------------------------------------------------------------ sectors
  var SCOLS = [['name', '類股', 1], ['count', '家數'], ['pct_1d', '今日'], ['pct_5d', '5日'], ['pct_20d', '20日'],
    ['value', '成交值(億)'], ['value_share', '占比'], ['updown', '漲／跌'], ['avg_pe', '本益比'], ['avg_yld', '殖利率'], ['top', '代表股', 1, 1]];
  function sectorsHtml() {
    var cats = (I.data.categories || []).slice(), pf = PFIELD[I.p];
    var key = I.sort, dir = I.dir === 'asc' ? 1 : -1;
    cats.sort(function (a, b) {
      var x = key === 'updown' ? (a.up || 0) - (a.down || 0) : a[key], y = key === 'updown' ? (b.up || 0) - (b.down || 0) : b[key];
      if (typeof x === 'string') return x.localeCompare(y, 'zh-Hant') * dir;
      if (!isNum(x) || !isNum(y)) return isNum(x) ? -1 : (isNum(y) ? 1 : 0);
      return (x - y) * dir;
    });
    var uni = App.uniCached();
    var nameOf = function (code) { var r = uni && uni.by[code]; return r ? r.name : code; };
    var rows = cats.map(function (c) {
      var tops = (c.leaders && c.leaders.length ? c.leaders.map(function (l) { return {code: l.code, name: l.name, pct: l.pct}; }) :
        (c.top || []).map(function (code) { var r = uni && uni.by[code]; return {code: code, name: nameOf(code), pct: r ? r.pct : null}; })).slice(0, 3);
      return '<tr data-href="#/screener?ind=' + encodeURIComponent(c.name) + '"><td class="l nm">' + esc(c.name) + '</td><td>' + fmtInt(c.count) + '</td>' +
        ['pct_1d', 'pct_5d', 'pct_20d'].map(function (k) {
          return '<td class="' + clsUpDown(c[k]) + '">' + (k === pf ? '<b>' + fmtPct(c[k]) + '</b>' : fmtPct(c[k])) + '</td>';
        }).join('') + '<td>' + fmtYi(c.value) +
        '</td><td>' + (isNum(c.value_share) ? fmtNum(c.value_share, 1) + '%' : '—') + '</td><td><span class="up">' + fmtInt(c.up) + '</span> / <span class="down">' +
        fmtInt(c.down) + '</span></td><td>' + fmtNum(c.avg_pe, 1) + '</td><td>' + (isNum(c.avg_yld) ? fmtNum(c.avg_yld, 2) + '%' : '—') + '</td><td class="l"><div class="sigs">' +
        tops.map(function (t) {
          return '<a class="chip" href="#/stock/' + encodeURIComponent(t.code) + '">' + esc(t.name) + (isNum(t.pct) ? ' <span class="' + clsUpDown(t.pct) + '">' + fmtPct(t.pct, 1) + '</span>' : '') + '</a>';
        }).join('') + '</div></td></tr>';
    }).join('');
    return '<div class="row wrap" style="margin-bottom:12px"><b>漲跌期間</b>' + segBtns('per', PERIODS, I.p) +
      '<span class="small muted">類股漲跌幅以成交值加權；點擊色塊或列可在選股器查看該產業個股</span></div>' +
      '<div class="heat" id="indHeat" style="height:380px"></div>' +
      '<div class="tbl-wrap mt"><table class="tbl dense"><thead><tr>' + SCOLS.map(function (c) {
        var on = I.sort === c[0];
        return '<th class="' + (c[2] ? 'l ' : '') + (c[3] ? '' : 'sortable ') + (on ? 'sorted ' + (I.dir === 'asc' ? 'asc' : '') : '') + (c[0] === pf ? ' sel' : '') + '"' +
          (c[3] ? '' : ' data-ssort="' + c[0] + '"') + '>' + c[1] + '</th>';
      }).join('') + '</tr></thead><tbody>' + rows + '</tbody></table></div>';
  }
  function layoutHeat() {
    var box = document.getElementById('indHeat');
    if (!box || !I.data) return;
    var pf = PFIELD[I.p];
    var cats = (I.data.categories || []).filter(function (c) { return (c.value || 0) > 0; }).sort(function (a, b) { return b.value - a.value; });
    var W = box.clientWidth || 900, H = box.clientHeight || 380, rects = treemap(cats, W, H), scale = I.p === '1d' ? 4 : (I.p === '5d' ? 8 : 15);
    box.innerHTML = cats.map(function (c, i) {
      var r = rects[i];
      if (!r) return '';
      var col = heatColor(c[pf], scale), small = r.w < 86 || r.h < 44, tiny = r.w < 46 || r.h < 26;
      var tip = c.name + '\n今日 ' + fmtPct(c.pct_1d) + '・5日 ' + fmtPct(c.pct_5d) + '・20日 ' + fmtPct(c.pct_20d) + '\n成交值 ' + fmtYi(c.value) + ' 億（' +
        fmtNum(c.value_share, 1) + '%）\n上漲 ' + fmtInt(c.up) + ' / 下跌 ' + fmtInt(c.down) + '（共 ' + fmtInt(c.count) + ' 檔）';
      return '<div class="tile' + (small ? ' sm' : '') + '" data-href="#/screener?ind=' + encodeURIComponent(c.name) + '" data-tip="' + esc(tip) + '" style="left:' +
        (r.x / W * 100).toFixed(3) + '%;top:' + (r.y / H * 100).toFixed(3) + '%;width:' + (r.w / W * 100).toFixed(3) + '%;height:' + (r.h / H * 100).toFixed(3) +
        '%;background:' + col.bg + ';color:' + col.fg + '">' + (tiny ? '' : '<b>' + esc(c.name.replace(/業$/, '')) + '</b><span>' + fmtPct(c[pf]) + '</span>') + '</div>';
    }).join('');
  }

  // ------------------------------------------------------------------ chains list
  function chainsHtml() {
    var chains = (I.data.chains || []).slice(), pf = PFIELD[I.p], q = I.cq.trim();
    if (!chains.length) {
      return '<div class="empty"><div class="big">🔗</div><h3>產業鏈資料建立中</h3><p>系統會從櫃買中心產業價值鏈資訊平台下載 47 條產業鏈，完成後自動顯示。</p></div>';
    }
    if (q) chains = chains.filter(function (c) { return (c.name || '').indexOf(q) >= 0 || (c.id || '').toLowerCase().indexOf(q.toLowerCase()) >= 0; });
    if (I.csort === 'pct') chains.sort(function (a, b) { return (b[pf] || -999) - (a[pf] || -999); });
    else if (I.csort === 'value') chains.sort(function (a, b) { return (b.value || 0) - (a.value || 0); });
    else if (I.csort === 'companies') chains.sort(function (a, b) { return (b.companies || 0) - (a.companies || 0); });
    return '<div class="row wrap" style="margin-bottom:12px"><input class="input" id="chainQ" type="search" placeholder="搜尋產業鏈（例如：半導體、電動車）" value="' + esc(I.cq) +
      '" style="width:260px" autocomplete="off">' + segBtns('per', PERIODS, I.p) + '<span class="small muted">排序</span>' +
      segBtns('csort', [['default', '預設'], ['pct', '漲幅'], ['value', '成交值'], ['companies', '公司數']], I.csort) + '</div>' +
      (chains.length ? '<div class="chain-grid">' + chains.map(function (c) {
        return '<a class="chain-card" href="#/industry/' + encodeURIComponent(c.id) + '"><div class="hd"><b>' + esc(c.name) + '</b><span class="p ' + clsUpDown(c[pf]) + '">' + fmtPct(c[pf]) + '</span></div>' +
          '<div class="meta"><span>' + fmtInt(c.companies) + ' 家公司</span><span>上市櫃 ' + fmtInt(c.listed) + '</span>' + (isNum(c.value) ? '<span>成交 ' + fmtYi(c.value) + ' 億</span>' : '') + '</div>' +
          '<div class="pp">' + PERIODS.map(function (p) {
            return '<div class="' + (p[2] === pf ? 'sel' : '') + '"><span>' + p[1] + '</span><b class="' + clsUpDown(c[p[2]]) + '">' + fmtPct(c[p[2]], 1) + '</b></div>';
          }).join('') + '</div>' +
          '<div class="chips">' + (c.streams || []).map(function (s) { return '<span class="chip ghost">' + esc(s) + '</span>'; }).join('') + '</div></a>';
      }).join('') + '</div>' : '<div class="empty">找不到「' + esc(q) + '」相關的產業鏈</div>') +
      '<div class="small muted mt">資料來源：<a href="https://ic.tpex.org.tw/" target="_blank" rel="noopener noreferrer">櫃買中心 產業價值鏈資訊平台</a>；漲跌幅為鏈上公司成交值加權平均。</div>';
  }

  function onClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-itab]'))) {
      I.tab = x.getAttribute('data-itab');
      $$('[data-itab]', I.el).forEach(function (b) { b.classList.toggle('on', b === x); });
      paintBody();
      return;
    }
    if ((x = t.closest('[data-per]'))) { I.p = x.getAttribute('data-per'); paintBody(); return; }
    if ((x = t.closest('[data-csort]'))) { I.csort = x.getAttribute('data-csort'); paintBody(); return; }
    if ((x = t.closest('[data-ssort]'))) {
      var k = x.getAttribute('data-ssort');
      if (I.sort === k) I.dir = I.dir === 'desc' ? 'asc' : 'desc';
      else { I.sort = k; I.dir = k === 'name' ? 'asc' : 'desc'; }
      paintBody();
    }
  }
  var chainFilterLater = App.debounce(function () {
    var body = document.getElementById('indBody');
    if (!body || I.tab !== 'chains') return;
    var input = document.getElementById('chainQ'), pos = input ? input.selectionStart : 0;
    paintBody();
    var again = document.getElementById('chainQ');
    if (again) { again.focus({preventScroll: true}); try { again.setSelectionRange(pos, pos); } catch (e) { /* ignore */ } }
  }, 160);
  function onInput(ev) {
    if (ev.target.id === 'chainQ') { I.cq = ev.target.value; chainFilterLater(); }
  }
  var onResize = App.debounce(function () { if (I.alive && I.tab === 'sectors') layoutHeat(); }, 160);
  window.addEventListener('resize', onResize);

  window.Pages.industry = {
    render: render,
    update: function (params) {
      if (!I.alive || !I.data) return false;
      var q = params.query || {}, tab = q.tab === 'chains' ? 'chains' : 'sectors', p = PFIELD[q.p] ? q.p : '1d';
      if (tab !== I.tab || p !== I.p) { I.tab = tab; I.p = p; paint(); }
      return true;
    },
    destroy: function () {
      I.alive = false;
      if (I.el) { I.el.removeEventListener('click', onClick); I.el.removeEventListener('input', onInput); }
    }
  };

  // ================================================================== #/industry/<id>
  var C = {el: null, alive: false, id: '', d: null, seg: '', sub: '', all: false, introOpen: false};
  var CO_FIRST = 48;

  function renderChain(params, el) {
    C = {el: el, alive: true, id: String(params.id || ''), d: null, seg: (params.query || {}).seg || '', sub: '', all: false, introOpen: false};
    setTitle('產業鏈');
    el.innerHTML = '<div class="skel" style="height:90px"></div><div class="skel mt" style="height:380px"></div>';
    el.addEventListener('click', onChainClick);
    return api('/api/industry/' + encodeURIComponent(C.id)).then(function (d) {
      if (!C.alive) return;
      C.d = d;
      setTitle(d.name + ' 產業鏈');
      if (C.seg && !findSeg(C.seg)) C.seg = '';
      paintChain();
    }, function (e) {
      if (!C.alive) return;
      el.innerHTML = '<div class="ph"><h1>產業鏈</h1></div><div class="card empty err"><div class="big">🔗</div><h3>' +
        (e.status === 404 ? '找不到這條產業鏈（' + esc(C.id) + '）' : '無法載入產業鏈') + '</h3><p>' + esc(e.message) +
        '</p><a class="btn sm" href="#/industry?tab=chains">回到產業鏈列表</a></div>';
    });
  }
  function allSegs() {
    var out = [];
    ((C.d && C.d.streams) || []).forEach(function (s) { (s.segments || []).forEach(function (g) { out.push({stream: s, seg: g}); }); });
    return out;
  }
  function findSeg(id) { return allSegs().filter(function (x) { return x.seg.id === id; })[0] || null; }
  function segCard(g) {
    if (g.ref) {
      return '<a class="seg-card" href="#/industry/' + encodeURIComponent(g.ref) + '" data-tip="' + esc(g.title || g.name) + '"><span class="nm">' + esc(g.name) +
        '<span class="p small">↗</span></span><span class="mt2">見「' + esc(g.ref_name || g.ref) + '」產業鏈</span></a>';
    }
    var n = (g.companies || []).length, o = (g.others || []).length, pct = g.pct_1d;
    var w = isNum(pct) ? Math.min(100, Math.abs(pct) / 6 * 100) : 0;
    return '<button type="button" class="seg-card' + (C.seg === g.id ? ' on' : '') + (g.placeholder ? ' ph' : '') + '" data-seg="' + esc(g.id) + '" data-tip="' + esc(g.title || g.name) + '">' +
      '<span class="nm">' + esc(g.name) + (isNum(pct) ? '<span class="p ' + clsUpDown(pct) + '">' + fmtPct(pct) + '</span>' : '') + '</span>' +
      (g.placeholder ? '<span class="mt2">概念說明</span>' : '<span class="mt2">' + n + ' 家上市櫃' + (o ? ' · ' + o + ' 家其他' : '') +
        (isNum(g.pct_20d) ? ' · 20日 <span class="' + clsUpDown(g.pct_20d) + '">' + fmtPct(g.pct_20d, 1) + '</span>' : '') + '</span>') +
      (isNum(pct) ? '<span class="pb"><span style="width:' + w.toFixed(0) + '%;background:' + (pct >= 0 ? '#f87171' : '#4ade80') + '"></span></span>' : '') + '</button>';
  }
  function paintChain() {
    var d = C.d, streams = d.streams || [];
    var intro = d.intro || [], introLong = intro.join('').length > 220;
    var cols = streams.map(function () { return 'minmax(0,1fr)'; }).join(' 28px ') || 'minmax(0,1fr)';
    var flow = streams.map(function (s, i) {
      return (i ? '<div class="flow-arrow" aria-hidden="true">➜</div>' : '') + '<div class="flow-col"><h3>' + esc(s.name) + '</h3>' +
        (s.caption ? '<div class="small muted" style="text-align:center;margin-top:-4px">' + esc(s.caption) + '</div>' : '') +
        ((s.desc || []).length ? '<details class="small"><summary class="muted" style="cursor:pointer">說明</summary><div style="line-height:1.7;margin-top:4px;color:var(--text-2)">' +
          s.desc.map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('') + '</div></details>' : '') +
        (s.segments || []).map(segCard).join('') + '</div>';
    }).join('');
    C.el.innerHTML = '<div class="ph"><a class="btn sm ghost" href="#/industry?tab=chains">← 產業鏈列表</a><h1>' + esc(d.name) + ' 產業鏈</h1><span class="sub">資料來源：' +
      (d.url ? '<a href="' + esc(d.url) + '" target="_blank" rel="noopener noreferrer">' + esc(d.source || '櫃買中心 產業價值鏈資訊平台') + ' ↗</a>' : esc(d.source || '')) + '</span></div>' +
      (intro.length ? '<section class="card intro"><div class="' + (introLong && !C.introOpen ? 'clamp' : '') + '" id="introBox">' + intro.map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('') + '</div>' +
        (introLong ? '<button type="button" class="btn xs ghost" data-act="intro">' + (C.introOpen ? '收合' : '展開全文') + '</button>' : '') + '</section>' : '') +
      '<section class="card mt"><div class="card-h"><h2>🔗 產業鏈結構</h2><span class="sub">點選環節查看說明與公司；百分比為今日成交值加權漲跌</span></div>' +
      (streams.length ? '<div class="flow" style="--cols:' + cols + ';grid-template-columns:var(--cols)">' + flow + '</div>' : '<div class="empty">此產業鏈沒有環節資料</div>') +
      '<div id="segDetail"></div></section>' +
      ((d.trends || []).length ? '<details class="card mt"><summary>📈 產業發展趨勢（' + d.trends.length + ' 段）</summary><div class="intro">' +
        d.trends.map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('') + '</div></details>' : '') + disclaimerHtml();
    paintSeg();
  }
  function paintSeg() {
    var box = document.getElementById('segDetail');
    if (!box) return;
    var hit = C.seg ? findSeg(C.seg) : null;
    if (!hit) {
      setHtml(box, '<div class="small muted mt" style="text-align:center">👆 點選上方任一環節，查看該環節的說明與相關公司</div>');
      return;
    }
    var g = hit.seg, comps = (g.companies || []).slice(), sub = (g.subs || []).filter(function (s) { return s.id === C.sub; })[0];
    if (sub) {
      var set = {};
      (sub.codes || []).forEach(function (c) { set[c] = 1; });
      comps = comps.filter(function (c) { return set[c.code]; });
    }
    var total = comps.length, shown = C.all ? comps : comps.slice(0, CO_FIRST);
    var subs = g.subs || [];
    setHtml(box, '<div class="card seg-detail mt"><div class="card-h"><span class="chip info">' + esc(hit.stream.name) + '</span><h2>' + esc(g.title || g.name) + '</h2>' +
      (isNum(g.pct_1d) ? '<span class="chip ' + (g.pct_1d >= 0 ? 'bull' : 'bear') + '">今日 ' + fmtPct(g.pct_1d) + '</span>' : '') +
      (isNum(g.pct_20d) ? '<span class="chip ' + (g.pct_20d >= 0 ? 'bull' : 'bear') + '">20日 ' + fmtPct(g.pct_20d) + '</span>' : '') +
      '<span class="sp"></span><button type="button" class="btn xs ghost" data-act="seg-close">✕ 收合</button></div>' +
      ((g.desc || []).length ? '<div class="intro">' + g.desc.map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('') + '</div>' : '') +
      (subs.length ? '<div class="subh">子分類</div><div class="chips"><button type="button" class="chip ' + (!C.sub ? 'tag-toggle on' : 'tag-toggle') + '" data-sub="">全部</button>' +
        subs.map(function (s) {
          return '<button type="button" class="chip tag-toggle' + (C.sub === s.id ? ' on' : '') + '" data-sub="' + esc(s.id) + '">' + esc(s.name) + ' <span class="muted">' + (s.codes || []).length + '</span></button>';
        }).join('') + '</div>' : '') +
      '<div class="subh">上市櫃公司 <span class="small muted" style="font-weight:400">' + total + ' 家，依成交值排序；點擊看個股分析</span></div>' +
      (shown.length ? '<div class="co-chips">' + shown.map(function (c) {
        return '<a class="co-chip" href="#/stock/' + encodeURIComponent(c.code) + '" data-tip="' + esc(c.name + '（' + (c.group || c.market || '') + '）\n收盤 ' + fmtPrice(c.close) +
          '・20日 ' + fmtPct(c.r20, 1) + '\n成交值 ' + fmtYi(c.value) + ' 億・綜合分數 ' + fmtScore(c.score)) + '"><b>' + esc(c.code) + '</b>' + esc(c.name) +
          '<span class="p ' + clsUpDown(c.pct) + '">' + fmtPct(c.pct, 1) + '</span></a>';
      }).join('') + '</div>' : '<div class="small muted">' + (g.placeholder ? '此環節為概念說明，沒有對應的上市櫃公司。' : '沒有符合的上市櫃公司。') + '</div>') +
      (total > CO_FIRST ? '<div class="row mt-s"><button type="button" class="btn xs" data-act="co-all">' + (C.all ? '只顯示前 ' + CO_FIRST + ' 家' : '顯示全部 ' + total + ' 家') + '</button></div>' : '') +
      ((g.others || []).length ? '<div class="subh">其他公司 <span class="small muted" style="font-weight:400">興櫃、外國企業等（無本站報價）</span></div><div class="co-chips">' +
        g.others.map(function (o) { return '<span class="co-chip other"' + (o.group ? ' data-tip="' + esc(o.group) + '"' : '') + '>' + esc(o.name) + '</span>'; }).join('') + '</div>' : '') + '</div>');
  }
  function onChainClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-seg]'))) {
      var id = x.getAttribute('data-seg');
      C.seg = C.seg === id ? '' : id;
      C.sub = '';
      C.all = false;
      $$('.seg-card[data-seg]', C.el).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-seg') === C.seg); });
      paintSeg();
      App.replaceHash('#/industry/' + encodeURIComponent(C.id) + buildQuery({seg: C.seg}));
      var box = document.getElementById('segDetail');
      if (C.seg && box && box.getBoundingClientRect().top > window.innerHeight - 120) box.scrollIntoView({behavior: 'smooth', block: 'nearest'});
      return;
    }
    if ((x = t.closest('[data-sub]'))) { C.sub = x.getAttribute('data-sub'); C.all = false; paintSeg(); return; }
    if ((x = t.closest('[data-act]'))) {
      var act = x.getAttribute('data-act');
      if (act === 'co-all') { C.all = !C.all; paintSeg(); }
      else if (act === 'seg-close') {
        C.seg = '';
        $$('.seg-card[data-seg]', C.el).forEach(function (b) { b.classList.remove('on'); });
        paintSeg();
        App.replaceHash('#/industry/' + encodeURIComponent(C.id));
      } else if (act === 'intro') {
        C.introOpen = !C.introOpen;
        var ib = document.getElementById('introBox');
        if (ib) ib.classList.toggle('clamp', !C.introOpen);
        x.textContent = C.introOpen ? '收合' : '展開全文';
      }
    }
  }

  window.Pages.chain = {
    render: renderChain,
    update: function (params) {
      if (!C.alive || !C.d || String(params.id) !== C.id) return false;
      var seg = (params.query || {}).seg || '';
      if (seg !== C.seg && (!seg || findSeg(seg))) { C.seg = seg; C.sub = ''; paintChain(); }
      return true;
    },
    destroy: function () {
      C.alive = false;
      if (C.el) C.el.removeEventListener('click', onChainClick);
    }
  };
})();
