/* 選股器 (#/screener) — client-side filters over /api/universe; state lives in the hash query. */
(function () {
  'use strict';
  var RANGES = [
    ['close', '股價', 'close', 'pv'], ['pct', '漲跌幅 %', 'pct', 'pv'], ['vol', '成交量(張)', 'vol', 'pv'],
    ['value', '成交值(億)', 'value', 'pv'], ['r20', '20日漲幅 %', 'r20', 'pv'], ['vr', '量比 5/20', 'vol_ratio', 'pv'],
    ['pe', '本益比', 'pe', 'fund'], ['pb', '股價淨值比', 'pb', 'fund'], ['yld', '殖利率 %', 'yld', 'fund'],
    ['eps', 'EPS 近四季', 'eps_ttm', 'fund'], ['ryoy', '營收 YoY %', 'rev_yoy', 'fund'],
    ['chip', '籌碼強度 %', 'chip', 'tech'], ['score', '綜合分數', 'score', 'tech'], ['rank', '綜合排名', 'rank', 'tech'],
    ['rsi', 'RSI', 'rsi', 'tech'], ['k', 'K 值', 'k', 'tech'], ['dh', '距52週高 %', 'dist_hi52', 'tech']
  ];
  var RMAP = {};
  RANGES.forEach(function (r) { RMAP[r[0]] = {label: r[1], field: r[2], group: r[3]}; });
  var TAG_GROUPS = [
    ['均線／趨勢', ['多頭排列', '空頭排列', '站上月線', '跌破月線', '站上季線', '跌破季線', '均線糾結', '創52週新高', '突破60日高', '跌破60日低', '突破箱型']],
    ['K線／缺口', ['跳空上漲', '跳空下跌', '長紅K', '長黑K', '多頭吞噬', '空頭吞噬', '錘子線', '十字線', '晨星', '夜星']],
    ['技術指標', ['KD黃金交叉', 'KD死亡交叉', 'KD高檔鈍化', 'KD低檔鈍化', 'MACD黃金交叉', 'MACD死亡交叉', 'MACD翻紅', 'MACD翻綠',
      'RSI超買', 'RSI超賣', '布林突破上軌', '布林跌破下軌', '布林收斂']],
    ['量能', ['爆量', '量增', '量縮', '價漲量增', '價跌量增']],
    ['籌碼／基本面', ['外資連買', '投信連買', '法人同買', '投信大買', '營收創高', '營收高成長', 'EPS成長', '高殖利率']]
  ];
  var PRESETS = [
    ['strong', '🔥 強勢多頭', '均線多頭排列、站上季線、20 日漲幅 ≥ 5%、量比 ≥ 1', {bull: true, m60: true, type: '股票', r: {r20: [5, null], vr: [1, null]}, sort: 'r20'}],
    ['inst', '💰 法人連買', '投信連買 ≥ 3 日且籌碼強度 > 0', {st: 3, type: '股票', r: {chip: [0, null]}, sort: 'chip'}],
    ['rev', '📈 營收創高', '近 3 個月營收創 12 個月新高，且年增 ≥ 10%', {rh: true, type: '股票', r: {ryoy: [10, null]}, sort: 'rev_yoy'}],
    ['yield', '🏦 高殖利率存股', '殖利率 ≥ 5%、本益比 ≤ 20、EPS > 0，排除風險股', {nr: true, type: '股票', r: {yld: [5, null], pe: [0, 20], eps: [0, null]}, sort: 'yld'}],
    ['rebound', '🔄 低檔轉強', 'KD 低檔（K ≤ 50）黃金交叉，且站上月線', {sig: ['KD黃金交叉'], m20: true, r: {k: [null, 50]}, sort: 'tech_score'}],
    ['breakout', '🚀 突破新高', '距 52 週高點 2% 以內，且量比 ≥ 1.2', {type: '股票', r: {dh: [-2, null], vr: [1.2, null]}, sort: 'r20'}],
    ['top50', '🧮 綜合分數前50', '綜合排名前 50 名（符合模型條件的普通股）', {r: {rank: [null, 50]}, sort: 'score', dir: 'desc'}]
  ];
  var PMAP = {};
  PRESETS.forEach(function (p) { PMAP[p[0]] = p; });
  var COLS = [
    {k: 'star', t: '', s: false, c: true, w: 30}, {k: 'code', t: '代號', l: true, w: 60}, {k: 'name', t: '名稱', l: true, w: 92},
    {k: 'industry', t: '產業', l: true, w: 86}, {k: 'close', t: '收盤', w: 66}, {k: 'pct', t: '漲跌%', w: 80}, {k: 'vol', t: '成交量', w: 68},
    {k: 'value', t: '成交值(億)', w: 80}, {k: 'r20', t: '20日%', w: 72}, {k: 'pe', t: '本益比', w: 56}, {k: 'yld', t: '殖利率', w: 60},
    {k: 'rev_yoy', t: '營收YoY', w: 80}, {k: 'chip', t: '籌碼%', w: 56}, {k: 'score', t: '分數', w: 50}, {k: 'signals', t: '訊號', l: true, s: false}
  ];
  var PAGE = 200;
  var S = {el: null, alive: false, U: null, F: null, rows: [], limit: PAGE, tagCount: {}, indCount: [], panelOpen: false};

  function num(v) {
    if (v === undefined || v === null || v === '') return null;
    var n = parseFloat(v);
    return isFinite(n) ? n : null;
  }
  function blankState() {
    return {q: '', mkt: '', type: '', ind: [], r: {}, rh: false, bull: false, m20: false, m60: false, st: 0, sf: 0,
      sig: [], nr: false, sort: 'score', dir: 'desc', p: ''};
  }
  function presetState(id) {
    var F = blankState(), p = PMAP[id];
    if (!p) return F;
    var f = JSON.parse(JSON.stringify(p[3]));
    Object.keys(f).forEach(function (k) { F[k] = f[k]; });
    F.p = id;
    return F;
  }
  function stateFromQuery(q) {
    var keys = Object.keys(q).filter(function (k) { return k !== 'p'; });
    if (q.p && PMAP[q.p] && !keys.length) return presetState(q.p);
    var F = blankState();
    F.q = q.q || '';
    F.mkt = q.mkt || '';
    F.type = q.type || '';
    F.ind = q.ind ? q.ind.split(',').filter(Boolean) : [];
    F.rh = q.rh === '1'; F.bull = q.bull === '1'; F.m20 = q.m20 === '1'; F.m60 = q.m60 === '1'; F.nr = q.nr === '1';
    F.st = parseInt(q.st || '0', 10) || 0;
    F.sf = parseInt(q.sf || '0', 10) || 0;
    F.sig = q.sig ? q.sig.split(',').filter(Boolean) : [];
    F.sort = q.sort || 'score';
    F.dir = q.dir === 'asc' ? 'asc' : 'desc';
    F.p = q.p && PMAP[q.p] ? q.p : '';
    RANGES.forEach(function (r) {
      var v = q[r[0]];
      if (!v) return;
      var parts = v.split('~');
      var lo = num(parts[0]), hi = num(parts[1]);
      if (lo !== null || hi !== null) F.r[r[0]] = [lo, hi];
    });
    return F;
  }
  function queryFromState(F) {
    var o = {p: F.p, q: F.q.trim(), mkt: F.mkt, type: F.type, ind: F.ind.join(','), rh: F.rh, bull: F.bull, m20: F.m20,
      m60: F.m60, st: F.st || '', sf: F.sf || '', sig: F.sig.join(','), nr: F.nr};
    RANGES.forEach(function (r) {
      var v = F.r[r[0]];
      if (v && (v[0] !== null || v[1] !== null)) o[r[0]] = (v[0] === null ? '' : v[0]) + '~' + (v[1] === null ? '' : v[1]);
    });
    if (F.sort !== 'score') o.sort = F.sort;
    if (F.dir !== 'desc') o.dir = F.dir;
    return o;
  }

  // ------------------------------------------------------------------ render
  function render(params, el) {
    S.el = el;
    S.alive = true;
    S.limit = PAGE;
    S.F = stateFromQuery(params.query || {});
    setTitle('選股器');
    el.innerHTML = '<div class="ph"><h1>選股器</h1><span class="sub">全市場上市櫃股票與 ETF，條件即時篩選</span></div>' + skeleton(1, 420);
    el.addEventListener('click', onClick);
    el.addEventListener('input', onInput);
    el.addEventListener('change', onChange);
    return load();
  }
  function load() {
    return getUniverse().then(function (U) {
      if (!S.alive) return;
      S.U = U;
      if (U.empty || !U.list.length) { S.el.innerHTML = '<div class="ph"><h1>選股器</h1></div>' + buildingHtml(U.message); return; }
      countTags();
      paint();
    });
  }
  function countTags() {
    var tc = {}, ic = {};
    S.U.list.forEach(function (r) {
      (r.signals || []).forEach(function (t) { tc[t] = (tc[t] || 0) + 1; });
      var ind = r.industry || '未分類';
      ic[ind] = (ic[ind] || 0) + 1;
    });
    S.tagCount = tc;
    S.indCount = Object.keys(ic).map(function (k) { return [k, ic[k]]; }).sort(function (a, b) { return b[1] - a[1]; });
  }
  function paint() {
    S.el.innerHTML = '<div class="ph"><h1>選股器</h1><span class="sub">全市場 ' + fmtInt(S.U.list.length) + ' 檔上市櫃股票與 ETF，條件即時篩選；網址會記住條件，可直接分享或加入書籤</span></div>' +
      '<div class="campus-acad-bar"><b>🏛️ 財經學院 · 選股指標對照教學：</b>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/fa" href="https://okayell.github.io/finance/#/track/fa">📊 基本面學院（本益比／殖利率／營收）</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/chip" href="https://okayell.github.io/finance/#/track/chip">🧮 籌碼面學院（投信外資連買）</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/ta" href="https://okayell.github.io/finance/#/track/ta">📈 技術分析學院（均線／KD／突破）</a></div>' +
      '<div class="presets card" style="padding:10px 12px;margin-bottom:12px"><span class="small muted" style="margin-right:2px">⚡ 一鍵策略</span>' +
      PRESETS.map(function (p) {
        return '<button type="button" class="preset' + (S.F.p === p[0] ? ' on' : '') + '" data-preset="' + p[0] + '" data-tip="' + esc(p[2]) + '">' + p[1] + '</button>';
      }).join('') + '</div>' +
      '<div class="scr"><aside class="card fpanel' + (S.panelOpen ? ' open' : '') + '" id="scrPanel">' + panelHtml() + '</aside>' +
      '<section class="card flush" id="scrRes"><div class="res-h" id="scrHead"></div><div class="tbl-wrap scr-tbl" id="scrTbl"></div></section></div>' +
      disclaimerHtml('篩選結果僅為條件比對，不代表推薦；資料為收盤後數據。');
    apply();
  }
  function rangeRow(k) {
    var v = S.F.r[k] || [null, null], d = RMAP[k];
    var val = function (x) { return x === null || x === undefined ? '' : String(x); };
    return '<div class="frow"><label for="r_' + k + '_0">' + esc(d.label) + '</label>' +
      '<input id="r_' + k + '_0" class="' + (v[0] !== null ? 'set' : '') + '" data-range="' + k + '" data-i="0" type="number" inputmode="decimal" step="any" placeholder="最低" value="' + val(v[0]) + '">' +
      '<span class="dash">~</span><input class="' + (v[1] !== null ? 'set' : '') + '" data-range="' + k + '" data-i="1" type="number" inputmode="decimal" step="any" placeholder="最高" value="' + val(v[1]) + '" aria-label="' + esc(d.label) + ' 最高"></div>';
  }
  function secCount(group) {
    var n = 0, F = S.F;
    if (group === 'basic') n = (F.q ? 1 : 0) + (F.mkt ? 1 : 0) + (F.type ? 1 : 0) + (F.nr ? 1 : 0);
    else if (group === 'ind') n = F.ind.length;
    else if (group === 'cond') n = [F.rh, F.bull, F.m20, F.m60, F.st > 0, F.sf > 0].filter(Boolean).length;
    else if (group === 'sig') n = F.sig.length;
    else RANGES.forEach(function (r) { if (r[3] === group && S.F.r[r[0]]) n++; });
    return n ? '<span class="cnt">' + n + '</span>' : '';
  }
  function seg(name, opts, cur) {
    return '<div class="seg">' + opts.map(function (o) {
      return '<button type="button" class="' + (cur === o[0] ? 'on' : '') + '" data-seg="' + name + '" data-v="' + esc(o[0]) + '">' + o[1] + '</button>';
    }).join('') + '</div>';
  }
  function panelHtml() {
    var F = S.F;
    var tagHtml = TAG_GROUPS.map(function (g) {
      var tags = g[1].filter(function (t) { return S.tagCount[t] || F.sig.indexOf(t) >= 0; });
      if (!tags.length) return '';
      return '<div class="tag-group"><span class="gl">' + g[0] + '</span><div class="chips">' + tags.map(function (t) {
        return '<button type="button" class="chip tag-toggle ' + (F.sig.indexOf(t) >= 0 ? 'on' : sigClass(t)) + '" data-tag="' + esc(t) + '"' +
          (App.SIG_TIP[t] ? ' data-tip="' + esc(App.SIG_TIP[t]) + '"' : '') + '>' + esc(t) + ' <span class="muted" style="opacity:.7">' + (S.tagCount[t] || 0) + '</span></button>';
      }).join('') + '</div></div>';
    }).join('');
    var sec = function (id, title, body, open) {
      return '<details class="fsec" data-sec="' + id + '"' + (open ? ' open' : '') + '><summary>' + title + secCount(id) + '</summary><div class="fsec-b">' + body + '</div></details>';
    };
    return '<div class="fpanel-h"><h2>篩選條件</h2><span class="sp"></span><button type="button" class="btn xs" data-act="clear">清除全部</button></div>' +
      sec('basic', '基本', '<input class="input" id="scrQ" type="search" placeholder="代號或名稱關鍵字" value="' + esc(F.q) + '" autocomplete="off">' +
        '<div class="row"><span class="small muted" style="width:34px">市場</span>' + seg('mkt', [['', '全部'], ['上市', '上市'], ['上櫃', '上櫃']], F.mkt) + '</div>' +
        '<div class="row"><span class="small muted" style="width:34px">類型</span>' + seg('type', [['', '全部'], ['股票', '股票'], ['ETF', 'ETF']], F.type) + '</div>' +
        '<label class="check"><input type="checkbox" data-bool="nr"' + (F.nr ? ' checked' : '') + '> 排除風險股（處置／注意／過熱／流動性不足／虧損）</label>', true) +
      sec('ind', '產業', '<input class="input" id="indQ" type="search" placeholder="搜尋產業" autocomplete="off" style="height:28px">' +
        '<div class="ind-list" id="indList">' + indListHtml('') + '</div>', F.ind.length > 0) +
      sec('pv', '價量', RANGES.filter(function (r) { return r[3] === 'pv'; }).map(function (r) { return rangeRow(r[0]); }).join(''), true) +
      sec('fund', '基本面', RANGES.filter(function (r) { return r[3] === 'fund'; }).map(function (r) { return rangeRow(r[0]); }).join(''), hasGroup('fund')) +
      sec('tech', '籌碼／技術／評分', RANGES.filter(function (r) { return r[3] === 'tech'; }).map(function (r) { return rangeRow(r[0]); }).join(''), hasGroup('tech')) +
      sec('cond', '條件', '<label class="check"><input type="checkbox" data-bool="rh"' + (F.rh ? ' checked' : '') + '> 營收創新高（近 3 月）</label>' +
        '<label class="check"><input type="checkbox" data-bool="bull"' + (F.bull ? ' checked' : '') + '> 均線多頭排列</label>' +
        '<label class="check"><input type="checkbox" data-bool="m20"' + (F.m20 ? ' checked' : '') + '> 站上月線（MA20）</label>' +
        '<label class="check"><input type="checkbox" data-bool="m60"' + (F.m60 ? ' checked' : '') + '> 站上季線（MA60）</label>' +
        '<div class="frow" style="grid-template-columns:auto 64px auto"><label>投信連買 ≥</label><input type="number" min="0" step="1" data-int="st" value="' + (F.st || '') + '" placeholder="0"><span class="small muted">日</span></div>' +
        '<div class="frow" style="grid-template-columns:auto 64px auto"><label>外資連買 ≥</label><input type="number" min="0" step="1" data-int="sf" value="' + (F.sf || '') + '" placeholder="0"><span class="small muted">日</span></div>',
        secCount('cond') !== '') +
      sec('sig', '技術訊號標籤 <span class="small muted" style="font-weight:400">（需同時符合）</span>', tagHtml, F.sig.length > 0);
  }
  function hasGroup(g) { return RANGES.some(function (r) { return r[3] === g && S.F.r[r[0]]; }); }
  function indListHtml(filter) {
    filter = (filter || '').trim();
    return S.indCount.filter(function (x) { return !filter || x[0].indexOf(filter) >= 0; }).map(function (x) {
      return '<label><input type="checkbox" data-ind="' + esc(x[0]) + '"' + (S.F.ind.indexOf(x[0]) >= 0 ? ' checked' : '') + '> ' + esc(x[0]) +
        '<span class="n">' + x[1] + '</span></label>';
    }).join('') || '<div class="small muted" style="padding:6px">沒有符合的產業</div>';
  }

  // ------------------------------------------------------------------ filtering
  function apply() {
    var F = S.F, list = S.U.list, out = [];
    var q = F.q.trim().toLowerCase();
    var indSet = F.ind.length ? new Set(F.ind) : null;
    var rdefs = [];
    Object.keys(F.r).forEach(function (k) {
      var v = F.r[k];
      if (v && RMAP[k] && (v[0] !== null || v[1] !== null)) rdefs.push([RMAP[k].field, v[0], v[1]]);
    });
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (F.mkt && r.market !== F.mkt) continue;
      if (F.type && r.type !== F.type) continue;
      if (indSet && !indSet.has(r.industry || '未分類')) continue;
      if (q && r._hay.indexOf(q) < 0) continue;
      var ok = true;
      for (var j = 0; j < rdefs.length; j++) {
        var v = r[rdefs[j][0]];
        if (typeof v !== 'number' || (rdefs[j][1] !== null && v < rdefs[j][1]) || (rdefs[j][2] !== null && v > rdefs[j][2])) { ok = false; break; }
      }
      if (!ok) continue;
      var bits = r.ma_bits || 0;
      if (F.bull && !(bits & 64)) continue;
      if (F.m20 && !(bits & 4)) continue;
      if (F.m60 && !(bits & 8)) continue;
      if (F.rh && r.rev_high !== true) continue;
      if (F.st && !((r.streak_t || 0) >= F.st)) continue;
      if (F.sf && !((r.streak_f || 0) >= F.sf)) continue;
      if (F.sig.length) {
        for (var t = 0; t < F.sig.length; t++) { if (r.signals.indexOf(F.sig[t]) < 0) { ok = false; break; } }
        if (!ok) continue;
      }
      if (F.nr && r.risk.length) continue;
      out.push(r);
    }
    var key = F.sort, dir = F.dir === 'asc' ? 1 : -1;
    out.sort(function (a, b) {
      var x = a[key], y = b[key];
      var xn = x === null || x === undefined, yn = y === null || y === undefined;
      if (xn || yn) return xn === yn ? 0 : (xn ? 1 : -1);
      if (typeof x === 'string') return x.localeCompare(y, 'zh-Hant') * dir;
      return (x - y) * dir;
    });
    S.rows = out;
    renderHead();
    renderTable();
    syncUrl();
  }
  function syncUrl() { App.replaceHash('#/screener' + buildQuery(queryFromState(S.F))); }

  function activeChips() {
    var F = S.F, c = [];
    if (F.q) c.push(['q', '關鍵字：' + F.q]);
    if (F.mkt) c.push(['mkt', F.mkt]);
    if (F.type) c.push(['type', F.type]);
    F.ind.forEach(function (x) { c.push(['ind:' + x, x]); });
    RANGES.forEach(function (r) {
      var v = F.r[r[0]];
      if (!v) return;
      var t = v[0] !== null && v[1] !== null ? v[0] + '～' + v[1] : (v[0] !== null ? '≥ ' + v[0] : '≤ ' + v[1]);
      c.push(['r:' + r[0], r[1].replace(/ /g, '') + ' ' + t]);
    });
    if (F.rh) c.push(['rh', '營收創高']);
    if (F.bull) c.push(['bull', '多頭排列']);
    if (F.m20) c.push(['m20', '站上月線']);
    if (F.m60) c.push(['m60', '站上季線']);
    if (F.st) c.push(['st', '投信連買≥' + F.st + '日']);
    if (F.sf) c.push(['sf', '外資連買≥' + F.sf + '日']);
    F.sig.forEach(function (x) { c.push(['sig:' + x, '#' + x]); });
    if (F.nr) c.push(['nr', '排除風險股']);
    return c;
  }
  function renderHead() {
    var chips = activeChips();
    setHtml(document.getElementById('scrHead'),
      '<button type="button" class="btn sm f-toggle" data-act="panel">⚙️ 篩選條件' + (chips.length ? '（' + chips.length + '）' : '') + '</button>' +
      '<span class="count">符合 <b>' + fmtInt(S.rows.length) + '</b> 檔</span>' +
      '<div class="active-f">' + chips.map(function (c) {
        return '<span class="chip info" data-rm="' + esc(c[0]) + '" data-tip="移除此條件">' + esc(c[1]) + '</span>';
      }).join('') + '</div>' +
      '<button type="button" class="btn sm" data-act="csv"' + (S.rows.length ? '' : ' disabled') + ' data-tip="匯出全部符合的股票（含未顯示的列）">⬇ 匯出 CSV</button>');
  }
  function cell(r, k) {
    switch (k) {
      case 'star': return '<td class="c">' + starBtn(r.code, 'icon') + '</td>';
      case 'code': return '<td class="l code">' + esc(r.code) + '</td>';
      case 'name': return '<td class="l nm" title="' + esc(r.name) + '">' + esc(r.name) + (r.risk.length ? '<span class="risk-dot" data-tip="風險：' + esc(r.risk.join('、')) + '">⚠</span>' : '') + '</td>';
      case 'industry': return '<td class="l muted" title="' + esc(r.industry || '') + '">' + esc(r.type === 'ETF' ? 'ETF' : (r.industry || '—')) + '</td>';
      case 'close': return '<td>' + fmtPrice(r.close) + '</td>';
      case 'pct': return '<td class="' + clsUpDown(r.pct) + '">' + fmtPct(r.pct) + '</td>';
      case 'vol': return '<td>' + fmtInt(r.vol) + '</td>';
      case 'value': return '<td>' + fmtYi(r.value) + '</td>';
      case 'r20': return '<td class="' + clsUpDown(r.r20) + '">' + fmtPct(r.r20, 1) + '</td>';
      case 'pe': return '<td>' + fmtNum(r.pe, 1) + '</td>';
      case 'yld': return '<td>' + (App.isNum(r.yld) ? fmtNum(r.yld, 2) + '%' : '—') + '</td>';
      case 'rev_yoy': return '<td class="' + clsUpDown(r.rev_yoy) + '">' + fmtPct(r.rev_yoy, 1) + '</td>';
      case 'chip': return '<td class="' + clsUpDown(r.chip) + '">' + fmtNum(r.chip, 1) + '</td>';
      case 'score': return '<td><b style="color:' + App.scoreColor(r.score) + '">' + fmtScore(r.score) + '</b></td>';
      case 'signals': return '<td class="l sig-cell"' + (r.signals.length > 2 ? ' data-tip="' + esc(r.signals.join('、')) + '"' : '') + '><div class="sigs">' +
        (r.signals || []).slice(0, 4).map(sigChip).join('') + '</div></td>';
    }
    return '<td></td>';
  }
  function renderTable() {
    var F = S.F, rows = S.rows.slice(0, S.limit);
    var head = '<thead><tr>' + COLS.map(function (c) {
      var sortable = c.s !== false, on = F.sort === c.k;
      return '<th class="' + (c.l ? 'l ' : '') + (c.c ? 'c ' : '') + (sortable ? 'sortable ' : '') + (on ? 'sorted ' + (F.dir === 'asc' ? 'asc' : '') : '') + '"' +
        (sortable ? ' data-sort="' + c.k + '"' : '') + '>' + c.t + '</th>';
    }).join('') + '</tr></thead>';
    var body = rows.map(function (r) {
      return '<tr data-href="#/stock/' + encodeURIComponent(r.code) + '">' + COLS.map(function (c) { return cell(r, c.k); }).join('') + '</tr>';
    }).join('');
    var html;
    if (!S.rows.length) {
      html = '<div class="empty"><div class="big">🔎</div><h3>沒有符合條件的股票</h3><p>試著放寬數值範圍、減少標籤條件，或點「清除全部」。</p></div>';
    } else {
      html = '<table class="tbl dense fixed"><colgroup>' + COLS.map(function (c) { return c.w ? '<col style="width:' + c.w + 'px">' : '<col>'; }).join('') +
        '</colgroup>' + head + '<tbody>' + body + '</tbody></table>' +
        (S.rows.length > S.limit ? '<div class="more-row"><button type="button" class="btn sm" data-act="more">顯示更多（已顯示 ' + fmtInt(S.limit) +
          ' / ' + fmtInt(S.rows.length) + '）</button></div>' : '');
    }
    setHtml(document.getElementById('scrTbl'), html);
  }

  // ------------------------------------------------------------------ events
  function changed(clearPreset) {
    if (clearPreset !== false) S.F.p = '';
    S.limit = PAGE;
    $$('.preset', S.el).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-preset') === S.F.p); });
    $$('.fsec', S.el).forEach(function (d) {
      var s = d.querySelector('summary'), id = d.getAttribute('data-sec');
      var old = s.querySelector('.cnt');
      if (old) old.remove();
      var cnt = secCount(id);
      if (cnt) s.insertAdjacentHTML('beforeend', cnt);
    });
    apply();
  }
  var applyLater = App.debounce(function () { if (S.alive) changed(); }, 140);
  function onInput(ev) {
    var t = ev.target;
    if (t.id === 'scrQ') { S.F.q = t.value; applyLater(); return; }
    if (t.id === 'indQ') { setHtml(document.getElementById('indList'), indListHtml(t.value)); return; }
    var rk = t.getAttribute('data-range');
    if (rk) {
      var v = S.F.r[rk] || [null, null];
      v[+t.getAttribute('data-i')] = num(t.value);
      if (v[0] === null && v[1] === null) delete S.F.r[rk]; else S.F.r[rk] = v;
      t.classList.toggle('set', num(t.value) !== null);
      applyLater();
      return;
    }
    var ik = t.getAttribute('data-int');
    if (ik) { S.F[ik] = Math.max(0, parseInt(t.value || '0', 10) || 0); applyLater(); }
  }
  function onChange(ev) {
    var t = ev.target;
    var b = t.getAttribute('data-bool');
    if (b) { S.F[b] = t.checked; changed(); return; }
    var ind = t.getAttribute('data-ind');
    if (ind !== null && ind !== undefined && t.hasAttribute('data-ind')) {
      var i = S.F.ind.indexOf(ind);
      if (t.checked && i < 0) S.F.ind.push(ind);
      if (!t.checked && i >= 0) S.F.ind.splice(i, 1);
      changed();
    }
  }
  function rebuildPanel() {
    var p = document.getElementById('scrPanel');
    if (p) p.innerHTML = panelHtml();
  }
  function removeChip(key) {
    var F = S.F;
    if (key.indexOf('ind:') === 0) F.ind = F.ind.filter(function (x) { return x !== key.slice(4); });
    else if (key.indexOf('sig:') === 0) F.sig = F.sig.filter(function (x) { return x !== key.slice(4); });
    else if (key.indexOf('r:') === 0) delete F.r[key.slice(2)];
    else if (key === 'q' || key === 'mkt' || key === 'type') F[key] = '';
    else if (key === 'st' || key === 'sf') F[key] = 0;
    else F[key] = false;
    rebuildPanel();
    changed();
  }
  function onClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-preset]'))) {
      var id = x.getAttribute('data-preset');
      S.F = S.F.p === id ? blankState() : presetState(id);
      rebuildPanel();
      changed(false);
      return;
    }
    if ((x = t.closest('[data-seg]'))) {
      S.F[x.getAttribute('data-seg')] = x.getAttribute('data-v');
      $$('[data-seg="' + x.getAttribute('data-seg') + '"]', S.el).forEach(function (b) { b.classList.toggle('on', b === x); });
      changed();
      return;
    }
    if ((x = t.closest('[data-tag]'))) {
      var tag = x.getAttribute('data-tag'), i = S.F.sig.indexOf(tag);
      if (i >= 0) S.F.sig.splice(i, 1); else S.F.sig.push(tag);
      x.classList.toggle('on', i < 0);
      if (i >= 0) { var cls = sigClass(tag); if (cls) x.classList.add(cls); } else x.classList.remove('bull', 'bear', 'fund', 'warn');
      changed();
      return;
    }
    if ((x = t.closest('[data-sort]'))) {
      var k = x.getAttribute('data-sort');
      if (S.F.sort === k) S.F.dir = S.F.dir === 'desc' ? 'asc' : 'desc';
      else { S.F.sort = k; S.F.dir = (k === 'code' || k === 'name' || k === 'industry') ? 'asc' : 'desc'; }
      S.limit = PAGE;
      apply();
      return;
    }
    if ((x = t.closest('[data-rm]'))) { removeChip(x.getAttribute('data-rm')); return; }
    if ((x = t.closest('[data-act]'))) {
      var act = x.getAttribute('data-act');
      if (act === 'more') { S.limit += PAGE; renderTable(); }
      else if (act === 'clear') { S.F = blankState(); rebuildPanel(); changed(); }
      else if (act === 'csv') exportCsv();
      else if (act === 'panel') {
        S.panelOpen = !S.panelOpen;
        var p = document.getElementById('scrPanel');
        if (p) p.classList.toggle('open', S.panelOpen);
      }
    }
  }
  function csvCell(v) {
    if (v === null || v === undefined) return '';
    var s = Array.isArray(v) ? v.join('、') : String(v);
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function exportCsv() {
    var cols = [['code', '代號'], ['name', '名稱'], ['market', '市場'], ['industry', '產業'], ['type', '類型'], ['close', '收盤'], ['chg', '漲跌'],
      ['pct', '漲跌%'], ['vol', '成交量(張)'], ['value', '成交值(億)'], ['r5', '5日%'], ['r20', '20日%'], ['r60', '60日%'], ['pe', '本益比'],
      ['pb', '股價淨值比'], ['yld', '殖利率%'], ['eps_ttm', 'EPS近四季'], ['rev_yoy', '營收YoY%'], ['chip', '籌碼強度%'], ['streak_f', '外資連買日'],
      ['streak_t', '投信連買日'], ['score', '綜合分數'], ['rank', '排名'], ['tech_score', '技術分數'], ['signals', '訊號'], ['risk', '風險']];
    var lines = [cols.map(function (c) { return c[1]; }).join(',')];
    S.rows.forEach(function (r) { lines.push(cols.map(function (c) { return csvCell(r[c[0]]); }).join(',')); });
    var blob = new Blob(['\ufeff' + lines.join('\r\n')], {type: 'text/csv;charset=utf-8'});
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'tw_screener_' + (S.U.date || 'data') + '.csv';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
    toast('已匯出 ' + S.rows.length + ' 檔股票', 'ok');
  }

  window.Pages.screener = {
    render: render,
    update: function (params) {
      if (!S.U || !S.alive) return false;
      var F = stateFromQuery(params.query || {});
      if (JSON.stringify(queryFromState(F)) === JSON.stringify(queryFromState(S.F))) return true;
      S.F = F;
      paint();
      return true;
    },
    refresh: function () {
      if (!S.alive) return false;
      load();
      return true;
    },
    destroy: function () {
      S.alive = false;
      if (S.el) {
        S.el.removeEventListener('click', onClick);
        S.el.removeEventListener('input', onInput);
        S.el.removeEventListener('change', onChange);
      }
    }
  };
})();
