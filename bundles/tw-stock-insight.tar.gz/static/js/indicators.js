/* Client-side indicators — exact port of ta.py `compute_indicators()` / `resample()`.
 * Used by the GitHub static build (stock payloads ship without `ind`, weekly/monthly bars
 * are resampled in the browser). Pure functions; exposes window.TA.
 * Parity with ta.py is checked by tools/ta_parity.mjs.
 */
(function (root) {
  'use strict';
  var KEYS = ['ma5', 'ma10', 'ma20', 'ma60', 'ma120', 'ma240', 'bb_up', 'bb_mid', 'bb_lo', 'k', 'd',
    'dif', 'dea', 'hist', 'rsi6', 'rsi14', 'vol_ma5', 'vol_ma20'];

  function nulls(m) { var a = new Array(m); for (var i = 0; i < m; i++) a[i] = null; return a; }
  function firstValid(xs) {
    for (var i = 0; i < xs.length; i++) if (xs[i] !== null && xs[i] !== undefined) return i;
    return xs.length;
  }
  /** Simple moving average; null during warm-up (leading nulls skipped). */
  function sma(xs, n) {
    var m = xs.length, out = nulls(m), s = firstValid(xs);
    if (n <= 0 || m - s < n) return out;
    var acc = 0;
    for (var i = s; i < s + n; i++) acc += xs[i];
    out[s + n - 1] = acc / n;
    for (var j = s + n; j < m; j++) { acc += xs[j] - xs[j - n]; out[j] = acc / n; }
    return out;
  }
  /** EMA (alpha 2/(n+1)) seeded with the SMA of the first n valid values. */
  function ema(xs, n) {
    var m = xs.length, out = nulls(m), s = firstValid(xs);
    if (n <= 0 || m - s < n) return out;
    var a = 2 / (n + 1), e = 0;
    for (var i = s; i < s + n; i++) e += xs[i];
    e /= n;
    out[s + n - 1] = e;
    for (var j = s + n; j < m; j++) { e += a * (xs[j] - e); out[j] = e; }
    return out;
  }
  function rsiVal(g, l) {
    if (l <= 0) return g > 0 ? 100 : 50;
    return 100 - 100 / (1 + g / l);
  }
  /** Wilder RSI: first value at index n (simple-average seed), then smoothed. */
  function rsi(c, n) {
    var m = c.length, out = nulls(m);
    if (n <= 0 || m <= n) return out;
    var g = 0, l = 0, i, ch;
    for (i = 1; i <= n; i++) { ch = c[i] - c[i - 1]; if (ch > 0) g += ch; else l -= ch; }
    g /= n;
    l /= n;
    out[n] = rsiVal(g, l);
    var k = n - 1;
    for (i = n + 1; i < m; i++) {
      ch = c[i] - c[i - 1];
      if (ch > 0) { g = (g * k + ch) / n; l = l * k / n; } else { g = g * k / n; l = (l * k - ch) / n; }
      out[i] = rsiVal(g, l);
    }
    return out;
  }
  /** Taiwan KD: RSV over n bars, K = 2/3·K + 1/3·RSV, D = 2/3·D + 1/3·K, seed 50. */
  function kd(h, l, c, n) {
    var m = c.length, ks = nulls(m), ds = nulls(m);
    if (n <= 0 || m < n) return [ks, ds];
    var k = 50, d = 50;
    for (var i = n - 1; i < m; i++) {
      var hh = -Infinity, ll = Infinity;
      for (var j = i - n + 1; j <= i; j++) { if (h[j] > hh) hh = h[j]; if (l[j] < ll) ll = l[j]; }
      var rng = hh - ll, rsv = 50;
      if (rng > 0) rsv = Math.max(0, Math.min(100, (c[i] - ll) / rng * 100));
      k = k * 2 / 3 + rsv / 3;
      d = d * 2 / 3 + k / 3;
      ks[i] = k;
      ds[i] = d;
    }
    return [ks, ds];
  }
  /** MACD: dif = EMAfast − EMAslow, dea = EMA(dif, signal), hist = dif − dea (OSC). */
  function macd(c, fast, slow, signal) {
    var ef = ema(c, fast), es = ema(c, slow), m = c.length, dif = nulls(m), hist = nulls(m), i;
    for (i = 0; i < m; i++) if (ef[i] !== null && es[i] !== null) dif[i] = ef[i] - es[i];
    var dea = ema(dif, signal);
    for (i = 0; i < m; i++) if (dif[i] !== null && dea[i] !== null) hist[i] = dif[i] - dea[i];
    return [dif, dea, hist];
  }
  /** Bollinger bands with population σ (base-shifted running sums, like ta.py). */
  function bollinger(c, n, k) {
    var m = c.length, up = nulls(m), mid = nulls(m), lo = nulls(m);
    if (n <= 0 || m < n) return [up, mid, lo];
    var base = c[0], s1 = 0, s2 = 0;
    for (var i = 0; i < m; i++) {
      var y = c[i] - base;
      s1 += y;
      s2 += y * y;
      if (i >= n) { var y0 = c[i - n] - base; s1 -= y0; s2 -= y0 * y0; }
      if (i >= n - 1) {
        var mu = s1 / n, v = s2 / n - mu * mu, sd = v > 0 ? Math.sqrt(v) : 0;
        if (sd < 1e-9 * (Math.abs(base) + 1)) sd = 0;
        var cc = mu + base;
        mid[i] = cc;
        up[i] = cc + k * sd;
        lo[i] = cc - k * sd;
      }
    }
    return [up, mid, lo];
  }
  function median(xs) {
    var s = xs.slice().sort(function (a, b) { return a - b; }), m = s.length;
    if (!m) return 0;
    return m % 2 ? s[(m - 1) / 2] : (s[m / 2 - 1] + s[m / 2]) / 2;
  }
  function ff(x, dflt) { var v = typeof x === 'number' ? x : parseFloat(x); return isFinite(v) ? v : dflt; }
  /**
   * Python round(x, nd): correctly rounded on the exact binary value, half-to-even on exact ties
   * (JS toFixed rounds exact ties away from zero, e.g. 111.625 → 111.63 vs Python 111.62).
   */
  function roundTo(x, nd) {
    if (x === null || !isFinite(x)) return null;
    var s = x.toFixed(nd), extra = 30, ext = x.toFixed(Math.min(100, nd + extra));
    var tail = ext.slice(ext.length - extra);
    if (tail.charAt(0) === '5' && /^50*$/.test(tail)) {
      var trunc = ext.slice(0, ext.length - extra).replace(/\.$/, '');
      var last = trunc.charAt(trunc.length - 1);
      if ((+last) % 2 === 0) s = trunc;
    }
    return Number(s);
  }

  /** Chart indicators aligned 1:1 with bars (null warm-up), rounded like ta.py. */
  function computeIndicators(bars) {
    bars = bars || [];
    var m = bars.length, out = {}, i;
    var closes = bars.map(function (b) { var c = ff(b[4], NaN); return isFinite(c) && c > 0 ? c : null; });
    var first = null;
    for (i = 0; i < m; i++) if (closes[i] !== null) { first = closes[i]; break; }
    if (first === null) { KEYS.forEach(function (k) { out[k] = nulls(m); }); return out; }
    var h = [], l = [], c = [], v = [], prev = first;
    for (i = 0; i < m; i++) {
      var b = bars[i], cl = closes[i], hi, lo, vol;
      if (cl === null) { cl = prev; hi = prev; lo = prev; vol = 0; } else {
        hi = b.length > 2 ? ff(b[2], cl) : cl;
        lo = b.length > 3 ? ff(b[3], cl) : cl;
        var op = b.length > 1 ? ff(b[1], cl) : cl;
        hi = Math.max(hi > 0 ? hi : cl, cl, op > 0 ? op : cl);
        lo = Math.min(lo > 0 ? lo : cl, cl, op > 0 ? op : cl);
        vol = b.length > 5 ? ff(b[5], 0) : 0;
      }
      h.push(hi); l.push(lo); c.push(cl); v.push(vol > 0 ? vol : 0);
      prev = cl;
    }
    var bb = bollinger(c, 20, 2), kk = kd(h, l, c, 9), mm = macd(c, 12, 26, 9);
    var raw = {ma5: sma(c, 5), ma10: sma(c, 10), ma20: bb[1], ma60: sma(c, 60), ma120: sma(c, 120), ma240: sma(c, 240),
      bb_up: bb[0], bb_mid: bb[1], bb_lo: bb[2], k: kk[0], d: kk[1], dif: mm[0], dea: mm[1], hist: mm[2],
      rsi6: rsi(c, 6), rsi14: rsi(c, 14), vol_ma5: sma(v, 5), vol_ma20: sma(v, 20)};
    var ref = median(c.slice(-60)), dp = ref >= 10 ? 2 : (ref >= 1 ? 3 : 4), dm = Math.min(4, dp + 1);
    var nds = {k: 2, d: 2, rsi6: 2, rsi14: 2, vol_ma5: 1, vol_ma20: 1, dif: dm, dea: dm, hist: dm};
    KEYS.forEach(function (key) {
      var nd = nds[key] !== undefined ? nds[key] : dp;
      out[key] = raw[key].map(function (x) { return roundTo(x, nd); });
    });
    return out;
  }

  function isoWeekKey(d) {
    var t = new Date(Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10)));
    var day = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - day);
    var y = t.getUTCFullYear();
    return y * 100 + Math.ceil(((t - Date.UTC(y, 0, 1)) / 86400000 + 1) / 7);
  }
  /** 'W' = ISO week, 'M' = calendar month; bar date = last trading day of the period. */
  function resample(bars, tf) {
    tf = String(tf || 'D').toUpperCase();
    if (tf !== 'W' && tf !== 'M') return (bars || []).map(function (b) { return b.slice(); });
    var out = [], prev = null;
    (bars || []).forEach(function (b) {
      var d = String(b[0]).slice(0, 10), key = tf === 'W' ? isoWeekKey(d) : d.slice(0, 7);
      var v = (b.length > 5 ? b[5] : 0) || 0;
      if (key !== prev) { out.push([d, b[1], b[2], b[3], b[4], v]); prev = key; return; }
      var cur = out[out.length - 1];
      cur[0] = d;
      if (b[2] > cur[2]) cur[2] = b[2];
      if (b[3] < cur[3]) cur[3] = b[3];
      cur[4] = b[4];
      cur[5] = cur[5] + v;
    });
    return out;
  }

  root.TA = {KEYS: KEYS, sma: sma, ema: ema, rsi: rsi, kd: kd, macd: macd, bollinger: bollinger,
    computeIndicators: computeIndicators, resample: resample};
})(typeof window !== 'undefined' ? window : globalThis);
