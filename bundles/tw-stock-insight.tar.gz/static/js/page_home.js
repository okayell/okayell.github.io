/* 今日推薦 (#/) — market strip, daily picks, sector heat map, hot lists, news. */
(function () {
  'use strict';
  var S = {el: null, alive: false, unsub: null, hotTab: 'gainers', showAll: false, market: null, picks: null, morning: null, mode: ''};
  var STANCE_CLS = {'強勢多頭': 'solid-bull', '偏多': 'bull', '中性': '', '偏空': 'bear', '弱勢空頭': 'solid-bear'};
  var PICKS_FIRST = 8;

  function render(params, el) {
    S.el = el;
    S.alive = true;
    S.showAll = false;
    setTitle('今日推薦');
    el.innerHTML = '<div class="ph"><h1>今日推薦</h1><span class="sub">多因子模型：籌碼強度 × 月營收動能 × 技術趨勢</span></div>' +
      '<div class="campus-acad-bar"><b>🏛️ 財經學院 · 四大分院對照教學：</b>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/ta" href="https://okayell.github.io/finance/#/track/ta">📈 技術分析學院</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/fa" href="https://okayell.github.io/finance/#/track/fa">📊 基本面學院</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/chip" href="https://okayell.github.io/finance/#/track/chip">🧮 籌碼面學院</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/news" href="https://okayell.github.io/finance/#/track/news">📰 消息面學院</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/glossary" href="https://okayell.github.io/finance/#/glossary">📖 術語百科</a></div>' +
      '<div class="mstrip">' + [1, 2, 3, 4, 5].map(function () { return '<div class="skel" style="height:92px"></div>'; }).join('') + '</div>' +
      '<div class="sec-title"><h2>🏆 今日推薦</h2></div>' + skeleton(2, 260);
    el.addEventListener('click', onClick);
    S.unsub = onMeta(onMetaChange);
    return getMeta().then(function (m) {
      if (!S.alive) return;
      if (needsProgress(m)) { showProgress(m); return; }
      return load();
    });
  }

  function needsProgress(m) { return !m.data_date || metaState(m) === 'backfill'; }

  function onMetaChange(m) {
    if (!S.alive) return;
    if (needsProgress(m)) { showProgress(m); return; }
    if (S.mode === 'progress') load();
  }

  function showProgress(m) {
    S.mode = 'progress';
    var st = m.status || {}, pct = Math.round((st.progress || 0) * 100);
    setHtml(S.el, '<div class="card progress-card"><div style="font-size:40px">🛠️</div><h2>首次建立資料庫中… ' + pct + '%</h2>' +
      '<p class="muted">正在下載上市櫃歷史行情、三大法人、月營收與財報資料。完成後會自動顯示今日推薦，不需要重新整理。</p>' +
      '<div class="pbar"><span style="width:' + pct + '%"></span></div>' +
      '<div class="small muted">' + esc(st.step || '準備中') + (st.message ? '：' + esc(st.message) : '') + '</div>' +
      msgsHtml(st.errors) + '</div>');
  }

  function msgsHtml(errors) {
    if (!errors || !errors.length) return '';
    return '<details class="msgs"><summary>資料更新訊息（' + errors.length + '）</summary><ul>' +
      errors.slice(-20).map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></details>';
  }

  function load() {
    S.mode = 'data';
    var settle = function (p) { return p.then(function (d) { return {ok: true, d: d}; }, function (e) { return {ok: false, e: e}; }); };
    return Promise.all([
      settle(api('/api/market')),
      settle(api('/api/picks')),
      settle(api('/api/morning'))
    ]).then(function (res) {
      if (!S.alive) return;
      S.market = res[0];
      S.picks = res[1];
      S.morning = res[2];
      paint();
    });
  }

  function paint() {
    var m = S.market, p = S.picks, pm = S.morning, meta = App.meta || {};
    var head = '<div class="ph"><h1>今日推薦</h1><span class="sub">多因子模型：籌碼強度 × 月營收動能 × 技術趨勢</span></div>' +
      '<div class="campus-acad-bar"><b>🏛️ 財經學院 · 四大分院對照教學：</b>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/ta" href="https://okayell.github.io/finance/#/track/ta">📈 技術分析學院</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/fa" href="https://okayell.github.io/finance/#/track/fa">📊 基本面學院</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/chip" href="https://okayell.github.io/finance/#/track/chip">🧮 籌碼面學院</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/news" href="https://okayell.github.io/finance/#/track/news">📰 消息面學院</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/glossary" href="https://okayell.github.io/finance/#/glossary">📖 術語百科</a></div>' +
      '<div class="inline-disc-bar"><span>⚖️ <b>免責聲明：</b>本站量化評分與推薦清單純供個人研究參考，非投顧建議亦不保證獲利；<b>投資人應獨立判斷並自負一切投資盈虧，任何投資失敗或損失概與本站及開發者無關</b>。</span>' +
      '<button type="button" class="inline-disc-link" data-open-disclaimer="1">查看完整免責條款 →</button></div>';
    var marketH = !m.ok ? errorHtml(m.e.message) : (isEmptyPayload(m.d) ? '' : marketHtml(m.d));
    var morningH = (pm && pm.ok && !isEmptyPayload(pm.d)) ? morningStripHtml(pm.d) : '';
    var picksH;
    if (!p.ok) picksH = errorHtml(p.e.message);
    else if (isEmptyPayload(p.d)) picksH = buildingHtml(p.d.message);
    else picksH = picksHtml(p.d);
    var lower = '';
    if (m.ok && !isEmptyPayload(m.d)) {
      lower = '<div class="grid g-main-side mt"><section class="card" id="hHeat">' + heatCard(m.d) + '</section>' +
        '<section class="card" id="hHot">' + hotCard(m.d) + '</section></div>' + newsCard(m.d.news || []);
    } else if (m.ok) {
      lower = buildingHtml(m.d.message);
    }
    var st = meta.status || {};
    S.el.innerHTML = head + marketH + morningH + picksH + lower +
      disclaimerHtml('推薦清單由程式依公開資料自動計算，可能因資料延遲或錯誤而失準。') +
      (st.errors && st.errors.length ? '<div class="mt-s">' + msgsHtml(st.errors) + '</div>' : '');
    layoutHeat();
  }

  function morningStripHtml(d) {
    var dec = d.decision || {}, est = dec.taiex_est || {}, ses = d.us_session || {}, us = d.us_market || {};
    var allUs = [].concat(us.indices || [], us.adrs || [], us.tech || [], us.macro || []);
    var bySym = {};
    allUs.forEach(function (q) { bySym[q.symbol] = q; });
    var qPill = function (sym, lbl) {
      var q = bySym[sym];
      if (!q || !App.isNum(q.pct)) return '';
      var post = q.post && App.isNum(q.post.post_pct) && Math.abs(q.post.post_pct) >= 0.1
        ? ' <small class="muted">(盤後 ' + fmtPct(q.post.post_pct) + ')</small>' : '';
      return '<span class="hm-us-pill"><b>' + esc(lbl) + '</b> <span class="num ' + clsUpDown(q.pct) + '">' +
        arrow(q.pct) + ' ' + fmtPct(q.pct) + '</span>' + post + '</span>';
    };
    var evs = (d.events || []).slice(0, 3);
    return '<section class="card hm-pm-card mt">' +
      '<div class="card-h">' +
        '<h2>🌅 今日盤前美股與重大事件快報</h2>' +
        '<span class="chip ' + esc(dec.regime_cls || '') + '">' + esc(dec.regime || '中性震盪') + '</span>' +
        (dec.allocation ? '<span class="chip info">' + esc(dec.allocation) + '</span>' : '') +
        (ses.season ? '<span class="chip ghost">' + (ses.is_dst ? '🌞 ' : '❄️ ') + esc(ses.season) + ' · ' + esc(ses.session_zh || '') + '</span>' : '') +
        '<span class="sp"></span>' +
        '<a class="btn sm primary" href="#/morning">盤前戰情＆買賣重判 →</a>' +
      '</div>' +
      '<div class="hm-us-row">' +
        qPill('SOX', '費半 SOX') +
        qPill('IXIC', '那指') +
        qPill('SPX', '標普500') +
        qPill('TSM', '台積電 ADR') +
        qPill('NVDA', 'NVIDIA') +
        (App.isNum(est.tsm_adr_twd) ? '<span class="hm-us-pill"><b>TSM 折合台幣</b> <span class="num ' + clsUpDown(est.tsm_adr_spread_pct) + '">NT$ ' + fmtNum(est.tsm_adr_twd, 0) + ' (' + fmtPct(est.tsm_adr_spread_pct) + ')</span></span>' : '') +
        (App.isNum(est.est_pts) ? '<span class="hm-us-pill"><b>加權開盤推估</b> <span class="num ' + clsUpDown(est.est_pct) + '">' + (est.est_pts > 0 ? '+' : '') + fmtInt(est.est_pts) + ' 點 (' + fmtPct(est.est_pct) + ')</span></span>' : '') +
      '</div>' +
      (dec.summary_advice ? '<div class="small muted mt-s">' + esc(dec.summary_advice) + '</div>' : '') +
      (evs.length ? '<div class="hm-ev-grid mt-s">' + evs.map(function (ev) {
        var polCls = ev.polarity === 'bull' ? 'bull' : (ev.polarity === 'bear' ? 'bear' : 'info');
        var secs = (ev.affected_sectors || []).slice(0, 2).map(function (s) { return s.name; }).join('、');
        return '<a class="hm-ev" href="#/morning?ev=' + encodeURIComponent(ev.id) + '">' +
          '<div class="row wrap"><span class="chip ' + polCls + '">' + esc(ev.polarity_zh || '') + '</span>' +
          '<span class="chip ghost">' + esc(ev.category_label || '') + '</span></div>' +
          '<div class="hm-ev-ttl">' + esc(ev.title) + '</div>' +
          '<div class="small muted">牽動台股：<b>' + esc(secs || '相關供應鏈') + '</b> · 點擊查看受影響個股 →</div>' +
        '</a>';
      }).join('') + '</div>' : '') +
    '</section>';
  }

  // ------------------------------------------------------------------ market strip
  function idxCard(label, x) {
    x = x || {};
    var ser = (x.series || []).map(function (r) { return r[1]; });
    return '<div class="mk"><div class="mk-l">' + label + '</div><div class="mk-row"><div><div class="mk-v num">' + fmtNum(x.close, 2) +
      '</div><div class="mk-s ' + clsUpDown(x.chg) + '">' + arrow(x.chg) + ' ' + fmtNum(Math.abs(x.chg || 0), 2) + '（' + fmtPct(x.pct) +
      '）</div></div>' + (ser.length > 1 ? svgSpark(ser, {w: 104, h: 40}) : '') + '</div></div>';
  }
  function marketHtml(m) {
    var tv = m.turnover || {}, b = m.breadth || {}, inst = m.inst || {};
    var total = (tv.twse || 0) + (tv.tpex || 0);
    var n = (b.up || 0) + (b.down || 0) + (b.flat || 0) || 1;
    var instV = function (v) { return '<b class="' + clsUpDown(v) + '">' + (App.isNum(v) ? (v > 0 ? '+' : '') + fmtNum(v, 1) : '—') + '</b>'; };
    var tp = inst.tpex;
    return '<div class="mstrip">' + idxCard('加權指數', m.taiex) + idxCard('櫃買指數', m.otc) +
      '<div class="mk"><div class="mk-l">成交值</div><div class="mk-v num">' + fmtYi(total) + ' <small class="muted" style="font-size:13px">億</small></div>' +
      '<div class="mk-s muted">上市 ' + fmtYi(tv.twse) + ' · 上櫃 ' + fmtYi(tv.tpex) + '</div></div>' +
      '<div class="mk"><div class="mk-l">漲跌家數</div><div class="mk-v num"><span class="up">' + fmtInt(b.up) + '</span> <span class="muted" style="font-size:14px">/</span> <span class="down">' +
      fmtInt(b.down) + '</span></div><div class="breadth-bar" data-tip="上漲 ' + fmtInt(b.up) + '、平盤 ' + fmtInt(b.flat) + '、下跌 ' + fmtInt(b.down) + '">' +
      '<span style="width:' + ((b.up || 0) / n * 100).toFixed(1) + '%;background:#dc2626"></span><span style="width:' + ((b.flat || 0) / n * 100).toFixed(1) +
      '%;background:#cbd5e1"></span><span style="width:' + ((b.down || 0) / n * 100).toFixed(1) + '%;background:#16a34a"></span></div>' +
      '<div class="mk-s muted">漲停 <span class="up">' + fmtInt(b.limit_up) + '</span> · 跌停 <span class="down">' + fmtInt(b.limit_down) + '</span> · 平盤 ' + fmtInt(b.flat) + '</div></div>' +
      '<div class="mk"><div class="mk-l">三大法人（上市）<span class="sp"></span>' + esc(App.fmtMD(inst.date)) + '</div>' +
      '<div class="mk-v num ' + clsUpDown(inst.total) + '">' + (App.isNum(inst.total) ? (inst.total > 0 ? '+' : '') + fmtNum(inst.total, 1) : '—') +
      ' <small class="muted" style="font-size:13px">億</small></div><div class="mk-s">外資 ' + instV(inst.foreign) + ' · 投信 ' + instV(inst.trust) +
      ' · 自營 ' + instV(inst.dealer) + '</div>' + (tp ? '<div class="mk-s muted">上櫃合計 ' + instV(tp.total) + ' 億</div>' : '') + '</div></div>';
  }

  // ------------------------------------------------------------------ picks
  function picksHtml(d) {
    var picks = d.picks || [];
    var head = '<div class="sec-title"><h2>🏆 今日推薦</h2><span class="sub">' + picks.length + ' 檔 · 綜合分數由高到低</span><span class="sp"></span>' +
      '<a class="btn sm" href="#/picks">📊 績效追蹤</a><a class="btn sm" href="#/screener?p=top50">🧮 看前 50 名</a></div>';
    if (!picks.length) {
      return head + '<div class="card empty"><div class="big">🔍</div><h3>今天沒有符合條件的推薦股</h3><p>模型要求籌碼、營收與技術面同時達標，市場偏弱時清單可能為空。</p></div>';
    }
    var shown = S.showAll ? picks : picks.slice(0, PICKS_FIRST);
    var more = picks.length > PICKS_FIRST ? '<div class="row mt-s" style="justify-content:center"><button type="button" class="btn" data-act="more-picks">' +
      (S.showAll ? '收合，只看前 ' + PICKS_FIRST + ' 檔' : '顯示全部 ' + picks.length + ' 檔') + '</button></div>' : '';
    return head + '<div class="picks-grid">' + shown.map(pickCard).join('') + '</div>' + more;
  }
  function lvl(label, v, cls, ref, tip) {
    return '<div' + (tip ? ' data-tip="' + esc(tip) + '"' : '') + '><div class="lb">' + label + '</div><div class="v ' + (cls || '') + '">' +
      (App.isNum(v) ? fmtPrice(v, ref) : '—') + '</div></div>';
  }
  function pickCard(p) {
    var L = p.levels || {}, t = p.tech || {}, code = esc(p.code), href = '#/stock/' + encodeURIComponent(p.code);
    var sig = (p.signals || []).slice(0, 6);
    return '<article class="pick">' +
      '<div class="pick-hd"><div class="pick-rank' + (p.rank <= 3 ? ' top' : '') + '" data-tip="綜合排名">' + esc(p.rank || '') + '</div>' +
      '<div class="pick-id"><a class="pick-name" href="' + href + '">' + esc(p.name) + ' <span class="code">' + code + '</span></a>' +
      '<div class="pick-meta"><span class="chip">' + esc(p.market || '') + '</span>' + (p.industry ? '<span class="chip">' + esc(p.industry) + '</span>' : '') + '</div></div>' +
      scoreRing(p.score, 52) + '</div>' +
      '<div class="pick-px"><span class="px ' + clsUpDown(p.pct) + '">' + fmtPrice(p.close) + '</span><span class="chg ' + clsUpDown(p.pct) + '">' +
      arrow(p.pct) + ' ' + fmtPct(p.pct) + '</span>' + svgSpark(p.spark, {w: 150, h: 38}) + '</div>' +
      '<div class="pick-body">' + factorBars(p.factors) + '<ul class="reasons">' +
      (p.reasons || []).slice(0, 4).map(function (r) { return '<li>' + esc(r) + '</li>'; }).join('') + '</ul></div>' +
      '<div class="levels">' + lvl('支撐', L.support, 'sup', p.close, '下方支撐價位') + lvl('壓力', L.resistance, 'res', p.close, '上方壓力價位') +
      lvl('停損', L.stop, 'down', p.close, '跌破此價建議出場') + lvl('目標', L.target, 'up', p.close, '技術面推估目標價') +
      '<div data-tip="報酬風險比 = (目標 − 現價) ÷ (現價 − 停損)，越高越划算"><div class="lb">報酬風險比</div><div class="v">' + (App.isNum(L.rr) ? fmtNum(L.rr, 1) : '—') + '</div></div></div>' +
      (t.stance || t.summary ? '<div class="pick-tech"><span class="chip ' + (STANCE_CLS[t.stance] || '') + '">' + esc(t.stance || '技術面') +
        (App.isNum(t.score) ? ' ' + Math.round(t.score) : '') + '</span><span>' + esc(t.summary || '') + '</span></div>' : '') +
      '<div class="pick-ft">' + (sig.length || (p.risks || []).length ? '<div class="chips">' +
        (p.risks || []).map(function (r) { return '<span class="chip warn">⚠ ' + esc(r) + '</span>'; }).join('') + sig.map(sigChip).join('') + '</div>' : '<span class="sp"></span>') +
      '<a class="btn sm primary" href="' + href + '">個股分析 →</a>' + starBtn(p.code) + '</div></article>';
  }

  // ------------------------------------------------------------------ heat map
  function heatCard(m) {
    return '<div class="card-h"><h2>🌡️ 類股熱力圖</h2><span class="sub">面積 = 成交值、顏色 = 今日漲跌（成交值加權）</span><span class="sp"></span>' +
      '<a class="btn xs ghost" href="#/industry">全部類股 →</a></div><div class="heat" id="heatBox"></div>' +
      '<div class="heat-legend"><span>−4%</span><span class="scale">' + [-4, -3, -2, -1, 0, 1, 2, 3, 4].map(function (v) {
        return '<span style="background:' + heatColor(v).bg + '"></span>';
      }).join('') + '</span><span>+4%</span><span class="sp"></span><span>點擊類股 → 選股器篩選</span></div>';
  }
  function layoutHeat() {
    var box = document.getElementById('heatBox');
    if (!box || !S.market || !S.market.ok) return;
    var secs = (S.market.d.sectors || []).filter(function (s) { return (s.value || 0) > 0; })
      .sort(function (a, b) { return b.value - a.value; });
    var W = box.clientWidth || 800, H = box.clientHeight || 340;
    var rects = treemap(secs, W, H);
    box.innerHTML = secs.map(function (s, i) {
      var r = rects[i];
      if (!r) return '';
      var c = heatColor(s.pct_1d), small = r.w < 86 || r.h < 44, tiny = r.w < 46 || r.h < 26;
      var tip = s.name + '\n漲跌 ' + fmtPct(s.pct_1d) + '（5日 ' + fmtPct(s.pct_5d) + '、20日 ' + fmtPct(s.pct_20d) + '）\n成交值 ' +
        fmtYi(s.value) + ' 億（占 ' + fmtNum(s.value_share, 1) + '%）\n上漲 ' + fmtInt(s.up) + ' · 下跌 ' + fmtInt(s.down) + ' · 共 ' + fmtInt(s.count) + ' 檔' +
        ((s.leaders || []).length ? '\n領漲：' + s.leaders.map(function (x) { return x.name + ' ' + fmtPct(x.pct); }).join('、') : '');
      return '<div class="tile' + (small ? ' sm' : '') + '" data-href="#/screener?ind=' + encodeURIComponent(s.name) + '" data-tip="' + esc(tip) +
        '" style="left:' + (r.x / W * 100).toFixed(3) + '%;top:' + (r.y / H * 100).toFixed(3) + '%;width:' + (r.w / W * 100).toFixed(3) +
        '%;height:' + (r.h / H * 100).toFixed(3) + '%;background:' + c.bg + ';color:' + c.fg + '">' +
        (tiny ? '' : '<b>' + esc(s.name.replace(/業$/, '')) + '</b><span>' + fmtPct(s.pct_1d) + '</span>') + '</div>';
    }).join('');
  }

  // ------------------------------------------------------------------ hot lists + news
  var HOT_TABS = [['gainers', '漲幅榜'], ['losers', '跌幅榜'], ['value', '成交值榜']];
  function hotCard(m) {
    var list = (m.hot || {})[S.hotTab] || [];
    return '<div class="card-h"><h2>🔥 熱門榜</h2><span class="sp"></span><div class="seg" role="tablist">' + HOT_TABS.map(function (t) {
      return '<button type="button" class="' + (t[0] === S.hotTab ? 'on' : '') + '" data-hot="' + t[0] + '">' + t[1] + '</button>';
    }).join('') + '</div></div><div class="hot-list">' + (list.length ? list.slice(0, 10).map(function (r, i) {
      return '<div class="hot-row" data-href="#/stock/' + encodeURIComponent(r.code) + '" data-tip="' + esc((r.industry || '') + ' · 成交值 ' + fmtYi(r.value) + ' 億') +
        '"><span class="i">' + (i + 1) + '</span><span class="n">' + esc(r.name) + '<small>' + esc(r.code) + '</small></span>' +
        '<span class="c">' + (S.hotTab === 'value' ? fmtYi(r.value) + ' 億' : fmtPrice(r.close)) + '</span><span class="p ' + clsUpDown(r.pct) + '">' + fmtPct(r.pct) + '</span></div>';
    }).join('') : '<div class="empty">暫無資料</div>') + '</div>';
  }
  function newsCard(news) {
    if (!news.length) return '';
    return '<section class="card mt"><div class="card-h"><h2>📰 市場新聞</h2><span class="sub">外部連結，於新分頁開啟</span></div><div class="news-list">' +
      news.slice(0, 16).map(function (n) {
        return '<div class="news-item"><a href="' + esc(n.link) + '" target="_blank" rel="noopener noreferrer">' + esc(n.title) + '</a>' +
          '<span class="meta"><span>' + esc(n.source || '') + '</span><span>' + esc(relTime(n.time)) + '</span></span></div>';
      }).join('') + '</div></section>';
  }

  function onClick(ev) {
    var t = ev.target;
    var hot = t.closest('[data-hot]');
    if (hot) {
      S.hotTab = hot.getAttribute('data-hot');
      var box = document.getElementById('hHot');
      if (box && S.market && S.market.ok) setHtml(box, hotCard(S.market.d));
      return;
    }
    if (t.closest('[data-act="more-picks"]')) {
      S.showAll = !S.showAll;
      paint();
    }
  }

  var onResize = App.debounce(function () { if (S.alive && S.mode === 'data') layoutHeat(); }, 150);
  window.addEventListener('resize', onResize);

  window.Pages.home = {
    render: render,
    destroy: function () {
      S.alive = false;
      if (S.unsub) S.unsub();
      S.unsub = null;
      if (S.el) S.el.removeEventListener('click', onClick);
      S.mode = '';
    }
  };
})();
