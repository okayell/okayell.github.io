/* 版本資訊 & Release Notes (header version badge + modal).
 * Cloudtop: GET /api/release_status → unpublished-file detection, smart 1.x.x bump suggestion,
 * publish (POST /api/release_publish) and the GitHub single-file download.
 * GitHub static build: release history only (from the embedded snapshot).
 * Exposes window.Releases = {open, close, refresh}.
 */
(function () {
  'use strict';
  var BUMP = {
    patch: {badge: 'Patch 細節修正', cls: 'ok', digit: '進第 3 位（1.x.X）', dflt: '微調樣式、文字修正、小 Bug 修復'},
    minor: {badge: 'Minor 功能擴充', cls: 'info', digit: '進第 2 位（1.X.0）', dflt: '新增功能、頁面、圖表或資料來源'},
    major: {badge: 'Major 大改版', cls: 'bad', digit: '進第 1 位（X.0.0）', dflt: '全站架構大改版、跨模組大規模升級'}
  };
  var STATUS_CLS = {added: 'ok', modified: 'warn', deleted: 'bad'};
  var R = {status: null, loading: false, err: '', sel: '', confirm: false, publishing: false, isOpen: false,
    lastFocus: null, form: {title: null, notes: null}, confirmTimer: 0, inflight: null};

  function esc(s) { return window.esc ? window.esc(s) : String(s === null || s === undefined ? '' : s); }
  function isStatic() {
    return !!(
      (window.App && App.isStatic) ||
      window.__STATIC_API__ ||
      location.protocol === 'file:' ||
      /\.github\.io$|\.pages\.dev$|\.netlify\.app$|\.vercel\.app$/i.test(location.hostname || '') ||
      (R.status && R.status.static)
    );
  }
  function curVersion() {
    return (R.status && R.status.current_version) || (window.App && App.meta && App.meta.version) ||
      (window.TW_STATIC && window.TW_STATIC.version) || '';
  }
  function changedCount() { return !isStatic() && R.status && R.status.has_changes ? (R.status.changed_files || []).length : 0; }

  // ------------------------------------------------------------------ header badge
  function renderBadge() {
    var b = document.getElementById('verBadge');
    if (!b) return;
    var v = curVersion(), n = changedCount();
    b.textContent = v ? 'v' + v : 'v—';
    b.classList.toggle('dirty', n > 0);
    b.setAttribute('data-tip', isStatic() ? '版本 v' + v + '（點擊查看 Release Notes）' :
      (n > 0 ? n + ' 個檔案尚未發布（點擊查看並發布新版本）' : '目前版本 v' + v + '（點擊查看 Release Notes 與發布中心）'));
    b.setAttribute('aria-label', '版本資訊 v' + v + (n ? '，' + n + ' 個檔案尚未發布' : ''));
  }

  function fetchStatus() {
    if (isStatic()) {
      R.status = (window.__STATIC_API__ || {})['/api/release_status'] || {static: true, current_version: curVersion(), releases: []};
      renderBadge();
      if (R.isOpen) render();
      return Promise.resolve(R.status);
    }
    if (R.inflight) return R.inflight;
    R.loading = true;
    R.err = '';
    if (R.isOpen) render();
    R.inflight = api('/api/release_status', {cache: false}).then(function (st) {
      R.status = st;
      if (!R.sel || !st.next_versions || !st.next_versions[R.sel]) R.sel = st.recommended_bump || 'patch';
      return st;
    }, function (e) {
      R.err = e.message || '無法取得版本狀態';
      return null;
    }).then(function (st) {
      R.loading = false;
      R.inflight = null;
      renderBadge();
      if (R.isOpen) render();
      return st;
    });
    return R.inflight;
  }

  // ------------------------------------------------------------------ modal
  function ensureModal() {
    var bd = document.getElementById('relModal');
    if (bd) return bd;
    bd = document.createElement('div');
    bd.id = 'relModal';
    bd.className = 'modal-bd hidden';
    bd.innerHTML = '<div class="modal rel-modal" role="dialog" aria-modal="true" aria-labelledby="relTitleH" tabindex="-1"></div>';
    bd.addEventListener('mousedown', function (ev) { if (ev.target === bd) close(); });
    bd.addEventListener('click', onClick);
    bd.addEventListener('input', onInput);
    bd.addEventListener('keydown', onKey);
    document.body.appendChild(bd);
    return bd;
  }
  function open() {
    var bd = ensureModal();
    R.lastFocus = document.activeElement;
    R.isOpen = true;
    R.confirm = false;
    bd.classList.remove('hidden');
    document.body.classList.add('modal-open');
    render();
    var box = bd.querySelector('.modal');
    if (box) box.focus({preventScroll: true});
    if (!R.publishing) fetchStatus();
  }
  function close() {
    var bd = document.getElementById('relModal');
    if (!bd || !R.isOpen) return;
    if (R.publishing) { toast('發布進行中，請稍候完成再關閉', 'warn'); return; }
    R.isOpen = false;
    bd.classList.add('hidden');
    document.body.classList.remove('modal-open');
    if (R.lastFocus && R.lastFocus.focus) R.lastFocus.focus({preventScroll: true});
  }

  function fmtBytes(n) {
    if (!App.isNum(n)) return '—';
    return n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.round(n / 1024) + ' KB';
  }
  function distHtml(dist) {
    if (!dist) {
      return '<div class="dist-card"><b>📦 GitHub 版打包檔</b><span class="muted small">尚未打包；第一次下載時會自動打包（約 20 秒）。</span></div>';
    }
    return '<div class="dist-card"><b>📦 目前 GitHub 版打包檔</b>' +
      '<span class="chip">版本 v' + esc(dist.version || '—') + '</span><span class="chip">資料日期 ' + esc(dist.data_date || '—') + '</span>' +
      '<span class="chip">大小 ' + fmtBytes(dist.bytes) + '</span><span class="chip">收錄 ' + fmtInt(dist.stocks_full) + ' 檔完整個股</span>' +
      (dist.built_at ? '<span class="chip ghost">打包於 ' + esc(String(dist.built_at).replace('T', ' ').slice(0, 16)) + '</span>' : '') +
      (dist.fresh ? '<span class="chip ok">✅ 已是最新</span>' : '<span class="chip warn" data-tip="程式、版本或資料日期已變動，下載時會自動重新打包（約 20 秒）">⏳ 下載時自動重新打包</span>') + '</div>';
  }
  function howtoHtml() {
    return '<details class="rel-howto"><summary>📘 如何發布到 GitHub Pages（免費公開網站）</summary><ol>' +
      '<li>按「⬇️ 下載 GitHub 版 index.html」取得單一 HTML 檔（已內含資料快照、圖表程式庫與全部頁面）。</li>' +
      '<li>在 GitHub 建立新的 repository，把 <code>index.html</code> 上傳到根目錄（Add file › Upload files）。</li>' +
      '<li>到 <b>Settings › Pages</b>，Source 選 <b>Deploy from a branch</b>，Branch 選 <code>main</code>、資料夾 <code>/ (root)</code>，按 Save。</li>' +
      '<li>約 1 分鐘後開啟 <code>https://&lt;帳號&gt;.github.io/&lt;repo&gt;/</code> 即可瀏覽。</li></ol>' +
      '<p class="small muted">靜態檔包含打包當下的資料快照：每天資料更新後，請重新下載並重新上傳 <code>index.html</code>（覆蓋舊檔）即可同步。</p></details>';
  }
  function historyHtml(list) {
    if (!list || !list.length) return '<div class="small muted">尚無版本紀錄。</div>';
    return '<div class="rel-tl">' + list.map(function (r, i) {
      var b = BUMP[r.bump] || BUMP.minor;
      return '<div class="rel-item' + (i === 0 ? ' latest' : '') + '"><div class="ri-head"><span class="ri-ver">v' + esc(r.version) + '</span>' +
        (i === 0 ? '<span class="chip info">目前版本</span>' : '') + '<span class="chip ' + b.cls + '">' + b.badge + '</span>' +
        '<span class="small muted">📅 ' + esc(r.date || '') + (r.files_count ? ' · ' + fmtInt(r.files_count) + ' 個檔案' : '') + '</span></div>' +
        (r.title ? '<div class="ri-title">' + esc(r.title) + '</div>' : '') +
        ((r.highlights || []).length ? '<ul class="ri-list">' + r.highlights.map(function (h) { return '<li>' + esc(h) + '</li>'; }).join('') + '</ul>' : '') + '</div>';
    }).join('') + '</div>';
  }
  function filesHtml(st) {
    return '<div class="tbl-wrap rel-files"><table class="tbl"><thead><tr><th class="l">分類</th><th class="l">修改檔案與說明</th><th class="c">狀態</th>' +
      '<th>行數</th></tr></thead><tbody>' + (st.changed_files || []).map(function (f) {
        return '<tr><td class="l"><span class="chip info">' + esc(f.cat || '其他') + '</span></td><td class="l wrap"><code class="rel-path">' + esc(f.path) + '</code>' +
          (f.desc ? '<div class="small muted">' + esc(f.desc) + '</div>' : '') + '</td><td class="c"><span class="chip ' + (STATUS_CLS[f.status] || 'warn') + '">' +
          esc(f.status_zh || f.status || '') + '</span></td><td class="nowrap"><b class="diff-add">+' + fmtInt(f.added_lines || 0) + '</b> <b class="diff-del">−' +
          fmtInt(f.removed_lines || 0) + '</b></td></tr>';
      }).join('') + '</tbody></table></div>';
  }
  function bumpCards(st) {
    var nv = st.next_versions || {}, txt = st.bump_text || {};
    return '<div class="bump-cards" role="radiogroup" aria-label="選擇版號進位">' + ['patch', 'minor', 'major'].map(function (b) {
      var on = R.sel === b, rec = st.recommended_bump === b;
      return '<button type="button" class="bump-card' + (on ? ' on' : '') + '" role="radio" aria-checked="' + on + '" data-bump="' + b + '"' + (R.publishing ? ' disabled' : '') + '>' +
        '<span class="bc-top"><b class="bc-ver">v' + esc(nv[b] || '—') + '</b>' + (rec ? '<span class="chip ok">🤖 系統建議</span>' : '') + '</span>' +
        '<span class="chip ' + BUMP[b].cls + '">' + BUMP[b].badge + '</span><span class="bc-digit">' + BUMP[b].digit + '</span>' +
        '<span class="bc-desc">' + esc(txt[b] || BUMP[b].dflt) + '</span></button>';
    }).join('') + '</div>';
  }
  function publishLabel(st) {
    var v = (st.next_versions || {})[R.sel] || '';
    if (R.publishing) return '<span class="spin"></span> 發布中…正在重新打包 GitHub 版（約 10–30 秒）';
    if (R.confirm) return '⚠️ 確定發布 v' + esc(v) + '？再按一次確認';
    return '🚀 發布新版本 v' + esc(v);
  }
  function exportCardHtml(st) {
    var download = '<a class="btn primary" href="/download/index.html" download="index.html" data-rel="download">⬇️ 直接下載最新 index.html</a>';
    return '<div class="rel-box" style="background:#f8fafc;border-color:#e2e8f0">' +
      '<div class="rb-head"><div><b>📦 GitHub Pages 單一檔案匯出（免安裝靜態版）</b>' +
      '<p class="small muted" style="margin:3px 0 0">將最新台股行情快照、技術指標與所有頁面打包成單一 <code>index.html</code>，直接拖進 GitHub 即可發布公開網頁（公開版僅顯示 Release Notes）。</p></div>' +
      download + '</div>' + distHtml(st.dist) + howtoHtml() + '</div>';
  }
  function statusHtml() {
    var st = R.status;
    if (R.loading && !st) return '<div class="rel-box"><span class="loading-inline"><span class="spin"></span> 正在檢查未發布的修改…</span></div>';
    if (R.err && !st) {
      return '<div class="rel-box dirty"><b>⚠️ 無法取得版本狀態</b><p class="small muted">' + esc(R.err) + '</p>' +
        '<button type="button" class="btn sm" data-rel="retry">重試</button></div>';
    }
    if (!st) return '';
    if (!st.has_changes) {
      return exportCardHtml(st) +
        '<div class="rel-box clean"><div class="rb-head"><div><span class="chip ok">✅ 已是最新版本</span> <b>目前工作目錄所有程式碼皆與最新發布版 v' + esc(st.current_version) + ' 同步，無待發布修改。</b></div></div></div>';
    }
    var title = R.form.title !== null ? R.form.title : (st.suggested_title || '');
    var notes = R.form.notes !== null ? R.form.notes : (st.suggested_highlights || []).join('\n');
    return exportCardHtml(st) +
      '<div class="rel-box dirty"><div class="rb-head"><div><span class="chip warn">⚠️ 尚未發布</span> <b>' + fmtInt((st.changed_files || []).length) +
      ' 個檔案自 v' + esc(st.current_version) + ' 後有修改</b></div><span class="small">總變動 <b class="diff-add">+' + fmtInt(st.total_added || 0) +
      '</b> <b class="diff-del">−' + fmtInt(st.total_removed || 0) + '</b> 行</span></div>' +
      (st.recommendation_reason ? '<div class="rel-advice">🧭 <b>智慧版號判斷：</b>' + esc(st.recommendation_reason) + '</div>' : '') +
      filesHtml(st) + '<div class="subh">選擇版號</div>' + bumpCards(st) +
      '<div class="rel-form"><label for="relTitle"><b>版本標題</b></label><input class="input" id="relTitle" maxlength="120" placeholder="一句話描述這次更新" value="' + esc(title) + '"' +
      (R.publishing ? ' disabled' : '') + '><label for="relNotes"><b>更新細項</b> <span class="small muted">（每行一條，已依修改檔案預填，可自行編輯）</span></label>' +
      '<textarea class="input" id="relNotes" rows="4"' + (R.publishing ? ' disabled' : '') + '>' + esc(notes) + '</textarea>' +
      '<div class="rel-actions"><button type="button" class="btn primary" id="relPublish" data-rel="publish"' + (R.publishing ? ' disabled' : '') + '>' + publishLabel(st) + '</button>' +
      '</div></div></div>';
  }
  function render() {
    var bd = ensureModal(), box = bd.querySelector('.modal');
    var st = R.status, list = (st && st.releases) || [];
    var stMode = isStatic();
    var headTitle = stMode ? '📜 台股智慧選股 · Release Notes' : '🚀 台股智慧選股 · 版本紀錄與發布中心';
    var headSub = stMode ? '' : '<p class="small muted">遵循語意化版本 <code>MAJOR.MINOR.PATCH (1.x.x)</code>：大改版進第 1 位、新功能進第 2 位、細節修正進第 3 位。</p>';
    var head = '<div class="modal-h"><div class="modal-ttl"><div class="row wrap"><h2 id="relTitleH">' + headTitle + '</h2>' +
      '<span class="ver-pill">v' + esc(curVersion()) + '</span></div>' + headSub +
      '</div><button type="button" class="btn sm ghost" data-rel="close" aria-label="關閉">✕</button></div>';
    var body = '<div class="modal-b">' + (stMode ? '' : statusHtml()) +
      '<h3 class="rel-sec"' + (stMode ? ' style="margin-top:0"' : '') + '>📜 Release Notes 歷史版本紀錄</h3>' + historyHtml(list) + '</div>';
    var scroll = box.querySelector('.modal-b');
    var top = scroll ? scroll.scrollTop : 0;
    var focusId = document.activeElement && box.contains(document.activeElement) ? document.activeElement.id : '';
    var selStart = focusId && document.activeElement.selectionStart;
    box.innerHTML = head + body;
    var nb = box.querySelector('.modal-b');
    if (nb) nb.scrollTop = top;
    if (focusId) {
      var el = document.getElementById(focusId);
      if (el) { el.focus({preventScroll: true}); try { el.setSelectionRange(selStart, selStart); } catch (e) { /* not a text field */ } }
    }
  }

  // ------------------------------------------------------------------ actions
  function syncPublishBtn() {
    var b = document.getElementById('relPublish');
    if (b && R.status) b.innerHTML = publishLabel(R.status);
  }
  function selectBump(b) {
    if (R.publishing || !BUMP[b]) return;
    R.sel = b;
    R.confirm = false;
    var bd = document.getElementById('relModal');
    App.$$('.bump-card', bd).forEach(function (c) {
      var on = c.getAttribute('data-bump') === b;
      c.classList.toggle('on', on);
      c.setAttribute('aria-checked', on ? 'true' : 'false');
    });
    syncPublishBtn();
  }
  function publish() {
    var st = R.status;
    if (!st || R.publishing || !st.has_changes) return;
    if (!R.confirm) {
      R.confirm = true;
      syncPublishBtn();
      clearTimeout(R.confirmTimer);
      R.confirmTimer = setTimeout(function () { R.confirm = false; syncPublishBtn(); }, 6000);
      return;
    }
    clearTimeout(R.confirmTimer);
    var title = (document.getElementById('relTitle') || {}).value || '';
    var notes = ((document.getElementById('relNotes') || {}).value || '').split('\n').map(function (x) { return x.trim(); }).filter(Boolean);
    if (!title.trim()) { R.confirm = false; syncPublishBtn(); toast('請先填寫版本標題', 'warn'); return; }
    R.confirm = false;
    R.publishing = true;
    render();
    api('/api/release_publish', {method: 'POST', body: JSON.stringify({bump: R.sel, title: title.trim(), highlights: notes})}).then(function (out) {
      if (!out || !out.ok) throw new Error((out && out.error) || '發布失敗');
      R.status = out.status || R.status;
      R.form = {title: null, notes: null};
      R.sel = (R.status && R.status.recommended_bump) || 'patch';
      toast('🎉 已發布 v' + out.new_version + '，GitHub 版已重新打包', 'ok', 4000);
      getMeta(true).then(null, function () {});
    }, function (e) {
      toast('發布失敗：' + (e.message || '未知錯誤'), 'err', 5000);
    }).then(function () {
      R.publishing = false;
      renderBadge();
      if (R.isOpen) render();
    });
  }
  function onClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-bump]'))) { selectBump(x.getAttribute('data-bump')); return; }
    if ((x = t.closest('[data-rel]'))) {
      var act = x.getAttribute('data-rel');
      if (act === 'close') close();
      else if (act === 'retry') fetchStatus();
      else if (act === 'publish') publish();
      else if (act === 'download') {
        toast(R.status && R.status.dist && R.status.dist.fresh ? '開始下載 index.html' : '正在準備下載（需要重新打包時約 20 秒）…', '', 4000);
      }
    }
  }
  function onInput(ev) {
    if (ev.target.id === 'relTitle') R.form.title = ev.target.value;
    else if (ev.target.id === 'relNotes') R.form.notes = ev.target.value;
  }
  function onKey(ev) {
    // IME-safe: Enter in the title moves to the notes (never publishes by accident).
    if (ev.target.id === 'relTitle' && App.isEnterSend(ev)) {
      ev.preventDefault();
      var n = document.getElementById('relNotes');
      if (n) n.focus();
    }
    if (ev.key === 'Tab') {
      var box = document.querySelector('#relModal .modal');
      var f = App.$$('button:not([disabled]), a[href], input:not([disabled]), textarea:not([disabled]), summary', box);
      if (!f.length) return;
      if (ev.shiftKey && document.activeElement === f[0]) { ev.preventDefault(); f[f.length - 1].focus(); }
      else if (!ev.shiftKey && document.activeElement === f[f.length - 1]) { ev.preventDefault(); f[0].focus(); }
    }
  }

  // ------------------------------------------------------------------ init
  var lastVer = null;
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && R.isOpen) { ev.preventDefault(); close(); }
  });
  function init() {
    var b = document.getElementById('verBadge');
    if (b) b.addEventListener('click', function (ev) { ev.preventDefault(); open(); });
    renderBadge();
    App.onMeta(function (m, info) {
      var verChanged = lastVer !== null && m.version !== lastVer;
      var first = lastVer === null;
      lastVer = m.version;
      renderBadge();
      if (first || verChanged || (info && info.changed)) fetchStatus();
    });
    if (window.App && App.meta && lastVer === null) { lastVer = App.meta.version; renderBadge(); fetchStatus(); }
    if (/[?&]releases=1/.test(location.search)) setTimeout(open, 300);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else setTimeout(init, 0);

  window.Releases = {open: open, close: close, refresh: fetchStatus};
})();
