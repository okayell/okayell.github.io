/* 台股智慧選股 — core: router, API cache, formatting, search, watchlist, SVG helpers.
 * Pages live in their own IIFEs (static/js/page_*.js) and register
 * window.Pages[name] = {render(params, el), update?(params), refresh?(), destroy()}.
 */
(function () {
  'use strict';
  window.Pages = window.Pages || {};
  var App = window.App = {};
  var DISCLAIMER = '本站所有量化評分、今日推薦、盤前戰情、選股篩選與技術指標分析，均由程式依公開歷史資料自動運算，純供個人量化研究參考，絕不構成任何證券投資顧問建議、買賣邀約或獲利保證；投資人應獨立判斷並自行查證，任何投資決策之盈虧、投資失敗或財務損失皆由投資人完全自負，概與本站及開發者無關。';
  // GitHub static build: API snapshot + build info are injected before this script.
  var STATIC_API = window.__STATIC_API__ || null;
  var TWS = window.TW_STATIC || null;
  var IS_STATIC = !!STATIC_API;

  // ------------------------------------------------------------------ DOM utils
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) {
    if (s === null || s === undefined) return '';
    return String(s).replace(/[&<>"']/g, function (c) {
      return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c];
    });
  }
  /** Zero-flicker: only touch innerHTML when the markup actually changed. */
  function setHtml(el, html) {
    if (!el) return false;
    if (el.__html === html) return false;
    el.innerHTML = html;
    el.__html = html;
    return true;
  }
  function debounce(fn, ms) {
    var t = null;
    return function () {
      var self = this, args = arguments;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, ms);
    };
  }
  function isTyping(t) {
    if (!t) return false;
    var tag = (t.tagName || '').toLowerCase();
    return tag === 'input' || tag === 'textarea' || tag === 'select' || t.isContentEditable;
  }

  // ------------------------------------------------------------------ formatting
  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  var NF = {};
  function nf(d) {
    return NF[d] || (NF[d] = new Intl.NumberFormat('en-US', {minimumFractionDigits: d, maximumFractionDigits: d}));
  }
  function fmtNum(v, d) { return isNum(v) ? nf(d === undefined || d === null ? 2 : d).format(v) : '—'; }
  function fmtInt(v) { return isNum(v) ? nf(0).format(Math.round(v)) : '—'; }
  function fmtPct(v, d, noSign) {
    if (!isNum(v)) return '—';
    return (!noSign && v > 0 ? '+' : '') + nf(d === undefined || d === null ? 2 : d).format(v) + '%';
  }
  function pricePrec(p) { p = Math.abs(p); return p >= 1000 ? 0 : (p >= 100 ? 1 : 2); }
  function fmtPrice(v, ref) {
    if (!isNum(v)) return '—';
    return nf(pricePrec(isNum(ref) ? ref : v)).format(v);
  }
  function fmtChg(v, ref) { return isNum(v) ? (v > 0 ? '+' : '') + fmtPrice(v, isNum(ref) ? ref : v) : '—'; }
  function fmtYi(v) {
    if (!isNum(v)) return '—';
    var a = Math.abs(v);
    return nf(a >= 1000 ? 0 : (a >= 100 ? 1 : 2)).format(v);
  }
  function fmtCompact(v) {
    if (!isNum(v)) return '—';
    var a = Math.abs(v);
    if (a >= 1e8) return nf(2).format(v / 1e8) + '億';
    if (a >= 1e4) return nf(a >= 1e6 ? 0 : 1).format(v / 1e4) + '萬';
    return nf(0).format(v);
  }
  function fmtScore(v) {
    if (!isNum(v)) return '—';
    var r = Math.round(v * 10) / 10;
    return r % 1 === 0 ? String(r) : nf(1).format(r);
  }
  function fmtMD(s) { return s && s.length >= 10 ? s.slice(5, 7) + '/' + s.slice(8, 10) : (s || '—'); }
  function relTime(iso) {
    var t = Date.parse(iso || '');
    if (!t) return '';
    var m = Math.round((Date.now() - t) / 60000);
    if (m < 1) return '剛剛';
    if (m < 60) return m + ' 分鐘前';
    if (m < 60 * 24) return Math.round(m / 60) + ' 小時前';
    if (m < 60 * 24 * 7) return Math.round(m / 1440) + ' 天前';
    return fmtMD(iso.slice(0, 10));
  }
  function clsUpDown(v) { return isNum(v) && v > 0 ? 'up' : (isNum(v) && v < 0 ? 'down' : 'flat'); }
  /** Coloured % span (Taiwan convention: 漲紅跌綠). */
  function pctSpan(v, d) { return '<span class="' + clsUpDown(v) + '">' + fmtPct(v, d) + '</span>'; }
  function arrow(v) { return isNum(v) && v > 0 ? '▲' : (isNum(v) && v < 0 ? '▼' : ''); }

  // ------------------------------------------------------------------ chips
  var SIG_CLASS = {};
  ('多頭排列 站上月線 站上季線 創52週新高 突破60日高 突破箱型 跳空上漲 KD黃金交叉 KD高檔鈍化 MACD黃金交叉 ' +
   'MACD翻紅 布林突破上軌 價漲量增 長紅K 多頭吞噬 錘子線 晨星').split(' ').forEach(function (t) { SIG_CLASS[t] = 'bull'; });
  ('空頭排列 跌破月線 跌破季線 跌破60日低 跳空下跌 KD死亡交叉 KD低檔鈍化 MACD死亡交叉 MACD翻綠 布林跌破下軌 ' +
   '價跌量增 長黑K 空頭吞噬 夜星').split(' ').forEach(function (t) { SIG_CLASS[t] = 'bear'; });
  '外資連買 投信連買 法人同買 投信大買 營收創高 營收高成長 EPS成長 高殖利率'.split(' ').forEach(function (t) { SIG_CLASS[t] = 'fund'; });
  'RSI超買 RSI超賣 爆量'.split(' ').forEach(function (t) { SIG_CLASS[t] = 'warn'; });
  var SIG_TIP = {
    '多頭排列': 'MA5 > MA10 > MA20 > MA60，短中長期均線由上而下排列', '空頭排列': '均線由下而上排列，趨勢偏空',
    '站上月線': '近 3 根K棒收盤由下往上突破 20 日均線', '跌破月線': '近 3 根K棒收盤跌破 20 日均線',
    '站上季線': '近 3 根K棒收盤突破 60 日均線', '跌破季線': '近 3 根K棒收盤跌破 60 日均線',
    '均線糾結': '多條均線靠得很近，常是變盤前兆', '創52週新高': '收盤創一年來新高',
    '突破60日高': '收盤突破近 60 日高點', '跌破60日低': '收盤跌破近 60 日低點', '突破箱型': '突破整理區間上緣',
    'KD黃金交叉': 'K 值由下往上穿越 D 值（近 3 根）', 'KD死亡交叉': 'K 值由上往下跌破 D 值（近 3 根）',
    'KD高檔鈍化': 'K 值連續在 80 以上，強勢', 'KD低檔鈍化': 'K 值連續在 20 以下，弱勢',
    'MACD黃金交叉': 'DIF 向上穿越 DEA', 'MACD死亡交叉': 'DIF 向下跌破 DEA', 'MACD翻紅': '柱狀體由負轉正',
    'MACD翻綠': '柱狀體由正轉負', 'RSI超買': 'RSI 高於 70～80，短線漲多', 'RSI超賣': 'RSI 低於 20～30，短線跌深',
    '布林突破上軌': '收盤高於布林上軌', '布林跌破下軌': '收盤低於布林下軌', '布林收斂': '布林通道變窄，波動降低',
    '爆量': '成交量為 20 日均量 2 倍以上', '量增': '成交量明顯放大', '量縮': '成交量明顯萎縮',
    '外資連買': '外資連續多日買超', '投信連買': '投信連續多日買超', '法人同買': '外資與投信同步買超',
    '投信大買': '投信單日大量買超', '營收創高': '近 3 個月平均營收創 12 個月新高', '營收高成長': '月營收年增率高',
    'EPS成長': '近一季 EPS 年增', '高殖利率': '現金殖利率高'
  };
  function sigClass(tag) { return SIG_CLASS[tag] || ''; }
  function sigChip(tag) {
    var tip = SIG_TIP[tag];
    return '<span class="chip ' + sigClass(tag) + '"' + (tip ? ' data-tip="' + esc(tip) + '"' : '') + '>' + esc(tag) + '</span>';
  }
  var RISK_CLASS = {'處置': 'bad', '注意': 'warn', '過熱': 'warn', '流動性不足': 'ghost', '虧損': 'bad', '全額交割': 'bad'};
  var RISK_TIP = {'處置': '處置股：交易受限（分盤撮合／預收款券）', '注意': '注意股：近期交易異常',
    '過熱': '短期漲幅過大', '流動性不足': '成交量偏低，進出可能有滑價', '虧損': '近四季 EPS 為負'};
  function riskChip(tag) {
    return '<span class="chip ' + (RISK_CLASS[tag] || 'warn') + '"' + (RISK_TIP[tag] ? ' data-tip="' + esc(RISK_TIP[tag]) + '"' : '') +
      '>⚠ ' + esc(tag) + '</span>';
  }

  // ------------------------------------------------------------------ toast / tooltip
  function toast(msg, kind, ms) {
    var wrap = $('#toasts');
    if (!wrap) return;
    var el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = msg;
    wrap.appendChild(el);
    while (wrap.children.length > 3) wrap.removeChild(wrap.firstChild);
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, ms || 2600);
  }
  var tipEl = null, tipTarget = null, tipRaf = 0, tipX = 0, tipY = 0;
  function placeTip() {
    tipRaf = 0;
    if (!tipEl || tipEl.style.display !== 'block') return;
    var w = tipEl.offsetWidth, h = tipEl.offsetHeight;
    var x = tipX + 14, y = tipY + 16;
    if (x + w > window.innerWidth - 8) x = Math.max(8, tipX - w - 12);
    if (y + h > window.innerHeight - 8) y = Math.max(8, tipY - h - 12);
    tipEl.style.transform = 'translate(' + Math.round(x) + 'px,' + Math.round(y) + 'px)';
  }
  function initTips() {
    tipEl = $('#tip');
    document.addEventListener('mouseover', function (ev) {
      var t = ev.target && ev.target.closest ? ev.target.closest('[data-tip]') : null;
      if (t === tipTarget) return;
      tipTarget = t;
      var txt = t ? t.getAttribute('data-tip') : '';
      if (!t || !txt) { tipEl.style.display = 'none'; return; }
      tipEl.textContent = txt;
      tipEl.style.left = '0px';
      tipEl.style.top = '0px';
      tipEl.style.display = 'block';
      tipX = ev.clientX; tipY = ev.clientY;
      placeTip();
    });
    document.addEventListener('mousemove', function (ev) {
      if (!tipTarget) return;
      tipX = ev.clientX; tipY = ev.clientY;
      if (!tipRaf) tipRaf = requestAnimationFrame(placeTip);
    }, {passive: true});
    var hide = function () { tipTarget = null; if (tipEl) tipEl.style.display = 'none'; };
    document.addEventListener('scroll', hide, {passive: true, capture: true});
    document.addEventListener('mousedown', hide, true);
    window.addEventListener('blur', hide);
  }

  // ------------------------------------------------------------------ IME-safe Enter
  var IME_ON = false, IME_END = 0;
  document.addEventListener('compositionstart', function () { IME_ON = true; }, true);
  document.addEventListener('compositionend', function () { IME_ON = false; IME_END = Date.now(); }, true);
  function isEnterSend(ev) {
    return ev.key === 'Enter' && !ev.isComposing && ev.keyCode !== 229 && !IME_ON && Date.now() - IME_END >= 150;
  }

  // ------------------------------------------------------------------ API + caches
  var MEM = {}, INFLIGHT = {};
  var pendingCount = 0;
  function api(path, opts) {
    opts = opts || {};
    var method = opts.method || 'GET';
    var cacheable = method === 'GET' && opts.cache !== false;
    if (cacheable && !opts.force && MEM[path]) return Promise.resolve(MEM[path]);
    if (cacheable && !opts.force && INFLIGHT[path]) return INFLIGHT[path];
    pendingCount++;
    var headers = {'Accept': 'application/json'};
    if (opts.body) headers['Content-Type'] = 'application/json';
    var p = IS_STATIC ? staticResolve(path, method) : fetch(path, {method: method, headers: headers, body: opts.body || undefined})
      .then(function (res) {
        return res.text().then(function (txt) {
          var data = null;
          try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = null; }
          if (!res.ok) {
            var err = new Error((data && data.error) || ('伺服器回應 ' + res.status));
            err.status = res.status;
            throw err;
          }
          if (data === null || typeof data !== 'object') throw new Error('回應格式錯誤');
          return data;
        });
      }, function () { throw new Error('無法連線到伺服器，請確認服務是否啟動'); });
    var done = function () { pendingCount--; if (cacheable) delete INFLIGHT[path]; };
    p.then(function (d) {
      done();
      if (cacheable && !d.empty) MEM[path] = d;
      if (path === '/api/picks' && d.method) setWeights(d.method.weights);
    }, done);
    if (cacheable) INFLIGHT[path] = p;
    return p;
  }
  // ------------------------------------------------------------------ static (GitHub) mode
  function staticErr(status, msg) { var e = new Error(msg); e.status = status; return e; }
  function staticRows() {
    var u = STATIC_API['/api/universe'] || {}, f = u.fields || [];
    return (u.rows || []).map(function (r) { var o = {}; for (var j = 0; j < f.length; j++) o[f[j]] = r[j]; return o; });
  }
  var STATIC_ROWS = null;
  function staticRow(code) {
    if (!STATIC_ROWS) { STATIC_ROWS = {}; staticRows().forEach(function (o) { STATIC_ROWS[o.code] = o; }); }
    return STATIC_ROWS[code] || null;
  }
  /** Chain positions of a code, searched in the embedded /api/industry/<id> payloads. */
  function staticChains(code) {
    var out = [];
    Object.keys(STATIC_API).forEach(function (k) {
      if (k.indexOf('/api/industry/') !== 0) return;
      var ch = STATIC_API[k];
      (ch.streams || []).forEach(function (st) {
        (st.segments || []).forEach(function (sg) {
          if ((sg.companies || []).some(function (c) { return c.code === code; })) {
            out.push({id: ch.id, name: ch.name, stream: st.name, segment: sg.name});
          }
        });
      });
    });
    return out;
  }
  function staticStock(code, q) {
    var tf = String(q.tf || 'D').toUpperCase();
    if (tf !== 'W' && tf !== 'M') tf = 'D';
    var full = STATIC_API['/api/stock/' + code];
    if (full) {
      var daily = full.bars || [], out = {}, TA = window.TA;
      Object.keys(full).forEach(function (k) { out[k] = full[k]; });
      out.bars = tf === 'D' ? daily : TA.resample(daily, tf);
      out.ind = (tf === 'D' && full.ind) ? full.ind : TA.computeIndicators(out.bars);
      out.tf = tf;
      out.range = q.range || full.range || '1y';
      out.static = true;
      if (!out.chains || !out.chains.length) out.chains = staticChains(code);
      return out;
    }
    var r = staticRow(code);
    if (!r) throw staticErr(404, '找不到股票代號 ' + code);
    var peers = staticRows().filter(function (x) { return x.industry === r.industry && x.type === r.type && x.code !== code; })
      .sort(function (a, b) { return (b.value || 0) - (a.value || 0); }).slice(0, 8)
      .map(function (x) { return {code: x.code, name: x.name, close: x.close, pct: x.pct, pe: x.pe, yld: x.yld, r20: x.r20, score: x.score}; });
    var u = STATIC_API['/api/universe'] || {};
    return {code: r.code, name: r.name, market: r.market, industry: r.industry, type: r.type, tf: 'D', range: '1y',
      lite: true, static: true, row: r, profile: {},
      quote: {date: u.date, close: r.close, chg: r.chg, pct: r.pct, open: r.open, high: r.high, low: r.low, vol: r.vol,
        value: r.value, hi52: r.hi52, lo52: r.lo52},
      bars: [], ind: {}, valuation: {pe: r.pe, pb: r.pb, yld: r.yld, eps_ttm: r.eps_ttm, pe_industry_median: null},
      margins: null, revenue: [], eps: [], dividends: [], inst: [], peers: peers, chains: staticChains(code),
      score: r.score === null || r.score === undefined ? null : {score: r.score, rank: r.rank,
        factors: {chip: r.f_chip, rev: r.f_rev, mom: r.f_mom, vol: r.f_vol, val: r.f_val}, reasons: [], risks: []},
      signals: r.signals || [], risk: r.risk || []};
  }
  /** Resolves an API path from window.__STATIC_API__ (query stripped; W/M + indicators computed here). */
  function staticResolve(path, method) {
    return new Promise(function (resolve) {
      if (method !== 'GET') throw staticErr(405, 'GitHub 靜態版不支援此功能，請在線上版操作');
      var qi = path.indexOf('?'), base = qi >= 0 ? path.slice(0, qi) : path, q = parseQuery(qi >= 0 ? path.slice(qi + 1) : '');
      var m = base.match(/^\/api\/stock\/([^/]+)(\/analysis|\/news)?$/);
      if (m) {
        var code = decodeURIComponent(m[1]).toUpperCase();
        if (!m[2]) { resolve(staticStock(code, q)); return; }
        if (m[2] === '/news') { resolve({code: code, items: [], static: true}); return; }
        if (String(q.tf || 'D').toUpperCase() !== 'D') throw staticErr(404, 'GitHub 靜態版只提供日K技術分析；週K、月K的分析請在線上版查看');
        var an = STATIC_API['/api/stock/' + code + '/analysis'];
        if (!an) throw staticErr(404, 'GitHub 靜態版沒有收錄這檔股票的技術分析，請在線上版查看');
        resolve(an);
        return;
      }
      if (STATIC_API[base]) { resolve(STATIC_API[base]); return; }
      if (base.indexOf('/api/industry/') === 0) throw staticErr(404, '找不到這條產業鏈');
      throw staticErr(404, 'GitHub 靜態版沒有這項資料');
    });
  }
  function apiCached(path) { return MEM[path] || null; }
  function clearCache() { MEM = {}; UNI = null; }
  function isEmptyPayload(d) { return !d || d.empty === true || (d.date === null && d.message); }

  // ------------------------------------------------------------------ meta + polling
  var META = null, metaTimer = 0, metaCheckedAt = 0, metaDue = false, dataSig = null;
  var metaListeners = [];
  function onMeta(fn) {
    metaListeners.push(fn);
    return function () { metaListeners = metaListeners.filter(function (f) { return f !== fn; }); };
  }
  function metaState(m) { return (m && m.status && m.status.state) || 'idle'; }
  function getMeta(force) {
    if (META && !force) return Promise.resolve(META);
    return api('/api/meta', {cache: false}).then(function (m) { applyMeta(m); return m; });
  }
  function applyMeta(m) {
    var prev = META;
    META = m;
    metaCheckedAt = Date.now();
    var sig = (m.data_date || '') + '|' + (m.updated_at || '');
    var changed = false;
    if (dataSig !== null && sig !== dataSig) {
      var dateChanged = prev && prev.data_date !== m.data_date;
      if (dateChanged || metaState(m) === 'idle') changed = true;
    }
    if (dataSig === null || changed) dataSig = sig;
    renderBadge();
    renderUpdStrip();
    scheduleMeta();
    if (changed) {
      clearCache();
      try { sessionStorage.removeItem(UNI_KEY); } catch (e) { /* ignore */ }
    }
    metaListeners.slice().forEach(function (fn) {
      try { fn(m, {changed: changed, prev: prev}); } catch (e) { console.error(e); }
    });
    if (changed) Router.refresh();
  }
  function scheduleMeta() {
    clearTimeout(metaTimer);
    metaTimer = 0;
    if (!META || IS_STATIC) return;
    var st = metaState(META);
    if (st === 'error') { metaTimer = setTimeout(pollMeta, 60000); return; }
    if (st !== 'idle') { metaTimer = setTimeout(pollMeta, 5000); return; }
    // Idle: no polling. One wake-up at the next scheduled update (+45 s).
    var t = Date.parse(META.next_update || '');
    if (t) {
      var ms = t - Date.now() + 45000;
      if (ms > 0 && ms < 6 * 3600 * 1000) metaTimer = setTimeout(pollMeta, ms);
    }
  }
  function pollMeta() {
    if (document.hidden) { metaDue = true; return; }
    metaDue = false;
    getMeta(true).catch(function () { metaTimer = setTimeout(pollMeta, 30000); });
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden || IS_STATIC) return;
    if (metaDue || (META && Date.now() - metaCheckedAt > 3 * 60 * 1000)) pollMeta();
  });
  function renderBadge() {
    var el = $('#metaBadge');
    if (!el || !META) return;
    var st = META.status || {}, state = metaState(META), isIntra = !!META.is_intraday, qTime = META.quote_time || '', html, cls = 'badge-date', tip = [];
    if (IS_STATIC) {
      html = '<span class="lbl">靜態版 · ' + (isIntra ? '盤中行情' : '資料日期') + '</span> ' +
        esc(META.data_date || (TWS && TWS.data_date) || '—') + (isIntra && qTime ? ' ' + esc(qTime) : '');
      tip = [(location.protocol === 'file:' ? '離線檔案：資料為打包當下的快照，不會自動更新' : 'GitHub 版：每個交易日依排程自動更新') +
        (isIntra ? '\n盤中即時快照（收盤後由正式結算行情覆蓋）' : '') +
        (TWS && TWS.built_at ? '\n打包於 ' + TWS.built_at.replace('T', ' ').slice(0, 16) : '')];
      el.className = 'badge-date static';
      el.setAttribute('data-tip', tip.join('\n'));
      setHtml(el, html);
      return;
    }
    if (state === 'error') {
      cls += ' err';
      html = '⚠️ <span class="lbl">更新失敗 ·</span> ' + esc(META.data_date || '—');
    } else if (state !== 'idle') {
      cls += ' busy';
      html = '<span class="spin"></span><span class="lbl">' + (state === 'backfill' ? '建立資料庫' : '資料更新中') + '</span> ' +
        Math.round((st.progress || 0) * 100) + '%';
    } else {
      html = '<span class="lbl">' + (isIntra ? '盤中行情' : '資料日期') + '</span> ' +
        esc(META.data_date || '—') + (isIntra && qTime ? ' ' + esc(qTime) : '');
    }
    if (isIntra) tip.push('盤中即時快照（收盤後 14:50／16:10 自動覆蓋為正式收盤結算）');
    if (st.step) tip.push(st.step + (st.message ? '：' + st.message : ''));
    if (META.updated_at) tip.push('更新於 ' + META.updated_at.replace('T', ' ').slice(0, 16));
    el.className = cls;
    el.setAttribute('data-tip', tip.join('\n'));
    setHtml(el, html);
  }

  // ------------------------------------------------------------------ 資料更新頻率 strip (top of every page)
  var UPD_EL = null, WEEKDAY = '日一二三四五六';
  /** Persistent node: mount() re-inserts it above every page, so route changes never re-render it. */
  function updStripEl() {
    if (!UPD_EL) {
      UPD_EL = document.createElement('div');
      UPD_EL.className = 'upd-strip';
      UPD_EL.id = 'updStrip';
      UPD_EL.setAttribute('role', 'note');
      UPD_EL.setAttribute('aria-label', '資料更新頻率');
    }
    return UPD_EL;
  }
  function twDate(addDays) { return new Date(Date.now() + (8 + 24 * (addDays || 0)) * 3600000).toISOString().slice(0, 10); }
  /** Taipei-time ISO (2026-10-30T16:10:00+08:00) → 16:10 (today) / 昨天 21:30 / 明天 07:45 / 11/02（一）07:45. */
  function whenTw(iso) {
    var d = String(iso || '').slice(0, 10), hm = String(iso || '').slice(11, 16);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || !/^\d{2}:\d{2}$/.test(hm)) return '';
    if (d === twDate(0)) return hm;
    if (d === twDate(-1)) return '昨天 ' + hm;
    if (d === twDate(1)) return '明天 ' + hm;
    return fmtMD(d) + '（' + WEEKDAY.charAt(new Date(d + 'T00:00:00Z').getUTCDay()) + '）' + hm;
  }
  function renderUpdStrip() {
    var el = updStripEl();
    if (!META) return;
    var s = META.schedule_slots, html = '<b class="us-lbl">🔄 資料更新頻率</b>', whenTip = '', when;
    if (s && s.morning && s.update) {
      var notes = s.notes || {}, intra = s.intraday || [];
      var slotTip = function (list) { return list.map(function (t) { return t + '　' + (notes[t] || ''); }).join('\n'); };
      html += '<span class="us-main">每個交易日自動更新 ' + (s.morning.length + intra.length + s.update.length) + ' 次</span>' +
        '<span class="us-seg" data-tip="' + esc('盤前戰情：\n' + slotTip(s.morning)) + '"><b>🌅 盤前 ' + esc(s.morning.join('、')) +
        '</b><span class="us-desc">美股與國際重大事件</span></span>' +
        (intra.length ? '<span class="us-seg" data-tip="' + esc('盤中即時快照（14:50 後由正式收盤結算覆蓋）：\n' + slotTip(intra)) +
          '"><b>⚡ 盤中 ' + esc(intra.join('、')) + '</b><span class="us-desc">上市櫃盤中行情與強弱勢</span></span>' : '') +
        '<span class="us-seg" data-tip="' + esc('各項資料公布時間不同，盤後分批補齊（大致如下）：\n' + slotTip(s.update) +
          '\n月營收、財報有新公布也會一併更新') + '"><b>📊 盤後 ' + esc(s.update.join('、')) +
        '</b><span class="us-desc">收盤行情、三大法人、月營收</span></span>' +
        '<span class="us-seg us-off">週末與休市日不更新</span>';
    } else {
      html += '<span class="us-main">' + esc(META.schedule || '每個交易日自動更新') + '</span>';
    }
    if (IS_STATIC) {
      var built = whenTw((TWS && TWS.built_at) || META.updated_at);
      if (location.protocol === 'file:') {
        when = '離線檔案：資料停在' + (built ? ' ' + built : '打包當下') + '，不會自動更新';
      } else {
        when = built ? '本頁資料更新於 ' + built : '';
        whenTip = 'GitHub 版由雲端排程在上述時段自動抓資料、重新發布，上線可能比表定時間晚幾分鐘到半小時';
      }
    } else {
      var last = whenTw(META.updated_at), next = whenTw(META.next_update);
      when = [last ? '上次更新 ' + last : '', next ? '下次 ' + next : ''].filter(Boolean).join(' ・ ');
    }
    if (when) html += '<span class="us-when"' + (whenTip ? ' data-tip="' + esc(whenTip) + '"' : '') + '>' + esc(when) + '</span>';
    setHtml(el, html);
  }

  // ------------------------------------------------------------------ universe
  var UNI = null, UNI_KEY = 'tw.universe.v2';
  function indexUniverse(d) {
    var f = d.fields || [], rows = d.rows || [], list = new Array(rows.length), by = {};
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i], o = {};
      for (var j = 0; j < f.length; j++) o[f[j]] = r[j];
      if (!o.signals) o.signals = [];
      if (!o.risk) o.risk = [];
      o._hay = (o.code + ' ' + (o.name || '')).toLowerCase();
      list[i] = o;
      by[o.code] = o;
    }
    return {date: d.date || null, empty: !!d.empty, message: d.message || '', list: list, by: by};
  }
  function getUniverse() {
    return getMeta().then(function (m) {
      var key = (m.data_date || '') + '|' + (m.updated_at || '');
      if (UNI && UNI.key === key && !UNI.empty) return UNI;
      if (m.data_date && !IS_STATIC) {
        try {
          var raw = sessionStorage.getItem(UNI_KEY);
          if (raw) {
            var c = JSON.parse(raw);
            if (c && c.key === key && c.data) { UNI = indexUniverse(c.data); UNI.key = key; return UNI; }
          }
        } catch (e) { /* ignore corrupt cache */ }
      }
      return api('/api/universe', {cache: false}).then(function (d) {
        UNI = indexUniverse(d);
        UNI.key = key;
        if (!UNI.empty && d.date && !IS_STATIC) {
          try { sessionStorage.setItem(UNI_KEY, JSON.stringify({key: key, data: d})); } catch (e) { /* quota */ }
        }
        return UNI;
      });
    });
  }
  function uniCached() { return UNI; }

  // ------------------------------------------------------------------ watchlist
  var WKEY = 'tw.watchlist.v1', WL = null;
  function watchList() {
    if (!WL) {
      try { WL = JSON.parse(localStorage.getItem(WKEY) || '[]'); } catch (e) { WL = []; }
      if (!Array.isArray(WL)) WL = [];
    }
    return WL;
  }
  function watchHas(code) { return watchList().indexOf(code) >= 0; }
  function watchSave() { try { localStorage.setItem(WKEY, JSON.stringify(WL)); } catch (e) { /* ignore */ } }
  function watchToggle(code, silent) {
    var a = watchList(), i = a.indexOf(code), on = i < 0;
    if (on) a.unshift(code); else a.splice(i, 1);
    watchSave();
    syncStars(code, on);
    if (!silent) toast(on ? '已加入自選股：' + code : '已從自選股移除：' + code, on ? 'ok' : '');
    document.dispatchEvent(new CustomEvent('tw:watch', {detail: {code: code, on: on}}));
    return on;
  }
  window.addEventListener('storage', function (ev) { if (ev.key === WKEY) WL = null; });
  function starBtn(code, variant) {
    var on = watchHas(code);
    if (variant === 'icon') {
      return '<button type="button" class="star-ico' + (on ? ' on' : '') + '" data-watch="' + esc(code) +
        '" aria-label="自選股" data-tip="' + (on ? '從自選股移除' : '加入自選股') + '">' + (on ? '★' : '☆') + '</button>';
    }
    return '<button type="button" class="btn sm star' + (on ? ' on' : '') + '" data-watch="' + esc(code) + '">' +
      (on ? '★ 已自選' : '☆ 加自選') + '</button>';
  }
  function syncStars(code, on) {
    $$('[data-watch]').forEach(function (b) {
      if (b.getAttribute('data-watch') !== code) return;
      b.classList.toggle('on', on);
      if (b.classList.contains('star-ico')) {
        b.textContent = on ? '★' : '☆';
        b.setAttribute('data-tip', on ? '從自選股移除' : '加入自選股');
      } else {
        b.textContent = on ? '★ 已自選' : '☆ 加自選';
      }
    });
  }
  function lastStock() {
    try { return localStorage.getItem('tw.lastStock') || '2330'; } catch (e) { return '2330'; }
  }
  function setLastStock(code) {
    try { localStorage.setItem('tw.lastStock', code); } catch (e) { /* ignore */ }
    var a = $('#navStock');
    if (a) a.setAttribute('href', '#/stock/' + encodeURIComponent(code));
  }

  // ------------------------------------------------------------------ query helpers
  function parseQuery(s) {
    var o = {};
    (s || '').split('&').forEach(function (kv) {
      if (!kv) return;
      var i = kv.indexOf('=');
      try {
        o[decodeURIComponent(i >= 0 ? kv.slice(0, i) : kv)] = i >= 0 ? decodeURIComponent(kv.slice(i + 1).replace(/\+/g, ' ')) : '';
      } catch (e) { /* malformed */ }
    });
    return o;
  }
  function buildQuery(o) {
    var a = [];
    Object.keys(o).forEach(function (k) {
      var v = o[k];
      if (v === '' || v === null || v === undefined || v === false) return;
      a.push(encodeURIComponent(k) + '=' + encodeURIComponent(v === true ? '1' : String(v)));
    });
    return a.length ? '?' + a.join('&') : '';
  }
  /** Updates the hash without triggering the router (filters, tabs). */
  function replaceHash(h) {
    if (location.hash === h) return;
    try { history.replaceState(history.state, '', h); } catch (e) { /* file:// sandbox */ }
  }
  function navigate(h) { if (location.hash === h) Router.refresh(); else location.hash = h; }

  // ------------------------------------------------------------------ SVG helpers
  function niceScale(min, max, count) {
    if (!isNum(min) || !isNum(max)) { min = 0; max = 1; }
    if (min === max) { var pad = Math.abs(min) * 0.1 || 1; min -= pad; max += pad; }
    var step0 = (max - min) / (count || 4);
    var mag = Math.pow(10, Math.floor(Math.log(step0) / Math.LN10));
    var r = step0 / mag;
    var step = (r <= 1 ? 1 : r <= 2 ? 2 : r <= 2.5 ? 2.5 : r <= 5 ? 5 : 10) * mag;
    var lo = Math.floor(min / step - 1e-9) * step, hi = Math.ceil(max / step - 1e-9) * step;
    var ticks = [];
    for (var v = lo, i = 0; v <= hi + step * 1e-6 && i < 50; v += step, i++) ticks.push(Math.round(v / step) * step);
    return {min: lo, max: hi, step: step, ticks: ticks};
  }
  function svgSpark(vals, o) {
    o = o || {};
    var w = o.w || 120, h = o.h || 34, pad = 2;
    var pts = (vals || []).filter(isNum);
    if (pts.length < 2) return '<svg class="spark" width="' + w + '" height="' + h + '" aria-hidden="true"></svg>';
    var mn = Math.min.apply(null, pts), mx = Math.max.apply(null, pts);
    if (isNum(o.base)) { mn = Math.min(mn, o.base); mx = Math.max(mx, o.base); }
    var rg = (mx - mn) || 1, n = pts.length, d = '';
    var yOf = function (v) { return pad + (1 - (v - mn) / rg) * (h - 2 * pad); };
    for (var i = 0; i < n; i++) {
      d += (i ? 'L' : 'M') + (pad + i * (w - 2 * pad) / (n - 1)).toFixed(1) + ' ' + yOf(pts[i]).toFixed(1);
    }
    var ref = isNum(o.base) ? o.base : pts[0];
    var col = o.color || (pts[n - 1] > ref ? '#dc2626' : (pts[n - 1] < ref ? '#16a34a' : '#64748b'));
    var area = d + 'L' + (w - pad) + ' ' + (h - pad) + 'L' + pad + ' ' + (h - pad) + 'Z';
    var base = isNum(o.base) ? '<line x1="0" x2="' + w + '" y1="' + yOf(o.base).toFixed(1) + '" y2="' + yOf(o.base).toFixed(1) +
      '" stroke="#94a3b8" stroke-dasharray="2 3" stroke-width="1"/>' : '';
    return '<svg class="spark" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true">' +
      base + '<path d="' + area + '" fill="' + col + '" fill-opacity=".09"/><path d="' + d + '" fill="none" stroke="' + col +
      '" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/></svg>';
  }
  /**
   * Bars (left axis) + optional line (right axis). cfg: {w, h, labels, bars, barColor(i,v), line, lineColor,
   * barFmt, lineFmt, tip(i), xLabel(i), zeroLine}
   */
  function svgBarLine(c) {
    var n = (c.labels || []).length;
    if (!n) return '';
    var W = Math.max(300, Math.round(c.w || 640)), H = c.h || 230;
    var hasLine = !!(c.line && c.line.some(isNum));
    var padL = c.padL || 54, padR = hasLine ? 50 : 14, padT = 12, padB = 26;
    var plotW = W - padL - padR, plotH = H - padT - padB, bw = plotW / n;
    var bv = (c.bars || []).filter(isNum);
    var s1 = niceScale(Math.min(0, Math.min.apply(null, bv.length ? bv : [0])), Math.max(0, Math.max.apply(null, bv.length ? bv : [1])), 4);
    var yB = function (v) { return padT + (1 - (v - s1.min) / (s1.max - s1.min)) * plotH; };
    var barFmt = c.barFmt || function (v) { return fmtCompact(v); };
    var out = [];
    s1.ticks.forEach(function (t) {
      var y = yB(t).toFixed(1);
      out.push('<line class="grid-l" x1="' + padL + '" x2="' + (W - padR) + '" y1="' + y + '" y2="' + y + '"/>');
      out.push('<text x="' + (padL - 6) + '" y="' + y + '" dy="4" text-anchor="end">' + esc(barFmt(t)) + '</text>');
    });
    if (s1.min < 0) out.push('<line class="axis-l" x1="' + padL + '" x2="' + (W - padR) + '" y1="' + yB(0).toFixed(1) + '" y2="' + yB(0).toFixed(1) + '"/>');
    var y0 = yB(0);
    for (var i = 0; i < n; i++) {
      var v = c.bars[i];
      if (!isNum(v)) continue;
      var y1 = yB(v), x = padL + i * bw + bw * 0.18, bwid = Math.max(1, bw * 0.64);
      out.push('<rect x="' + x.toFixed(1) + '" y="' + Math.min(y0, y1).toFixed(1) + '" width="' + bwid.toFixed(1) + '" height="' +
        Math.max(1, Math.abs(y1 - y0)).toFixed(1) + '" rx="' + Math.min(3, bwid / 3).toFixed(1) + '" fill="' + (c.barColor ? c.barColor(i, v) : '#93c5fd') + '"/>');
    }
    if (hasLine) {
      var lv = c.line.filter(isNum), s2 = niceScale(Math.min.apply(null, lv), Math.max.apply(null, lv), 4);
      var yL = function (v) { return padT + (1 - (v - s2.min) / (s2.max - s2.min)) * plotH; };
      var lineFmt = c.lineFmt || function (v) { return fmtNum(v, 0); };
      s2.ticks.forEach(function (t) {
        out.push('<text x="' + (W - padR + 6) + '" y="' + yL(t).toFixed(1) + '" dy="4" text-anchor="start">' + esc(lineFmt(t)) + '</text>');
      });
      var d = '', pen = false, dots = '';
      for (var k = 0; k < n; k++) {
        var lvv = c.line[k];
        if (!isNum(lvv)) { pen = false; continue; }
        var px = (padL + k * bw + bw / 2).toFixed(1), py = yL(lvv).toFixed(1);
        d += (pen ? 'L' : 'M') + px + ' ' + py;
        pen = true;
        if (n <= 40) dots += '<circle cx="' + px + '" cy="' + py + '" r="2.4" fill="#fff" stroke="' + (c.lineColor || '#f59e0b') + '" stroke-width="1.5"/>';
      }
      out.push('<path d="' + d + '" fill="none" stroke="' + (c.lineColor || '#f59e0b') + '" stroke-width="2" stroke-linejoin="round"/>' + dots);
    }
    var every = Math.max(1, Math.ceil(n / Math.max(1, plotW / 58)));
    for (var j = 0; j < n; j++) {
      if ((n - 1 - j) % every) continue;
      out.push('<text x="' + (padL + j * bw + bw / 2).toFixed(1) + '" y="' + (H - 7) + '" text-anchor="middle">' +
        esc(c.xLabel ? c.xLabel(j) : c.labels[j]) + '</text>');
    }
    for (var q = 0; q < n; q++) {
      out.push('<rect class="hit" x="' + (padL + q * bw).toFixed(1) + '" y="' + padT + '" width="' + bw.toFixed(1) + '" height="' + plotH +
        '" data-tip="' + esc(c.tip ? c.tip(q) : c.labels[q]) + '"/>');
    }
    return '<div class="svgc"><svg viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '" role="img">' + out.join('') + '</svg></div>';
  }
  function scoreColor(v) {
    return !isNum(v) ? '#cbd5e1' : v >= 80 ? '#dc2626' : v >= 60 ? '#ea580c' : v >= 40 ? '#ca8a04' : '#64748b';
  }
  function scoreRing(v, size) {
    size = size || 46;
    var sw = size >= 56 ? 6 : 5, r = size / 2 - sw / 2 - 1, c = 2 * Math.PI * r;
    var p = isNum(v) ? Math.max(0, Math.min(100, v)) / 100 : 0, col = scoreColor(v);
    return '<span class="ring" style="width:' + size + 'px;height:' + size + 'px" data-tip="綜合分數 0–100（全市場百分位加權）">' +
      '<svg width="' + size + '" height="' + size + '" aria-hidden="true"><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r +
      '" fill="none" stroke="#eef2f6" stroke-width="' + sw + '"/><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r +
      '" fill="none" stroke="' + col + '" stroke-width="' + sw + '" stroke-linecap="round" stroke-dasharray="' + (c * p).toFixed(1) + ' ' + c.toFixed(1) +
      '"/></svg><b style="color:' + col + ';font-size:' + Math.round(size * 0.32) + 'px">' + (isNum(v) ? Math.round(v) : '—') + '</b></span>';
  }
  // Factor keys per SPEC §3.4 (labels follow the backend's current model).
  var FACTORS = [['chip', '籌碼', '籌碼強度：投信、外資近 20 日買超占成交量'], ['rev', '營收', '月營收動能：年增率、累計年增、是否創 12 個月新高'],
    ['mom', '趨勢', '技術趨勢：20／60 日漲幅、均線排列、距 52 週高點'], ['vol', '穩定', '穩定度：股價波動越低分數越高'],
    ['val', '價值', '價值：本益比、殖利率']];
  var FACTOR_NAME = {chip: '籌碼強度', rev: '月營收動能', mom: '技術趨勢', vol: '穩定度（低波動）', val: '價值'};
  var WEIGHTS = null;
  /** Model weights from /api/picks.method.weights (0-weight factors are reference-only). */
  function setWeights(w) { if (w && typeof w === 'object') WEIGHTS = w; }
  function factorBars(f, weights) {
    var w = weights || WEIGHTS;
    return '<div class="fbars">' + FACTORS.map(function (x) {
      var v = f ? f[x[0]] : null, pct = isNum(v) ? Math.max(3, Math.min(100, v)) : 0;
      var wt = w && isNum(w[x[0]]) ? w[x[0]] : null, ref = wt === 0;
      var lbl = x[1] + (wt ? ' <em>' + Math.round(wt * 100) + '%</em>' : '') + (ref ? ' <em class="ref-tag">參考</em>' : '');
      var tip = FACTOR_NAME[x[0]] + '：' + x[2] + '\n全市場百分位 ' + (isNum(v) ? Math.round(v) : '—') + '（越高越好）' +
        (wt ? '\n模型權重 ' + Math.round(wt * 100) + '%' : (ref ? '\n權重 0%：僅供參考，不計入綜合分數' : ''));
      return '<div class="fbar' + (ref ? ' ref' : '') + '" data-tip="' + esc(tip) + '"><span class="lb">' + lbl + '</span><span class="tr"><span class="fl' +
        (!ref && isNum(v) && v >= 80 ? ' hi' : '') + '" style="width:' + pct + '%"></span></span><span class="v">' + (isNum(v) ? Math.round(v) : '—') + '</span></div>';
    }).join('') + '</div>';
  }
  function heatColor(p, m) {
    if (!isNum(p)) return {bg: '#e2e8f0', fg: '#334155'};
    var t = Math.max(-1, Math.min(1, p / (m || 4))), a = Math.pow(Math.abs(t), 0.7);
    var n0 = [226, 232, 240], tg = t >= 0 ? [220, 38, 38] : [22, 163, 74];
    var rgb = n0.map(function (v, i) { return Math.round(v + (tg[i] - v) * a); });
    return {bg: 'rgb(' + rgb.join(',') + ')', fg: a > 0.42 ? '#fff' : '#1e293b'};
  }
  /** Squarified treemap. items: [{value}] (desc). Returns rects aligned with items. */
  function treemap(items, W, H) {
    var total = items.reduce(function (s, it) { return s + Math.max(0, it.value || 0); }, 0);
    var rects = new Array(items.length);
    if (!total || !items.length) return rects;
    var scale = (W * H) / total;
    var queue = items.map(function (it, i) { return {i: i, a: Math.max(0, it.value || 0) * scale}; });
    var x = 0, y = 0, w = W, h = H, row = [];
    function worst(r, len) {
      var s = 0, mx = 0, mn = Infinity;
      r.forEach(function (e) { s += e.a; mx = Math.max(mx, e.a); mn = Math.min(mn, e.a); });
      if (!s || !mn) return Infinity;
      return Math.max(len * len * mx / (s * s), (s * s) / (len * len * mn));
    }
    function layout(r) {
      var s = r.reduce(function (acc, e) { return acc + e.a; }, 0);
      if (w >= h) {
        var cw = s / h, cy = y;
        r.forEach(function (e) { var ch = e.a / cw; rects[e.i] = {x: x, y: cy, w: cw, h: ch}; cy += ch; });
        x += cw; w -= cw;
      } else {
        var rh = s / w, cx = x;
        r.forEach(function (e) { var rw = e.a / rh; rects[e.i] = {x: cx, y: y, w: rw, h: rh}; cx += rw; });
        y += rh; h -= rh;
      }
    }
    while (queue.length) {
      var len = Math.min(w, h), e = queue[0];
      if (!row.length || worst(row.concat([e]), len) <= worst(row, len)) { row.push(e); queue.shift(); }
      else { layout(row); row = []; }
    }
    if (row.length) layout(row);
    return rects;
  }

  // ------------------------------------------------------------------ shared snippets
  function loadingHtml(t) { return '<div class="loading-inline"><span class="spin"></span>' + esc(t || '載入中…') + '</div>'; }
  function errorHtml(msg, retry) {
    return '<div class="card empty err"><div class="big">⚠️</div><h3>無法載入資料</h3><p>' + esc(msg || '未知錯誤') + '</p>' +
      (retry === false ? '' : '<button type="button" class="btn sm" data-act="retry">重試</button>') + '</div>';
  }
  function buildingHtml(msg) {
    return '<div class="card empty"><div class="big">🛠️</div><h3>' + esc(msg || '資料建立中，請稍候…') +
      '</h3><p>首次建立資料庫需要一些時間，完成後頁面會自動更新，不需要重新整理。</p></div>';
  }
  function skeleton(n, h) {
    var a = [];
    for (var i = 0; i < (n || 3); i++) a.push('<div class="skel" style="height:' + (h || 110) + 'px"></div>');
    return '<div class="grid">' + a.join('') + '</div>';
  }
  function disclaimer() { return (META && META.disclaimer) || DISCLAIMER; }
  function disclaimerHtml(extra) {
    return '<div class="footer-note">⚠️ ' + esc(disclaimer()) + (extra ? '<br>' + extra : '') + '</div>';
  }
  function setTitle(t) { document.title = (t ? t + ' · ' : '') + '台股智慧選股'; }

  // ------------------------------------------------------------------ router
  var ROUTES = [
    [/^\/$/, 'home', []], [/^\/morning$/, 'morning', []], [/^\/screener$/, 'screener', []],
    [/^\/etf$/, 'etf', []], [/^\/stock$/, '_stock', []],
    [/^\/stock\/([^/]+)$/, 'stock', ['code']], [/^\/industry$/, 'industry', []],
    [/^\/industry\/([^/]+)$/, 'chain', ['id']], [/^\/picks$/, 'picks', []],
    [/^\/watchlist$/, 'watchlist', []], [/^\/about$/, 'about', []], [/^\/feedback$/, 'feedback', []]
  ];
  var NAV_OF = {home: 'home', morning: 'morning', screener: 'screener', etf: 'etf', stock: 'stock',
    industry: 'industry', chain: 'industry', picks: 'picks', watchlist: 'watchlist', about: 'about', feedback: 'feedback'};
  var Router = App.Router = {cur: {name: null, page: null, el: null, params: null}};
  var rafId = 0;
  function parseHash() {
    var h = location.hash.replace(/^#/, '') || '/';
    var qi = h.indexOf('?');
    var path = (qi >= 0 ? h.slice(0, qi) : h).replace(/\/+$/, '') || '/';
    if (path.charAt(0) !== '/') path = '/' + path;
    var query = parseQuery(qi >= 0 ? h.slice(qi + 1) : '');
    for (var i = 0; i < ROUTES.length; i++) {
      var m = path.match(ROUTES[i][0]);
      if (!m) continue;
      var params = {query: query};
      ROUTES[i][2].forEach(function (k, j) {
        try { params[k] = decodeURIComponent(m[j + 1]); } catch (e) { params[k] = m[j + 1]; }
      });
      return {name: ROUTES[i][1], params: params};
    }
    return {name: '_404', params: {query: query}};
  }
  function highlightNav(name) {
    $$('.nav a').forEach(function (a) { a.classList.toggle('active', a.getAttribute('data-nav') === name); });
  }
  function mount(r, keepScroll) {
    var page = window.Pages[r.name];
    var cur = Router.cur;
    if (cur.page && cur.page.destroy) {
      try { cur.page.destroy(); } catch (e) { console.error(e); }
    }
    var el = document.createElement('div');
    el.className = 'page page-' + r.name;
    var app = $('#app');
    app.innerHTML = '';
    app.appendChild(updStripEl());
    app.appendChild(el);
    Router.cur = {name: r.name, page: page || null, el: el, params: r.params};
    if (!keepScroll) window.scrollTo({top: 0, left: 0, behavior: 'instant'});
    if (!page) {
      setTitle('找不到頁面');
      el.innerHTML = '<div class="card empty"><div class="big">🧭</div><h3>找不到這個頁面</h3><p><a href="#/">回到今日推薦</a></p></div>';
      return;
    }
    try {
      var p = page.render(r.params, el);
      if (p && typeof p.then === 'function') {
        p.then(null, function (e) {
          console.error(e);
          if (Router.cur.el === el) el.innerHTML = errorHtml(e && e.message);
        });
      }
    } catch (e) {
      console.error(e);
      el.innerHTML = errorHtml(e && e.message);
    }
  }
  function route() {
    var r = parseHash();
    if (r.name === '_stock') { location.replace('#/stock/' + encodeURIComponent(lastStock())); return; }
    highlightNav(NAV_OF[r.name]);
    var cur = Router.cur;
    if (cur.name === r.name && cur.page && cur.page.update) {
      var handled = false;
      try { handled = cur.page.update(r.params) === true; } catch (e) { console.error(e); }
      if (handled) { cur.params = r.params; return; }
    }
    cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(function () { mount(r, false); });
  }
  /** Re-renders the current page in place (after a data update or 重試). */
  Router.refresh = function () {
    var cur = Router.cur;
    if (cur.page && cur.page.refresh) {
      try { if (cur.page.refresh() === true) return; } catch (e) { console.error(e); }
    }
    mount(parseHash(), true);
  };

  // ------------------------------------------------------------------ global search
  function searchUniverse(q, limit) {
    q = (q || '').trim().toLowerCase();
    if (!q || !UNI) return [];
    var a = [], b = [], c = [];
    for (var i = 0; i < UNI.list.length; i++) {
      var r = UNI.list[i], code = r.code.toLowerCase();
      if (code === q) a.unshift(r);
      else if (code.indexOf(q) === 0) a.push(r);
      else if ((r.name || '').toLowerCase().indexOf(q) === 0) b.push(r);
      else if (r._hay.indexOf(q) >= 0) c.push(r);
    }
    var byVal = function (x, y) { return (y.value || 0) - (x.value || 0); };
    b.sort(byVal);
    c.sort(byVal);
    return a.concat(b, c).slice(0, limit || 8);
  }
  function initSearch() {
    var input = $('#gsearch'), box = $('#gsearchAc'), items = [], sel = -1;
    if (!input) return;
    function close() { box.classList.add('hidden'); sel = -1; }
    function render() {
      var q = input.value.trim();
      if (!q) { close(); return; }
      if (!UNI) {
        box.innerHTML = '<div class="ac-empty">' + loadingHtml('載入股票清單…') + '</div>';
        box.classList.remove('hidden');
        getUniverse().then(function () { if (input.value.trim() === q) render(); }, function () {
          box.innerHTML = '<div class="ac-empty">股票清單載入失敗</div>';
        });
        return;
      }
      items = searchUniverse(q, 8);
      sel = items.length ? 0 : -1;
      box.innerHTML = items.length ? items.map(function (r, i) {
        return '<div class="ac-item' + (i === sel ? ' on' : '') + '" data-i="' + i + '"><span class="ac-code">' + esc(r.code) +
          '</span><span class="ac-name">' + esc(r.name) + '<small>' + esc(r.type === 'ETF' ? 'ETF' : (r.industry || r.market || '')) +
          '</small></span><span class="ac-px num">' + fmtPrice(r.close) + ' ' + pctSpan(r.pct) + '</span></div>';
      }).join('') : '<div class="ac-empty">找不到「' + esc(q) + '」，可輸入代號或名稱</div>';
      box.classList.remove('hidden');
    }
    function move(d) {
      if (!items.length) return;
      sel = (sel + d + items.length) % items.length;
      $$('.ac-item', box).forEach(function (el, i) { el.classList.toggle('on', i === sel); });
    }
    function pick(r) {
      var q = input.value.trim();
      if (!r && /^[0-9]{4,6}[a-z]?$/i.test(q)) r = {code: q.toUpperCase()};
      if (!r) return;
      input.value = '';
      close();
      input.blur();
      navigate('#/stock/' + encodeURIComponent(r.code));
    }
    input.addEventListener('focus', function () { getUniverse().then(null, function () {}); if (input.value.trim()) render(); });
    input.addEventListener('input', debounce(render, 50));
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'ArrowDown') { ev.preventDefault(); move(1); }
      else if (ev.key === 'ArrowUp') { ev.preventDefault(); move(-1); }
      else if (ev.key === 'Escape') { close(); input.blur(); }
      else if (isEnterSend(ev)) { ev.preventDefault(); pick(sel >= 0 ? items[sel] : null); }
    });
    input.addEventListener('blur', function () { setTimeout(close, 120); });
    box.addEventListener('mousedown', function (ev) {
      var it = ev.target.closest('.ac-item');
      if (it) { ev.preventDefault(); pick(items[+it.getAttribute('data-i')]); }
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === '/' && !ev.ctrlKey && !ev.metaKey && !ev.altKey && !isTyping(ev.target)) {
        ev.preventDefault();
        input.focus();
        input.select();
      }
    });
  }

  // ------------------------------------------------------------------ global delegation
  function initDelegation() {
    // Stars first (capture) so row navigation never fires underneath.
    document.addEventListener('click', function (ev) {
      var w = ev.target.closest ? ev.target.closest('[data-watch]') : null;
      if (!w) return;
      ev.preventDefault();
      ev.stopPropagation();
      watchToggle(w.getAttribute('data-watch'));
    }, true);
    document.addEventListener('click', function (ev) {
      if (ev.defaultPrevented || ev.button !== 0) return;
      var t = ev.target;
      if (t.closest && (t.closest('#disclaimerBtn') || t.closest('[data-open-disclaimer]'))) {
        ev.preventDefault();
        var dm = $('#twDiscModal');
        if (dm) dm.classList.remove('hidden');
        return;
      }
      if (t.closest && (t.closest('#twDiscModalClose') || t.id === 'twDiscModal')) {
        var dm2 = $('#twDiscModal');
        if (dm2) dm2.classList.add('hidden');
        return;
      }
      var retry = t.closest('[data-act="retry"]');
      if (retry) { clearCache(); Router.refresh(); return; }
      var row = t.closest('[data-href]');
      if (row && !t.closest('a,button,input,select,label,textarea')) {
        var href = row.getAttribute('data-href');
        if (ev.metaKey || ev.ctrlKey) window.open(href, '_blank');
        else navigate(href);
      }
    });
  }

  // ------------------------------------------------------------------ boot
  function boot() {
    initTips();
    initSearch();
    initDelegation();
    setLastStock(lastStock());
    window.addEventListener('hashchange', route);
    getMeta().then(null, function (e) {
      var el = $('#metaBadge');
      if (el) { el.className = 'badge-date err'; el.textContent = '⚠️ 無法連線'; el.setAttribute('data-tip', e.message); }
    });
    route();
  }

  // ------------------------------------------------------------------ exports
  var EXPORTS = {
    $: $, $$: $$, esc: esc, setHtml: setHtml, debounce: debounce, isNum: isNum, isTyping: isTyping,
    fmtNum: fmtNum, fmtInt: fmtInt, fmtPct: fmtPct, fmtPrice: fmtPrice, fmtChg: fmtChg, fmtYi: fmtYi,
    fmtCompact: fmtCompact, fmtScore: fmtScore, fmtMD: fmtMD, relTime: relTime, pricePrec: pricePrec,
    clsUpDown: clsUpDown, pctSpan: pctSpan, arrow: arrow, sigChip: sigChip, sigClass: sigClass, riskChip: riskChip,
    SIG_TIP: SIG_TIP, toast: toast, isEnterSend: isEnterSend, api: api, apiCached: apiCached,
    clearCache: clearCache, isEmptyPayload: isEmptyPayload, getMeta: getMeta, onMeta: onMeta, metaState: metaState,
    getUniverse: getUniverse, uniCached: uniCached, searchUniverse: searchUniverse, watchList: watchList,
    watchHas: watchHas, watchToggle: watchToggle, starBtn: starBtn, lastStock: lastStock, setLastStock: setLastStock,
    parseQuery: parseQuery, buildQuery: buildQuery, replaceHash: replaceHash, navigate: navigate,
    niceScale: niceScale, svgSpark: svgSpark, svgBarLine: svgBarLine, scoreRing: scoreRing, scoreColor: scoreColor,
    factorBars: factorBars, setWeights: setWeights, FACTORS: FACTORS, FACTOR_NAME: FACTOR_NAME, heatColor: heatColor, treemap: treemap, loadingHtml: loadingHtml,
    errorHtml: errorHtml, buildingHtml: buildingHtml, skeleton: skeleton, disclaimer: disclaimer,
    disclaimerHtml: disclaimerHtml, setTitle: setTitle
  };
  Object.keys(EXPORTS).forEach(function (k) { App[k] = EXPORTS[k]; window[k] = EXPORTS[k]; });
  Object.defineProperty(App, 'meta', {get: function () { return META; }});
  Object.defineProperty(App, 'pending', {get: function () { return pendingCount; }});
  Object.defineProperty(App, 'weights', {get: function () { return WEIGHTS; }});
  App.isStatic = IS_STATIC;
  App.staticInfo = TWS;

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else setTimeout(boot, 0);
})();
