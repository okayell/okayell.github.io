/* 說明 (#/about) — data sources, update schedule, scoring method, beginner glossary, disclaimer. */
(function () {
  'use strict';
  var A = {el: null, alive: false};
  var GLOSSARY = [
    ['📏', '均線（MA）', '過去 N 個交易日收盤價的平均，可以看成「最近 N 天買進的人平均成本」。MA5 是週線、MA20 是月線、MA60 是季線、MA240 是年線。',
      '股價在均線之上，代表最近買的人大多賺錢、買盤占優勢；跌破均線則相反。'],
    ['📈', '多頭排列／空頭排列', '短天期均線在上、長天期在下（MA5 > MA10 > MA20 > MA60）叫多頭排列，代表短中長期趨勢都向上；反過來就是空頭排列。',
      '多頭排列的股票較常「漲多跌少」，但排列太開時也容易短線拉回。'],
    ['🕯', 'K 線（紅K／黑K）', '一根 K 線記錄一段時間的開盤、最高、最低、收盤價。台灣習慣收盤高於開盤畫紅色（紅K），低於開盤畫綠色或黑色。',
      '長紅K代表買盤強；長上影線代表高檔有賣壓；長下影線代表低檔有人承接。'],
    ['🎢', 'KD 指標', '隨機指標，把最近 9 天的價格區間換算成 0～100。K 值由下往上穿越 D 值叫「黃金交叉」，反之叫「死亡交叉」。',
      'K > 80 為高檔、K < 20 為低檔；在低檔出現黃金交叉的反彈訊號較可靠。連續停在高檔叫「高檔鈍化」，代表強勢。'],
    ['🌊', 'MACD', '用快慢兩條指數平均線的差距（DIF）與它的平均（DEA）來判斷趨勢動能；兩者相減就是柱狀體（OSC）。',
      '柱狀體由綠轉紅（翻紅）代表動能轉強；DIF 向上穿越 DEA 為黃金交叉。'],
    ['⚖️', 'RSI 相對強弱指標', '比較一段期間上漲與下跌的力道，數值 0～100。', '一般 70 以上視為超買（漲多）、30 以下視為超賣（跌深），但強勢股可能長時間維持在高檔。'],
    ['🎯', '布林通道', '以 20 日均線為中軌，上下各加減 2 倍標準差形成通道，大約 95% 的時間股價會在通道內。',
      '通道變窄（布林收斂）常是大波動前兆；收盤突破上軌代表強勢，但也容易短線過熱。'],
    ['📐', '乖離率（BIAS）', '股價偏離均線的百分比，例如月線乖離 +8% 代表股價比 20 日均線高 8%。', '乖離過大時，股價常會向均線靠攏（漲多拉回、跌深反彈）。'],
    ['🔊', '成交量與量價關係', '成交量是買賣的張數（1 張 = 1,000 股）。「價漲量增」代表上漲有買盤支持；「價漲量縮」則追價力道不足。', '突破壓力時最好伴隨成交量放大；爆量長黑要特別小心。'],
    ['🧱', '支撐與壓力', '支撐是股價下跌時容易止跌的價位（例如前波低點、成交密集區），壓力則是上漲時容易遇到賣壓的價位（前波高點、套牢區、整數關卡）。',
      '跌破支撐後常會「支撐變壓力」，突破壓力後則「壓力變支撐」。'],
    ['📉', '趨勢線與通道', '連接兩個以上的波段低點（或高點）畫出的斜線。上升趨勢線在股價下方當支撐；下降趨勢線在上方當壓力。', '有效跌破上升趨勢線，代表原本的上漲趨勢可能結束。'],
    ['〽️', 'W底／M頭／頭肩型態', 'W底是兩個差不多高的低點，突破中間的「頸線」才算完成，屬於底部反轉型態；M頭相反。頭肩底／頭肩頂則是三個低點（高點）、中間最深（最高）。',
      '型態完成後，常用「頸線到底部的距離」往上（下）推估目標價。'],
    ['🔺', '三角收斂與箱型', '高點越來越低、低點越來越高形成三角形；股價在固定區間上下震盪叫箱型整理。', '往哪個方向突破，通常就會延續那個方向一段時間。'],
    ['🌡', 'ATR 平均真實波幅', '一天平均會波動多少元。ATR 為股價 3% 代表平常一天上下 3% 很正常。', '設停損時可預留 1～2 倍 ATR，避免被正常波動洗出場。'],
    ['💪', 'ADX 趨勢強度', '衡量趨勢「有多明確」，不分漲跌。', '25 以上代表趨勢明確、順勢操作較有利；20 以下代表盤整，適合區間操作。'],
    ['🏦', '三大法人', '外資（外國機構投資人）、投信（國內基金）與自營商（券商自己的資金）。', '投信連續買超常代表基金在布局；外資資金大，對權值股影響最大。'],
    ['🧲', '籌碼強度', '本站自訂：外資＋投信近 20 日買超張數 ÷ 同期間總成交量。', '數字越高代表法人買得越積極、籌碼越集中；負值代表法人在賣。'],
    ['💵', '殖利率', '一年現金股利 ÷ 股價。股價 100 元、配 5 元，殖利率就是 5%。', '高殖利率適合存股，但要注意公司獲利是否穩定，避免「賺了股息、賠了價差」。'],
    ['🧾', '本益比（PE）與 EPS', 'EPS 是每股盈餘（公司一年幫每一股賺多少錢）；本益比 = 股價 ÷ EPS，代表用幾年的獲利買這家公司。', '同產業比較才有意義；成長快的公司本益比通常較高。'],
    ['📚', '股價淨值比（PB）', '股價 ÷ 每股淨值（公司資產扣掉負債後每股值多少）。', '金融、傳產常用 PB 評價；PB < 1 代表股價低於帳面價值。'],
    ['📆', '月營收 YoY／MoM', 'YoY 是和去年同月比的成長率，MoM 是和上個月比。上市櫃公司每月 10 日前公布上月營收。', 'YoY 可以排除季節性；「營收創新高」常是股價的領先指標。'],
    ['🛑', '停損、目標價與報酬風險比', '停損是「錯了就出場」的價位；目標價是預期可能漲到的價位。報酬風險比 = (目標 − 進場) ÷ (進場 − 停損)。', '報酬風險比 2 以上，代表可能賺的是可能賠的 2 倍，勝率不用太高也能長期獲利。'],
    ['🚨', '注意股與處置股', '短期漲跌或成交量異常時，交易所會公告為注意股；情況持續則列為處置股，改為分盤撮合或需預收款券。', '處置股流動性變差、波動大，本站推薦清單會自動排除。']
  ];

  function render(params, el) {
    A.el = el;
    A.alive = true;
    setTitle('說明');
    el.addEventListener('click', onClick);
    paint(App.meta, null);
    return Promise.all([getMeta().then(null, function () { return null; }), api('/api/picks').then(null, function () { return null; })]).then(function (r) {
      if (A.alive) paint(r[0], r[1]);
    });
  }
  function onClick(ev) {
    var b = ev.target.closest('[data-act="gloss-all"]');
    if (!b) return;
    var open = !$$('.gloss-item', A.el).every(function (d) { return d.open; });
    $$('.gloss-item', A.el).forEach(function (d) { d.open = open; });
    b.textContent = open ? '⊟ 收合全部' : '⊞ 展開全部';
  }
  function paint(meta, picks) {
    meta = meta || {};
    var m = (picks && picks.method) || {}, w = m.weights || {}, names = App.FACTOR_NAME || {}, st = meta.status || {}, cnt = meta.counts || {};
    var weightsHtml = (App.FACTORS || []).map(function (f) {
      var wt = w[f[0]];
      return '<div class="wbar' + (wt ? '' : ' ref') + '"><span>' + esc(names[f[0]] || f[1]) + '</span><span class="tr"><span class="fl" style="width:' +
        (App.isNum(wt) ? Math.max(wt ? 4 : 0, wt * 100) : 0) + '%"></span></span><b>' + (App.isNum(wt) ? (wt ? Math.round(wt * 100) + '%' : '參考') : '—') + '</b></div>';
    }).join('');
    setHtml(A.el, '<div class="ph"><h1>說明</h1><span class="sub">資料來源、更新時間、評分方法與新手指標小辭典</span></div>' +
      '<div class="grid g2">' +
      '<section class="card"><div class="card-h"><h2>📦 關於本站</h2></div><p style="line-height:1.8;color:var(--text-2)">「台股智慧選股」是個人研究用的台股分析工具：每個交易日於盤前（美股與國際重大事件）、盤中（10:30／12:30 上市櫃即時行情）與收盤後自動更新全部上市櫃股票的行情、三大法人、月營收與財報，' +
      '計算技術指標與多因子分數，產生<a href="#/">今日推薦</a>、<a href="#/screener">選股器</a>、<a href="#/industry">產業與產業鏈</a>，並提供個股 K 線圖與<b>一鍵技術分析解說</b>。</p>' +
      '<div class="subh">顏色慣例（台股）</div><div class="color-demo"><span class="chip solid-bull">上漲／偏多 = 紅</span><span class="chip solid-bear">下跌／偏空 = 綠</span>' +
      '<span class="chip" style="background:#e0f2fe;color:#0369a1">支撐線 = 藍</span><span class="chip" style="background:#ffedd5;color:#c2410c">壓力線 = 橘</span><span class="chip fund">籌碼／基本面標籤 = 紫</span></div></section>' +
      (App.isStatic ? staticCard() :
      '<section class="card"><div class="card-h"><h2>🕒 資料更新</h2></div><div class="kv-grid" style="grid-template-columns:1fr">' +
      '<div><span>資料日期</span><span>' + esc(meta.data_date || '—') + '</span></div>' +
      '<div><span>最後更新</span><span>' + esc((meta.updated_at || '—').replace('T', ' ').slice(0, 19)) + '</span></div>' +
      '<div><span>自動更新排程</span><span>' + esc(meta.schedule || '—') + '</span></div>' +
      '<div><span>下次更新</span><span>' + esc((meta.next_update || '—').replace('T', ' ').slice(0, 16)) + '</span></div>' +
      '<div><span>收錄股票／可評分</span><span>' + fmtInt(cnt.stocks) + ' 檔／' + fmtInt(cnt.eligible) + ' 檔</span></div>' +
      '<div><span>歷史資料天數</span><span>' + fmtInt(cnt.days) + ' 個交易日</span></div></div>' +
      '<p class="small muted mt-s">資料更新時，右上角會顯示進度；完成後頁面自動換成新資料，不需要手動重新整理。</p>' +
      ((st.errors || []).length ? '<details class="msgs"><summary>資料更新訊息（' + st.errors.length + '）</summary><ul>' +
        st.errors.slice(-20).map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></details>' : '') + '</section>') + '</div>' +
      '<section class="card mt"><div class="card-h"><h2>🔗 資料來源</h2></div><ul class="src-list">' +
      '<li>臺灣證券交易所（TWSE）OpenAPI 與盤後資料：上市股票日成交、本益比／殖利率、三大法人、注意／處置股</li>' +
      '<li>證券櫃檯買賣中心（TPEx）OpenAPI 與盤後資料：上櫃股票行情與法人買賣超</li>' +
      '<li>公開資訊觀測站（MOPS）：月營收、季財報（EPS、營收、營業利益、稅後淨利）、公司基本資料、股利</li>' +
      '<li><a href="https://ic.tpex.org.tw/" target="_blank" rel="noopener noreferrer">櫃買中心 產業價值鏈資訊平台</a>：47 條產業鏈的上中下游環節與公司</li>' +
      '<li>新聞：Google 新聞 RSS 與財經媒體公開資訊（點擊後開啟原網站）</li>' +
      '<li>K 線圖：<a href="https://www.tradingview.com/lightweight-charts/" target="_blank" rel="noopener noreferrer">TradingView Lightweight Charts™</a>（Apache 2.0 授權）</li></ul></section>' +
      '<section class="card mt"><div class="card-h"><h2>🧮 綜合分數怎麼算？</h2><a class="btn xs ghost" href="#/picks">看回測績效 →</a></div><div class="grid g2"><div>' +
      (m.text ? '<p style="line-height:1.8;color:var(--text-2)">' + esc(m.text) + '</p>' : '<p class="muted">' + loadingHtml('載入評分方法…') + '</p>') +
      ((m.filters || []).length ? '<div class="subh">納入條件</div><ul class="risk-list">' + m.filters.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ul>' : '') +
      '</div><div><div class="subh" style="margin-top:0">因子權重</div><div class="wbars">' + weightsHtml + '</div>' +
      '<p class="small muted mt">每個因子先換算成「全市場百分位」：80 分代表贏過 80% 的股票。權重為 0 的因子只供參考。技術分數（技術面偏多／偏空）是另外由 K 線、均線、指標計算的 0–100 分。</p></div></div></section>' +
      '<section class="card mt"><div class="card-h"><h2>📖 新手指標小辭典</h2><span class="sub">點標題展開說明</span><span class="sp"></span><button type="button" class="btn xs" data-act="gloss-all">⊞ 展開全部</button></div>' +
      '<div class="gloss">' + GLOSSARY.map(function (g) {
        return '<details class="gloss-item"><summary><h3 style="display:inline-flex">' + g[0] + ' ' + esc(g[1]) + '</h3></summary><p style="margin-top:6px">' + esc(g[2]) +
          '</p><div class="how">👉 怎麼看：' + esc(g[3]) + '</div></details>';
      }).join('') + '</div></section>' +
      '<section class="card mt" style="background:#fffbeb;border-color:#fcd34d"><div class="card-h"><h2>⚖️ 投資風險與法律免責聲明</h2></div>' +
      '<p style="line-height:1.8;color:#78350f;margin:0">' + esc(App.disclaimer()) + ' 本站暨開發者並非金管會核准之證券投資顧問事業，所有資料可能因來源延遲、格式變動或程式解析誤差而不完整；過去之回測績效不代表未來表現，投資人於下單前應自行查證並獨立評估風險，本站及開發者不負任何損害賠償或法律責任。</p></section>');
  }

  function staticCard() {
    var t = App.staticInfo || {}, meta = App.meta || {};
    return '<section class="card"><div class="card-h"><h2>🕒 資料快照資訊</h2></div><div class="kv-grid" style="grid-template-columns:1fr">' +
      '<div><span>版本</span><span>v' + esc(t.version || meta.version || '—') + '</span></div>' +
      '<div><span>資料日期</span><span>' + esc(meta.data_date || t.data_date || '—') + '</span></div>' +
      '<div><span>更新時間</span><span>' + esc((t.built_at || '—').replace('T', ' ').slice(0, 16)) + '</span></div>' +
      '<div><span>完整 K 線與技術分析</span><span>' + fmtInt(t.stocks_full) + ' 檔（熱門股＋今日推薦）</span></div></div>' +
      '<p class="small muted mt-s">選股器、類股表現、ETF 股利與產業鏈涵蓋全部上市櫃標的；個股 K 線與技術分析收錄熱門股與今日推薦。</p></section>';
  }

  window.Pages.about = {
    render: render,
    destroy: function () { A.alive = false; if (A.el) A.el.removeEventListener('click', onClick); }
  };
})();
