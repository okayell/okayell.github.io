/* 意見回饋 (#/feedback) — Bug 回報、功能許願與體驗建議，送出後寄信至 okayell@hotmail.com */
(function () {
  'use strict';
  var TARGET_EMAIL = 'okayell@hotmail.com';
  var LS_KEY = 'twstock.feedback.v1';
  var KINDS = [
    ['feature', '✨ 功能許願'],
    ['bug', '🐞 問題回報 (Bug)'],
    ['ux', '🎨 介面與選股建議'],
    ['other', '💬 其他意見']
  ];
  var FB = {el: null, alive: false, items: null, kind: 'feature', sending: false};

  function loadLocal() {
    try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); }
    catch (e) { return []; }
  }
  function saveLocal(items) {
    try { localStorage.setItem(LS_KEY, JSON.stringify((items || []).slice(0, 50))); }
    catch (e) { /* ignore */ }
  }
  function buildMailto(kindLabel, title, desc) {
    var subject = '[台股智慧選股 意見回饋] ' + kindLabel + ' — ' + title;
    var body = '工具名稱：台股智慧選股\n回饋類型：' + kindLabel + '\n標題：' + title + '\n\n內容描述：\n' + desc + '\n';
    return 'mailto:' + TARGET_EMAIL + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
  }

  function isStaticEnv() {
    return Boolean(
      App.isStatic ||
      window.__STATIC_API__ ||
      location.protocol === 'file:' ||
      /\.github\.io$|\.pages\.dev$|\.netlify\.app$|\.vercel\.app$/i.test(location.hostname || '')
    );
  }

  function renderFallbackBox(kindLabel, title, desc, note) {
    if (window.CampusNav && CampusNav.fallbackHtml) {
      return CampusNav.fallbackHtml({
        email: TARGET_EMAIL,
        tool: '台股智慧選股',
        kindLabel: kindLabel,
        title: title,
        description: desc,
        note: note
      });
    }
    var mailtoUrl = buildMailto(kindLabel, title, desc);
    return '<div style="background:#fffbeb;border:1px solid #fcd34d;color:#92400e;padding:10px 12px;border-radius:8px;font-size:13px">' +
      esc(note || '請點此寄出：') + ' <a href="' + esc(mailtoUrl) + '" style="font-weight:700;text-decoration:underline">📩 直接寄信給站長</a>。</div>';
  }

  function sendStaticEmail(item) {
    if (window.CampusNav && CampusNav.sendStaticFeedback) {
      return CampusNav.sendStaticFeedback({
        email: TARGET_EMAIL,
        tool: '台股智慧選股',
        kindLabel: item.kind_label,
        title: item.title,
        description: item.description,
        createdAt: item.created_at
      });
    }
    var subject = '[台股智慧選股 意見回饋] ' + item.kind_label + ' — ' + item.title;
    return fetch('https://formsubmit.co/ajax/' + TARGET_EMAIL, {
      method: 'POST',
      headers: {'Content-Type': 'application/json', Accept: 'application/json'},
      body: JSON.stringify({
        _subject: subject,
        _template: 'table',
        _captcha: 'false',
        '工具名稱': '台股智慧選股',
        '回饋類型': item.kind_label,
        '標題': item.title,
        '內容描述': item.description,
        '送出時間': item.created_at
      })
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        return {sent: r.ok && (d.success === 'true' || d.success === true)};
      });
    }, function () {
      return {sent: false};
    });
  }

  function paint(bannerHtml) {
    if (!FB.alive || !FB.el) return;
    var items = FB.items || [];
    FB.el.innerHTML =
      '<div class="card" style="margin-bottom:14px">' +
        '<h1 style="margin:0 0 6px;font-size:20px">💬 意見回饋・問題回報・功能許願</h1>' +
        '<p class="muted" style="margin:0;font-size:13.5px">有任何選股條件建議、技術指標許願或介面問題回報，歡迎隨時留言！送出後將自動寄送通知信至站長信箱。</p>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:14px;align-items:start">' +
        '<form class="card" id="twFbForm" style="display:flex;flex-direction:column;gap:14px">' +
          '<div>' +
            '<label style="font-weight:700;font-size:13.5px;display:block;margin-bottom:6px">1. 回饋類型</label>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
              KINDS.map(function (k) {
                var on = FB.kind === k[0];
                return '<button type="button" class="btn sm' + (on ? ' primary' : '') + '" data-tw-fb-kind="' + k[0] + '" ' +
                  'style="' + (on ? 'background:#2563eb;color:#fff;border-color:#2563eb' : '') + '">' + k[1] + '</button>';
              }).join('') +
            '</div>' +
          '</div>' +
          '<div>' +
            '<label for="twFbTitle" style="font-weight:700;font-size:13.5px;display:block;margin-bottom:6px">2. 標題</label>' +
            '<input id="twFbTitle" required maxlength="150" placeholder="簡短說明您的建議、許願功能或遇到的問題…" ' +
              'style="width:100%;padding:8px 11px;border:1px solid #cbd5e1;border-radius:8px;font-size:13.5px;font-family:inherit;background:#fff;color:#0f172a">' +
          '</div>' +
          '<div>' +
            '<label for="twFbDesc" style="font-weight:700;font-size:13.5px;display:block;margin-bottom:6px">3. 內容描述</label>' +
            '<textarea id="twFbDesc" required rows="6" maxlength="4000" placeholder="請描述詳細情境、希望新增的台股／ETF 指標，或操作上遇到的異常狀況…" ' +
              'style="width:100%;min-height:130px;padding:8px 11px;border:1px solid #cbd5e1;border-radius:8px;font-size:13.5px;font-family:inherit;resize:vertical;background:#fff;color:#0f172a"></textarea>' +
          '</div>' +
          (bannerHtml || '<div id="twFbBanner" class="hidden"></div>') +
          '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">' +
            '<span class="muted" style="font-size:12px">📩 送出後會自動通知站長</span>' +
            '<button type="submit" class="btn primary" id="twFbSubmit" style="background:#2563eb;color:#fff;border-color:#2563eb">📨 送出回饋</button>' +
          '</div>' +
        '</form>' +
        '<div class="card">' +
          '<h3 style="margin:0 0 10px;font-size:15.5px">🗂️ 已送出的回饋紀錄（' + items.length + '）</h3>' +
          '<div style="display:flex;flex-direction:column;gap:10px;max-height:520px;overflow-y:auto">' +
            (items.length ? items.map(function (it) {
              return '<div style="padding:10px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:9px">' +
                '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:4px">' +
                  '<span style="font-size:12px;font-weight:700;color:#1d4ed8;background:#dbeafe;padding:2px 8px;border-radius:99px">' + esc(it.kind_label || it.kind) + '</span>' +
                  '<span class="muted" style="font-size:11.5px">' + esc(it.created_at || '') + '</span>' +
                '</div>' +
                '<div style="font-weight:700;font-size:13.5px">' + esc(it.title) + '</div>' +
                '<div style="font-size:12.5px;color:#334155;margin-top:4px;white-space:pre-wrap">' + esc(it.description) + '</div>' +
              '</div>';
            }).join('') : '<div class="muted" style="padding:24px 0;text-align:center">目前尚無回饋紀錄，歡迎留下第一則建議！</div>') +
          '</div>' +
        '</div>' +
      '</div>';

    $$('[data-tw-fb-kind]', FB.el).forEach(function (btn) {
      btn.onclick = function () {
        var curT = ($('#twFbTitle', FB.el) || {}).value || '';
        var curD = ($('#twFbDesc', FB.el) || {}).value || '';
        FB.kind = btn.getAttribute('data-tw-fb-kind');
        paint();
        if ($('#twFbTitle', FB.el)) $('#twFbTitle', FB.el).value = curT;
        if ($('#twFbDesc', FB.el)) $('#twFbDesc', FB.el).value = curD;
      };
    });

    var tInp = $('#twFbTitle', FB.el);
    if (tInp) {
      tInp.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' && !App.isEnterSend(ev)) ev.preventDefault();
      });
    }

    var form = $('#twFbForm', FB.el);
    if (form) {
      form.onsubmit = function (ev) {
        ev.preventDefault();
        if (FB.sending) return;
        var title = (($('#twFbTitle', FB.el) || {}).value || '').trim();
        var description = (($('#twFbDesc', FB.el) || {}).value || '').trim();
        if (!title || !description) {
          toast('請填寫標題與內容描述');
          return;
        }
        FB.sending = true;
        var btn = $('#twFbSubmit', FB.el);
        if (btn) { btn.disabled = true; btn.textContent = '⏳ 寄送中…'; }
        var kPair = KINDS.find(function (x) { return x[0] === FB.kind; }) || KINDS[0];
        var kindLabel = kPair[1];

        if (!isStaticEnv()) {
          fetch('/api/feedback', {
            method: 'POST',
            headers: {'Content-Type': 'application/json', Accept: 'application/json'},
            body: JSON.stringify({kind: FB.kind, title: title, description: description})
          }).then(function (r) { return r.json().then(function (d) { return {ok: r.ok, d: d}; }); }).then(function (res) {
            FB.sending = false;
            if (!res.ok || !res.d.ok) throw new Error((res.d && res.d.error) || '送出失敗');
            FB.items = res.d.items || [res.d.item].concat(FB.items || []);
            saveLocal(FB.items);
            var sentOk = !res.d.item || res.d.item.mail_sent !== false;
            if (sentOk) {
              toast('✅ 感謝您的回饋！已寄送至站長信箱');
              paint('<div style="background:#f0fdf4;border:1px solid #86efac;color:#166534;padding:10px 12px;border-radius:8px;font-size:13px">✅ 已成功收到並寄送通知信給站長！感謝您的寶貴建議。</div>');
            } else {
              paint(renderFallbackBox(kindLabel, title, description, '✅ 回饋已儲存至伺服器紀錄；但自動寄信暫時忙碌，請任選下方一種方式一鍵寄達站長：'));
            }
          }).catch(function (err) {
            FB.sending = false;
            paint(renderFallbackBox(kindLabel, title, description, '⚠️ 暫時無法連線（' + (err.message || '連線忙碌') + '），請任選下方一種方式一鍵寄達站長：'));
          });
        } else {
          var item = {
            id: 'FB-' + Date.now().toString(36).toUpperCase(),
            kind: FB.kind,
            kind_label: kindLabel,
            title: title,
            description: description,
            created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
          };
          sendStaticEmail(item).then(function (mRes) {
            FB.sending = false;
            FB.items = [item].concat(FB.items || []);
            saveLocal(FB.items);
            if (mRes && mRes.sent) {
              paint('<div style="background:#f0fdf4;border:1px solid #86efac;color:#166534;padding:10px 12px;border-radius:8px;font-size:13px">✅ 感謝回饋！意見已成功寄送給站長。</div>');
            } else {
              paint(renderFallbackBox(kindLabel, title, description));
            }
          });
        }
      };
    }
  }

  function render(params, el) {
    FB.el = el;
    FB.alive = true;
    setTitle('意見回饋');
    if (FB.items === null) FB.items = loadLocal();
    paint();
    if (!isStaticEnv()) {
      fetch('/api/feedback', {headers: {Accept: 'application/json'}}).then(function (r) { return r.json(); }).then(function (d) {
        if (d && Array.isArray(d.items)) {
          FB.items = d.items;
          if (FB.alive) paint();
        }
      }).catch(function () {});
    }
  }

  function destroy() {
    FB.alive = false;
    FB.el = null;
  }

  window.Pages.feedback = {render: render, destroy: destroy};
})();
