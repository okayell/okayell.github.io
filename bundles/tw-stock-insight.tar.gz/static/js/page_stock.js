/* 個股分析 (#/stock/<code>) — hero, K-line chart (KChart), 一鍵技術分析 panel, fundamentals tabs. */
(function () {
  'use strict';
  var TF_RANGES = {
    D: [['3m', '3M', 3], ['6m', '6M', 6], ['1y', '1Y', 12], ['2y', '2Y', 24], ['5y', '5Y', 60]],
    W: [['6m', '6M', 6], ['1y', '1Y', 12], ['2y', '2Y', 24], ['5y', '5Y', 60]],
    M: [['2y', '2Y', 24], ['5y', '5Y', 60], ['all', '全部', 0]]
  };
  var TF_DEFAULT = {D: '6m', W: '2y', M: '5y'};
  var TF_LABEL = {D: '日K', W: '週K', M: '月K'};
  var TABS = [['profile', '基本資料'], ['revenue', '營收'], ['eps', '獲利'], ['div', '股利'], ['inst', '法人籌碼'],
    ['news', '新聞'], ['peers', '同業比較'], ['chain', '產業鏈位置']];
  var STANCE_CLS = {'強勢多頭': 'solid-bull', '偏多': 'bull', '中性': '', '偏空': 'bear', '弱勢空頭': 'solid-bear'};
  var LEVEL_CLS = {'2': 'solid-bull', '1': 'bull', '0': '', '-1': 'bear', '-2': 'solid-bear'};
  var PREF_KEY = 'tw.chart.prefs.v1';
  var S = {};

  function fetchRange(tf, rk) {
    if (tf === 'D') return rk === '5y' ? '5y' : '2y';
    if (tf === 'W') return '5y';
    return 'max';
  }
  function monthsOf(tf, rk) {
    var r = (TF_RANGES[tf] || []).filter(function (x) { return x[0] === rk; })[0];
    return r ? r[2] : 6;
  }
  function loadPrefs() {
    var p = {};
    try { p = JSON.parse(localStorage.getItem(PREF_KEY) || '{}') || {}; } catch (e) { p = {}; }
    return {ma: p.ma || {ma5: true, ma20: true, ma60: true}, bb: !!p.bb, sub: p.sub || 'kd', marks: p.marks !== false};
  }
  function savePrefs() {
    try { localStorage.setItem(PREF_KEY, JSON.stringify(S.prefs)); } catch (e) { /* ignore */ }
  }
  function stockUrl(tf, fr) { return '/api/stock/' + encodeURIComponent(S.code) + '?tf=' + tf + '&range=' + fr; }
  function isNum(v) { return App.isNum(v); }

  // ------------------------------------------------------------------ lifecycle
  function render(params, el) {
    var q = params.query || {};
    S = {el: el, alive: true, code: String(params.code || '').toUpperCase(), data: null, kc: null, prefs: loadPrefs(),
      tf: TF_RANGES[q.tf] ? q.tf : 'D', rk: '', tab: q.tab || 'profile', ana: null, anaLoading: false, tabHtml: {},
      news: null, newsErr: null, instMode: 'total', curFetch: ''};
    S.rk = q.range && monthsOfValid(S.tf, q.range) ? q.range : TF_DEFAULT[S.tf];
    setLastStock(S.code);
    setTitle(S.code + ' 個股分析');
    el.innerHTML = '<div class="skel" style="height:132px"></div><div class="skel mt" style="height:640px"></div>';
    el.addEventListener('click', onClick);
    var fr = fetchRange(S.tf, S.rk);
    return api(stockUrl(S.tf, fr)).then(function (d) {
      if (!S.alive) return;
      S.data = d;
      S.curFetch = fr;
      setTitle(d.name + ' ' + d.code);
      if (d.lite) { paintLite(d); return; }
      paint();
      var hadUni = !!App.uniCached();
      getUniverse().then(function () {
        if (!S.alive || hadUni) return;
        var h = document.getElementById('stHero');
        if (h) { var tmp = document.createElement('div'); tmp.innerHTML = heroHtml(S.data); h.parentNode.replaceChild(tmp.firstChild, h); }
        if (S.tab === 'peers' || S.tab === 'profile') showTab(S.tab, true);
      }, function () {});
      if (!App.weights && d.score) {
        api('/api/picks').then(function () { if (S.alive && S.tab === 'profile') showTab('profile', true); }, function () {});
      }
    }, function (e) {
      if (!S.alive) return;
      el.innerHTML = '<div class="card empty err"><div class="big">🔎</div><h3>' + (e.status === 404 ? '找不到股票代號「' + esc(S.code) + '」' : '無法載入個股資料') +
        '</h3><p>' + esc(e.message) + '</p><p class="small">可按 <kbd>/</kbd> 用代號或名稱搜尋，或回到 <a href="#/screener">選股器</a>。</p>' +
        (e.status === 404 ? '' : '<button type="button" class="btn sm" data-act="retry">重試</button>') + '</div>';
    });
  }
  function monthsOfValid(tf, rk) { return (TF_RANGES[tf] || []).some(function (x) { return x[0] === rk; }); }

  function paint() {
    var d = S.data;
    S.el.innerHTML = heroHtml(d) +
      '<div class="campus-acad-bar"><b>🏛️ 財經學院 · 看盤觀念對照：</b>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/ta" href="https://okayell.github.io/finance/#/track/ta">📈 技術分析學院（K線／均線／KD／MACD）</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/chip" href="https://okayell.github.io/finance/#/track/chip">🧮 籌碼面學院（三大法人／主力）</a>' +
      '<a class="campus-acad-pill" data-campus-go="finance" data-campus-hash="#/track/fa" href="https://okayell.github.io/finance/#/track/fa">📊 基本面學院（營收／EPS／殖利率）</a></div>' +
      '<section class="card chart-card mt"><div class="ctoolbar" id="ctb">' + toolbarHtml() + '</div><div id="anaStrip"></div>' +
      '<div style="position:relative"><div class="kc" id="kc"></div><div class="kc-loading hidden" id="kcLoad"></div></div>' +
      '<div class="kc-note"><span>' + (d.adjusted ? 'K 線已還原權息' : 'K 線未還原權息') + '</span>' +
      (App.isStatic ? '<span>靜態版收錄近 1 年日K（週K／月K 由日K 換算）</span>' : '') + '<span>滾輪縮放 · 拖曳平移 · 十字線同步三個圖</span>' +
      '<span class="sp"></span><span>圖表：<a href="https://www.tradingview.com/" target="_blank" rel="noopener noreferrer">TradingView Lightweight Charts™</a></span></div></section>' +
      '<div id="anaPanel"></div>' +
      '<section class="card tabbox"><div class="tabs" id="stTabs" role="tablist">' + tabsHtml() + '</div><div class="tab-body" id="tabBody"></div></section>' +
      disclaimerHtml();
    try {
      S.kc = new window.KChart(document.getElementById('kc'), {ma: S.prefs.ma, bb: S.prefs.bb, sub: S.prefs.sub});
      S.kc.setData(d);
      S.kc.setRange(monthsOf(S.tf, S.rk));
    } catch (e) {
      console.error(e);
      document.getElementById('kc').innerHTML = '<div class="empty">⚠️ 圖表載入失敗：' + esc(e.message) + '</div>';
    }
    if (!(d.bars || []).length) {
      document.getElementById('kc').insertAdjacentHTML('beforeend', '<div class="kc-loading">尚無 K 線資料</div>');
    }
    if (!tabVisible(S.tab)) S.tab = 'profile';
    showTab(S.tab, true);
    syncUrl();
  }

  /** GitHub static build: stock without embedded K-line → key metrics only. */
  function paintLite(d) {
    var t = App.staticInfo || {}, r = d.row || {}, q = d.quote || {}, sc = d.score;
    var pct = function (v, dd) { return '<span class="' + clsUpDown(v) + '">' + fmtPct(v, dd === undefined ? 1 : dd) + '</span>'; };
    var streak = function (n) { return isNum(n) && n !== 0 ? (n > 0 ? '<span class="up">連買 ' + n + ' 日</span>' : '<span class="down">連賣 ' + (-n) + ' 日</span>') : '—'; };
    var cards = [
      valCard('近 20 日漲跌', pct(r.r20), '60 日 ' + fmtPct(r.r60, 1) + ' · 1 年 ' + fmtPct(r.r250, 1)),
      valCard('本益比 PE', isNum(r.pe) ? fmtNum(r.pe, 1) : '—', '股價淨值比 ' + fmtNum(r.pb, 2)),
      valCard('殖利率', isNum(r.yld) ? fmtNum(r.yld, 2) + '%' : '—', 'EPS 近四季 ' + fmtNum(r.eps_ttm, 2) + ' 元'),
      valCard('月營收年增', pct(r.rev_yoy), r.rev_ym ? esc(r.rev_ym) + ' · 累計 ' + fmtPct(r.rev_cum_yoy, 1) : '—'),
      valCard('籌碼強度', isNum(r.chip) ? '<span class="' + clsUpDown(r.chip) + '">' + fmtNum(r.chip, 1) + '%</span>' : '—', '外資 ' + streak(r.streak_f) + ' · 投信 ' + streak(r.streak_t)),
      valCard('技術面', isNum(r.tech_score) ? Math.round(r.tech_score) + '<small style="font-size:12px"> 分</small>' : '—', 'RSI ' + fmtNum(r.rsi, 1) + ' · K ' + fmtNum(r.k, 1) + ' · 月線乖離 ' + fmtPct(r.bias20, 1))
    ];
    S.el.innerHTML = heroHtml(d) +
      '<section class="card mt static-note"><span style="font-size:26px">📦</span><div><b>GitHub 靜態版只收錄熱門股與今日推薦的完整 K 線與技術分析（共 ' + fmtInt(t.stocks_full) +
      ' 檔），此股請在線上版查看</b><div class="small muted mt-s">以下是打包當日（' + esc(q.date || t.data_date || '—') + '）的重點數據；K 線圖、一鍵技術分析、月營收、獲利與法人籌碼明細請在線上版瀏覽。</div></div></section>' +
      '<section class="card mt"><div class="card-h"><h2>📊 重點數據</h2></div><div class="val-cards">' + cards.join('') + '</div></section>' +
      (sc ? '<section class="card mt"><div class="card-h"><h2>🧮 綜合評分</h2><span class="chip">第 ' + fmtInt(sc.rank) + ' 名</span><span class="sub">全市場百分位，越高越好</span></div>' +
        '<div class="score-card">' + scoreRing(sc.score, 72) + factorBars(sc.factors) + '<div class="small muted">各因子為全市場百分位；完整的評分理由請在線上版查看。</div></div></section>' : '') +
      '<section class="card mt"><div class="card-h"><h2>🏭 同業比較</h2></div>' + TAB_RENDER.peers(d) + '</section>' +
      '<section class="card mt"><div class="card-h"><h2>🔗 產業鏈位置</h2></div>' + TAB_RENDER.chain(d) + '</section>' + disclaimerHtml();
  }

  function syncUrl() {
    var o = {};
    if (S.tf !== 'D') o.tf = S.tf;
    if (S.rk !== TF_DEFAULT[S.tf]) o.range = S.rk;
    if (S.tab !== 'profile') o.tab = S.tab;
    App.replaceHash('#/stock/' + encodeURIComponent(S.code) + buildQuery(o));
  }

  // ------------------------------------------------------------------ hero
  function heroHtml(d) {
    var q = d.quote || {}, ref = q.close;
    var uni = App.uniCached(), row = uni && uni.by[d.code];
    var r52 = '';
    if (isNum(q.hi52) && isNum(q.lo52) && q.hi52 > q.lo52 && isNum(q.close)) {
      var pos = Math.max(0, Math.min(100, (q.close - q.lo52) / (q.hi52 - q.lo52) * 100));
      r52 = '<div class="r52" data-tip="目前股價位於 52 週區間的 ' + pos.toFixed(0) + '% 位置"><div class="row"><span>52 週區間</span><span class="sp"></span><span>距高點 ' +
        fmtPct((q.close / q.hi52 - 1) * 100, 1) + '</span></div><div class="bar"><span class="dot" style="left:' + pos.toFixed(1) + '%"></span></div>' +
        '<div class="ends"><span class="down">' + fmtPrice(q.lo52, ref) + '</span><span class="up">' + fmtPrice(q.hi52, ref) + '</span></div></div>';
    }
    var chains = (d.chains || []).map(function (c) {
      return '<a class="chip info" href="#/industry/' + encodeURIComponent(c.id) + '" data-tip="櫃買中心產業價值鏈：' + esc(c.name + ' › ' + c.stream + ' › ' + c.segment) + '">🔗 ' +
        esc(c.name) + ' · ' + esc(c.stream) + ' · ' + esc(c.segment) + '</a>';
    }).join('');
    var mcap = row && isNum(row.mcap) ? row.mcap : null;
    return '<section class="card" id="stHero"><div class="s-hero"><div>' +
      '<div class="s-title"><h1>' + esc(d.name) + '</h1><span class="code">' + esc(d.code) + '</span>' +
      '<span class="chip">' + esc(d.market || '') + '</span>' +
      (d.type === 'ETF' ? '<span class="chip info">ETF</span>' : (d.industry ? '<a class="chip" href="#/screener?ind=' + encodeURIComponent(d.industry) + '" data-tip="在選股器查看同產業">' + esc(d.industry) + '</a>' : '')) +
      starBtn(d.code) + '</div>' +
      '<div class="s-price"><span class="px ' + clsUpDown(q.chg) + '">' + fmtPrice(q.close) + '</span><span class="chg ' + clsUpDown(q.chg) + '">' +
      arrow(q.chg) + ' ' + fmtPrice(Math.abs(q.chg || 0), ref) + '（' + fmtPct(q.pct) + '）</span><span class="small muted">資料日期 ' + esc(q.date || '—') + '</span></div>' +
      '<div class="ohlc"><span>開<b>' + fmtPrice(q.open, ref) + '</b></span><span>高<b class="up">' + fmtPrice(q.high, ref) + '</b></span><span>低<b class="down">' +
      fmtPrice(q.low, ref) + '</b></span><span>成交量<b>' + fmtInt(q.vol) + ' 張</b></span><span>成交值<b>' + fmtYi(q.value) + ' 億</b></span>' +
      (mcap !== null ? '<span>市值<b>' + fmtYi(mcap) + ' 億</b></span>' : '') + '</div>' +
      ((d.signals || []).length || (d.risk || []).length ? '<div class="chips mt-s">' + (d.risk || []).map(riskChip).join('') + (d.signals || []).map(sigChip).join('') + '</div>' : '') +
      '</div><div class="s-side">' + r52 + (chains ? '<div class="s-chains">' + chains + '</div>' : '') + '</div></div></section>';
  }

  // ------------------------------------------------------------------ toolbar
  function toolbarHtml() {
    var p = S.prefs;
    var seg = function (g, opts, cur) {
      return '<div class="seg">' + opts.map(function (o) {
        return '<button type="button" class="' + (o[0] === cur ? 'on' : '') + '" data-' + g + '="' + o[0] + '">' + o[1] + '</button>';
      }).join('') + '</div>';
    };
    var anaBtn = S.anaLoading ? '<button type="button" class="btn hero" disabled><span class="spin"></span> 分析中…</button>' :
      (S.ana ? '<button type="button" class="btn hero" data-act="goto-ana">📖 查看完整解說</button>' :
        '<button type="button" class="btn hero" data-act="analyze" id="btnAnalyze" data-tip="自動判斷趨勢、支撐壓力、型態與訊號，並畫在 K 線圖上">🧠 一鍵技術分析</button>');
    return seg('tf', [['D', '日K'], ['W', '週K'], ['M', '月K']], S.tf) +
      seg('rk', TF_RANGES[S.tf].map(function (r) { return [r[0], r[1]]; }), S.rk) +
      '<div class="grp"><span class="lbl">均線</span>' + window.KChart.MA_DEF.map(function (m) {
        return '<button type="button" class="ma-t' + (p.ma[m[0]] ? ' on' : '') + '" data-ma="' + m[0] + '"><i style="background:' + m[2] + '"></i>' + m[1].replace('MA', '') + '</button>';
      }).join('') + '<button type="button" class="ma-t' + (p.bb ? ' on' : '') + '" data-bb="1" data-tip="布林通道：20 日均線 ± 2 倍標準差"><i style="background:#94a3b8"></i>布林</button></div>' +
      '<div class="grp"><span class="lbl">副圖</span>' + seg('sub', [['kd', 'KD'], ['macd', 'MACD'], ['rsi', 'RSI']], p.sub) + '</div>' +
      '<span class="sp"></span>' + anaBtn;
  }
  function renderToolbar() { setHtml(document.getElementById('ctb'), toolbarHtml()); }

  function showLoading(text) {
    var el = document.getElementById('kcLoad');
    if (!el) return;
    el.innerHTML = loadingHtml(text);
    el.classList.remove('hidden');
  }
  function hideLoading() {
    var el = document.getElementById('kcLoad');
    if (el) el.classList.add('hidden');
  }
  function loadBars() {
    var fr = fetchRange(S.tf, S.rk), url = stockUrl(S.tf, fr), tf = S.tf;
    if (!App.apiCached(url)) showLoading(fr === '5y' || fr === 'max' ? '載入較長期間的 K 線中，可能需要幾秒…' : '載入 K 線中…');
    return api(url).then(function (d) {
      if (!S.alive || S.tf !== tf) return;
      S.curFetch = fr;
      S.kc.setData(d);
      S.kc.setRange(monthsOf(S.tf, S.rk));
      hideLoading();
      if (S.ana && S.ana.tf !== S.tf) runAnalysis();
    }, function (e) {
      hideLoading();
      if (S.alive) toast('K 線載入失敗：' + e.message, 'err');
    });
  }
  function setTf(tf) {
    if (tf === S.tf || !TF_RANGES[tf]) return;
    S.tf = tf;
    S.rk = TF_DEFAULT[tf];
    renderToolbar();
    syncUrl();
    loadBars();
  }
  function setRangeKey(rk) {
    if (rk === S.rk) return;
    S.rk = rk;
    renderToolbar();
    syncUrl();
    if (fetchRange(S.tf, rk) !== S.curFetch) loadBars();
    else if (S.kc) S.kc.setRange(monthsOf(S.tf, rk));
  }

  // ------------------------------------------------------------------ analysis
  function runAnalysis() {
    if (S.anaLoading) return;
    S.anaLoading = true;
    renderToolbar();
    var tf = S.tf, first = !S.ana;
    api('/api/stock/' + encodeURIComponent(S.code) + '/analysis?tf=' + tf).then(function (a) {
      if (!S.alive || S.tf !== tf) return;
      S.ana = a;
      if (S.kc) {
        S.kc.setAnnotations(a.annotations || {});
        S.kc.showAnnotations(S.prefs.marks);
      }
      renderAnaStrip();
      renderAnaPanel();
      if (first) toast('技術分析完成：已在 K 線圖標示支撐、壓力、趨勢線與訊號', 'ok');
    }, function (e) {
      if (!S.alive) return;
      if (S.ana && S.ana.tf !== S.tf) closeAna();
      toast(App.isStatic ? e.message : '技術分析失敗：' + e.message, App.isStatic ? 'warn' : 'err', 4500);
    }).then(function () {
      S.anaLoading = false;
      if (S.alive) renderToolbar();
    });
  }
  function stanceChip(a, lg) {
    return '<span class="chip ' + (lg ? 'lg ' : '') + (STANCE_CLS[a.stance] || '') + '">' + esc(a.stance || '—') + ' · ' + (isNum(a.score) ? Math.round(a.score) : '—') + ' 分</span>';
  }
  function marksBtn() {
    return '<button type="button" class="btn sm" data-act="marks">' + (S.prefs.marks ? '🙈 隱藏圖上標記' : '👁 顯示圖上標記') + '</button>';
  }
  function renderAnaStrip() {
    var a = S.ana, el = document.getElementById('anaStrip');
    if (!el) return;
    if (!a) { setHtml(el, ''); return; }
    setHtml(el, '<div class="ana-strip"><span class="small muted">🧠 ' + TF_LABEL[a.tf] + '技術面</span>' + stanceChip(a, true) +
      '<span class="sum">' + esc(a.summary || '') + '</span>' + marksBtn() + '<button type="button" class="btn sm" data-act="goto-ana">完整解說 ↓</button></div>');
  }
  function stars(n) {
    n = Math.max(0, Math.min(3, n || 0));
    return '<span class="stars" data-tip="強度 ' + n + ' / 3（觸及次數越多、越近期越強）">' + '★★★'.slice(0, n) + '<span class="off">' + '★★★'.slice(0, 3 - n) + '</span></span>';
  }
  function gaugeSvg(score) {
    var cx = 110, cy = 104, r = 84, sw = 18;
    var bands = [[0, 25, '#16a34a'], [25, 42, '#86efac'], [42, 58, '#cbd5e1'], [58, 75, '#fca5a5'], [75, 100, '#dc2626']];
    var pt = function (v, rr) { var th = Math.PI - v / 100 * Math.PI; return [cx + rr * Math.cos(th), cy - rr * Math.sin(th)]; };
    var paths = bands.map(function (b) {
      var p0 = pt(b[0] + 0.6, r), p1 = pt(b[1] - 0.6, r);
      return '<path d="M' + p0[0].toFixed(1) + ' ' + p0[1].toFixed(1) + ' A' + r + ' ' + r + ' 0 0 1 ' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1) +
        '" stroke="' + b[2] + '" stroke-width="' + sw + '" fill="none"/>';
    }).join('');
    var v = isNum(score) ? Math.max(0, Math.min(100, score)) : 50, tip = pt(v, r - 26);
    return '<svg width="220" height="122" viewBox="0 0 220 122" role="img" aria-label="技術分數 ' + v + '">' + paths +
      '<line x1="' + cx + '" y1="' + cy + '" x2="' + tip[0].toFixed(1) + '" y2="' + tip[1].toFixed(1) + '" stroke="#0f172a" stroke-width="3" stroke-linecap="round"/>' +
      '<circle cx="' + cx + '" cy="' + cy + '" r="6" fill="#0f172a"/>' +
      '<text x="22" y="120" font-size="10" fill="#16a34a">偏空</text><text x="178" y="120" font-size="10" fill="#dc2626">偏多</text></svg>';
  }
  function gaugeFacts(a) {
    var all = (a.signals || []).concat(a.candles || []);
    var bull = all.filter(function (x) { return x.type === 'bullish'; }).length, bear = all.filter(function (x) { return x.type === 'bearish'; }).length;
    var L = a.levels || {}, s0 = (L.supports || [])[0], r0 = (L.resistances || [])[0];
    var row = function (k, v) { return '<div><span>' + k + '</span><span>' + v + '</span></div>'; };
    return '<div class="kv-grid" style="grid-template-columns:1fr;align-self:stretch;margin-top:6px">' +
      row('偏多／偏空訊號', '<span class="up">' + bull + '</span> ／ <span class="down">' + bear + '</span>') +
      row('最近支撐', s0 ? '<span style="color:var(--support)">' + fmtPrice(s0.price, a.price) + '</span> <span class="small muted">' + fmtPct(pctFrom(s0.price, a.price), 1) + '</span>' : '—') +
      row('最近壓力', r0 ? '<span style="color:var(--resist)">' + fmtPrice(r0.price, a.price) + '</span> <span class="small muted">' + fmtPct(pctFrom(r0.price, a.price), 1) + '</span>' : '—') +
      row('ATR 平均波幅', isNum(a.atr) ? fmtPrice(a.atr, a.price) + ' <span class="small muted">' + fmtPct(a.atr / a.price * 100, 1, true) + '</span>' : '—') + '</div>';
  }
  function pctFrom(p, ref) { return isNum(p) && isNum(ref) && ref ? (p / ref - 1) * 100 : null; }
  function levelsTable(a) {
    var L = a.levels || {}, price = a.price, rows = [];
    (L.resistances || []).slice().sort(function (x, y) { return y.price - x.price; }).forEach(function (x) { rows.push(['res', x]); });
    rows.push(['now', null]);
    (L.supports || []).slice().sort(function (x, y) { return y.price - x.price; }).forEach(function (x) { rows.push(['sup', x]); });
    var body = rows.map(function (r) {
      if (r[0] === 'now') {
        return '<tr class="self"><td class="l"><b>現價</b></td><td><b>' + fmtPrice(price) + '</b></td><td colspan="3" class="l muted small">ATR（平均真實波幅）約 ' +
          fmtPrice(a.atr, price) + '，可作為停損緩衝參考</td></tr>';
      }
      var x = r[1], isRes = r[0] === 'res';
      var range = isNum(x.low) && isNum(x.high) && x.low !== x.high ? fmtPrice(x.low, price) + '–' + fmtPrice(x.high, price) : '';
      return '<tr><td class="l"><span class="chip ' + (isRes ? 'warn' : 'info') + '">' + (isRes ? '壓力' : '支撐') + '</span></td>' +
        '<td><b style="color:' + (isRes ? 'var(--resist)' : 'var(--support)') + '">' + fmtPrice(x.price, price) + '</b>' + (range ? '<div class="small muted">' + range + '</div>' : '') + '</td>' +
        '<td class="' + clsUpDown(pctFrom(x.price, price)) + '">' + fmtPct(pctFrom(x.price, price), 1) + '</td><td>' + stars(x.strength) + '</td>' +
        '<td class="l wrap"><span class="chip">' + esc(x.kind || '') + '</span> <span class="small">' + esc(x.desc || '') + '</span></td></tr>';
    }).join('');
    var dyn = (L.dynamic || []).map(function (x) {
      return '<span class="chip ' + (x.role === 'support' ? 'info' : 'warn') + '" data-tip="' + (x.role === 'support' ? '在現價之下，可視為動態支撐' : '在現價之上，可視為動態壓力') + '">' +
        esc(x.name) + ' ' + fmtPrice(x.price, price) + (x.role === 'support' ? ' 撐' : ' 壓') + '</span>';
    }).join('');
    var poc = L.poc && isNum(L.poc.price) ? '<span class="chip" data-tip="' + esc(L.poc.desc || '') + '">成交密集區 POC ' + fmtPrice(L.poc.price, price) + '</span>' : '';
    return '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="l">類型</th><th>價位</th><th>距現價</th><th>強度</th><th class="l">依據</th></tr></thead><tbody>' +
      body + '</tbody></table></div>' + (dyn || poc ? '<div class="chips mt-s"><span class="small muted">均線／密集區：</span>' + dyn + poc + '</div>' : '');
  }
  function patternsHtml(a) {
    var ps = a.patterns || [];
    if (!ps.length) return '<div class="empty" style="padding:18px 8px"><div style="font-size:24px">🔺</div>近期未偵測到明確的經典型態（W底、M頭、頭肩、三角收斂、箱型…），以支撐壓力區間操作為主。</div>';
    var st = {'形成中': 'info', '已突破': 'bull', '已跌破': 'bear', '失效': 'ghost'};
    return '<div class="grid" style="gap:10px">' + ps.map(function (p) {
      return '<div class="pat-card"><div class="hd"><b>' + esc(p.name) + '</b><span class="chip ' + (p.type === 'bullish' ? 'bull' : p.type === 'bearish' ? 'bear' : '') + '">' +
        (p.type === 'bullish' ? '多方型態' : p.type === 'bearish' ? '空方型態' : '中性') + '</span><span class="chip ' + (st[p.status] || '') + '">' + esc(p.status || '') + '</span>' +
        (isNum(p.confidence) ? '<span class="small muted" data-tip="型態可信度">可信度 ' + Math.round(p.confidence * 100) + '%</span>' : '') + '</div>' +
        '<div class="kv">' + (isNum(p.neckline) ? '<span>頸線 <b>' + fmtPrice(p.neckline, a.price) + '</b></span>' : '') +
        (isNum(p.target) ? '<span>目標 <b>' + fmtPrice(p.target, a.price) + '</b></span>' : '') +
        (p.start ? '<span>' + esc(App.fmtMD(p.start)) + ' → ' + esc(App.fmtMD(p.end)) + '</span>' : '') + '</div>' +
        (p.desc ? '<p>' + esc(p.desc) + '</p>' : '') + '</div>';
    }).join('') + '</div>';
  }
  function signalsHtml(a) {
    var groups = {}, order = [];
    (a.candles || []).forEach(function (c) { (groups['K線型態'] = groups['K線型態'] || []).push(c); });
    if (groups['K線型態']) order.push('K線型態');
    (a.signals || []).forEach(function (s) {
      var g = s.group || '其他';
      if (!groups[g]) { groups[g] = []; order.push(g); }
      groups[g].push(s);
    });
    if (!order.length) return '<div class="empty" style="padding:18px 8px">近期沒有新的指標訊號或特殊 K 線。</div>';
    return order.map(function (g) {
      return '<div class="sig-group"><span class="gl">' + esc(g) + '</span>' + groups[g].map(function (s) {
        return '<div class="sig-item"><span class="chip ' + (s.type === 'bullish' ? 'bull' : s.type === 'bearish' ? 'bear' : '') + '">' + esc(s.name) + '</span>' +
          '<span class="d">' + esc(s.date || '') + '</span>' + (s.desc ? '<p>' + esc(s.desc) + '</p>' : '') + '</div>';
      }).join('') + '</div>';
    }).join('');
  }
  function planHtml(a) {
    var p = a.plan || {}, price = a.price, t = p.targets || [], e = p.entry || [];
    var row = function (label, val, extra) { return '<div class="plan-row"><span>' + label + '</span><b>' + val + (extra ? ' <span class="small muted">' + extra + '</span>' : '') + '</b></div>'; };
    return '<div class="plan-box">' + (p.bias ? '<div><span class="chip lg ' + (/多/.test(p.bias) ? 'bull' : /空/.test(p.bias) ? 'bear' : 'info') + '">' + esc(p.bias) + '</span></div>' : '') +
      (e.length ? row('進場區', fmtPrice(e[0], price) + (isNum(e[1]) ? '–' + fmtPrice(e[1], price) : '')) : '') +
      (isNum(p.stop) ? row('停損', '<span class="down">' + fmtPrice(p.stop, price) + '</span>', fmtPct(pctFrom(p.stop, price), 1)) : '') +
      t.map(function (x, i) { return row('目標 ' + (i + 1), '<span class="up">' + fmtPrice(x, price) + '</span>', fmtPct(pctFrom(x, price), 1)); }).join('') +
      (isNum(p.rr) ? row('報酬風險比', fmtNum(p.rr, 1), p.rr >= 2 ? '佳' : (p.rr >= 1 ? '普通' : '偏低')) : '') +
      (p.desc ? '<div class="plan-desc">' + esc(p.desc) + '</div>' : '') + '</div>';
  }
  function renderAnaPanel() {
    var a = S.ana, el = document.getElementById('anaPanel');
    if (!el) return;
    if (!a) { setHtml(el, ''); return; }
    var tr = a.trend || {}, v = a.volume || {};
    var trendRow = function (k, label) {
      var x = tr[k] || {};
      return '<tr><td class="l">' + label + '</td><td class="c"><span class="chip lvl-chip ' + (LEVEL_CLS[String(x.level)] || '') + '">' + esc(x.label || '—') + '</span></td>' +
        '<td class="l wrap small">' + esc(x.reason || '') + '</td></tr>';
    };
    var volCls = /價漲量增/.test(v.state || '') ? 'bull' : (/價跌量增/.test(v.state || '') ? 'bear' : 'info');
    var narr = (a.narrative || []).map(function (sec) {
      return '<div class="card narr-sec"><h3>' + esc(sec.title) + '</h3><ul>' + (sec.items || []).map(function (it) { return '<li>' + esc(it) + '</li>'; }).join('') + '</ul></div>';
    }).join('');
    setHtml(el, '<section class="ana" id="anaSec"><div class="ana-hd"><h2>🧠 技術分析解說</h2><span class="chip">' + TF_LABEL[a.tf] + '</span>' +
      '<span class="chip ghost">資料至 ' + esc(a.as_of || '') + '</span><span class="sp"></span>' + marksBtn() +
      '<button type="button" class="btn sm ghost" data-act="close-ana" data-tip="收合解說並清除圖上標記">✕ 收合</button></div>' +
      '<div class="ana-grid">' +
      '<div class="card gauge-wrap"><div class="card-h" style="align-self:stretch"><h3>技術分數</h3></div>' + gaugeSvg(a.score) +
      '<div style="margin-top:-6px">' + stanceChip(a, true) + '</div><div class="sum">' + esc(a.summary || '') + '</div>' + gaugeFacts(a) + '</div>' +
      '<div class="card"><div class="card-h"><h3>📈 趨勢判斷</h3></div><table class="tbl trend-tbl"><tbody>' + trendRow('short', '短期') + trendRow('mid', '中期') + trendRow('long', '長期') +
      '</tbody></table><div class="small muted mt-s">ADX（趨勢強度，25 以上代表趨勢明確）<b class="num">' + (isNum(tr.adx) ? fmtNum(tr.adx, 1) : '—') + '</b>・強度「' + esc(tr.strength || '—') +
      '」<br>價格結構：' + esc(tr.structure || '—') + '</div></div>' +
      '<div class="card"><div class="card-h"><h3>🎯 操作參考</h3><span class="sub">非投資建議</span></div>' + planHtml(a) + '</div>' +
      '<div class="card span2"><div class="card-h"><h3>🧱 支撐與壓力</h3><span class="sub">由上而下依價位排列</span></div>' + levelsTable(a) + '</div>' +
      '<div class="card"><div class="card-h"><h3>🔺 型態辨識</h3></div>' + patternsHtml(a) + '</div>' +
      '<div class="card span2"><div class="card-h"><h3>📊 K 線與指標訊號</h3><span class="sub">紅＝偏多、綠＝偏空</span></div>' + signalsHtml(a) + '</div>' +
      '<div class="card"><div class="card-h"><h3>🔊 量價關係</h3></div><div class="row wrap"><span class="chip lg ' + volCls + '">' + esc(v.state || '—') + '</span>' +
      '<span class="small muted">OBV ' + esc(v.obv_trend || '—') + '</span></div><div class="kv-grid mt-s" style="grid-template-columns:1fr">' +
      '<div><span>5 日均量 ÷ 20 日均量</span><span>' + (isNum(v.ratio5_20) ? fmtNum(v.ratio5_20, 2) + ' 倍' : '—') + '</span></div>' +
      '<div><span>今日量 ÷ 20 日均量</span><span>' + (isNum(v.today_vs_ma20) ? fmtNum(v.today_vs_ma20, 2) + ' 倍' : '—') + '</span></div></div>' +
      (v.desc ? '<p class="small mt-s" style="line-height:1.7">' + esc(v.desc) + '</p>' : '') +
      '<div class="card-h mt"><h3>⚠️ 風險提示</h3></div>' + ((a.risks || []).length ? '<ul class="risk-list">' + a.risks.map(function (r) { return '<li>' + esc(r) + '</li>'; }).join('') + '</ul>' : '<div class="small muted">無明顯技術面風險。</div>') +
      '</div></div>' +
      (narr ? '<div class="sec-title"><h2>📖 白話完整解說</h2><span class="sub">每個專有名詞第一次出現時都附有括號說明</span></div><div class="narr">' + narr + '</div>' : '') +
      '</section>');
  }
  function toggleMarks() {
    S.prefs.marks = !S.prefs.marks;
    savePrefs();
    if (S.kc) S.kc.showAnnotations(S.prefs.marks);
    $$('[data-act="marks"]', S.el).forEach(function (b) { b.textContent = S.prefs.marks ? '🙈 隱藏圖上標記' : '👁 顯示圖上標記'; });
    toast(S.prefs.marks ? '已顯示圖上標記' : '已隱藏圖上標記');
  }
  function closeAna() {
    S.ana = null;
    if (S.kc) S.kc.setAnnotations(null);
    renderAnaStrip();
    renderAnaPanel();
    renderToolbar();
  }

  // ------------------------------------------------------------------ tabs
  function tabVisible(id) {
    var d = S.data;
    if (!d) return true;
    if (d.type === 'ETF' && (id === 'revenue' || id === 'eps') && !(d[id === 'revenue' ? 'revenue' : 'eps'] || []).length) return false;
    return true;
  }
  function tabsHtml() {
    return TABS.filter(function (t) { return tabVisible(t[0]); }).map(function (t) {
      return '<button type="button" role="tab" class="' + (t[0] === S.tab ? 'on' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>';
    }).join('');
  }
  function tabBodyWidth() {
    var b = document.getElementById('tabBody');
    return b ? Math.max(300, b.clientWidth - 32) : 800;
  }
  function showTab(id, force) {
    if (!force && id === S.tab) return;
    S.tab = id;
    $$('#stTabs button', S.el).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === id); });
    var body = document.getElementById('tabBody');
    if (!body) return;
    var html;
    try { html = TAB_RENDER[id] ? TAB_RENDER[id](S.data) : ''; } catch (e) { console.error(e); html = errorHtml(e.message, false); }
    setHtml(body, html);
    if (id === 'news' && !S.news && !S.newsErr) loadNews();
    syncUrl();
  }
  function kv(label, val) { return '<div><span>' + label + '</span><span>' + (val === null || val === undefined || val === '' ? '—' : val) + '</span></div>'; }
  function valCard(label, val, sub) {
    return '<div class="val-card"><div class="l">' + label + '</div><div class="v">' + val + '</div>' + (sub ? '<div class="s">' + sub + '</div>' : '') + '</div>';
  }
  function legend(items) {
    return '<div class="legend-row">' + items.map(function (x) { return '<span><i class="' + (x[2] ? 'ln' : '') + '" style="background:' + x[1] + '"></i>' + x[0] + '</span>'; }).join('') + '</div>';
  }
  var TAB_RENDER = {
    profile: function (d) {
      var p = d.profile || {}, v = d.valuation || {}, m = d.margins, sc = d.score, q = d.quote || {};
      var uni = App.uniCached(), row = uni && uni.by[d.code];
      var mcap = row && isNum(row.mcap) ? row.mcap : (isNum(p.shares) && isNum(q.close) ? p.shares * q.close / 10 : null);
      var web = p.website ? '<a href="' + esc(/^https?:/.test(p.website) ? p.website : 'https://' + p.website) + '" target="_blank" rel="noopener noreferrer">' + esc(p.website.replace(/^https?:\/\//, '')) + '</a>' : null;
      var peSub = isNum(v.pe_industry_median) ? '產業中位數 ' + fmtNum(v.pe_industry_median, 1) + (isNum(v.pe) ? (v.pe < v.pe_industry_median ? '・相對便宜' : '・高於同業') : '') : '';
      var cards = [];
      if (d.type !== 'ETF' || isNum(v.pe)) cards.push(valCard('本益比 PE', isNum(v.pe) ? fmtNum(v.pe, 1) + '<small style="font-size:12px"> 倍</small>' : '—', peSub));
      if (d.type !== 'ETF' || isNum(v.pb)) cards.push(valCard('股價淨值比 PB', isNum(v.pb) ? fmtNum(v.pb, 2) + '<small style="font-size:12px"> 倍</small>' : '—', '股價 ÷ 每股淨值'));
      if (d.type !== 'ETF' || isNum(v.yld)) cards.push(valCard('殖利率', isNum(v.yld) ? fmtNum(v.yld, 2) + '%' : '—', '近一年現金股利 ÷ 股價'));
      if (d.type !== 'ETF' || isNum(v.eps_ttm)) cards.push(valCard('EPS（近四季）', isNum(v.eps_ttm) ? fmtNum(v.eps_ttm, 2) + '<small style="font-size:12px"> 元</small>' : '—', '每股盈餘合計'));
      var html = cards.length ? '<div class="subh">💰 評價</div><div class="val-cards">' + cards.join('') + '</div>' : '';
      if (m) {
        html += '<div class="subh">🏭 獲利能力 <span class="chip">' + esc(m.q || '') + '</span></div><div class="val-cards">' +
          valCard('毛利率', isNum(m.gross) ? fmtNum(m.gross, 1) + '%' : '—') + valCard('營業利益率', isNum(m.operating) ? fmtNum(m.operating, 1) + '%' : '—') +
          valCard('稅後淨利率', isNum(m.net) ? fmtNum(m.net, 1) + '%' : '—') + '</div>';
      }
      if (sc) {
        html += '<div class="subh">🧮 綜合評分 <span class="chip">第 ' + fmtInt(sc.rank) + ' 名</span><span class="small muted" style="font-weight:400">全市場百分位，越高越好</span></div>' +
          '<div class="score-card card" style="box-shadow:none">' + scoreRing(sc.score, 72) + factorBars(sc.factors) +
          '<div><ul class="reasons">' + (sc.reasons || []).map(function (r) { return '<li>' + esc(r) + '</li>'; }).join('') + '</ul>' +
          ((sc.risks || []).length ? '<div class="chips mt-s">' + sc.risks.map(function (r) { return '<span class="chip warn">⚠ ' + esc(r) + '</span>'; }).join('') + '</div>' : '') + '</div></div>';
      } else if (d.type === '股票') {
        html += '<div class="subh">🧮 綜合評分</div><div class="small muted">此股票未符合評分條件（例如成交量過低、股價低於 10 元、資料不足或為處置／注意股），因此沒有綜合分數。</div>';
      }
      html += '<div class="subh">🏢 公司資料</div><div class="kv-grid">' +
        kv('公司全名', esc(p.full_name)) + kv('董事長', esc(p.chairman)) + kv('總經理', esc((p.gm || '').replace(/:\s*/, '：'))) +
        kv('成立日期', esc(p.founded)) + kv(d.market === '上櫃' ? '上櫃日期' : '上市日期', esc(p.listed)) +
        kv('實收資本額', isNum(p.capital) ? fmtYi(p.capital) + ' 億元' : null) + kv('已發行股數', isNum(p.shares) ? fmtNum(p.shares, 1) + ' 萬張' : null) +
        kv('市值', isNum(mcap) ? fmtYi(mcap) + ' 億元' : null) + kv('發言人', esc(p.spokesman)) + kv('簽證會計師', esc(p.auditor)) +
        kv('電話', esc(p.phone)) + kv('網站', web) + kv('地址', esc(p.address)) + '</div>';
      return html;
    },
    revenue: function (d) {
      var rows = (d.revenue || []).slice(-36);
      if (!rows.length) return '<div class="empty">尚無月營收資料</div>';
      var last = rows[rows.length - 1];
      var chart = svgBarLine({w: tabBodyWidth(), h: 240, labels: rows.map(function (r) { return r.ym; }),
        bars: rows.map(function (r) { return isNum(r.rev) ? r.rev / 1e5 : null; }),
        barColor: function (i) { var y = rows[i].yoy; return isNum(y) && y < 0 ? '#86efac' : '#93c5fd'; },
        line: rows.map(function (r) { return r.yoy; }), lineColor: '#ea580c', barFmt: function (v) { return fmtYi(v); },
        lineFmt: function (v) { return fmtNum(v, 0) + '%'; }, xLabel: function (i) { var ym = rows[i].ym; return ym.slice(5) === '01' ? ym.slice(0, 4) : ym.slice(5) + '月'; },
        tip: function (i) { var r = rows[i]; return r.ym + '\n營收 ' + fmtYi(r.rev / 1e5) + ' 億\n月增 ' + fmtPct(r.mom, 1) + '\n年增 ' + fmtPct(r.yoy, 1) + '\n累計年增 ' + fmtPct(r.cum_yoy, 1); }});
      return '<div class="val-cards">' + valCard(esc(last.ym) + ' 營收', fmtYi(last.rev / 1e5) + '<small style="font-size:12px"> 億</small>', '單位：億元（原始資料為千元）') +
        valCard('月增率 MoM', '<span class="' + clsUpDown(last.mom) + '">' + fmtPct(last.mom, 1) + '</span>') +
        valCard('年增率 YoY', '<span class="' + clsUpDown(last.yoy) + '">' + fmtPct(last.yoy, 1) + '</span>') +
        valCard('累計年增', '<span class="' + clsUpDown(last.cum_yoy) + '">' + fmtPct(last.cum_yoy, 1) + '</span>', '今年以來') + '</div>' +
        '<div class="subh">近 ' + rows.length + ' 個月營收</div>' + legend([['月營收（億，左軸）', '#93c5fd'], ['年減月份', '#86efac'], ['年增率 %（右軸）', '#ea580c', 1]]) + chart +
        '<div class="tbl-wrap mt"><table class="tbl"><thead><tr><th class="l">月份</th><th>營收（億）</th><th>月增率</th><th>年增率</th><th>累計年增</th></tr></thead><tbody>' +
        rows.slice().reverse().map(function (r) {
          return '<tr><td class="l">' + esc(r.ym) + '</td><td>' + fmtYi(r.rev / 1e5) + '</td><td class="' + clsUpDown(r.mom) + '">' + fmtPct(r.mom, 1) +
            '</td><td class="' + clsUpDown(r.yoy) + '">' + fmtPct(r.yoy, 1) + '</td><td class="' + clsUpDown(r.cum_yoy) + '">' + fmtPct(r.cum_yoy, 1) + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    },
    eps: function (d) {
      var rows = (d.eps || []).slice(-12);
      if (!rows.length) return '<div class="empty">尚無財報資料</div>';
      var ttm = (d.valuation || {}).eps_ttm;
      var chart = svgBarLine({w: tabBodyWidth(), h: 230, labels: rows.map(function (r) { return r.q; }), bars: rows.map(function (r) { return r.eps; }),
        barColor: function (i, v) { return v >= 0 ? '#fca5a5' : '#86efac'; }, barFmt: function (v) { return fmtNum(v, Math.abs(v) >= 10 ? 0 : 1); },
        line: rows.map(function (r) { return isNum(r.ni) && isNum(r.rev) && r.rev ? r.ni / r.rev * 100 : null; }), lineColor: '#2563eb',
        lineFmt: function (v) { return fmtNum(v, 0) + '%'; },
        tip: function (i) { var r = rows[i]; return r.q + '\nEPS ' + fmtNum(r.eps, 2) + ' 元\n營收 ' + fmtYi(r.rev / 1e5) + ' 億\n稅後淨利 ' + fmtYi(r.ni / 1e5) + ' 億'; }});
      return '<div class="val-cards">' + valCard('最新一季 EPS（' + esc(rows[rows.length - 1].q) + '）', fmtNum(rows[rows.length - 1].eps, 2) + '<small style="font-size:12px"> 元</small>') +
        valCard('近四季 EPS', isNum(ttm) ? fmtNum(ttm, 2) + '<small style="font-size:12px"> 元</small>' : '—') + '</div>' +
        '<div class="subh">單季 EPS 與淨利率</div>' + legend([['單季 EPS（元，左軸）', '#fca5a5'], ['稅後淨利率 %（右軸）', '#2563eb', 1]]) + chart +
        '<div class="tbl-wrap mt"><table class="tbl"><thead><tr><th class="l">季度</th><th>EPS（元）</th><th>營收（億）</th><th>營業利益（億）</th><th>稅後淨利（億）</th><th>營益率</th><th>淨利率</th></tr></thead><tbody>' +
        rows.slice().reverse().map(function (r) {
          var om = isNum(r.op) && r.rev ? r.op / r.rev * 100 : null, nm = isNum(r.ni) && r.rev ? r.ni / r.rev * 100 : null;
          return '<tr><td class="l">' + esc(r.q) + '</td><td class="' + clsUpDown(r.eps) + '"><b>' + fmtNum(r.eps, 2) + '</b></td><td>' + fmtYi(isNum(r.rev) ? r.rev / 1e5 : null) +
            '</td><td>' + fmtYi(isNum(r.op) ? r.op / 1e5 : null) + '</td><td>' + fmtYi(isNum(r.ni) ? r.ni / 1e5 : null) + '</td><td>' + (isNum(om) ? fmtNum(om, 1) + '%' : '—') +
            '</td><td>' + (isNum(nm) ? fmtNum(nm, 1) + '%' : '—') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    },
    div: function (d) {
      var rows = (d.dividends || []).slice();
      var v = d.valuation || {};
      if (!rows.length) return '<div class="empty"><div class="big">💵</div>尚無股利資料' + (isNum(v.yld) ? '（目前殖利率 ' + fmtNum(v.yld, 2) + '%）' : '') + '</div>';
      var byYear = {};
      rows.forEach(function (r) {
        var y = r.year || (r.ex_date || '').slice(0, 4);
        var o = byYear[y] || (byYear[y] = {cash: 0, stock: 0, n: 0});
        o.cash += r.cash || 0; o.stock += r.stock || 0; o.n++;
      });
      var years = Object.keys(byYear).sort().slice(-12);
      var last5 = years.slice(-6, -1).filter(function (y) { return byYear[y]; });
      var avg5 = last5.length ? last5.reduce(function (s, y) { return s + byYear[y].cash; }, 0) / last5.length : null;
      var chart = svgBarLine({w: tabBodyWidth(), h: 210, labels: years, bars: years.map(function (y) { return byYear[y].cash + byYear[y].stock; }),
        barColor: function () { return '#fcd34d'; }, barFmt: function (x) { return fmtNum(x, x >= 10 ? 0 : 1); },
        tip: function (i) { var o = byYear[years[i]]; return years[i] + ' 年度\n現金股利 ' + fmtNum(o.cash, 2) + ' 元\n股票股利 ' + fmtNum(o.stock, 2) + ' 元\n共 ' + o.n + ' 次配發'; }});
      var etfBanner = d.type === 'ETF'
        ? '<div class="row wrap" style="margin-bottom:10px;padding:8px 12px;border-radius:10px;background:#f8fafc;border:1px solid #bfdbfe">' +
          '<span class="small">💡 查看此 ETF 的<b>配息頻率、折溢價、歷次填息天數與存股領息試算</b>：</span><span class="sp"></span>' +
          '<a class="btn xs primary" href="#/etf?code=' + encodeURIComponent(d.code) + '">💰 前往 ETF 股利專區明細 →</a></div>'
        : '';
      return etfBanner + '<div class="val-cards">' + valCard('目前殖利率', isNum(v.yld) ? fmtNum(v.yld, 2) + '%' : '—', '近一年現金股利 ÷ 股價') +
        valCard(esc(years[years.length - 1]) + ' 年度合計', fmtNum(byYear[years[years.length - 1]].cash + byYear[years[years.length - 1]].stock, 2) + '<small style="font-size:12px"> 元</small>', '可能尚未配發完畢') +
        valCard('前 5 年平均現金股利', isNum(avg5) ? fmtNum(avg5, 2) + '<small style="font-size:12px"> 元</small>' : '—') + '</div>' +
        '<div class="subh">歷年股利（依所屬年度加總）</div>' + chart +
        '<div class="tbl-wrap mt"><table class="tbl"><thead><tr><th class="l">所屬年度</th><th class="l">期別</th><th>現金股利</th><th>股票股利</th><th class="l">除權息日</th><th class="l">發放日</th></tr></thead><tbody>' +
        rows.slice().reverse().map(function (r) {
          return '<tr><td class="l">' + esc(r.year) + '</td><td class="l">' + esc(r.period || '') + '</td><td>' + fmtNum(r.cash, 2) + '</td><td>' + fmtNum(r.stock, 2) +
            '</td><td class="l">' + esc(r.ex_date || '—') + '</td><td class="l">' + esc(r.pay_date || '—') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    },
    inst: function (d) {
      var rows = d.inst || [];
      if (!rows.length) return '<div class="empty">尚無三大法人資料</div>';
      var idx = {foreign: 1, trust: 2, dealer: 3, total: 4}, names = {foreign: '外資', trust: '投信', dealer: '自營商', total: '三大法人合計'};
      var sum = function (k, n) { return rows.slice(-n).reduce(function (s, r) { return s + (r[idx[k]] || 0); }, 0); };
      var card = function (k) {
        return '<div class="val-card"><div class="l">' + names[k] + '</div><div class="v ' + clsUpDown(sum(k, 5)) + '" style="font-size:17px">' + fmtSigned(sum(k, 5)) + '<small style="font-size:11px"> 張 (5日)</small></div>' +
          '<div class="s">1 日 <span class="' + clsUpDown(sum(k, 1)) + '">' + fmtSigned(sum(k, 1)) + '</span> · 20 日 <span class="' + clsUpDown(sum(k, 20)) + '">' + fmtSigned(sum(k, 20)) + '</span></div></div>';
      };
      var k = S.instMode, i0 = idx[k], recent = rows.slice(-60), cum = 0;
      var cumArr = recent.map(function (r) { cum += r[i0] || 0; return cum; });
      var chart = svgBarLine({w: tabBodyWidth(), h: 230, labels: recent.map(function (r) { return r[0]; }), bars: recent.map(function (r) { return r[i0]; }),
        barColor: function (i, v) { return v >= 0 ? '#f87171' : '#4ade80'; }, line: cumArr, lineColor: '#2563eb',
        barFmt: function (v) { return fmtCompact(v); }, lineFmt: function (v) { return fmtCompact(v); }, xLabel: function (i) { return App.fmtMD(recent[i][0]); },
        tip: function (i) { var r = recent[i]; return r[0] + '\n外資 ' + fmtSigned(r[1]) + '\n投信 ' + fmtSigned(r[2]) + '\n自營 ' + fmtSigned(r[3]) + '\n合計 ' + fmtSigned(r[4]) + '\n區間累計（' + names[k] + '）' + fmtSigned(cumArr[i]); }});
      return '<div class="inst-sum">' + card('foreign') + card('trust') + card('dealer') + card('total') + '</div>' +
        '<div class="row wrap"><div class="subh" style="margin:0">近 ' + recent.length + ' 日買賣超（張）</div><span class="sp"></span><div class="seg">' +
        ['total', 'foreign', 'trust', 'dealer'].map(function (m) { return '<button type="button" class="' + (m === k ? 'on' : '') + '" data-inst="' + m + '">' + names[m].replace('三大法人', '') + '</button>'; }).join('') +
        '</div></div><div class="mt-s">' + legend([['買超', '#f87171'], ['賣超', '#4ade80'], ['區間累計（右軸）', '#2563eb', 1]]) + chart + '</div>' +
        '<div class="tbl-wrap mt"><table class="tbl"><thead><tr><th class="l">日期</th><th>外資</th><th>投信</th><th>自營商</th><th>合計</th></tr></thead><tbody>' +
        rows.slice(-20).reverse().map(function (r) {
          return '<tr><td class="l">' + esc(r[0]) + '</td>' + [1, 2, 3, 4].map(function (j) { return '<td class="' + clsUpDown(r[j]) + '">' + fmtSigned(r[j]) + '</td>'; }).join('') + '</tr>';
        }).join('') + '</tbody></table></div><div class="small muted mt-s">單位：張（1 張 = 1,000 股）。</div>';
    },
    news: function () {
      if (S.newsErr) return errorHtml(S.newsErr, false) + '<div class="row mt-s" style="justify-content:center"><button type="button" class="btn sm" data-act="news-retry">重新載入新聞</button></div>';
      if (!S.news) return '<div class="empty">' + loadingHtml('載入新聞中…') + '</div>';
      var items = S.news.items || [];
      if (S.news.static) {
        var q = (S.data ? S.data.name + ' ' + S.data.code : S.code);
        return '<div class="empty"><div class="big">📰</div><h3>GitHub 靜態版不含即時新聞</h3><p>可以直接到 Google 新聞搜尋「' + esc(q) + '」的最新消息。</p>' +
          '<a class="btn sm primary" href="https://news.google.com/search?q=' + encodeURIComponent(q) + '&amp;hl=zh-TW&amp;gl=TW&amp;ceid=TW:zh-Hant" target="_blank" rel="noopener noreferrer">在 Google 新聞查看 →</a></div>';
      }
      if (!items.length) return '<div class="empty">近期沒有相關新聞</div>';
      return '<div class="news-list">' + items.slice(0, 40).map(function (n) {
        return '<div class="news-item"><a href="' + esc(n.link) + '" target="_blank" rel="noopener noreferrer">' + esc(n.title) + '</a><span class="meta"><span>' +
          esc(n.source || '') + '</span><span>' + esc(relTime(n.time)) + '</span></span></div>';
      }).join('') + '</div><div class="small muted mt-s">新聞來源為外部網站，標題與內容版權屬原作者；更新於 ' + esc((S.news.fetched_at || '').replace('T', ' ').slice(0, 16)) + '。</div>';
    },
    peers: function (d) {
      var peers = d.peers || [];
      var uni = App.uniCached(), me = uni && uni.by[d.code], q = d.quote || {};
      var self = {code: d.code, name: d.name, close: q.close, pct: q.pct, pe: (d.valuation || {}).pe, yld: (d.valuation || {}).yld,
        r20: me ? me.r20 : null, score: d.score ? d.score.score : (me ? me.score : null), self: true};
      if (!peers.length) return '<div class="empty">沒有同產業的比較對象</div>';
      return '<div class="tbl-wrap"><table class="tbl"><thead><tr><th class="l">代號</th><th class="l">名稱</th><th>收盤</th><th>漲跌%</th><th>本益比</th><th>殖利率</th><th>20日%</th><th>綜合分數</th></tr></thead><tbody>' +
        [self].concat(peers).map(function (p) {
          return '<tr' + (p.self ? ' class="self"' : ' data-href="#/stock/' + encodeURIComponent(p.code) + '"') + '><td class="l code">' + esc(p.code) + '</td><td class="l nm">' + esc(p.name) +
            (p.self ? ' <span class="chip">本股</span>' : '') + '</td><td>' + fmtPrice(p.close) + '</td><td class="' + clsUpDown(p.pct) + '">' + fmtPct(p.pct) + '</td><td>' +
            fmtNum(p.pe, 1) + '</td><td>' + (isNum(p.yld) ? fmtNum(p.yld, 2) + '%' : '—') + '</td><td class="' + clsUpDown(p.r20) + '">' + fmtPct(p.r20, 1) + '</td><td><b style="color:' +
            App.scoreColor(p.score) + '">' + fmtScore(p.score) + '</b></td></tr>';
        }).join('') + '</tbody></table></div><div class="small muted mt-s">同業依官方產業別「' + esc(d.industry || '') + '」、成交值排序。</div>';
    },
    chain: function (d) {
      var cs = d.chains || [];
      if (!cs.length) {
        return '<div class="empty"><div class="big">🔗</div><h3>尚未對應到產業鏈</h3><p>櫃買中心產業價值鏈平台沒有收錄這檔股票，或資料仍在建立中。</p><a class="btn sm" href="#/industry?tab=chains">瀏覽全部產業鏈</a></div>';
      }
      return '<div class="chain-pos">' + cs.map(function (c) {
        return '<a href="#/industry/' + encodeURIComponent(c.id) + '"><span style="font-size:22px">🔗</span><div class="crumb"><b>' + esc(c.name) + '</b><span class="sep">›</span><span class="chip info">' +
          esc(c.stream) + '</span><span class="sep">›</span><span>' + esc(c.segment) + '</span></div><span class="sp"></span><span class="small muted">看整條產業鏈 →</span></a>';
      }).join('') + '</div><div class="small muted mt-s">資料來源：櫃買中心 產業價值鏈資訊平台。</div>';
    }
  };
  function fmtSigned(v) { return isNum(v) ? (v > 0 ? '+' : '') + fmtInt(v) : '—'; }
  function loadNews() {
    var code = S.code;
    api('/api/stock/' + encodeURIComponent(code) + '/news').then(function (n) {
      if (!S.alive || S.code !== code) return;
      S.news = n;
      if (S.tab === 'news') showTab('news', true);
    }, function (e) {
      if (!S.alive) return;
      S.newsErr = e.message;
      if (S.tab === 'news') showTab('news', true);
    });
  }

  // ------------------------------------------------------------------ events
  function onClick(ev) {
    var t = ev.target, x;
    if ((x = t.closest('[data-tf]'))) { setTf(x.getAttribute('data-tf')); return; }
    if ((x = t.closest('[data-rk]'))) { setRangeKey(x.getAttribute('data-rk')); return; }
    if ((x = t.closest('[data-ma]'))) {
      var k = x.getAttribute('data-ma');
      S.prefs.ma[k] = !S.prefs.ma[k];
      x.classList.toggle('on', S.prefs.ma[k]);
      if (S.kc) S.kc.setMA(k, S.prefs.ma[k]);
      savePrefs();
      return;
    }
    if ((x = t.closest('[data-bb]'))) {
      S.prefs.bb = !S.prefs.bb;
      x.classList.toggle('on', S.prefs.bb);
      if (S.kc) S.kc.setBB(S.prefs.bb);
      savePrefs();
      return;
    }
    if ((x = t.closest('[data-sub]'))) {
      S.prefs.sub = x.getAttribute('data-sub');
      $$('[data-sub]', S.el).forEach(function (b) { b.classList.toggle('on', b === x); });
      if (S.kc) S.kc.setSub(S.prefs.sub);
      savePrefs();
      return;
    }
    if ((x = t.closest('[data-tab]'))) { showTab(x.getAttribute('data-tab')); return; }
    if ((x = t.closest('[data-inst]'))) { S.instMode = x.getAttribute('data-inst'); showTab('inst', true); return; }
    if ((x = t.closest('[data-act]'))) {
      var act = x.getAttribute('data-act');
      if (act === 'analyze') runAnalysis();
      else if (act === 'marks') toggleMarks();
      else if (act === 'close-ana') closeAna();
      else if (act === 'goto-ana') {
        var sec = document.getElementById('anaSec');
        if (sec) window.scrollTo({top: sec.getBoundingClientRect().top + window.scrollY - 70, behavior: 'smooth'});
      } else if (act === 'news-retry') { S.newsErr = null; showTab('news', true); }
    }
  }
  var onResize = App.debounce(function () {
    if (!S.alive || !S.data) return;
    if (S.tab === 'revenue' || S.tab === 'eps' || S.tab === 'div' || S.tab === 'inst') showTab(S.tab, true);
  }, 200);
  window.addEventListener('resize', onResize);

  window.Pages.stock = {
    render: render,
    update: function (params) {
      if (!S.alive || !S.data || String(params.code || '').toUpperCase() !== S.code) return false;
      if (S.data.lite) return true;
      var q = params.query || {}, tf = TF_RANGES[q.tf] ? q.tf : 'D';
      if (tf !== S.tf) setTf(tf);
      var rk = q.range && monthsOfValid(S.tf, q.range) ? q.range : TF_DEFAULT[S.tf];
      if (rk !== S.rk) setRangeKey(rk);
      var tab = q.tab || 'profile';
      if (tab !== S.tab && tabVisible(tab)) showTab(tab);
      return true;
    },
    destroy: function () {
      S.alive = false;
      if (S.kc) { S.kc.destroy(); S.kc = null; }
      if (S.el) S.el.removeEventListener('click', onClick);
    },
    _state: function () { return S; }
  };
})();
