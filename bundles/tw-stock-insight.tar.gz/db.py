"""SQLite storage (WAL, one connection per thread)."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from typing import Any, Iterable, Sequence

import config

_LOCAL = threading.local()
_WRITE_LOCK = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS stocks (
  code TEXT PRIMARY KEY, name TEXT, market TEXT, type TEXT, industry TEXT,
  industry_code TEXT, full_name TEXT, chairman TEXT, gm TEXT, founded TEXT,
  listed TEXT, capital REAL, shares REAL, address TEXT, phone TEXT,
  website TEXT, spokesman TEXT, auditor TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS daily (
  code TEXT, date TEXT, open REAL, high REAL, low REAL, close REAL,
  vol REAL, value REAL, trades INTEGER, chg REAL,
  PRIMARY KEY (code, date)) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS daily_date ON daily(date);
CREATE TABLE IF NOT EXISTS inst (
  code TEXT, date TEXT, foreign_net REAL, trust_net REAL, dealer_net REAL,
  total_net REAL, PRIMARY KEY (code, date)) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS inst_date ON inst(date);
CREATE TABLE IF NOT EXISTS valuation (
  code TEXT, date TEXT, pe REAL, pb REAL, yld REAL,
  PRIMARY KEY (code, date)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS revenue (
  code TEXT, ym TEXT, rev REAL, mom REAL, yoy REAL, cum_rev REAL,
  cum_yoy REAL, PRIMARY KEY (code, ym)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS eps (
  code TEXT, q TEXT, cum_eps REAL, cum_rev REAL, cum_op REAL, cum_ni REAL,
  PRIMARY KEY (code, q)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS margins (
  code TEXT PRIMARY KEY, q TEXT, gross REAL, operating REAL, net REAL);
CREATE TABLE IF NOT EXISTS dividends (
  code TEXT, year TEXT, period TEXT, cash REAL, stock REAL, ex_date TEXT,
  pay_date TEXT, board_date TEXT, PRIMARY KEY (code, year, period)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS exrights (
  code TEXT, date TEXT, kind TEXT, amount REAL, PRIMARY KEY (code, date)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS index_daily (
  name TEXT, date TEXT, close REAL, chg REAL, pct REAL,
  PRIMARY KEY (name, date)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS market (date TEXT PRIMARY KEY, data TEXT);
CREATE TABLE IF NOT EXISTS fetch_log (
  source TEXT, key TEXT, status TEXT, fetched_at REAL,
  PRIMARY KEY (source, key)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS picks (
  date TEXT, rank INTEGER, code TEXT, score REAL, close REAL, data TEXT,
  PRIMARY KEY (date, rank)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS news_cache (code TEXT PRIMARY KEY, fetched_at REAL, data TEXT);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
"""


def connect() -> sqlite3.Connection:
  """Returns this thread's connection (created on first use)."""
  conn = getattr(_LOCAL, 'conn', None)
  if conn is None:
    os.makedirs(config.DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH, timeout=60, check_same_thread=False)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    conn.execute('PRAGMA busy_timeout=60000')
    conn.execute('PRAGMA temp_store=MEMORY')
    _LOCAL.conn = conn
  return conn


def init() -> None:
  with _WRITE_LOCK:
    conn = connect()
    conn.executescript(SCHEMA)
    conn.commit()


def query(sql: str, params: Sequence[Any] = ()) -> list[tuple]:
  return connect().execute(sql, params).fetchall()


def query_one(sql: str, params: Sequence[Any] = ()) -> tuple | None:
  return connect().execute(sql, params).fetchone()


def execute(sql: str, params: Sequence[Any] = ()) -> None:
  with _WRITE_LOCK:
    conn = connect()
    conn.execute(sql, params)
    conn.commit()


def upsert_many(table: str, cols: Sequence[str], rows: Iterable[Sequence[Any]]) -> int:
  """INSERT OR REPLACE rows; returns count."""
  rows = list(rows)
  if not rows:
    return 0
  sql = (f'INSERT OR REPLACE INTO {table} ({",".join(cols)}) '
         f'VALUES ({",".join("?" * len(cols))})')
  with _WRITE_LOCK:
    conn = connect()
    conn.executemany(sql, rows)
    conn.commit()
  return len(rows)


def fetched(source: str, key: str) -> str | None:
  row = query_one('SELECT status FROM fetch_log WHERE source=? AND key=?', (source, key))
  return row[0] if row else None


def mark_fetched(source: str, key: str, status: str = 'ok') -> None:
  execute('INSERT OR REPLACE INTO fetch_log VALUES (?,?,?,?)',
          (source, key, status, time.time()))


def get_kv(key: str, default: Any = None) -> Any:
  row = query_one('SELECT value FROM kv WHERE key=?', (key,))
  if not row:
    return default
  try:
    return json.loads(row[0])
  except (TypeError, ValueError):
    return default


def set_kv(key: str, value: Any) -> None:
  execute('INSERT OR REPLACE INTO kv VALUES (?,?)',
          (key, json.dumps(value, ensure_ascii=False)))


def trading_dates(limit: int | None = None) -> list[str]:
  """Market-wide trading dates (dates whose TWSE daily quotes or >=500-stock session exist), ascending.

  Per-stock long histories fetched on demand (FinMind) must not leak into this list.
  """
  f_rows = query("SELECT key FROM fetch_log WHERE source='twse_quotes' AND status='ok'")
  d_rows = query('SELECT date FROM daily GROUP BY date HAVING COUNT(*) > 500')
  dates = sorted({r[0] for r in f_rows} | {r[0] for r in d_rows})
  return dates[-limit:] if limit else dates
