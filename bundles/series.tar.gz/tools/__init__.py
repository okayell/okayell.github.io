"""Tools package for Streaming & Series Academy."""
