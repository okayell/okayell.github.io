#!/usr/bin/env python3
"""每週自動抓取七大串流平台（Netflix、HBO／Max、Disney+、myVideo、愛奇藝、騰訊視頻、優酷）線上熱播真人影集。

設計原則（遵循 academy-data-sync）：
  1. 只收真人戲劇／影集（排除電影、動畫／動漫、綜藝／真人秀、紀錄片、體育、兒童卡通與未開播預約片）。
  2. 地區統一歸入 7 類：cn 陸劇、kr 韓劇、tw 台劇、jp 日劇、us 美劇、uk 英劇、world 歐陸與其他。
  3. 同一部影集若同時在多個平台熱播，自動合併 platforms 陣列（不重複出卡、各平台篩選皆可找到）。
  4. 零外部套件相依（內建 OpenCC 級繁化 tools/s2tw.py），本機排程與 GitHub Actions 皆可直接執行。
  5. 具備單一平台斷線補齊與總量防呆（GUARD: 低於門檻時保留上一版好資料）。
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import hashlib
import html as html_lib
import json
import os
import re
import sys
import urllib.parse
import urllib.request

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

from tools import s2tw  # noqa: E402

DATA_DIR = os.path.join(ROOT_DIR, 'data')
CONTENT_DIR = os.path.join(ROOT_DIR, 'static', 'js', 'content')
NOW_STREAMING_JSON = os.path.join(DATA_DIR, 'now_streaming.json')
NOW_STREAMING_JS = os.path.join(CONTENT_DIR, 'now_streaming_data.js')

UA = (
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
)

PLATFORM_ORDER = ('netflix', 'hbo', 'disney', 'myvideo', 'iqiyi', 'wetv', 'youku')
PLATFORM_LABELS = {
    'netflix': 'Netflix',
    'hbo': 'HBO／Max',
    'disney': 'Disney+',
    'myvideo': 'myVideo',
    'iqiyi': '愛奇藝',
    'wetv': '騰訊視頻',
    'youku': '優酷 (Youku)',
}

COUNTRY_TO_REGION = {
    'CN': ('cn', '中國大陸'),
    'KR': ('kr', '南韓'),
    'TW': ('tw', '台灣'),
    'JP': ('jp', '日本'),
    'US': ('us', '美國'),
    'GB': ('uk', '英國'),
    'UK': ('uk', '英國'),
    'HK': ('world', '香港'),
    'TH': ('world', '泰國'),
    'DE': ('world', '德國'),
    'FR': ('world', '法國'),
    'ES': ('world', '西班牙'),
    'IT': ('world', '義大利'),
    'DK': ('world', '丹麥'),
    'SE': ('world', '瑞典'),
    'NO': ('world', '挪威'),
    'CA': ('world', '加拿大'),
    'AU': ('world', '澳洲'),
    'IN': ('world', '印度'),
}

JW_GENRE_MAP = {
    'drm': 'drama',
    'crm': 'crime',
    'trl': 'thriller',
    'cmy': 'comedy',
    'rma': 'romance',
    'scf': 'scifi',
    'fnt': 'scifi',
    'hst': 'history',
    'war': 'history',
    'fml': 'family',
    'hrr': 'horror',
    'act': 'action',
    'wsn': 'action',
}

GENRE_KEYWORDS = (
    ('history', ('古裝', '歷史', '宮廷', '宅鬥', '宮鬥', '朝堂', '權謀', '武俠', '仙俠', '民國', '時代', '王朝', '大河', '古風')),
    ('crime', ('犯罪', '刑偵', '警匪', '緝毒', '檢察官', '黑幫', '命案', '破案', '懸案', '法醫', '罪案', '臥底', '追兇')),
    ('thriller', ('懸疑', '驚悚', '推理', '燒腦', '密室', '謎團', '心理', '失蹤', '復仇', '人性黑暗')),
    ('workplace', ('職場', '職人', '醫療', '醫院', '外科', '律師', '律政', '商戰', '公關', '新聞', '消防', '金融')),
    ('scifi', ('科幻', '奇幻', '穿越', '重生', '超能力', '時間循環', '平行時空', '末日', '太空', '玄幻', '仙魔', '妖')),
    ('romance', ('愛情', '戀愛', '甜寵', '浪漫', '初戀', '暗戀', '先婚後愛', '婚姻', '都市情感', '言情', '深情')),
    ('comedy', ('喜劇', '搞笑', '爆笑', '輕鬆', '荒謬', '歡喜冤家', '幽默', '情境喜劇')),
    ('family', ('家庭', '親情', '成長', '倫理', '父母', '婚姻生活', '療癒日常', '鄰里')),
    ('youth', ('青春', '校園', '高中', '大學', '熱血青春', '少男少女')),
    ('horror', ('恐怖', '靈異', '鬼', '喪屍', '活屍', '驚嚇', '怪談', '邪教')),
    ('action', ('動作', '冒險', '特務', '諜報', '槍戰', '格鬥', '救援', '戰爭')),
)

# 嚴格排除非真人影集（動畫／動漫、綜藝／真人秀、紀錄片、演唱會、兒童卡通、未開播預告）
NON_DRAMA_TITLE_RE = re.compile(
    r'(動畫版|動漫|番劇|劇場版|演唱會|音樂會|頒獎典禮|脫口秀|實境秀|真人秀|戀愛綜藝|'
    r'汪汪隊|佩佩豬|粉紅豬小妹|巧虎|寶寶巴士|哆啦A夢|名偵探柯南|蠟筆小新|寶可夢|海賊王|航海王|'
    r'火影忍者|咒術迴戰|鬼滅之刃|進擊的巨人|間諜家家酒|排球少年|葬送的芙莉蓮|膽大黨|'
    r'鬥破蒼穹|斗羅大陸|仙逆|吞噬星空|完美世界|凡人修仙傳|遮天|神印王座|一念永恆|斬神|'
    r'武神主宰|煉氣十萬年|劍來|牧神記|眷思量|畫江湖|狐妖小紅娘動畫|一人之下動畫|'
    r'Running\s*Man|綜藝玩很大|飢餓遊戲|天才衝衝衝|小姐不熙娣|全員加速中|奔跑吧|你好星期六|'
    r'乘風破浪|披荊斬棘|歌手202|現在就出發|密室大逃脫|大偵探第|心動的信號|再見愛人|'
    r'半熟戀人|偏愛之戀|喜人奇妙夜|一年一度喜劇大賽|種地吧|花兒與少年|五十公里桃花塢|'
    r'podcast|播客|rotten\s*files|[（(](?:日語|韓語|英語|泰語|印尼語|越南語|西語|葡語|阿拉伯語)(?:版|配音)[^）)]*[）)])',
    re.I,
)
PROMO_SLOGAN_RE = re.compile(
    r'^(一鍵直通|會員專享|限時免費|精彩搶先看|預告花絮|高能名場面|獨家花絮)|佔坑|篩選|更多劇集|查看全部|片庫首頁',
)
NON_DRAMA_TAG_SET = {
    '動漫', '動畫', '少兒', '兒童', '卡通', '番劇', '國漫', '日漫',
    '綜藝', '真人秀', '實境秀', '脫口秀', '晚會', '選秀', '戀綜',
    '紀錄片', '紀實', '體育', '運動', '演唱會', '音樂會', '電影', '微電影', '網路大電影',
}

REGION_STYLE = {
    'cn': '融合華語長篇敘事的群像張力、精緻服化美術與高密度情節鉤子',
    'kr': '具備韓劇成熟的高概念類型劇本、快節奏轉折與強烈情緒渲染力',
    'tw': '貼近台灣在地生活肌理與社會議題共鳴，人物情感寫實細膩',
    'jp': '延續日劇精煉不拖泥帶水的篇幅控制、職人細節與溫暖生活哲思',
    'us': '展現美劇成熟的節目統籌（Showrunner）工業規格與長線人物弧線',
    'uk': '承襲英劇短小精悍的作者敘事傳統，對白冷冽機鋒且結構緊密',
    'world': '帶來跨文化視角與非典型類型切角，展現國際串流合製的多元魅力',
}
GENRE_CRAFT = {
    'history': '服裝禮制、場景調度與權謀對白層次分明，將時代氛圍與人物命運緊密交織。',
    'crime': '案件線索鋪陳嚴密，冷峻攝影色調搭配多線交叉敘事，步步逼近人性灰色地帶。',
    'thriller': '善用視角資訊差與每集結尾懸念鉤子，氣氛緊繃且伏筆回收俐落。',
    'workplace': '專業領域細節考究，將職場博弈與理想掙扎拍出強烈的臨場代入感。',
    'scifi': '高概念世界觀設定清晰，特效視覺服務於人物情感與核心哲學提問。',
    'romance': '眼神對手戲與情感推拉細膩自然，在甜蜜互動與現實考驗間取得平衡。',
    'comedy': '喜劇節奏輕快討喜、角色反差鮮明，非常適合作為日常放鬆的配飯首選。',
    'family': '從餐桌日常與代際摩擦切入，不灑廉價狗血卻能自然觸動內心柔軟處。',
    'youth': '清新明快的鏡頭語言捕捉成長陣痛與純粹情誼，青春氣息飽滿。',
    'horror': '以環境音場留白與心理壓迫感取代單純突發驚嚇，懸疑餘韻綿長。',
    'action': '動作場面調度俐落、節奏推進毫不拖沓，兼顧視覺爽感與戲劇張力。',
    'drama': '人物動機鋪陳扎實、群戲對手戲火花十足，隨集數推進越嚼越有味道。',
}


def now_taipei() -> datetime:
  return datetime.now(timezone(timedelta(hours=8)))


def _http_get(url: str, timeout: int = 9, data: bytes | None = None, headers: dict | None = None) -> str:
  hdrs = {
      'User-Agent': UA,
      'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.8',
  }
  if headers:
    hdrs.update(headers)
  req = urllib.request.Request(url, data=data, headers=hdrs)
  with urllib.request.urlopen(req, timeout=timeout) as resp:
    raw = resp.read(2_500_000)
  return raw.decode('utf-8', errors='ignore')


def _https(u: str | None) -> str:
  s = str(u or '').strip().rstrip('\\')
  if s.startswith('//'):
    return 'https:' + s
  if s.startswith('http://'):
    return 'https://' + s[7:]
  return s if s.startswith('https://') else ''


def _norm_title_key(title: str) -> str:
  """Canonical key for cross-platform deduplication of the same show."""
  t = s2tw.to_tw(title).lower()
  t = re.sub(r'[\s\u3000·・:：\-—－_～~！!？?《》「」『』()（）\[\]【】,.，。\'\"’]+', '', t)
  return t


def _clean_title(raw: str) -> str:
  t = html_lib.unescape(s2tw.to_tw(raw)).strip()
  t = re.sub(r'\s*(線上看|高清.*|在線觀看.*|免費線上看.*|\|.*|- MyVideo.*)$', '', t, flags=re.I)
  t = re.sub(r'\s*繁體版.*$', '', t)
  t = re.sub(r'^《(.+)》$', r'\1', t)
  return t.strip()


def _clean_synopsis(raw: str) -> str:
  s = html_lib.unescape(s2tw.to_tw(raw)).strip()
  s = re.sub(r'<[^>]+>', ' ', s)
  s = re.sub(r'\s*\|\s*藍光畫質.*$', '', s)
  s = re.sub(r'^[^_]{1,25}線上看_[^_]{1,20}_', '', s)
  s = re.sub(r'-MyVideo\s*$', '', s)
  s = re.sub(r'\s+', ' ', s).strip()
  return s


def _infer_genres(text: str, base: list[str] | None = None) -> list[str]:
  out: list[str] = []
  for g in base or []:
    if g and g not in out:
      out.append(g)
  for gid, kws in GENRE_KEYWORDS:
    if len(out) >= 3:
      break
    if any(kw in text for kw in kws) and gid not in out:
      out.append(gid)
  if not out:
    out.append('drama')
  return out[:3]


def _is_non_drama(title: str, tags: list[str], synopsis: str = '') -> bool:
  if not title or len(title) > 36:
    return True
  if PROMO_SLOGAN_RE.search(title) or NON_DRAMA_TITLE_RE.search(title):
    return True
  for tg in tags:
    t_tw = s2tw.to_tw(str(tg)).strip()
    if t_tw in NON_DRAMA_TAG_SET or any(bad in t_tw for bad in ('動漫', '動畫', '綜藝', '真人秀', '實境', '紀錄', '少兒', '卡通')):
      return True
  if re.search(r'(是一部.*動畫|改編自同名動漫番劇|大型.*真人秀綜藝|戀愛社交推理真人秀|親自主持.*深入討論作品)', synopsis):
    return True
  return False


def _stable_id(title: str, year: int) -> str:
  key = _norm_title_key(title)
  h = hashlib.sha1(f'{key}:{year or 0}'.encode('utf-8')).hexdigest()[:10]
  return f'now-{h}'


def _load_curated_lookup() -> dict[str, dict]:
  """Lightweight regex reader for static/js/content/series_*.js (no Node needed in CI)."""
  lookup: dict[str, dict] = {}
  if not os.path.isdir(CONTENT_DIR):
    return lookup
  push_re = re.compile(r'window\.SER_SERIES\.push\(\{([\s\S]*?)\n\}\);')
  str_field = lambda k, body: (re.search(rf'\b{k}\s*:\s*\'([^\']*)\'', body) or [None, ''])[1]
  int_field = lambda k, body: int((re.search(rf'\b{k}\s*:\s*(\d+)', body) or [None, '0'])[1])
  for fn in sorted(os.listdir(CONTENT_DIR)):
    if not (fn.startswith('series_') and fn.endswith('.js')):
      continue
    try:
      txt = open(os.path.join(CONTENT_DIR, fn), encoding='utf-8').read()
    except OSError:
      continue
    for m in push_re.finditer(txt):
      b = m.group(1)
      cid = str_field('id', b)
      title = str_field('title', b)
      orig = str_field('origTitle', b)
      yr = int_field('startYear', b)
      if not cid or not title:
        continue
      info = {'id': cid, 'title': title, 'origTitle': orig, 'year': yr}
      lookup[_norm_title_key(title)] = info
      if orig:
        lookup[_norm_title_key(orig)] = info
  return lookup


# ------------------------------------------------------------------ 1) JustWatch TW (Netflix / HBO Max / Disney+ / iQIYI)
JW_QUERY = """
query GetPopularTitles($country: Country!, $language: Language!, $first: Int!, $after: String, $popularTitlesFilter: TitleFilter, $popularTitlesSortBy: PopularTitlesSorting!) {
  popularTitles(country: $country, filter: $popularTitlesFilter, first: $first, after: $after, sortBy: $popularTitlesSortBy) {
    pageInfo { hasNextPage endCursor }
    edges {
      node {
        objectId
        content(country: $country, language: $language) {
          title
          originalReleaseYear
          shortDescription
          productionCountries
          genres { shortName }
          posterUrl
          scoring { imdbScore tmdbScore }
          credits { role name }
        }
        enContent: content(country: "US", language: "en") {
          title
        }
        ... on Show { totalSeasonCount }
      }
    }
  }
}
"""


def fetch_justwatch_package(pkg_short: str, plat_id: str, max_pages: int = 2) -> list[dict]:
  out: list[dict] = []
  after: str | None = None
  for _ in range(max_pages):
    variables: dict = {
        'country': 'TW',
        'language': 'zh',
        'first': 90,
        'popularTitlesSortBy': 'POPULAR',
        'popularTitlesFilter': {
            'objectTypes': ['SHOW'],
            'packages': [pkg_short],
            'monetizationTypes': ['FLATRATE', 'FREE', 'ADS'],
            'excludeGenres': ['ani', 'rly', 'doc', 'spt'],
        },
    }
    if after:
      variables['after'] = after
    payload = json.dumps({'operationName': 'GetPopularTitles', 'variables': variables, 'query': JW_QUERY}).encode('utf-8')
    raw = _http_get('https://apis.justwatch.com/graphql', timeout=12, data=payload, headers={'Content-Type': 'application/json'})
    data = json.loads(raw)
    pt = ((data.get('data') or {}).get('popularTitles')) or {}
    edges = pt.get('edges') or []
    for idx, edge in enumerate(edges):
      node = edge.get('node') or {}
      c = node.get('content') or {}
      en_c = node.get('enContent') or {}
      title = _clean_title(c.get('title') or '')
      syn = _clean_synopsis(c.get('shortDescription') or '')
      g_shorts = [g.get('shortName') for g in (c.get('genres') or []) if isinstance(g, dict)]
      if 'ani' in g_shorts or 'rly' in g_shorts or 'doc' in g_shorts or 'spt' in g_shorts:
        continue
      if 'fml' in g_shorts and 'drm' not in g_shorts and 'cmy' not in g_shorts:
        continue
      if _is_non_drama(title, [], syn):
        continue
      countries = c.get('productionCountries') or []
      c0 = str(countries[0]).upper() if countries else 'US'
      region, country_zh = COUNTRY_TO_REGION.get(c0, ('world', '國際合製'))
      # Infer region from Chinese title/synopsis if country missing
      if not countries and re.search(r'[\u4e00-\u9fff]', title):
        region, country_zh = ('cn', '中國大陸')
      poster_tpl = str(c.get('posterUrl') or '')
      poster = f"https://images.justwatch.com{poster_tpl.replace('{profile}', 's332').replace('{format}', 'jpg')}" if poster_tpl else ''
      poster_hi = f"https://images.justwatch.com{poster_tpl.replace('{profile}', 's592').replace('{format}', 'jpg')}" if poster_tpl else poster
      scoring = c.get('scoring') or {}
      sc = scoring.get('imdbScore') or scoring.get('tmdbScore') or 7.8
      rating = round(max(6.8, min(9.6, float(sc))), 1)
      seasons_cnt = max(1, int(node.get('totalSeasonCount') or 1))
      yr = int(c.get('originalReleaseYear') or now_taipei().year)
      credits = c.get('credits') or []
      cast = []
      directors = []
      for cr in credits:
        nm = s2tw.to_tw(str(cr.get('name') or '').strip())
        if not nm:
          continue
        if cr.get('role') == 'ACTOR' and nm not in cast and len(cast) < 4:
          cast.append(nm)
        elif cr.get('role') == 'DIRECTOR' and nm not in directors and len(directors) < 2:
          directors.append(nm)
      base_genres = [JW_GENRE_MAP[g] for g in g_shorts if g in JW_GENRE_MAP]
      genres = _infer_genres(title + ' ' + syn, base_genres)
      en_title = str(en_c.get('title') or '').strip()
      if len(syn) < 22:
        syn = f'《{title}》為目前於 {PLATFORM_LABELS[plat_id]} 台灣站熱播的{country_zh}真人影集（共 {seasons_cnt} 季），融合{"、".join(genres[:2])}題材魅力。'
      out.append({
          'title': title,
          'origTitle': en_title if en_title and en_title != title else '',
          'region': region,
          'country': country_zh,
          'year': yr,
          'seasonsCount': seasons_cnt,
          'episodes': 0,
          'statusBadge': f'共 {seasons_cnt} 季' if seasons_cnt > 1 else '全季熱播',
          'rating': rating,
          'genres': genres,
          'cast': cast,
          'creator': '、'.join(directors),
          'creatorRole': '導演' if directors else '主創',
          'poster': poster,
          'posterHi': poster_hi,
          'synopsis': syn,
          'platform': plat_id,
          'rankOrder': len(out) + idx,
      })
    pinfo = pt.get('pageInfo') or {}
    if not pinfo.get('hasNextPage') or not pinfo.get('endCursor'):
      break
    after = pinfo['endCursor']
  return out


# ------------------------------------------------------------------ 2) myVideo 台灣大哥大戲劇館
def _parse_myvideo_detail(path: str) -> dict | None:
  url = 'https://www.myvideo.net.tw' + path
  try:
    html = _http_get(url, timeout=9)
  except Exception:
    return None
  og = dict(re.findall(r'<meta[^>]+property=["\']og:([^"\']+)["\'][^>]+content=["\']([^"\']+)["\']', html))
  raw_title = og.get('title') or ''
  if not raw_title:
    return None
  # Example og:title: "獨一無二的浪漫 線上看-韓劇-戲劇-MyVideo"
  region, country_zh = 'tw', '台灣'
  for kw, (rg, cz) in (
      ('陸劇', ('cn', '中國大陸')),
      ('大陸', ('cn', '中國大陸')),
      ('韓劇', ('kr', '南韓')),
      ('台劇', ('tw', '台灣')),
      ('日劇', ('jp', '日本')),
      ('英劇', ('uk', '英國')),
      ('美劇', ('us', '美國')),
      ('歐美', ('us', '歐美')),
      ('港劇', ('world', '香港')),
      ('泰劇', ('world', '泰國')),
  ):
    if kw in raw_title:
      region, country_zh = rg, cz
      break
  title = _clean_title(raw_title.split('線上看')[0])
  # Remove season suffix like "(第1季)" only for display cleanliness? Keep season info in title if distinct
  ld_blocks = re.findall(r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.S)
  vo = {}
  for blk in ld_blocks:
    try:
      obj = json.loads(blk.strip())
      if isinstance(obj, dict) and obj.get('@type') in ('VideoObject', 'TVSeries'):
        vo = obj
        break
    except Exception:
      continue
  kws = [str(k).strip() for k in (vo.get('keywords') or []) if str(k).strip()]
  if _is_non_drama(title, kws, ''):
    return None
  syn = _clean_synopsis(vo.get('description') or og.get('description') or '')
  if _is_non_drama(title, kws, syn) or len(syn) < 16:
    return None
  poster = _https(vo.get('image') or og.get('image') or '')
  directors = [
      s2tw.to_tw(d.get('name', '').strip())
      for d in (vo.get('director') or [])
      if isinstance(d, dict) and d.get('name')
  ]
  ignore_kw = {'MyVideo｜陪你每一刻', '線上看', '戲劇', '陸劇', '韓劇', '台劇', '日劇', '美劇', '英劇', '歐美劇', '港劇', '泰劇'}
  cast = [s2tw.to_tw(k) for k in kws if k not in ignore_kw and k not in directors and len(k) <= 12][:4]
  yr_m = re.search(r'(20[0-2]\d|19[89]\d)\s*年', html)
  yr = int(yr_m.group(1)) if yr_m else now_taipei().year
  ep_m = re.search(r'(全\s*\d+\s*集|更新至\s*\d+\s*集|共\s*\d+\s*集)', html)
  badge = ep_m.group(1).replace(' ', '') if ep_m else '熱播上架'
  genres = _infer_genres(title + ' ' + syn + ' ' + ' '.join(kws))
  return {
      'title': title,
      'origTitle': '',
      'region': region,
      'country': country_zh,
      'year': yr,
      'seasonsCount': 1,
      'episodes': int(re.search(r'\d+', badge).group(0)) if re.search(r'\d+', badge) else 0,
      'statusBadge': badge,
      'rating': 8.1,
      'genres': genres,
      'cast': cast,
      'creator': '、'.join(directors[:2]),
      'creatorRole': '導演' if directors else '主創',
      'poster': poster,
      'posterHi': poster,
      'synopsis': syn,
      'platform': 'myvideo',
  }


def fetch_myvideo() -> list[dict]:
  urls = (
      'https://www.myvideo.net.tw/drama/',
      'https://www.myvideo.net.tw/drama/filter',
      'https://www.myvideo.net.tw/mainGroup/DailyRank/drama/?uxPanelId=202104061018560088',
  )
  seen_paths: list[str] = []
  seen_set: set[str] = set()
  for u in urls:
    try:
      html = _http_get(u, timeout=10)
    except Exception:
      continue
    for p in re.findall(r'/details/3/\d+', html):
      if p not in seen_set:
        seen_set.add(p)
        seen_paths.append(p)
  items: list[dict] = []
  with ThreadPoolExecutor(max_workers=14) as ex:
    for idx, res in enumerate(ex.map(_parse_myvideo_detail, seen_paths)):
      if res:
        res['rankOrder'] = idx
        items.append(res)
  return items


# ------------------------------------------------------------------ 3) 愛奇藝 iQIYI (pcw-api 電視劇頻道 + iq.com 台灣站)
def fetch_iqiyi() -> list[dict]:
  out: list[dict] = []
  # (A) Official drama channel list API (channel_id=2 = 電視劇)
  for page_id in (1, 2):
    u = f'https://pcw-api.iqiyi.com/search/recommend/list?channel_id=2&data_type=1&mode=11&page_id={page_id}&ret_num=48'
    try:
      data = json.loads(_http_get(u, timeout=10))
    except Exception:
      continue
    for it in ((data.get('data') or {}).get('list') or []):
      if not isinstance(it, dict):
        continue
      title = _clean_title(it.get('name') or it.get('title') or '')
      cats = [s2tw.to_tw(str(c)) for c in (it.get('categories') or [])]
      syn = _clean_synopsis(it.get('description') or it.get('focus') or '')
      latest = int(it.get('latestOrder') or 0)
      total_eps = int(it.get('videoCount') or latest or 0)
      if latest <= 0 and total_eps <= 0:
        continue
      if _is_non_drama(title, cats, syn):
        continue
      region, country_zh = 'cn', '中國大陸'
      cat_join = ' '.join(cats)
      for kw, (rg, cz) in (
          ('韓國', ('kr', '南韓')), ('韓劇', ('kr', '南韓')),
          ('台灣', ('tw', '台灣')), ('台劇', ('tw', '台灣')),
          ('日本', ('jp', '日本')), ('日劇', ('jp', '日本')),
          ('美國', ('us', '美國')), ('美劇', ('us', '美國')),
          ('英國', ('uk', '英國')), ('英劇', ('uk', '英國')),
          ('泰國', ('world', '泰國')), ('泰劇', ('world', '泰國')),
          ('香港', ('world', '香港')), ('港劇', ('world', '香港')),
      ):
        if kw in cat_join:
          region, country_zh = rg, cz
          break
      people = it.get('people') or {}
      cast = [
          s2tw.to_tw(p.get('name', '').strip())
          for p in (people.get('main_charactor') or [])
          if isinstance(p, dict) and p.get('name')
      ][:4]
      directors = [
          s2tw.to_tw(p.get('name', '').strip())
          for p in (people.get('director') or [])
          if isinstance(p, dict) and p.get('name')
      ][:2]
      period = str(it.get('period') or '')
      yr_m = re.match(r'(20[0-2]\d|19[89]\d)', period)
      yr = int(yr_m.group(1)) if yr_m else now_taipei().year
      poster = _https(it.get('imageUrl') or '')
      if not poster:
        continue
      raw_sc = it.get('score')
      rating = round(max(7.0, min(9.5, float(raw_sc))), 1) if isinstance(raw_sc, (int, float)) else 8.0
      if total_eps and latest >= total_eps:
        badge = f'全 {total_eps} 集'
      elif latest > 0:
        badge = f'更新至 {latest} 集'
      else:
        badge = '熱播中'
      focus = _clean_synopsis(it.get('focus') or '')
      if len(syn) < 20:
        syn = f'《{title}》為愛奇藝熱播{country_zh}影集（{badge}）' + (f'，{focus}。' if focus else '。')
      out.append({
          'title': title,
          'origTitle': '',
          'region': region,
          'country': country_zh,
          'year': yr,
          'seasonsCount': 1,
          'episodes': total_eps or latest,
          'statusBadge': badge,
          'rating': rating,
          'genres': _infer_genres(title + ' ' + syn + ' ' + cat_join),
          'cast': cast,
          'creator': '、'.join(directors),
          'creatorRole': '導演' if directors else '主創',
          'poster': poster,
          'posterHi': poster,
          'synopsis': syn,
          'tagline': focus if 6 <= len(focus) <= 36 else '',
          'platform': 'iqiyi',
          'rankOrder': len(out),
      })
  # (B) Supplement with JustWatch TW iQIYI catalog
  try:
    for extra in fetch_justwatch_package('iqi', 'iqiyi', max_pages=1):
      extra['rankOrder'] = len(out)
      out.append(extra)
  except Exception:
    pass
  return out


# ------------------------------------------------------------------ 4) 騰訊視頻 WeTV 台灣站（電視劇 10319 + 韓劇 10608）
def _parse_wetv_detail(cid: str) -> dict | None:
  url = f'https://wetv.vip/zh-tw/play/{cid}'
  try:
    html = _http_get(url, timeout=9)
  except Exception:
    return None
  og = dict(re.findall(r'<meta[^>]+property=["\']og:([^"\']+)["\'][^>]+content=["\']([^"\']+)["\']', html))
  ld_blocks = re.findall(r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.S)
  tv_series: dict = {}
  tv_ep: dict = {}
  for blk in ld_blocks:
    try:
      obj = json.loads(blk.strip())
      for node in (obj.get('@graph') or []):
        if isinstance(node, dict):
          if node.get('@type') == 'TVSeries':
            tv_series = node
          elif node.get('@type') == 'TVEpisode':
            tv_ep = node
    except Exception:
      continue
  raw_title = tv_series.get('name') or (og.get('title') or '').split(' - ')[0]
  title = _clean_title(raw_title)
  raw_genres = [s2tw.to_tw(str(g)) for g in (tv_series.get('genre') or tv_ep.get('genre') or [])]
  syn = _clean_synopsis(tv_series.get('description') or og.get('description') or '')
  if _is_non_drama(title, raw_genres, syn) or len(syn) < 16:
    return None
  origin = s2tw.to_tw(str(((tv_ep.get('countryOfOrigin') or {}).get('name')) or ''))
  region, country_zh = 'cn', '中國大陸'
  for kw, (rg, cz) in (
      ('中國大陸', ('cn', '中國大陸')), ('中國', ('cn', '中國大陸')),
      ('韓國', ('kr', '南韓')), ('南韓', ('kr', '南韓')),
      ('台灣', ('tw', '台灣')),
      ('日本', ('jp', '日本')),
      ('美國', ('us', '美國')),
      ('英國', ('uk', '英國')),
      ('泰國', ('world', '泰國')),
  ):
    if kw in origin:
      region, country_zh = rg, cz
      break
  vt_matches = re.findall(rf'https://vcover-vt-pic\.wetvinfo\.com/vcover_vt_pic/0/{re.escape(cid)}[^"\'\\\s]*', html)
  if not vt_matches:
    vt_matches = re.findall(r'https://vcover-vt-pic\.wetvinfo\.com/vcover_vt_pic/[^"\'\\\s]+', html)
  poster = _https(vt_matches[0] if vt_matches else (og.get('image') or ''))
  if not poster:
    return None
  cast = [
      s2tw.to_tw(a.get('name', '').strip())
      for a in (tv_ep.get('actor') or [])
      if isinstance(a, dict) and a.get('name')
  ][:4]
  directors = [
      s2tw.to_tw(d.get('name', '').strip())
      for d in (tv_ep.get('director') or [])
      if isinstance(d, dict) and d.get('name')
  ][:2]
  eps = int(tv_series.get('numberOfEpisodes') or 0)
  yr_m = re.search(r'"datePublished"\s*:\s*"(20[0-2]\d|19[89]\d)', html)
  yr = int(yr_m.group(1)) if yr_m else now_taipei().year
  badge = f'全 {eps} 集' if eps > 0 else '熱播中'
  return {
      'title': title,
      'origTitle': '',
      'region': region,
      'country': country_zh,
      'year': yr,
      'seasonsCount': 1,
      'episodes': eps,
      'statusBadge': badge,
      'rating': 8.2,
      'genres': _infer_genres(title + ' ' + syn + ' ' + ' '.join(raw_genres)),
      'cast': cast,
      'creator': '、'.join(directors),
      'creatorRole': '導演' if directors else '主創',
      'poster': poster,
      'posterHi': poster,
      'synopsis': syn,
      'platform': 'wetv',
  }


def fetch_wetv() -> list[dict]:
  ch_urls = (
      'https://wetv.vip/zh-tw/channel/10319?id=10319&type=PAGE_TYPE_MODULE_LIST',  # 電視劇
      'https://wetv.vip/zh-tw/channel/10608?id=10608&type=PAGE_TYPE_MODULE_LIST',  # 韓劇
  )
  cids: list[str] = []
  seen: set[str] = set()
  for u in ch_urls:
    try:
      html = _http_get(u, timeout=10)
    except Exception:
      continue
    for cid in re.findall(r'/zh-tw/play/([a-z0-9]{12,20})', html):
      if cid not in seen:
        seen.add(cid)
        cids.append(cid)
  items: list[dict] = []
  with ThreadPoolExecutor(max_workers=14) as ex:
    for idx, res in enumerate(ex.map(_parse_wetv_detail, cids[:85])):
      if res:
        res['rankOrder'] = idx
        items.append(res)
  return items


# ------------------------------------------------------------------ 5) 優酷 Youku（youku.tv 繁體國際版 + youku.com 劇集頻道）
def _infer_youku_region(tags_and_text: str) -> tuple[str, str]:
  for kw, (rg, cz) in (
      ('英劇', ('uk', '英國')), ('英國', ('uk', '英國')),
      ('美劇', ('us', '美國')), ('美國', ('us', '美國')),
      ('韓劇', ('kr', '南韓')), ('韓國', ('kr', '南韓')),
      ('日劇', ('jp', '日本')), ('日本', ('jp', '日本')),
      ('台劇', ('tw', '台灣')), ('台灣', ('tw', '台灣')),
      ('泰劇', ('world', '泰國')), ('泰國', ('world', '泰國')), ('名門紳士', ('world', '泰國')),
      ('港劇', ('world', '香港')), ('香港', ('world', '香港')), ('TVB', ('world', '香港')),
  ):
    if kw in tags_and_text:
      return rg, cz
  return 'cn', '中國大陸'


def fetch_youku() -> list[dict]:
  out: list[dict] = []
  seen_sids: set[str] = set()

  # (A) youku.com/ku/webtv — rich JUMP_TO_SHOW cards with real title, plot summary, episode badge & vertical poster
  try:
    html_cn = _http_get('https://www.youku.com/ku/webtv', timeout=12)
    m_cn = re.search(r'window\.__INITIAL_DATA__\s*=\s*(\{.*?\});?\s*</script>', html_cn, re.S)
    if m_cn:
      yd_cn = json.loads(re.sub(r'\bundefined\b', 'null', m_cn.group(1)))
      cards_cn: list[dict] = []

      def _walk_cn(o: object) -> None:
        if isinstance(o, dict):
          if o.get('action_type') == 'JUMP_TO_SHOW' and o.get('title') and not o.get('isYkAd') and not o.get('ad_flag'):
            cards_cn.append(o)
          for v in o.values():
            _walk_cn(v)
        elif isinstance(o, list):
          for x in o:
            _walk_cn(x)

      _walk_cn(yd_cn)
      for c in cards_cn:
        sid = str(c.get('action_value') or '')
        if not sid or sid in seen_sids:
          continue
        lb = s2tw.to_tw(str(c.get('lbTexts') or c.get('updateTips') or '')).strip()
        if any(w in lb for w in ('敬請期待', '預約', '即將')):
          continue
        tag_titles = [
            s2tw.to_tw(str(((t.get('text') or {}).get('title')) or ''))
            for t in (c.get('tags') or [])
            if isinstance(t, dict)
        ]
        cat_extra = s2tw.to_tw(str((((c.get('action') or {}).get('extra') or {}).get('category')) or ''))
        all_tags = [x for x in tag_titles + ([cat_extra] if cat_extra else []) if x]
        title = _clean_title(c.get('title') or '')
        syn = _clean_synopsis(c.get('desc') or '')
        sub = _clean_synopsis(c.get('subtitle') or '')
        if _is_non_drama(title, all_tags, syn):
          continue
        poster = _https(c.get('img') or '')
        if not poster:
          continue
        seen_sids.add(sid)
        ep_m = re.search(r'(\d+)\s*集', lb)
        eps = int(ep_m.group(1)) if ep_m else 0
        badge = lb if lb and len(lb) <= 10 else (f'全 {eps} 集' if eps else '優酷熱播')
        rg, cz = _infer_youku_region(' '.join(all_tags) + ' ' + title + ' ' + sub)
        yr_m = re.search(r'\b(19[89]\d|20[0-2]\d)\b', ' '.join(all_tags) + ' ' + sub + ' ' + syn)
        yr = int(yr_m.group(1)) if yr_m else now_taipei().year
        if len(syn) < 22:
          syn = f'《{title}》為優酷線上熱播{cz}影集（{badge}）' + (f'：{sub}。' if sub else '。')
        out.append({
            'title': title,
            'origTitle': '',
            'region': rg,
            'country': cz,
            'year': yr,
            'seasonsCount': 1,
            'episodes': eps,
            'statusBadge': badge,
            'rating': 8.1,
            'genres': _infer_genres(title + ' ' + syn + ' ' + ' '.join(all_tags)),
            'cast': [],
            'creator': '',
            'creatorRole': '主創',
            'poster': poster,
            'posterHi': poster,
            'synopsis': syn,
            'tagline': sub if 6 <= len(sub) <= 36 else '',
            'platform': 'youku',
            'rankOrder': len(out),
        })
  except Exception:
    pass

  # (B) youku.tv/channel/webtv — international Traditional Chinese edition
  try:
    html_tw = _http_get('https://www.youku.tv/channel/webtv', timeout=12)
    m_tw = re.search(r'window\.__INITIAL_DATA__\s*=\s*(\{.*?\});?\s*</script>', html_tw, re.S)
    if m_tw:
      yd_tw = json.loads(re.sub(r'\bundefined\b', 'null', m_tw.group(1)))
      cards_tw: list[dict] = []

      def _walk_tw(o: object) -> None:
        if isinstance(o, dict):
          if (o.get('vImg') or o.get('img')) and (o.get('sid') or o.get('title')) and not o.get('isAd'):
            cards_tw.append(o)
          for v in o.values():
            _walk_tw(v)
        elif isinstance(o, list):
          for x in o:
            _walk_tw(x)

      _walk_tw(yd_tw)
      for c in cards_tw:
        sid = str(c.get('sid') or '')
        if sid and sid in seen_sids:
          continue
        int_desc = [s2tw.to_tw(str(x)) for x in (c.get('IntDesc') or [])]
        desc_tags = [s2tw.to_tw(str(x)) for x in (c.get('desc') or []) if isinstance(x, str)]
        if int_desc and '影集' not in int_desc and '電視劇' not in (c.get('IntDesc') or []):
          continue
        obj_title = str(((c.get('trackInfo') or {}).get('object_title')) or '')
        real_raw = obj_title.split('繁體版')[0].strip() if '繁體版' in obj_title else (c.get('title') or '')
        title = _clean_title(real_raw)
        sub = _clean_synopsis(c.get('subtitle') or '')
        if _is_non_drama(title, desc_tags + int_desc, sub):
          continue
        poster = _https(c.get('vImg') or c.get('img') or '')
        if not poster:
          continue
        if sid:
          seen_sids.add(sid)
        yr = next((int(x) for x in (c.get('IntDesc') or []) if isinstance(x, int) and 1990 <= x <= 2030), now_taipei().year)
        rg, cz = _infer_youku_region(' '.join(desc_tags + int_desc) + ' ' + title + ' ' + sub)
        syn = f'《{title}》為優酷國際版線上熱播{cz}影集（{yr} 年）' + (f'，{sub}。' if sub else '。')
        out.append({
            'title': title,
            'origTitle': '',
            'region': rg,
            'country': cz,
            'year': yr,
            'seasonsCount': 1,
            'episodes': 0,
            'statusBadge': '優酷熱播',
            'rating': 8.0,
            'genres': _infer_genres(title + ' ' + sub + ' ' + ' '.join(desc_tags)),
            'cast': [],
            'creator': '',
            'creatorRole': '主創',
            'poster': poster,
            'posterHi': poster,
            'synopsis': syn,
            'tagline': sub if 6 <= len(sub) <= 36 else '',
            'platform': 'youku',
            'rankOrder': len(out),
        })
  except Exception:
    pass

  return out


def _enrich_item(item: dict, curated_lookup: dict[str, dict]) -> dict:
  """Builds consistent analysis/guide fields so every #/now card opens cleanly in the modal."""
  tkey = _norm_title_key(item['title'])
  okey = _norm_title_key(item.get('origTitle') or '')
  matched = curated_lookup.get(tkey) or (curated_lookup.get(okey) if okey else None)
  if matched and abs((matched.get('year') or item['year']) - item['year']) <= 3:
    item['catalogId'] = matched['id']
    if matched.get('origTitle') and not item.get('origTitle'):
      item['origTitle'] = matched['origTitle']

  plats = item['platforms']
  plat_names = '、'.join(PLATFORM_LABELS[p] for p in plats if p in PLATFORM_LABELS)
  item['platform'] = plats[0]
  item['network'] = ' · '.join(PLATFORM_LABELS[p] for p in plats[:3] if p in PLATFORM_LABELS)
  g0 = (item.get('genres') or ['drama'])[0]
  craft = GENRE_CRAFT.get(g0, GENRE_CRAFT['drama'])
  rstyle = REGION_STYLE.get(item['region'], REGION_STYLE['world'])

  cast_txt = f"由{'、'.join(item['cast'][:3])}領銜演出，" if item.get('cast') else ''
  ep_txt = f"目前上架規格為「{item.get('statusBadge') or '線上熱播'}」，"
  item['isNowStreaming'] = True
  item['startYear'] = item['year']
  item['endYear'] = item['year']
  item['status'] = 'ongoing' if '更新至' in str(item.get('statusBadge') or '') else 'ended'
  if not item.get('tagline'):
    item['tagline'] = f'{plat_names} 線上熱播・{item["country"]}人氣影集'
  item['analysis'] = {
      'highlights': [
          f'上架平台：{plat_names} 現正線上播出，{ep_txt}可直接排入本週追劇清單。',
          f'看點特色：{cast_txt}{rstyle}。',
          f'類型魅力：{craft}',
      ],
      'structure': craft,
      'arc': f'{rstyle}，角色關係隨劇情推進層層展開。',
      'showrunner': (f"{item.get('creatorRole') or '主創'}：{item['creator']}。" if item.get('creator') else '') + f'目前於 {plat_names} 線上供應。',
  }
  return item


def _merge_platform_lists(per_plat: dict[str, list[dict]], curated_lookup: dict[str, dict]) -> list[dict]:
  merged: dict[str, dict] = {}
  for plat_id in PLATFORM_ORDER:
    for raw in per_plat.get(plat_id) or []:
      key = _norm_title_key(raw['title'])
      if not key:
        continue
      existing = merged.get(key)
      if existing is None:
        rec = dict(raw)
        rec['id'] = _stable_id(raw['title'], raw.get('year') or 0)
        rec['platforms'] = [plat_id]
        rec['posterFallback'] = ''
        merged[key] = rec
      else:
        if plat_id not in existing['platforms']:
          existing['platforms'].append(plat_id)
        # Keep longer/better Traditional Chinese synopsis, cast, origTitle, episodes, backup poster
        if len(raw.get('synopsis') or '') > len(existing.get('synopsis') or '') + 15:
          existing['synopsis'] = raw['synopsis']
        if raw.get('origTitle') and not existing.get('origTitle'):
          existing['origTitle'] = raw['origTitle']
        if len(raw.get('cast') or []) > len(existing.get('cast') or []):
          existing['cast'] = raw['cast']
        if raw.get('creator') and not existing.get('creator'):
          existing['creator'] = raw['creator']
          existing['creatorRole'] = raw.get('creatorRole') or '導演'
        if (raw.get('episodes') or 0) > (existing.get('episodes') or 0):
          existing['episodes'] = raw['episodes']
          existing['statusBadge'] = raw.get('statusBadge') or existing.get('statusBadge')
        if raw.get('poster') and raw['poster'] != existing.get('poster') and not existing.get('posterFallback'):
          existing['posterFallback'] = raw['poster']

  items = [_enrich_item(v, curated_lookup) for v in merged.values()]
  # Sort: multi-platform hits & recent years & higher rating first
  items.sort(
      key=lambda x: (
          len(x.get('platforms') or []) >= 2,
          1 if (x.get('year') or 0) >= now_taipei().year - 1 else 0,
          round(float(x.get('rating') or 7.8), 1),
          -(x.get('rankOrder') or 999),
      ),
      reverse=True,
  )
  # Ensure unique IDs even on hash collision
  seen_ids: set[str] = set()
  for it in items:
    base_id = it['id']
    idx = 2
    while it['id'] in seen_ids:
      it['id'] = f'{base_id}-{idx}'
      idx += 1
    seen_ids.add(it['id'])
    it.pop('rankOrder', None)
  return items


def _load_previous() -> dict:
  if not os.path.isfile(NOW_STREAMING_JSON):
    return {}
  try:
    with open(NOW_STREAMING_JSON, 'r', encoding='utf-8') as f:
      d = json.load(f)
      return d if isinstance(d, dict) else {}
  except Exception:
    return {}


def _write_outputs(payload: dict) -> None:
  os.makedirs(DATA_DIR, exist_ok=True)
  os.makedirs(CONTENT_DIR, exist_ok=True)
  raw_json = json.dumps(payload, ensure_ascii=False, indent=2) + '\n'
  tmp_j = f'{NOW_STREAMING_JSON}.{os.getpid()}.tmp'
  with open(tmp_j, 'w', encoding='utf-8') as f:
    f.write(raw_json)
  os.replace(tmp_j, NOW_STREAMING_JSON)

  compact_json = json.dumps(payload, ensure_ascii=False)
  tmp_js = f'{NOW_STREAMING_JS}.{os.getpid()}.tmp'
  with open(tmp_js, 'w', encoding='utf-8') as f:
    f.write(
        '/* Auto-generated by tools/update_now_streaming.py — 每週自動更新七大串流平台熱播影集 */\n'
        f'window.SER_NOW_STREAMING = {compact_json};\n'
    )
  os.replace(tmp_js, NOW_STREAMING_JS)


def update_now_streaming() -> dict:
  now = now_taipei()
  prev = _load_previous()
  prev_items = prev.get('items') if isinstance(prev.get('items'), list) else []
  curated_lookup = _load_curated_lookup()

  tasks = {
      'netflix': lambda: fetch_justwatch_package('nfx', 'netflix', max_pages=2),
      'hbo': lambda: fetch_justwatch_package('mxx', 'hbo', max_pages=2),
      'disney': lambda: fetch_justwatch_package('dnp', 'disney', max_pages=2),
      'myvideo': fetch_myvideo,
      'iqiyi': fetch_iqiyi,
      'wetv': fetch_wetv,
      'youku': fetch_youku,
  }

  per_plat: dict[str, list[dict]] = {}
  errors: dict[str, str] = {}
  with ThreadPoolExecutor(max_workers=7) as ex:
    futs = {pid: ex.submit(fn) for pid, fn in tasks.items()}
    for pid, fut in futs.items():
      try:
        res = fut.result(timeout=90)
        per_plat[pid] = res or []
      except Exception as e:
        errors[pid] = str(e)[:180]
        per_plat[pid] = []

  # Per-platform fallback: if a single platform returned < 8 items due to transient network error,
  # carry forward that platform's items from previous good snapshot so no platform tab goes empty.
  for pid in PLATFORM_ORDER:
    if len(per_plat.get(pid) or []) < 8 and prev_items:
      recovered = []
      for old in prev_items:
        if pid in (old.get('platforms') or []):
          cp = dict(old)
          cp['platform'] = pid
          cp['rankOrder'] = len(recovered)
          recovered.append(cp)
      if recovered:
        per_plat[pid] = recovered

  items = _merge_platform_lists(per_plat, curated_lookup)
  plat_counts = {
      pid: sum(1 for x in items if pid in (x.get('platforms') or []))
      for pid in PLATFORM_ORDER
  }
  region_counts: dict[str, int] = {}
  for x in items:
    rg = str(x.get('region') or 'world')
    region_counts[rg] = region_counts.get(rg, 0) + 1

  prev_cnt = len(prev_items)
  min_guard = max(120, int(prev_cnt * 0.6)) if prev_cnt else 120
  non_empty_plats = sum(1 for v in plat_counts.values() if v >= 8)
  if len(items) < min_guard or non_empty_plats < 6:
    if prev_items:
      print(f'GUARD: 本次僅抓到 {len(items)} 部（有效平台 {non_empty_plats}/7），低於門檻 {min_guard}，保留上一版 {prev_cnt} 部')
      _write_outputs(prev)
      return prev

  payload = {
      'updatedAt': now.strftime('%Y-%m-%d %H:%M'),
      'weekKey': now.strftime('%G-W%V'),
      'scheduleNote': '每週一自動同步 Netflix、HBO／Max、Disney+、myVideo、愛奇藝、騰訊視頻與優酷線上熱播真人影集（僅收真人戲劇，排除電影、動漫與綜藝）。',
      'count': len(items),
      'platformCounts': plat_counts,
      'regionCounts': region_counts,
      'errors': errors,
      'items': items,
  }
  _write_outputs(payload)
  return payload


if __name__ == '__main__':
  res = update_now_streaming()
  print(
      f"NOW_STREAMING_AT={res.get('updatedAt')} week={res.get('weekKey')} "
      f"count={res.get('count')} platforms={res.get('platformCounts')} regions={res.get('regionCounts')}"
  )
