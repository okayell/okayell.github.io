"""Configuration paths for 串流與影集學院 (Streaming & Series Academy)."""

from __future__ import annotations

import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
NOW_STREAMING_JSON = os.path.join(DATA_DIR, 'now_streaming.json')
DB_PATH = NOW_STREAMING_JSON
