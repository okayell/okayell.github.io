"""Weekly updater entrypoint for Streaming & Series Academy (compatible with ci_update.py & campus_scheduler.py)."""

from __future__ import annotations

import os
import sys

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

from tools import update_now_streaming as _uns  # noqa: E402


def sync_all(full_backfill: bool = False, update_odds: bool = False, odds_stage: str = 'auto') -> dict:
  del full_backfill, update_odds, odds_stage
  payload = _uns.update_now_streaming()
  return {
      'weekKey': payload.get('weekKey'),
      'updatedAt': payload.get('updatedAt'),
      'count': payload.get('count', 0),
      'platformCounts': payload.get('platformCounts', {}),
  }
