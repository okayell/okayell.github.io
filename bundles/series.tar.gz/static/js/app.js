/* 📺 串流與影集學院主路由、事件委派、版本更新紀錄與意見回饋 */
(function () {
  'use strict';
  var SER = window.SER;
  var ROUTES = ['home', 'now', 'explore', 'radar', 'platforms', 'my-list', 'guide', 'feedback'];

  function isEnterSend(ev) {
    return ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing && ev.keyCode !== 229;
  }

  function renderFeedbackPage(root) {
    root.innerHTML =
      '<div style="max-width:640px;margin:0 auto;">' +
        '<div class="ser-sec-hd"><div><h2>💬 意見回饋與許願池</h2><div class="ser-sec-sub">想看哪一部影集的無雷導讀、覺得哪一季的評價不準，或有功能建議，都歡迎告訴我們</div></div></div>' +
        '<form id="serFeedbackForm" class="ser-panel">' +
          '<div style="margin-bottom:12px;">' +
            '<label for="fbCategory" style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">類型</label>' +
            '<select id="fbCategory" class="ser-select">' +
              '<option value="影集許願">📺 許願新增影集</option>' +
              '<option value="資料修正">📝 資料或評價修正</option>' +
              '<option value="功能建議">✨ 功能與介面建議</option>' +
            '</select>' +
          '</div>' +
          '<div style="margin-bottom:12px;">' +
            '<label for="fbTitle" style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">標題</label>' +
            '<input id="fbTitle" class="ser-input" maxlength="80" placeholder="例：想看《某某影集》的分季導讀" />' +
          '</div>' +
          '<div style="margin-bottom:12px;">' +
            '<label for="fbMessage" style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">內容</label>' +
            '<textarea id="fbMessage" class="ser-input" rows="5" maxlength="2000" placeholder="請描述你的建議（請勿透露劇情結局）" required></textarea>' +
          '</div>' +
          '<button type="submit" class="ser-btn ser-btn-primary" id="fbSubmitBtn">📮 送出</button>' +
        '</form>' +
      '</div>';

    var form = document.getElementById('serFeedbackForm');
    var btn = document.getElementById('fbSubmitBtn');
    var titleInput = document.getElementById('fbTitle');
    if (titleInput) {
      titleInput.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' && !isEnterSend(ev)) ev.preventDefault();
      });
    }
    form.onsubmit = function (ev) {
      ev.preventDefault();
      var cat = document.getElementById('fbCategory').value;
      var title = document.getElementById('fbTitle').value.trim();
      var msg = document.getElementById('fbMessage').value.trim();
      if (!msg) return;
      var done = function (text) {
        SER.toast(text);
        form.reset();
        btn.disabled = false;
        btn.textContent = '📮 送出';
      };
      btn.disabled = true;
      btn.textContent = '⏳ 傳送中…';
      if (!SER.isStatic()) {
        fetch(SER.apiBase() + 'feedback', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: cat, title: title, content: msg, page: window.location.hash })
        })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (res && res.ok) done('🎉 感謝回饋，我們收到了！');
            else { btn.disabled = false; btn.textContent = '📮 送出'; SER.toast((res && res.error) || '送出失敗，請稍後再試'); }
          })
          .catch(function () { btn.disabled = false; btn.textContent = '📮 送出'; SER.toast('送出失敗，請稍後再試'); });
      } else if (window.CampusNav && typeof window.CampusNav.openFeedback === 'function') {
        window.CampusNav.openFeedback('series', '[' + cat + '] ' + (title ? title + '：' : '') + msg);
        btn.disabled = false;
        btn.textContent = '📮 送出';
      } else {
        btn.disabled = false;
        btn.textContent = '📮 送出';
        SER.toast('離線版無法送出回饋，請到線上版填寫');
      }
    };
  }

  function openReleaseModal() {
    var rel = window.SER_RELEASES || { current_version: '1.0.0', releases: [] };
    var backdrop = document.getElementById('releaseModal');
    var card = document.getElementById('releaseModalCard');
    if (!backdrop || !card) return;
    var items = (rel.releases || []).map(function (r) {
      var lis = (r.changes || []).map(function (c) { return '<li>' + SER.esc(c) + '</li>'; }).join('');
      return '<div class="ser-block"><h4>v' + SER.esc(r.version) + '｜' + SER.esc(r.title || '') + '　<span class="ser-note">' + SER.esc(r.date || '') + '</span></h4><ol style="list-style:disc;">' + lis + '</ol></div>';
    }).join('');
    card.innerHTML =
      '<button type="button" class="ser-modal-close" id="serRelClose" aria-label="關閉">✕</button>' +
      '<div class="ser-modal-hero" style="background:linear-gradient(135deg,#0c4a6e,#0284c7)"><h2 id="releaseModalTitle">📺 版本更新紀錄</h2></div>' +
      '<div class="ser-modal-body">' + items + '</div>';
    document.getElementById('serRelClose').onclick = function () { backdrop.classList.remove('open'); };
    backdrop.classList.add('open');
  }

  /* 路由：#/home、#/explore…；#/s/<id> 直接打開該影集的導讀 */
  function parseHash() {
    var h = String(window.location.hash || '').replace(/^#\/?/, '').split('?')[0].trim();
    var parts = h.split('/');
    if (parts[0] === 's' && parts[1]) {
      var sid = decodeURIComponent(parts[1]);
      return { route: sid.indexOf('now-') === 0 ? 'now' : 'explore', open: sid };
    }
    return { route: ROUTES.indexOf(parts[0]) !== -1 ? parts[0] : 'home', open: '' };
  }

  SER.refreshCurrentView = function () {
    var route = parseHash().route;
    var root = document.getElementById('appRoot');
    if (!root) return;
    document.querySelectorAll('#mainNav .ser-tab').forEach(function (t) {
      t.classList.toggle('active', t.getAttribute('data-route') === route);
    });
    SER.syncHeaderBadges();
    if (route === 'now') SER.renderNowPage(root);
    else if (route === 'explore') SER.renderExplorePage(root);
    else if (route === 'radar') SER.renderRadarPage(root);
    else if (route === 'platforms') SER.renderPlatformsPage(root);
    else if (route === 'my-list') SER.renderMyListPage(root);
    else if (route === 'guide') SER.renderGuidePage(root);
    else if (route === 'feedback') renderFeedbackPage(root);
    else SER.renderHomePage(root);
  };

  function go(route) {
    if (parseHash().route === route && window.location.hash === '#/' + route) SER.refreshCurrentView();
    else window.location.hash = '#/' + route;
  }

  function init() {
    var rel = window.SER_RELEASES || { current_version: '1.0.0' };
    var vb = document.getElementById('verBadge');
    if (vb) {
      vb.textContent = 'v' + (rel.current_version || '1.0.0');
      vb.onclick = openReleaseModal;
    }
    var dl = document.getElementById('dlOfflineBtn');
    if (dl && !SER.isStatic()) dl.classList.add('show');

    document.querySelectorAll('#mainNav .ser-tab').forEach(function (btn) {
      btn.onclick = function () { go(btn.getAttribute('data-route')); };
    });
    document.querySelectorAll('[data-hdr-tab]').forEach(function (btn) {
      btn.onclick = function () {
        SER.state.myTab = btn.getAttribute('data-hdr-tab');
        go('my-list');
      };
    });

    document.addEventListener('click', function (ev) {
      var t = ev.target;
      if (!t || !t.closest) return;
      var wl = t.closest('[data-toggle-watchlist]');
      if (wl) {
        ev.preventDefault();
        SER.toggleWatchlist(wl.getAttribute('data-toggle-watchlist'));
        SER.refreshCurrentView();
        return;
      }
      var all = t.closest('[data-toggle-all]');
      if (all) {
        ev.preventDefault();
        SER.toggleAllSeasons(all.getAttribute('data-toggle-all'));
        SER.refreshCurrentView();
        return;
      }
      var open = t.closest('[data-open-series]');
      if (open) {
        ev.preventDefault();
        SER.openModal(open.getAttribute('data-open-series'));
        return;
      }
      var goEl = t.closest('[data-go-route]');
      if (goEl) {
        ev.preventDefault();
        go(goEl.getAttribute('data-go-route'));
        return;
      }
      if (t.id === 'seriesModal') SER.closeModal();
      if (t.id === 'releaseModal') t.classList.remove('open');
    });

    document.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Escape') return;
      SER.closeModal();
      var rm = document.getElementById('releaseModal');
      if (rm) rm.classList.remove('open');
    });

    window.addEventListener('hashchange', function () {
      var ph = parseHash();
      window.scrollTo(0, 0);
      SER.closeModal();
      SER.refreshCurrentView();
      if (ph.open) SER.openModal(ph.open);
    });

    SER.resetExplore();
    SER.refreshCurrentView();
    var first = parseHash();
    if (first.open) SER.openModal(first.open);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
