/* 📺 串流與影集學院核心：分類常數、七大平台熱播與經典片庫整合、追劇護照儲存、海報與無雷導讀彈窗 */
(function () {
  'use strict';

  var SER = window.SER = window.SER || {};

  SER.REGIONS = [
    { id: 'cn', label: '🏮 陸劇', short: '陸劇', desc: '古裝權謀、生活懸疑短劇與當代話題陸劇' },
    { id: 'kr', label: '🇰🇷 韓劇', short: '韓劇', desc: '一季完結的高完成度類型劇與催淚人性作' },
    { id: 'tw', label: '🇹🇼 台劇', short: '台劇', desc: '公視社會寫實、時代劇與新世代類型劇' },
    { id: 'jp', label: '🇯🇵 日劇', short: '日劇', desc: '季番職人劇、坂元裕二式對白與懸疑社會派' },
    { id: 'us', label: '🇺🇸 美劇', short: '美劇', desc: '有線台黃金年代、情境喜劇與串流原創鉅作' },
    { id: 'uk', label: '🇬🇧 英劇', short: '英劇', desc: '短小精悍的迷你影集、推理與時代劇' },
    { id: 'world', label: '🌍 歐陸與其他', short: '歐陸', desc: '歐陸、泰、港等跨國話題真人影集' }
  ];

  SER.GENRES = [
    { id: 'drama', label: '🎭 劇情人性', short: '劇情', c1: '#7c2d12', c2: '#c2410c', icon: '🎭' },
    { id: 'crime', label: '🕵️ 犯罪推理', short: '犯罪推理', c1: '#1e293b', c2: '#475569', icon: '🕵️' },
    { id: 'thriller', label: '🧠 懸疑驚悚', short: '懸疑驚悚', c1: '#1e1b4b', c2: '#4338ca', icon: '🧠' },
    { id: 'comedy', label: '😂 喜劇', short: '喜劇', c1: '#b45309', c2: '#eab308', icon: '😂' },
    { id: 'romance', label: '💕 愛情', short: '愛情', c1: '#9d174d', c2: '#f43f5e', icon: '💕' },
    { id: 'scifi', label: '🚀 科幻奇幻', short: '科幻奇幻', c1: '#0f172a', c2: '#0891b2', icon: '🚀' },
    { id: 'workplace', label: '💼 職人職場', short: '職人', c1: '#134e4a', c2: '#0d9488', icon: '💼' },
    { id: 'history', label: '🏯 歷史時代', short: '歷史時代', c1: '#44403c', c2: '#a16207', icon: '🏯' },
    { id: 'family', label: '🏠 家庭成長', short: '家庭', c1: '#365314', c2: '#65a30d', icon: '🏠' },
    { id: 'youth', label: '🎒 青春校園', short: '青春', c1: '#0369a1', c2: '#38bdf8', icon: '🎒' },
    { id: 'horror', label: '👻 恐怖', short: '恐怖', c1: '#18181b', c2: '#991b1b', icon: '👻' },
    { id: 'action', label: '💥 動作冒險', short: '動作', c1: '#7f1d1d', c2: '#ea580c', icon: '💥' }
  ];

  /* 七大串流平台（每週自動同步線上熱播真人影集） */
  SER.STREAMING_PLATFORMS = [
    { id: 'netflix', label: 'Netflix', color: '#dc2626', cls: 'plat-netflix', desc: '台灣站目前上架的所有真人影集（含原創與各國授權熱播劇）' },
    { id: 'hbo', label: 'HBO／Max', color: '#6d28d9', cls: 'plat-hbo', desc: 'HBO 招牌精品劇與 Max 台灣站熱播歐美亞真人影集' },
    { id: 'disney', label: 'Disney+', color: '#1d4ed8', cls: 'plat-disney', desc: 'Star 亞太獨播韓劇日劇、FX／Hulu 影集與漫威星戰真人劇' },
    { id: 'myvideo', label: 'myVideo', color: '#ea580c', cls: 'plat-myvideo', desc: '台灣大哥大戲劇館同步跟播台劇、陸劇、韓劇、日劇與英美劇' },
    { id: 'iqiyi', label: '愛奇藝', color: '#059669', cls: 'plat-iqiyi', desc: '迷霧劇場懸疑短劇、古裝大作與愛奇藝熱播陸劇韓劇' },
    { id: 'wetv', label: '騰訊視頻', color: '#0284c7', cls: 'plat-wetv', desc: 'WeTV／騰訊視頻重磅古裝、X 劇場精品短劇與都市情感劇' },
    { id: 'youku', label: '優酷 (Youku)', color: '#2563eb', cls: 'plat-youku', desc: '白夜劇場懸疑推理、生花劇場古裝言情與優酷熱播劇集' }
  ];

  /* 跨年代經典片庫的首播平台分類 */
  SER.PLATFORMS = [
    { id: 'netflix', label: 'Netflix', color: '#b91c1c', desc: '一次上架整季、最適合一口氣追完的全球串流原創與獨播劇' },
    { id: 'hbo', label: 'HBO／Max', color: '#6d28d9', desc: '週播制精品劇的代名詞，編劇與製作規格的業界標竿' },
    { id: 'disney', label: 'Disney+／Hulu／FX', color: '#1d4ed8', desc: '星戰、漫威宇宙之外，FX 與 Hulu 的作者型劇集同樣精彩' },
    { id: 'iqiyi', label: '愛奇藝', color: '#059669', desc: '迷霧劇場社會派懸疑短劇與高討論度華語原創劇集' },
    { id: 'wetv', label: '騰訊視頻', color: '#0284c7', desc: 'X 劇場精品作者劇、科幻改編與大型古裝權謀代表作' },
    { id: 'youku', label: '優酷 (Youku)', color: '#2563eb', desc: '白夜劇場硬派刑偵、歷史懸疑與高節奏古裝復仇劇' },
    { id: 'myvideo', label: 'myVideo', color: '#ea580c', desc: '共同出品與首播台灣在地職人劇、寫實影集' },
    { id: 'apple', label: 'Apple TV+', color: '#334155', desc: '重質不重量，高預算原創與精緻美術設計' },
    { id: 'prime', label: 'Prime Video', color: '#0e7490', desc: '大製作類型劇與改編作品' },
    { id: 'network', label: '歐美電視網與有線台', color: '#b45309', desc: 'AMC、NBC、BBC、ITV 等傳統電視台的經典與當代名作' },
    { id: 'cn-tv', label: '陸劇衛視與電視台', color: '#991b1b', desc: '東方衛視、北京衛視、湖南衛視與央視首播的國民級經典陸劇' },
    { id: 'kr-tv', label: '韓國電視台', color: '#be185d', desc: 'tvN、JTBC 與三大無線台的週末劇、水木劇' },
    { id: 'jp-tv', label: '日本電視台', color: '#c2410c', desc: 'TBS、富士、日テレ、NHK 的季番連續劇' },
    { id: 'tw-tv', label: '台灣電視台與本土平台', color: '#047857', desc: '公視、台視、華視與本土平台首播的經典台劇' }
  ];

  SER.STATUS = {
    ended: { label: '已完結', cls: 'ok', icon: '✅' },
    ongoing: { label: '製播中', cls: 'live', icon: '📡' },
    limited: { label: '迷你影集', cls: 'ok', icon: '🎞️' }
  };

  SER.PACES = { slow: '🐢 慢熱型', steady: '🚶 穩定推進', fast: '⚡ 快節奏' };

  SER.VERDICTS = [
    { id: 'perfect', label: '🏆 神收尾', cls: 'ok', desc: '結局備受推崇，可以毫無顧慮地投入' },
    { id: 'good', label: '👍 好好收尾', cls: 'ok', desc: '主線有交代、口碑穩定，放心追到最後' },
    { id: 'open', label: '🌫️ 開放式結局', cls: 'warn', desc: '留白讓觀眾自行解讀，喜惡看個人' },
    { id: 'mixed', label: '⚖️ 評價兩極', cls: 'warn', desc: '有人滿意有人失望，建議先看收尾評價再決定' },
    { id: 'letdown', label: '⚠️ 高開低走', cls: 'bad', desc: '後段口碑明顯下滑，入坑前先做好心理準備' },
    { id: 'cancelled', label: '✂️ 遭腰斬未完', cls: 'bad', desc: '故事沒有說完就停播' },
    { id: 'ongoing', label: '📡 尚未完結', cls: 'live', desc: '仍在製播中，收尾成績未定' }
  ];

  SER.LENGTHS = [
    { id: 'weekend', label: '🛋️ 一個週末（12 小時內）', test: function (h) { return h <= 12; } },
    { id: 'fortnight', label: '🗓️ 兩週左右（12–30 小時）', test: function (h) { return h > 12 && h <= 30; } },
    { id: 'season', label: '📚 一兩個月（30–80 小時）', test: function (h) { return h > 30 && h <= 80; } },
    { id: 'epic', label: '🏔️ 長期抗戰（80 小時以上）', test: function (h) { return h > 80; } }
  ];

  function indexBy(list) {
    var m = {};
    list.forEach(function (x) { m[x.id] = x; });
    return m;
  }
  SER.REGION_MAP = indexBy(SER.REGIONS);
  SER.GENRE_MAP = indexBy(SER.GENRES);
  SER.STREAMING_PLATFORM_MAP = indexBy(SER.STREAMING_PLATFORMS);
  SER.PLATFORM_MAP = indexBy(SER.PLATFORMS);
  SER.VERDICT_MAP = indexBy(SER.VERDICTS);
  SER.LENGTH_MAP = indexBy(SER.LENGTHS);

  var KEY_WATCHLIST = 'ser.watchlist.v1';
  var KEY_PROGRESS = 'ser.progress.v1';
  var KEY_SNAPSHOTS = 'ser.snapshots.v1';
  var KEY_QUIZ = 'ser.guide.quiz.v1';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  SER.esc = esc;

  function loadJson(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      if (!raw) return fallback;
      var v = JSON.parse(raw);
      return v && typeof v === 'object' ? v : fallback;
    } catch (e) {
      return fallback;
    }
  }
  function saveJson(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* ignore */ }
  }
  function today() { return new Date().toISOString().slice(0, 10); }

  SER.state = {
    watchlist: loadJson(KEY_WATCHLIST, {}),
    progress: loadJson(KEY_PROGRESS, {}),
    snapshots: loadJson(KEY_SNAPSHOTS, {}),
    quizDone: loadJson(KEY_QUIZ, {}),
    nowFilter: { platform: 'all', region: 'all', genre: 'all', status: 'all', q: '', sort: 'hot', limit: 48 },
    explore: { region: 'all', genre: 'all', platform: 'all', status: 'all', verdict: 'all', length: 'all', mine: 'all', q: '', sort: 'rating', limit: 0 },
    picker: { length: 'all', genre: 'all', region: 'all', safe: true, seed: 0 },
    radarTab: 'trend',
    radarTrend: 'all',
    myTab: 'watching'
  };

  /* ---------- 跨年代經典片庫 & 七大平台熱播 ---------- */
  var catalogCache = null;
  var catalogMap = null;
  var nowCache = null;
  var nowMap = null;

  function normalizeNowItem(raw) {
    if (!raw || !raw.id) return null;
    if (!Array.isArray(raw.seasons) || !raw.seasons.length) {
      var sc = Math.max(1, Number(raw.seasonsCount) || 1);
      var eps = Math.max(1, Number(raw.episodes) || (sc * 10));
      raw.seasons = [{
        n: 1,
        to: sc,
        eps: eps,
        year: Number(raw.year || raw.startYear) || 2026,
        score: Number(raw.rating) || 8.0,
        guide: raw.statusBadge || '線上熱播中'
      }];
      if (!raw.epRuntime) raw.epRuntime = 45;
      if (!raw.episodes) raw.episodes = eps;
      if (!raw.seasonsCount) raw.seasonsCount = sc;
    }
    raw.isNowStreaming = true;
    return raw;
  }

  SER.getCatalog = function () {
    var raw = Array.isArray(window.SER_SERIES) ? window.SER_SERIES : [];
    if (catalogCache && catalogCache._len === raw.length) return catalogCache;
    catalogMap = {};
    var list = raw.filter(function (s) {
      if (!s || !s.id || catalogMap[s.id]) return false;
      catalogMap[s.id] = s;
      return true;
    });
    list._len = raw.length;
    catalogCache = list;
    return list;
  };

  SER.invalidateNowCache = function () {
    nowCache = null;
    nowMap = null;
  };

  SER.getNowStreamingPayload = function () {
    var p = window.SER_NOW_STREAMING;
    return (p && typeof p === 'object') ? p : { updatedAt: '', weekKey: '', count: 0, items: [] };
  };

  SER.getNowStreamingItems = function () {
    var p = SER.getNowStreamingPayload();
    var raw = Array.isArray(p.items) ? p.items : [];
    if (nowCache && nowCache._ref === raw && nowCache._len === raw.length) return nowCache;
    nowMap = {};
    var list = [];
    raw.forEach(function (it) {
      var norm = normalizeNowItem(it);
      if (!norm || nowMap[norm.id]) return;
      nowMap[norm.id] = norm;
      list.push(norm);
    });
    list._ref = raw;
    list._len = raw.length;
    nowCache = list;
    return list;
  };

  SER.find = function (id) {
    SER.getCatalog();
    if (catalogMap && catalogMap[id]) return catalogMap[id];
    SER.getNowStreamingItems();
    if (nowMap && nowMap[id]) return nowMap[id];
    var snap = SER.state.snapshots && SER.state.snapshots[id];
    return snap ? normalizeNowItem(snap) : null;
  };

  /* 回傳經典片庫＋使用者已加入待看或有進度的熱播劇（讓追劇護照跨週更新不遺失紀錄） */
  SER.getTrackedPool = function () {
    var seen = {};
    var out = [];
    SER.getCatalog().forEach(function (s) {
      seen[s.id] = 1;
      out.push(s);
    });
    var extraIds = {};
    Object.keys(SER.state.watchlist || {}).forEach(function (id) { extraIds[id] = 1; });
    Object.keys(SER.state.progress || {}).forEach(function (id) { extraIds[id] = 1; });
    Object.keys(extraIds).forEach(function (id) {
      if (seen[id]) return;
      var s = SER.find(id);
      if (s) {
        seen[id] = 1;
        out.push(s);
      }
    });
    return out;
  };

  function rememberSnapshot(s) {
    if (!s || !s.isNowStreaming) return;
    SER.state.snapshots[s.id] = {
      id: s.id,
      title: s.title,
      origTitle: s.origTitle || '',
      region: s.region,
      country: s.country || '',
      year: s.year || s.startYear || 2026,
      startYear: s.startYear || s.year || 2026,
      endYear: s.endYear || s.year || 2026,
      seasonsCount: s.seasonsCount || 1,
      episodes: s.episodes || 12,
      epRuntime: s.epRuntime || 45,
      status: s.status || 'ended',
      statusBadge: s.statusBadge || '線上熱播',
      rating: s.rating || 8.0,
      genres: s.genres || ['drama'],
      platforms: s.platforms || [s.platform || 'netflix'],
      platform: s.platform || 'netflix',
      network: s.network || '',
      cast: s.cast || [],
      creator: s.creator || '',
      creatorRole: s.creatorRole || '主創',
      poster: s.poster || '',
      posterHi: s.posterHi || s.poster || '',
      posterFallback: s.posterFallback || '',
      tagline: s.tagline || '',
      synopsis: s.synopsis || '',
      analysis: s.analysis || {},
      catalogId: s.catalogId || '',
      isNowStreaming: true
    };
    saveJson(KEY_SNAPSHOTS, SER.state.snapshots);
  }

  function maybeForgetSnapshot(id) {
    if (!SER.state.watchlist[id] && !SER.state.progress[id] && SER.state.snapshots[id]) {
      delete SER.state.snapshots[id];
      saveJson(KEY_SNAPSHOTS, SER.state.snapshots);
    }
  }

  SER.hours = function (s) {
    return Math.round(((s.episodes || 0) * (s.epRuntime || 45)) / 60);
  };

  SER.hoursLabel = function (s) {
    var h = SER.hours(s);
    return h < 1 ? '不到 1 小時' : '約 ' + h + ' 小時';
  };

  SER.yearsLabel = function (s) {
    if (s.isNowStreaming) return String(s.year || s.startYear || '');
    if (s.status === 'ongoing' || s.endYear == null) return s.startYear + '–';
    return s.startYear === s.endYear ? String(s.startYear) : s.startYear + '–' + s.endYear;
  };

  SER.seasonLabel = function (se) {
    var to = se.to == null ? se.n : se.to;
    return to > se.n ? '第 ' + se.n + '–' + to + ' 季' : '第 ' + se.n + ' 季';
  };

  SER.seasonShort = function (se) {
    var to = se.to == null ? se.n : se.to;
    return to > se.n ? 'S' + se.n + '–' + to : 'S' + se.n;
  };

  SER.barPct = function (score) {
    return Math.max(8, Math.min(100, Math.round(((Number(score) - 6) / 4) * 100)));
  };

  SER.scoreCls = function (score, best) {
    if (score < 6.5) return 'bad';
    if (score < 7.6) return 'low';
    return best ? 'best' : '';
  };

  SER.TRENDS = [
    { id: 'steady', label: '🟢 全程穩定', desc: '各季口碑差距小，任何一季都不踩雷' },
    { id: 'rising', label: '📈 漸入佳境', desc: '越後面越精彩，前面撐過去就值得' },
    { id: 'wobble', label: '〰️ 中段起伏', desc: '有明顯的高峰與低谷，可參考分季導讀挑著看' },
    { id: 'falling', label: '📉 高開低走', desc: '後段口碑明顯低於高峰，建議先看避雷說明' }
  ];
  SER.TREND_MAP = indexBy(SER.TRENDS);

  SER.trendOf = function (s) {
    var arr = (s.seasons || []).map(function (x) { return Number(x.score) || 0; });
    if (arr.length < 2) return null;
    var max = Math.max.apply(null, arr);
    var min = Math.min.apply(null, arr);
    var first = arr[0];
    var last = arr[arr.length - 1];
    var tail = arr.length >= 4 ? (arr[arr.length - 1] + arr[arr.length - 2]) / 2 : last;
    if (max - min <= 0.6) return 'steady';
    if (max - tail >= 1.0) return 'falling';
    if (last - first >= 0.5 && last >= max - 0.3) return 'rising';
    return 'wobble';
  };

  SER.bestWorst = function (s) {
    var best = null;
    var worst = null;
    (s.seasons || []).forEach(function (se) {
      if (!best || se.score > best.score) best = se;
      if (!worst || se.score < worst.score) worst = se;
    });
    return { best: best, worst: worst };
  };

  /* ---------- 追劇護照（待看清單＋分季進度） ---------- */
  SER.inWatchlist = function (id) { return !!SER.state.watchlist[id]; };
  SER.getProgress = function (id) { return SER.state.progress[id] || null; };

  SER.seenCount = function (s) {
    var p = SER.getProgress(s.id);
    if (!p || !p.s) return 0;
    var n = 0;
    (s.seasons || []).forEach(function (_, i) { if (p.s[i]) n++; });
    return n;
  };

  SER.seenEpisodes = function (s) {
    var p = SER.getProgress(s.id);
    if (!p || !p.s) return 0;
    var n = 0;
    (s.seasons || []).forEach(function (se, i) { if (p.s[i]) n += se.eps || 0; });
    return n;
  };

  SER.mineStatus = function (s) {
    var total = (s.seasons || []).length;
    var seen = SER.seenCount(s);
    if (total && seen >= total) return 'done';
    if (seen > 0) return 'watching';
    if (SER.inWatchlist(s.id)) return 'watchlist';
    return '';
  };

  function persistProgress() { saveJson(KEY_PROGRESS, SER.state.progress); }
  function persistWatchlist() { saveJson(KEY_WATCHLIST, SER.state.watchlist); }

  function ensureProgress(id) {
    var p = SER.state.progress[id];
    if (!p) {
      p = { s: {}, startedAt: today(), updatedAt: today(), rating: 0, note: '' };
      SER.state.progress[id] = p;
    }
    if (!p.s) p.s = {};
    return p;
  }

  function cleanupProgress(id) {
    var p = SER.state.progress[id];
    if (!p) return;
    var any = Object.keys(p.s || {}).some(function (k) { return p.s[k]; });
    if (!any && !p.note && !p.rating) {
      delete SER.state.progress[id];
      maybeForgetSnapshot(id);
    }
  }

  SER.recordCampusAct = function () {
    try {
      var cn = window.CampusNav;
      if (cn && typeof cn.recordAct === 'function') cn.recordAct('series');
      else if (cn && typeof cn.bumpAct === 'function') cn.bumpAct('series');
    } catch (e) { /* ignore */ }
  };

  SER.toast = function (msg) {
    var el = document.getElementById('serToast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(function () { el.classList.remove('show'); }, 2600);
  };

  SER.toggleWatchlist = function (id) {
    var s = SER.find(id);
    var title = s ? s.title : id;
    if (SER.state.watchlist[id]) {
      delete SER.state.watchlist[id];
      maybeForgetSnapshot(id);
      persistWatchlist();
      SER.toast('已從待看清單移除《' + title + '》');
      return false;
    }
    rememberSnapshot(s);
    SER.state.watchlist[id] = { addedAt: today() };
    persistWatchlist();
    SER.recordCampusAct();
    SER.toast('📋 已加入待看清單：《' + title + '》');
    return true;
  };

  SER.toggleSeason = function (id, idx) {
    var s = SER.find(id);
    if (!s || !s.seasons || !s.seasons[idx]) return;
    rememberSnapshot(s);
    var p = ensureProgress(id);
    if (p.s[idx]) {
      delete p.s[idx];
      p.updatedAt = today();
      cleanupProgress(id);
      persistProgress();
      SER.toast('已取消《' + s.title + '》' + SER.seasonLabel(s.seasons[idx]) + '的觀看紀錄');
      return;
    }
    p.s[idx] = 1;
    p.updatedAt = today();
    persistProgress();
    SER.recordCampusAct();
    if (SER.mineStatus(s) === 'done') {
      SER.toast(s.status === 'ongoing' ? '📡 已追到最新進度：《' + s.title + '》' : '🎉 完食！《' + s.title + '》全部看完');
    } else {
      SER.toast('✅ 蓋章：《' + s.title + '》' + SER.seasonLabel(s.seasons[idx]));
    }
  };

  SER.toggleAllSeasons = function (id) {
    var s = SER.find(id);
    if (!s) return;
    if (SER.mineStatus(s) === 'done') {
      var p0 = SER.state.progress[id];
      if (p0) { p0.s = {}; p0.updatedAt = today(); }
      cleanupProgress(id);
      persistProgress();
      SER.toast('已清除《' + s.title + '》的觀看紀錄');
      return;
    }
    rememberSnapshot(s);
    var p = ensureProgress(id);
    (s.seasons || []).forEach(function (_, i) { p.s[i] = 1; });
    p.updatedAt = today();
    persistProgress();
    SER.recordCampusAct();
    SER.toast(s.status === 'ongoing' ? '📡 已標記追到最新：《' + s.title + '》' : '🎉 已標記全部看完：《' + s.title + '》');
  };

  SER.saveNote = function (id, rating, note) {
    var s = SER.find(id);
    rememberSnapshot(s);
    var p = ensureProgress(id);
    p.rating = Math.max(0, Math.min(5, Number(rating) || 0));
    p.note = String(note || '').trim().slice(0, 500);
    p.updatedAt = today();
    cleanupProgress(id);
    persistProgress();
    SER.recordCampusAct();
    SER.toast('💾 已儲存個人評分與追劇筆記');
  };

  SER.saveQuizDone = function (idx) {
    SER.state.quizDone[String(idx)] = 1;
    saveJson(KEY_QUIZ, SER.state.quizDone);
    SER.recordCampusAct();
  };

  SER.exportBackup = function () {
    return JSON.stringify({
      app: 'series-academy',
      v: 2,
      exportedAt: today(),
      watchlist: SER.state.watchlist,
      progress: SER.state.progress,
      snapshots: SER.state.snapshots
    });
  };

  SER.importBackup = function (text) {
    var d = JSON.parse(text);
    if (!d || d.app !== 'series-academy' || typeof d.watchlist !== 'object' || typeof d.progress !== 'object') {
      throw new Error('格式不符');
    }
    if (d.snapshots && typeof d.snapshots === 'object') {
      Object.keys(d.snapshots).forEach(function (k) {
        if (d.snapshots[k] && typeof d.snapshots[k] === 'object') {
          SER.state.snapshots[k] = d.snapshots[k];
        }
      });
      saveJson(KEY_SNAPSHOTS, SER.state.snapshots);
    }
    var day = function (v) { return /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : today(); };
    Object.keys(d.watchlist || {}).forEach(function (k) {
      if (!SER.find(k)) return;
      SER.state.watchlist[k] = { addedAt: day((d.watchlist[k] || {}).addedAt) };
    });
    Object.keys(d.progress || {}).forEach(function (k) {
      var s = SER.find(k);
      var src = d.progress[k];
      if (!s || !src || typeof src !== 'object') return;
      var seen = {};
      (s.seasons || []).forEach(function (_, i) { if (src.s && src.s[i]) seen[i] = 1; });
      SER.state.progress[k] = {
        s: seen,
        startedAt: day(src.startedAt),
        updatedAt: day(src.updatedAt),
        rating: Math.max(0, Math.min(5, Math.round(Number(src.rating) || 0))),
        note: String(src.note || '').slice(0, 500)
      };
      cleanupProgress(k);
    });
    persistWatchlist();
    persistProgress();
  };

  SER.myStats = function () {
    var st = { watchlist: 0, watching: 0, done: 0, episodes: 0, hours: 0 };
    var mins = 0;
    SER.getTrackedPool().forEach(function (s) {
      var ms = SER.mineStatus(s);
      if (ms) st[ms]++;
      var eps = SER.seenEpisodes(s);
      st.episodes += eps;
      mins += eps * (s.epRuntime || 45);
    });
    st.hours = Math.round(mins / 60);
    return st;
  };

  SER.syncHeaderBadges = function () {
    var st = SER.myStats();
    var set = function (id, v) {
      var el = document.getElementById(id);
      if (el) el.textContent = String(v);
    };
    set('hdrWatchlistCnt', st.watchlist);
    set('hdrWatchingCnt', st.watching);
    set('hdrDoneCnt', st.done);
    set('navNowCnt', SER.getNowStreamingItems().length);
    set('navTotalCnt', SER.getCatalog().length);
    set('navMyCnt', st.watchlist + st.watching + st.done);
  };

  /* ---------- 海報插畫與真實海報 ---------- */
  SER.heroGradient = function (s) {
    var g = SER.GENRE_MAP[(s.genres && s.genres[0]) || 'drama'] || SER.GENRES[0];
    return 'linear-gradient(135deg, ' + g.c1 + ' 0%, ' + g.c2 + ' 100%)';
  };

  SER.posterSvg = function (s) {
    var g = SER.GENRE_MAP[(s.genres && s.genres[0]) || 'drama'] || SER.GENRES[0];
    var sid = String(s.id || '');
    var seed = 0;
    for (var i = 0; i < sid.length; i++) seed = (seed * 31 + sid.charCodeAt(i)) & 0xffff;
    var gid = 'sp-' + sid.replace(/[^a-zA-Z0-9_-]/g, '');
    var title = String(s.title || '');
    var shortTitle = title.length > 13 ? title.slice(0, 12) + '…' : title;
    var fs = title.length > 9 ? 20 : 24;
    var cx = 250 + (seed % 70);
    var cy = 30 + ((seed >> 5) % 50);
    var scan = '';
    for (var y = 6; y < 150; y += 6) scan += '<rect x="0" y="' + y + '" width="360" height="1" fill="rgba(255,255,255,0.045)"/>';
    var sub = s.isNowStreaming
      ? (SER.yearsLabel(s) + ' · ' + (s.network || '') + ' · ' + (s.statusBadge || '線上熱播'))
      : (SER.yearsLabel(s) + ' · ' + (s.network || '') + ' · ' + (s.seasonsCount > 1 ? s.seasonsCount + ' 季 ' : '') + (s.episodes || 0) + ' 集');
    return (
      '<svg viewBox="0 0 360 150" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" role="img" aria-label="' + esc(title) + '">' +
        '<defs><linearGradient id="' + gid + '" x1="0" y1="0" x2="1" y2="1">' +
          '<stop offset="0%" stop-color="' + g.c1 + '"/><stop offset="100%" stop-color="' + g.c2 + '"/>' +
        '</linearGradient></defs>' +
        '<rect width="360" height="150" fill="url(#' + gid + ')"/>' +
        '<circle cx="' + cx + '" cy="' + cy + '" r="78" fill="rgba(255,255,255,0.09)"/>' +
        '<circle cx="' + (cx - 150) + '" cy="' + (cy + 96) + '" r="58" fill="rgba(0,0,0,0.16)"/>' +
        scan +
        '<text x="320" y="112" font-size="40" text-anchor="middle" opacity="0.9">' + g.icon + '</text>' +
        '<text x="16" y="104" font-size="' + fs + '" font-weight="900" fill="#ffffff">' + esc(shortTitle) + '</text>' +
        '<text x="16" y="128" font-size="12.5" font-weight="700" fill="rgba(255,255,255,0.88)">' + esc(sub) + '</text>' +
      '</svg>'
    );
  };

  SER.poster = function (s) {
    if (s && s.poster) {
      return { m: s.poster, o: s.posterHi || s.poster, fb: s.posterFallback || '' };
    }
    var p = window.SER_POSTERS && window.SER_POSTERS[s.id];
    return p && p.m ? p : null;
  };

  SER.onPosterLoad = function (img) {
    var box = img && img.closest ? img.closest('.ser-poster-real, .ser-modal-poster') : null;
    if (box) box.classList.add('is-loaded');
  };

  SER.onPosterError = function (img) {
    var fb = img && img.getAttribute ? img.getAttribute('data-fb') : '';
    if (fb && img.src !== fb) {
      img.removeAttribute('data-fb');
      img.src = fb;
      return;
    }
    var box = img && img.closest ? img.closest('.ser-poster-real, .ser-modal-poster') : null;
    if (box && box.parentNode) box.parentNode.removeChild(box);
  };

  function posterRealHtml(s, r) {
    var p = SER.poster(s);
    if (!p) return '';
    var sub = s.isNowStreaming
      ? (SER.yearsLabel(s) + ' · ' + (s.network || '') + ' · ' + (s.statusBadge || '線上熱播'))
      : (SER.yearsLabel(s) + ' · ' + (s.network || '') + ' · ' + (s.seasonsCount > 1 ? s.seasonsCount + ' 季 ' : '') + (s.episodes || 0) + ' 集');
    var fbAttr = p.fb ? ' data-fb="' + esc(p.fb) + '"' : '';
    return (
      '<div class="ser-poster-real">' +
        '<img class="ser-poster-bg" src="' + esc(p.m) + '" alt="" aria-hidden="true" loading="lazy" decoding="async" referrerpolicy="no-referrer" />' +
        '<div class="ser-poster-stage">' +
          '<img class="ser-poster-img" src="' + esc(p.m) + '"' + fbAttr + ' alt="《' + esc(s.title) + '》海報" loading="lazy" decoding="async" referrerpolicy="no-referrer" onload="window.SER.onPosterLoad(this)" onerror="window.SER.onPosterError(this)" />' +
          '<div class="ser-poster-side">' +
            '<div class="ser-poster-side-top">' +
              '<span class="ser-badge">' + esc(r.label) + '</span>' +
              '<span class="ser-badge score">★ ' + esc(Number(s.rating || 0).toFixed(1)) + '</span>' +
            '</div>' +
            '<div class="ser-poster-side-btm"><b>' + esc(s.title) + '</b><span>' + esc(sub) + '</span></div>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
  }

  SER.miniBars = function (s) {
    if (s.isNowStreaming) return '';
    var seasons = s.seasons || [];
    if (seasons.length < 2) return '';
    var bw = SER.bestWorst(s);
    var bars = seasons.map(function (se) {
      var h = SER.barPct(se.score);
      var cls = SER.scoreCls(se.score, false);
      return '<i class="ser-mini-bar' + (cls ? ' ' + cls : '') + '" style="height:' + h + '%" title="' + esc(SER.seasonLabel(se) + '：' + se.score.toFixed(1)) + '"></i>';
    }).join('');
    var trend = SER.TREND_MAP[SER.trendOf(s)];
    return (
      '<div>' +
        '<div class="ser-mini-bars">' + bars + '</div>' +
        '<div class="ser-mini-cap"><span>分季口碑 ' + esc(trend ? trend.label : '') + '</span>' +
        '<span>高點 ' + esc(SER.seasonShort(bw.best)) + '</span></div>' +
      '</div>'
    );
  };

  SER.verdictChip = function (s) {
    if (s.isNowStreaming) {
      return '<span class="ser-chip live">📺 ' + esc(s.statusBadge || '線上熱播') + '</span>';
    }
    var v = SER.VERDICT_MAP[(s.ending && s.ending.verdict) || 'ongoing'] || SER.VERDICT_MAP.ongoing;
    return '<span class="ser-chip ' + v.cls + '">' + esc(v.label) + '</span>';
  };

  SER.streamingBadgesHtml = function (plats) {
    return (plats || []).map(function (pid) {
      var sp = SER.STREAMING_PLATFORM_MAP[pid];
      var cls = sp ? sp.cls : '';
      var lbl = sp ? sp.label : pid;
      return '<span class="ser-plat-chip ' + cls + '">' + esc(lbl) + '</span>';
    }).join('');
  };

  function mineBadge(s) {
    var ms = SER.mineStatus(s);
    if (ms === 'done') return '<span class="ser-badge-mine done">' + (s.status === 'ongoing' ? '📡 已追到最新' : '✅ 已看完') + '</span>';
    if (ms === 'watching') return '<span class="ser-badge-mine watching">▶ 追劇中 ' + SER.seenCount(s) + '/' + s.seasons.length + '</span>';
    if (ms === 'watchlist') return '<span class="ser-badge-mine">📋 待看</span>';
    return '';
  }

  SER.renderCard = function (s) {
    var r = SER.REGION_MAP[s.region] || SER.REGIONS[0];
    var ms = SER.mineStatus(s);
    var inList = SER.inWatchlist(s.id);
    var gChips = (s.genres || []).map(function (gid) {
      var g = SER.GENRE_MAP[gid];
      return '<span class="ser-chip genre">' + esc(g ? g.short : gid) + '</span>';
    }).join('');

    if (s.isNowStreaming) {
      var origSub = (s.origTitle ? s.origTitle + ' · ' : '') + (s.year || '') + ' 年 · ' + (s.country || r.short);
      var deepChip = (s.catalogId && SER.find(s.catalogId))
        ? '<span class="ser-chip ok">📖 含經典分季導讀</span>'
        : '';
      return (
        '<article class="ser-card' + (ms === 'done' ? ' is-done' : '') + '">' +
          '<div class="ser-poster" data-open-series="' + esc(s.id) + '">' +
            SER.posterSvg(s) +
            '<div class="ser-poster-badges">' +
              '<span class="ser-badge">' + esc(r.label) + '</span>' +
              '<span class="ser-badge score">★ ' + esc(Number(s.rating || 0).toFixed(1)) + '</span>' +
            '</div>' +
            posterRealHtml(s, r) +
            mineBadge(s) +
          '</div>' +
          '<div class="ser-card-body">' +
            '<div>' +
              '<h3 class="ser-card-title" data-open-series="' + esc(s.id) + '">' + esc(s.title) + '</h3>' +
              '<div class="ser-card-orig">' + esc(origSub) + '</div>' +
            '</div>' +
            '<div class="ser-card-meta">' +
              SER.streamingBadgesHtml(s.platforms) +
              '<span class="ser-chip">' + esc(s.statusBadge || '熱播中') + '</span>' +
              gChips + deepChip +
            '</div>' +
            '<div class="ser-card-tagline">' + esc(s.tagline || '') + '</div>' +
            '<p class="ser-card-syn">' + esc(s.synopsis || '') + '</p>' +
            '<div class="ser-card-foot">' +
              '<div class="ser-card-actions">' +
                '<button type="button" class="ser-act-btn' + (inList ? ' on' : '') + '" data-toggle-watchlist="' + esc(s.id) + '">' + (inList ? '📋 已在待看' : '➕ 加入待看') + '</button>' +
                '<button type="button" class="ser-act-btn' + (ms === 'done' ? ' done' : '') + '" data-toggle-all="' + esc(s.id) + '">' + (ms === 'done' ? '✅ 已看完' : '👀 標記看完') + '</button>' +
                '<button type="button" class="ser-act-btn detail" data-open-series="' + esc(s.id) + '">看點</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</article>'
      );
    }

    var st = SER.STATUS[s.status] || SER.STATUS.ended;
    return (
      '<article class="ser-card' + (ms === 'done' ? ' is-done' : '') + '">' +
        '<div class="ser-poster" data-open-series="' + esc(s.id) + '">' +
          SER.posterSvg(s) +
          '<div class="ser-poster-badges">' +
            '<span class="ser-badge">' + esc(r.label) + '</span>' +
            '<span class="ser-badge score">★ ' + esc(Number(s.rating || 0).toFixed(1)) + '</span>' +
          '</div>' +
          posterRealHtml(s, r) +
          mineBadge(s) +
        '</div>' +
        '<div class="ser-card-body">' +
          '<div>' +
            '<h3 class="ser-card-title" data-open-series="' + esc(s.id) + '">' + esc(s.title) + '</h3>' +
            '<div class="ser-card-orig">' + esc(s.origTitle || '') + ' · ' + esc(SER.hoursLabel(s)) + '</div>' +
          '</div>' +
          '<div class="ser-card-meta">' +
            '<span class="ser-chip ' + st.cls + '">' + st.icon + ' ' + esc(st.label) + '</span>' +
            SER.verdictChip(s) + gChips +
          '</div>' +
          '<div class="ser-card-tagline">' + esc(s.tagline || '') + '</div>' +
          '<p class="ser-card-syn">' + esc(s.synopsis || '') + '</p>' +
          '<div class="ser-card-foot">' +
            SER.miniBars(s) +
            '<div class="ser-card-actions">' +
              '<button type="button" class="ser-act-btn' + (inList ? ' on' : '') + '" data-toggle-watchlist="' + esc(s.id) + '">' + (inList ? '📋 已在待看' : '➕ 加入待看') + '</button>' +
              '<button type="button" class="ser-act-btn' + (ms === 'done' ? ' done' : '') + '" data-toggle-all="' + esc(s.id) + '">' + (ms === 'done' ? '✅ 已看完' : '👀 標記看完') + '</button>' +
              '<button type="button" class="ser-act-btn detail" data-open-series="' + esc(s.id) + '">導讀</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</article>'
    );
  };

  /* 分季口碑長條圖（雷達頁與彈窗共用） */
  SER.seasonBars = function (s) {
    var seasons = s.seasons || [];
    var bw = SER.bestWorst(s);
    var cols = seasons.map(function (se) {
      var h = SER.barPct(se.score);
      var cls = SER.scoreCls(se.score, seasons.length > 1 && se === bw.best);
      return (
        '<div class="ser-bar-col">' +
          '<span class="ser-bar-val">' + se.score.toFixed(1) + '</span>' +
          '<div class="ser-bar' + (cls ? ' ' + cls : '') + '" style="height:' + h + '%"></div>' +
        '</div>'
      );
    }).join('');
    var lbls = seasons.map(function (se) { return '<span>' + esc(SER.seasonShort(se)) + '</span>'; }).join('');
    return '<div class="ser-bars">' + cols + '</div><div class="ser-bar-lbls">' + lbls + '</div>';
  };

  /* ---------- 無雷導讀／熱播看點彈窗 ---------- */
  SER.openModal = function (id) {
    var s = SER.find(id);
    var backdrop = document.getElementById('seriesModal');
    var card = document.getElementById('seriesModalCard');
    if (!s || !backdrop || !card) return;
    SER.recordCampusAct();
    var draft = null;

    function render() {
      var r = SER.REGION_MAP[s.region] || SER.REGIONS[0];
      var ms = SER.mineStatus(s);
      var inList = SER.inWatchlist(s.id);
      var p = SER.getProgress(s.id) || { s: {}, rating: 0, note: '' };
      if (!draft) draft = { rating: p.rating || 0, note: p.note || '' };
      var pst = SER.poster(s);
      var fbAttr = (pst && pst.fb) ? ' data-fb="' + esc(pst.fb) + '"' : '';

      var gChips = (s.genres || []).map(function (gid) {
        var g = SER.GENRE_MAP[gid];
        return '<span class="ser-chip">' + esc(g ? g.label : gid) + '</span>';
      }).join('');
      var hls = ((s.analysis && s.analysis.highlights) || []).map(function (h) { return '<li>' + esc(h) + '</li>'; }).join('');
      var stars = '';
      for (var k = 1; k <= 5; k++) {
        stars += '<button type="button" class="ser-star-btn" data-set-star="' + k + '" title="' + k + ' 顆星">' + (k <= draft.rating ? '⭐' : '☆') + '</button>';
      }
      var doneLbl = s.status === 'ongoing' ? '📡 已追到最新（點擊清除）' : '✅ 已全部看完（點擊清除）';
      var todoLbl = s.status === 'ongoing' ? '👀 標記追到最新進度' : '👀 標記已看完';

      if (s.isNowStreaming) {
        var deepTarget = s.catalogId ? SER.find(s.catalogId) : null;
        var creditParts = [];
        if (s.creator) creditParts.push(esc(s.creatorRole || '導演') + '：<b>' + esc(s.creator) + '</b>');
        if (s.cast && s.cast.length) creditParts.push('主演：' + esc(s.cast.join('、')));
        card.innerHTML =
          '<button type="button" class="ser-modal-close" id="serModalClose" aria-label="關閉">✕</button>' +
          '<div class="ser-modal-hero" style="background:' + SER.heroGradient(s) + '">' +
            (pst
              ? '<div class="ser-modal-poster"><img src="' + esc(pst.o || pst.m) + '"' + fbAttr + ' alt="《' + esc(s.title) + '》海報" decoding="async" referrerpolicy="no-referrer" onload="window.SER.onPosterLoad(this)" onerror="window.SER.onPosterError(this)" /></div>'
              : '') +
            '<div class="ser-modal-hero-main">' +
              '<h2 id="seriesModalTitle">' + esc(s.title) + '</h2>' +
              (s.origTitle ? '<div class="ser-modal-orig">' + esc(s.origTitle) + '</div>' : '') +
              '<div class="ser-modal-chips">' +
                SER.streamingBadgesHtml(s.platforms) +
                '<span class="ser-chip">' + esc(r.label) + ' · ' + esc(s.country || '') + '</span>' +
                '<span class="ser-chip">' + esc(s.year || '') + ' 年</span>' +
                '<span class="ser-chip">📺 ' + esc(s.statusBadge || '線上熱播') + '</span>' +
                '<span class="ser-chip">★ 評分參考 ' + esc(Number(s.rating || 0).toFixed(1)) + '</span>' +
                gChips +
              '</div>' +
              (creditParts.length ? '<div class="ser-modal-credit">' + creditParts.join('　') + '</div>' : '') +
              '<div class="ser-modal-acts">' +
                '<button type="button" class="ser-btn ser-btn-sm' + (inList ? ' on' : '') + '" id="serModalWl">' + (inList ? '📋 已在待看清單（點擊移除）' : '➕ 加入待看清單') + '</button>' +
                '<button type="button" class="ser-btn ser-btn-sm' + (ms === 'done' ? ' on' : '') + '" id="serModalAll">' + (ms === 'done' ? doneLbl : todoLbl) + '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
          '<div class="ser-modal-body">' +
            (deepTarget
              ? '<div class="ser-deep-callout">' +
                  '<b>📖 本劇同時收錄於「跨年代經典片庫」，提供完整分季口碑走勢與收尾避雷評價！</b>' +
                  '<button type="button" class="ser-btn ser-btn-sm ser-btn-primary" id="serModalGoDeep">開啟完整分季導讀 →</button>' +
                '</div>'
              : '') +
            '<div class="ser-modal-tagline">❝ ' + esc(s.tagline || '') + ' ❞</div>' +
            '<div class="ser-block"><h4>📖 劇情簡介</h4><p>' + esc(s.synopsis || '') + '</p></div>' +
            '<div class="ser-block"><h4>🔍 本週追劇三大看點</h4><ol>' + hls + '</ol></div>' +
            '<div class="ser-two-col">' +
              '<div class="ser-block"><h4>🧩 類型與敘事魅力</h4><p>' + esc((s.analysis && s.analysis.structure) || '') + '</p></div>' +
              '<div class="ser-block"><h4>📡 線上供應平台</h4><p>' + esc((s.analysis && s.analysis.showrunner) || '') + '</p></div>' +
            '</div>' +
            '<div class="ser-note-box">' +
              '<div class="ser-note-hd"><span>📝 我的評分與追劇筆記（只存在這台裝置的瀏覽器）</span><div class="ser-stars" id="serModalStars">' + stars + '</div></div>' +
              '<textarea id="serModalNote" class="ser-input" rows="2" maxlength="500" placeholder="寫下看到第幾集、喜歡的角色或觀後心得…">' + esc(draft.note) + '</textarea>' +
              '<div style="margin-top:8px;text-align:right;"><button type="button" class="ser-btn ser-btn-sm ser-btn-primary" id="serModalSave">💾 儲存評分與筆記</button></div>' +
            '</div>' +
            '<p class="ser-disclaimer">七大串流平台熱播清單每週自動同步（僅收真人戲劇／影集）；實際上架集數與會員權限請以各串流平台當下頁面為準。</p>' +
          '</div>';
      } else {
        var plat = SER.PLATFORM_MAP[s.platform];
        var st = SER.STATUS[s.status] || SER.STATUS.ended;
        var v = SER.VERDICT_MAP[(s.ending && s.ending.verdict) || 'ongoing'] || SER.VERDICT_MAP.ongoing;
        var bw = SER.bestWorst(s);
        var multi = (s.seasons || []).length > 1;
        var moods = (s.mood || []).map(function (m) { return '<span class="ser-chip">#' + esc(m) + '</span>'; }).join('');
        var seasonsHtml = (s.seasons || []).map(function (se, i) {
          var seen = !!(p.s && p.s[i]);
          var w = SER.barPct(se.score);
          var cls = SER.scoreCls(se.score, multi && se === bw.best);
          return (
            '<div class="ser-season">' +
              '<div class="ser-season-hd"><b>' + esc(SER.seasonLabel(se)) + '</b><span>' + esc(se.year) + ' · ' + esc(se.eps) + ' 集</span></div>' +
              '<div class="ser-season-mid">' +
                '<div class="ser-season-score"><div class="ser-season-track"><i class="' + cls + '" style="width:' + w + '%"></i></div><em>' + se.score.toFixed(1) + '</em></div>' +
                '<p>' + esc(se.guide || '') + '</p>' +
              '</div>' +
              '<button type="button" class="ser-stamp' + (seen ? ' on' : '') + '" data-modal-season="' + i + '">' + (seen ? '✅ 已看完' : '☐ 看完蓋章') + '</button>' +
            '</div>'
          );
        }).join('');

        card.innerHTML =
          '<button type="button" class="ser-modal-close" id="serModalClose" aria-label="關閉">✕</button>' +
          '<div class="ser-modal-hero" style="background:' + SER.heroGradient(s) + '">' +
            (pst
              ? '<div class="ser-modal-poster"><img src="' + esc(pst.o || pst.m) + '"' + fbAttr + ' alt="《' + esc(s.title) + '》海報" decoding="async" referrerpolicy="no-referrer" onload="window.SER.onPosterLoad(this)" onerror="window.SER.onPosterError(this)" /></div>'
              : '') +
            '<div class="ser-modal-hero-main">' +
              '<h2 id="seriesModalTitle">' + esc(s.title) + '</h2>' +
              '<div class="ser-modal-orig">' + esc(s.origTitle || '') + '</div>' +
              '<div class="ser-modal-chips">' +
                '<span class="ser-chip">' + esc(r.label) + ' · ' + esc(s.country || '') + '</span>' +
                '<span class="ser-chip">' + esc(SER.yearsLabel(s)) + '</span>' +
                '<span class="ser-chip">' + st.icon + ' ' + esc(st.label) + '</span>' +
                '<span class="ser-chip">📺 ' + esc(s.network || '') + '</span>' +
                '<span class="ser-chip">★ 本館推薦 ' + esc(Number(s.rating || 0).toFixed(1)) + '</span>' +
                gChips + moods +
              '</div>' +
              '<div class="ser-modal-credit">' + esc(s.creatorRole || '主創') + '：<b>' + esc(s.creator || '') + '</b>　主演：' + esc((s.cast || []).join('、')) + '</div>' +
              '<div class="ser-modal-acts">' +
                '<button type="button" class="ser-btn ser-btn-sm' + (inList ? ' on' : '') + '" id="serModalWl">' + (inList ? '📋 已在待看清單（點擊移除）' : '➕ 加入待看清單') + '</button>' +
                '<button type="button" class="ser-btn ser-btn-sm' + (ms === 'done' ? ' on' : '') + '" id="serModalAll">' + (ms === 'done' ? doneLbl : todoLbl) + '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
          '<div class="ser-modal-body">' +
            '<div class="ser-modal-tagline">❝ ' + esc(s.tagline || '') + ' ❞</div>' +
            '<div class="ser-block"><h4>📖 無雷劇情簡介</h4><p>' + esc(s.synopsis || '') + '</p></div>' +
            '<div class="ser-block">' +
              '<h4>🚪 入坑指南</h4>' +
              '<div class="ser-entry-grid">' +
                '<div class="ser-entry-cell"><span>規模</span><b>' + (s.seasonsCount > 1 ? esc(s.seasonsCount) + ' 季 ' : '') + esc(s.episodes) + ' 集</b></div>' +
                '<div class="ser-entry-cell"><span>全部看完</span><b>' + esc(SER.hoursLabel(s)) + '</b></div>' +
                '<div class="ser-entry-cell"><span>單集片長</span><b>約 ' + esc(s.epRuntime) + ' 分鐘</b></div>' +
                '<div class="ser-entry-cell"><span>節奏</span><b>' + esc(SER.PACES[(s.entry && s.entry.pace) || 'steady'] || '') + '</b></div>' +
                '<div class="ser-entry-cell"><span>看到這裡會入戲</span><b>' + esc((s.entry && s.entry.hookBy) || '') + '</b></div>' +
              '</div>' +
              '<p>' + esc((s.entry && s.entry.tip) || '') + '</p>' +
            '</div>' +
            '<div class="ser-block">' +
              '<h4>📊 ' + (multi ? '分季無雷導讀與口碑走勢' : '節奏導讀') + '（看完一季就蓋一個章）</h4>' +
              seasonsHtml +
            '</div>' +
            '<div class="ser-verdict-box ' + v.cls + '"><b>🏁 收尾評價：' + esc(v.label) + '</b><p>' + esc((s.ending && s.ending.note) || '') + '</p></div>' +
            '<div class="ser-block"><h4>🔍 三大看門道亮點</h4><ol>' + hls + '</ol></div>' +
            '<div class="ser-two-col">' +
              '<div class="ser-block"><h4>🧩 敘事結構與伏筆</h4><p>' + esc((s.analysis && s.analysis.structure) || '') + '</p></div>' +
              '<div class="ser-block"><h4>🎭 角色弧線</h4><p>' + esc((s.analysis && s.analysis.arc) || '') + '</p></div>' +
              '<div class="ser-block"><h4>✍️ 主創風格</h4><p>' + esc((s.analysis && s.analysis.showrunner) || '') + '</p></div>' +
            '</div>' +
            '<div class="ser-note-box">' +
              '<div class="ser-note-hd"><span>📝 我的評分與追劇筆記（只存在這台裝置的瀏覽器）</span><div class="ser-stars" id="serModalStars">' + stars + '</div></div>' +
              '<textarea id="serModalNote" class="ser-input" rows="2" maxlength="500" placeholder="寫下最喜歡的一集、最有共鳴的角色，或提醒自己看到哪裡…">' + esc(draft.note) + '</textarea>' +
              '<div style="margin-top:8px;text-align:right;"><button type="button" class="ser-btn ser-btn-sm ser-btn-primary" id="serModalSave">💾 儲存評分與筆記</button></div>' +
            '</div>' +
            '<p class="ser-disclaimer">本館推薦指數與分季口碑指數為編輯綜合各方評價後的主觀整理，僅供選片參考；「' + esc(plat ? plat.label : '') + '」為首播平台分類，查詢目前線上供應請切換至「🔥 七大平台熱播」分頁。</p>' +
          '</div>';
      }

      var refresh = function () {
        render();
        if (typeof SER.refreshCurrentView === 'function') SER.refreshCurrentView();
      };
      var keepDraft = function () {
        var ta = document.getElementById('serModalNote');
        if (ta) draft.note = ta.value;
      };
      document.getElementById('serModalClose').onclick = SER.closeModal;
      document.getElementById('serModalWl').onclick = function () { keepDraft(); SER.toggleWatchlist(s.id); refresh(); };
      document.getElementById('serModalAll').onclick = function () { keepDraft(); SER.toggleAllSeasons(s.id); refresh(); };
      var goDeep = document.getElementById('serModalGoDeep');
      if (goDeep && s.catalogId) {
        goDeep.onclick = function () { SER.openModal(s.catalogId); };
      }
      card.querySelectorAll('[data-modal-season]').forEach(function (btn) {
        btn.onclick = function () {
          keepDraft();
          SER.toggleSeason(s.id, Number(btn.getAttribute('data-modal-season')));
          refresh();
        };
      });
      card.querySelectorAll('[data-set-star]').forEach(function (btn) {
        btn.onclick = function () {
          var n = Number(btn.getAttribute('data-set-star')) || 0;
          draft.rating = draft.rating === n ? 0 : n;
          card.querySelectorAll('[data-set-star]').forEach(function (b2) {
            b2.textContent = Number(b2.getAttribute('data-set-star')) <= draft.rating ? '⭐' : '☆';
          });
        };
      });
      document.getElementById('serModalSave').onclick = function () {
        keepDraft();
        SER.saveNote(s.id, draft.rating, draft.note);
        refresh();
      };
    }

    render();
    backdrop.classList.add('open');
    backdrop.scrollTop = 0;
  };

  SER.closeModal = function () {
    var backdrop = document.getElementById('seriesModal');
    if (backdrop) backdrop.classList.remove('open');
  };

  SER.apiBase = function () {
    var ms = document.querySelector && document.querySelector('script[data-campus-mount]');
    if (ms) {
      var mnt = ms.getAttribute('data-campus-mount');
      if (mnt) return '/' + mnt + '/api/';
    }
    return 'api/';
  };

  SER.isStatic = function () {
    if (window.SER_STATIC_ONLY || window.CAMPUS_STATIC_ONLY) return true;
    var loc = window.location || {};
    if (String(loc.protocol || '').indexOf('http') !== 0) return true;
    return /(^|\.)github\.io$/i.test(String(loc.hostname || ''));
  };
})();
