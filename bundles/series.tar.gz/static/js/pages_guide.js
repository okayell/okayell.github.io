/* 🧩 編劇結構課：長篇敘事怎麼看門道（課程、術語小辭典、隨堂測驗） */
(function () {
  'use strict';
  var SER = window.SER;

  function lessons() { return Array.isArray(window.SER_LESSONS) ? window.SER_LESSONS : []; }
  function glossary() { return Array.isArray(window.SER_GLOSSARY) ? window.SER_GLOSSARY : []; }
  function quiz() { return Array.isArray(window.SER_QUIZ) ? window.SER_QUIZ : []; }

  var answered = {};

  function lessonHtml(l, i) {
    var pts = (l.points || []).map(function (p) { return '<li>' + SER.esc(p) + '</li>'; }).join('');
    var ex = (l.examples || []).map(function (id) {
      var s = SER.find(id);
      return s ? '<button type="button" class="ser-ex-chip" data-open-series="' + SER.esc(id) + '">《' + SER.esc(s.title) + '》</button>' : '';
    }).join('');
    return (
      '<div class="ser-lesson">' +
        '<h3>第 ' + (i + 1) + ' 堂｜' + SER.esc(l.title) + '</h3>' +
        '<div class="ser-lesson-sum">' + SER.esc(l.summary || '') + '</div>' +
        '<ul>' + pts + '</ul>' +
        (ex ? '<div class="ser-lesson-ex"><span>延伸觀摩（點開看無雷導讀）：</span>' + ex + '</div>' : '') +
      '</div>'
    );
  }

  function quizHtml(q, i) {
    var picked = answered[i];
    var done = picked != null;
    /* 選項顯示順序依題號輪轉，避免正確答案總是在同一個位置 */
    var n = (q.opts || []).length;
    var rot = n ? (i * 2 + (i >> 1) + 1) % n : 0;
    var opts = (q.opts || []).map(function (_, pos) {
      var j = (pos + rot) % n;
      var cls = 'ser-quiz-opt';
      if (done && j === q.ans) cls += ' right';
      else if (done && j === picked) cls += ' wrong';
      return '<button type="button" class="' + cls + '" data-quiz="' + i + '" data-opt="' + j + '"' + (done ? ' disabled' : '') + '>' + String.fromCharCode(65 + pos) + '．' + SER.esc(q.opts[j]) + '</button>';
    }).join('');
    var passed = !!SER.state.quizDone[String(i)];
    return (
      '<div class="ser-quiz">' +
        '<div class="ser-quiz-q">Q' + (i + 1) + '．' + SER.esc(q.q) + (passed ? ' <span class="ser-chip ok">已答對</span>' : '') + '</div>' +
        opts +
        (done ? '<div class="ser-quiz-exp">' + (picked === q.ans ? '✅ 答對了！' : '❌ 再想想。') + SER.esc(q.exp || '') + '</div>' : '') +
      '</div>'
    );
  }

  SER.renderGuidePage = function (root) {
    var ls = lessons();
    var gs = glossary();
    var qs = quiz();
    var passed = qs.filter(function (_, i) { return SER.state.quizDone[String(i)]; }).length;
    root.innerHTML =
      '<div class="ser-sec-hd"><div><h2>🧩 編劇結構課</h2><div class="ser-sec-sub">影集和電影最大的不同是「時間」：' + ls.length + ' 堂課帶你看懂長篇敘事怎麼鋪陳、怎麼留人，以及為什麼有些作品會爛尾</div></div></div>' +
      ls.map(lessonHtml).join('') +
      (gs.length
        ? '<div class="ser-sec-hd"><div><h2>📒 追劇術語小辭典</h2><div class="ser-sec-sub">看劇評、訪談時常見的 ' + gs.length + ' 個行話</div></div></div>' +
          '<div class="ser-gloss-grid">' + gs.map(function (g) {
            return '<div class="ser-gloss"><b>' + SER.esc(g.term) + '</b>' + (g.en ? '<em>' + SER.esc(g.en) + '</em>' : '') + '<p>' + SER.esc(g.desc) + '</p></div>';
          }).join('') + '</div>'
        : '') +
      (qs.length
        ? '<div class="ser-sec-hd"><div><h2>✍️ 隨堂測驗</h2><div class="ser-sec-sub">共 ' + qs.length + ' 題，已答對 ' + passed + ' 題</div></div>' +
            '<button type="button" class="ser-link-btn" id="quizReset">🔄 重新作答</button></div>' +
          qs.map(quizHtml).join('')
        : '');

    root.querySelectorAll('[data-quiz]').forEach(function (b) {
      b.onclick = function () {
        var i = Number(b.getAttribute('data-quiz'));
        var j = Number(b.getAttribute('data-opt'));
        answered[i] = j;
        if (qs[i] && j === qs[i].ans) SER.saveQuizDone(i);
        var y = window.scrollY;
        SER.renderGuidePage(root);
        window.scrollTo(0, y);
      };
    });
    var reset = document.getElementById('quizReset');
    if (reset) {
      reset.onclick = function () {
        answered = {};
        var y = window.scrollY;
        SER.renderGuidePage(root);
        window.scrollTo(0, y);
      };
    }
  };
})();
