/* 🎞️ 影集片庫：地區 × 類型 × 首播平台 × 完結狀態 × 收尾評價 × 片長 × 我的進度 交叉篩選 */
(function () {
  'use strict';
  var SER = window.SER;
  var PAGE_STEP = 36;

  var VERDICT_GROUPS = [
    { id: 'safe', label: '✅ 收尾好評', test: function (v) { return v === 'perfect' || v === 'good'; } },
    { id: 'perfect', label: '🏆 神收尾', test: function (v) { return v === 'perfect'; } },
    { id: 'divided', label: '⚖️ 兩極／開放式', test: function (v) { return v === 'mixed' || v === 'open'; } },
    { id: 'risky', label: '⚠️ 高開低走／腰斬', test: function (v) { return v === 'letdown' || v === 'cancelled'; } },
    { id: 'ongoing', label: '📡 尚未完結', test: function (v) { return v === 'ongoing'; } }
  ];
  var MINE = [
    { id: 'none', label: '🆕 還沒看過' },
    { id: 'watchlist', label: '📋 待看' },
    { id: 'watching', label: '▶ 追劇中' },
    { id: 'done', label: '✅ 已看完' }
  ];
  var STATUS = [
    { id: 'ended', label: '✅ 已完結' },
    { id: 'limited', label: '🎞️ 迷你影集' },
    { id: 'ongoing', label: '📡 製播中' }
  ];

  SER.resetExplore = function () {
    var ef = SER.state.explore;
    ef.region = ef.genre = ef.platform = ef.status = ef.verdict = ef.length = ef.mine = 'all';
    ef.q = '';
    ef.sort = 'rating';
    ef.limit = PAGE_STEP;
  };

  function matchDim(s, dim, val) {
    if (val === 'all') return true;
    if (dim === 'region') return s.region === val;
    if (dim === 'genre') return (s.genres || []).indexOf(val) !== -1;
    if (dim === 'platform') return s.platform === val;
    if (dim === 'status') return s.status === val;
    if (dim === 'verdict') {
      var g = null;
      VERDICT_GROUPS.forEach(function (x) { if (x.id === val) g = x; });
      return g ? g.test((s.ending && s.ending.verdict) || '') : true;
    }
    if (dim === 'length') {
      var len = SER.LENGTH_MAP[val];
      return len ? len.test(SER.hours(s)) : true;
    }
    if (dim === 'mine') {
      var ms = SER.mineStatus(s);
      return val === 'none' ? ms === '' : ms === val;
    }
    return true;
  }

  var DIMS = ['region', 'genre', 'platform', 'status', 'verdict', 'length', 'mine'];

  SER.renderExplorePage = function (root) {
    var cat = SER.getCatalog();
    var ef = SER.state.explore;
    if (!ef.limit || ef.limit < PAGE_STEP) ef.limit = PAGE_STEP;
    var q = String(ef.q || '').trim().toLowerCase();

    function matchSearch(s) {
      if (!q) return true;
      var hay = [s.title, s.origTitle, s.creator, s.network, s.country, (s.cast || []).join(' '), (s.mood || []).join(' '), s.tagline].join(' ').toLowerCase();
      return hay.indexOf(q) !== -1;
    }
    function matchExcept(s, skip) {
      for (var i = 0; i < DIMS.length; i++) {
        if (DIMS[i] !== skip && !matchDim(s, DIMS[i], ef[DIMS[i]])) return false;
      }
      return matchSearch(s);
    }

    var filtered = cat.filter(function (s) { return matchExcept(s, ''); });
    filtered.sort(function (a, b) {
      if (ef.sort === 'year_desc') return (b.startYear || 0) - (a.startYear || 0) || (b.rating || 0) - (a.rating || 0);
      if (ef.sort === 'year_asc') return (a.startYear || 0) - (b.startYear || 0) || (b.rating || 0) - (a.rating || 0);
      if (ef.sort === 'short') return SER.hours(a) - SER.hours(b) || (b.rating || 0) - (a.rating || 0);
      if (ef.sort === 'long') return SER.hours(b) - SER.hours(a) || (b.rating || 0) - (a.rating || 0);
      return (b.rating || 0) - (a.rating || 0) || (b.startYear || 0) - (a.startYear || 0);
    });

    function pillRow(dim, allLabel, items) {
      var pool = cat.filter(function (s) { return matchExcept(s, dim); });
      var html = '<button type="button" class="ser-pill' + (ef[dim] === 'all' ? ' active' : '') + '" data-ef="' + dim + '" data-val="all">' + allLabel + ' (' + pool.length + ')</button>';
      items.forEach(function (it) {
        var c = pool.filter(function (s) { return matchDim(s, dim, it.id); }).length;
        if (!c && ef[dim] !== it.id && (dim === 'platform' || dim === 'region' || dim === 'genre')) return;
        html += '<button type="button" class="ser-pill' + (ef[dim] === it.id ? ' active' : '') + (c === 0 ? ' is-zero' : '') + '" data-ef="' + dim + '" data-val="' + it.id + '">' + SER.esc(it.label) + ' (' + c + ')</button>';
      });
      return html;
    }

    var active = !!q || DIMS.some(function (d) { return ef[d] !== 'all'; });
    var visible = filtered.slice(0, ef.limit);
    var remaining = filtered.length - visible.length;

    root.innerHTML =
      '<div class="ser-sec-hd">' +
        '<div><h2>🎞️ 跨年代經典片庫</h2><div class="ser-sec-sub">收錄陸劇、韓劇、台劇、日劇、美劇、英劇與歐陸跨年代經典代表作，每部皆附無雷分季導讀、入坑指南與收尾評價</div></div>' +
        '<button type="button" class="ser-link-btn" data-go-route="now">🔥 找目前線上熱播影集？前往七大平台熱播 →</button>' +
      '</div>' +
      '<div class="ser-filter">' +
        '<div class="ser-search-row">' +
          '<input type="search" class="ser-input" id="efSearch" placeholder="搜尋片名、原文片名、主創、演員、頻道…" value="' + SER.esc(ef.q) + '" />' +
          '<select class="ser-select" id="efSort" aria-label="排序方式">' +
            '<option value="rating"' + (ef.sort === 'rating' ? ' selected' : '') + '>排序：推薦指數高→低</option>' +
            '<option value="year_desc"' + (ef.sort === 'year_desc' ? ' selected' : '') + '>排序：開播年份新→舊</option>' +
            '<option value="year_asc"' + (ef.sort === 'year_asc' ? ' selected' : '') + '>排序：開播年份舊→新</option>' +
            '<option value="short"' + (ef.sort === 'short' ? ' selected' : '') + '>排序：最快看完優先</option>' +
            '<option value="long"' + (ef.sort === 'long' ? ' selected' : '') + '>排序：最耐看優先</option>' +
          '</select>' +
        '</div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">地區</div><div class="ser-pills">' + pillRow('region', '全部', SER.REGIONS) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">類型</div><div class="ser-pills">' + pillRow('genre', '全部', SER.GENRES) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">首播平台</div><div class="ser-pills">' + pillRow('platform', '全部', SER.PLATFORMS) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">狀態</div><div class="ser-pills">' + pillRow('status', '全部', STATUS) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">收尾</div><div class="ser-pills">' + pillRow('verdict', '全部', VERDICT_GROUPS) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">片長</div><div class="ser-pills">' + pillRow('length', '全部', SER.LENGTHS) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">我的進度</div><div class="ser-pills">' + pillRow('mine', '全部', MINE) + '</div></div>' +
      '</div>' +
      '<div class="ser-result-bar"><span>找到 <b>' + filtered.length + '</b> 部影集</span>' +
        (active ? '<button type="button" class="ser-link-btn" id="efReset">✕ 清除所有條件</button>' : '') + '</div>' +
      (visible.length
        ? '<div class="ser-grid">' + visible.map(SER.renderCard).join('') + '</div>'
        : '<div class="ser-empty"><b>沒有符合條件的影集</b>試著放寬條件，或到「💬 意見回饋」許願想看的作品。</div>') +
      (remaining > 0
        ? '<div class="ser-more-bar"><button type="button" class="ser-btn" id="efMore">顯示更多（還有 ' + remaining + ' 部）</button></div>'
        : '');

    root.querySelectorAll('[data-ef]').forEach(function (b) {
      b.onclick = function () {
        ef[b.getAttribute('data-ef')] = b.getAttribute('data-val');
        ef.limit = PAGE_STEP;
        SER.renderExplorePage(root);
      };
    });
    var search = document.getElementById('efSearch');
    if (search) {
      var composing = false;
      var timer = null;
      var apply = function () {
        ef.q = search.value;
        ef.limit = PAGE_STEP;
        var pos = search.selectionStart;
        SER.renderExplorePage(root);
        var again = document.getElementById('efSearch');
        if (again) {
          again.focus();
          try { again.setSelectionRange(pos, pos); } catch (e) { /* ignore */ }
        }
      };
      search.addEventListener('compositionstart', function () { composing = true; });
      search.addEventListener('compositionend', function () { composing = false; apply(); });
      search.addEventListener('input', function () {
        if (composing) return;
        clearTimeout(timer);
        timer = setTimeout(apply, 220);
      });
    }
    var sortSel = document.getElementById('efSort');
    if (sortSel) sortSel.onchange = function () { ef.sort = sortSel.value; SER.renderExplorePage(root); };
    var reset = document.getElementById('efReset');
    if (reset) reset.onclick = function () { SER.resetExplore(); SER.renderExplorePage(root); };
    var more = document.getElementById('efMore');
    if (more) {
      more.onclick = function () {
        var y = window.scrollY;
        ef.limit += PAGE_STEP;
        SER.renderExplorePage(root);
        window.scrollTo(0, y);
      };
    }
  };
})();
