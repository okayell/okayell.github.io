/* 🔥 七大平台熱播專區（每週自動同步 Netflix、HBO／Max、Disney+、myVideo、愛奇藝、騰訊視頻、優酷線上熱播真人影集） */
(function () {
  'use strict';
  var SER = window.SER;
  var PAGE_STEP = 48;

  var MINE_FILTERS = [
    { id: 'all', lbl: '全部熱播劇' },
    { id: 'unwatched', lbl: '🆕 我還沒看過' },
    { id: 'watchlist', lbl: '📋 在我的待看清單' },
    { id: 'watched', lbl: '✅ 我已經看過' }
  ];

  function matchesMine(s, st) {
    var ms = SER.mineStatus(s);
    if (st === 'unwatched') return ms !== 'done';
    if (st === 'watchlist') return SER.inWatchlist(s.id);
    if (st === 'watched') return ms === 'done';
    return true;
  }

  function matchesQuery(s, qLower) {
    if (!qLower) return true;
    var hay = [
      s.title, s.origTitle, s.creator, s.network, s.country, s.statusBadge,
      (s.cast || []).join(' '), (s.platforms || []).join(' '), s.synopsis
    ].join(' ').toLowerCase();
    return hay.indexOf(qLower) !== -1;
  }

  function sortNowList(list, sortMode) {
    var out = list.slice();
    if (sortMode === 'year_desc') {
      out.sort(function (a, b) {
        return (b.year || 0) - (a.year || 0) || (b.rating || 0) - (a.rating || 0);
      });
    } else if (sortMode === 'rating_desc') {
      out.sort(function (a, b) {
        return (b.rating || 0) - (a.rating || 0) || (b.year || 0) - (a.year || 0);
      });
    } else if (sortMode === 'multi_plat') {
      out.sort(function (a, b) {
        var pa = (a.platforms || []).length;
        var pb = (b.platforms || []).length;
        return pb - pa || (b.rating || 0) - (a.rating || 0);
      });
    }
    return out;
  }

  SER.resetNowFilter = function () {
    var nf = SER.state.nowFilter;
    nf.platform = 'all';
    nf.region = 'all';
    nf.genre = 'all';
    nf.status = 'all';
    nf.q = '';
    nf.sort = 'hot';
    nf.limit = PAGE_STEP;
  };

  SER.renderNowPage = function (root) {
    var payload = SER.getNowStreamingPayload();
    var allNow = SER.getNowStreamingItems();
    var nf = SER.state.nowFilter;
    if (!nf.platform) nf.platform = 'all';
    if (!nf.region) nf.region = 'all';
    if (!nf.genre) nf.genre = 'all';
    if (!nf.status) nf.status = 'all';
    if (nf.q == null) nf.q = '';
    if (!nf.sort) nf.sort = 'hot';
    if (!nf.limit || nf.limit < PAGE_STEP) nf.limit = PAGE_STEP;

    var qLower = String(nf.q || '').trim().toLowerCase();

    function matchesExcept(s, skip) {
      if (skip !== 'platform' && nf.platform !== 'all' && (s.platforms || []).indexOf(nf.platform) === -1) return false;
      if (skip !== 'region' && nf.region !== 'all' && s.region !== nf.region) return false;
      if (skip !== 'genre' && nf.genre !== 'all' && (s.genres || []).indexOf(nf.genre) === -1) return false;
      if (skip !== 'status' && !matchesMine(s, nf.status)) return false;
      if (skip !== 'q' && !matchesQuery(s, qLower)) return false;
      return true;
    }

    var filtered = sortNowList(allNow.filter(function (s) { return matchesExcept(s, ''); }), nf.sort);
    var poolPlat = allNow.filter(function (s) { return matchesExcept(s, 'platform'); });
    var poolRegion = allNow.filter(function (s) { return matchesExcept(s, 'region'); });
    var poolGenre = allNow.filter(function (s) { return matchesExcept(s, 'genre'); });
    var poolStatus = allNow.filter(function (s) { return matchesExcept(s, 'status'); });

    var isLocalServer = !SER.isStatic();

    var platPills = '<button type="button" class="ser-pill' + (nf.platform === 'all' ? ' active' : '') + '" data-now-plat="all">全部七大平台 (' + poolPlat.length + ')</button>' +
      SER.STREAMING_PLATFORMS.map(function (p) {
        var c = poolPlat.filter(function (s) { return (s.platforms || []).indexOf(p.id) !== -1; }).length;
        var cls = 'ser-pill' + (nf.platform === p.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
        return '<button type="button" class="' + cls + '" data-now-plat="' + p.id + '">' + SER.esc(p.label) + ' (' + c + ')</button>';
      }).join('');

    var regionPills = '<button type="button" class="ser-pill' + (nf.region === 'all' ? ' active' : '') + '" data-now-region="all">全部地區 (' + poolRegion.length + ')</button>' +
      SER.REGIONS.map(function (r) {
        var c = poolRegion.filter(function (s) { return s.region === r.id; }).length;
        var cls = 'ser-pill' + (nf.region === r.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
        return '<button type="button" class="' + cls + '" data-now-region="' + r.id + '">' + SER.esc(r.label) + ' (' + c + ')</button>';
      }).join('');

    var genrePills = '<button type="button" class="ser-pill' + (nf.genre === 'all' ? ' active' : '') + '" data-now-genre="all">全部類型 (' + poolGenre.length + ')</button>' +
      SER.GENRES.map(function (g) {
        var c = poolGenre.filter(function (s) { return (s.genres || []).indexOf(g.id) !== -1; }).length;
        var tot = allNow.filter(function (s) { return (s.genres || []).indexOf(g.id) !== -1; }).length;
        if (!tot && nf.genre !== g.id) return '';
        var cls = 'ser-pill' + (nf.genre === g.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
        return '<button type="button" class="' + cls + '" data-now-genre="' + g.id + '">' + SER.esc(g.label) + ' (' + c + ')</button>';
      }).join('');

    var statusPills = MINE_FILTERS.map(function (st) {
      var c = poolStatus.filter(function (s) { return matchesMine(s, st.id); }).length;
      var cls = 'ser-pill' + (nf.status === st.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
      return '<button type="button" class="' + cls + '" data-now-status="' + st.id + '">' + st.lbl + ' (' + c + ')</button>';
    }).join('');

    function buildResultsHtml(list) {
      var visible = list.slice(0, nf.limit);
      var remaining = list.length - visible.length;
      if (!visible.length) {
        return (
          '<div class="ser-empty">' +
            '<b>目前篩選條件下沒有符合的線上熱播影集</b>' +
            '試著切換串流平台、地區分類，或清除搜尋關鍵字查看其他熱播作品。' +
            '<div style="margin-top:12px;"><button type="button" class="ser-btn ser-btn-sm ser-btn-primary" id="btnNowEmptyReset">顯示全部線上熱播影集</button></div>' +
          '</div>'
        );
      }
      var moreHtml = remaining > 0
        ? '<div class="ser-more-bar">' +
            '<button type="button" class="ser-btn ser-btn-primary" id="btnNowMore">👇 再載入 ' + Math.min(PAGE_STEP, remaining) + ' 部熱播影集（目前顯示 ' + visible.length + ' / ' + list.length + ' 部）</button>' +
            '<button type="button" class="ser-btn" id="btnNowAll">⚡ 一次展開全部 (' + list.length + ' 部)</button>' +
          '</div>'
        : '';
      return '<div class="ser-grid">' + visible.map(SER.renderCard).join('') + '</div>' + moreHtml;
    }

    var hasActive = nf.platform !== 'all' || nf.region !== 'all' || nf.genre !== 'all' || nf.status !== 'all' || !!qLower;

    root.innerHTML =
      '<div class="ser-now-banner">' +
        '<div>' +
          '<h2>🔥 七大串流平台現正熱播（每週固定自動同步）</h2>' +
          '<p>' + SER.esc(payload.scheduleNote || '每週一自動同步 Netflix 台灣站全部上架影集，以及 HBO／Max、Disney+、myVideo、愛奇藝、騰訊視頻與優酷線上熱播真人戲劇（排除電影、動漫與綜藝）。') + '</p>' +
        '</div>' +
        '<div class="ser-now-meta-pills">' +
          '<span class="ser-now-pill">📅 最近同步：' + SER.esc(payload.updatedAt || '本週最新') + '</span>' +
          (payload.weekKey ? '<span class="ser-now-pill">🗓️ 週次：' + SER.esc(payload.weekKey) + '</span>' : '') +
          '<span class="ser-now-pill">📺 線上熱播 ' + allNow.length + ' 部</span>' +
          (isLocalServer ? '<button type="button" class="ser-btn ser-btn-sm" id="btnRefreshNowStreaming">🔄 立即同步</button>' : '') +
        '</div>' +
      '</div>' +

      '<div class="ser-filter">' +
        '<div class="ser-search-row">' +
          '<input type="search" id="nowSearchInput" class="ser-input" placeholder="🔍 搜尋線上熱播片名、原文片名、導演或主演（如：慶餘年、請回答1988、怪奇物語）…" value="' + SER.esc(nf.q) + '" />' +
          '<select id="nowSortSelect" class="ser-select" aria-label="排序方式">' +
            '<option value="hot"' + (nf.sort === 'hot' ? ' selected' : '') + '>排序：本週平台熱度優先</option>' +
            '<option value="multi_plat"' + (nf.sort === 'multi_plat' ? ' selected' : '') + '>排序：多平台同步上架優先</option>' +
            '<option value="year_desc"' + (nf.sort === 'year_desc' ? ' selected' : '') + '>排序：年份最新 → 較早</option>' +
            '<option value="rating_desc"' + (nf.sort === 'rating_desc' ? ' selected' : '') + '>排序：評分高 → 低</option>' +
          '</select>' +
        '</div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">串流平台</div><div class="ser-pills">' + platPills + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">地區分類</div><div class="ser-pills">' + regionPills + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">影集類型</div><div class="ser-pills">' + genrePills + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">追劇狀態</div><div class="ser-pills">' + statusPills + '</div></div>' +
      '</div>' +

      '<div class="ser-result-bar">' +
        '<span>共找到 <b id="nowMatchCount">' + filtered.length + '</b> / ' + allNow.length + ' 部線上熱播真人影集</span>' +
        '<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">' +
          (hasActive ? '<button type="button" class="ser-link-btn" id="btnResetNowFilter">✕ 清除篩選條件</button>' : '') +
          '<button type="button" class="ser-link-btn" data-go-route="explore">🎞️ 想看跨年代神劇與分季避雷？前往經典片庫 →</button>' +
        '</div>' +
      '</div>' +

      '<div id="nowResultsBox">' + buildResultsHtml(filtered) + '</div>';

    function resetAll() {
      SER.resetNowFilter();
      SER.renderNowPage(root);
    }

    function bindMoreButtons(curList) {
      var bMore = document.getElementById('btnNowMore');
      if (bMore) {
        bMore.onclick = function () {
          var y = window.scrollY;
          nf.limit = (nf.limit || PAGE_STEP) + PAGE_STEP;
          SER.renderNowPage(root);
          window.scrollTo(0, y);
        };
      }
      var bAll = document.getElementById('btnNowAll');
      if (bAll) {
        bAll.onclick = function () {
          var y = window.scrollY;
          nf.limit = curList.length + PAGE_STEP;
          SER.renderNowPage(root);
          window.scrollTo(0, y);
        };
      }
      var bEmpty = document.getElementById('btnNowEmptyReset');
      if (bEmpty) bEmpty.onclick = resetAll;
    }
    bindMoreButtons(filtered);

    var rBtn = document.getElementById('btnResetNowFilter');
    if (rBtn) rBtn.onclick = resetAll;

    root.querySelectorAll('[data-now-plat]').forEach(function (b) {
      b.onclick = function () {
        nf.platform = b.getAttribute('data-now-plat');
        nf.limit = PAGE_STEP;
        SER.renderNowPage(root);
      };
    });
    root.querySelectorAll('[data-now-region]').forEach(function (b) {
      b.onclick = function () {
        nf.region = b.getAttribute('data-now-region');
        nf.limit = PAGE_STEP;
        SER.renderNowPage(root);
      };
    });
    root.querySelectorAll('[data-now-genre]').forEach(function (b) {
      b.onclick = function () {
        nf.genre = b.getAttribute('data-now-genre');
        nf.limit = PAGE_STEP;
        SER.renderNowPage(root);
      };
    });
    root.querySelectorAll('[data-now-status]').forEach(function (b) {
      b.onclick = function () {
        nf.status = b.getAttribute('data-now-status');
        nf.limit = PAGE_STEP;
        SER.renderNowPage(root);
      };
    });

    var sortSel = document.getElementById('nowSortSelect');
    if (sortSel) {
      sortSel.onchange = function () {
        nf.sort = sortSel.value;
        nf.limit = PAGE_STEP;
        SER.renderNowPage(root);
      };
    }

    var searchInp = document.getElementById('nowSearchInput');
    if (searchInp) {
      var composing = false;
      var applyLive = function () {
        nf.q = searchInp.value;
        nf.limit = PAGE_STEP;
        qLower = String(nf.q || '').trim().toLowerCase();
        var nextList = sortNowList(allNow.filter(function (s) { return matchesExcept(s, ''); }), nf.sort);
        var box = document.getElementById('nowResultsBox');
        var cnt = document.getElementById('nowMatchCount');
        if (box) box.innerHTML = buildResultsHtml(nextList);
        if (cnt) cnt.textContent = String(nextList.length);
        bindMoreButtons(nextList);
      };
      searchInp.addEventListener('compositionstart', function () { composing = true; });
      searchInp.addEventListener('compositionend', function () { composing = false; applyLive(); });
      searchInp.addEventListener('input', function () {
        if (!composing) applyLive();
      });
    }

    var refreshBtn = document.getElementById('btnRefreshNowStreaming');
    if (refreshBtn) {
      refreshBtn.onclick = function () {
        refreshBtn.disabled = true;
        refreshBtn.textContent = '⏳ 正在同步七大平台…';
        fetch(SER.apiBase() + 'now_streaming/refresh', { method: 'POST' })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            var d = (res && res.data) ? res.data : res;
            if (res && res.ok && d && Array.isArray(d.items)) {
              window.SER_NOW_STREAMING = d;
              SER.invalidateNowCache();
              SER.syncHeaderBadges();
              SER.toast('✅ 已同步最新七大串流平台熱播影集（共 ' + d.items.length + ' 部）');
              SER.renderNowPage(root);
            } else {
              throw new Error((res && res.error) || '同步失敗');
            }
          })
          .catch(function (err) {
            refreshBtn.disabled = false;
            refreshBtn.textContent = '🔄 立即同步';
            SER.toast('⚠️ 同步失敗：' + err.message);
          });
      };
    }
  };
})();
