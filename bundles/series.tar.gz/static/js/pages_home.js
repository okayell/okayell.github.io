/* 🏠 首頁：選片雷達（今晚看什麼）、七大串流平台熱播入口、精選榜單與七大地區導覽 */
(function () {
  'use strict';
  var SER = window.SER;

  function topBy(list, n, cmp) {
    return list.slice().sort(cmp).slice(0, n);
  }
  function byRating(a, b) { return (b.rating || 0) - (a.rating || 0) || (b.startYear || 0) - (a.startYear || 0); }

  function shuffleSeeded(list, seed) {
    var arr = list.slice();
    var x = (seed * 9301 + 49297) % 233280;
    for (var i = arr.length - 1; i > 0; i--) {
      x = (x * 9301 + 49297) % 233280;
      var j = Math.floor((x / 233280) * (i + 1));
      var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  }

  function pickerPool() {
    var pk = SER.state.picker;
    var len = SER.LENGTH_MAP[pk.length];
    return SER.getCatalog().filter(function (s) {
      if (SER.mineStatus(s) === 'done') return false;
      if (len && !len.test(SER.hours(s))) return false;
      if (pk.genre !== 'all' && (s.genres || []).indexOf(pk.genre) === -1) return false;
      if (pk.region !== 'all' && s.region !== pk.region) return false;
      if (pk.safe) {
        var v = (s.ending && s.ending.verdict) || '';
        if (v !== 'perfect' && v !== 'good') return false;
      }
      return true;
    });
  }

  function pickerResultHtml() {
    var pk = SER.state.picker;
    var pool = pickerPool();
    if (!pool.length) {
      return '<div class="ser-empty"><b>這個組合目前沒有符合的作品</b>放寬一個條件，或關掉「只要收尾好評」再試一次。</div>';
    }
    var strong = pool.filter(function (s) { return (s.rating || 0) >= 8.3; });
    var base = strong.length >= 3 ? strong : pool;
    var picks = shuffleSeeded(base, pk.seed + base.length).slice(0, 3);
    return (
      '<div class="ser-result-bar"><span>符合條件 <b>' + pool.length + '</b> 部，先推薦這 ' + picks.length + ' 部：</span>' +
      (pool.length > 3 ? '<button type="button" class="ser-link-btn" id="pkShuffle">🔄 換一批</button>' : '') + '</div>' +
      '<div class="ser-grid">' + picks.map(SER.renderCard).join('') + '</div>'
    );
  }

  function pills(attr, cur, items) {
    return items.map(function (it) {
      return '<button type="button" class="ser-pill' + (cur === it.id ? ' active' : '') + '" ' + attr + '="' + it.id + '">' + SER.esc(it.label) + '</button>';
    }).join('');
  }

  var watchCache = null;
  function watchHtml(rep) {
    if (!rep || !rep.ok) return '';
    var items = rep.items || [];
    var head = '🛠️ 每週片庫巡檢（' + SER.esc(rep.checkedAt || '') + '，比對 ' + SER.esc(rep.matched) + '/' + SER.esc(rep.total) + ' 部）：';
    if (!items.length) return '<div class="ser-watch ok">' + head + '目前沒有需要更新的作品。</div>';
    return '<div class="ser-watch">' + head + '<b>' + items.length + ' 部待更新</b><ul>' + items.map(function (it) {
      return '<li><button type="button" class="ser-link-btn" data-open-series="' + SER.esc(it.id) + '">' + SER.esc(it.title) + '</button>　' + SER.esc(it.detail) + '</li>';
    }).join('') + '</ul><span class="ser-note">僅本機版顯示。更新內容後執行 tools/watch_updates.py；若只是計集方式不同，用 --ack 標記。</span></div>';
  }
  SER.renderWatchNotice = function () {
    var box = document.getElementById('serWatchBox');
    if (!box || SER.isStatic()) return;
    if (watchCache) { box.innerHTML = watchHtml(watchCache); return; }
    fetch(SER.apiBase() + 'watch')
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (rep) {
        watchCache = rep || { ok: false };
        var cur = document.getElementById('serWatchBox');
        if (cur) cur.innerHTML = watchHtml(watchCache);
      })
      .catch(function () { watchCache = { ok: false }; });
  };

  SER.renderHomePage = function (root) {
    var cat = SER.getCatalog();
    var allNow = SER.getNowStreamingItems();
    var nowPayload = SER.getNowStreamingPayload();
    var pk = SER.state.picker;
    var multi = cat.filter(function (s) { return (s.seasons || []).length > 1; });
    var safeCnt = cat.filter(function (s) { var v = s.ending && s.ending.verdict; return v === 'perfect' || v === 'good'; }).length;

    var perfect = topBy(cat.filter(function (s) { return s.ending && s.ending.verdict === 'perfect'; }), 6, byRating);
    var weekend = topBy(cat.filter(function (s) { return SER.hours(s) <= 12 && s.status !== 'ongoing'; }), 6, byRating);
    var cnPicks = topBy(cat.filter(function (s) { return s.region === 'cn'; }), 6, byRating);

    var platTiles = SER.STREAMING_PLATFORMS.map(function (p) {
      var cnt = allNow.filter(function (s) { return (s.platforms || []).indexOf(p.id) !== -1; }).length;
      return (
        '<button type="button" class="ser-now-plat-tile" style="border-top-color:' + p.color + '" data-home-now-plat="' + p.id + '">' +
          '<b>' + SER.esc(p.label) + '</b>' +
          '<span>線上熱播真人影集</span>' +
          '<em>' + cnt + ' 部熱播中 →</em>' +
        '</button>'
      );
    }).join('');

    var regionTiles = SER.REGIONS.map(function (r) {
      var nClassic = cat.filter(function (s) { return s.region === r.id; }).length;
      var nNow = allNow.filter(function (s) { return s.region === r.id; }).length;
      if (!nClassic && !nNow) return '';
      return (
        '<button type="button" class="ser-region-tile" data-home-region="' + r.id + '">' +
          '<b>' + SER.esc(r.label) + '</b>' +
          '<span>' + SER.esc(r.desc) + '</span>' +
          '<em>經典 ' + nClassic + ' 部 · 熱播 ' + nNow + ' 部 →</em>' +
        '</button>'
      );
    }).join('');

    function row(title, sub, list, moreAttr) {
      if (!list.length) return '';
      return (
        '<div class="ser-sec-hd"><div><h2>' + title + '</h2><div class="ser-sec-sub">' + sub + '</div></div>' +
        (moreAttr ? '<button type="button" class="ser-link-btn" ' + moreAttr + '>看全部 →</button>' : '') + '</div>' +
        '<div class="ser-grid">' + list.map(SER.renderCard).join('') + '</div>'
      );
    }

    root.innerHTML =
      '<div id="serWatchBox"></div>' +
      '<section class="ser-hero">' +
        '<h1>📺 七大平台現在播什麼？哪一部經典值得追到最後？</h1>' +
        '<p>每週自動同步 Netflix、HBO／Max、Disney+、myVideo、愛奇藝、騰訊視頻與優酷線上熱播真人影集；同時收錄陸劇、韓劇、台劇、日劇、美劇、英劇與歐陸跨年代經典分季無雷導讀。</p>' +
        '<div class="ser-hero-stats">' +
          '<div class="ser-hero-stat"><b>' + allNow.length + '</b><span>部七大平台熱播</span></div>' +
          '<div class="ser-hero-stat"><b>' + cat.length + '</b><span>部跨年代經典導讀</span></div>' +
          '<div class="ser-hero-stat"><b>' + multi.length + '</b><span>部分季口碑走勢</span></div>' +
          '<div class="ser-hero-stat"><b>' + safeCnt + '</b><span>部收尾好評可放心追</span></div>' +
        '</div>' +
        '<div class="ser-hero-cta">' +
          '<button type="button" class="ser-btn ser-btn-primary" data-go-route="now">🔥 逛七大平台熱播</button>' +
          '<button type="button" class="ser-btn" data-go-route="explore">🎞️ 逛跨年代經典片庫</button>' +
          '<button type="button" class="ser-btn" data-go-route="radar">📊 分季避雷雷達</button>' +
        '</div>' +
      '</section>' +

      '<div class="ser-sec-hd">' +
        '<div><h2>🔥 七大串流平台現正熱播直達</h2><div class="ser-sec-sub">每週自動更新（最近同步：' + SER.esc(nowPayload.updatedAt || '本週最新') + '），點擊任一平台直接篩選目前在線上的真人影集</div></div>' +
        '<button type="button" class="ser-link-btn" data-go-route="now">查看全部 ' + allNow.length + ' 部熱播劇 →</button>' +
      '</div>' +
      '<div class="ser-now-plat-grid">' + platTiles + '</div>' +

      '<div class="ser-sec-hd"><div><h2>🎯 選片雷達：今晚看什麼？</h2><div class="ser-sec-sub">依可投入的時間、想看的類型與地區，從跨年代經典片庫還沒看完的作品裡挑三部給你</div></div></div>' +
      '<div class="ser-filter ser-picker">' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">時間</div><div class="ser-pills">' +
          pills('data-pk-length', pk.length, [{ id: 'all', label: '不限' }].concat(SER.LENGTHS)) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">類型</div><div class="ser-pills">' +
          pills('data-pk-genre', pk.genre, [{ id: 'all', label: '不限' }].concat(SER.GENRES)) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">地區</div><div class="ser-pills">' +
          pills('data-pk-region', pk.region, [{ id: 'all', label: '不限' }].concat(SER.REGIONS)) + '</div></div>' +
        '<div class="ser-filter-row"><div class="ser-filter-lbl">避雷</div><div class="ser-pills">' +
          '<button type="button" class="ser-pill' + (pk.safe ? ' active' : '') + '" id="pkSafe">' + (pk.safe ? '✅ 只要收尾好評（神收尾／好好收尾）' : '☐ 只要收尾好評（神收尾／好好收尾）') + '</button></div></div>' +
        '<div class="ser-picker-result" id="pkResult">' + pickerResultHtml() + '</div>' +
      '</div>' +

      row('🏮 陸劇口碑經典必看', '古裝權謀、迷霧懸疑短劇與當代高分代表作', cnPicks, 'data-home-region="cn"') +
      row('🏆 收尾滿分神劇', '結局備受推崇，可以毫無顧慮投入的作品', perfect, 'data-home-verdict="perfect"') +
      row('🛋️ 一個週末追完', '12 小時內看完的完結作品與迷你影集', weekend, 'data-home-length="weekend"') +

      '<div class="ser-sec-hd"><div><h2>🌍 依七大地區逛經典片庫</h2><div class="ser-sec-sub">陸劇、韓劇、台劇、日劇、美劇、英劇與歐陸影集各自擁有獨特的敘事節奏與集數規格</div></div></div>' +
      '<div class="ser-region-grid">' + regionTiles + '</div>' +
      '<p class="ser-disclaimer">影集海報圖片來源：JustWatch、各串流平台公開海報、TVmaze、Wikipedia，版權屬各出品方所有；推薦指數為編輯主觀整理，僅供選片參考。</p>';

    function rerenderPicker() { SER.renderHomePage(root); }
    SER.renderWatchNotice();
    root.querySelectorAll('[data-pk-length]').forEach(function (b) {
      b.onclick = function () { pk.length = b.getAttribute('data-pk-length'); pk.seed = 0; rerenderPicker(); };
    });
    root.querySelectorAll('[data-pk-genre]').forEach(function (b) {
      b.onclick = function () { pk.genre = b.getAttribute('data-pk-genre'); pk.seed = 0; rerenderPicker(); };
    });
    root.querySelectorAll('[data-pk-region]').forEach(function (b) {
      b.onclick = function () { pk.region = b.getAttribute('data-pk-region'); pk.seed = 0; rerenderPicker(); };
    });
    var safeBtn = document.getElementById('pkSafe');
    if (safeBtn) safeBtn.onclick = function () { pk.safe = !pk.safe; pk.seed = 0; rerenderPicker(); };
    var shBtn = document.getElementById('pkShuffle');
    if (shBtn) {
      shBtn.onclick = function () {
        pk.seed += 1;
        var box = document.getElementById('pkResult');
        if (box) box.innerHTML = pickerResultHtml();
        var again = document.getElementById('pkShuffle');
        if (again) again.onclick = shBtn.onclick;
      };
    }

    root.querySelectorAll('[data-home-now-plat]').forEach(function (b) {
      b.onclick = function () {
        if (typeof SER.resetNowFilter === 'function') SER.resetNowFilter();
        SER.state.nowFilter.platform = b.getAttribute('data-home-now-plat');
        window.location.hash = '#/now';
      };
    });

    function goExplore(patch) {
      SER.resetExplore();
      Object.keys(patch).forEach(function (k) { SER.state.explore[k] = patch[k]; });
      window.location.hash = '#/explore';
    }
    root.querySelectorAll('[data-home-region]').forEach(function (b) {
      b.onclick = function () { goExplore({ region: b.getAttribute('data-home-region') }); };
    });
    root.querySelectorAll('[data-home-verdict]').forEach(function (b) {
      b.onclick = function () { goExplore({ verdict: b.getAttribute('data-home-verdict') }); };
    });
    root.querySelectorAll('[data-home-length]').forEach(function (b) {
      b.onclick = function () { goExplore({ length: b.getAttribute('data-home-length') }); };
    });
    root.querySelectorAll('[data-home-sort]').forEach(function (b) {
      b.onclick = function () { goExplore({ sort: b.getAttribute('data-home-sort') }); };
    });
  };
})();
