/* 📋 我的追劇護照：追劇中（分季蓋章）、待看清單、已看完、統計與備份 */
(function () {
  'use strict';
  var SER = window.SER;

  function passHtml(s) {
    var p = SER.getProgress(s.id) || { s: {} };
    var total = (s.seasons || []).length;
    var seen = SER.seenCount(s);
    var pct = total ? Math.round((seen / total) * 100) : 0;
    var ms = SER.mineStatus(s);
    var stamps = (s.seasons || []).map(function (se, i) {
      var on = !!(p.s && p.s[i]);
      return '<button type="button" class="ser-stamp' + (on ? ' on' : '') + '" data-stamp-id="' + SER.esc(s.id) + '" data-stamp-idx="' + i + '" title="' + SER.esc(se.eps) + ' 集">' + (on ? '✅ ' : '') + SER.esc(SER.seasonLabel(se)) + '</button>';
    }).join('');
    var stars = p.rating ? ' · 我的評分 ' + '★'.repeat(p.rating) : '';
    var next = '';
    if (ms === 'watching') {
      for (var i = 0; i < total; i++) {
        if (!(p.s && p.s[i])) { next = '下一站：' + SER.seasonLabel(s.seasons[i]) + '（' + s.seasons[i].eps + ' 集）'; break; }
      }
    }
    return (
      '<div class="ser-pass">' +
        '<div class="ser-pass-hd">' +
          '<div><span class="ser-pass-title" data-open-series="' + SER.esc(s.id) + '">' + SER.esc(s.title) + '</span> ' + SER.verdictChip(s) +
            '<div class="ser-pass-meta">' + SER.esc((SER.REGION_MAP[s.region] || {}).short || '') + ' · ' + SER.esc(SER.yearsLabel(s)) + ' · ' + SER.esc(s.episodes) + ' 集 · ' + SER.esc(SER.hoursLabel(s)) + SER.esc(stars) + '</div></div>' +
          '<div class="ser-pass-meta"><b>' + SER.seenEpisodes(s) + '</b>／' + SER.esc(s.episodes) + ' 集' + (next ? '　' + SER.esc(next) : '') + '</div>' +
        '</div>' +
        '<div class="ser-progress' + (ms === 'done' ? ' done' : '') + '"><i style="width:' + pct + '%"></i></div>' +
        '<div class="ser-stamps">' + stamps + '</div>' +
        (p.note ? '<div class="ser-pass-note">📝 ' + SER.esc(p.note) + '</div>' : '') +
      '</div>'
    );
  }

  SER.renderMyListPage = function (root) {
    var cat = SER.getTrackedPool();
    var st = SER.myStats();
    var tab = SER.state.myTab;
    if (['watching', 'watchlist', 'done'].indexOf(tab) === -1) tab = SER.state.myTab = 'watching';

    var groups = { watching: [], watchlist: [], done: [] };
    cat.forEach(function (s) {
      var ms = SER.mineStatus(s);
      if (groups[ms]) groups[ms].push(s);
    });
    var updated = function (s) { var p = SER.getProgress(s.id); return (p && p.updatedAt) || ''; };
    groups.watching.sort(function (a, b) { return updated(b).localeCompare(updated(a)); });
    groups.done.sort(function (a, b) { return updated(b).localeCompare(updated(a)); });
    groups.watchlist.sort(function (a, b) {
      var wa = SER.state.watchlist[a.id] || {}; var wb = SER.state.watchlist[b.id] || {};
      return String(wb.addedAt || '').localeCompare(String(wa.addedAt || '')) || (b.rating || 0) - (a.rating || 0);
    });

    var body;
    var list = groups[tab];
    if (!list.length) {
      var emptyMsg = {
        watching: '<b>目前沒有追到一半的影集</b>在任何作品的導讀裡幫看完的季數蓋章，就會出現在這裡。',
        watchlist: '<b>待看清單是空的</b>到片庫按「➕ 加入待看」，把想看的作品先存起來。',
        done: '<b>還沒有全部看完的作品</b>把每一季都蓋章，或直接按「👀 標記看完」。'
      }[tab];
      body = '<div class="ser-empty">' + emptyMsg + '<div style="margin-top:12px;"><button type="button" class="ser-btn ser-btn-primary" data-go-route="explore">🎞️ 去逛片庫</button></div></div>';
    } else if (tab === 'watchlist') {
      var hrs = 0;
      list.forEach(function (s) { hrs += SER.hours(s); });
      body = '<div class="ser-result-bar"><span>待看 <b>' + list.length + '</b> 部，全部看完約需 <b>' + hrs + '</b> 小時</span></div>' +
        '<div class="ser-grid">' + list.map(SER.renderCard).join('') + '</div>';
    } else {
      body = '<div class="ser-pass-list">' + list.map(passHtml).join('') + '</div>';
    }

    root.innerHTML =
      '<div class="ser-sec-hd"><div><h2>📋 我的追劇護照</h2><div class="ser-sec-sub">紀錄只存在這台裝置的瀏覽器，不需要帳號；換裝置前可用下方的備份功能帶走</div></div></div>' +
      '<div class="ser-stats-row">' +
        '<div class="ser-stat-box"><b>' + st.watching + '</b><span>▶ 追劇中</span></div>' +
        '<div class="ser-stat-box"><b>' + st.watchlist + '</b><span>📋 待看</span></div>' +
        '<div class="ser-stat-box"><b>' + st.done + '</b><span>✅ 已看完</span></div>' +
        '<div class="ser-stat-box"><b>' + st.episodes.toLocaleString() + '</b><span>🎬 累計看過集數</span></div>' +
        '<div class="ser-stat-box"><b>' + st.hours.toLocaleString() + '</b><span>⏱️ 累計追劇時數</span></div>' +
      '</div>' +
      '<div class="ser-subtabs">' +
        '<button type="button" class="ser-pill' + (tab === 'watching' ? ' active' : '') + '" data-my-tab="watching">▶ 追劇中 (' + groups.watching.length + ')</button>' +
        '<button type="button" class="ser-pill' + (tab === 'watchlist' ? ' active' : '') + '" data-my-tab="watchlist">📋 待看 (' + groups.watchlist.length + ')</button>' +
        '<button type="button" class="ser-pill' + (tab === 'done' ? ' active' : '') + '" data-my-tab="done">✅ 已看完 (' + groups.done.length + ')</button>' +
      '</div>' +
      body +
      '<div class="ser-backup">' +
        '<button type="button" class="ser-btn ser-btn-sm" id="myExport">⬇️ 匯出備份檔</button>' +
        '<button type="button" class="ser-btn ser-btn-sm" id="myImport">⬆️ 匯入備份檔</button>' +
        '<input type="file" id="myImportFile" accept="application/json,.json" style="display:none;" />' +
        '<span class="ser-note">匯入會與現有紀錄合併，不會清空。</span>' +
      '</div>';

    root.querySelectorAll('[data-my-tab]').forEach(function (b) {
      b.onclick = function () { SER.state.myTab = b.getAttribute('data-my-tab'); SER.renderMyListPage(root); };
    });
    root.querySelectorAll('[data-stamp-id]').forEach(function (b) {
      b.onclick = function () {
        SER.toggleSeason(b.getAttribute('data-stamp-id'), Number(b.getAttribute('data-stamp-idx')));
        SER.syncHeaderBadges();
        SER.renderMyListPage(root);
      };
    });
    var exp = document.getElementById('myExport');
    if (exp) {
      exp.onclick = function () {
        try {
          var blob = new Blob([SER.exportBackup()], { type: 'application/json' });
          var a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'series-passport-' + new Date().toISOString().slice(0, 10) + '.json';
          document.body.appendChild(a);
          a.click();
          setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
        } catch (e) {
          SER.toast('匯出失敗，請改用其他瀏覽器再試一次');
        }
      };
    }
    var imp = document.getElementById('myImport');
    var file = document.getElementById('myImportFile');
    if (imp && file) {
      imp.onclick = function () { file.click(); };
      file.onchange = function () {
        var f = file.files && file.files[0];
        if (!f) return;
        var reader = new FileReader();
        reader.onload = function () {
          try {
            SER.importBackup(String(reader.result || ''));
            SER.toast('✅ 已匯入追劇護照備份');
            SER.syncHeaderBadges();
            SER.renderMyListPage(root);
          } catch (e) {
            SER.toast('這不是串流與影集學院的備份檔');
          }
        };
        reader.readAsText(f);
      };
    }
  };
})();
