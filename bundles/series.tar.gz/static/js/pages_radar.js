/* 📊 分季避雷雷達（口碑走勢＋收尾評價）與 📡 首播平台索引 */
(function () {
  'use strict';
  var SER = window.SER;

  function radarCard(s) {
    var bw = SER.bestWorst(s);
    var trend = SER.TREND_MAP[SER.trendOf(s)];
    var gap = bw.best.score - bw.worst.score;
    var txt = '口碑高點在' + SER.seasonLabel(bw.best) + '（' + bw.best.score.toFixed(1) + '）';
    if (gap >= 0.3) txt += '，低點在' + SER.seasonLabel(bw.worst) + '（' + bw.worst.score.toFixed(1) + '）';
    else txt += '，各季差距不到 0.3 分';
    return (
      '<div class="ser-radar-card" data-open-series="' + SER.esc(s.id) + '">' +
        '<div class="ser-radar-hd"><b>' + SER.esc(s.title) + '</b><span>' + SER.esc(SER.yearsLabel(s)) + ' · ' + SER.esc(s.seasonsCount) + ' 季 ' + SER.esc(s.episodes) + ' 集</span></div>' +
        SER.seasonBars(s) +
        '<div class="ser-radar-txt">' + SER.esc(txt) + '。</div>' +
        '<div class="ser-radar-foot">' +
          (trend ? '<span class="ser-chip">' + SER.esc(trend.label) + '</span>' : '') +
          SER.verdictChip(s) +
          '<span class="ser-chip">' + SER.esc((SER.REGION_MAP[s.region] || {}).short || '') + '</span>' +
        '</div>' +
      '</div>'
    );
  }

  function trendTab() {
    var multi = SER.getCatalog().filter(function (s) { return (s.seasons || []).length > 1; });
    var cur = SER.state.radarTrend;
    var pillsHtml = '<button type="button" class="ser-pill' + (cur === 'all' ? ' active' : '') + '" data-trend="all">全部 (' + multi.length + ')</button>' +
      SER.TRENDS.map(function (t) {
        var c = multi.filter(function (s) { return SER.trendOf(s) === t.id; }).length;
        return '<button type="button" class="ser-pill' + (cur === t.id ? ' active' : '') + (c ? '' : ' is-zero') + '" data-trend="' + t.id + '">' + SER.esc(t.label) + ' (' + c + ')</button>';
      }).join('');
    var list = multi.filter(function (s) { return cur === 'all' || SER.trendOf(s) === cur; });
    list.sort(function (a, b) {
      if (cur === 'falling') {
        var ga = SER.bestWorst(a); var gb = SER.bestWorst(b);
        return (gb.best.score - gb.worst.score) - (ga.best.score - ga.worst.score);
      }
      return (b.rating || 0) - (a.rating || 0);
    });
    var desc = cur === 'all'
      ? '長條越高代表該季口碑越好：綠色是全劇高點，橘色與紅色是需要留意的低谷。點卡片可看每一季的無雷導讀。'
      : (SER.TREND_MAP[cur] || {}).desc || '';
    return (
      '<div class="ser-filter"><div class="ser-filter-row"><div class="ser-filter-lbl">走勢</div><div class="ser-pills">' + pillsHtml + '</div></div>' +
      '<p class="ser-note" style="margin-top:6px;">' + SER.esc(desc) + '</p></div>' +
      '<div class="ser-result-bar"><span>共 <b>' + list.length + '</b> 部多季作品</span></div>' +
      (list.length ? '<div class="ser-radar-list">' + list.map(radarCard).join('') + '</div>'
        : '<div class="ser-empty"><b>這個分類目前沒有作品</b></div>')
    );
  }

  function endingTab() {
    var cat = SER.getCatalog();
    return SER.VERDICTS.map(function (v) {
      var list = cat.filter(function (s) { return s.ending && s.ending.verdict === v.id; })
        .sort(function (a, b) { return (b.rating || 0) - (a.rating || 0); });
      if (!list.length) return '';
      return (
        '<div class="ser-panel ser-verdict-sec">' +
          '<div class="ser-verdict-hd"><b>' + SER.esc(v.label) + '</b><span class="ser-chip ' + v.cls + '">' + list.length + ' 部</span><span class="ser-note">' + SER.esc(v.desc) + '</span></div>' +
          '<div class="ser-verdict-list">' + list.map(function (s) {
            return '<button type="button" class="ser-verdict-item" data-open-series="' + SER.esc(s.id) + '"><b>' + SER.esc(s.title) + '　<span style="display:inline;color:#64748b;font-weight:700;">' + SER.esc(SER.yearsLabel(s)) + '</span></b><span>' + SER.esc((s.ending && s.ending.note) || '') + '</span></button>';
          }).join('') + '</div>' +
        '</div>'
      );
    }).join('');
  }

  SER.renderRadarPage = function (root) {
    var tab = SER.state.radarTab;
    root.innerHTML =
      '<div class="ser-sec-hd"><div><h2>📊 分季避雷雷達</h2><div class="ser-sec-sub">入坑前先看兩件事：哪幾季最精彩、哪幾季口碑下滑，以及這部作品有沒有好好收尾（全程無雷）</div></div></div>' +
      '<div class="ser-subtabs">' +
        '<button type="button" class="ser-pill' + (tab === 'trend' ? ' active' : '') + '" data-radar-tab="trend">📈 分季口碑走勢</button>' +
        '<button type="button" class="ser-pill' + (tab === 'ending' ? ' active' : '') + '" data-radar-tab="ending">🏁 收尾評價總覽</button>' +
      '</div>' +
      (tab === 'ending' ? endingTab() : trendTab()) +
      '<p class="ser-disclaimer">分季口碑指數與收尾評價為編輯綜合各方評價後的主觀整理，僅供選片參考，不代表任何評分網站的數據。</p>';
    root.querySelectorAll('[data-radar-tab]').forEach(function (b) {
      b.onclick = function () { SER.state.radarTab = b.getAttribute('data-radar-tab'); SER.renderRadarPage(root); };
    });
    root.querySelectorAll('[data-trend]').forEach(function (b) {
      b.onclick = function () { SER.state.radarTrend = b.getAttribute('data-trend'); SER.renderRadarPage(root); };
    });
  };

  SER.renderPlatformsPage = function (root) {
    var allNow = SER.getNowStreamingItems();
    var nowCards = SER.STREAMING_PLATFORMS.map(function (p) {
      var list = allNow.filter(function (s) { return (s.platforms || []).indexOf(p.id) !== -1; });
      var regs = {};
      list.forEach(function (s) { regs[s.region] = (regs[s.region] || 0) + 1; });
      var regChips = SER.REGIONS.filter(function (r) { return regs[r.id]; })
        .map(function (r) { return '<span class="ser-chip">' + SER.esc(r.short) + ' ' + regs[r.id] + '</span>'; }).join('');
      var top = list.slice(0, 5).map(function (s) {
        return '<li data-open-series="' + SER.esc(s.id) + '"><b>' + SER.esc(s.title) + '</b><span>' + SER.esc(s.statusBadge || '熱播中') + ' · ★ ' + Number(s.rating || 0).toFixed(1) + '</span></li>';
      }).join('');
      return (
        '<div class="ser-plat-card" style="border-top-color:' + p.color + '">' +
          '<div class="ser-plat-hd"><b>' + SER.esc(p.label) + '</b><span class="ser-plat-chip ' + p.cls + '">線上熱播 ' + list.length + ' 部</span></div>' +
          '<div class="ser-plat-desc">' + SER.esc(p.desc) + '</div>' +
          '<div class="ser-plat-nets">' + regChips + '</div>' +
          (top ? '<ul class="ser-plat-top">' + top + '</ul>' : '') +
          '<button type="button" class="ser-btn ser-btn-sm ser-btn-primary" data-now-plat-jump="' + p.id + '">🔥 看 ' + SER.esc(p.label) + ' 全部 ' + list.length + ' 部熱播影集 →</button>' +
        '</div>'
      );
    }).join('');

    var cat = SER.getCatalog();
    var cards = SER.PLATFORMS.map(function (p) {
      var list = cat.filter(function (s) { return s.platform === p.id; })
        .sort(function (a, b) { return (b.rating || 0) - (a.rating || 0); });
      if (!list.length) return '';
      var nets = {};
      list.forEach(function (s) { nets[s.network] = (nets[s.network] || 0) + 1; });
      var netChips = Object.keys(nets).sort(function (a, b) { return nets[b] - nets[a] || a.localeCompare(b); })
        .map(function (n) { return '<span class="ser-chip">' + SER.esc(n) + ' ' + nets[n] + '</span>'; }).join('');
      var safe = list.filter(function (s) { var v = s.ending && s.ending.verdict; return v === 'perfect' || v === 'good'; }).length;
      var top = list.slice(0, 6).map(function (s) {
        return '<li data-open-series="' + SER.esc(s.id) + '"><b>' + SER.esc(s.title) + '</b><span>★ ' + Number(s.rating || 0).toFixed(1) + ' · ' + SER.esc(SER.hoursLabel(s)) + '</span></li>';
      }).join('');
      return (
        '<div class="ser-plat-card" style="border-top-color:' + p.color + '">' +
          '<div class="ser-plat-hd"><b>' + SER.esc(p.label) + '</b><span class="ser-chip genre">經典 ' + list.length + ' 部</span></div>' +
          '<div class="ser-plat-desc">' + SER.esc(p.desc) + '｜其中 ' + safe + ' 部收尾好評</div>' +
          '<div class="ser-plat-nets">' + netChips + '</div>' +
          '<ul class="ser-plat-top">' + top + '</ul>' +
          '<button type="button" class="ser-btn ser-btn-sm" data-plat-all="' + p.id + '">看這個首播平台的全部 ' + list.length + ' 部經典 →</button>' +
        '</div>'
      );
    }).join('');
    root.innerHTML =
      '<div class="ser-sec-hd"><div><h2>🔥 七大串流平台目前線上熱播索引</h2><div class="ser-sec-sub">每週自動抓取目前正在台灣站與各大華語串流平台上架播出的真人戲劇影集</div></div></div>' +
      '<div class="ser-plat-grid">' + nowCards + '</div>' +
      '<div class="ser-sec-hd"><div><h2>📡 跨年代經典片庫：首播平台與電視台索引</h2><div class="ser-sec-sub">依「最初在哪裡首播」整理歷年代表作，快速認識各平台與電視台的製作風格</div></div></div>' +
      '<div class="ser-plat-grid">' + cards + '</div>' +
      '<p class="ser-disclaimer">上方「七大串流平台熱播」每週自動同步目前線上可觀看的真人影集；下方「首播平台」則標示跨年代經典作品最初問世的出品頻道。</p>';
    root.querySelectorAll('[data-now-plat-jump]').forEach(function (b) {
      b.onclick = function () {
        if (typeof SER.resetNowFilter === 'function') SER.resetNowFilter();
        SER.state.nowFilter.platform = b.getAttribute('data-now-plat-jump');
        window.location.hash = '#/now';
      };
    });
    root.querySelectorAll('[data-plat-all]').forEach(function (b) {
      b.onclick = function () {
        SER.resetExplore();
        SER.state.explore.platform = b.getAttribute('data-plat-all');
        window.location.hash = '#/explore';
      };
    });
  };
})();
