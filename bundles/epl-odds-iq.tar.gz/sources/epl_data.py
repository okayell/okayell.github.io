#!/usr/bin/env python3
"""Live 2026-27 Premier League Fixtures, DraftKings Open/Close Odds, Boxscores & FPL xG/Injuries."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt
import json
import sqlite3
from typing import Any

import config
import net
import teams

FPL_BOOTSTRAP = 'https://fantasy.premierleague.com/api/bootstrap-static/'
FPL_FIXTURES = 'https://fantasy.premierleague.com/api/fixtures/'
ESPN_SB_TPL = 'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard?dates={ymd}'
ESPN_SUMMARY_TPL = 'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/summary?event={gid}'
ESPN_ODDS_TPL = (
    'https://sports.core.api.espn.com/v2/sports/soccer/leagues/eng.1/'
    'events/{gid}/competitions/{gid}/odds?lang=en&region=us'
)

POS_MAP = {1: 'GK', 2: 'DEF', 3: 'MID', 4: 'FWD'}


def _am_to_dec(am: Any, fallback: float = 0.0) -> float:
  if am is None or am == '':
    return fallback
  try:
    v = float(am)
  except (TypeError, ValueError):
    return fallback
  if v == 0:
    return fallback
  if v > 0:
    return round(1.0 + v / 100.0, 2)
  return round(1.0 + 100.0 / abs(v), 2)


def _iso_to_tw(iso_str: str) -> tuple[str, str, str]:
  s = (iso_str or '').strip()
  if not s:
    return '', '', ''
  if s.endswith('Z'):
    s = s[:-1] + '+00:00'
  try:
    d_utc = dt.datetime.fromisoformat(s)
    if d_utc.tzinfo is None:
      d_utc = d_utc.replace(tzinfo=config.TZ_UTC)
    d_tw = d_utc.astimezone(config.TZ_TW)
    return d_tw.strftime('%Y-%m-%d %H:%M'), d_tw.strftime('%Y-%m-%d'), d_utc.strftime('%Y-%m-%d')
  except ValueError:
    return s[:16], s[:10], s[:10]


def _parse_spread_val(raw: Any) -> float | None:
  if raw is None or raw == '':
    return None
  s = str(raw).strip().upper()
  if s in ('PK', 'PICK', 'EVEN', '0', '0.0'):
    return 0.0
  try:
    return float(s)
  except ValueError:
    return None


def _extract_odds_dict(item: dict[str, Any]) -> dict[str, Any]:
  ho = item.get('homeTeamOdds') or {}
  ao = item.get('awayTeamOdds') or {}
  do = item.get('drawOdds') or {}

  close_sp = _parse_spread_val(
      (((ho.get('close') or ho.get('current') or {}).get('pointSpread') or {}).get('american'))
      or item.get('spread')
  )
  open_sp = _parse_spread_val(
      (((ho.get('open') or {}).get('pointSpread') or {}).get('american'))
  )
  # Check if item['spread'] sign needs home alignment via favorite flag
  if close_sp is not None and item.get('spread') is not None and not ((ho.get('close') or ho.get('current') or {}).get('pointSpread')):
    if ho.get('favorite') and close_sp > 0:
      close_sp = -abs(close_sp)
    elif ao.get('favorite') and close_sp < 0:
      close_sp = abs(close_sp)
  if open_sp is None:
    open_sp = close_sp

  close_tot = float(item['overUnder']) if item.get('overUnder') is not None else None
  open_tot_raw = (((item.get('open') or {}).get('total') or {}).get('american'))
  open_tot = _parse_spread_val(open_tot_raw) if open_tot_raw else close_tot
  if open_tot is not None:
    open_tot = abs(open_tot)

  ml_h = float((((ho.get('close') or ho.get('current') or {}).get('moneyLine') or {}).get('decimal')) or _am_to_dec(ho.get('moneyLine'), 0.0))
  ml_a = float((((ao.get('close') or ao.get('current') or {}).get('moneyLine') or {}).get('decimal')) or _am_to_dec(ao.get('moneyLine'), 0.0))
  ml_d = float(do.get('decimal') or _am_to_dec(do.get('moneyLine'), 0.0))
  open_ml_h = float((((ho.get('open') or {}).get('moneyLine') or {}).get('decimal')) or ml_h)

  return {
      'open_spread_home': open_sp,
      'close_spread_home': close_sp,
      'spread_odds_home': int(float(ho.get('spreadOdds') or -110)),
      'spread_odds_away': int(float(ao.get('spreadOdds') or -110)),
      'open_total': open_tot,
      'close_total': close_tot,
      'over_odds': int(float(item.get('overOdds') or -110)),
      'under_odds': int(float(item.get('underOdds') or -110)),
      'ml_home_dec': round(ml_h, 2) if ml_h > 1.0 else None,
      'ml_draw_dec': round(ml_d, 2) if ml_d > 1.0 else None,
      'ml_away_dec': round(ml_a, 2) if ml_a > 1.0 else None,
      'open_ml_home_dec': round(open_ml_h, 2) if open_ml_h > 1.0 else None,
  }


def sync_fpl_bootstrap_and_fixtures(conn: sqlite3.Connection) -> tuple[dict[tuple[str, str], int], list[str], int]:
  gw_map: dict[tuple[str, str], int] = {}
  match_dates: set[str] = set()
  p_cnt = 0

  boot = net.fetch_json(FPL_BOOTSTRAP)
  fpl_team_abbr = {int(t['id']): teams.FPL_ID_TO_ABBR.get(int(t['id']), t['short_name'].upper()) for t in boot.get('teams') or []}

  conn.execute('DELETE FROM fpl_players')
  for el in boot.get('elements') or []:
    fid = int(el['id'])
    tab = fpl_team_abbr.get(int(el.get('team') or 0), 'EPL')
    pos = POS_MAP.get(int(el.get('element_type') or 3), 'MID')
    st = str(el.get('status') or 'a')
    prob = el.get('chance_of_playing_next_round')
    if prob is None:
      prob = 100 if st == 'a' else (0 if st in ('i', 's', 'n', 'u') else 75)
    xg = float(el.get('expected_goals') or 0.0)
    xa = float(el.get('expected_assists') or 0.0)
    code_num = str(el.get('code') or '')
    photo = f'https://resources.premierleague.com/premierleague/photos/players/110x140/p{code_num}.png' if code_num else ''

    conn.execute(
        """
        INSERT INTO fpl_players(
          fpl_id, team_abbr, web_name, full_name, pos, status, news, play_prob,
          minutes, goals, assists, xg, xa, xgi, clean_sheets, saves, yc, rc,
          form, cost_m, selected_pct, photo_url
        ) VALUES (?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?,?,?, ?,?,?,?)
        """,
        (
            fid, tab, el.get('web_name') or '', f"{el.get('first_name','')} {el.get('second_name','')}".strip(),
            pos, st, (el.get('news') or '').strip(), int(prob),
            int(el.get('minutes') or 0), int(el.get('goals_scored') or 0), int(el.get('assists') or 0),
            round(xg, 2), round(xa, 2), round(xg + xa, 2),
            int(el.get('clean_sheets') or 0), int(el.get('saves') or 0),
            int(el.get('yellow_cards') or 0), int(el.get('red_cards') or 0),
            float(el.get('form') or 0.0), round(float(el.get('now_cost') or 50) / 10.0, 1),
            float(el.get('selected_by_percent') or 0.0), photo,
        ),
    )
    p_cnt += 1

  fixtures = net.fetch_json(FPL_FIXTURES)
  cutoff = (dt.datetime.now(config.TZ_UTC).date() + dt.timedelta(days=18)).isoformat()
  for fx in fixtures or []:
    ko = (fx.get('kickoff_time') or '')[:10]
    gw = int(fx.get('event') or 0)
    h_ab = fpl_team_abbr.get(int(fx.get('team_h') or 0), '')
    a_ab = fpl_team_abbr.get(int(fx.get('team_a') or 0), '')
    if h_ab and a_ab and gw:
      gw_map[(h_ab, a_ab)] = gw
    if ko and config.SEASON_START_DATE.isoformat() <= ko <= cutoff:
      match_dates.add(ko.replace('-', ''))

  return gw_map, sorted(match_dates), p_cnt


def _fetch_match_enrichment(gid: str, is_final: bool, need_summary: bool, allow_odds: bool) -> dict[str, Any]:
  out: dict[str, Any] = {'gid': gid, 'odds': None, 'summary': None}
  if allow_odds:
    try:
      od = net.fetch_json(ESPN_ODDS_TPL.format(gid=gid), min_interval=0.05)
      items = od.get('items') or []
      if items:
        dk = next((x for x in items if str((x.get('provider') or {}).get('id')) == '100'), items[0])
        out['odds'] = _extract_odds_dict(dk)
    except Exception:  # pylint: disable=broad-except
      pass

  if need_summary and is_final:
    try:
      out['summary'] = net.fetch_json(ESPN_SUMMARY_TPL.format(gid=gid), min_interval=0.05)
    except Exception:  # pylint: disable=broad-except
      pass
  return out


def sync_epl_matches(conn: sqlite3.Connection, update_odds: bool = True) -> dict[str, int]:
  now_str = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S')
  gw_map, ymd_list, fpl_cnt = sync_fpl_bootstrap_and_fixtures(conn)

  # Also ensure today..today+10 are always included even if rescheduled
  today_utc = dt.datetime.now(config.TZ_UTC).date()
  for d_off in range(-3, 12):
    ymd_list.append((today_utc + dt.timedelta(days=d_off)).strftime('%Y%m%d'))
  ymd_unique = sorted(set(ymd_list))

  sb_events: dict[str, dict[str, Any]] = {}
  with ThreadPoolExecutor(max_workers=6) as pool:
    futs = {pool.submit(net.fetch_json, ESPN_SB_TPL.format(ymd=ymd), 15.0, 0.06): ymd for ymd in ymd_unique}
    for fut in as_completed(futs):
      try:
        d = fut.result()
        for ev in d.get('events') or []:
          sb_events[str(ev['id'])] = ev
      except Exception:  # pylint: disable=broad-except
        continue

  existing = {
      row['game_id']: dict(row)
      for row in conn.execute('SELECT game_id, summary_fetched, close_spread_home, close_total FROM games').fetchall()
  }

  work_items: list[tuple[str, bool, bool, bool]] = []
  parsed_games: list[dict[str, Any]] = []

  for gid, ev in sorted(sb_events.items(), key=lambda kv: kv[1].get('date') or ''):
    comp = (ev.get('competitions') or [{}])[0]
    comps = comp.get('competitors') or []
    if len(comps) < 2:
      continue
    home_c = next((c for c in comps if c.get('homeAway') == 'home'), comps[0])
    away_c = next((c for c in comps if c.get('homeAway') == 'away'), comps[1])
    h_team = home_c.get('team') or {}
    a_team = away_c.get('team') or {}
    h_ab = teams.norm_abbr(h_team.get('abbreviation'), h_team.get('id'))
    a_ab = teams.norm_abbr(a_team.get('abbreviation'), a_team.get('id'))

    st_name = ((ev.get('status') or {}).get('type') or {}).get('name') or ''
    is_final = st_name in ('STATUS_FULL_TIME', 'STATUS_FINAL', 'STATUS_FINAL_AET', 'STATUS_FINAL_PEN')
    status = 'FINAL' if is_final else ('LIVE' if 'IN_PROGRESS' in st_name or 'HALFTIME' in st_name else 'SCHEDULED')

    ko_tw, tw_date, uk_date = _iso_to_tw(ev.get('date') or '')
    h_sc = int(float(home_c.get('score') or 0)) if status in ('FINAL', 'LIVE') else None
    a_sc = int(float(away_c.get('score') or 0)) if status in ('FINAL', 'LIVE') else None

    h_ls = home_c.get('linescores') or []
    a_ls = away_c.get('linescores') or []
    ht_h = int(float(h_ls[0].get('value') or 0)) if h_ls else None
    ht_a = int(float(a_ls[0].get('value') or 0)) if a_ls else None

    h_rec = ((home_c.get('records') or [{}])[0].get('summary')) or ''
    a_rec = ((away_c.get('records') or [{}])[0].get('summary')) or ''

    sb_odds_raw = (comp.get('odds') or [None])[0]
    sb_odds = _extract_odds_dict(sb_odds_raw) if isinstance(sb_odds_raw, dict) else {}

    ex = existing.get(gid) or {}
    need_sum = is_final and not bool(ex.get('summary_fetched'))
    has_saved_odds = ex.get('close_spread_home') is not None or ex.get('close_total') is not None
    allow_odds = (update_odds and status == 'SCHEDULED') or (not has_saved_odds)

    parsed_games.append({
        'game_id': gid,
        'gameweek': gw_map.get((h_ab, a_ab), 0),
        'kickoff_utc': ev.get('date') or '',
        'kickoff_tw': ko_tw,
        'tw_date': tw_date,
        'uk_date': uk_date,
        'status': status,
        'venue': ((comp.get('venue') or {}).get('fullName')) or '',
        'home_abbr': h_ab,
        'away_abbr': a_ab,
        'home_record': h_rec,
        'away_record': a_rec,
        'ht_home': ht_h,
        'ht_away': ht_a,
        'home_score': h_sc,
        'away_score': a_sc,
        'sb_odds': sb_odds,
    })
    if need_sum or allow_odds:
      work_items.append((gid, is_final, need_sum, allow_odds))

  enriched: dict[str, dict[str, Any]] = {}
  with ThreadPoolExecutor(max_workers=6) as pool:
    futs = [pool.submit(_fetch_match_enrichment, *w) for w in work_items]
    for fut in as_completed(futs):
      res = fut.result()
      enriched[res['gid']] = res

  saved_games = 0
  saved_players = 0
  for g in parsed_games:
    gid = g['game_id']
    enr = enriched.get(gid) or {}
    ex_full_row = conn.execute('SELECT * FROM games WHERE game_id = ?', (gid,)).fetchone()
    ex_full = dict(ex_full_row) if ex_full_row else {}
    has_ex_odds = ex_full.get('close_spread_home') is not None or ex_full.get('close_total') is not None
    can_refresh_odds = (update_odds and g['status'] == 'SCHEDULED') or (not has_ex_odds)
    od = (enr.get('odds') or g['sb_odds'] or {}) if can_refresh_odds else {}

    # Preserve 18:00 Stage-1 open_spread_home / open_total baseline so 23:00 Stage-2 computes true 5h steam
    open_sp = ex_full.get('open_spread_home') if ex_full.get('open_spread_home') is not None else od.get('open_spread_home')
    close_sp = od.get('close_spread_home') if od.get('close_spread_home') is not None else ex_full.get('close_spread_home')
    open_tot = ex_full.get('open_total') if ex_full.get('open_total') is not None else od.get('open_total')
    close_tot = od.get('close_total') if od.get('close_total') is not None else ex_full.get('close_total')
    ml_h = od.get('ml_home_dec') or ex_full.get('ml_home_dec')
    ml_d = od.get('ml_draw_dec') or ex_full.get('ml_draw_dec')
    ml_a = od.get('ml_away_dec') or ex_full.get('ml_away_dec')
    open_ml_h = ex_full.get('open_ml_home_dec') or od.get('open_ml_home_dec')

    # Default soccer spread -0.5/+0.5 or 0.0 from 1X2 moneyline if spread missing
    if close_sp is None and ml_h and ml_a:
      if ml_h <= 1.55:
        close_sp = -1.0
      elif ml_h <= 2.15:
        close_sp = -0.5
      elif ml_a <= 2.15:
        close_sp = 0.5
      else:
        close_sp = 0.0
    if open_sp is None and close_sp is not None:
      open_sp = close_sp
    if close_tot is None:
      close_tot = 2.5
    if open_tot is None and close_tot is not None:
      open_tot = close_tot

    tot_goals = None
    ats_winner = ''
    ou_result = ''
    res_1x2 = ''
    btts_yes = None
    if g['status'] == 'FINAL' and g['home_score'] is not None and g['away_score'] is not None:
      hs, as_ = g['home_score'], g['away_score']
      tot_goals = hs + as_
      btts_yes = 1 if (hs > 0 and as_ > 0) else 0
      res_1x2 = 'HOME' if hs > as_ else ('AWAY' if as_ > hs else 'DRAW')
      if close_sp is not None:
        adj = (hs - as_) + close_sp
        ats_winner = 'HOME' if adj > 0 else ('AWAY' if adj < 0 else 'PUSH')
      if close_tot is not None:
        ou_result = 'OVER' if tot_goals > close_tot else ('UNDER' if tot_goals < close_tot else 'PUSH')

    stats_json = ex_full.get('stats_json') or '{}'
    kev_json = ex_full.get('key_events_json') or '[]'
    sum_fetched = int(ex_full.get('summary_fetched') or 0)

    summ = enr.get('summary')
    if isinstance(summ, dict):
      t_stats: dict[str, dict[str, str]] = {}
      for tb in (summ.get('boxscore') or {}).get('teams') or []:
        t_ab = teams.norm_abbr((tb.get('team') or {}).get('abbreviation'), (tb.get('team') or {}).get('id'))
        smap = {s.get('name'): s.get('displayValue') for s in (tb.get('statistics') or []) if s.get('name')}
        t_stats[t_ab] = smap
      stats_json = json.dumps(t_stats, ensure_ascii=False)

      kevs = []
      for ke in summ.get('keyEvents') or []:
        tp_txt = ((ke.get('type') or {}).get('text') or '').strip()
        if any(k in tp_txt for k in ('Goal', 'Penalty', 'Red Card', 'Own Goal')):
          kevs.append({
              'clock': ((ke.get('clock') or {}).get('displayValue')) or '',
              'type': tp_txt,
              'text': (ke.get('shortText') or ke.get('text') or '').strip()[:140],
          })
      kev_json = json.dumps(kevs, ensure_ascii=False)

      for rost in summ.get('rosters') or []:
        side = (rost.get('homeAway') or 'home').lower()
        r_tab = g['home_abbr'] if side == 'home' else g['away_abbr']
        for pl in rost.get('roster') or []:
          ath = pl.get('athlete') or {}
          pid = str(ath.get('id') or '')
          if not pid:
            continue
          st_map = {s.get('name'): s.get('displayValue') for s in (pl.get('stats') or []) if s.get('name')}
          app = int(float(st_map.get('appearances') or 0))
          starter = 1 if pl.get('starter') else 0
          sub_in = 1 if (pl.get('subbedIn') or int(float(st_map.get('subIns') or 0)) > 0) else 0
          played = 1 if (starter or sub_in or app > 0) else 0
          conn.execute(
              """
              INSERT INTO match_players(
                game_id, player_id, team_abbr, side, name, pos, jersey,
                starter, sub_in, played, goals, assists, shots, sot, saves,
                fouls, yc, rc, goals_conceded
              ) VALUES (?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?,?,?)
              ON CONFLICT(game_id, player_id) DO UPDATE SET
                played=excluded.played, goals=excluded.goals, assists=excluded.assists,
                shots=excluded.shots, sot=excluded.sot, saves=excluded.saves,
                fouls=excluded.fouls, yc=excluded.yc, rc=excluded.rc
              """,
              (
                  gid, pid, r_tab, side, ath.get('displayName') or ath.get('shortName') or pid,
                  ((pl.get('position') or {}).get('abbreviation')) or '',
                  str(pl.get('jersey') or ''), starter, sub_in, played,
                  int(float(st_map.get('totalGoals') or 0)),
                  int(float(st_map.get('goalAssists') or 0)),
                  int(float(st_map.get('totalShots') or 0)),
                  int(float(st_map.get('shotsOnTarget') or 0)),
                  int(float(st_map.get('saves') or 0)),
                  int(float(st_map.get('foulsCommitted') or 0)),
                  int(float(st_map.get('yellowCards') or 0)),
                  int(float(st_map.get('redCards') or 0)),
                  int(float(st_map.get('goalsConceded') or 0)),
              ),
          )
          saved_players += 1
      sum_fetched = 1

    conn.execute(
        """
        INSERT INTO games(
          game_id, gameweek, kickoff_utc, kickoff_tw, tw_date, uk_date, status, venue,
          home_abbr, away_abbr, home_record, away_record, ht_home, ht_away,
          home_score, away_score, total_goals, open_spread_home, close_spread_home,
          spread_odds_home, spread_odds_away, open_total, close_total, over_odds, under_odds,
          ml_home_dec, ml_draw_dec, ml_away_dec, open_ml_home_dec,
          ats_winner, ou_result, result_1x2, btts_yes, stats_json, key_events_json,
          summary_fetched, updated_at
        ) VALUES (?,?,?,?,?,?,?,?, ?,?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,?, ?,?,?,?, ?,?,?,?,?,?, ?,?)
        ON CONFLICT(game_id) DO UPDATE SET
          gameweek=CASE WHEN excluded.gameweek > 0 THEN excluded.gameweek ELSE games.gameweek END,
          kickoff_utc=excluded.kickoff_utc, kickoff_tw=excluded.kickoff_tw,
          tw_date=excluded.tw_date, uk_date=excluded.uk_date, status=excluded.status,
          venue=excluded.venue, home_record=excluded.home_record, away_record=excluded.away_record,
          ht_home=excluded.ht_home, ht_away=excluded.ht_away,
          home_score=excluded.home_score, away_score=excluded.away_score, total_goals=excluded.total_goals,
          open_spread_home=COALESCE(games.open_spread_home, excluded.open_spread_home),
          close_spread_home=COALESCE(excluded.close_spread_home, games.close_spread_home),
          open_total=COALESCE(games.open_total, excluded.open_total),
          close_total=COALESCE(excluded.close_total, games.close_total),
          ml_home_dec=COALESCE(excluded.ml_home_dec, games.ml_home_dec),
          ml_draw_dec=COALESCE(excluded.ml_draw_dec, games.ml_draw_dec),
          ml_away_dec=COALESCE(excluded.ml_away_dec, games.ml_away_dec),
          open_ml_home_dec=COALESCE(games.open_ml_home_dec, excluded.open_ml_home_dec),
          ats_winner=excluded.ats_winner, ou_result=excluded.ou_result,
          result_1x2=excluded.result_1x2, btts_yes=excluded.btts_yes,
          stats_json=excluded.stats_json, key_events_json=excluded.key_events_json,
          summary_fetched=excluded.summary_fetched, updated_at=excluded.updated_at
        """,
        (
            gid, g['gameweek'], g['kickoff_utc'], g['kickoff_tw'], g['tw_date'], g['uk_date'],
            g['status'], g['venue'], g['home_abbr'], g['away_abbr'], g['home_record'], g['away_record'],
            g['ht_home'], g['ht_away'], g['home_score'], g['away_score'], tot_goals,
            open_sp, close_sp, od.get('spread_odds_home', -110), od.get('spread_odds_away', -110),
            open_tot, close_tot, od.get('over_odds', -110), od.get('under_odds', -110),
            ml_h, ml_d, ml_a, open_ml_h,
            ats_winner, ou_result, res_1x2, btts_yes, stats_json, kev_json, sum_fetched, now_str,
        ),
    )
    saved_games += 1

  return {'games': saved_games, 'fpl_players': fpl_cnt, 'match_players': saved_players}
