#!/usr/bin/env python3
"""Bilingual Premier League Injury, Lineup & Betting News Aggregator (ESPN Soccer + Google News RSS)."""
from __future__ import annotations

import datetime as dt
import email.utils
import hashlib
import html
import re
import sqlite3
import urllib.parse
import xml.etree.ElementTree as ET

import config
import net

ESPN_EPL_NEWS = 'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/news?limit=25'
GNEWS_ZH = (
    'https://news.google.com/rss/search?q='
    + urllib.parse.quote('英超 (兵工廠 OR 利物浦 OR 曼城 OR 切爾西 OR 曼聯 OR 熱刺 OR 傷兵) when:7d')
    + '&hl=zh-TW&gl=TW&ceid=TW:zh-Hant'
)
GNEWS_EN = (
    'https://news.google.com/rss/search?q='
    + urllib.parse.quote('"Premier League" (injury OR team news OR lineup OR prediction) when:5d')
    + '&hl=en-US&gl=US&ceid=US:en'
)

CLUB_KW: list[tuple[str, tuple[str, ...]]] = [
    ('ARS', ('arsenal', 'saka', 'arteta', 'saliba', '兵工廠', '阿森納')),
    ('LIV', ('liverpool', 'salah', 'slot', 'anfield', '利物浦', '薩拉赫')),
    ('MCI', ('manchester city', 'man city', 'haaland', 'guardiola', '曼城', '哈蘭德')),
    ('CHE', ('chelsea', 'palmer', 'stamford', '切爾西', '車路士', '帕爾默')),
    ('MUN', ('manchester united', 'man utd', 'old trafford', 'bruno', '曼聯')),
    ('TOT', ('tottenham', 'spurs', '熱刺')),
    ('NEW', ('newcastle', 'isak', 'guimaraes', '紐卡索', '紐卡斯爾')),
    ('AVL', ('aston villa', 'watkins', 'emery', '阿斯頓維拉', '維拉')),
    ('BHA', ('brighton', '布萊頓', '白禮頓')),
    ('WHU', ('west ham', '西漢姆')),
    ('CRY', ('crystal palace', '水晶宮')),
    ('BRE', ('brentford', '布倫特福德')),
    ('FUL', ('fulham', '富勒姆')),
    ('BOU', ('bournemouth', '伯恩茅斯')),
    ('NFO', ('nottingham forest', '諾丁漢森林')),
    ('EVE', ('everton', '艾佛頓', '愛華頓')),
    ('LEE', ('leeds', '利茲聯', '列斯聯')),
    ('IPS', ('ipswich', '伊普斯維奇')),
    ('SUN', ('sunderland', '桑德蘭')),
    ('COV', ('coventry', '考文垂')),
    ('HUL', ('hull city', '赫爾城')),
]


def _detect_club(text: str) -> str:
  low = text.lower()
  for ab, kws in CLUB_KW:
    if any(k in low for k in kws):
      return ab
  return ''


def _detect_cat(text: str) -> str:
  low = text.lower()
  if any(k in low for k in ('injur', 'doubt', 'suspend', 'out', 'fitness', '傷', '禁賽', '缺陣', '復出')):
    return 'INJURY'
  if any(k in low for k in ('lineup', 'xi', 'predicted', 'team news', '先發', '陣容')):
    return 'LINEUP'
  if any(k in low for k in ('odds', 'betting', 'prediction', 'preview', '盤口', '預測', '賠率')):
    return 'BETTING'
  return 'NEWS'


def _strip_tags(s: str) -> str:
  return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', s or ''))).strip()


def _rss_date_tw(pub: str) -> str:
  try:
    d = email.utils.parsedate_to_datetime(pub)
    if d.tzinfo is None:
      d = d.replace(tzinfo=config.TZ_UTC)
    return d.astimezone(config.TZ_TW).strftime('%Y-%m-%d %H:%M')
  except Exception:  # pylint: disable=broad-except
    return dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M')


def sync_epl_news(conn: sqlite3.Connection) -> int:
  now_tw = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M')
  cnt = 0

  try:
    d = net.fetch_json(ESPN_EPL_NEWS)
    for art in d.get('articles') or []:
      title = (art.get('headline') or '').strip()
      desc = (art.get('description') or '').strip()
      url = (((art.get('links') or {}).get('web') or {}).get('href') or '').strip()
      if not title or not url:
        continue
      pub = art.get('published') or ''
      if pub.endswith('Z'):
        pub = pub[:-1] + '+00:00'
      try:
        pub_tw = dt.datetime.fromisoformat(pub).astimezone(config.TZ_TW).strftime('%Y-%m-%d %H:%M')
      except ValueError:
        pub_tw = now_tw
      nid = hashlib.sha1(url.encode('utf-8')).hexdigest()[:16]
      blob = f'{title} {desc}'
      conn.execute(
          """
          INSERT INTO news_items(news_id, published_tw, source, lang, category, team_abbr, title, summary, url)
          VALUES (?,?,?,?,?,?,?,?,?)
          ON CONFLICT(news_id) DO UPDATE SET
            published_tw=excluded.published_tw, title=excluded.title, summary=excluded.summary
          """,
          (nid, pub_tw, 'ESPN FC', 'EN', _detect_cat(blob), _detect_club(blob), title, desc[:260], url),
      )
      cnt += 1
  except Exception:  # pylint: disable=broad-except
    pass

  for rss_url, lang, src_def in ((GNEWS_ZH, 'ZH', '英超中文新聞'), (GNEWS_EN, 'EN', 'EPL Wire')):
    try:
      xml_txt = net.fetch_text(rss_url)
      root = ET.fromstring(xml_txt)
      for item in root.findall('.//item')[:18]:
        raw_title = (item.findtext('title') or '').strip()
        link = (item.findtext('link') or '').strip()
        desc = _strip_tags(item.findtext('description') or '')
        src_el = item.find('source')
        src = (src_el.text.strip() if src_el is not None and src_el.text else '') or src_def
        if ' - ' in raw_title:
          raw_title = raw_title.rsplit(' - ', 1)[0].strip()
        if not raw_title or not link:
          continue
        pub_tw = _rss_date_tw(item.findtext('pubDate') or '')
        nid = hashlib.sha1(raw_title.encode('utf-8')).hexdigest()[:16]
        blob = f'{raw_title} {desc}'
        conn.execute(
            """
            INSERT INTO news_items(news_id, published_tw, source, lang, category, team_abbr, title, summary, url)
            VALUES (?,?,?,?,?,?,?,?,?)
            ON CONFLICT(news_id) DO NOTHING
            """,
            (nid, pub_tw, src[:32], lang, _detect_cat(blob), _detect_club(blob), raw_title[:200], desc[:220], link),
        )
        cnt += 1
    except Exception:  # pylint: disable=broad-except
      pass

  return cnt
