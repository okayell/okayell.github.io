/* Page 9: 📖 英超足球運彩百科 · 亞洲讓球盤／2.5大小球／xG與泊松模型實戰指南 (#/guide) */
(function () {
  'use strict';
  const EPL = window.EPL;

  EPL.pages.guide = function (root) {
    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">📖 英超足球運彩百科：從亞洲讓球盤、和局陷阱到預期進球 (xG) 實戰指南</h1>
          <div class="sec-sub">專為台灣運彩與國際盤足球玩家整理的核心盤口規則與量化避坑手冊</div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,430px),1fr));gap:14px">
        <div class="card">
          <h3 class="sec-title" style="font-size:15.5px;margin-bottom:8px">⏱️ 1. 足球運彩鐵律：只算「法定 90 分鐘＋傷停補時」</h3>
          <p style="margin:0;color:#334155;font-size:13.5px;line-height:1.7">
            不論是台灣運彩的不讓分（1X2 主客和）、讓分、大小球或雙進球（BTTS），<strong>一律只計算正規 90 分鐘加上裁判給的傷停補時（如 90+6'）</strong>。英超聯賽沒有延長賽；即便未來遇到足總盃或歐冠淘汰賽踢進 30 分鐘延長賽或 PK 點球大戰，正規時間踢成 1:1 在運彩標準盤口就是「和局 (Draw) 2 球」。
          </p>
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:15.5px;margin-bottom:8px">🛡️ 2. 為什麼強隊讓半球 (-0.5) 最容易踩「和局陷阱」？</h3>
          <p style="margin:0;color:#334155;font-size:13.5px;line-height:1.7">
            英超平均約有 <strong>24%～27%</strong> 的比賽以和局收場！當莊家開出主隊讓半球（<code>-0.5</code>），買主隊必須「淨勝 1 球以上」才贏；一旦踢成 0:0 或 1:1 和局即全輸。反之買客隊受讓（<code>+0.5</code>）等於同時包辦「客勝＋和局」（Double Chance X2）。因此本智庫內建<strong>和局防雷護盾</strong>：當泊松和局機率 ≥ 27.5% 時自動示警，避免盲目追買 -0.5 熱門上盤。
          </p>
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:15.5px;margin-bottom:8px">📐 3. 亞洲讓球盤（Asian Handicap）速查對照表</h3>
          <div class="tbl-wrap">
            <table class="data-tbl">
              <thead><tr><th>盤口線值</th><th>買讓球方（上盤）結算規則</th><th>買受讓方（下盤）結算規則</th></tr></thead>
              <tbody>
                <tr><td><strong>0 (PK 平手盤)</strong></td><td>贏球全贏、和局退本走水、輸球全輸</td><td>贏球全贏、和局退本走水、輸球全輸</td></tr>
                <tr><td><strong>-0.5 / +0.5</strong></td><td>贏 1 球以上全贏；和局或輸球全輸</td><td>不敗（贏或和）即全贏！</td></tr>
                <tr><td><strong>-1.0 / +1.0</strong></td><td>贏 2 球以上全贏；剛好贏 1 球退本走水</td><td>贏或和全贏；剛好輸 1 球退本走水</td></tr>
                <tr><td><strong>-1.5 / +1.5</strong></td><td>必須淨勝 2 球（含）以上才贏盤</td><td>贏、和、或僅小輸 1 球皆全贏！</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:15.5px;margin-bottom:8px">📊 4. 什麼是泊松進球分布 (λ) 與預期進球 (xG)？</h3>
          <p style="margin:0;color:#334155;font-size:13.5px;line-height:1.7">
            <strong>預期進球（Expected Goals, xG）</strong>衡量每次射門依距離、角度與防守壓力轉化為進球的歷史機率。若某隊連兩週靠世界波踢進 6 球但累積僅 <code>2.1 xG</code>，代表終結運氣過熱、下輪極易均值回歸啞火！本系統將主客隊攻擊力、防守失球與官方 FPL 傷停折損輸入 <strong>Dixon-Coles 雙變數泊松矩陣</strong>，精準推算 0:0 到 6:6 共 49 種比分機率。
          </p>
        </div>
      </div>
    `;
  };
})();
