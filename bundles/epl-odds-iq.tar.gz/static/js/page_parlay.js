/* Page 2: 🎰 英超本輪跨場串關推薦 · 台彩／國際盤試算 ＆ 3串4 防絕殺容錯 (#/parlay) */
(function () {
  'use strict';
  const EPL = window.EPL;

  function tierPill(tier) {
    if (tier === 'STRONG') return '<span class="chip strong">🔥 強推精選</span>';
    if (tier === 'LEAN') return '<span class="chip ok">✅ 順勢推薦</span>';
    return '<span class="chip warn">⚠️ 湊關次選</span>';
  }

  function legResultBadge(res) {
    if (res === 'WIN') return '<span class="chip ok">✅ 過關</span>';
    if (res === 'LOSS') return '<span class="chip bad">❌ 倒關</span>';
    if (res === 'PUSH') return '<span class="chip warn">➖ 走水 (1.0x)</span>';
    return '<span class="chip muted">⏳ 待開賽</span>';
  }

  function renderPackageCard(pkg, book, unitStake) {
    const isTw = book === 'TW';
    const isCombo = pkg.type === 'COMBO';
    const totalBets = pkg.bets_count || 1;
    const totalStake = unitStake * totalBets;
    const singleOdds = isTw ? 1.75 : 1.91;
    const combinedOdds = isTw ? Number(pkg.tw_odds || 1) : Number(pkg.intl_odds || 1);

    const maxMult = isCombo ? Number(pkg.max_mult || 0) : combinedOdds;
    const maxGross = Math.round(unitStake * maxMult);
    const maxNet = maxGross - totalStake;
    const hit2Gross = isCombo ? Math.round(unitStake * Number(pkg.hit2_mult || 0)) : 0;

    const cardCls = pkg.key === 'anchor_2x1' ? 'parlay-card anchor' : isCombo ? 'parlay-card combo' : 'parlay-card';

    let statusHtml = '';
    if (pkg.status !== 'PENDING') {
      const gross = Math.round(unitStake * Number(pkg.return_mult || 0));
      const net = gross - totalStake;
      if (pkg.status === 'WIN') {
        statusHtml = `<div style="background:#dcfce7;border:1px solid #86efac;color:#14532d;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">🎉 賽後對獎：全關命中過盤！總領回 NT$ ${gross.toLocaleString()}（淨利 +NT$ ${net.toLocaleString()}）</div>`;
      } else if (pkg.status === 'PARTIAL') {
        statusHtml = `<div style="background:#eff6ff;border:1px solid #93c5fd;color:#1e3a8a;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">🛡️ 賽後對獎：觸發 3 串 4 複式容錯保護（中 ${pkg.cashed_combos}/4 注）！領回 NT$ ${gross.toLocaleString()}（損益 ${net >= 0 ? '+' : ''}NT$ ${net.toLocaleString()}）</div>`;
      } else {
        statusHtml = `<div style="background:#fee2e2;border:1px solid #fca5a5;color:#991b1b;padding:8px 12px;border-radius:8px;font-size:12.5px;font-weight:700">❌ 賽後對獎：未達過關門檻，損益 -NT$ ${totalStake.toLocaleString()}</div>`;
      }
    }

    const legsHtml = (pkg.legs || []).map((lg, idx) => {
      const rowCls = lg.leg_result === 'WIN' ? 'leg-win' : lg.leg_result === 'LOSS' ? 'leg-loss' : '';
      const scoreTxt = lg.status === 'FINAL' && lg.home_score != null
        ? `終場 ${lg.home_score}:${lg.away_score}`
        : `台灣 ${(lg.kickoff_tw || '').slice(5)}`;
      return `
        <div class="parlay-leg-row ${rowCls}">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
              <span class="chip info" style="font-weight:800">第 ${idx + 1} 關</span>
              <span style="display:inline-flex;align-items:center;gap:4px;font-size:12.5px;font-weight:700">
                <img src="${EPL.esc(lg.home_logo)}" alt="" style="width:17px;height:17px;object-fit:contain">
                <span class="tm-link" data-team-link="${EPL.esc(lg.home_abbr)}">${EPL.esc(lg.home_zh)}</span>
                <span style="color:#94a3b8">vs</span>
                <img src="${EPL.esc(lg.away_logo)}" alt="" style="width:17px;height:17px;object-fit:contain">
                <span class="tm-link" data-team-link="${EPL.esc(lg.away_abbr)}">${EPL.esc(lg.away_zh)}</span>
              </span>
              <span style="font-size:11.5px;color:#64748b">（${EPL.esc(scoreTxt)}）</span>
            </div>
            <div style="display:flex;align-items:center;gap:5px">
              ${tierPill(lg.tier)}
              ${legResultBadge(lg.leg_result)}
            </div>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:2px">
            <div>
              <span class="chip muted" style="margin-right:5px">${EPL.esc(lg.market_zh)}</span>
              <strong style="font-size:14px;color:#0f172a">${EPL.esc(lg.pick_label_zh)}</strong>
              <span style="font-size:11.5px;color:#059669;font-weight:700;margin-left:6px">Edge ${EPL.fmtSigned(lg.edge, 1)}%</span>
            </div>
            <div style="font-size:12px;color:#334155">
              單關 <strong>${singleOdds.toFixed(2)}x</strong> · 預估過盤率 <strong>${lg.win_prob_pct}%</strong>
            </div>
          </div>
        </div>`;
    }).join('');

    const payoutHtml = isCombo
      ? `<div class="parlay-payout-box">
          <div><div style="color:#64748b;font-size:11px">總本金（4 注）</div><div style="font-size:14.5px;font-weight:800">NT$ ${totalStake.toLocaleString()}</div><div style="font-size:11px;color:#64748b">每注 NT$ ${unitStake.toLocaleString()} × 4</div></div>
          <div><div style="color:#64748b;font-size:11px">🎉 3 關全過領回</div><div style="font-size:14.5px;font-weight:800;color:#15803d">NT$ ${maxGross.toLocaleString()}</div><div style="font-size:11px;color:#15803d">淨利 +NT$ ${maxNet.toLocaleString()}</div></div>
          <div><div style="color:#64748b;font-size:11px">🛡️ 3 過 2 保本回血</div><div style="font-size:14.5px;font-weight:800;color:#1d4ed8">NT$ ${hit2Gross.toLocaleString()}</div><div style="font-size:11px;color:#475569">拿回 ${Math.round((hit2Gross / totalStake) * 100)}% 本金</div></div>
          <div><div style="color:#64748b;font-size:11px">至少過 2 關機率</div><div style="font-size:14.5px;font-weight:800">${pkg.at_least_2_prob_pct}%</div><div style="font-size:11px;color:#059669;font-weight:700">防補時絕殺斷龍</div></div>
        </div>`
      : `<div class="parlay-payout-box">
          <div><div style="color:#64748b;font-size:11px">單注本金</div><div style="font-size:14.5px;font-weight:800">NT$ ${totalStake.toLocaleString()}</div><div style="font-size:11px;color:#64748b">均注試算</div></div>
          <div><div style="color:#64748b;font-size:11px">綜合過關賠率</div><div style="font-size:15px;font-weight:800;color:#059669">${combinedOdds.toFixed(2)} 倍</div><div style="font-size:11px;color:#64748b">${isTw ? '台彩參考盤' : '國際標準盤'}</div></div>
          <div><div style="color:#64748b;font-size:11px">過關總領回</div><div style="font-size:15px;font-weight:800;color:#15803d">NT$ ${maxGross.toLocaleString()}</div><div style="font-size:11px;color:#15803d;font-weight:700">淨利 +NT$ ${maxNet.toLocaleString()}</div></div>
          <div><div style="color:#64748b;font-size:11px">聯立過關率 / EV</div><div style="font-size:14.5px;font-weight:800">${pkg.joint_prob_pct}%</div><div style="font-size:11px;font-weight:700;color:${pkg.ev_pct >= 0 ? '#15803d' : '#b45309'}">EV ${pkg.ev_pct >= 0 ? '+' : ''}${pkg.ev_pct}%</div></div>
        </div>`;

    return `
      <article class="${cardCls}">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;flex-wrap:wrap">
          <div>
            <div style="font-size:11.5px;font-weight:800;color:#059669;margin-bottom:2px">${EPL.esc(pkg.badge_zh)}</div>
            <h3 style="margin:0;font-size:16.5px;color:#0f172a">${EPL.esc(pkg.title_zh)}</h3>
          </div>
          <span class="chip ${EPL.esc(pkg.grade_cls || 'ok')}">${EPL.esc(pkg.grade_zh)}</span>
        </div>
        <div style="font-size:12.5px;color:#475569;line-height:1.5">${EPL.esc(pkg.subtitle_zh)}</div>
        <div class="parlay-leg-list">${legsHtml}</div>
        ${payoutHtml}
        ${statusHtml}
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:auto;padding-top:4px">
          <span style="font-size:11.5px;color:#64748b">✅ 嚴格跨場不重複賽事（符合台彩＆國際盤足球串關規範）</span>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button type="button" class="btn btn-sm" data-copy-pkg="${EPL.esc(pkg.key)}">📋 複製串關單</button>
            <button type="button" class="btn btn-primary btn-sm" data-save-pkg="${EPL.esc(pkg.key)}">➕ 一鍵加入注單追蹤</button>
          </div>
        </div>
      </article>`;
  }

  EPL.pages.parlay = function (root) {
    const snap = EPL.snap || {};
    const meta = snap.meta || {};
    const allGames = snap.games || [];
    const gwSet = Array.from(new Set(allGames.map((g) => Number(g.gameweek)).filter(Boolean))).sort((a, b) => a - b);
    const nextGw = Number(meta.next_gameweek || 9);
    const activeGw = Number(EPL.state.parlayGw || nextGw);
    const book = EPL.state.parlayBook || 'INTL';
    const isTw = book === 'TW';
    const unitStake = Math.max(10, Number(EPL.state.parlayStake || 500));

    const bundle = EPL.buildGwParlayPackages(activeGw, book);
    const pkgs = bundle.packages || [];
    const gwGames = bundle.games || [];
    const selMap = EPL.state.parlayCustom || {};
    const selLegs = Object.values(selMap).filter((x) => Number(x.gw) === activeGw);
    const singleOdds = isTw ? 1.75 : 1.91;
    const customMult = selLegs.length >= 2 ? +(singleOdds ** selLegs.length).toFixed(2) : 0;
    const customJoint = selLegs.reduce((acc, x) => acc * (x.prob / 100), 1) * 100;

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🎰 英超 GW${activeGw} 跨場串關推薦 · 台彩／國際盤試算 ＆ 3串4 防絕殺組合</h1>
          <div class="sec-sub">嚴守「同一場比賽僅選最優單一方向」跨場不重複原則，並提供足球玩家最實用的 3 串 4（Trixie）防補時被絕平斷龍方案</div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <div class="sub-tabs" style="margin:0">
            <button type="button" class="sub-tab ${!isTw ? 'active' : ''}" data-book="INTL">🌐 國際盤 (1.91x)</button>
            <button type="button" class="sub-tab ${isTw ? 'active' : ''}" data-book="TW">🇹🇼 台灣運彩 (1.75x)</button>
          </div>
          <label style="font-size:12.5px;font-weight:700;color:#475569;display:inline-flex;align-items:center;gap:5px">
            每注金額 NT$
            <input type="number" step="100" min="100" class="inp" id="parlayStakeInp" value="${unitStake}" style="width:92px;padding:5px 8px">
          </label>
        </div>
      </div>

      <div class="date-bar">
        <span style="font-size:12.5px;font-weight:700;color:#475569">⚽ 選擇串關輪次：</span>
        ${gwSet.filter((gw) => Math.abs(gw - nextGw) <= 3 || gw === activeGw).map((gw) => `
          <button type="button" class="date-pill ${gw === activeGw ? 'active' : ''}" data-pgw="${gw}">
            GW${gw} ${gw === nextGw ? '本輪主推' : ''}
          </button>
        `).join('')}
        <select class="inp" id="parlayGwSel" style="margin-left:auto;padding:5px 9px;font-size:12.5px">
          ${gwSet.map((gw) => `<option value="${gw}" ${gw === activeGw ? 'selected' : ''}>英超第 ${gw} 輪 (GW${gw})</option>`).join('')}
        </select>
      </div>

      <div class="parlay-pkg-grid">
        ${pkgs.map((pkg) => renderPackageCard(pkg, book, unitStake)).join('')}
      </div>

      <!-- Custom Parlay Builder -->
      <div class="card">
        <div class="sec-hdr">
          <div>
            <h2 class="sec-title">🧮 自選英超跨場串關試算機（GW${activeGw} 點選任意 2～6 場自動算賠率與期望值）</h2>
            <div class="sec-sub">每場賽事最多勾選 1 個方向（點擊已選按鈕可取消），系統即時試算直串過關倍數與聯立機率</div>
          </div>
          ${selLegs.length ? `<button type="button" class="btn btn-sm" id="clearCustomParlayBtn">清除已選 (${selLegs.length})</button>` : ''}
        </div>
        <div class="parlay-builder-wrap">
          <div style="display:flex;flex-direction:column;gap:7px">
            ${gwGames.map((g) => {
              const h = EPL.teamOf(g.home_abbr), a = EPL.teamOf(g.away_abbr);
              const p = g.pred || {};
              const spH = Number(g.close_spread_home ?? -0.5);
              const tot = Number(g.close_total ?? 2.5);
              const atsSide = p.ats_pick !== 'PASS' ? p.ats_pick : p.ats_lean_side || 'HOME';
              const atsLbl = `${atsSide === 'HOME' ? h.zh : a.zh} ${EPL.fmtSpread(atsSide === 'HOME' ? spH : -spH)}`;
              const ouSide = p.ou_pick !== 'PASS' ? p.ou_pick : p.ou_lean_side || 'OVER';
              const ouLbl = `${ouSide === 'OVER' ? '大球' : '小球'} ${tot}`;
              const cur = selMap[g.game_id];
              return `
                <div class="pb-game-row">
                  <div>
                    <div style="font-weight:800;font-size:13px">${EPL.esc(h.zh)} vs ${EPL.esc(a.zh)}</div>
                    <div style="font-size:11px;color:#64748b">${EPL.esc((g.kickoff_tw || '').slice(5))}</div>
                  </div>
                  <button type="button" class="pb-pick-btn ${cur && cur.mkt === 'ATS' ? 'selected' : ''}" data-cpg="${EPL.esc(g.game_id)}" data-cmkt="ATS" data-clbl="${EPL.esc(atsLbl)}" data-cprob="${(52.38 + Number(p.ats_edge || 0)).toFixed(1)}" data-cdate="${EPL.esc(g.tw_date)}">
                    <span>⚽ ${EPL.esc(atsLbl)}</span>
                    <span class="chip ${p.ats_tier === 'STRONG' ? 'strong' : 'muted'}">${EPL.fmtSigned(p.ats_edge, 1)}%</span>
                  </button>
                  <button type="button" class="pb-pick-btn ${cur && cur.mkt === 'OU' ? 'selected' : ''}" data-cpg="${EPL.esc(g.game_id)}" data-cmkt="OU" data-clbl="${EPL.esc(ouLbl)}" data-cprob="${(52.38 + Number(p.ou_edge || 0)).toFixed(1)}" data-cdate="${EPL.esc(g.tw_date)}">
                    <span>🥅 ${EPL.esc(ouLbl)}</span>
                    <span class="chip ${p.ou_tier === 'STRONG' ? 'strong' : 'muted'}">${EPL.fmtSigned(p.ou_edge, 1)}%</span>
                  </button>
                </div>`;
            }).join('')}
          </div>

          <div class="card" style="background:#f8fafc;align-self:start">
            <h3 style="margin:0 0 8px;font-size:15px">📋 自選串關試算單（已選 ${selLegs.length} 關）</h3>
            ${selLegs.length < 2
              ? `<div class="empty-box" style="padding:20px">請從左側點選至少 <strong>2 場不同賽事</strong> 進行串關試算</div>`
              : `
                <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:12px">
                  ${selLegs.map((x, i) => `<div style="display:flex;justify-content:space-between;font-size:13px;padding:6px 9px;background:#fff;border-radius:7px;border:1px solid #e2e8f0"><span><strong>#${i + 1}</strong> ${EPL.esc(x.pick_label_zh)}</span><span style="color:#059669;font-weight:700">${x.prob}%</span></div>`).join('')}
                </div>
                <div class="parlay-payout-box" style="margin-bottom:12px">
                  <div><div style="font-size:11px;color:#64748b">${selLegs.length} 串 1 綜合賠率</div><div style="font-size:16px;font-weight:900;color:#059669">${customMult}x</div></div>
                  <div><div style="font-size:11px;color:#64748b">預估總領回</div><div style="font-size:16px;font-weight:900;color:#15803d">NT$ ${Math.round(unitStake * customMult).toLocaleString()}</div></div>
                  <div><div style="font-size:11px;color:#64748b">聯立過關率</div><div style="font-size:15px;font-weight:800">${customJoint.toFixed(1)}%</div></div>
                </div>
                <button type="button" class="btn btn-primary" style="width:100%" id="saveCustomParlayBtn">➕ 將此 ${selLegs.length} 串 1 加入注單追蹤</button>
              `}
          </div>
        </div>
      </div>
    `;

    root.querySelectorAll('[data-book]').forEach((b) => {
      b.onclick = () => { EPL.state.parlayBook = b.getAttribute('data-book'); EPL.render(); };
    });
    const stInp = document.getElementById('parlayStakeInp');
    if (stInp) {
      stInp.onchange = () => { EPL.state.parlayStake = Math.max(100, Number(stInp.value || 500)); EPL.render(); };
    }
    root.querySelectorAll('[data-pgw]').forEach((b) => {
      b.onclick = () => { EPL.state.parlayGw = Number(b.getAttribute('data-pgw')); EPL.render(); };
    });
    const gwSel = document.getElementById('parlayGwSel');
    if (gwSel) gwSel.onchange = () => { EPL.state.parlayGw = Number(gwSel.value); EPL.render(); };

    root.querySelectorAll('[data-copy-pkg]').forEach((btn) => {
      btn.onclick = () => {
        const pkg = pkgs.find((x) => x.key === btn.getAttribute('data-copy-pkg'));
        if (!pkg) return;
        const txt = `【${pkg.title_zh}】\n` + pkg.legs.map((l, i) => `${i + 1}. ${l.home_zh} vs ${l.away_zh} → ${l.pick_label_zh}`).join('\n');
        navigator.clipboard.writeText(txt).then(() => EPL.toast('📋 已複製串關單內容！'));
      };
    });
    root.querySelectorAll('[data-save-pkg]').forEach((btn) => {
      btn.onclick = () => {
        const pkg = pkgs.find((x) => x.key === btn.getAttribute('data-save-pkg'));
        if (pkg) EPL.addParlayBet({ tw_date: pkg.legs[0].tw_date, type: pkg.type, title: pkg.title_zh, legs: pkg.legs });
      };
    });
    root.querySelectorAll('[data-cpg]').forEach((btn) => {
      btn.onclick = () => {
        const gid = btn.getAttribute('data-cpg');
        const mkt = btn.getAttribute('data-cmkt');
        const cur = EPL.state.parlayCustom[gid];
        if (cur && cur.mkt === mkt) {
          delete EPL.state.parlayCustom[gid];
        } else {
          EPL.state.parlayCustom[gid] = {
            gw: activeGw,
            game_id: gid,
            mkt,
            pick_label_zh: btn.getAttribute('data-clbl'),
            prob: Number(btn.getAttribute('data-cprob') || 54),
            tw_date: btn.getAttribute('data-cdate') || '',
          };
        }
        EPL.render();
      };
    });
    const clrBtn = document.getElementById('clearCustomParlayBtn');
    if (clrBtn) clrBtn.onclick = () => { EPL.state.parlayCustom = {}; EPL.render(); };
    const svBtn = document.getElementById('saveCustomParlayBtn');
    if (svBtn && selLegs.length >= 2) {
      svBtn.onclick = () => EPL.addParlayBet({
        tw_date: selLegs[0].tw_date,
        type: 'DIRECT',
        title: `GW${activeGw} 自選 ${selLegs.length} 串 1`,
        legs: selLegs,
      });
    }
  };
})();
