/* 英超運彩智庫 — Core SPA Router, State, IME-Safe Input, Match Boxscore, FPL Player Modal & Release Center */
(function () {
  'use strict';

  const _isPublicStaticHost = Boolean(
    window.EPL_STATIC_ONLY ||
    location.protocol === 'file:' ||
    /\.github\.io$|\.pages\.dev$|\.netlify\.app$|\.vercel\.app$/i.test(location.hostname || '')
  );

  const EPL = (window.EPL = {
    isStatic: _isPublicStaticHost,
    snap: window.__STATIC_SNAPSHOT__ || null,
    health: { ok: true, ai: false, version: '1.0.0' },
    bets: [],
    pages: {},
    route: 'picks',
    state: {
      picksGw: 0,
      picksFilter: 'ALL',
      picksSearch: '',
      parlayGw: 0,
      parlayBook: 'INTL',
      parlayStake: 500,
      parlayCustom: {},
      resultsGw: 'ALL',
      resultsTab: 'ledger',
      activeTeam: 'ARS',
      teamGameId: '',
      statsEntity: 'table',
      statsTeam: 'ALL',
      statsPos: 'ALL',
      statsSearch: '',
      statsSort: 'xgi',
      statsDir: 'desc',
      tableSort: 'pts',
      tableDir: 'desc',
      newsTab: 'injuries',
      injTeam: 'ALL',
      injStatus: 'ALL',
      newsCat: 'ALL',
      newsTeam: 'ALL',
      newsQuery: '',
    },
  });

  // --- IME-Safe Enter Guard (Mandatory for Traditional Chinese IMEs) ---
  let _imeComposing = false;
  let _lastImeEndAt = 0;
  document.addEventListener('compositionstart', () => { _imeComposing = true; }, true);
  document.addEventListener('compositionend', () => { _imeComposing = false; _lastImeEndAt = Date.now(); }, true);
  EPL.isEnterSend = function (ev) {
    return (
      ev.key === 'Enter' &&
      !ev.shiftKey &&
      !ev.isComposing &&
      ev.keyCode !== 229 &&
      !_imeComposing &&
      Date.now() - _lastImeEndAt >= 150
    );
  };

  EPL.esc = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  EPL.fmtSpread = function (val) {
    if (val == null || val === '') return '—';
    const n = Number(val);
    if (Number.isNaN(n)) return '—';
    if (Math.abs(n) < 0.01) return 'PK (0)';
    return (n > 0 ? '+' : '') + n.toFixed(2).replace(/\.00$/, '.0').replace(/(\.\d)0$/, '$1');
  };

  EPL.fmtSigned = function (val, digits = 2) {
    if (val == null || val === '') return '—';
    const n = Number(val);
    if (Number.isNaN(n)) return '—';
    return (n > 0 ? '+' : '') + n.toFixed(digits);
  };

  EPL.teamMap = {};
  EPL.playerMap = {};
  EPL.gameMap = {};
  EPL.teamOf = function (abbr) {
    return EPL.teamMap[abbr] || { abbr: abbr || 'EPL', zh: abbr || '俱樂部', en: abbr || '', logo: '', color: '#059669' };
  };

  EPL.toast = function (msg) {
    const box = document.getElementById('toastBox');
    if (!box) return;
    const el = document.createElement('div');
    el.className = 'toast-msg';
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => { el.remove(); }, 3200);
  };

  EPL.apiGet = async function (path) {
    if (EPL.isStatic) {
      if (path === '/api/snapshot') return EPL.snap;
      if (path === '/api/bets') {
        let list = [];
        try { list = JSON.parse(localStorage.getItem('epl.bets.v1') || '[]'); } catch (_) { list = []; }
        const graded = EPL._gradeStaticBets(list);
        if (graded.changed) {
          try { localStorage.setItem('epl.bets.v1', JSON.stringify(graded.list)); } catch (_) { /* 無痕模式或空間不足：略過 */ }
        }
        return { bets: graded.list };
      }
      if (path === '/api/feedback') {
        try { return { ok: true, items: JSON.parse(localStorage.getItem('epl.feedback.v1') || '[]') }; }
        catch (_) { return { ok: true, items: [] }; }
      }
      if (path === '/api/release_status') {
        const rd = window.EPL_RELEASES || { current_version: '1.0.0', releases: [] };
        return { static: true, current_version: rd.current_version, has_changes: false, changed_files: [], releases: rd.releases || [] };
      }
      return {};
    }
    const r = await fetch(path, { headers: { Accept: 'application/json' } });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  };

  EPL.apiPost = async function (path, body) {
    if (EPL.isStatic) {
      if (path.startsWith('/api/bets/')) return EPL._staticBetAction(path, body || {});
      throw new Error('靜態離線版不支援雲端背景操作，請在主機環境操作。');
    }
    const r = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body || {}),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  };

  EPL._staticBetAction = function (path, body) {
    let list = [];
    try { list = JSON.parse(localStorage.getItem('epl.bets.v1') || '[]'); } catch (_) { list = []; }
    if (path === '/api/bets/add') {
      list.unshift({
        bet_id: 'BET-' + Date.now().toString(36).toUpperCase(),
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
        tw_date: body.tw_date || '',
        game_id: body.game_id || '',
        matchup: body.matchup || '',
        market: body.market || 'ATS',
        pick_side: body.pick_side || 'HOME',
        pick_label: body.pick_label || '',
        line: Number(body.line || 0),
        odds_decimal: Number(body.odds_decimal || 1.91),
        stake: Number(body.stake || 1000),
        status: 'PENDING',
        pnl: 0,
        note: body.note || '',
      });
      list = EPL._gradeStaticBets(list).list;
    } else if (path === '/api/bets/settle') {
      list = list.map((b) => {
        if (b.bet_id !== body.bet_id) return b;
        const st = body.status || 'PENDING';
        const pnl = st === 'WIN' ? +(b.stake * (b.odds_decimal - 1)).toFixed(2) : st === 'LOSS' ? -b.stake : 0;
        return { ...b, status: st, pnl };
      });
    } else if (path === '/api/bets/delete') {
      list = list.filter((b) => b.bet_id !== body.bet_id);
    }
    localStorage.setItem('epl.bets.v1', JSON.stringify(list));
    return { ok: true, bets: list };
  };

  // GitHub Pages / offline builds have no backend, so settle PENDING bets in the browser against the
  // bundled snapshot with the same rules as model_engine._grade_user_bets (ATS handicap from the picked
  // side, O/U total goals with exact = PUSH, 1X2 against result_1x2). Parlays (no game_id) stay manual.
  EPL._gradeStaticBets = function (list) {
    const byId = {};
    for (const g of (EPL.snap && EPL.snap.games) || []) byId[g.game_id] = g;
    let changed = false;
    const out = list.map((b) => {
      const gid = String(b.game_id || '');
      const g = byId[gid];
      if (b.status !== 'PENDING' || !gid || !g || g.status !== 'FINAL' || g.home_score == null) return b;
      const hs = Number(g.home_score);
      const as = Number(g.away_score);
      const mkt = String(b.market || 'ATS').toUpperCase();
      const side = String(b.pick_side || 'HOME').toUpperCase();
      const ln = Number(b.line || 0);
      let st = '';
      if (mkt === 'ATS') {
        const adj = side === 'HOME' ? hs - as + ln : as - hs + ln;
        st = adj > 0 ? 'WIN' : adj < 0 ? 'LOSS' : 'PUSH';
      } else if (mkt === 'OU') {
        const tot = hs + as;
        st = tot === ln ? 'PUSH' : (side === 'OVER' && tot > ln) || (side === 'UNDER' && tot < ln) ? 'WIN' : 'LOSS';
      } else if (mkt === '1X2') {
        st = side === g.result_1x2 ? 'WIN' : 'LOSS';
      }
      if (!st) return b;
      changed = true;
      const stake = Number(b.stake);
      const pnl = st === 'WIN' ? Math.round(stake * (Number(b.odds_decimal) - 1) * 100) / 100 : st === 'LOSS' ? -stake : 0;
      return { ...b, status: st, pnl };
    });
    return { list: out, changed };
  };

  EPL.openModal = function (title, bodyHtml, sizeCls) {
    const card = document.getElementById('appModalCard');
    if (card) card.className = 'modal-card' + (sizeCls ? ' ' + sizeCls : '');
    document.getElementById('appModalTitle').textContent = title;
    document.getElementById('appModalBody').innerHTML = bodyHtml;
    document.getElementById('appModalBd').classList.remove('hidden');
  };
  EPL.closeModal = function () {
    document.getElementById('appModalBd').classList.add('hidden');
  };

  // --- Compute Cross-Match Parlay Packages per Gameweek ---
  EPL.buildGwParlayPackages = function (gw, book) {
    const snap = EPL.snap || {};
    const games = (snap.games || []).filter((g) => Number(g.gameweek) === Number(gw));
    const isTw = book === 'TW';
    const baseOdds = isTw ? 1.75 : 1.91;

    // Extract best candidate leg per match (strictly max 1 leg per match!)
    const candidates = [];
    games.forEach((g) => {
      const p = g.pred || {};
      const h = EPL.teamOf(g.home_abbr);
      const a = EPL.teamOf(g.away_abbr);
      const spH = g.close_spread_home != null ? Number(g.close_spread_home) : -Number(p.fair_spread_home || 0);
      const totLine = g.close_total != null ? Number(g.close_total) : 2.5;

      // Candidate 1: ATS
      const atsSide = p.ats_pick !== 'PASS' ? p.ats_pick : p.ats_lean_side || 'HOME';
      const atsLine = atsSide === 'HOME' ? spH : -spH;
      const atsEdge = Number(p.ats_edge || 0);
      const atsLegRes = g.status === 'FINAL' && g.ats_winner
        ? (g.ats_winner === 'PUSH' ? 'PUSH' : g.ats_winner === atsSide ? 'WIN' : 'LOSS')
        : 'PENDING';

      // Candidate 2: OU
      const ouSide = p.ou_pick !== 'PASS' ? p.ou_pick : p.ou_lean_side || 'OVER';
      const ouEdge = Number(p.ou_edge || 0);
      const ouLegRes = g.status === 'FINAL' && g.ou_result
        ? (g.ou_result === 'PUSH' ? 'PUSH' : g.ou_result === ouSide ? 'WIN' : 'LOSS')
        : 'PENDING';

      const tierScore = (t) => (t === 'STRONG' ? 12 : t === 'LEAN' ? 5 : 0);
      const atsScore = tierScore(p.ats_tier) + atsEdge;
      const ouScore = tierScore(p.ou_tier) + ouEdge;

      if (atsScore >= ouScore) {
        const pickTm = atsSide === 'HOME' ? h : a;
        const probPct = Math.min(75, Math.max(48, 52.38 + atsEdge));
        candidates.push({
          game_id: g.game_id,
          tw_date: g.tw_date,
          kickoff_tw: g.kickoff_tw,
          status: g.status,
          home_abbr: g.home_abbr, away_abbr: g.away_abbr,
          home_zh: h.zh, away_zh: a.zh,
          home_logo: h.logo, away_logo: a.logo,
          home_score: g.home_score, away_score: g.away_score,
          market: 'ATS',
          market_zh: '亞洲讓球盤',
          side: atsSide,
          line: atsLine,
          pick_label_zh: `${pickTm.zh} ${EPL.fmtSpread(atsLine)}`,
          tier: p.ats_tier || 'PASS',
          edge: atsEdge,
          win_prob_pct: +probPct.toFixed(1),
          intl_odds: 1.91,
          tw_odds: 1.75,
          leg_result: atsLegRes,
          reason_zh: p.rationale_zh || `泊松過盤率優勢 ${EPL.fmtSigned(atsEdge, 1)}%`,
          score: atsScore,
        });
      } else {
        const probPct = Math.min(75, Math.max(48, 52.38 + ouEdge));
        candidates.push({
          game_id: g.game_id,
          tw_date: g.tw_date,
          kickoff_tw: g.kickoff_tw,
          status: g.status,
          home_abbr: g.home_abbr, away_abbr: g.away_abbr,
          home_zh: h.zh, away_zh: a.zh,
          home_logo: h.logo, away_logo: a.logo,
          home_score: g.home_score, away_score: g.away_score,
          market: 'OU',
          market_zh: '大小球盤',
          side: ouSide,
          line: totLine,
          pick_label_zh: `${ouSide === 'OVER' ? '大球' : '小球'} ${totLine}`,
          tier: p.ou_tier || 'PASS',
          edge: ouEdge,
          win_prob_pct: +probPct.toFixed(1),
          intl_odds: 1.91,
          tw_odds: 1.75,
          leg_result: ouLegRes,
          reason_zh: `泊松預期總進球 ${Number(p.pred_total || 2.6).toFixed(2)} 球 vs 盤口 ${totLine}`,
          score: ouScore,
        });
      }
    });

    candidates.sort((a, b) => b.score - a.score);

    function gradeDirect(legs) {
      if (legs.some((l) => l.leg_result === 'PENDING')) return { status: 'PENDING', mult: 0 };
      if (legs.some((l) => l.leg_result === 'LOSS')) return { status: 'LOSS', mult: 0 };
      if (legs.every((l) => l.leg_result === 'PUSH')) return { status: 'PUSH', mult: 1 };
      let mult = 1;
      legs.forEach((l) => { if (l.leg_result === 'WIN') mult *= baseOdds; });
      return { status: 'WIN', mult };
    }

    const packages = [];
    if (candidates.length >= 2) {
      const l2 = candidates.slice(0, 2);
      const jp = (l2[0].win_prob_pct / 100) * (l2[1].win_prob_pct / 100);
      const gr = gradeDirect(l2);
      packages.push({
        key: 'anchor_2x1',
        type: 'DIRECT',
        bets_count: 1,
        badge_zh: '⭐ 穩健首選 · 2 串 1 雙星主推',
        title_zh: `GW${gw} 雙強跨場 2 串 1`,
        subtitle_zh: '嚴選本輪模型 Edge 最高且避開和局陷阱之兩場賽事，單注過關期望值最穩健。',
        grade_zh: l2.every((x) => x.tier === 'STRONG') ? '🔥 雙強推 S 級' : '✅ 精選 A 級',
        grade_cls: l2.every((x) => x.tier === 'STRONG') ? 'strong' : 'ok',
        legs: l2,
        intl_odds: +(1.91 * 1.91).toFixed(2),
        tw_odds: +(1.75 * 1.75).toFixed(2),
        joint_prob_pct: +(jp * 100).toFixed(1),
        ev_pct: +((jp * baseOdds * baseOdds - 1) * 100).toFixed(1),
        status: gr.status,
        return_mult: gr.mult,
      });
    }
    if (candidates.length >= 3) {
      const l3 = candidates.slice(0, 3);
      const p1 = l3[0].win_prob_pct / 100, p2 = l3[1].win_prob_pct / 100, p3 = l3[2].win_prob_pct / 100;
      const jp3 = p1 * p2 * p3;
      const gr3 = gradeDirect(l3);
      packages.push({
        key: 'boost_3x1',
        type: 'DIRECT',
        bets_count: 1,
        badge_zh: '🚀 高賠進取 · 3 串 1 黃金三星',
        title_zh: `GW${gw} 黃金三星 3 串 1`,
        subtitle_zh: '串聯本輪前三高優勢場次衝刺高倍賠率，建議以小額娛樂注碼參與。',
        grade_zh: '⚡ 高賠衝刺',
        grade_cls: 'info',
        legs: l3,
        intl_odds: +(1.91 ** 3).toFixed(2),
        tw_odds: +(1.75 ** 3).toFixed(2),
        joint_prob_pct: +(jp3 * 100).toFixed(1),
        ev_pct: +((jp3 * (baseOdds ** 3) - 1) * 100).toFixed(1),
        status: gr3.status,
        return_mult: gr3.mult,
      });

      // 3串4 (Trixie: 3 x 2-folds + 1 x 3-fold = 4 bets)
      const pAtLeast2 = jp3 + p1 * p2 * (1 - p3) + p1 * (1 - p2) * p3 + (1 - p1) * p2 * p3;
      const combos = [[l3[0], l3[1]], [l3[0], l3[2]], [l3[1], l3[2]], [l3[0], l3[1], l3[2]]];
      let comboMultSum = 0;
      let cashed = 0;
      const anyPend = l3.some((x) => x.leg_result === 'PENDING');
      if (!anyPend) {
        combos.forEach((cb) => {
          const gcb = gradeDirect(cb);
          if (gcb.status === 'WIN' || gcb.status === 'PUSH') {
            comboMultSum += gcb.mult;
            if (gcb.status === 'WIN') cashed += 1;
          }
        });
      }
      packages.push({
        key: 'shield_3x4',
        type: 'COMBO',
        bets_count: 4,
        badge_zh: '🛡️ 防斷龍容錯 · 3 串 4 複式組合（Trixie）',
        title_zh: `GW${gw} 防補時絕殺 3 串 4（共 4 注）`,
        subtitle_zh: '內含 3 注「2串1」＋ 1 注「3串1」；即使英超常見補時被扳平倒 1 關（3 過 2），仍可領回雙星派彩保本回血！',
        grade_zh: '🛡️ 容錯推薦',
        grade_cls: 'ok',
        legs: l3,
        max_mult: +(3 * (baseOdds ** 2) + (baseOdds ** 3)).toFixed(2),
        hit2_mult: +(baseOdds ** 2).toFixed(2),
        at_least_2_prob_pct: +(pAtLeast2 * 100).toFixed(1),
        status: anyPend ? 'PENDING' : cashed === 4 ? 'WIN' : cashed >= 1 ? 'PARTIAL' : 'LOSS',
        cashed_combos: cashed,
        return_mult: comboMultSum,
      });
    }

    return { games, candidates, packages };
  };

  // --- Full Single-Match Boxscore, Team Stats & Key Events ---
  // player row cols: [0:pid, 1:name, 2:pos, 3:jersey, 4:starter, 5:sub_in, 6:played, 7:goals, 8:assists, 9:shots, 10:sot, 11:saves, 12:fouls, 13:yc, 14:rc]
  function renderClubMatchPlayersTable(clubAbbr, rows) {
    const tm = EPL.teamOf(clubAbbr);
    if (!rows || !rows.length) {
      return `<div class="empty-box" style="padding:18px">尚無 ${EPL.esc(tm.zh)} 單場球員出場明細（待開賽或同步中）</div>`;
    }
    return `
      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
          <div style="display:flex;align-items:center;gap:8px">
            <img src="${EPL.esc(tm.logo)}" alt="" style="width:24px;height:24px;object-fit:contain">
            <strong class="tm-link" data-team-link="${EPL.esc(tm.abbr)}" style="font-size:14px">${EPL.esc(tm.zh)} (${EPL.esc(tm.abbr)}) 出賽陣容數據</strong>
          </div>
          <span style="font-size:11.5px;color:#64748b">先發 ${rows.filter((r) => r[4] === 1).length} 人 · 替補上場 ${rows.filter((r) => r[4] !== 1).length} 人</span>
        </div>
        <div class="nba-tbl-wrap standalone">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="left sticky-pl no-sort" style="left:0">球員 PLAYER</th>
                <th class="no-sort">位置</th>
                <th class="no-sort">角色</th>
                <th class="no-sort col-active">進球 G</th>
                <th class="no-sort">助攻 A</th>
                <th class="no-sort">射門 SH</th>
                <th class="no-sort">射正 SOT</th>
                <th class="no-sort">撲救 SV</th>
                <th class="no-sort">犯規 FC</th>
                <th class="no-sort">黃牌 YC</th>
                <th class="no-sort">紅牌 RC</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((r) => `
                <tr>
                  <td class="left sticky-pl" style="left:0">
                    <span style="font-weight:700;color:#0f172a">${EPL.esc(r[1])}</span>
                    ${r[3] ? `<span style="color:#94a3b8;font-size:11px;margin-left:3px">#${EPL.esc(r[3])}</span>` : ''}
                  </td>
                  <td style="color:#64748b">${EPL.esc(r[2] || '—')}</td>
                  <td>${r[4] === 1 ? '<span class="chip ok">先發</span>' : '<span class="chip muted">替補</span>'}</td>
                  <td class="col-active">${r[7] > 0 ? `⚽ ${r[7]}` : '0'}</td>
                  <td>${r[8] > 0 ? `🎯 ${r[8]}` : '0'}</td>
                  <td>${r[9]}</td>
                  <td>${r[10]}</td>
                  <td>${r[11]}</td>
                  <td>${r[12]}</td>
                  <td style="color:${r[13] > 0 ? '#b45309' : '#64748b'};font-weight:${r[13] > 0 ? '800' : '400'}">${r[13] > 0 ? `🟨 ${r[13]}` : '0'}</td>
                  <td style="color:${r[14] > 0 ? '#b91c1c' : '#64748b'};font-weight:${r[14] > 0 ? '800' : '400'}">${r[14] > 0 ? `🟥 ${r[14]}` : '0'}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
  }

  EPL.renderGameBoxscoreHtml = function (gid) {
    const g = ((EPL.snap && EPL.snap.games) || []).find((x) => x.game_id === gid);
    if (!g) return '<div class="empty-box">找不到該場英超賽事資料</div>';
    const h = EPL.teamOf(g.home_abbr);
    const a = EPL.teamOf(g.away_abbr);
    const box = ((EPL.snap && EPL.snap.game_boxscores) || {})[gid] || { home: [], away: [] };
    const ts = g.team_stats || {};
    const hSt = ts.home || {};
    const aSt = ts.away || {};
    const evs = g.key_events || [];

    const statItems = [
      ['控球率 (%)', hSt.possessionPct, aSt.possessionPct],
      ['總射門數', hSt.totalShots, aSt.totalShots],
      ['射正球門', hSt.shotsOnTarget, aSt.shotsOnTarget],
      ['角球數', hSt.wonCorners, aSt.wonCorners],
      ['犯規次數', hSt.foulsCommitted, aSt.foulsCommitted],
    ].filter((it) => it[1] != null || it[2] != null);

    const statsHtml = statItems.length
      ? `<div class="card" style="padding:12px 16px">
          <div style="font-weight:800;font-size:13px;margin-bottom:8px;color:#334155">📊 全場技術統計對比（主隊 ${EPL.esc(h.zh)} vs 客隊 ${EPL.esc(a.zh)}）</div>
          <div style="display:flex;flex-direction:column;gap:7px">
            ${statItems.map(([lbl, hv, av]) => {
              const hn = parseFloat(hv || 0), an = parseFloat(av || 0);
              const tot = hn + an || 1;
              const hp = Math.round((hn / tot) * 100);
              return `
                <div>
                  <div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;margin-bottom:2px">
                    <span style="color:#059669">${EPL.esc(hv ?? '0')}</span>
                    <span style="color:#64748b">${EPL.esc(lbl)}</span>
                    <span style="color:#2563eb">${EPL.esc(av ?? '0')}</span>
                  </div>
                  <div style="display:flex;height:7px;border-radius:99px;overflow:hidden;background:#e2e8f0">
                    <div style="width:${hp}%;background:#059669"></div>
                    <div style="width:${100 - hp}%;background:#3b82f6"></div>
                  </div>
                </div>`;
            }).join('')}
          </div>
        </div>`
      : '';

    const eventsHtml = evs.length
      ? `<div class="card" style="padding:11px 15px;background:#f8fafc">
          <div style="font-weight:800;font-size:12.5px;color:#334155;margin-bottom:6px">⏱️ 關鍵進球與紅黃牌時間軸</div>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            ${evs.map((e) => {
              const ic = e.kind === 'goal' ? '⚽' : e.kind === 'rc' ? '🟥' : '🟨';
              const cls = e.kind === 'goal' ? 'ok' : e.kind === 'rc' ? 'bad' : 'warn';
              return `<span class="chip ${cls}">${ic} ${EPL.esc(e.clock)} ${EPL.esc(e.team)} · ${EPL.esc(e.player)}</span>`;
            }).join('')}
          </div>
        </div>`
      : '';

    return `
      <div style="display:flex;flex-direction:column;gap:12px">
        <div class="card" style="background:#f8fafc;padding:12px 16px">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:10px">
              <img src="${EPL.esc(h.logo)}" alt="" style="width:36px;height:36px;object-fit:contain">
              <div>
                <div style="font-weight:800;font-size:15px">GW${g.gameweek || '—'} · 主 ${EPL.esc(h.zh)} <span style="color:#059669;font-size:18px;margin:0 6px">${g.home_score ?? '—'} : ${g.away_score ?? '—'}</span> 客 ${EPL.esc(a.zh)}</div>
                <div style="font-size:12px;color:#64748b">台灣時間 ${EPL.esc(g.kickoff_tw)} · 半場 (${g.ht_home ?? '—'}:${g.ht_away ?? '—'}) · 球場：${EPL.esc(g.venue || h.stadium || '')}</div>
              </div>
              <img src="${EPL.esc(a.logo)}" alt="" style="width:36px;height:36px;object-fit:contain">
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              ${g.close_spread_home != null ? `<span class="chip info">讓球盤：主 ${EPL.fmtSpread(g.close_spread_home)} (${g.ats_winner === 'HOME' ? '主過盤' : g.ats_winner === 'AWAY' ? '客過盤' : g.ats_winner === 'PUSH' ? '走水' : '待結算'})</span>` : ''}
              ${g.close_total ? `<span class="chip strong">大小球 ${g.close_total}：總進球 ${g.total_goals ?? '—'} (${g.ou_result === 'OVER' ? '大球' : g.ou_result === 'UNDER' ? '小球' : '待結算'})</span>` : ''}
              ${g.btts_yes != null ? `<span class="chip ${g.btts_yes ? 'ok' : 'muted'}">雙進球 BTTS：${g.btts_yes ? '是 (Yes)' : '否 (No)'}</span>` : ''}
            </div>
          </div>
        </div>
        ${eventsHtml}
        ${statsHtml}
        ${renderClubMatchPlayersTable(g.home_abbr, box.home)}
        ${renderClubMatchPlayersTable(g.away_abbr, box.away)}
      </div>`;
  };

  EPL.openGameBoxscoreModal = function (gid) {
    const g = ((EPL.snap && EPL.snap.games) || []).find((x) => x.game_id === gid);
    if (!g) return;
    const h = EPL.teamOf(g.home_abbr);
    const a = EPL.teamOf(g.away_abbr);
    EPL.openModal(`⚽ 單場完整技術統計與陣容 Boxscore · ${h.zh} vs ${a.zh}`, EPL.renderGameBoxscoreHtml(gid), 'modal-xl');
  };

  // --- Official FPL Player xG / xA / Availability Profile Modal ---
  EPL.openPlayerModal = function (pid) {
    const snap = EPL.snap || {};
    const p = (snap.player_stats || []).find((x) => String(x.pid) === String(pid) || x.name === pid);
    if (!p) {
      EPL.toast('找不到該球員 FPL 統計資料');
      return;
    }
    const tm = EPL.teamOf(p.team);
    const stChip = p.status === 'a'
      ? '<span class="chip ok">✅ 健康可出賽</span>'
      : `<span class="chip warn">🏥 ${EPL.esc(p.news || '傷停觀察')}</span>`;

    const bodyHtml = `
      <div style="display:flex;flex-direction:column;gap:14px">
        <div class="card" style="background:linear-gradient(135deg,#ecfdf5 0%,#ffffff 100%);display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:14px">
            <img src="${EPL.esc(p.headshot)}" alt="" style="width:64px;height:64px;border-radius:50%;object-fit:cover;background:#fff;border:2px solid #a7f3d0" onerror="this.src='${EPL.esc(tm.logo)}'">
            <div>
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <span style="font-size:20px;font-weight:900;color:#0f172a">${EPL.esc(p.name)}</span>
                <span style="font-size:13.5px;color:#475569">(${EPL.esc(p.full_name)})</span>
                ${stChip}
              </div>
              <div style="font-size:13px;color:#475569;margin-top:4px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
                <span class="tm-link" data-team-link="${EPL.esc(p.team)}" style="font-weight:700;color:#059669">⚽ ${EPL.esc(tm.zh)} (${EPL.esc(p.team)})</span>
                <span>位置：${EPL.esc(p.pos)}</span>
                <span>上場時間：${p.minutes} 分鐘（${p.nineties} 場滿場折算）</span>
                <span>FPL 身價：£${Number(p.cost_m).toFixed(1)}m</span>
              </div>
            </div>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <div class="th-stat"><div class="th-stat-lbl">進球 / 助攻</div><div class="th-stat-val" style="color:#059669">${p.goals}G / ${p.assists}A</div></div>
            <div class="th-stat"><div class="th-stat-lbl">預期進球 xG</div><div class="th-stat-val">${Number(p.xg).toFixed(2)}</div></div>
            <div class="th-stat"><div class="th-stat-lbl">預期助攻 xA</div><div class="th-stat-val">${Number(p.xa).toFixed(2)}</div></div>
            <div class="th-stat"><div class="th-stat-lbl">每90分 xGI</div><div class="th-stat-val" style="color:#1d4ed8">${Number(p.xgi_per90).toFixed(2)}</div></div>
          </div>
        </div>
        <div class="card">
          <h4 style="margin:0 0 8px;font-size:14px">📐 進階運彩量化解讀（實際終結 vs 預期進球 xG 偏離度）</h4>
          <div style="font-size:13px;color:#334155;line-height:1.65">
            本季實際進球 <strong>${p.goals}</strong> 球 vs 官方預期進球 <strong>${Number(p.xg).toFixed(2)} xG</strong>（差值 <strong>${EPL.fmtSigned(p.goals - p.xg, 2)}</strong>）；
            實際參與進球（G+A）<strong>${p.ga_sum}</strong> 次 vs 預期參與進球 <strong>${Number(p.xgi).toFixed(2)} xGI</strong>。
            零封場數 <strong>${p.cs}</strong> 場 · 門將撲救 <strong>${p.saves}</strong> 次 · 近期狀態指數 Form <strong>${Number(p.form).toFixed(1)}</strong> · 紅黃牌 <strong>${p.yc}黃 / ${p.rc}紅</strong>。
          </div>
        </div>
      </div>`;
    EPL.openModal(`🏃 英超官方 FPL 球員 xG 數據卡 · ${p.name}`, bodyHtml, 'modal-lg');
  };

  // --- Quick Bet Slip Modal（➕ 記讓球單／記大小球單）---
  // Guided form: market tabs (the card's button preselects 讓球 or 大小球; 獨贏 1X2 has no card button) →
  // ① tap the side you back (sets `pick_side`, which auto-settlement grades) → ② line + odds → ③ stake,
  // with a live payout preview. Rules mirror model_engine._grade_user_bets: the handicap is read from the
  // picked team's side, and only 0.5-step lines are accepted because quarter lines (−0.75, 2.25) settle
  // as split stakes at real bookmakers, which the ledger does not model.
  EPL.openQuickBetModal = function (gid, market) {
    const g = ((EPL.snap && EPL.snap.games) || []).find((x) => x.game_id === gid);
    if (!g) return;
    const h = EPL.teamOf(g.home_abbr);
    const a = EPL.teamOf(g.away_abbr);
    const p = g.pred || {};
    const matchup = `GW${g.gameweek} ${h.zh} vs ${a.zh}`;
    const money = (n) => Math.round(n).toLocaleString('en-US');
    const num = (v) => (v == null || v === '' || Number.isNaN(Number(v)) ? null : Number(v));
    const x12 = [
      { side: 'HOME', name: `主勝 · ${h.zh}`, odds: num(g.ml_home_dec) || 2.1, prob: Number(p.prob_home_pct || 0), res: `「${h.zh}」主場贏球`, label: `${h.zh} 主勝 (1X2)` },
      { side: 'DRAW', name: '和局', odds: num(g.ml_draw_dec) || 3.4, prob: Number(p.prob_draw_pct || 0), res: '踢成和局', label: '和局 (1X2)' },
      { side: 'AWAY', name: `客勝 · ${a.zh}`, odds: num(g.ml_away_dec) || 3.2, prob: Number(p.prob_away_pct || 0), res: `「${a.zh}」客場贏球`, label: `${a.zh} 客勝 (1X2)` },
    ];
    x12.forEach((o) => { o.ev = (o.prob / 100) * o.odds - 1; });
    const EXPLAIN = {
      ATS: '⚽ <strong>亞洲讓球盤</strong>：把讓球加到你押的那一隊進球數上再比輸贏（以 90 分鐘含傷停補時的比分計算）。負數是讓球：押 −0.5 要贏球，和局算輸；正數是受讓：押 +0.5 贏球或和局都算贏。',
      OU: '🥅 <strong>大小球</strong>：猜兩隊在 90 分鐘（含傷停補時）總共進幾球，會大於還是小於盤口線，跟哪一隊贏無關。',
      '1X2': '🏆 <strong>獨贏（1X2）</strong>：不讓球，直接猜 90 分鐘（含傷停補時）的賽果是主隊贏、和局還是客隊贏，猜中就贏。',
    };
    let mkt = market === 'OU' || market === '1X2' ? market : 'ATS';
    let opts = [];
    let recSide = '';
    let side = '';
    let lineBase = null;  // ATS: home-based handicap; OU: total goals
    let saving = false;

    // Handicap read from the picked team: it covers when (its goal margin + L) > 0; whole-number L can push.
    function atsRule(L) {
      const need = -L;
      const isWhole = Number.isInteger(need);
      const minWin = Math.floor(need) + 1;
      const loseMax = isWhole ? need - 1 : minWin - 1;
      return {
        win: minWin >= 2 ? `贏 ${minWin} 球以上` : minWin === 1 ? '贏球' : minWin === 0 ? '贏球或和局' : `輸 ${-minWin} 球以內、和局或贏球`,
        lose: loseMax >= 2 ? `只贏 ${loseMax} 球以內、和局或輸球` : loseMax === 1 ? '只贏 1 球、和局或輸球' : loseMax === 0 ? '和局或輸球' : loseMax === -1 ? '輸球' : `輸 ${-loseMax} 球以上`,
        push: isWhole ? (need > 0 ? `剛好贏 ${need} 球` : need < 0 ? `剛好輸 ${-need} 球` : '踢成和局') : '',
      };
    }
    // Totals: a .5 line never pushes; on a whole-number line an exact hit is a push (stake refunded).
    const ouCut = (ln) => ({ over: Math.floor(ln) + 1, under: Math.ceil(ln) - 1, push: Number.isInteger(ln) ? ln : null });
    const sideLine = (s) => (s === 'HOME' ? lineBase : -lineBase);
    const optOf = (s) => opts.find((o) => o.side === s) || opts[0];

    EPL.openModal(
      `➕ 加入注單追蹤 · ${matchup}`,
      `<form id="quickBetForm" class="qb-form" novalidate>
        <div class="qb-tabs" role="tablist" aria-label="玩法">
          <button type="button" class="qb-tab" role="tab" data-qb-mkt="ATS">⚽ 讓球盤</button>
          <button type="button" class="qb-tab" role="tab" data-qb-mkt="OU">🥅 大小球</button>
          <button type="button" class="qb-tab" role="tab" data-qb-mkt="1X2">🏆 獨贏 1X2</button>
        </div>
        <div class="qb-explain" id="qbExplain"></div>
        <div class="qb-step" role="radiogroup" aria-labelledby="qbStepPick">
          <div class="qb-step-title" id="qbStepPick"></div>
          <div class="qb-opts" id="qbOpts"></div>
          <div class="qb-line-row" id="qbLineRow">
            <label for="qbLine" id="qbLineLbl"></label>
            <input type="number" step="0.5" class="inp" id="qbLine">
            <span id="qbLineUnit"></span>
            <span class="qb-hint" id="qbLineHint"></span>
          </div>
        </div>
        <div class="qb-fields">
          <div class="qb-field">
            <label class="qb-step-title" for="qbOdds">② 賠率</label>
            <input type="number" inputmode="decimal" step="0.01" min="1.01" class="inp" id="qbOdds">
            <div class="qb-chips" id="qbOddsChips"><button type="button" class="qb-chip" data-qb-odds="1.75">台灣運彩 1.75</button><button type="button" class="qb-chip" data-qb-odds="1.91">國際盤 1.91</button></div>
            <span class="qb-hint" id="qbOddsHint"></span>
          </div>
          <div class="qb-field">
            <label class="qb-step-title" for="qbStake">③ 投注金額（NT$）</label>
            <input type="number" inputmode="numeric" step="100" min="1" class="inp" id="qbStake" value="1000">
            <div class="qb-chips">${[100, 500, 1000, 2000, 5000].map((v) => `<button type="button" class="qb-chip" data-qb-stake="${v}">${money(v)}</button>`).join('')}</div>
          </div>
        </div>
        <div class="qb-preview" id="qbPreview" aria-live="polite"></div>
        <label class="qb-field">
          <span class="qb-step-title">備註（選填）</span>
          <input class="inp" id="qbNote" maxlength="200" placeholder="例如：確認先發 11 人名單後進場">
        </label>
        <div class="qb-foot">📌 這裡只是幫你<strong>記帳</strong>，不會真的下注。完賽後系統會依 90 分鐘賽果自動對獎、計算損益，可到「📝 注單追蹤」查看${EPL.isStatic ? '（公開版的注單只存在這台裝置的瀏覽器）' : ''}。</div>
        <div class="qb-actions">
          <button type="button" class="btn" data-qb-cancel>取消</button>
          <button type="submit" class="btn btn-primary" id="qbSubmit">💾 儲存注單</button>
        </div>
      </form>`
    );

    const form = document.getElementById('quickBetForm');
    const lineInp = document.getElementById('qbLine');
    const oddsInp = document.getElementById('qbOdds');
    const stakeInp = document.getElementById('qbStake');
    const preview = document.getElementById('qbPreview');
    const submitBtn = document.getElementById('qbSubmit');

    function setMarket(m) {
      mkt = m;
      form.querySelectorAll('[data-qb-mkt]').forEach((b) => {
        const on = b.getAttribute('data-qb-mkt') === m;
        b.classList.toggle('on', on);
        b.setAttribute('aria-selected', on ? 'true' : 'false');
      });
      let chip;
      let title;
      if (m === 'ATS') {
        opts = [{ side: 'HOME', team: h, tag: '主' }, { side: 'AWAY', team: a, tag: '客' }];
        const isPick = Boolean(p.ats_tier) && p.ats_tier !== 'PASS' && (p.ats_pick === 'HOME' || p.ats_pick === 'AWAY');
        recSide = isPick ? p.ats_pick : (p.ats_lean_side === 'AWAY' ? 'AWAY' : 'HOME');
        chip = isPick ? '<span class="chip strong">👍 模型推薦</span>' : '<span class="chip muted">模型傾向</span>';
        lineBase = num(g.close_spread_home);
        title = `① 你看好哪一隊過盤？（點一下選擇）<span class="qb-step-sub">模型預估：主勝 ${Number(p.prob_home_pct || 0).toFixed(1)}% · 和局 ${Number(p.prob_draw_pct || 0).toFixed(1)}% · 客勝 ${Number(p.prob_away_pct || 0).toFixed(1)}%</span>`;
      } else if (m === 'OU') {
        opts = [{ side: 'OVER', name: '大球 OVER' }, { side: 'UNDER', name: '小球 UNDER' }];
        const isPick = Boolean(p.ou_tier) && p.ou_tier !== 'PASS' && (p.ou_pick === 'OVER' || p.ou_pick === 'UNDER');
        recSide = isPick ? p.ou_pick : (p.ou_lean_side === 'UNDER' ? 'UNDER' : 'OVER');
        chip = isPick ? '<span class="chip strong">👍 模型推薦</span>' : '<span class="chip muted">模型傾向</span>';
        lineBase = num(g.close_total);
        title = `① 押大球還是小球？（點一下選擇）${p.pred_total != null ? `<span class="qb-step-sub">模型預估總進球 ${Number(p.pred_total).toFixed(2)} 球</span>` : ''}`;
      } else {
        opts = x12;
        const best = x12.reduce((mx, o) => (o.ev > mx.ev ? o : mx), x12[0]);
        const top = x12.reduce((mx, o) => (o.prob > mx.prob ? o : mx), x12[0]);
        recSide = best.ev > 0 ? best.side : top.side;
        chip = best.ev > 0 ? `<span class="chip strong">💎 有價值 EV +${(best.ev * 100).toFixed(1)}%</span>` : '<span class="chip muted">模型最看好</span>';
        lineBase = 0;
        title = '① 猜哪一個賽果？（點一下選擇）';
      }
      document.getElementById('qbExplain').innerHTML = EXPLAIN[m];
      document.getElementById('qbStepPick').innerHTML = title;
      const box = document.getElementById('qbOpts');
      box.classList.toggle('three', m === '1X2');
      box.innerHTML = opts.map((o) => `
        <label class="qb-opt" data-qb-side="${o.side}">
          <input type="radio" name="qbSide" value="${o.side}">
          <span class="qb-opt-hd">
            <span class="qb-opt-name"><span class="qb-radio" aria-hidden="true"></span>${EPL.esc(m === 'ATS' ? `${o.team.zh}（${o.tag}）` : o.name)}${m === 'ATS' ? `<span class="qb-opt-line" data-qb-line="${o.side}"></span>` : ''}</span>
            ${o.side === recSide ? chip : ''}
          </span>
          ${m === '1X2'
            ? `<span class="qb-opt-sub">模型機率 ${o.prob.toFixed(1)}%</span><span class="qb-opt-sub">本站參考賠率 <strong>${o.odds.toFixed(2)}</strong></span>`
            : `<span class="qb-opt-sub" data-qb-desc="${o.side}"></span>`}
        </label>`).join('');
      document.getElementById('qbLineRow').hidden = m === '1X2';
      document.getElementById('qbLineLbl').textContent = m === 'ATS' ? '讓球' : '大小球盤口';
      document.getElementById('qbOddsChips').hidden = m === '1X2';
      document.getElementById('qbOddsHint').textContent = m === '1X2'
        ? (g.ml_home_dec ? '已帶入本站的 1X2 參考賠率，請改成你實際下注時看到的數字。' : '本場還沒有 1X2 賠率，預設值只是參考，請改成你實際下注時看到的數字。')
        : '讓球、大小球沒有固定賠率：國際盤常見 1.91、台灣運彩常見 1.75，請改成你實際下注時看到的數字。';
      if (m !== '1X2') oddsInp.value = '1.91';
      selectSide(recSide);
    }

    const showLine = () => { lineInp.value = lineBase == null ? '' : String(mkt === 'ATS' ? sideLine(side) : lineBase); };
    const lineOk = () => mkt === '1X2' || (lineBase != null && Number.isInteger(lineBase * 2)
      && (mkt === 'ATS' ? Math.abs(lineBase) <= 5 : lineBase >= 0.5 && lineBase <= 10));

    function refresh() {
      const odds = Number(oddsInp.value);
      const stake = Number(stakeInp.value);
      const lOk = lineOk();
      const oddsOk = oddsInp.value.trim() !== '' && odds >= 1.01;
      const stakeOk = stakeInp.value.trim() !== '' && stake >= 1;
      lineInp.classList.toggle('inp-err', !lOk);
      oddsInp.classList.toggle('inp-err', !oddsOk);
      stakeInp.classList.toggle('inp-err', !stakeOk);
      form.querySelectorAll('[data-qb-stake]').forEach((b) => b.classList.toggle('on', Number(b.getAttribute('data-qb-stake')) === stake));
      form.querySelectorAll('[data-qb-odds]').forEach((b) => b.classList.toggle('on', Number(b.getAttribute('data-qb-odds')) === odds));

      const hint = document.getElementById('qbLineHint');
      const unit = document.getElementById('qbLineUnit');
      if (mkt === 'ATS') {
        unit.textContent = `球（${optOf(side).team.zh}）`;
        hint.textContent = g.close_spread_home == null
          ? '本場還沒開盤，請填你下注時看到的讓球；負數＝讓球、正數＝受讓。'
          : '負數＝讓球、正數＝受讓；已帶入本站參考盤口，請對照你下注的盤口。';
      } else if (mkt === 'OU') {
        unit.textContent = '球';
        hint.textContent = g.close_total == null ? '本場還沒開盤，請填你下注時看到的大小球盤口。' : '';
      }
      if (lOk && mkt === 'ATS') {
        opts.forEach((o) => {
          const L = sideLine(o.side);
          const r = atsRule(L);
          form.querySelector(`[data-qb-line="${o.side}"]`).textContent = EPL.fmtSpread(L);
          form.querySelector(`[data-qb-desc="${o.side}"]`).textContent = `${r.win}就算過盤${r.push ? `（${r.push}走水）` : ''}`;
        });
      } else if (lOk && mkt === 'OU') {
        const c = ouCut(lineBase);
        form.querySelector('[data-qb-desc="OVER"]').textContent = `總進球 ${c.over} 球以上`;
        form.querySelector('[data-qb-desc="UNDER"]').textContent = c.under > 0 ? `總進球 ${c.under} 球以下` : '雙方都沒進球（0 球）';
        hint.textContent = `${lineBase} 代表 ${c.over} 球以上算「大」、${c.under} 球以下算「小」${c.push != null ? `，剛好 ${c.push} 球算走水（退回本金）` : ''}；請對照你下注的盤口。`;
      }

      const errs = [];
      if (!lOk) {
        errs.push(mkt === 'ATS'
          ? '讓球請填 0.5 的倍數，例如 -0.5、+1、-1.5（-0.75 這類四分之一盤本站無法正確對獎）'
          : '大小球盤口請填 0.5 的倍數，例如 2.5、3（2.25 這類四分之一盤本站無法正確對獎）');
      }
      if (!oddsOk) errs.push('賠率要大於 1，例如 1.91');
      if (!stakeOk) errs.push('請填投注金額，例如 1000');
      submitBtn.disabled = saving || errs.length > 0;
      if (errs.length) {
        preview.className = 'qb-preview invalid';
        preview.innerHTML = errs.map((e) => `<div>⚠️ ${e}</div>`).join('');
        return;
      }
      const back = stake * odds;
      let win;
      let lose;
      let push = '';
      if (mkt === 'ATS') {
        const nm = `「${optOf(side).team.zh}」`;
        const r = atsRule(sideLine(side));
        win = nm + r.win;
        lose = nm + r.lose;
        push = r.push ? nm + r.push : '';
      } else if (mkt === 'OU') {
        const c = ouCut(lineBase);
        win = side === 'OVER' ? `總進球 ${c.over} 球以上` : `總進球 ${c.under} 球以下`;
        lose = side === 'OVER' ? `總進球 ${c.under} 球以下` : `總進球 ${c.over} 球以上`;
        push = c.push != null ? `總進球剛好 ${c.push} 球` : '';
      } else {
        win = optOf(side).res;
        lose = '是其他賽果';
      }
      preview.className = 'qb-preview';
      preview.innerHTML = `
        <div>💰 若${EPL.esc(win)} → 可領回 <strong>NT$${money(back)}</strong>（含本金，淨賺 <strong>+${money(back - stake)}</strong>）</div>
        <div class="loss">若${EPL.esc(lose)} → 損失本金 NT$${money(stake)}</div>
        ${push ? `<div class="push">若${EPL.esc(push)} → 走水，退回本金 NT$${money(stake)}</div>` : ''}`;
    }

    function selectSide(s) {
      side = s;
      form.querySelectorAll('.qb-opt').forEach((el) => {
        const on = el.getAttribute('data-qb-side') === s;
        el.classList.toggle('selected', on);
        el.querySelector('input').checked = on;
      });
      if (mkt === '1X2') oddsInp.value = optOf(s).odds.toFixed(2);  // each outcome has its own price
      else showLine();  // the handicap flips sign with the team you back
      refresh();
    }

    form.querySelectorAll('[data-qb-mkt]').forEach((b) => {
      b.addEventListener('click', () => { if (b.getAttribute('data-qb-mkt') !== mkt) setMarket(b.getAttribute('data-qb-mkt')); });
    });
    form.addEventListener('change', (ev) => {
      if (ev.target.name === 'qbSide' && ev.target.checked) selectSide(ev.target.value);
    });
    lineInp.addEventListener('input', () => {
      const v = num(lineInp.value);
      lineBase = v == null ? null : (mkt === 'ATS' && side === 'AWAY' ? -v : v);
      refresh();
    });
    form.querySelectorAll('[data-qb-stake]').forEach((b) => {
      b.addEventListener('click', () => { stakeInp.value = b.getAttribute('data-qb-stake'); refresh(); });
    });
    form.querySelectorAll('[data-qb-odds]').forEach((b) => {
      b.addEventListener('click', () => { oddsInp.value = b.getAttribute('data-qb-odds'); refresh(); });
    });
    [oddsInp, stakeInp].forEach((inp) => inp.addEventListener('input', refresh));
    // IME-safe: the Enter that confirms a 注音／倉頡 candidate in 備註 must not submit the form.
    form.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' && ev.target.tagName === 'INPUT' && !EPL.isEnterSend(ev)) ev.preventDefault();
    });
    form.querySelector('[data-qb-cancel]').addEventListener('click', EPL.closeModal);
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      refresh();
      if (saving || submitBtn.disabled) return;
      saving = true;
      submitBtn.disabled = true;
      submitBtn.textContent = '⏳ 儲存中…';
      const L = mkt === 'ATS' ? sideLine(side) : mkt === 'OU' ? lineBase : 0;
      const o = optOf(side);
      try {
        const res = await EPL.apiPost('/api/bets/add', {
          tw_date: g.tw_date,
          game_id: g.game_id,
          matchup,
          market: mkt,
          pick_side: side,
          pick_label: mkt === 'ATS' ? `${o.team.zh} ${EPL.fmtSpread(L)}` : mkt === 'OU' ? `${side === 'OVER' ? '大球' : '小球'} ${L}` : o.label,
          line: L,
          odds_decimal: Number(oddsInp.value),
          stake: Number(stakeInp.value),
          note: document.getElementById('qbNote').value.trim(),
        });
        EPL.bets = res.bets || [];
        EPL.closeModal();
        EPL.toast('✅ 已加入注單！完賽後會自動對獎，可到「📝 注單追蹤」查看');
      } catch (e) {
        saving = false;
        submitBtn.textContent = '💾 儲存注單';
        refresh();
        EPL.toast('⚠️ ' + e.message);
      }
    });
    setMarket(mkt);
  };

  EPL.addParlayBet = async function (opts) {
    const legs = opts.legs || [];
    if (legs.length < 2) return;
    const isTw = (EPL.state.parlayBook || 'INTL') === 'TW';
    const unitStake = Math.max(10, Number(EPL.state.parlayStake || 500));
    const singleOdds = isTw ? 1.75 : 1.91;
    const isCombo = opts.type === 'COMBO';
    const totalStake = isCombo ? unitStake * 4 : unitStake;
    const combinedOdds = isCombo
      ? +((3 * singleOdds * singleOdds + singleOdds ** 3) / 4).toFixed(2)
      : +(singleOdds ** legs.length).toFixed(2);
    const label = legs.map((l) => l.pick_label_zh).join(' ＋ ');
    try {
      const res = await EPL.apiPost('/api/bets/add', {
        tw_date: opts.tw_date || (legs[0] && legs[0].tw_date) || '',
        game_id: '',
        matchup: `${opts.title || '英超跨場串關'}（${isTw ? '台彩盤' : '國際盤'}）`,
        market: 'PARLAY',
        pick_side: opts.type || 'DIRECT',
        pick_label: label,
        line: legs.length,
        odds_decimal: combinedOdds,
        stake: totalStake,
        note: `串關關數 ${legs.length} 關`,
      });
      EPL.bets = res.bets || [];
      EPL.toast(`✅ 已將「${opts.title}」加入注單追蹤！`);
    } catch (e) {
      EPL.toast('⚠️ ' + e.message);
    }
  };

  EPL.openAiGameDive = async function (gid) {
    EPL.openModal(
      `🤖 AI 英超泊松戰術深度解盤 · ${gid}`,
      `<div class="loading-box" style="padding:24px">🧠 正在透過 Jetski 語言伺服器結合預期進球 xG、主客場得失球與傷停名單撰寫解盤報告（約需 8–18 秒）…</div>`
    );
    try {
      const st = await EPL.apiPost('/api/ai/start', { kind: 'game_deep_dive', game_id: gid });
      const tid = st.task;
      for (let i = 0; i < 55; i++) {
        await new Promise((r) => setTimeout(r, 1200));
        const tk = await EPL.apiGet(`/api/ai/task?id=${encodeURIComponent(tid)}`);
        if (tk.status === 'done' && tk.result) {
          const d = tk.result;
          document.getElementById('appModalBody').innerHTML = `
            <div style="display:flex;flex-direction:column;gap:12px">
              <div class="card" style="background:#ecfdf5;border-color:#6ee7b7">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
                  <strong style="font-size:15px;color:#065f46">📌 ${EPL.esc(d.headline || '本場實戰結論')}</strong>
                  <span class="chip ok">${EPL.esc(d.risk_level || '泊松量化評估')}</span>
                </div>
                <div style="font-size:13.5px;color:#1e293b">${EPL.esc(d.summary || '')}</div>
              </div>
              ${d.ats_verdict ? `<div class="card"><strong>⚽ 亞洲讓球盤／1X2 和局風險分析</strong><p style="margin:6px 0 0;color:#334155">${EPL.esc(d.ats_verdict)}</p></div>` : ''}
              ${d.ou_verdict ? `<div class="card"><strong>🥅 2.5 球大小盤與雙進球 (BTTS) 評估</strong><p style="margin:6px 0 0;color:#334155">${EPL.esc(d.ou_verdict)}</p></div>` : ''}
              ${d.injury_watch ? `<div class="card" style="background:#fffbeb;border-color:#fde68a"><strong>🏥 賽前 60 分鐘先發名單與傷停觀察</strong><p style="margin:6px 0 0;color:#78350f">${EPL.esc(d.injury_watch)}</p></div>` : ''}
            </div>`;
          return;
        }
        if (tk.status === 'error') throw new Error(tk.error || 'AI 解盤失敗');
      }
      throw new Error('AI 回覆逾時，請稍後再試');
    } catch (e) {
      document.getElementById('appModalBody').innerHTML = `<div class="empty-box">⚠️ ${EPL.esc(e.message)}</div>`;
    }
  };

  // --- Release Notes & Smart 1.x.x Publisher Modal (Pattern 164 / 173) ---
  let _publishConfirmArmed = false;
  EPL.openReleaseModal = async function () {
    _publishConfirmArmed = false;
    const bd = document.getElementById('relModal');
    const ttl = document.getElementById('relModalTitle');
    const body = document.getElementById('relModalBody');
    if (ttl) {
      ttl.textContent = EPL.isStatic ? '📜 英超運彩智庫 · Release Notes' : '🚀 英超運彩智庫 · 版本紀錄與發布中心';
    }
    bd.classList.remove('hidden');
    body.innerHTML = '<div class="loading-box">讀取版本更新紀錄中…</div>';
    try {
      const st = await EPL.apiGet('/api/release_status');
      renderReleaseModalBody(st);
    } catch (_) {
      const rd = window.EPL_RELEASES || { current_version: '1.0.0', releases: [] };
      renderReleaseModalBody({ static: true, current_version: rd.current_version, has_changes: false, changed_files: [], releases: rd.releases || [] });
    }
  };

  function renderReleaseModalBody(st) {
    const body = document.getElementById('relModalBody');
    const ttl = document.getElementById('relModalTitle');
    const isLocal = !EPL.isStatic && !(st && st.static);
    if (ttl) {
      ttl.textContent = isLocal ? '🚀 英超運彩智庫 · 版本紀錄與發布中心' : '📜 英超運彩智庫 · Release Notes';
    }
    const dlHtml = isLocal
      ? `<div class="card" style="background:#f8fafc;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
          <div>
            <strong>📦 GitHub Pages 單一檔案匯出（免安裝靜態版）</strong>
            <div class="sec-sub">將最新 2026-27 英超賽季快照、FPL 數據與所有介面打包成單一 <code>index.html</code>，直接上傳 GitHub 即可公開瀏覽。</div>
          </div>
          <a class="btn btn-soft" href="/download/index.html" download="index.html">⬇️ 直接下載最新 index.html</a>
        </div>`
      : '';

    let dirtyHtml = '';
    if (isLocal && st.has_changes) {
      const rec = st.recommended_bump || 'patch';
      const nv = st.next_versions || {};
      dirtyHtml = `
        <div class="card" style="border-color:#fcd34d;background:#fffdf7;margin-bottom:16px">
          <div class="sec-hdr" style="margin-bottom:8px">
            <div>
              <strong style="font-size:15px">🛠️ 偵測到 ${st.changed_files.length} 個未發布檔案變更（+${st.total_added} / -${st.total_removed} 行）</strong>
              <div class="sec-sub">${EPL.esc(st.recommend_reason || '')}</div>
            </div>
            <span class="chip warn">目前 v${EPL.esc(st.current_version)}</span>
          </div>
          <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:10px">
            ${['patch', 'minor', 'major'].map((b) => `
              <label class="card" style="padding:9px 11px;cursor:pointer;background:${rec === b ? '#ecfdf5' : '#fff'};border-color:${rec === b ? '#059669' : '#cbd5e1'}">
                <input type="radio" name="relBump" value="${b}" ${rec === b ? 'checked' : ''}>
                <strong>v${EPL.esc(nv[b] || '')}</strong>
                <span class="chip ${rec === b ? 'ok' : 'muted'}" style="margin-left:4px">${b === 'major' ? '進第1位' : b === 'minor' ? '進第2位' : '進第3位'}</span>
                <div style="font-size:11.5px;color:#475569;margin-top:4px">${EPL.esc((st.bump_descriptions || {})[b] || '')}</div>
              </label>
            `).join('')}
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px">
            <input class="inp" id="relTitleInp" value="${EPL.esc(st.suggested_title || '')}" placeholder="版本標題">
            <textarea class="inp" id="relHlInp" rows="3" placeholder="每行一條更新重點">${EPL.esc((st.suggested_highlights || []).join('\n'))}</textarea>
          </div>
          <div style="display:flex;justify-content:flex-end">
            <button type="button" class="btn btn-primary" id="relPublishBtn">🚀 發布新版本並同步重新打包</button>
          </div>
        </div>`;
    } else if (isLocal) {
      dirtyHtml = `<div class="card" style="background:#f0fdf4;border-color:#bbf7d0;margin-bottom:14px;font-size:13px;color:#166534">✅ 目前工作目錄所有程式碼皆與最新發布版 <strong>v${EPL.esc(st.current_version)}</strong> 同步，無待發布修改。</div>`;
    }

    const histHtml = (st.releases || []).map((r) => `
      <div class="card" style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
          <div>
            <span class="chip ok">v${EPL.esc(r.version)}</span>
            <strong style="margin-left:6px">${EPL.esc(r.title || '')}</strong>
          </div>
          <span style="font-size:12px;color:#64748b">${EPL.esc(r.date || '')}</span>
        </div>
        <ul style="margin:6px 0 0;padding-left:18px;color:#334155;font-size:13px">
          ${(r.highlights || []).map((h) => `<li style="margin-bottom:3px">${EPL.esc(h)}</li>`).join('')}
        </ul>
      </div>`).join('');

    body.innerHTML = dlHtml + dirtyHtml + `<h4 style="margin:8px 0">📜 Release Notes 歷史版本紀錄</h4>` + histHtml;

    const pubBtn = document.getElementById('relPublishBtn');
    if (pubBtn) {
      pubBtn.onclick = async () => {
        const picked = (document.querySelector('input[name="relBump"]:checked') || {}).value || 'patch';
        const targetVer = (st.next_versions || {})[picked] || '';
        if (!_publishConfirmArmed) {
          _publishConfirmArmed = true;
          pubBtn.textContent = `⚠️ 確定發布 v${targetVer}？再按一次確認`;
          return;
        }
        pubBtn.disabled = true;
        pubBtn.textContent = '⏳ 正在寫入版本與打包單一 HTML…';
        try {
          const title = document.getElementById('relTitleInp').value;
          const highlights = document.getElementById('relHlInp').value.split('\n').map((s) => s.trim()).filter(Boolean);
          const nextSt = await EPL.apiPost('/api/release_publish', { bump_type: picked, title, highlights });
          _publishConfirmArmed = false;
          updateHeaderBadges(nextSt.current_version, nextSt.has_changes);
          renderReleaseModalBody(nextSt);
          EPL.toast(`🎉 已發布 v${nextSt.current_version}！`);
        } catch (e) {
          pubBtn.disabled = false;
          _publishConfirmArmed = false;
          EPL.toast('⚠️ ' + e.message);
        }
      };
    }
  }

  function updateHeaderBadges(ver, hasChanges) {
    const vb = document.getElementById('verBadgeBtn');
    if (vb) {
      const showDot = !EPL.isStatic && hasChanges;
      vb.className = 'ver-badge' + (showDot ? ' has-changes' : '');
      vb.title = EPL.isStatic ? `版本 v${ver}（點擊查看 Release Notes）` : '查看版本更新紀錄與發布新版本';
      vb.innerHTML = `v${EPL.esc(ver)}${showDot ? '<span class="ver-dot" title="有尚未發布的修改"></span>' : ''}`;
    }
    const mp = document.getElementById('hdrModelPill');
    if (mp && EPL.snap && EPL.snap.meta) {
      const k = EPL.snap.kpi || {};
      mp.textContent = `Model ${EPL.snap.meta.model_version} · 強推勝率 ${k.strong_win_rate || 0}% (${k.strong_w || 0}W-${k.strong_l || 0}L)`;
    }
  }

  function rebuildLookups() {
    EPL.teamMap = {};
    for (const t of (EPL.snap && EPL.snap.teams) || []) EPL.teamMap[t.abbr] = t;
    EPL.playerMap = {};
    for (const p of (EPL.snap && EPL.snap.player_stats) || []) EPL.playerMap[p.pid] = p;
    EPL.gameMap = {};
    for (const g of (EPL.snap && EPL.snap.games) || []) EPL.gameMap[g.game_id] = g;
    const meta = (EPL.snap && EPL.snap.meta) || {};
    if (!EPL.state.picksGw) EPL.state.picksGw = meta.next_gameweek || 10;
    if (!EPL.state.parlayGw) EPL.state.parlayGw = meta.next_gameweek || 10;
    if ((EPL.snap && EPL.snap.teams && EPL.snap.teams[0]) && !EPL.teamMap[EPL.state.activeTeam]) {
      EPL.state.activeTeam = EPL.snap.teams[0].abbr;
    }
  }

  EPL.render = function () {
    const hash = (window.location.hash || '#/picks').replace(/^#\/?/, '');
    const parts = hash.split('?')[0].split('/').filter(Boolean);
    const route = parts[0] || 'picks';
    const sub = (parts[1] || '').toUpperCase();
    if (route === 'team' && sub && EPL.teamMap[sub]) {
      EPL.state.activeTeam = sub;
      EPL.state.teamGameId = '';
    }
    if (route === 'stats' && parts[1]) {
      const ent = parts[1].toLowerCase();
      if (['table', 'players', 'leaders'].includes(ent)) EPL.state.statsEntity = ent;
    }
    EPL.route = EPL.pages[route] ? route : 'picks';

    document.querySelectorAll('#mainNav .nav-item').forEach((a) => {
      a.classList.toggle('active', a.getAttribute('data-route') === EPL.route);
    });

    const main = document.getElementById('appMain');
    if (!EPL.snap) {
      main.innerHTML = '<div class="loading-box">載入英超運彩智庫資料中…</div>';
      return;
    }
    const prevScroll = document.documentElement.style.scrollBehavior;
    document.documentElement.style.scrollBehavior = 'auto';
    EPL.pages[EPL.route](main);
    document.documentElement.style.scrollBehavior = prevScroll;
  };

  EPL.refreshAllData = async function () {
    const [snap, betsRes] = await Promise.all([
      EPL.apiGet('/api/snapshot'),
      EPL.apiGet('/api/bets').catch(() => ({ bets: [] })),
    ]);
    EPL.snap = snap;
    EPL.bets = betsRes.bets || [];
    rebuildLookups();
    updateHeaderBadges(EPL.health.version || '1.0.0', Boolean(EPL.relHasChanges));
    EPL.render();
  };

  EPL.openDisclaimerModal = function () {
    EPL.openModal(
      '⚖️ 法律與運動彩券風險免責聲明（Disclaimer）',
      `
        <div style="display:flex;flex-direction:column;gap:12px;font-size:13.5px;line-height:1.7;color:#1e293b">
          <div class="card" style="background:#fffbeb;border-color:#fcd34d;color:#78350f;padding:12px 15px">
            <strong>⚠️ 核心免責原則：</strong>使用本網站（英超運彩智庫）即表示您已詳閱並完全同意本聲明。<strong>任何參考本站數據或模型分析所進行之投注行為與資金配置，其一切盈虧結果、本金損失與風險均由使用者自行判斷並完全自負，概與本站及開發者無關。</strong>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">1. 純足球量化統計與研究性質（非投注建議或勸誘）</div>
            <div>本站所有亞洲讓球盤（Asian Handicap / Spread）、2.5 球大小分、1X2 主客和機率、FPL 預期進球（xG）傷停推估與 AI 分析文字，均由電腦程式依據公開體育數據自動運算產生，純供個人足球數據研究與觀賽娛樂參考，<strong>絕不構成任何形式之投注建議、明牌報牌、招攬、勸誘或獲利保證</strong>。</div>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">2. 足球低比分高變異性、法定 90 分鐘規則與資料延遲免責</div>
            <div>足球屬於低得分運動，極易受紅牌判罰、12 碼點球、VAR 越位毫釐改判、門柱橫樑與傷停補時絕殺影響；且所有足球運彩盤口皆僅計算「正規 90 分鐘含傷停補時」。公開資料可能存在延遲或與台灣運彩實際開盤不同，本站不負即時性與正確性擔保責任。</div>
          </div>
          <div class="card" style="padding:13px 16px">
            <div style="font-weight:800;margin-bottom:6px;color:#0f172a">3. 損益完全自負與遵守所在地法令</div>
            <div><strong>不論獲利或虧損，一切財務風險皆由使用者個人完全承擔，本站及開發者概不負責。</strong>於中華民國境內請僅透過合法授權之「台灣運彩」管道參與（未滿 18 歲不得購買或兌領彩券），並嚴格衡量自身財務能力、理性參與。</div>
          </div>
        </div>
      `,
      'modal-lg'
    );
  };

  async function boot() {
    document.getElementById('appModalClose').onclick = EPL.closeModal;
    document.getElementById('appModalBd').onclick = (e) => { if (e.target.id === 'appModalBd') EPL.closeModal(); };
    document.getElementById('relModalClose').onclick = () => document.getElementById('relModal').classList.add('hidden');
    document.getElementById('relModal').onclick = (e) => { if (e.target.id === 'relModal') e.target.classList.add('hidden'); };
    document.getElementById('verBadgeBtn').onclick = EPL.openReleaseModal;
    const discBtn = document.getElementById('disclaimerBtn');
    if (discBtn) discBtn.onclick = EPL.openDisclaimerModal;

    const syncBtn = document.getElementById('syncNowBtn');
    EPL.syncStaticLiveEspn = async function () {
      if (!EPL.snap || !Array.isArray(EPL.snap.games)) return { updated: 0 };
      const now = new Date();
      const twNow = new Date(now.getTime() + 8 * 3600 * 1000);
      const pad = (n) => String(n).padStart(2, '0');
      const fmtCompact = (d) => `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}`;
      const fmtIso = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
      const dStart = fmtCompact(new Date(now.getTime() - 3 * 86400000));
      const dEnd = fmtCompact(new Date(now.getTime() + 5 * 86400000));
      const byId = {};
      for (const g of EPL.snap.games) byId[String(g.game_id)] = g;

      let touched = 0;
      const r = await fetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard?dates=${dStart}-${dEnd}`, { cache: 'no-store' });
      if (!r.ok) throw new Error('ESPN HTTP ' + r.status);
      const payload = await r.json();
      for (const ev of (payload && payload.events) || []) {
        const g = byId[String(ev.id || '')];
        if (!g) continue;
        const comp = (ev.competitions && ev.competitions[0]) || {};
        const stType = (comp.status && comp.status.type) || {};
        const state = String(stType.state || '');
        const newStatus = stType.completed || state === 'post' ? 'FINAL' : state === 'in' ? 'LIVE' : 'SCHEDULED';
        let homeC = null;
        let awayC = null;
        for (const c of comp.competitors || []) {
          if (c.homeAway === 'home') homeC = c;
          else if (c.homeAway === 'away') awayC = c;
        }
        if (!homeC || !awayC) continue;
        const hs = newStatus === 'SCHEDULED' ? null : (homeC.score != null ? parseInt(homeC.score, 10) : g.home_score);
        const as = newStatus === 'SCHEDULED' ? null : (awayC.score != null ? parseInt(awayC.score, 10) : g.away_score);
        const prevSig = `${g.status}:${g.home_score}-${g.away_score}`;

        g.status = newStatus;
        if (hs != null && !Number.isNaN(hs)) g.home_score = hs;
        if (as != null && !Number.isNaN(as)) g.away_score = as;
        if (newStatus === 'FINAL' && g.home_score != null && g.away_score != null) {
          g.total_goals = g.home_score + g.away_score;
          g.result_1x2 = g.home_score > g.away_score ? 'HOME' : g.home_score < g.away_score ? 'AWAY' : 'DRAW';
          g.btts_yes = g.home_score > 0 && g.away_score > 0;
          if (g.close_spread_home != null) {
            const adj = +(g.home_score - g.away_score + Number(g.close_spread_home)).toFixed(2);
            g.ats_winner = adj > 0 ? 'HOME' : adj < 0 ? 'AWAY' : 'PUSH';
          }
          if (g.close_total != null) {
            const tot = g.total_goals;
            const ln = Number(g.close_total);
            g.ou_result = tot > ln ? 'OVER' : tot < ln ? 'UNDER' : 'PUSH';
          }
          if (g.pred) {
            if (g.pred.ats_pick && g.pred.ats_pick !== 'PASS' && g.ats_winner) {
              g.pred.ats_result = g.ats_winner === 'PUSH' ? 'PUSH' : g.pred.ats_pick === g.ats_winner ? 'WIN' : 'LOSS';
            }
            if (g.pred.ou_pick && g.pred.ou_pick !== 'PASS' && g.ou_result) {
              g.pred.ou_graded = g.ou_result === 'PUSH' ? 'PUSH' : g.pred.ou_pick === g.ou_result ? 'WIN' : 'LOSS';
            }
          }
        }
        if (prevSig !== `${g.status}:${g.home_score}-${g.away_score}`) touched++;
      }

      const stamp = `${fmtIso(twNow)} ${pad(twNow.getUTCHours())}:${pad(twNow.getUTCMinutes())} (ESPN 即時同步)`;
      if (EPL.snap.meta) {
        EPL.snap.meta.updated_at = stamp;
        EPL.snap.meta.completed_games = EPL.snap.games.filter((g) => g.status === 'FINAL').length;
      }
      await EPL.refreshAllData();
      return { updated: touched, stamp };
    };

    if (EPL.isStatic) {
      syncBtn.style.display = '';
      syncBtn.textContent = '↻ 即時同步比分';
      syncBtn.onclick = async () => {
        syncBtn.disabled = true;
        syncBtn.textContent = '⏳ 連線 ESPN 同步中…';
        try {
          const r = await EPL.syncStaticLiveEspn();
          EPL.toast(`✅ 已即時同步 ESPN 最新英超比分與注單對獎！（更新 ${r.updated} 場狀態）`);
        } catch (e) {
          EPL.toast('⚠️ 即時同步失敗：' + e.message);
        } finally {
          syncBtn.disabled = false;
          syncBtn.textContent = '↻ 即時同步比分';
        }
      };
    } else {
      syncBtn.onclick = async () => {
        syncBtn.disabled = true;
        syncBtn.textContent = '⏳ 同步比分與對獎中…';
        try {
          await EPL.apiPost('/api/sync', { full: false, update_odds: false });
          for (let i = 0; i < 45; i++) {
            await new Promise((r) => setTimeout(r, 1200));
            const st = await EPL.apiGet('/api/sync_status');
            if (!st.running) break;
          }
          await EPL.refreshAllData();
          EPL.toast('✅ 已同步最新 2026-27 英超比分、Boxscore、FPL 傷停與對獎！');
        } catch (e) {
          EPL.toast('⚠️ ' + e.message);
        } finally {
          syncBtn.disabled = false;
          syncBtn.textContent = '↻ 更新比分與對獎';
        }
      };
    }

    window.addEventListener('hashchange', () => requestAnimationFrame(EPL.render));

    document.addEventListener('click', (ev) => {
      const discTrigger = ev.target.closest('[data-open-disclaimer]');
      if (discTrigger) { ev.preventDefault(); EPL.openDisclaimerModal(); return; }
      const boxBtn = ev.target.closest('[data-boxscore-gid]');
      if (boxBtn) { ev.preventDefault(); ev.stopPropagation(); EPL.openGameBoxscoreModal(boxBtn.getAttribute('data-boxscore-gid')); return; }
      const plEl = ev.target.closest('[data-player-id]');
      if (plEl) { ev.preventDefault(); ev.stopPropagation(); EPL.openPlayerModal(plEl.getAttribute('data-player-id')); return; }
      const tmEl = ev.target.closest('[data-team-link]');
      if (tmEl) {
        ev.preventDefault(); ev.stopPropagation();
        const ab = (tmEl.getAttribute('data-team-link') || '').toUpperCase();
        if (ab) {
          EPL.closeModal();
          EPL.state.activeTeam = ab;
          EPL.state.teamGameId = '';
          if (window.location.hash === `#/team/${ab}`) EPL.render();
          else window.location.hash = `#/team/${ab}`;
        }
      }
    });

    try {
      if (!EPL.isStatic) {
        const [h, relSt] = await Promise.all([
          EPL.apiGet('/api/health').catch(() => ({ version: '1.0.0', ai: false })),
          EPL.apiGet('/api/release_status').catch(() => ({ current_version: '1.0.0', has_changes: false })),
        ]);
        EPL.health = h;
        EPL.relHasChanges = Boolean(relSt.has_changes);
        EPL.health.version = relSt.current_version || h.version || '1.0.0';
      } else if (window.EPL_RELEASES) {
        EPL.health.version = window.EPL_RELEASES.current_version || '1.0.0';
      }
      await EPL.refreshAllData();
      if (EPL.isStatic) {
        EPL.syncStaticLiveEspn().catch(() => {});
        setInterval(() => { if (!document.hidden) EPL.syncStaticLiveEspn().catch(() => {}); }, 90000);
      }
      if (window.location.search.includes('releases=1')) EPL.openReleaseModal();
    } catch (e) {
      document.getElementById('appMain').innerHTML = `<div class="empty-box">⚠️ 資料載入失敗：${EPL.esc(e.message)}</div>`;
    }
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
