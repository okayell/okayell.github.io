/* Page 4: ⚽ 英超 20 俱樂部專區 · 連過/連大小雷達 · 近10場走勢燈 · 單場 Boxscore 與 FPL 陣容 (#/team/<ABBR>) */
(function () {
  'use strict';
  const EPL = window.EPL;

  function renderClubPill(t, activeAbbr) {
    let stk = '';
    if (t.ats_win_streak >= 3) stk = `<span class="tm-mini-stk ats-w">過${t.ats_win_streak}</span>`;
    else if (t.ats_loss_streak >= 3) stk = `<span class="tm-mini-stk ats-l">輸${t.ats_loss_streak}</span>`;
    else if (t.over_streak >= 3) stk = `<span class="tm-mini-stk ou-o">大${t.over_streak}</span>`;
    else if (t.under_streak >= 3) stk = `<span class="tm-mini-stk ou-u">小${t.under_streak}</span>`;
    return `
      <a href="#/team/${EPL.esc(t.abbr)}" class="tm-pill ${t.abbr === activeAbbr ? 'active' : ''}">
        <img loading="lazy" decoding="async" src="${EPL.esc(t.logo)}" alt="">
        <span>${EPL.esc(t.zh)}</span>
        ${stk}
      </a>`;
  }

  EPL.pages.team = function (root) {
    const snap = EPL.snap || {};
    const teams = snap.teams || [];
    const activeAbbr = EPL.state.activeTeam || (teams[0] && teams[0].abbr) || 'MCI';
    const club = teams.find((t) => t.abbr === activeAbbr) || teams[0];
    if (!club) {
      root.innerHTML = '<div class="empty-box">尚無俱樂部資料</div>';
      return;
    }

    const topHalf = teams.slice(0, 10);
    const botHalf = teams.slice(10);

    // League >=3 streak radar
    const hotCover = teams.filter((t) => t.ats_win_streak >= 3);
    const coldLoss = teams.filter((t) => t.ats_loss_streak >= 3);
    const hotOver = teams.filter((t) => t.over_streak >= 3);
    const hotUnder = teams.filter((t) => t.under_streak >= 3);

    const clubGames = (snap.games || []).filter((g) => g.home_abbr === activeAbbr || g.away_abbr === activeAbbr);
    const pastGames = clubGames.filter((g) => g.status === 'FINAL').slice().reverse();
    const nextGames = clubGames.filter((g) => g.status !== 'FINAL').slice(0, 5);
    const selGid = EPL.state.teamGameId || (pastGames[0] && pastGames[0].game_id) || '';

    const squad = (snap.player_stats || []).filter((p) => p.team === activeAbbr);

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">⚽ 英超 20 俱樂部運彩專區 · 盤路連莊雷達與單場 Boxscore</h1>
          <div class="sec-sub">點擊任一俱樂部可檢視近 10 場讓球／大小球／主客和走勢燈號、單場控球射門 Boxscore 與全隊官方 FPL xG 陣容</div>
        </div>
      </div>

      <!-- League >=3 Streak Radar -->
      <div class="streak-radar-card">
        <div style="font-size:13px;font-weight:800;color:#0f172a">📡 全聯盟連續盤路警報雷達（連續 ≥ 3 場過盤／開大小球一鍵跳轉）</div>
        <div class="streak-radar-grid">
          <div class="streak-radar-col">
            <div class="streak-radar-lbl"><span style="color:#15803d">🔥 連續過讓球盤</span><span>${hotCover.length} 隊</span></div>
            <div style="display:flex;gap:5px;flex-wrap:wrap">${hotCover.length ? hotCover.map((t) => `<a href="#/team/${t.abbr}" class="streak-team-chip ${t.abbr === activeAbbr ? 'is-cur' : ''}"><img loading="lazy" decoding="async" src="${EPL.esc(t.logo)}" alt="">${EPL.esc(t.zh)} 連${t.ats_win_streak}</a>`).join('') : '<span style="font-size:12px;color:#94a3b8">目前無 ≥3 連過隊伍</span>'}</div>
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl"><span style="color:#be123c">❄️ 連續輸讓球盤</span><span>${coldLoss.length} 隊</span></div>
            <div style="display:flex;gap:5px;flex-wrap:wrap">${coldLoss.length ? coldLoss.map((t) => `<a href="#/team/${t.abbr}" class="streak-team-chip ${t.abbr === activeAbbr ? 'is-cur' : ''}"><img loading="lazy" decoding="async" src="${EPL.esc(t.logo)}" alt="">${EPL.esc(t.zh)} 連輸${t.ats_loss_streak}</a>`).join('') : '<span style="font-size:12px;color:#94a3b8">目前無 ≥3 連輸隊伍</span>'}</div>
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl"><span style="color:#c2410c">🔴 連續開大球</span><span>${hotOver.length} 隊</span></div>
            <div style="display:flex;gap:5px;flex-wrap:wrap">${hotOver.length ? hotOver.map((t) => `<a href="#/team/${t.abbr}" class="streak-team-chip ${t.abbr === activeAbbr ? 'is-cur' : ''}"><img loading="lazy" decoding="async" src="${EPL.esc(t.logo)}" alt="">${EPL.esc(t.zh)} 連${t.over_streak}大</a>`).join('') : '<span style="font-size:12px;color:#94a3b8">目前無 ≥3 連大隊伍</span>'}</div>
          </div>
          <div class="streak-radar-col">
            <div class="streak-radar-lbl"><span style="color:#1d4ed8">🔵 連續開小球</span><span>${hotUnder.length} 隊</span></div>
            <div style="display:flex;gap:5px;flex-wrap:wrap">${hotUnder.length ? hotUnder.map((t) => `<a href="#/team/${t.abbr}" class="streak-team-chip ${t.abbr === activeAbbr ? 'is-cur' : ''}"><img loading="lazy" decoding="async" src="${EPL.esc(t.logo)}" alt="">${EPL.esc(t.zh)} 連${t.under_streak}小</a>`).join('') : '<span style="font-size:12px;color:#94a3b8">目前無 ≥3 連小隊伍</span>'}</div>
          </div>
        </div>
      </div>

      <!-- 20-Club Strip -->
      <div class="team-conf-strip">
        <div class="conf-row"><span class="conf-tag">前半榜 P1-10</span>${topHalf.map((t) => renderClubPill(t, activeAbbr)).join('')}</div>
        <div class="conf-row"><span class="conf-tag">後半榜 P11-20</span>${botHalf.map((t) => renderClubPill(t, activeAbbr)).join('')}</div>
      </div>

      <!-- Club Hero -->
      <div class="team-hero">
        <div class="team-hero-left">
          <img loading="lazy" decoding="async" class="team-hero-logo" src="${EPL.esc(club.logo)}" alt="${EPL.esc(club.zh)}">
          <div>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <h2 style="margin:0;font-size:21px;font-weight:900">${EPL.esc(club.zh)} <span style="font-size:14px;color:#64748b">${EPL.esc(club.en)}</span></h2>
              <span class="chip ok">英超排名 #${club.rank} · ${club.pts} 積分</span>
              ${club.euro ? '<span class="chip info">🌍 歐戰雙線球隊</span>' : ''}
            </div>
            <div style="font-size:12.5px;color:#64748b;margin-top:4px">
              主場：${EPL.esc(club.stadium || '—')} · 城市：${EPL.esc(club.city || '—')} · 戰績：${EPL.esc(club.record)}（進 ${club.gf} 失 ${club.ga}，淨勝 ${EPL.fmtSigned(club.gd, 0)}）
            </div>
          </div>
        </div>
        <div class="team-hero-stats">
          <div class="th-stat"><div class="th-stat-lbl">讓球過盤率 ATS</div><div class="th-stat-val" style="color:#059669">${club.ats_pct}% (${club.ats_w}W-${club.ats_l}L)</div></div>
          <div class="th-stat"><div class="th-stat-lbl">大球開出率 Over</div><div class="th-stat-val" style="color:#c2410c">${club.over_pct}% (${club.ou_o}大-${club.ou_u}小)</div></div>
          <div class="th-stat"><div class="th-stat-lbl">場均進球 / 失球</div><div class="th-stat-val">${club.gf_pg} / ${club.ga_pg}</div></div>
          <div class="th-stat"><div class="th-stat-lbl">零封率 CS / 雙進球 BTTS</div><div class="th-stat-val">${club.cs_pct}% / ${club.btts_pct}%</div></div>
        </div>
      </div>

      <!-- 3-Column 10-Match Trend Dots -->
      <div class="trend-strip-grid">
        <div class="trend-box ${club.ats_win_streak >= 3 ? 'alert-cover' : club.ats_loss_streak >= 3 ? 'alert-loss' : ''}">
          <div style="display:flex;justify-content:space-between;font-size:12.5px;font-weight:800">
            <span>⚽ 讓球盤近況（舊 → 新）</span>
            <span>${club.ats_win_streak >= 2 ? `🔥 連 ${club.ats_win_streak} 過盤` : club.ats_loss_streak >= 2 ? `❄️ 連 ${club.ats_loss_streak} 輸盤` : '盤路均衡'}</span>
          </div>
          <div class="trend-dots">
            ${(club.last10_ats || []).map((x) => `<span class="t-dot ${x === 'W' ? 'w' : x === 'L' ? 'l' : 'p'}">${x === 'W' ? '過' : x === 'L' ? '輸' : '走'}</span>`).join('')}
          </div>
        </div>
        <div class="trend-box ${club.over_streak >= 3 ? 'alert-over' : club.under_streak >= 3 ? 'alert-under' : ''}">
          <div style="display:flex;justify-content:space-between;font-size:12.5px;font-weight:800">
            <span>🥅 大小球近況（舊 → 新）</span>
            <span>${club.over_streak >= 2 ? `🔴 連 ${club.over_streak} 大球` : club.under_streak >= 2 ? `🔵 連 ${club.under_streak} 小球` : '大小交錯'}</span>
          </div>
          <div class="trend-dots">
            ${(club.last10_ou || []).map((x) => `<span class="t-dot ${x === 'O' ? 'o' : 'u'}">${x === 'O' ? '大' : '小'}</span>`).join('')}
          </div>
        </div>
        <div class="trend-box">
          <div style="display:flex;justify-content:space-between;font-size:12.5px;font-weight:800">
            <span>🏆 聯賽勝負和近況（舊 → 新）</span>
            <span>${club.unbeaten_streak >= 3 ? `🛡️ 連續 ${club.unbeaten_streak} 輪不敗` : `${club.pts} 積分`}</span>
          </div>
          <div class="trend-dots">
            ${(club.last10_su || []).map((x) => `<span class="t-dot ${x === 'W' ? 'w' : x === 'D' ? 'd' : 'l'}">${x === 'W' ? '勝' : x === 'D' ? '和' : '敗'}</span>`).join('')}
          </div>
        </div>
      </div>

      <!-- Upcoming Fixtures + Past Games -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:14px;margin-bottom:16px">
        <div class="card">
          <div class="sec-hdr" style="margin-bottom:8px">
            <h3 class="sec-title" style="font-size:14.5px">📅 本季已完賽盤路明細（點擊任一場在下方檢視完整 Boxscore）</h3>
            <span class="odds-rule-pill">🕚 23:00 鎖定盤</span>
          </div>
          <div class="tbl-wrap">
            <table class="data-tbl">
              <thead>
                <tr><th>輪次</th><th>主客對手</th><th>比分</th><th>讓球盤</th><th>大小球</th></tr>
              </thead>
              <tbody>
                ${pastGames.map((g) => {
                  const isHome = g.home_abbr === activeAbbr;
                  const opp = EPL.teamOf(isHome ? g.away_abbr : g.home_abbr);
                  const myScore = isHome ? g.home_score : g.away_score;
                  const oppScore = isHome ? g.away_score : g.home_score;
                  const mySp = isHome ? g.close_spread_home : -Number(g.close_spread_home || 0);
                  const myCov = (isHome && g.ats_winner === 'HOME') || (!isHome && g.ats_winner === 'AWAY');
                  return `
                    <tr class="${g.game_id === selGid ? 'game-row-sel' : ''}" data-sel-gid="${EPL.esc(g.game_id)}" style="cursor:pointer">
                      <td>GW${g.gameweek}</td>
                      <td>${isHome ? '主 vs' : '客 @'} <strong>${EPL.esc(opp.zh)}</strong></td>
                      <td><strong>${myScore}:${oppScore}</strong></td>
                      <td>${EPL.fmtSpread(mySp)} <span class="chip ${myCov ? 'ok' : g.ats_winner === 'PUSH' ? 'warn' : 'bad'}">${myCov ? '過' : g.ats_winner === 'PUSH' ? '走' : '輸'}</span></td>
                      <td>${g.close_total} <span class="chip ${g.ou_result === 'OVER' ? 'strong' : 'info'}">${g.ou_result === 'OVER' ? '大' : '小'}</span></td>
                    </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:14.5px;margin-bottom:10px">⏭️ 未來 5 輪賽程與泊松預估</h3>
          <div class="tbl-wrap">
            <table class="data-tbl">
              <thead><tr><th>輪次 / 台灣時間</th><th>對戰</th><th>期望進球 λ</th></tr></thead>
              <tbody>
                ${nextGames.map((g) => {
                  const isHome = g.home_abbr === activeAbbr;
                  const opp = EPL.teamOf(isHome ? g.away_abbr : g.home_abbr);
                  const p = g.pred || {};
                  return `
                    <tr>
                      <td>GW${g.gameweek} · ${EPL.esc((g.kickoff_tw || '').slice(5))}</td>
                      <td>${isHome ? '主 vs' : '客 @'} <span class="tm-link" data-team-link="${EPL.esc(opp.abbr)}" style="font-weight:700">${EPL.esc(opp.zh)}</span></td>
                      <td>主 ${Number(p.lambda_home || 1.4).toFixed(2)} : 客 ${Number(p.lambda_away || 1.2).toFixed(2)}</td>
                    </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Inline Selected Match Boxscore -->
      ${selGid ? `<div class="card" style="margin-bottom:16px">${EPL.renderGameBoxscoreHtml(selGid)}</div>` : ''}

      <!-- Squad FPL xG Table -->
      <div class="card">
        <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">🏃 ${EPL.esc(club.zh)} 全隊球員官方 FPL 預期進球 (xG) 與傷停狀態（點擊球員查看詳情）</h3>
        <div class="nba-tbl-wrap standalone">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="left sticky-pl no-sort" style="left:0">球員 PLAYER</th>
                <th class="no-sort">位置</th>
                <th class="no-sort">健康狀態</th>
                <th class="no-sort">分鐘</th>
                <th class="no-sort">進球 G</th>
                <th class="no-sort">助攻 A</th>
                <th class="no-sort col-active">xGI (xG+xA)</th>
                <th class="no-sort">xG</th>
                <th class="no-sort">xA</th>
                <th class="no-sort">每90分 xGI</th>
                <th class="no-sort">零封 CS</th>
              </tr>
            </thead>
            <tbody>
              ${squad.map((p) => `
                <tr>
                  <td class="left sticky-pl" style="left:0">
                    <span class="pl-link" data-player-id="${EPL.esc(p.pid)}" style="font-weight:800;color:#059669">${EPL.esc(p.name)}</span>
                  </td>
                  <td>${EPL.esc(p.pos)}</td>
                  <td>${p.status === 'a' ? '<span class="chip ok">健康</span>' : `<span class="chip warn">${EPL.esc(p.news || '傷停')}</span>`}</td>
                  <td>${p.minutes}</td>
                  <td style="font-weight:700">${p.goals}</td>
                  <td>${p.assists}</td>
                  <td class="col-active">${Number(p.xgi).toFixed(2)}</td>
                  <td>${Number(p.xg).toFixed(2)}</td>
                  <td>${Number(p.xa).toFixed(2)}</td>
                  <td>${Number(p.xgi_per90).toFixed(2)}</td>
                  <td>${p.cs}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    root.querySelectorAll('[data-sel-gid]').forEach((tr) => {
      tr.onclick = () => {
        EPL.state.teamGameId = tr.getAttribute('data-sel-gid');
        EPL.render();
      };
    });
  };
})();
