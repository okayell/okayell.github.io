/* Page 10: 💬 極簡 3 欄位意見回饋與問題回報 (#/feedback — Pattern 175) */
(function () {
  'use strict';
  const EPL = window.EPL;

  const KIND_OPTS = [
    ['feature', '✨ 功能許願'],
    ['model', '📐 模型與盤口建議'],
    ['bug', '🐛 問題回報'],
    ['ui', '🎨 介面體驗'],
  ];

  let _fbKind = 'feature';
  let _fbSending = false;

  function renderFallbackBox(kindLabel, title, description, note) {
    if (window.CampusNav && CampusNav.fallbackHtml) {
      return CampusNav.fallbackHtml({
        email: 'okayell@hotmail.com',
        tool: '英超運彩智庫',
        kindLabel,
        title,
        description,
        note,
      });
    }
    const mailto = `mailto:okayell@hotmail.com?subject=${encodeURIComponent(`[英超運彩智庫 意見回饋] ${kindLabel} — ${title}`)}&body=${encodeURIComponent(description)}`;
    return `<div class="card" style="background:#fffbeb;border-color:#fde68a;font-size:12.5px">${EPL.esc(note || '已儲存於本機紀錄，請點此寄出：')} <a href="${mailto}" style="font-weight:800">📧 直接開啟信箱寄送給維護者</a>。</div>`;
  }

  EPL.pages.feedback = async function (root) {
    let items = [];
    if (EPL.isStatic) {
      try { items = JSON.parse(localStorage.getItem('epl.feedback.v1') || '[]'); } catch (_) { items = []; }
    } else {
      try {
        const r = await EPL.apiGet('/api/feedback');
        items = r.items || [];
      } catch (_) {
        try { items = JSON.parse(localStorage.getItem('epl.feedback.v1') || '[]'); } catch (e) { items = []; }
      }
    }

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">💬 意見回饋與功能許願池</h1>
          <div class="sec-sub">有任何英超盤口指標想法、球隊翻譯修正或問題回報，歡迎直接填寫送出</div>
        </div>
      </div>

      <div class="fb-layout">
        <form class="card" id="fbForm" style="display:flex;flex-direction:column;gap:14px">
          <div>
            <label style="font-weight:800;font-size:13px">1. 回饋類型</label>
            <div class="fb-type-pills" id="fbKindPills">
              ${[
                ['feature', '✨ 功能許願'],
                ['model', '📐 模型與盤口建議'],
                ['bug', '🐛 問題回報'],
                ['ui', '🎨 介面體驗'],
              ].map(([k, lbl]) => `<button type="button" class="fb-type-pill ${_fbKind === k ? 'active' : ''}" data-fbk="${k}">${lbl}</button>`).join('')}
            </div>
          </div>

          <label style="font-weight:800;font-size:13px">
            2. 標題
            <input class="inp" id="fbTitleInp" required maxlength="120" placeholder="簡短說明您的建議或遇到的狀況（支援中文輸入法選字保護）" style="width:100%;margin-top:6px">
          </label>

          <label style="font-weight:800;font-size:13px">
            3. 內容描述
            <textarea class="inp" id="fbDescInp" required rows="5" maxlength="3000" placeholder="請描述詳細需求、希望新增的英超聯賽統計或問題步驟…" style="width:100%;margin-top:6px"></textarea>
          </label>

          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
            <span style="font-size:12px;color:#64748b">送出後將自動留存紀錄並寄送通知信予維護團隊</span>
            <button type="submit" class="btn btn-primary" id="fbSubmitBtn">📨 送出回饋</button>
          </div>
          <div id="fbFallbackBox"></div>
        </form>

        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">📋 近期回饋紀錄 (${items.length})</h3>
          ${items.length
            ? `<div style="display:flex;flex-direction:column;gap:9px">
                ${items.slice(0, 12).map((it) => `
                  <div style="padding:10px 12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:9px">
                    <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:4px">
                      <span class="chip info">${EPL.esc(it.kind_zh || it.kind)}</span>
                      <span style="font-size:11.5px;color:#64748b">${EPL.esc(it.created_at || '')}</span>
                    </div>
                    <div style="font-weight:800;font-size:13.5px">${EPL.esc(it.title)}</div>
                    <div style="font-size:12.5px;color:#475569;margin-top:3px;white-space:pre-wrap">${EPL.esc(it.description)}</div>
                  </div>`).join('')}
              </div>`
            : `<div class="empty-box" style="padding:24px">目前尚無回饋紀錄，歡迎搶先留下第一則建議！</div>`}
        </div>
      </div>
    `;

    root.querySelectorAll('[data-fbk]').forEach((btn) => {
      btn.onclick = () => {
        _fbKind = btn.getAttribute('data-fbk');
        root.querySelectorAll('[data-fbk]').forEach((b) => b.classList.toggle('active', b === btn));
      };
    });

    const titleInp = document.getElementById('fbTitleInp');
    const descInp = document.getElementById('fbDescInp');
    if (titleInp) {
      titleInp.addEventListener('keydown', (ev) => {
        if (EPL.isEnterSend(ev)) {
          ev.preventDefault();
          if (descInp) descInp.focus();
        }
      });
    }

    const form = document.getElementById('fbForm');
    form.onsubmit = async (ev) => {
      ev.preventDefault();
      if (_fbSending) return;
      const title = titleInp.value.trim();
      const description = descInp.value.trim();
      if (!title || !description) return;

      const kPair = KIND_OPTS.find((x) => x[0] === _fbKind) || KIND_OPTS[0];
      const kindLabel = kPair[1];
      _fbSending = true;
      const btn = document.getElementById('fbSubmitBtn');
      btn.disabled = true;
      btn.textContent = '⏳ 傳送中…';

      try {
        if (EPL.isStatic) {
          const item = {
            id: 'FB-' + Date.now().toString(36).toUpperCase(),
            created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
            kind: _fbKind,
            kind_zh: kindLabel,
            title,
            description,
          };
          let list = [];
          try { list = JSON.parse(localStorage.getItem('epl.feedback.v1') || '[]'); } catch (_) { list = []; }
          list.unshift(item);
          try { localStorage.setItem('epl.feedback.v1', JSON.stringify(list.slice(0, 50))); } catch (_) {}
          let sent = false;
          if (window.CampusNav && CampusNav.sendStaticFeedback) {
            const mRes = await CampusNav.sendStaticFeedback({
              email: 'okayell@hotmail.com',
              tool: '英超運彩智庫',
              kindLabel,
              title,
              description,
              createdAt: item.created_at,
            });
            sent = !!(mRes && mRes.sent);
          } else {
            try {
              const resp = await fetch('https://formsubmit.co/ajax/okayell@hotmail.com', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                body: JSON.stringify({ _subject: `[英超運彩智庫 意見回饋] ${kindLabel} — ${title}`, _template: 'table', _captcha: 'false', 工具名稱: '英超運彩智庫', 回饋類型: kindLabel, 標題: title, 內容描述: description }),
              });
              const d = await resp.json().catch(() => ({}));
              sent = resp.ok && (d.success === true || d.success === 'true');
            } catch (_) { sent = false; }
          }
          await EPL.pages.feedback(root);
          const box = document.getElementById('fbFallbackBox');
          if (sent) {
            EPL.toast('✅ 感謝您的回饋！已成功寄出');
            if (box) box.innerHTML = `<div class="card" style="background:#f0fdf4;border-color:#86efac;color:#166534;padding:10px 13px;font-size:13px">✅ 感謝回饋！意見已成功寄送給站長。</div>`;
          } else if (box) {
            box.innerHTML = renderFallbackBox(kindLabel, title, description);
          }
        } else {
          const res = await EPL.apiPost('/api/feedback', { kind: _fbKind, title, description });
          const sentOk = !res || !res.item || res.item.mail_sent !== false;
          await EPL.pages.feedback(root);
          const box = document.getElementById('fbFallbackBox');
          if (sentOk) {
            EPL.toast('✅ 感謝您的意見回饋！系統已留存並寄出通知');
            if (box) box.innerHTML = `<div class="card" style="background:#f0fdf4;border-color:#86efac;color:#166534;padding:10px 13px;font-size:13px">✅ 已成功收到並寄送通知信給站長！</div>`;
          } else if (box) {
            box.innerHTML = renderFallbackBox(kindLabel, title, description, '✅ 回饋已儲存至伺服器紀錄；但自動寄信暫時忙碌，請任選下方一種方式一鍵寄達站長：');
          }
        }
      } catch (e) {
        const box = document.getElementById('fbFallbackBox');
        if (box) box.innerHTML = renderFallbackBox(kindLabel, title, description, `⚠️ 連線忙碌（${e.message || '無法自動送出'}），請任選下方一種方式一鍵寄達站長：`);
        else EPL.toast('⚠️ ' + e.message);
      } finally {
        _fbSending = false;
        const b2 = document.getElementById('fbSubmitBtn');
        if (b2) { b2.disabled = false; b2.textContent = '📨 送出回饋'; }
      }
    };
  };
})();
