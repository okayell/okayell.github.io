/* Page 3: 📊 2026-27 英超完賽過盤紀錄、賽後對獎總帳與損益走勢 (#/results) */
(function () {
  'use strict';
  const EPL = window.EPL;

  function resChip(res) {
    if (res === 'WIN') return '<span class="chip ok">✅ 命中</span>';
    if (res === 'LOSS') return '<span class="chip bad">❌ 未過</span>';
    if (res === 'PUSH') return '<span class="chip warn">➖ 走水</span>';
    return '<span class="chip muted">觀望</span>';
  }

  EPL.pages.results = function (root) {
    const snap = EPL.snap || {};
    const k = snap.kpi || {};
    const finals = (snap.games || []).filter((g) => g.status === 'FINAL').slice().reverse();
    const gwList = Array.from(new Set(finals.map((g) => g.gameweek))).sort((a, b) => b - a);
    const activeGw = EPL.state.resultsGw || 'ALL';
    const tab = EPL.state.resultsTab || 'ledger';

    const rows = activeGw === 'ALL' ? finals : finals.filter((g) => String(g.gameweek) === String(activeGw));
    const curve = ((snap.evolution || {}).curve || []);

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">📊 2026-27 英超完賽過盤紀錄與 Walk-Forward 真實回測總帳</h1>
          <div class="sec-sub">嚴格零偷看未來數據（Zero-Lookahead）：每場皆以開球前已知積分與射正統計預測，賽後依晚上 11 點鎖定盤對獎</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <select class="inp" id="resGwSel">
            <option value="ALL" ${activeGw === 'ALL' ? 'selected' : ''}>全部完賽輪次（共 ${finals.length} 場）</option>
            ${gwList.map((gw) => `<option value="${gw}" ${String(activeGw) === String(gw) ? 'selected' : ''}>第 ${gw} 輪 (GW${gw})</option>`).join('')}
          </select>
        </div>
      </div>

      <div class="odds-rule-bar">
        <div><strong>🔒 對獎盤口基準：</strong>所有完賽場次之亞洲讓球盤與大小球盤皆以賽前<strong>每天晚上 11:00（台灣時間）鎖定盤</strong>結算，杜絕賽後收盤飄移失真。</div>
        <span class="odds-rule-pill">損益平衡線 52.38% (-110)</span>
      </div>

      <div class="kpi-grid">
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>🔥 強推精選勝率</span><span class="chip strong">STRONG</span></div>
          <div class="kpi-val" style="color:${k.strong_win_rate >= 52.38 ? '#15803d' : '#b45309'}">${k.strong_win_rate || 0}%</div>
          <div class="kpi-sub">${k.strong_w || 0} 勝 - ${k.strong_l || 0} 敗</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>全推薦總勝率</span><span class="chip ok">STRONG+LEAN</span></div>
          <div class="kpi-val" style="color:#059669">${k.all_win_rate || 0}%</div>
          <div class="kpi-sub">${k.all_w || 0} 勝 - ${k.all_l || 0} 敗（優於熱門無腦買 ${k.baseline_win_rate || 40}%）</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>⚽ 亞洲讓球盤勝率</span><span>Spread</span></div>
          <div class="kpi-val">${k.ats_win_rate || 0}%</div>
          <div class="kpi-sub">${k.ats_w || 0} 勝 - ${k.ats_l || 0} 敗</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>🥅 大小球盤勝率</span><span>Over/Under</span></div>
          <div class="kpi-val">${k.ou_win_rate || 0}%</div>
          <div class="kpi-sub">${k.ou_w || 0} 勝 - ${k.ou_l || 0} 敗</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>💰 單注均注投資報酬率</span><span>ROI (-110)</span></div>
          <div class="kpi-val" style="color:${k.roi_pct >= 0 ? '#15803d' : '#b91c1c'}">${EPL.fmtSigned(k.roi_pct || 0, 1)}%</div>
          <div class="kpi-sub">依標準 1.91 賠率扣除水錢計算</div>
        </div>
      </div>

      <div class="sub-tabs">
        <button type="button" class="sub-tab ${tab === 'ledger' ? 'active' : ''}" data-rtab="ledger">📋 逐場過盤與覆盤總帳 (${rows.length})</button>
        <button type="button" class="sub-tab ${tab === 'curve' ? 'active' : ''}" data-rtab="curve">📈 比賽日累積損益走勢 (${curve.length})</button>
      </div>

      ${tab === 'ledger'
        ? `<div class="tbl-wrap">
            <table class="data-tbl">
              <thead>
                <tr>
                  <th>輪次 / 日期</th>
                  <th>主隊 vs 客隊</th>
                  <th>終場 (半場)</th>
                  <th>鎖定讓球盤 / 結果</th>
                  <th>模型讓球建議</th>
                  <th>鎖定大小盤 / 結果</th>
                  <th>模型大小建議</th>
                  <th>賽後覆盤歸因</th>
                  <th>技術統計</th>
                </tr>
              </thead>
              <tbody>
                ${rows.map((g) => {
                  const h = EPL.teamOf(g.home_abbr), a = EPL.teamOf(g.away_abbr);
                  const p = g.pred || {};
                  const atsPickTxt = p.ats_pick && p.ats_pick !== 'PASS'
                    ? `${p.ats_pick === 'HOME' ? h.zh : a.zh} (${p.ats_tier})`
                    : '觀望';
                  const ouPickTxt = p.ou_pick && p.ou_pick !== 'PASS'
                    ? `${p.ou_pick === 'OVER' ? '大球' : '小球'} (${p.ou_tier})`
                    : '觀望';
                  return `
                    <tr>
                      <td style="white-space:nowrap"><strong>GW${g.gameweek}</strong><div style="font-size:11px;color:#64748b">${EPL.esc(g.tw_date)}</div></td>
                      <td>
                        <span class="tm-link" data-team-link="${EPL.esc(h.abbr)}" style="font-weight:700">${EPL.esc(h.zh)}</span>
                        <span style="color:#94a3b8;margin:0 4px">vs</span>
                        <span class="tm-link" data-team-link="${EPL.esc(a.abbr)}" style="font-weight:700">${EPL.esc(a.zh)}</span>
                      </td>
                      <td style="font-weight:800">${g.home_score} : ${g.away_score} <span style="font-size:11px;color:#64748b;font-weight:400">(${g.ht_home ?? 0}:${g.ht_away ?? 0})</span></td>
                      <td>主 ${EPL.fmtSpread(g.close_spread_home)} → <strong>${g.ats_winner === 'HOME' ? '主過' : g.ats_winner === 'AWAY' ? '客過' : '走水'}</strong></td>
                      <td>${EPL.esc(atsPickTxt)} ${resChip(p.ats_result)}</td>
                      <td>${g.close_total} 球 → <strong>${g.ou_result === 'OVER' ? '大' : '小'} (${g.total_goals}球)</strong></td>
                      <td>${EPL.esc(ouPickTxt)} ${resChip(p.ou_graded)}</td>
                      <td style="max-width:260px;font-size:12px;color:#475569">${EPL.esc(p.postmortem_zh || '盤口走勢正常')}</td>
                      <td><button type="button" class="btn btn-sm" data-boxscore-gid="${EPL.esc(g.game_id)}">📊 Boxscore</button></td>
                    </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>`
        : `<div class="tbl-wrap">
            <table class="data-tbl">
              <thead>
                <tr>
                  <th>比賽日 (台灣時間)</th>
                  <th class="num">當日推薦戰績</th>
                  <th class="num">當日強推戰績</th>
                  <th class="num">累積總勝率</th>
                  <th class="num">累積單位損益 (Units)</th>
                </tr>
              </thead>
              <tbody>
                ${curve.slice().reverse().map((c) => `
                  <tr>
                    <td><strong>${EPL.esc(c.date)}</strong></td>
                    <td class="num">${c.day_w} 勝 - ${c.day_l} 敗</td>
                    <td class="num">${c.strong_w} 勝 - ${c.strong_l} 敗</td>
                    <td class="num"><strong>${c.cum_win_rate}%</strong></td>
                    <td class="num" style="font-weight:800;color:${c.cum_units >= 0 ? '#15803d' : '#b91c1c'}">${EPL.fmtSigned(c.cum_units, 2)} U</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>`}
    `;

    const sel = document.getElementById('resGwSel');
    if (sel) sel.onchange = () => { EPL.state.resultsGw = sel.value; EPL.render(); };
    root.querySelectorAll('[data-rtab]').forEach((b) => {
      b.onclick = () => { EPL.state.resultsTab = b.getAttribute('data-rtab'); EPL.render(); };
    });
  };
})();
