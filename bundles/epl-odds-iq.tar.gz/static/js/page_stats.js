/* Page 5: 🏆 2026-27 英超積分運彩榜、660+ 球員官方 FPL xG 數據榜與聯盟領先王 (#/stats) */
(function () {
  'use strict';
  const EPL = window.EPL;

  function renderLeaderCard(title, rows, valFn, unit) {
    if (!rows.length) return '';
    const top = rows[0];
    const topTm = EPL.teamOf(top.team);
    return `
      <div class="leader-card">
        <div class="leader-hdr"><span>${EPL.esc(title)}</span><span style="color:#64748b;font-size:11.5px">${EPL.esc(unit)}</span></div>
        <div class="leader-top1">
          <div style="display:flex;align-items:center;gap:10px;min-width:0">
            <img class="leader-avatar" src="${EPL.esc(top.headshot)}" alt="" onerror="this.src='${EPL.esc(topTm.logo)}'">
            <div style="min-width:0">
              <div class="pl-link" data-player-id="${EPL.esc(top.pid)}" style="font-weight:900;font-size:15px;color:#0f172a">${EPL.esc(top.name)}</div>
              <div class="tm-link" data-team-link="${EPL.esc(top.team)}" style="font-size:12px;color:#059669;font-weight:700">${EPL.esc(topTm.zh)} · ${EPL.esc(top.pos)}</div>
            </div>
          </div>
          <div class="leader-val-big">${valFn(top)}</div>
        </div>
        <div>
          ${rows.slice(1, 6).map((p, i) => `
            <div class="leader-row">
              <div style="display:flex;align-items:center;gap:7px">
                <span style="width:18px;color:#64748b;font-weight:700">${i + 2}.</span>
                <span class="pl-link" data-player-id="${EPL.esc(p.pid)}" style="font-weight:700">${EPL.esc(p.name)}</span>
                <span class="tm-link" data-team-link="${EPL.esc(p.team)}" style="font-size:11.5px;color:#64748b">(${EPL.esc(EPL.teamOf(p.team).zh)})</span>
              </div>
              <strong style="color:#0f172a">${valFn(p)}</strong>
            </div>`).join('')}
        </div>
      </div>`;
  }

  EPL.pages.stats = function (root) {
    const snap = EPL.snap || {};
    const ent = EPL.state.statsEntity || 'table';
    const teams = (snap.teams || []).slice();
    const players = (snap.player_stats || []).slice();

    let bodyHtml = '';
    if (ent === 'table') {
      const sk = EPL.state.tableSort || 'pts';
      const dir = EPL.state.tableDir === 'asc' ? 1 : -1;
      teams.sort((a, b) => (Number(a[sk] || 0) - Number(b[sk] || 0)) * dir || a.rank - b.rank);

      const cols = [
        ['pts', '積分 PTS'], ['gp', '已賽'], ['w', '勝'], ['d', '和'], ['l', '敗'],
        ['gf', '進球 GF'], ['ga', '失球 GA'], ['gd', '淨勝 GD'],
        ['ats_pct', '讓球過盤%'], ['over_pct', '大球開出%'], ['cs_pct', '零封%'], ['btts_pct', '雙進球%'],
      ];

      bodyHtml = `
        <div class="nba-pager-bar">
          <span>2026-27 英超 20 隊積分與運彩過盤／大小球／雙進球綜合榜（點擊表頭可排序；前 4 名歐冠區、第 18-20 名降級區）</span>
          <span style="font-weight:700;color:#059669">點擊俱樂部進入單隊專區</span>
        </div>
        <div class="nba-tbl-wrap">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="sticky-rk no-sort">排名</th>
                <th class="left sticky-pl no-sort">俱樂部 CLUB</th>
                ${cols.map(([k, lbl]) => `<th data-tsort="${k}" class="${sk === k ? 'col-active' : ''}">${lbl} ${sk === k ? (dir === -1 ? '▼' : '▲') : ''}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${teams.map((t) => {
                const zoneColor = t.rank <= 4 ? '#059669' : t.rank >= 18 ? '#b91c1c' : '#64748b';
                return `
                  <tr>
                    <td class="sticky-rk" style="color:${zoneColor};font-weight:800">${t.rank}</td>
                    <td class="left sticky-pl">
                      <span class="tm-link" data-team-link="${EPL.esc(t.abbr)}" style="display:inline-flex;align-items:center;gap:7px;font-weight:800">
                        <img src="${EPL.esc(t.logo)}" alt="" style="width:20px;height:20px;object-fit:contain">
                        ${EPL.esc(t.zh)} <span style="color:#94a3b8;font-size:11px">${EPL.esc(t.abbr)}</span>
                      </span>
                    </td>
                    <td class="${sk === 'pts' ? 'col-active' : ''}" style="font-weight:800">${t.pts}</td>
                    <td class="${sk === 'gp' ? 'col-active' : ''}">${t.gp}</td>
                    <td class="${sk === 'w' ? 'col-active' : ''}">${t.w}</td>
                    <td class="${sk === 'd' ? 'col-active' : ''}">${t.d}</td>
                    <td class="${sk === 'l' ? 'col-active' : ''}">${t.l}</td>
                    <td class="${sk === 'gf' ? 'col-active' : ''}">${t.gf}</td>
                    <td class="${sk === 'ga' ? 'col-active' : ''}">${t.ga}</td>
                    <td class="${sk === 'gd' ? 'col-active' : ''}">${EPL.fmtSigned(t.gd, 0)}</td>
                    <td class="${sk === 'ats_pct' ? 'col-active' : ''} nba-blue-num">${t.ats_pct}% (${t.ats_w}-${t.ats_l})</td>
                    <td class="${sk === 'over_pct' ? 'col-active' : ''}">${t.over_pct}% (${t.ou_o}大-${t.ou_u}小)</td>
                    <td class="${sk === 'cs_pct' ? 'col-active' : ''}">${t.cs_pct}%</td>
                    <td class="${sk === 'btts_pct' ? 'col-active' : ''}">${t.btts_pct}%</td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>`;
    } else if (ent === 'players') {
      const ftTeam = EPL.state.statsTeam || 'ALL';
      const ftPos = EPL.state.statsPos || 'ALL';
      const q = (EPL.state.statsSearch || '').trim().toLowerCase();
      const sk = EPL.state.statsSort || 'xgi';
      const dir = EPL.state.statsDir === 'asc' ? 1 : -1;

      const list = players.filter((p) => {
        if (ftTeam !== 'ALL' && p.team !== ftTeam) return false;
        if (ftPos !== 'ALL' && p.pos !== ftPos) return false;
        if (q && !`${p.name} ${p.full_name} ${p.team}`.toLowerCase().includes(q)) return false;
        return true;
      }).sort((a, b) => (Number(a[sk] || 0) - Number(b[sk] || 0)) * dir).slice(0, 120);

      const cols = [
        ['minutes', '分鐘'], ['goals', '進球 G'], ['assists', '助攻 A'], ['ga_sum', 'G+A'],
        ['xg', '預期進球 xG'], ['xa', '預期助攻 xA'], ['xgi', 'xGI'], ['xgi_per90', 'xGI/90'],
        ['cs', '零封'], ['saves', '撲救'], ['form', '近況 Form'],
      ];

      bodyHtml = `
        <div class="stats-filter-grid">
          <div class="sf-field">
            <span class="sf-lbl">所屬俱樂部</span>
            <select class="inp" id="stClubSel">
              <option value="ALL">全部 20 隊</option>
              ${(snap.teams || []).map((t) => `<option value="${t.abbr}" ${ftTeam === t.abbr ? 'selected' : ''}>${EPL.esc(t.zh)} (${t.abbr})</option>`).join('')}
            </select>
          </div>
          <div class="sf-field">
            <span class="sf-lbl">場上位置</span>
            <select class="inp" id="stPosSel">
              <option value="ALL">全部位置</option>
              ${['FWD', 'MID', 'DEF', 'GK'].map((pos) => `<option value="${pos}" ${ftPos === pos ? 'selected' : ''}>${pos}</option>`).join('')}
            </select>
          </div>
          <div class="sf-field">
            <span class="sf-lbl">搜尋球員姓名</span>
            <input class="inp" id="stPlayerSearch" value="${EPL.esc(EPL.state.statsSearch || '')}" placeholder="如 Haaland, Saka, Salah…">
          </div>
        </div>
        <div class="nba-pager-bar">
          <span>顯示前 ${list.length} 名球員（資料來源：Premier League Official Fantasy xG API）</span>
          <span style="color:#059669;font-weight:700">點擊球員查看個人 xG 偏離度卡片</span>
        </div>
        <div class="nba-tbl-wrap">
          <table class="nba-stats-tbl">
            <thead>
              <tr>
                <th class="sticky-rk no-sort">#</th>
                <th class="left sticky-pl no-sort">球員 PLAYER</th>
                <th class="left no-sort">俱樂部</th>
                <th class="no-sort">位置</th>
                ${cols.map(([k, lbl]) => `<th data-psort="${k}" class="${sk === k ? 'col-active' : ''}">${lbl} ${sk === k ? (dir === -1 ? '▼' : '▲') : ''}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${list.map((p, idx) => {
                const tm = EPL.teamOf(p.team);
                return `
                  <tr>
                    <td class="sticky-rk">${idx + 1}</td>
                    <td class="left sticky-pl">
                      <span class="pl-link" data-player-id="${EPL.esc(p.pid)}" style="font-weight:800;color:#059669">${EPL.esc(p.name)}</span>
                    </td>
                    <td class="left"><span class="tm-link" data-team-link="${EPL.esc(p.team)}" style="font-weight:700">${EPL.esc(tm.zh)}</span></td>
                    <td>${EPL.esc(p.pos)}</td>
                    <td class="${sk === 'minutes' ? 'col-active' : ''}">${p.minutes}</td>
                    <td class="${sk === 'goals' ? 'col-active' : ''}" style="font-weight:800">${p.goals}</td>
                    <td class="${sk === 'assists' ? 'col-active' : ''}">${p.assists}</td>
                    <td class="${sk === 'ga_sum' ? 'col-active' : ''}">${p.ga_sum}</td>
                    <td class="${sk === 'xg' ? 'col-active' : ''}">${Number(p.xg).toFixed(2)}</td>
                    <td class="${sk === 'xa' ? 'col-active' : ''}">${Number(p.xa).toFixed(2)}</td>
                    <td class="${sk === 'xgi' ? 'col-active' : ''}">${Number(p.xgi).toFixed(2)}</td>
                    <td class="${sk === 'xgi_per90' ? 'col-active' : ''}">${Number(p.xgi_per90).toFixed(2)}</td>
                    <td class="${sk === 'cs' ? 'col-active' : ''}">${p.cs}</td>
                    <td class="${sk === 'saves' ? 'col-active' : ''}">${p.saves}</td>
                    <td class="${sk === 'form' ? 'col-active' : ''}">${Number(p.form).toFixed(1)}</td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>`;
    } else {
      const byGoals = players.slice().sort((a, b) => b.goals - a.goals || b.xg - a.xg);
      const byAssists = players.slice().sort((a, b) => b.assists - a.assists || b.xa - a.xa);
      const byXg = players.slice().sort((a, b) => b.xg - a.xg);
      const byXgi = players.slice().sort((a, b) => b.xgi - a.xgi);
      const bySaves = players.filter((p) => p.pos === 'GK').sort((a, b) => b.saves - a.saves);
      const byForm = players.slice().sort((a, b) => b.form - a.form);
      bodyHtml = `
        <div class="leader-grid">
          ${renderLeaderCard('⚽ 英超金靴進球榜 Goals', byGoals, (p) => p.goals, '球')}
          ${renderLeaderCard('🎯 英超助攻王 Assists', byAssists, (p) => p.assists, '次')}
          ${renderLeaderCard('📐 預期進球王 Expected Goals (xG)', byXg, (p) => Number(p.xg).toFixed(2), 'xG')}
          ${renderLeaderCard('🔥 預期進球參與王 (xGI = xG+xA)', byXgi, (p) => Number(p.xgi).toFixed(2), 'xGI')}
          ${renderLeaderCard('🧤 門將神撲救王 Saves', bySaves, (p) => p.saves, '次撲救')}
          ${renderLeaderCard('⚡ 近況火燙指數王 FPL Form', byForm, (p) => Number(p.form).toFixed(1), 'Form')}
        </div>`;
    }

    root.innerHTML = `
      <div class="stats-nav-strip">
        <div class="stats-entity-links">
          <button type="button" class="stats-entity-btn ${ent === 'table' ? 'active' : ''}" data-ent="table">🏆 英超積分與過盤榜</button>
          <span class="stats-sep">|</span>
          <button type="button" class="stats-entity-btn ${ent === 'players' ? 'active' : ''}" data-ent="players">🏃 球員官方 FPL xG 數據榜</button>
          <span class="stats-sep">|</span>
          <button type="button" class="stats-entity-btn ${ent === 'leaders' ? 'active' : ''}" data-ent="leaders">👑 聯盟單項領先王</button>
        </div>
        <span style="font-size:12px;color:#64748b">2026-27 賽季即時統計</span>
      </div>
      ${bodyHtml}
    `;

    root.querySelectorAll('[data-ent]').forEach((b) => {
      b.onclick = () => { EPL.state.statsEntity = b.getAttribute('data-ent'); EPL.render(); };
    });
    root.querySelectorAll('[data-tsort]').forEach((th) => {
      th.onclick = () => {
        const k = th.getAttribute('data-tsort');
        if (EPL.state.tableSort === k) EPL.state.tableDir = EPL.state.tableDir === 'desc' ? 'asc' : 'desc';
        else { EPL.state.tableSort = k; EPL.state.tableDir = 'desc'; }
        EPL.render();
      };
    });
    root.querySelectorAll('[data-psort]').forEach((th) => {
      th.onclick = () => {
        const k = th.getAttribute('data-psort');
        if (EPL.state.statsSort === k) EPL.state.statsDir = EPL.state.statsDir === 'desc' ? 'asc' : 'desc';
        else { EPL.state.statsSort = k; EPL.state.statsDir = 'desc'; }
        EPL.render();
      };
    });
    const cs = document.getElementById('stClubSel');
    if (cs) cs.onchange = () => { EPL.state.statsTeam = cs.value; EPL.render(); };
    const ps = document.getElementById('stPosSel');
    if (ps) ps.onchange = () => { EPL.state.statsPos = ps.value; EPL.render(); };
    const inp = document.getElementById('stPlayerSearch');
    if (inp) {
      inp.oninput = () => {
        EPL.state.statsSearch = inp.value;
        EPL.render();
        const el = document.getElementById('stPlayerSearch');
        if (el) { el.focus({ preventScroll: true }); el.setSelectionRange(el.value.length, el.value.length); }
      };
    }
  };
})();
