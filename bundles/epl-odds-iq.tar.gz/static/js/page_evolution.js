/* Page 7: 🧠 泊松模型自我檢討與因子權重進化中心 (#/evolution) */
(function () {
  'use strict';
  const EPL = window.EPL;

  function renderWeightRows(items) {
    return (items || []).map((f) => {
      const pct = Math.min(100, Math.round((Number(f.weight || 1) / 1.45) * 100));
      const col = f.hit_rate >= 54 ? '#059669' : f.hit_rate < 48 ? '#e11d48' : '#2563eb';
      return `
        <div style="padding:9px 0;border-bottom:1px solid #f1f5f9">
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:13px">
            <strong>${EPL.esc(f.label)}</strong>
            <span>權重 <strong>${Number(f.weight).toFixed(3)}x</strong> · 歷史準確率 <strong style="color:${col}">${f.hit_rate}%</strong> (${f.samples}場)</span>
          </div>
          <div class="fac-bar-track" style="margin:5px 0"><div class="fac-bar-fill" style="width:${pct}%;background:${col}"></div></div>
          <div style="font-size:11.5px;color:#64748b">${EPL.esc(f.desc || '')}</div>
        </div>`;
    }).join('');
  }

  EPL.pages.evolution = function (root) {
    const snap = EPL.snap || {};
    const evo = snap.evolution || {};
    const coach = snap.ai_coach;

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🧠 賽後自動檢討歸因 ＆ 泊松因子權重進化中心（${EPL.esc((snap.meta || {}).model_version || 'v2.8')}）</h1>
          <div class="sec-sub">每場英超完賽後自動比對泊松期望進球 λ 與實際賽果，剖析「和局陷阱、紅牌變數、xG 終結背離、傷停補時絕殺」並線上調整權重</div>
        </div>
        ${!EPL.isStatic && EPL.health.ai ? `<button type="button" class="btn btn-primary" id="runAiCoachBtn">🤖 請 AI 總教練執行最新賽後覆盤</button>` : ''}
      </div>

      ${coach
        ? `<div class="card" style="background:linear-gradient(135deg,#ecfdf5 0%,#ffffff 100%);border-color:#6ee7b7;margin-bottom:14px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
              <strong style="font-size:15px;color:#065f46">🤖 AI 運彩模型總教練覆盤報告：${EPL.esc(coach.title || '')}</strong>
              <span style="font-size:11.5px;color:#64748b">${EPL.esc(coach.generated_at || '')}</span>
            </div>
            <div style="font-size:13px;color:#1e293b;margin-bottom:8px"><strong>本輪最大盲點：</strong>${EPL.esc(coach.key_lesson || '')}</div>
            <ul style="margin:0;padding-left:18px;font-size:12.5px;color:#334155">
              ${(coach.action_items || []).map((x) => `<li>${EPL.esc(x)}</li>`).join('')}
            </ul>
          </div>`
        : ''}

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,440px),1fr));gap:14px;margin-bottom:16px">
        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:8px">⚽ 亞洲讓球盤 7 大動態學習因子權重</h3>
          ${renderWeightRows(evo.ats_factors)}
        </div>
        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:8px">🥅 大小球盤 6 大動態學習因子權重</h3>
          ${renderWeightRows(evo.ou_factors)}
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:14px">
        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">🔍 倒關失誤歸因統計（Error Attribution）</h3>
          <div style="display:flex;flex-direction:column;gap:8px">
            ${(evo.error_breakdown || []).map((e) => `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 11px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0">
                <span style="font-weight:700">${EPL.esc(e.label)}</span>
                <span class="chip ${e.tag === 'CLEAN_READ' ? 'ok' : 'warn'}">${e.count} 場</span>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="card">
          <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">📜 逐日線上學習與對獎日誌（Daily Evolution Log）</h3>
          <div class="tbl-wrap">
            <table class="data-tbl">
              <thead><tr><th>比賽日</th><th class="num">當日推薦命中</th><th class="num">強推戰績</th><th class="num">當日損益</th></tr></thead>
              <tbody>
                ${(evo.daily_log || []).map((d) => `
                  <tr>
                    <td><strong>${EPL.esc(d.date)}</strong></td>
                    <td class="num">${d.day_w}W - ${d.day_l}L</td>
                    <td class="num">${d.strong_w}W - ${d.strong_l}L</td>
                    <td class="num" style="font-weight:800;color:${d.day_units >= 0 ? '#15803d' : '#b91c1c'}">${EPL.fmtSigned(d.day_units, 2)} U</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    const aiBtn = document.getElementById('runAiCoachBtn');
    if (aiBtn) {
      aiBtn.onclick = async () => {
        aiBtn.disabled = true;
        aiBtn.textContent = '⏳ AI 總教練覆盤運算中…';
        try {
          const st = await EPL.apiPost('/api/ai/start', { kind: 'daily_coach' });
          for (let i = 0; i < 55; i++) {
            await new Promise((r) => setTimeout(r, 1200));
            const tk = await EPL.apiGet(`/api/ai/task?id=${encodeURIComponent(st.task)}`);
            if (tk.status === 'done') {
              await EPL.refreshAllData();
              EPL.toast('✅ AI 總教練已完成最新賽後檢討！');
              return;
            }
            if (tk.status === 'error') throw new Error(tk.error || 'AI 覆盤失敗');
          }
        } catch (e) {
          EPL.toast('⚠️ ' + e.message);
        } finally {
          aiBtn.disabled = false;
          aiBtn.textContent = '🤖 請 AI 總教練執行最新賽後覆盤';
        }
      };
    }
  };
})();
