/* Page 6: 🏥 官方 FPL 傷停禁賽機率雷達與中英文英超新聞 (#/news) */
(function () {
  'use strict';
  const EPL = window.EPL;

  EPL.pages.news = function (root) {
    const snap = EPL.snap || {};
    const tab = EPL.state.newsTab || 'injuries';
    const injuries = snap.injuries || [];
    const news = snap.news || [];

    const injClub = EPL.state.injTeam || 'ALL';
    const injSt = EPL.state.injStatus || 'ALL';
    const filteredInj = injuries.filter((x) => {
      if (injClub !== 'ALL' && x.team !== injClub) return false;
      if (injSt === 'OUT' && x.play_prob > 0) return false;
      if (injSt === 'DOUBT' && (x.play_prob === 0 || x.play_prob >= 100)) return false;
      return true;
    });

    const nq = (EPL.state.newsQuery || '').trim().toLowerCase();
    const filteredNews = news.filter((n) => !nq || `${n.title} ${n.summary || ''} ${n.team_abbrs || ''}`.toLowerCase().includes(nq));

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🏥 英超官方 FPL 傷停／紅黃牌禁賽雷達 ＆ 賽前先發情報</h1>
          <div class="sec-sub">整合 Premier League 官方各隊領隊賽前記者會公布之下輪出賽機率（0% / 25% / 50% / 75%）與即時外電新聞</div>
        </div>
      </div>

      <div class="sub-tabs">
        <button type="button" class="sub-tab ${tab === 'injuries' ? 'active' : ''}" data-ntab="injuries">🏥 官方 FPL 傷停與禁賽名單 (${injuries.length})</button>
        <button type="button" class="sub-tab ${tab === 'news' ? 'active' : ''}" data-ntab="news">📰 英超賽前外電與台灣新聞 (${news.length})</button>
      </div>

      ${tab === 'injuries'
        ? `
          <div class="stats-filter-grid">
            <div class="sf-field">
              <span class="sf-lbl">篩選俱樂部</span>
              <select class="inp" id="injClubSel">
                <option value="ALL">全部 20 支俱樂部</option>
                ${(snap.teams || []).map((t) => `<option value="${t.abbr}" ${injClub === t.abbr ? 'selected' : ''}>${EPL.esc(t.zh)} (${t.abbr})</option>`).join('')}
              </select>
            </div>
            <div class="sf-field">
              <span class="sf-lbl">出賽機率狀態</span>
              <select class="inp" id="injStSel">
                <option value="ALL" ${injSt === 'ALL' ? 'selected' : ''}>全部傷停與觀察名單</option>
                <option value="OUT" ${injSt === 'OUT' ? 'selected' : ''}>確定缺陣／禁賽 (0%)</option>
                <option value="DOUBT" ${injSt === 'DOUBT' ? 'selected' : ''}>賽前評估存疑 (25%–75%)</option>
              </select>
            </div>
          </div>
          <div class="tbl-wrap">
            <table class="data-tbl">
              <thead>
                <tr>
                  <th>俱樂部</th>
                  <th>球員 (位置)</th>
                  <th>狀態與下輪出賽率</th>
                  <th>本季貢獻 (分鐘 / G+A / xGI)</th>
                  <th>進球影響折損</th>
                  <th>官方醫療／禁賽說明</th>
                </tr>
              </thead>
              <tbody>
                ${filteredInj.map((it) => {
                  const tm = EPL.teamOf(it.team);
                  const chipCls = it.play_prob === 0 ? 'bad' : it.play_prob <= 50 ? 'warn' : 'info';
                  return `
                    <tr>
                      <td>
                        <span class="tm-link" data-team-link="${EPL.esc(it.team)}" style="display:inline-flex;align-items:center;gap:6px;font-weight:800">
                          <img loading="lazy" decoding="async" src="${EPL.esc(tm.logo)}" alt="" style="width:20px;height:20px;object-fit:contain">
                          ${EPL.esc(tm.zh)}
                        </span>
                      </td>
                      <td>
                        <span class="pl-link" data-player-id="${EPL.esc(it.fpl_id)}" style="font-weight:800;color:#059669">${EPL.esc(it.name)}</span>
                        <span style="color:#64748b;font-size:11.5px;margin-left:4px">${EPL.esc(it.pos)}</span>
                      </td>
                      <td><span class="chip ${chipCls}">${EPL.esc(it.status_zh)} · ${it.play_prob}% 上場</span></td>
                      <td>${it.minutes} 分鐘 · ${it.goals}G/${it.assists}A · <strong>${Number(it.xgi).toFixed(2)} xGI</strong></td>
                      <td style="font-weight:700;color:#b91c1c">-${Number(it.impact_goals || 0).toFixed(2)} 球</td>
                      <td style="color:#334155;font-size:12.5px">${EPL.esc(it.news)}</td>
                    </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>`
        : `
          <div style="margin-bottom:12px">
            <input class="inp" id="newsSearchInp" value="${EPL.esc(EPL.state.newsQuery || '')}" placeholder="🔍 搜尋新聞關鍵字或球隊代號…" style="width:100%;max-width:380px">
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,340px),1fr));gap:12px">
            ${filteredNews.map((n) => `
              <article class="card" style="display:flex;flex-direction:column;gap:8px">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;font-size:11.5px;color:#64748b">
                  <span class="chip ${n.category === 'injury' ? 'warn' : 'info'}">${EPL.esc(n.source || 'EPL News')}</span>
                  <span>${EPL.esc(n.published_tw || '')}</span>
                </div>
                <a href="${EPL.esc(n.url || '#')}" target="_blank" rel="noopener noreferrer" style="font-weight:800;font-size:14.5px;color:#0f172a;line-height:1.45">${EPL.esc(n.title)}</a>
                ${n.summary ? `<div style="font-size:12.5px;color:#475569">${EPL.esc(n.summary)}</div>` : ''}
                ${n.team_abbrs ? `<div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:auto">${n.team_abbrs.split(',').filter(Boolean).map((ab) => `<span class="chip muted tm-link" data-team-link="${EPL.esc(ab)}">${EPL.esc(EPL.teamOf(ab).zh)}</span>`).join('')}</div>` : ''}
              </article>
            `).join('')}
          </div>`}
    `;

    root.querySelectorAll('[data-ntab]').forEach((b) => {
      b.onclick = () => { EPL.state.newsTab = b.getAttribute('data-ntab'); EPL.render(); };
    });
    const ic = document.getElementById('injClubSel');
    if (ic) ic.onchange = () => { EPL.state.injTeam = ic.value; EPL.render(); };
    const is = document.getElementById('injStSel');
    if (is) is.onchange = () => { EPL.state.injStatus = is.value; EPL.render(); };
    EPL.bindLiveSearch('newsSearchInp', (v) => { EPL.state.newsQuery = v; });
  };
})();
