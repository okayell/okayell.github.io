/* Page 8: 📝 個人英超注單追蹤、自動對獎與凱利注碼計算機 (#/bankroll) */
(function () {
  'use strict';
  const EPL = window.EPL;

  EPL.pages.bankroll = function (root) {
    const bets = EPL.bets || [];
    const settled = bets.filter((b) => b.status === 'WIN' || b.status === 'LOSS' || b.status === 'PUSH');
    const wins = settled.filter((b) => b.status === 'WIN').length;
    const losses = settled.filter((b) => b.status === 'LOSS').length;
    const totStake = settled.reduce((s, b) => s + Number(b.stake || 0), 0);
    const totPnl = settled.reduce((s, b) => s + Number(b.pnl || 0), 0);
    const roi = totStake > 0 ? (totPnl / totStake) * 100 : 0;

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">📝 個人英超注單追蹤與 Quarter-Kelly 資金控管中心</h1>
          <div class="sec-sub">從「🎯 本輪解盤」或「🎰 英超串關」加入之單場注單，於英超完賽同步時將自動依賽果結算損益</div>
        </div>
        ${!EPL.isStatic ? `<a class="btn btn-soft btn-sm" href="/download/index.html" download="index.html">⬇️ 下載最新單檔 index.html (GitHub Pages)</a>` : ''}
      </div>

      <div class="kpi-grid">
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>總紀錄注單數</span><span>待開獎 ${bets.length - settled.length} 筆</span></div>
          <div class="kpi-val">${bets.length} 筆</div>
          <div class="kpi-sub">已結算 ${settled.length} 筆</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>個人實戰勝率</span><span>不含走水</span></div>
          <div class="kpi-val">${wins + losses > 0 ? ((wins / (wins + losses)) * 100).toFixed(1) : '0.0'}%</div>
          <div class="kpi-sub">${wins} 勝 - ${losses} 敗</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>累積實戰淨損益</span><span>NT$</span></div>
          <div class="kpi-val" style="color:${totPnl >= 0 ? '#15803d' : '#b91c1c'}">${totPnl >= 0 ? '+' : ''}${Math.round(totPnl).toLocaleString()}</div>
          <div class="kpi-sub">總投入本金 NT$ ${Math.round(totStake).toLocaleString()}</div>
        </div>
        <div class="kpi-card static-kpi">
          <div class="kpi-lbl"><span>投資報酬率 ROI</span><span>淨利 / 總投入</span></div>
          <div class="kpi-val" style="color:${roi >= 0 ? '#15803d' : '#b91c1c'}">${EPL.fmtSigned(roi, 1)}%</div>
          <div class="kpi-sub">建議單注不超過總本金 2.5%</div>
        </div>
      </div>

      <div class="card" style="margin-bottom:16px">
        <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">🧮 1/4 凱利公式（Quarter-Kelly）足球注碼試算器</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;align-items:end">
          <label style="font-size:12.5px">總運彩資金池 (NT$)<br><input type="number" class="inp" id="klBank" value="50000" style="width:100%;margin-top:4px"></label>
          <label style="font-size:12.5px">莊家十進位賠率<br><input type="number" step="0.01" class="inp" id="klOdds" value="1.91" style="width:100%;margin-top:4px"></label>
          <label style="font-size:12.5px">模型預估過盤率 (%)<br><input type="number" step="0.5" class="inp" id="klProb" value="57.0" style="width:100%;margin-top:4px"></label>
          <div class="th-stat" id="klOutBox">
            <div class="th-stat-lbl">建議最佳單場注額 (1/4 Kelly)</div>
            <div class="th-stat-val" style="color:#059669" id="klOutVal">NT$ 1,220</div>
          </div>
        </div>
      </div>

      <div class="card">
        <h3 class="sec-title" style="font-size:15px;margin-bottom:10px">📋 我的注單明細</h3>
        ${bets.length
          ? `<div class="tbl-wrap">
              <table class="data-tbl">
                <thead>
                  <tr><th>日期</th><th>賽事組合</th><th>玩法 / 標的</th><th class="num">賠率</th><th class="num">本金</th><th>狀態</th><th class="num">損益</th><th>操作</th></tr>
                </thead>
                <tbody>
                  ${bets.map((b) => `
                    <tr>
                      <td>${EPL.esc(b.tw_date)}</td>
                      <td><strong>${EPL.esc(b.matchup)}</strong>${b.note ? `<div style="font-size:11px;color:#64748b">${EPL.esc(b.note)}</div>` : ''}</td>
                      <td><span class="chip muted">${EPL.esc(b.market)}</span> ${EPL.esc(b.pick_label)}</td>
                      <td class="num">${Number(b.odds_decimal).toFixed(2)}</td>
                      <td class="num">NT$ ${Number(b.stake).toLocaleString()}</td>
                      <td><span class="chip ${b.status === 'WIN' ? 'ok' : b.status === 'LOSS' ? 'bad' : b.status === 'PUSH' ? 'warn' : 'info'}">${b.status}</span></td>
                      <td class="num" style="font-weight:800;color:${b.pnl > 0 ? '#15803d' : b.pnl < 0 ? '#b91c1c' : '#64748b'}">${b.pnl > 0 ? '+' : ''}${Math.round(b.pnl).toLocaleString()}</td>
                      <td>
                        <div style="display:flex;gap:4px">
                          <select class="inp" data-settle-id="${EPL.esc(b.bet_id)}" style="padding:3px 6px;font-size:11.5px">
                            ${['PENDING', 'WIN', 'LOSS', 'PUSH'].map((s) => `<option value="${s}" ${b.status === s ? 'selected' : ''}>${s}</option>`).join('')}
                          </select>
                          <button type="button" class="btn btn-sm" data-del-id="${EPL.esc(b.bet_id)}">✕</button>
                        </div>
                      </td>
                    </tr>`).join('')}
                </tbody>
              </table>
            </div>`
          : `<div class="empty-box">目前尚無注單紀錄，可於「🎯 本輪解盤」或「🎰 英超串關」點擊「➕ 記注單」開始追蹤！</div>`}
      </div>
    `;

    function calcKelly() {
      const bank = Math.max(0, Number(document.getElementById('klBank').value || 0));
      const odds = Math.max(1.01, Number(document.getElementById('klOdds').value || 1.91));
      const p = Math.min(0.99, Math.max(0.01, Number(document.getElementById('klProb').value || 55) / 100));
      const b = odds - 1;
      const fullK = (b * p - (1 - p)) / b;
      const qk = Math.max(0, Math.min(0.05, fullK * 0.25));
      const amt = Math.round(bank * qk);
      document.getElementById('klOutVal').textContent = fullK <= 0 ? 'NT$ 0（無正期望值，建議觀望）' : `NT$ ${amt.toLocaleString()} (${(qk * 100).toFixed(2)}%)`;
    }
    ['klBank', 'klOdds', 'klProb'].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.oninput = calcKelly;
    });
    calcKelly();

    root.querySelectorAll('[data-settle-id]').forEach((sel) => {
      sel.onchange = async () => {
        const res = await EPL.apiPost('/api/bets/settle', { bet_id: sel.getAttribute('data-settle-id'), status: sel.value });
        EPL.bets = res.bets || [];
        EPL.render();
      };
    });
    root.querySelectorAll('[data-del-id]').forEach((btn) => {
      btn.onclick = async () => {
        const res = await EPL.apiPost('/api/bets/delete', { bet_id: btn.getAttribute('data-del-id') });
        EPL.bets = res.bets || [];
        EPL.render();
      };
    });
  };
})();
