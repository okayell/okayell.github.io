/* Page 1: 🎯 英超本輪盤口分析、泊松期望進球與下注建議 (#/picks) */
(function () {
  'use strict';
  const EPL = window.EPL;

  function tierBadge(tier) {
    if (tier === 'STRONG') return '<span class="chip strong">🔥 強推精選</span>';
    if (tier === 'LEAN') return '<span class="chip ok">✅ 順勢推薦</span>';
    return '<span class="chip muted">⚖️ 觀望不碰</span>';
  }

  function resultBadge(res) {
    if (res === 'WIN') return '<span class="chip ok">✅ 命中過盤</span>';
    if (res === 'LOSS') return '<span class="chip bad">❌ 未過盤</span>';
    if (res === 'PUSH') return '<span class="chip warn">➖ 走水退本</span>';
    return '';
  }

  function renderSpreadMove(openSp, closeSp, homeZh, awayZh) {
    if (closeSp == null) return '<span class="odds-sub">⏳ 等待 18:00 初盤／23:00 定盤（台灣時間）抓盤</span>';
    const sp = Number(closeSp);
    const favTxt = sp < 0 ? `${homeZh} 主讓 ${Math.abs(sp)}` : sp > 0 ? `${awayZh} 客讓 ${Math.abs(sp)}` : 'PK 平手盤 (0)';
    if (openSp == null || Number(openSp) === sp) {
      return `<div class="odds-sub">${EPL.esc(favTxt)}（初盤持平）</div>`;
    }
    const delta = Number(openSp) - sp;
    const dirTxt = delta > 0 ? `▲ 升盤往${homeZh}傾斜` : `▼ 退盤往${awayZh}傾斜`;
    return `<div class="odds-sub">18:00 初盤 ${EPL.fmtSpread(openSp)} → 23:00 定盤 ${EPL.fmtSpread(sp)} <span class="${delta > 0 ? 'move-up' : 'move-dn'}">(${EPL.esc(dirTxt)})</span></div>`;
  }

  function renderTotalMove(openTot, closeTot) {
    if (!closeTot) return '<span class="odds-sub">⏳ 等待 18:00 初盤／23:00 定盤（台灣時間）抓盤</span>';
    if (!openTot || Number(openTot) === Number(closeTot)) {
      return `<div class="odds-sub">標準線 ${closeTot} 球（盤口持平）</div>`;
    }
    const diff = +(Number(closeTot) - Number(openTot)).toFixed(2);
    return `<div class="odds-sub">18:00 初盤 ${openTot} → 23:00 定盤 ${closeTot} <span class="${diff > 0 ? 'move-up' : 'move-dn'}">(${diff > 0 ? '▲ 調升大球門檻' : '▼ 下修小球線'})</span></div>`;
  }

  function renderFactorBars(atsFac, ouFac, hZh, aZh) {
    const metaAts = {
      xg_net_diff: 'xG 射正淨勝差',
      home_fortress: '主客場得失球差',
      key_injury_susp: '主力傷停與禁賽',
      rest_euro_fatigue: '歐戰雙線疲勞差',
      line_steam: '莊家升退盤資金',
      draw_trap_shield: '和局防雷護盾',
      finishing_regression: '終結效率均值回歸',
    };
    const rows = Object.entries(metaAts).map(([k, lbl]) => {
      const raw = (atsFac || {})[k];
      const v = Number(raw && typeof raw === 'object' ? raw.weighted : raw) || 0;
      const pct = Math.min(100, Math.round(Math.abs(v) * 75));
      const col = v >= 0 ? '#059669' : '#2563eb';
      const dir = v > 0.03 ? `利主 ${hZh}` : v < -0.03 ? `利客 ${aZh}` : '中性';
      return `
        <div class="fac-row">
          <span style="color:#475569;font-weight:600">${EPL.esc(lbl)}</span>
          <div class="fac-bar-track"><div class="fac-bar-fill" style="width:${pct}%;background:${col}"></div></div>
          <span class="num" style="font-size:11px;color:${col};font-weight:700">${EPL.esc(dir)}</span>
        </div>`;
    });
    return `<div class="fac-list">${rows.join('')}</div>`;
  }

  function renderGameCard(g) {
    const h = EPL.teamOf(g.home_abbr);
    const a = EPL.teamOf(g.away_abbr);
    const p = g.pred || {};
    const hasStrong = p.ats_tier === 'STRONG' || p.ou_tier === 'STRONG';
    const spH = g.close_spread_home;
    const spA = spH != null ? -Number(spH) : null;

    // ATS Pick
    let atsTargetTxt = '等待莊家開盤';
    if (spH != null) {
      const side = p.ats_pick !== 'PASS' ? p.ats_pick : p.ats_lean_side || 'HOME';
      const pickTm = side === 'HOME' ? h : a;
      const line = side === 'HOME' ? Number(spH) : Number(spA);
      const role = line < 0 ? '讓球' : line > 0 ? '受讓含和局贏' : '平手盤';
      atsTargetTxt = p.ats_pick !== 'PASS'
        ? `${pickTm.zh} ${EPL.fmtSpread(line)}（${role}）`
        : `建議觀望 · 微偏${pickTm.zh} ${EPL.fmtSpread(line)}`;
    }

    // OU Pick
    let ouTargetTxt = '等待莊家開盤';
    if (g.close_total) {
      const side = p.ou_pick !== 'PASS' ? p.ou_pick : p.ou_lean_side || 'OVER';
      const word = side === 'OVER' ? '大球 (OVER)' : '小球 (UNDER)';
      ouTargetTxt = p.ou_pick !== 'PASS'
        ? `${word} ${g.close_total}`
        : `建議觀望 · 微偏${side === 'OVER' ? '大球' : '小球'} ${g.close_total}`;
    }

    // Injuries
    const allInj = [
      ...(g.home_injuries || []).map((x) => ({ ...x, clubZh: h.zh })),
      ...(g.away_injuries || []).map((x) => ({ ...x, clubZh: a.zh })),
    ].filter((x) => x.minutes >= 90 || x.play_prob <= 50).slice(0, 6);

    const injHtml = allInj.length
      ? `<div class="inj-strip">
          <strong style="color:#475569;font-size:11.5px">🏥 官方 FPL 傷停雷達：</strong>
          ${allInj.map((it) => {
            const cls = it.play_prob === 0 ? '' : it.play_prob <= 50 ? 'gtd' : 'prob';
            return `<span class="inj-pill ${cls} pl-link" data-player-id="${EPL.esc(it.fpl_id)}" title="${EPL.esc(it.news)}">
              ${EPL.esc(it.clubZh)}·${EPL.esc(it.name)} (${it.play_prob}% 上場)
            </span>`;
          }).join('')}
        </div>`
      : `<div class="inj-strip" style="color:#059669;font-size:12px">✅ 雙方先發主力目前無重大傷停禁賽報告</div>`;

    const ph = Number(p.prob_home_pct || 42);
    const pd = Number(p.prob_draw_pct || 26);
    const pa = Number(p.prob_away_pct || 32);
    const drawWarn = pd >= 27.5 && Math.abs(Number(spH || 0)) === 0.5;

    return `
      <article class="game-card ${hasStrong ? 'has-strong' : ''}">
        <div class="gc-top">
          <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            <span class="chip muted">GW${g.gameweek}</span>
            <span>🕒 台灣 ${EPL.esc(g.kickoff_tw)}</span>
            ${g.venue ? `<span>🏟️ ${EPL.esc(g.venue)}</span>` : ''}
          </div>
          <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap">
            ${drawWarn ? '<span class="chip warn" title="泊松和局率 ≥ 27.5%，買 -0.5 上盤遇和局即全輸，受讓 +0.5 享勝/和雙贏保護">🛡️ 和局警戒 (' + pd.toFixed(0) + '%)</span>' : ''}
            ${g.status === 'FINAL' ? '<span class="chip ok">已完賽 FT</span>' : '<span class="chip info">🔄 18:00 初盤／23:00 定盤</span>'}
          </div>
        </div>

        <!-- Soccer Convention: HOME (Left) vs AWAY (Right) -->
        <div class="gc-teams">
          <div class="tm-side home tm-link" data-team-link="${EPL.esc(g.home_abbr)}">
            <img loading="lazy" decoding="async" class="tm-logo" src="${EPL.esc(h.logo)}" alt="${EPL.esc(h.zh)}">
            <div style="min-width:0">
              <div class="tm-name">主 · ${EPL.esc(h.zh)}</div>
              <div class="tm-meta"><span>${EPL.esc(g.home_record || '')}</span></div>
            </div>
          </div>

          <div class="vs-center">
            ${g.status === 'FINAL' && g.home_score != null
              ? `<div class="score-big">${g.home_score} : ${g.away_score}</div>
                 <div style="font-size:11px;color:#64748b">半場 (${g.ht_home ?? 0}:${g.ht_away ?? 0})</div>`
              : `<div class="vs-tag">λ ${Number(p.lambda_home || 1.4).toFixed(2)} : ${Number(p.lambda_away || 1.2).toFixed(2)}</div>
                 <div style="font-size:10.5px;color:#64748b;margin-top:2px">泊松期望進球</div>`}
          </div>

          <div class="tm-side away tm-link" data-team-link="${EPL.esc(g.away_abbr)}">
            <img loading="lazy" decoding="async" class="tm-logo" src="${EPL.esc(a.logo)}" alt="${EPL.esc(a.zh)}">
            <div style="min-width:0">
              <div class="tm-name">客 · ${EPL.esc(a.zh)}</div>
              <div class="tm-meta"><span>${EPL.esc(g.away_record || '')}</span></div>
            </div>
          </div>
        </div>

        <!-- 1X2 Poisson Probability Bar -->
        <div class="prob-1x2-wrap">
          <div class="prob-1x2-lbls">
            <span style="color:#059669">主勝 ${ph.toFixed(1)}%</span>
            <span style="color:#b45309">和局 ${pd.toFixed(1)}% · 雙進球 BTTS ${Number(p.prob_btts_pct || 55).toFixed(0)}%</span>
            <span style="color:#2563eb">客勝 ${pa.toFixed(1)}%</span>
          </div>
          <div class="prob-1x2-bar">
            <div style="width:${ph}%;background:#10b981"></div>
            <div style="width:${pd}%;background:#fbbf24"></div>
            <div style="width:${pa}%;background:#3b82f6"></div>
          </div>
        </div>

        <!-- 3-Column Odds Strip -->
        <div class="odds-strip">
          <div class="odds-col">
            <div class="odds-lbl">亞洲讓球盤（主隊基準）</div>
            <div class="odds-main">${spH != null ? `主 ${EPL.fmtSpread(spH)} / 客 ${EPL.fmtSpread(spA)}` : '尚未開盤'}</div>
            ${renderSpreadMove(g.open_spread_home, spH, h.zh, a.zh)}
          </div>
          <div class="odds-col">
            <div class="odds-lbl">全場大小球盤 (O/U)</div>
            <div class="odds-main">${g.close_total ? `${g.close_total} 球（模型預估 ${Number(p.pred_total || 2.6).toFixed(2)} 球）` : '尚未開盤'}</div>
            ${renderTotalMove(g.open_total, g.close_total)}
          </div>
          <div class="odds-col">
            <div class="odds-lbl">1X2 主客和十進位賠率</div>
            <div class="odds-main">${g.ml_home_dec ? `主 ${Number(g.ml_home_dec).toFixed(2)} · 和 ${Number(g.ml_draw_dec || 3.4).toFixed(2)} · 客 ${Number(g.ml_away_dec || 3.2).toFixed(2)}` : '待更新'}</div>
            <div class="odds-sub">${p.value_1x2 ? `💎 賠率價值：<strong style="color:#059669">${EPL.esc(p.value_1x2)}</strong>` : '1X2 賠率貼近模型公平值'}</div>
          </div>
        </div>

        <!-- Model Picks -->
        <div class="pick-box">
          <div class="pick-cell tier-${EPL.esc(p.ats_tier || 'PASS')}">
            <div class="pick-hdr">
              <span>⚽ 亞洲讓球模型建議</span>
              <div style="display:flex;gap:4px">${tierBadge(p.ats_tier)} ${resultBadge(p.ats_result)}</div>
            </div>
            <div class="pick-target">${EPL.esc(atsTargetTxt)}</div>
            <div class="pick-edge">
              過盤優勢 Edge：<strong>${EPL.fmtSigned(p.ats_edge, 1)}%</strong> · 公平盤 主 ${EPL.fmtSpread(p.fair_spread_home)}
              ${p.ats_kelly_u > 0 ? ` · 建議 <strong>${p.ats_kelly_u}U</strong>` : ''}
            </div>
          </div>

          <div class="pick-cell tier-${EPL.esc(p.ou_tier || 'PASS')}">
            <div class="pick-hdr">
              <span>🥅 大小球模型建議</span>
              <div style="display:flex;gap:4px">${tierBadge(p.ou_tier)} ${resultBadge(p.ou_graded)}</div>
            </div>
            <div class="pick-target">${EPL.esc(ouTargetTxt)}</div>
            <div class="pick-edge">
              過盤優勢 Edge：<strong>${EPL.fmtSigned(p.ou_edge, 1)}%</strong> · 雙進球率 <strong>${Number(p.prob_btts_pct || 55).toFixed(0)}%</strong>
              ${p.ou_kelly_u > 0 ? ` · 建議 <strong>${p.ou_kelly_u}U</strong>` : ''}
            </div>
          </div>
        </div>

        <div class="rationale-bar">💡 ${EPL.esc(p.rationale_zh || '')}</div>
        ${g.status === 'FINAL' && p.postmortem_zh ? `<div class="rationale-bar" style="border-left-color:#2563eb;background:#eff6ff">🔎 賽後覆盤：${EPL.esc(p.postmortem_zh)}</div>` : ''}
        ${injHtml}

        <details style="font-size:12px;color:#475569">
          <summary style="cursor:pointer;font-weight:700;color:#059669">📐 展開 7 大英超泊松讓球量化因子權重拆解</summary>
          ${renderFactorBars(p.ats_factors, p.ou_factors, h.zh, a.zh)}
        </details>

        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;padding-top:4px;border-top:1px solid #f1f5f9">
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button type="button" class="btn btn-sm" data-boxscore-gid="${EPL.esc(g.game_id)}">📊 單場數據與先發 Boxscore</button>
            ${!EPL.isStatic && EPL.health.ai ? `<button type="button" class="btn btn-soft btn-sm" data-ai-gid="${EPL.esc(g.game_id)}">🤖 AI 戰術深解</button>` : ''}
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button type="button" class="btn btn-sm" data-qbet="${EPL.esc(g.game_id)}" data-mkt="ATS">➕ 記讓球單</button>
            <button type="button" class="btn btn-primary btn-sm" data-qbet="${EPL.esc(g.game_id)}" data-mkt="OU">➕ 記大小球單</button>
          </div>
        </div>
      </article>`;
  }

  EPL.pages.picks = function (root) {
    const snap = EPL.snap || {};
    const meta = snap.meta || {};
    const allGames = snap.games || [];

    // Group gameweeks
    const gwMap = {};
    allGames.forEach((g) => {
      const gw = Number(g.gameweek || 0);
      if (!gw) return;
      if (!gwMap[gw]) gwMap[gw] = { gw, total: 0, final: 0, firstDate: g.tw_date };
      gwMap[gw].total += 1;
      if (g.status === 'FINAL') gwMap[gw].final += 1;
    });
    const gws = Object.values(gwMap).sort((a, b) => a.gw - b.gw);
    const nextGw = Number(meta.next_gameweek || 9);
    const activeGw = Number(EPL.state.picksGw || nextGw);
    const quickGws = gws.filter((x) => Math.abs(x.gw - nextGw) <= 2 || x.gw === activeGw);

    const gwGames = allGames.filter((g) => Number(g.gameweek) === activeGw);
    const f = EPL.state.picksFilter || 'ALL';
    const q = (EPL.state.picksSearch || '').trim().toLowerCase();

    const strongCnt = gwGames.filter((g) => (g.pred || {}).ats_tier === 'STRONG' || (g.pred || {}).ou_tier === 'STRONG').length;
    const atsCnt = gwGames.filter((g) => (g.pred || {}).ats_pick && (g.pred || {}).ats_pick !== 'PASS').length;
    const ouCnt = gwGames.filter((g) => (g.pred || {}).ou_pick && (g.pred || {}).ou_pick !== 'PASS').length;
    const trapCnt = gwGames.filter((g) => {
      const p = g.pred || {};
      return Number(p.prob_draw_pct || 0) >= 27.5 || ((g.home_injuries || []).length + (g.away_injuries || []).length) >= 3;
    }).length;

    const filtered = gwGames.filter((g) => {
      const p = g.pred || {};
      if (f === 'STRONG' && !(p.ats_tier === 'STRONG' || p.ou_tier === 'STRONG')) return false;
      if (f === 'ATS' && (!p.ats_pick || p.ats_pick === 'PASS')) return false;
      if (f === 'OU' && (!p.ou_pick || p.ou_pick === 'PASS')) return false;
      if (f === 'TRAP' && !(Number(p.prob_draw_pct || 0) >= 27.5 || ((g.home_injuries || []).length + (g.away_injuries || []).length) >= 3)) return false;
      if (q) {
        const h = EPL.teamOf(g.home_abbr), a = EPL.teamOf(g.away_abbr);
        const hay = `${h.zh} ${h.en} ${h.abbr} ${a.zh} ${a.en} ${a.abbr} ${g.venue || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const parlayBundle = EPL.buildGwParlayPackages(activeGw, EPL.state.parlayBook || 'INTL');
    const anchor2x1 = (parlayBundle.packages || []).find((x) => x.key === 'anchor_2x1');
    const shield3x4 = (parlayBundle.packages || []).find((x) => x.key === 'shield_3x4');

    root.innerHTML = `
      <div class="sec-hdr">
        <div>
          <h1 class="sec-title">🎯 2026-27 英超第 ${activeGw} 輪（GW${activeGw}）泊松盤口分析與下注建議</h1>
          <div class="sec-sub">結合 Dixon-Coles 雙變數泊松進球分布、官方 FPL 球員 xG／傷停機率與「-0.5 和局防雷護盾」 · 最後更新：${EPL.esc(meta.updated_at || '')}</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <input class="inp" id="picksSearchInp" value="${EPL.esc(EPL.state.picksSearch || '')}" placeholder="🔍 搜尋俱樂部（如：兵工廠、曼城、利物浦）…" style="min-width:230px">
        </div>
      </div>

      <div class="odds-rule-bar">
        <div>
          <strong>🔄 每日雙階段抓盤與變盤重析規範：</strong>系統於<strong>每天晚上 6 點（18:00 初盤）</strong>先抓一次讓球與大小球盤並完成第一輪泊松解盤（週六早場開踢前即鎖定賽前盤口）；<strong>晚上 11 點（23:00 尾盤定盤）</strong>再抓最後一次未開踢賽事盤口，結合 5 小時升退盤資金變化重新推演並鎖定對獎基準。
        </div>
        <span class="odds-rule-pill">🕕 18:00 初盤首析 · 🕚 23:00 變盤定盤</span>
      </div>

      <div class="inline-disc-bar">
        <span>⚖️ <strong>免責聲明：</strong>本站盤口與泊松量化模型純供個人足球數據研究參考，不構成任何投注建議或獲利保證；使用者應獨立判斷，<strong>任何投注損益與失敗風險概由個人完全自負，與本站及開發者無關</strong>。</span>
        <button type="button" class="inline-disc-link" data-open-disclaimer="1">查看完整免責條款 →</button>
      </div>

      <div class="date-bar">
        <span style="font-size:12.5px;font-weight:700;color:#475569">⚽ 英超輪次 (Gameweek)：</span>
        ${quickGws.map((x) => `
          <button type="button" class="date-pill ${x.gw === activeGw ? 'active' : ''}" data-gw="${x.gw}">
            <span>GW${x.gw} ${x.gw === nextGw ? '本輪焦點' : x.final === x.total ? '已完賽' : '預告'}</span>
            <span class="cnt">${x.total}場</span>
          </button>
        `).join('')}
        <select class="inp" id="picksGwSel" style="margin-left:auto;padding:5px 9px;font-size:12.5px">
          ${gws.map((x) => `<option value="${x.gw}" ${x.gw === activeGw ? 'selected' : ''}>第 ${x.gw} 輪 GW${x.gw}（${EPL.esc(x.firstDate)} 起 · ${x.total} 場 / 完賽 ${x.final}）</option>`).join('')}
        </select>
      </div>

      <div class="kpi-grid">
        <button type="button" class="kpi-card ${f === 'ALL' ? 'active' : ''}" data-pf="ALL">
          <div class="kpi-lbl"><span>本輪總場次</span><span>點擊顯示全部</span></div>
          <div class="kpi-val">${gwGames.length} 場</div>
          <div class="kpi-sub">英超第 ${activeGw} 輪完整對戰</div>
        </button>
        <button type="button" class="kpi-card ${f === 'STRONG' ? 'active' : ''}" data-pf="STRONG">
          <div class="kpi-lbl"><span>🔥 強推精選 (STRONG)</span><span class="chip strong">首選</span></div>
          <div class="kpi-val">${strongCnt} 場</div>
          <div class="kpi-sub">本季強推勝率 ${(snap.kpi || {}).strong_win_rate || 0}% (損益線 52.38%)</div>
        </button>
        <button type="button" class="kpi-card ${f === 'ATS' ? 'active' : ''}" data-pf="ATS">
          <div class="kpi-lbl"><span>✅ 亞洲讓球推薦</span><span>Spread</span></div>
          <div class="kpi-val">${atsCnt} 場</div>
          <div class="kpi-sub">本季讓球勝率 ${(snap.kpi || {}).ats_win_rate || 0}%</div>
        </button>
        <button type="button" class="kpi-card ${f === 'OU' ? 'active' : ''}" data-pf="OU">
          <div class="kpi-lbl"><span>🥅 大小球推薦</span><span>Over/Under</span></div>
          <div class="kpi-val">${ouCnt} 場</div>
          <div class="kpi-sub">本季大小球勝率 ${(snap.kpi || {}).ou_win_rate || 0}%</div>
        </button>
        <button type="button" class="kpi-card ${f === 'TRAP' ? 'active' : ''}" data-pf="TRAP">
          <div class="kpi-lbl"><span>🛡️ 和局陷阱／傷停警戒</span><span>Draw ≥27.5%</span></div>
          <div class="kpi-val">${trapCnt} 場</div>
          <div class="kpi-sub">防範強隊 -0.5 平局輸盤與主力缺陣</div>
        </button>
      </div>

      ${anchor2x1
        ? `<div class="parlay-quick-banner">
            <div>
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <strong style="font-size:14px;color:#065f46">🎰 GW${activeGw} 英超跨場串關首選（2串1 雙星主推 · 國際 ${anchor2x1.intl_odds}x / 台彩 ${anchor2x1.tw_odds}x）</strong>
                <span class="chip ${EPL.esc(anchor2x1.grade_cls)}">${EPL.esc(anchor2x1.grade_zh)}</span>
                ${anchor2x1.status === 'WIN' ? '<span class="chip ok">🎉 已過關中獎</span>' : anchor2x1.status === 'LOSS' ? '<span class="chip bad">❌ 未過</span>' : ''}
              </div>
              <div class="pq-legs-wrap">
                ${anchor2x1.legs.map((lg, idx) => `<span class="pq-leg-chip">#${idx + 1} ${EPL.esc(lg.pick_label_zh)} (Edge ${EPL.fmtSigned(lg.edge, 1)}%)</span>`).join('<span style="font-weight:800;color:#059669">＋</span>')}
                ${shield3x4 ? `<span style="font-size:12px;color:#475569;margin-left:4px">（另有防補時絕殺「3串4 複式容錯」至少過 2 關機率 ${shield3x4.at_least_2_prob_pct}%）</span>` : ''}
              </div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <button type="button" class="btn btn-sm" id="quickAdd2x1Btn">➕ 記此 2串1 注單</button>
              <a href="#/parlay" class="btn btn-primary btn-sm" id="jumpParlayBtn">🎰 查看完整串關與 3串4 試算 →</a>
            </div>
          </div>`
        : ''}

      ${filtered.length
        ? `<div class="games-grid">${filtered.map(renderGameCard).join('')}</div>`
        : `<div class="empty-box">目前篩選條件下沒有符合的英超賽事，請點擊上方「本輪總場次」檢視全部。</div>`}
    `;

    root.querySelectorAll('.date-pill[data-gw]').forEach((btn) => {
      btn.onclick = () => {
        EPL.state.picksGw = Number(btn.getAttribute('data-gw'));
        EPL.state.parlayGw = EPL.state.picksGw;
        EPL.render();
      };
    });
    const gwSel = document.getElementById('picksGwSel');
    if (gwSel) {
      gwSel.onchange = () => {
        EPL.state.picksGw = Number(gwSel.value);
        EPL.state.parlayGw = EPL.state.picksGw;
        EPL.render();
      };
    }
    root.querySelectorAll('.kpi-card[data-pf]').forEach((btn) => {
      btn.onclick = () => {
        EPL.state.picksFilter = btn.getAttribute('data-pf');
        EPL.render();
      };
    });
    root.querySelectorAll('[data-qbet]').forEach((btn) => {
      btn.onclick = () => EPL.openQuickBetModal(btn.getAttribute('data-qbet'), btn.getAttribute('data-mkt'));
    });
    root.querySelectorAll('[data-ai-gid]').forEach((btn) => {
      btn.onclick = () => EPL.openAiGameDive(btn.getAttribute('data-ai-gid'));
    });
    const qAdd2 = document.getElementById('quickAdd2x1Btn');
    if (qAdd2 && anchor2x1) {
      qAdd2.onclick = () => EPL.addParlayBet({
        tw_date: anchor2x1.legs[0].tw_date,
        type: 'DIRECT',
        title: `GW${activeGw} 雙星主推 2 串 1`,
        legs: anchor2x1.legs,
      });
    }
    EPL.bindLiveSearch('picksSearchInp', (v) => { EPL.state.picksSearch = v; });
  };
})();
