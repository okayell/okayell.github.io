#!/usr/bin/env python3
"""SQLite WAL schema & helpers for 英超運彩智庫."""
from __future__ import annotations

import json
import os
import sqlite3
from typing import Any

import config

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS games (
  game_id TEXT PRIMARY KEY,
  gameweek INTEGER DEFAULT 0,
  kickoff_utc TEXT NOT NULL,
  kickoff_tw TEXT NOT NULL,
  tw_date TEXT NOT NULL,
  uk_date TEXT NOT NULL,
  status TEXT NOT NULL,
  venue TEXT DEFAULT '',
  home_abbr TEXT NOT NULL,
  away_abbr TEXT NOT NULL,
  home_record TEXT DEFAULT '',
  away_record TEXT DEFAULT '',
  ht_home INTEGER,
  ht_away INTEGER,
  home_score INTEGER,
  away_score INTEGER,
  total_goals INTEGER,
  open_spread_home REAL,
  close_spread_home REAL,
  spread_odds_home INTEGER,
  spread_odds_away INTEGER,
  open_total REAL,
  close_total REAL,
  over_odds INTEGER,
  under_odds INTEGER,
  ml_home_dec REAL,
  ml_draw_dec REAL,
  ml_away_dec REAL,
  open_ml_home_dec REAL,
  ats_winner TEXT DEFAULT '',
  ou_result TEXT DEFAULT '',
  result_1x2 TEXT DEFAULT '',
  btts_yes INTEGER,
  stats_json TEXT DEFAULT '{}',
  key_events_json TEXT DEFAULT '[]',
  summary_fetched INTEGER DEFAULT 0,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS match_players (
  game_id TEXT NOT NULL,
  player_id TEXT NOT NULL,
  team_abbr TEXT NOT NULL,
  side TEXT NOT NULL,
  name TEXT NOT NULL,
  pos TEXT DEFAULT '',
  jersey TEXT DEFAULT '',
  starter INTEGER DEFAULT 0,
  sub_in INTEGER DEFAULT 0,
  played INTEGER DEFAULT 0,
  goals INTEGER DEFAULT 0,
  assists INTEGER DEFAULT 0,
  shots INTEGER DEFAULT 0,
  sot INTEGER DEFAULT 0,
  saves INTEGER DEFAULT 0,
  fouls INTEGER DEFAULT 0,
  yc INTEGER DEFAULT 0,
  rc INTEGER DEFAULT 0,
  goals_conceded INTEGER DEFAULT 0,
  PRIMARY KEY (game_id, player_id)
);

CREATE TABLE IF NOT EXISTS fpl_players (
  fpl_id INTEGER PRIMARY KEY,
  team_abbr TEXT NOT NULL,
  web_name TEXT NOT NULL,
  full_name TEXT NOT NULL,
  pos TEXT NOT NULL,
  status TEXT NOT NULL,
  news TEXT DEFAULT '',
  play_prob INTEGER DEFAULT 100,
  minutes INTEGER DEFAULT 0,
  goals INTEGER DEFAULT 0,
  assists INTEGER DEFAULT 0,
  xg REAL DEFAULT 0,
  xa REAL DEFAULT 0,
  xgi REAL DEFAULT 0,
  clean_sheets INTEGER DEFAULT 0,
  saves INTEGER DEFAULT 0,
  yc INTEGER DEFAULT 0,
  rc INTEGER DEFAULT 0,
  form REAL DEFAULT 0,
  cost_m REAL DEFAULT 0,
  selected_pct REAL DEFAULT 0,
  photo_url TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS predictions (
  game_id TEXT PRIMARY KEY,
  model_version TEXT NOT NULL,
  lambda_home REAL NOT NULL,
  lambda_away REAL NOT NULL,
  pred_total REAL NOT NULL,
  fair_spread_home REAL NOT NULL,
  prob_home_pct REAL NOT NULL,
  prob_draw_pct REAL NOT NULL,
  prob_away_pct REAL NOT NULL,
  prob_btts_pct REAL NOT NULL,
  ats_pick TEXT NOT NULL,
  ats_lean_side TEXT NOT NULL,
  ats_tier TEXT NOT NULL,
  ats_edge REAL NOT NULL,
  ats_kelly_u REAL DEFAULT 0,
  ou_pick TEXT NOT NULL,
  ou_lean_side TEXT NOT NULL,
  ou_tier TEXT NOT NULL,
  ou_edge REAL NOT NULL,
  ou_kelly_u REAL DEFAULT 0,
  value_1x2 TEXT DEFAULT '',
  ats_factors_json TEXT DEFAULT '{}',
  ou_factors_json TEXT DEFAULT '{}',
  rationale_zh TEXT DEFAULT '',
  ats_result TEXT DEFAULT 'PENDING',
  ou_graded TEXT DEFAULT 'PENDING',
  error_tag TEXT DEFAULT '',
  postmortem_zh TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS news_items (
  news_id TEXT PRIMARY KEY,
  published_tw TEXT NOT NULL,
  source TEXT NOT NULL,
  lang TEXT NOT NULL,
  category TEXT NOT NULL,
  team_abbr TEXT DEFAULT '',
  title TEXT NOT NULL,
  summary TEXT DEFAULT '',
  url TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_bets (
  bet_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  tw_date TEXT NOT NULL,
  game_id TEXT DEFAULT '',
  matchup TEXT NOT NULL,
  market TEXT NOT NULL,
  pick_side TEXT NOT NULL,
  pick_label TEXT NOT NULL,
  line REAL DEFAULT 0,
  odds_decimal REAL NOT NULL,
  stake REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING',
  pnl REAL DEFAULT 0,
  note TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS kv_state (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL,
  updated_at TEXT
);
"""


def connect() -> sqlite3.Connection:
  os.makedirs(config.DATA_DIR, exist_ok=True)
  conn = sqlite3.connect(config.DB_PATH, timeout=30.0)
  conn.row_factory = sqlite3.Row
  conn.execute('PRAGMA journal_mode=WAL;')
  conn.execute('PRAGMA synchronous=NORMAL;')
  conn.executescript(SCHEMA_SQL)
  return conn


def set_state(conn: sqlite3.Connection, key: str, val: Any, updated_at: str = '') -> None:
  conn.execute(
      'INSERT INTO kv_state(k, v, updated_at) VALUES (?,?,?) '
      'ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at',
      (key, json.dumps(val, ensure_ascii=False), updated_at),
  )


def get_state(conn: sqlite3.Connection, key: str, default: Any = None) -> Any:
  row = conn.execute('SELECT v FROM kv_state WHERE k = ?', (key,)).fetchone()
  if not row:
    return default
  try:
    return json.loads(row['v'])
  except ValueError:
    return default
