#!/usr/bin/env python3
"""2026-27 English Premier League 20 Clubs Dictionary, Normalization & Crest Logos."""
from __future__ import annotations

from typing import Any
import urllib.parse


def _crest_svg(abbr: str, bg: str) -> str:
  svg = (
      f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'>"
      f"<path d='M10 8 H54 V34 C54 48 32 58 32 58 C32 58 10 48 10 34 Z' fill='{bg}' stroke='#cbd5e1' stroke-width='2'/>"
      f"<text x='32' y='35' text-anchor='middle' font-family='Arial,sans-serif' font-weight='900' font-size='16' fill='#ffffff'>{abbr}</text></svg>"
  )
  return 'data:image/svg+xml;utf8,' + urllib.parse.quote(svg)


CLUBS: dict[str, dict[str, Any]] = {
    'ARS': {'abbr': 'ARS', 'espn_id': '359', 'fpl_id': 1, 'zh': '兵工廠', 'en': 'Arsenal', 'city_zh': '北倫敦', 'tier': '歐冠爭冠組', 'euro': True, 'color': '#ef0107'},
    'AVL': {'abbr': 'AVL', 'espn_id': '362', 'fpl_id': 2, 'zh': '阿斯頓維拉', 'en': 'Aston Villa', 'city_zh': '伯明罕', 'tier': '歐戰競爭組', 'euro': True, 'color': '#670e36'},
    'BOU': {'abbr': 'BOU', 'espn_id': '349', 'fpl_id': 3, 'zh': '伯恩茅斯', 'en': 'Bournemouth', 'city_zh': '南海岸', 'tier': '中游進取組', 'euro': False, 'color': '#da291c'},
    'BRE': {'abbr': 'BRE', 'espn_id': '337', 'fpl_id': 4, 'zh': '布倫特福德', 'en': 'Brentford', 'city_zh': '西倫敦', 'tier': '中游進取組', 'euro': False, 'color': '#e30613'},
    'BHA': {'abbr': 'BHA', 'espn_id': '331', 'fpl_id': 5, 'zh': '布萊頓', 'en': 'Brighton', 'city_zh': '南海岸', 'tier': '歐戰競爭組', 'euro': False, 'color': '#0057b8'},
    'CHE': {'abbr': 'CHE', 'espn_id': '363', 'fpl_id': 6, 'zh': '切爾西', 'en': 'Chelsea', 'city_zh': '西倫敦', 'tier': '歐冠爭冠組', 'euro': True, 'color': '#034694'},
    'COV': {'abbr': 'COV', 'espn_id': '388', 'fpl_id': 7, 'zh': '考文垂', 'en': 'Coventry City', 'city_zh': '西密德蘭', 'tier': '升班馬保級組', 'euro': False, 'color': '#0299db'},
    'CRY': {'abbr': 'CRY', 'espn_id': '384', 'fpl_id': 8, 'zh': '水晶宮', 'en': 'Crystal Palace', 'city_zh': '南倫敦', 'tier': '中游防守組', 'euro': False, 'color': '#1b458f'},
    'EVE': {'abbr': 'EVE', 'espn_id': '368', 'fpl_id': 9, 'zh': '艾佛頓', 'en': 'Everton', 'city_zh': '默西賽德', 'tier': '中下游組', 'euro': False, 'color': '#003399'},
    'FUL': {'abbr': 'FUL', 'espn_id': '370', 'fpl_id': 10, 'zh': '富勒姆', 'en': 'Fulham', 'city_zh': '西倫敦', 'tier': '中游穩健組', 'euro': False, 'color': '#1e293b'},
    'HUL': {'abbr': 'HUL', 'espn_id': '306', 'fpl_id': 11, 'zh': '赫爾城', 'en': 'Hull City', 'city_zh': '約克郡', 'tier': '升班馬保級組', 'euro': False, 'color': '#f59e0b'},
    'IPS': {'abbr': 'IPS', 'espn_id': '373', 'fpl_id': 12, 'zh': '伊普斯維奇', 'en': 'Ipswich Town', 'city_zh': '東英格蘭', 'tier': '升班馬保級組', 'euro': False, 'color': '#1d4ed8'},
    'LEE': {'abbr': 'LEE', 'espn_id': '357', 'fpl_id': 13, 'zh': '利茲聯', 'en': 'Leeds United', 'city_zh': '約克郡', 'tier': '中下游組', 'euro': False, 'color': '#1d428a'},
    'LIV': {'abbr': 'LIV', 'espn_id': '364', 'fpl_id': 14, 'zh': '利物浦', 'en': 'Liverpool', 'city_zh': '默西賽德', 'tier': '歐冠爭冠組', 'euro': True, 'color': '#c8102e'},
    'MCI': {'abbr': 'MCI', 'espn_id': '382', 'fpl_id': 15, 'zh': '曼城', 'en': 'Manchester City', 'city_zh': '曼徹斯特', 'tier': '歐冠爭冠組', 'euro': True, 'color': '#6cabdd'},
    'MUN': {'abbr': 'MUN', 'espn_id': '360', 'fpl_id': 16, 'zh': '曼聯', 'en': 'Manchester United', 'city_zh': '曼徹斯特', 'tier': '歐戰競爭組', 'euro': True, 'color': '#da291c'},
    'NEW': {'abbr': 'NEW', 'espn_id': '361', 'fpl_id': 17, 'zh': '紐卡索聯', 'en': 'Newcastle United', 'city_zh': '泰恩河畔', 'tier': '歐戰競爭組', 'euro': True, 'color': '#241f20'},
    'NFO': {'abbr': 'NFO', 'espn_id': '393', 'fpl_id': 18, 'zh': '諾丁漢森林', 'en': 'Nottingham Forest', 'city_zh': '東密德蘭', 'tier': '中游反擊組', 'euro': False, 'color': '#dd0000'},
    'TOT': {'abbr': 'TOT', 'espn_id': '367', 'fpl_id': 19, 'zh': '熱刺', 'en': 'Tottenham Hotspur', 'city_zh': '北倫敦', 'tier': '歐戰競爭組', 'euro': True, 'color': '#132257'},
    'SUN': {'abbr': 'SUN', 'espn_id': '366', 'fpl_id': 20, 'zh': '桑德蘭', 'en': 'Sunderland', 'city_zh': '東北英格蘭', 'tier': '中下游組', 'euro': False, 'color': '#eb172b'},
}

ALIASES: dict[str, str] = {
    'MNC': 'MCI', 'MAN': 'MUN', 'SPURS': 'TOT', 'NOT': 'NFO',
}
ESPN_ID_TO_ABBR: dict[str, str] = {v['espn_id']: k for k, v in CLUBS.items()}
FPL_ID_TO_ABBR: dict[int, str] = {v['fpl_id']: k for k, v in CLUBS.items()}


def norm_abbr(raw: str | None, espn_id: str | None = None) -> str:
  if espn_id and str(espn_id) in ESPN_ID_TO_ABBR:
    return ESPN_ID_TO_ABBR[str(espn_id)]
  s = (raw or '').strip().upper()
  if s in CLUBS:
    return s
  if s in ALIASES:
    return ALIASES[s]
  low = (raw or '').strip().lower()
  for k, v in CLUBS.items():
    if low and (low in v['en'].lower() or v['en'].lower() in low):
      return k
  return s[:3] or 'EPL'


def team_info(abbr: str) -> dict[str, Any]:
  ab = norm_abbr(abbr)
  base = dict(CLUBS.get(ab) or {
      'abbr': ab, 'espn_id': '', 'fpl_id': 0, 'zh': ab, 'en': ab,
      'city_zh': '英格蘭', 'tier': '英超俱樂部', 'euro': False, 'color': '#334155',
  })
  if base.get('espn_id'):
    base['logo'] = f"https://a.espncdn.com/i/teamlogos/soccer/500/{base['espn_id']}.png"
  else:
    base['logo'] = _crest_svg(ab, base['color'])
  base['fallback_logo'] = _crest_svg(ab, base['color'])
  return base
