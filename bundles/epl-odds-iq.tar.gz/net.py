#!/usr/bin/env python3
"""Polite rate-limited HTTP client with gzip & exponential backoff."""
from __future__ import annotations

import gzip
import json
import threading
import time
from typing import Any
import urllib.error
import urllib.request

_HOST_LOCK = threading.Lock()
_LAST_REQ_TS: dict[str, float] = {}
USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 EPLBettingStudio/1.0'


def fetch_bytes(url: str, timeout: float = 16.0, min_interval: float = 0.12, retries: int = 3) -> bytes:
  host = urllib.request.urlparse(url).netloc
  with _HOST_LOCK:
    now = time.time()
    wait = min_interval - (now - _LAST_REQ_TS.get(host, 0.0))
    if wait > 0:
      time.sleep(wait)
    _LAST_REQ_TS[host] = time.time()

  last_err: Exception | None = None
  for attempt in range(retries):
    req = urllib.request.Request(
        url,
        headers={
            'User-Agent': USER_AGENT,
            'Accept': 'application/json, application/xml, text/xml, */*',
            'Accept-Encoding': 'gzip',
        },
    )
    try:
      with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        if (resp.headers.get('Content-Encoding') or '').lower() == 'gzip' or raw[:2] == b'\x1f\x8b':
          try:
            raw = gzip.decompress(raw)
          except OSError:
            pass
        return raw
    except (urllib.error.URLError, TimeoutError, OSError) as e:
      last_err = e
      if attempt + 1 < retries:
        time.sleep(0.5 * (2 ** attempt))
  raise RuntimeError(f'HTTP fetch failed for {url}: {last_err}')


def fetch_json(url: str, timeout: float = 16.0, min_interval: float = 0.12) -> Any:
  raw = fetch_bytes(url, timeout=timeout, min_interval=min_interval)
  return json.loads(raw.decode('utf-8', errors='replace'))


def fetch_text(url: str, timeout: float = 16.0, min_interval: float = 0.12) -> str:
  return fetch_bytes(url, timeout=timeout, min_interval=min_interval).decode('utf-8', errors='replace')
