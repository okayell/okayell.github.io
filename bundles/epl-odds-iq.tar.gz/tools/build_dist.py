#!/usr/bin/env python3
"""Builds standalone single-file HTML (`index.html`) for GitHub Pages / offline sharing (英超運彩智庫)."""
from __future__ import annotations

import base64
import json
import os
import re
import sys

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

import config  # pylint: disable=wrong-import-position
import release_mgr  # pylint: disable=wrong-import-position
import snapshot  # pylint: disable=wrong-import-position

OUT_HTML = os.path.join(config.DIST_DIR, 'epl_betting_single.html')
FORBIDDEN_TOKENS = tuple(
    base64.b64decode(b).decode()
    for b in (
        b'Z29vZ2xlcnMuY29t',
        b'Y29ycC5nb29nbGUuY29t',
        b'Z29vZ2xlcGxleA==',
        b'aHVhbmd5aWNoYW8=',
        b'L2dvb2dsZS9zcmMv',
        b'QGdvb2dsZS5jb20=',
    )
)


def _escape_script(js_code: str) -> str:
  return js_code.replace('</script>', '<\\/script>')


def is_stale() -> bool:
  if not os.path.isfile(OUT_HTML):
    return True
  out_m = os.path.getmtime(OUT_HTML)
  watch = [config.SNAPSHOT_JSON, release_mgr.RELEASES_JSON]
  for rel in release_mgr.tracked_paths():
    if rel.startswith('static/'):
      watch.append(os.path.join(ROOT_DIR, rel))
  for fp in watch:
    if os.path.isfile(fp) and os.path.getmtime(fp) > out_m:
      return True
  return False


def build_all() -> str:
  os.makedirs(config.DIST_DIR, exist_ok=True)
  release_mgr.write_releases_js()
  snap = snapshot.load_cached_snapshot()

  index_fp = os.path.join(config.STATIC_DIR, 'index.html')
  css_fp = os.path.join(config.STATIC_DIR, 'app.css')
  with open(index_fp, encoding='utf-8') as f:
    html = f.read()
  with open(css_fp, encoding='utf-8') as f:
    css = f.read()

  html = re.sub(
      r'<link[^>]+href="[^"]*app\.css[^"]*"[^>]*>',
      lambda _: f'<style>\n{css}\n</style>',
      html,
      count=1,
  )

  script_tags = list(re.finditer(r'<script[^>]+src="([^"]+)"[^>]*></script>', html))
  # The snapshot ships as inert JSON (parsed once by app.js); '<' only occurs inside JSON strings, so
  # escaping it keeps any '</script>' / '<!--' sequence from terminating the data block.
  snap_json = json.dumps(snap, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
  inlined_parts = [
      '<script>window.EPL_STATIC_ONLY = true;</script>',
      '<script id="staticSnapshot" type="application/json">' + snap_json + '</script>',
  ]
  for m in script_tags:
    src = m.group(1).split('?', 1)[0].lstrip('/')
    js_fp = os.path.join(config.STATIC_DIR, src.removeprefix('static/'))
    if not os.path.isfile(js_fp):
      js_fp = os.path.join(ROOT_DIR, src)
    if os.path.isfile(js_fp):
      with open(js_fp, encoding='utf-8') as jf:
        inlined_parts.append('<script>\n' + _escape_script(jf.read()) + '\n</script>')

  if script_tags:
    first_start = script_tags[0].start()
    last_end = script_tags[-1].end()
    html = html[:first_start] + '\n'.join(inlined_parts) + html[last_end:]

  low = html.lower()
  for tok in FORBIDDEN_TOKENS:
    if tok.lower() in low:
      raise RuntimeError(f'Public HTML leak guard triggered on token: {tok}')

  tmp = OUT_HTML + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    f.write(html)
  os.replace(tmp, OUT_HTML)
  return OUT_HTML


if __name__ == '__main__':
  p = build_all()
  print(f'Built {p} ({os.path.getsize(p):,} bytes)')
