#!/usr/bin/env python3
"""Global configuration for 英超運彩智庫 (Premier League Football Betting Analytics & Self-Evolving Studio)."""
from __future__ import annotations

import datetime as dt
import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')

DB_PATH = os.path.join(DATA_DIR, 'epl_betting.sqlite3')
SNAPSHOT_JSON = os.path.join(DATA_DIR, 'snapshot.json')
SYNC_LOCK = os.path.join(DATA_DIR, 'sync.lock')

SERVICE_SLUG = 'epl-betting'
TOOL_TITLE = '英超戰情室'
BACKEND_PORT = 8916
PROXY_PORT = 8917

SEASON_LABEL = '2026-27'
SEASON_START_DATE = dt.date(2026, 8, 14)

TZ_TW = dt.timezone(dt.timedelta(hours=8))
TZ_UK = dt.timezone.utc
TZ_UTC = dt.timezone.utc

DEFAULT_AMERICAN_ODDS = -110
DEFAULT_DECIMAL_ODDS = 1.91
BREAKEVEN_WIN_RATE = 52.38
TAIWAN_LOTTERY_DECIMAL_ODDS = 1.75

EARLY_ODDS_CAPTURE_TW_TIME = '18:00'
ODDS_CAPTURE_TW_TIME = '23:00'
ODDS_CAPTURE_SLOTS_TW = (EARLY_ODDS_CAPTURE_TW_TIME, ODDS_CAPTURE_TW_TIME)
SCHEDULE_TW_TIMES = ('07:30', '12:30', '18:00', '23:00')
