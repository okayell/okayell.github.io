#!/usr/bin/env python3
"""Compiles <2ms cached JSON snapshot for 英超運彩智庫 SPA & static GitHub Pages export."""
from __future__ import annotations

import datetime as dt
import json
import os
import sqlite3
from typing import Any

import config
import db
import teams


def _streak(seq: list[str], target: str) -> int:
  n = 0
  for x in reversed(seq):
    if x == target:
      n += 1
    else:
      break
  return n


def build_and_save_snapshot(conn: sqlite3.Connection) -> dict[str, Any]:
  now_tw = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S')
  evo = db.get_state(conn, 'evolution_summary') or {}
  ai_coach = db.get_state(conn, 'latest_ai_coach') or None

  game_rows = [dict(r) for r in conn.execute('SELECT * FROM games ORDER BY kickoff_utc ASC, game_id ASC').fetchall()]
  pred_map = {
      r['game_id']: dict(r)
      for r in conn.execute('SELECT * FROM predictions').fetchall()
  }
  fpl_rows = [dict(r) for r in conn.execute('SELECT * FROM fpl_players ORDER BY xgi DESC, minutes DESC').fetchall()]
  mp_rows = [dict(r) for r in conn.execute('SELECT * FROM match_players ORDER BY starter DESC, goals DESC, shots DESC').fetchall()]

  # Group injuries by club
  inj_by_club: dict[str, list[dict[str, Any]]] = {}
  all_injuries: list[dict[str, Any]] = []
  for fp in fpl_rows:
    if fp['status'] != 'a' or (fp['play_prob'] is not None and int(fp['play_prob']) < 100):
      st_lbl = {
          'i': '傷缺 Out', 's': '禁賽 Suspended', 'd': '出賽存疑 Doubtful', 'u': '離隊/未註冊', 'n': '無法出賽',
      }.get(fp['status'], '觀察中')
      if fp['status'] == 'u':
        continue
      item = {
          'fpl_id': fp['fpl_id'],
          'team': fp['team_abbr'],
          'name': fp['web_name'],
          'full_name': fp['full_name'],
          'pos': fp['pos'],
          'status': fp['status'],
          'status_zh': st_lbl,
          'play_prob': int(fp['play_prob'] if fp['play_prob'] is not None else 50),
          'news': fp['news'] or st_lbl,
          'minutes': fp['minutes'],
          'goals': fp['goals'],
          'assists': fp['assists'],
          'xgi': fp['xgi'],
          'impact_goals': round(min(0.35, float(fp['xgi'] or 0) * 0.04 + (0.06 if fp['minutes'] >= 450 else 0.01)), 2),
          'photo': fp['photo_url'],
      }
      inj_by_club.setdefault(fp['team_abbr'], []).append(item)
      all_injuries.append(item)

  # Group per-match player boxscores
  # row cols: [0:pid, 1:name, 2:pos, 3:jersey, 4:starter, 5:sub_in, 6:played, 7:goals, 8:assists, 9:shots, 10:sot, 11:saves, 12:fouls, 13:yc, 14:rc]
  game_boxscores: dict[str, dict[str, list[list[Any]]]] = {}
  for mp in mp_rows:
    if not mp['played']:
      continue
    gid = mp['game_id']
    side = mp['side'] if mp['side'] in ('home', 'away') else 'home'
    gb = game_boxscores.setdefault(gid, {'away': [], 'home': []})
    gb[side].append([
        mp['player_id'], mp['name'], mp['pos'], mp['jersey'],
        int(mp['starter']), int(mp['sub_in']), int(mp['played']),
        int(mp['goals']), int(mp['assists']), int(mp['shots']), int(mp['sot']),
        int(mp['saves']), int(mp['fouls']), int(mp['yc']), int(mp['rc']),
    ])

  # Aggregate Club League Table & Betting Stats
  club_agg: dict[str, dict[str, Any]] = {}
  for ab in teams.CLUBS:
    club_agg[ab] = {
        **teams.team_info(ab),
        'gp': 0, 'w': 0, 'd': 0, 'l': 0, 'gf': 0, 'ga': 0, 'gd': 0, 'pts': 0,
        'cs': 0, 'btts': 0, 'ats_w': 0, 'ats_l': 0, 'ats_p': 0, 'ou_o': 0, 'ou_u': 0,
        'ats_seq': [], 'ou_seq': [], 'su_seq': [],
    }

  games_out = []
  upcoming_dates: list[str] = []
  for g in game_rows:
    gid = g['game_id']
    pr = pred_map.get(gid) or {}
    h_ab, a_ab = g['home_abbr'], g['away_abbr']

    if g['status'] != 'FINAL' and g['tw_date'] not in upcoming_dates:
      upcoming_dates.append(g['tw_date'])

    if g['status'] == 'FINAL' and g['home_score'] is not None and g['away_score'] is not None:
      hs, as_ = int(g['home_score']), int(g['away_score'])
      for ab, my_g, opp_g, side in ((h_ab, hs, as_, 'HOME'), (a_ab, as_, hs, 'AWAY')):
        if ab not in club_agg:
          continue
        ca = club_agg[ab]
        ca['gp'] += 1
        ca['gf'] += my_g
        ca['ga'] += opp_g
        ca['gd'] = ca['gf'] - ca['ga']
        if opp_g == 0:
          ca['cs'] += 1
        if my_g > 0 and opp_g > 0:
          ca['btts'] += 1
        if my_g > opp_g:
          ca['w'] += 1
          ca['pts'] += 3
          ca['su_seq'].append('W')
        elif my_g == opp_g:
          ca['d'] += 1
          ca['pts'] += 1
          ca['su_seq'].append('D')
        else:
          ca['l'] += 1
          ca['su_seq'].append('L')

        if g['ats_winner'] == side:
          ca['ats_w'] += 1
          ca['ats_seq'].append('W')
        elif g['ats_winner'] == 'PUSH':
          ca['ats_p'] += 1
          ca['ats_seq'].append('P')
        elif g['ats_winner']:
          ca['ats_l'] += 1
          ca['ats_seq'].append('L')

        if g['ou_result'] == 'OVER':
          ca['ou_o'] += 1
          ca['ou_seq'].append('O')
        elif g['ou_result'] == 'UNDER':
          ca['ou_u'] += 1
          ca['ou_seq'].append('U')

    games_out.append({
        'game_id': gid,
        'gameweek': g['gameweek'],
        'kickoff_tw': g['kickoff_tw'],
        'tw_date': g['tw_date'],
        'uk_date': g['uk_date'],
        'status': g['status'],
        'venue': g['venue'],
        'home_abbr': h_ab,
        'away_abbr': a_ab,
        'ht_home': g['ht_home'],
        'ht_away': g['ht_away'],
        'home_score': g['home_score'],
        'away_score': g['away_score'],
        'total_goals': g['total_goals'],
        'open_spread_home': g['open_spread_home'],
        'close_spread_home': g['close_spread_home'],
        'open_total': g['open_total'],
        'close_total': g['close_total'],
        'ml_home_dec': g['ml_home_dec'],
        'ml_draw_dec': g['ml_draw_dec'],
        'ml_away_dec': g['ml_away_dec'],
        'ats_winner': g['ats_winner'],
        'ou_result': g['ou_result'],
        'result_1x2': g['result_1x2'],
        'btts_yes': g['btts_yes'],
        'team_stats': json.loads(g['stats_json'] or '{}'),
        'key_events': json.loads(g['key_events_json'] or '[]'),
        'home_injuries': (inj_by_club.get(h_ab) or [])[:5],
        'away_injuries': (inj_by_club.get(a_ab) or [])[:5],
        'pred': {
            'lambda_home': pr.get('lambda_home', 1.4),
            'lambda_away': pr.get('lambda_away', 1.2),
            'pred_total': pr.get('pred_total', 2.6),
            'fair_spread_home': pr.get('fair_spread_home', -0.2),
            'prob_home_pct': pr.get('prob_home_pct', 42.0),
            'prob_draw_pct': pr.get('prob_draw_pct', 26.0),
            'prob_away_pct': pr.get('prob_away_pct', 32.0),
            'prob_btts_pct': pr.get('prob_btts_pct', 55.0),
            'ats_pick': pr.get('ats_pick', 'PASS'),
            'ats_lean_side': pr.get('ats_lean_side', 'HOME'),
            'ats_tier': pr.get('ats_tier', 'PASS'),
            'ats_edge': pr.get('ats_edge', 0.0),
            'ats_kelly_u': pr.get('ats_kelly_u', 0.0),
            'ou_pick': pr.get('ou_pick', 'PASS'),
            'ou_lean_side': pr.get('ou_lean_side', 'OVER'),
            'ou_tier': pr.get('ou_tier', 'PASS'),
            'ou_edge': pr.get('ou_edge', 0.0),
            'ou_kelly_u': pr.get('ou_kelly_u', 0.0),
            'value_1x2': pr.get('value_1x2', ''),
            'ats_factors': json.loads(pr.get('ats_factors_json') or '{}'),
            'ou_factors': json.loads(pr.get('ou_factors_json') or '{}'),
            'rationale_zh': pr.get('rationale_zh', ''),
            'ats_result': pr.get('ats_result', 'PENDING'),
            'ou_graded': pr.get('ou_graded', 'PENDING'),
            'error_tag': pr.get('error_tag', ''),
            'postmortem_zh': pr.get('postmortem_zh', ''),
        },
    })

  # Finalize 20-club table sorted by League Points, GD, GF
  teams_out = []
  for ab, ca in club_agg.items():
    gp = max(1, ca['gp'])
    ats_dec = [x for x in ca['ats_seq'] if x in ('W', 'L')]
    ou_dec = [x for x in ca['ou_seq'] if x in ('O', 'U')]
    teams_out.append({
        **{k: v for k, v in ca.items() if not k.endswith('_seq')},
        'record': f"{ca['w']}勝-{ca['d']}和-{ca['l']}敗",
        'gf_pg': round(ca['gf'] / gp, 2),
        'ga_pg': round(ca['ga'] / gp, 2),
        'cs_pct': round(ca['cs'] / gp * 100, 1),
        'btts_pct': round(ca['btts'] / gp * 100, 1),
        'ats_pct': round(ca['ats_w'] / max(1, ca['ats_w'] + ca['ats_l']) * 100, 1),
        'over_pct': round(ca['ou_o'] / max(1, ca['ou_o'] + ca['ou_u']) * 100, 1),
        'ats_win_streak': _streak(ats_dec, 'W'),
        'ats_loss_streak': _streak(ats_dec, 'L'),
        'over_streak': _streak(ou_dec, 'O'),
        'under_streak': _streak(ou_dec, 'U'),
        'unbeaten_streak': _streak(['U' if x in ('W', 'D') else 'L' for x in ca['su_seq']], 'U'),
        'last10_ats': ca['ats_seq'][-10:],
        'last10_ou': ca['ou_seq'][-10:],
        'last10_su': ca['su_seq'][-10:],
    })
  teams_out.sort(key=lambda x: (-x['pts'], -x['gd'], -x['gf'], x['abbr']))
  for idx, t in enumerate(teams_out, 1):
    t['rank'] = idx

  # Backfill records onto games_out
  rec_lookup = {t['abbr']: f"{t['pts']}分 (P{t['rank']})" for t in teams_out}
  for gm in games_out:
    gm['home_record'] = rec_lookup.get(gm['home_abbr'], gm.get('home_record') or '')
    gm['away_record'] = rec_lookup.get(gm['away_abbr'], gm.get('away_record') or '')

  # Player stats table from FPL (rich xG, xA, goals, assists, minutes, CS, saves, form!)
  player_stats = []
  for fp in fpl_rows:
    if int(fp['minutes'] or 0) <= 0 and float(fp['xgi'] or 0) <= 0:
      continue
    m90 = max(0.5, float(fp['minutes']) / 90.0)
    player_stats.append({
        'pid': str(fp['fpl_id']),
        'name': fp['web_name'],
        'full_name': fp['full_name'],
        'team': fp['team_abbr'],
        'pos': fp['pos'],
        'minutes': fp['minutes'],
        'nineties': round(float(fp['minutes']) / 90.0, 1),
        'goals': fp['goals'],
        'assists': fp['assists'],
        'ga_sum': fp['goals'] + fp['assists'],
        'xg': fp['xg'],
        'xa': fp['xa'],
        'xgi': fp['xgi'],
        'xgi_per90': round(float(fp['xgi']) / m90, 2),
        'cs': fp['clean_sheets'],
        'saves': fp['saves'],
        'yc': fp['yc'],
        'rc': fp['rc'],
        'form': fp['form'],
        'cost_m': fp['cost_m'],
        'selected_pct': fp['selected_pct'],
        'status': fp['status'],
        'news': fp['news'],
        'headshot': fp['photo_url'],
    })

  news = [dict(r) for r in conn.execute('SELECT * FROM news_items ORDER BY published_tw DESC LIMIT 60').fetchall()]

  default_date = upcoming_dates[0] if upcoming_dates else (games_out[-1]['tw_date'] if games_out else '')
  next_gw = next((g['gameweek'] for g in games_out if g['status'] != 'FINAL' and g['gameweek']), 10)

  snap = {
      'meta': {
          'tool': config.TOOL_TITLE,
          'season': config.SEASON_LABEL,
          'updated_at': now_tw,
          'model_version': evo.get('model_version') or 'v2.9',
          'default_picks_date': default_date,
          'next_gameweek': next_gw,
          'completed_games': sum(1 for g in games_out if g['status'] == 'FINAL'),
      },
      'kpi': {
          'strong_w': evo.get('strong_w', 0),
          'strong_l': evo.get('strong_l', 0),
          'strong_win_rate': evo.get('strong_win_rate', 0.0),
          'all_w': evo.get('all_w', 0),
          'all_l': evo.get('all_l', 0),
          'all_win_rate': evo.get('all_win_rate', 0.0),
          'ats_w': evo.get('ats_w', 0),
          'ats_l': evo.get('ats_l', 0),
          'ats_win_rate': evo.get('ats_win_rate', 0.0),
          'ou_w': evo.get('ou_w', 0),
          'ou_l': evo.get('ou_l', 0),
          'ou_win_rate': evo.get('ou_win_rate', 0.0),
          'baseline_win_rate': evo.get('baseline_win_rate', 0.0),
          'roi_pct': evo.get('roi_pct', 0.0),
          'breakeven_pct': config.BREAKEVEN_WIN_RATE,
      },
      'games': games_out,
      'game_boxscores': game_boxscores,
      'teams': teams_out,
      'player_stats': player_stats,
      'injuries': all_injuries,
      'news': news,
      'evolution': {
          'ats_factors': evo.get('ats_factors') or [],
          'ou_factors': evo.get('ou_factors') or [],
          'error_breakdown': evo.get('error_breakdown') or [],
          'curve': evo.get('curve') or [],
          'daily_log': evo.get('daily_log') or [],
      },
      'ai_coach': ai_coach,
  }

  os.makedirs(config.DATA_DIR, exist_ok=True)
  tmp = config.SNAPSHOT_JSON + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(snap, f, ensure_ascii=False, separators=(',', ':'))
  os.replace(tmp, config.SNAPSHOT_JSON)
  return snap


def load_cached_snapshot() -> dict[str, Any]:
  if os.path.isfile(config.SNAPSHOT_JSON):
    try:
      with open(config.SNAPSHOT_JSON, encoding='utf-8') as f:
        return json.load(f)
    except (OSError, ValueError):
      pass
  conn = db.connect()
  try:
    return build_and_save_snapshot(conn)
  finally:
    conn.close()
