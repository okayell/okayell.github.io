#!/usr/bin/env python3
"""Flock-guarded Data Sync, Walk-Forward Evolution & Snapshot Builder for 英超運彩智庫."""
from __future__ import annotations

import datetime as dt
import fcntl
import os
import threading
from typing import Any

import config
import db
import model_engine
import snapshot
from sources import epl_data
from sources import epl_news

_STATE_LOCK = threading.Lock()
_SYNC_STATE: dict[str, Any] = {
    'running': False,
    'step': 'idle',
    'last_sync_tw': '',
    'error': '',
}


def get_sync_state() -> dict[str, Any]:
  with _STATE_LOCK:
    return dict(_SYNC_STATE)


def _set_sync(**kw: Any) -> None:
  with _STATE_LOCK:
    _SYNC_STATE.update(kw)


def evening_cycle_date(now_tw: dt.datetime) -> str:
  return (now_tw - dt.timedelta(hours=5)).strftime('%Y-%m-%d')


def is_early_odds_captured(conn, tw_date: str) -> bool:
  return bool(db.get_state(conn, f'odds_early_{tw_date}', False))


def is_daily_odds_captured(conn, tw_date: str) -> bool:
  return bool(db.get_state(conn, f'odds_lock_{tw_date}', False))


def sync_all(full_backfill: bool = False, update_odds: bool = True, odds_stage: str = 'auto') -> dict[str, Any]:
  os.makedirs(config.DATA_DIR, exist_ok=True)
  lock_fd = open(config.SYNC_LOCK, 'w', encoding='utf-8')
  try:
    try:
      fcntl.flock(lock_fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
      return get_sync_state()

    _set_sync(running=True, step='同步 2026-27 英超賽程、盤口、Boxscore 與官方 FPL xG／傷停…', error='')
    conn = db.connect()
    try:
      now_tw = dt.datetime.now(config.TZ_TW)
      today_s = now_tw.strftime('%Y-%m-%d')
      cycle_s = evening_cycle_date(now_tw)
      hm = now_tw.strftime('%H:%M')
      is_1800_catchup = (config.EARLY_ODDS_CAPTURE_TW_TIME <= hm < '22:30') and not is_early_odds_captured(conn, today_s)
      is_2300_catchup = (hm >= config.ODDS_CAPTURE_TW_TIME or hm < '05:00') and not is_daily_odds_captured(conn, cycle_s)
      eff_update_odds = bool(update_odds or full_backfill or is_1800_catchup or is_2300_catchup)
      eff_stage = odds_stage if odds_stage in ('early', 'final') else ('final' if (hm >= '22:30' or hm < '05:00' or is_2300_catchup) else 'early')

      stats_m = epl_data.sync_epl_matches(conn, update_odds=eff_update_odds)
      conn.commit()

      _set_sync(step='更新中英文英超傷停與先發情報新聞…')
      news_cnt = epl_news.sync_epl_news(conn)
      conn.commit()

      _set_sync(step='執行泊松 Walk-Forward 賽後對獎與因子權重進化…')
      evo = model_engine.run_walk_forward(conn)
      if eff_update_odds and not full_backfill:
        if eff_stage == 'final':
          db.set_state(conn, f'odds_lock_{cycle_s}', True, now_tw.strftime('%Y-%m-%d %H:%M:%S'))
        else:
          db.set_state(conn, f'odds_early_{today_s}', True, now_tw.strftime('%Y-%m-%d %H:%M:%S'))
        db.set_state(conn, 'last_odds_stage', {'stage': eff_stage, 'at_tw': now_tw.strftime('%Y-%m-%d %H:%M')}, now_tw.strftime('%Y-%m-%d %H:%M:%S'))
      conn.commit()

      _set_sync(step='編譯毫秒級全站快取 Snapshot…')
      snapshot.build_and_save_snapshot(conn)
      conn.commit()

      done_ts = now_tw.strftime('%Y-%m-%d %H:%M:%S')
      _set_sync(running=False, step='done', last_sync_tw=done_ts, error='')
      return {'ok': True, 'matches': stats_m, 'news': news_cnt, 'model': evo.get('model_version')}
    except Exception as e:  # pylint: disable=broad-except
      _set_sync(running=False, step='error', error=str(e))
      raise
    finally:
      conn.close()
  finally:
    try:
      fcntl.flock(lock_fd.fileno(), fcntl.LOCK_UN)
    except OSError:
      pass
    lock_fd.close()


if __name__ == '__main__':
  res = sync_all(full_backfill=True, update_odds=True)
  print('Sync complete:', res)
