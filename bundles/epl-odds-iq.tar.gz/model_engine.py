#!/usr/bin/env python3
"""Self-Evolving Premier League Dixon-Coles / Poisson Walk-Forward Model Engine.

Strictly chronological match-by-match evaluation (GW1 -> Current, ZERO lookahead):
- Anchors on DraftKings pre-match spread (-0.5 / +0.5 / -1.5 / PK) & Over/Under (2.5 / 3.5).
- Computes 7 Asian-Handicap / Spread factors + 6 Total-Goals factors.
- Uses bivariate Poisson / Dixon-Coles low-score correlation to estimate exact 1X2, BTTS, Spread cover, and Over/Under probabilities.
- Post-mortem error attribution (Red card, 90+' stoppage goal, Low-block draw, Finishing xG variance, Midweek euro fatigue, Steam trap) + online L2 weight evolution.
"""
from __future__ import annotations

import datetime as dt
import json
import math
import sqlite3
from typing import Any

import config
import db
import teams

ATS_FACTOR_META: dict[str, dict[str, str]] = {
    'xg_net_diff': {'zh': '攻守射正與淨球差實力', 'desc': '雙方滾動進球＋射正創造力減防守壓制力'},
    'home_fortress': {'zh': '英超主客場戰力分野', 'desc': '主場搶分率對比客隊作客失球落差'},
    'key_injury_susp': {'zh': '核心傷停與禁賽折損', 'desc': '僅針對未來場次計算 FPL 主力缺陣 xGI 折損'},
    'rest_euro_fatigue': {'zh': '週中歐戰與密集賽程負荷', 'desc': '休息天數差與歐冠／歐霸分心折減'},
    'line_steam': {'zh': '初盤→臨場變盤與水錢流向', 'desc': '莊家讓球與獨贏賠率下修之真實資金方向'},
    'draw_trap_shield': {'zh': '低位鐵桶陣與和局防呆', 'desc': '強隊讓半球(-0.5)遇高和局率對手之防誘盤修正'},
    'finishing_regression': {'zh': '射門轉化率均值回歸', 'desc': '近期實際進球偏離射正期望值之冷熱回歸'},
}

OU_FACTOR_META: dict[str, dict[str, str]] = {
    'combined_attack_pace': {'zh': '雙方進攻節奏與射正總量', 'desc': '主客近場場均進球與射正合計強度'},
    'def_leak_clean_sheet': {'zh': '後防失球率與零封缺口', 'desc': '雙方近期場均失球與難以零封程度'},
    'btts_open_style': {'zh': '雙方進球 (BTTS) 對攻傾向', 'desc': '兩隊同時破門比例與高位逼搶開放度'},
    'ou_market_steam': {'zh': '大小球盤口與水錢流向', 'desc': '初盤至目前大小球線值與高低水變化'},
    'fatigue_late_goals': {'zh': '密集賽程末段體能失球', 'desc': '短休作戰導致 75 分鐘後防線鬆動效應'},
    'attacker_absence': {'zh': '鋒線主力傷停進球折減', 'desc': '主力前鋒／進攻中場傷缺對總進球壓抑'},
}

ERROR_TAG_META: dict[str, dict[str, str]] = {
    'RED_CARD_PENALTY': {
        'zh': '紅牌少打一人／十二碼劇變',
        'guardrail': '單場紅牌屬不可控隨機事件，模型自動限制單筆權重懲罰上限，避免過度擬合。',
    },
    'STOPPAGE_TIME_HEARTBREAK': {
        'zh': '90+ 補時階段絕殺／絕平翻盤',
        'guardrail': '針對深盤讓球方（-1.0 以上）提高 STRONG 邊際門檻，防範領先一球保守退防遭補時追平。',
    },
    'LOW_BLOCK_DRAW': {
        'zh': '密集鐵桶陣悶和（讓半球輸盤）',
        'guardrail': '當泊松模型和局機率 ≥ 27.5% 且主讓 -0.5 時，強制啟動「和局防呆」優先轉向受讓 +0.5。',
    },
    'FINISHING_XG_VARIANCE': {
        'zh': '射正壓制但門前把握度失常',
        'guardrail': '射正領先 ≥ 4 次卻未贏盤屬短期終結變異，提高「射門轉化均值回歸」因子權重。',
    },
    'MIDWEEK_FATIGUE_DROP': {
        'zh': '歐戰／週中雙賽體能下滑',
        'guardrail': '歐戰球隊休息 ≤ 4 天作客中游主場時，自動折減預期進球 λ 0.14 球。',
    },
    'MARKET_STEAM_TRAP': {
        'zh': '熱門豪門公眾資金過熱誘盤',
        'guardrail': '傳統六強作客讓 -0.5 但獨贏賠率逆勢上調時，視為誘盤訊號予以避開或反下受讓。',
    },
}

PRE_SEASON_STRENGTH: dict[str, float] = {
    'MCI': 0.85, 'ARS': 0.82, 'LIV': 0.78, 'CHE': 0.52, 'NEW': 0.35,
    'TOT': 0.32, 'MUN': 0.28, 'AVL': 0.30, 'BHA': 0.18, 'BOU': 0.05,
    'BRE': 0.02, 'FUL': 0.00, 'CRY': -0.04, 'NFO': -0.06, 'EVE': -0.15,
    'SUN': -0.28, 'LEE': -0.30, 'IPS': -0.45, 'COV': -0.52, 'HUL': -0.55,
}


def _clamp(v: float, lo: float, hi: float) -> float:
  return max(lo, min(hi, v))


def _poisson_pmf(k: int, lam: float) -> float:
  lam = max(0.08, lam)
  return math.exp(-lam) * (lam ** k) / math.factorial(k)


def _match_probs(lam_h: float, lam_a: float, rho: float = -0.09) -> dict[str, float]:
  """Dixon-Coles adjusted bivariate Poisson score grid (0..8 goals)."""
  grid: dict[tuple[int, int], float] = {}
  tot = 0.0
  for i in range(9):
    pi = _poisson_pmf(i, lam_h)
    for j in range(9):
      pj = _poisson_pmf(j, lam_a)
      tau = 1.0
      if i == 0 and j == 0:
        tau = 1.0 - lam_h * lam_a * rho
      elif i == 0 and j == 1:
        tau = 1.0 + lam_h * rho
      elif i == 1 and j == 0:
        tau = 1.0 + lam_a * rho
      elif i == 1 and j == 1:
        tau = 1.0 - rho
      p = max(0.0, pi * pj * tau)
      grid[(i, j)] = p
      tot += p
  if tot <= 0:
    tot = 1.0
  for k in grid:
    grid[k] /= tot

  p_home = sum(p for (i, j), p in grid.items() if i > j)
  p_draw = sum(p for (i, j), p in grid.items() if i == j)
  p_away = sum(p for (i, j), p in grid.items() if i < j)
  p_btts = sum(p for (i, j), p in grid.items() if i >= 1 and j >= 1)
  return {'grid': grid, 'home': p_home, 'draw': p_draw, 'away': p_away, 'btts': p_btts}


def _cover_prob_home(grid: dict[tuple[int, int], float], spread_home: float) -> float:
  win_p = push_p = 0.0
  for (i, j), p in grid.items():
    adj = (i - j) + spread_home
    if adj > 1e-6:
      win_p += p
    elif abs(adj) <= 1e-6:
      push_p += p
  denom = max(0.01, 1.0 - push_p)
  return _clamp(win_p / denom, 0.08, 0.92)


def _over_prob(grid: dict[tuple[int, int], float], total_line: float) -> float:
  over_p = push_p = 0.0
  for (i, j), p in grid.items():
    s = i + j
    if s > total_line + 1e-6:
      over_p += p
    elif abs(s - total_line) <= 1e-6:
      push_p += p
  denom = max(0.01, 1.0 - push_p)
  return _clamp(over_p / denom, 0.08, 0.92)


def _club_rolling(hist: list[dict[str, Any]], abbr: str, match_date: str) -> dict[str, float]:
  rows = [r for r in hist if r['team'] == abbr]
  prior = PRE_SEASON_STRENGTH.get(abbr, 0.0)
  if not rows:
    return {
        'gf': 1.42 + prior * 0.45,
        'ga': 1.42 - prior * 0.38,
        'sot_f': 4.6 + prior * 1.4,
        'sot_a': 4.6 - prior * 1.2,
        'home_gd': 0.25 + prior * 0.5,
        'away_gd': -0.20 + prior * 0.45,
        'btts_rate': 0.56,
        'cs_rate': 0.28 + prior * 0.08,
        'rest_days': 7.0,
        'gp': 0,
    }
  n = len(rows)
  w = min(1.0, n / 4.0)
  rec = rows[-6:]
  gf = sum(r['gf'] for r in rec) / len(rec)
  ga = sum(r['ga'] for r in rec) / len(rec)
  sot_f = sum(r['sot_f'] for r in rec) / len(rec)
  sot_a = sum(r['sot_a'] for r in rec) / len(rec)
  h_rows = [r for r in rows if r['is_home']]
  a_rows = [r for r in rows if not r['is_home']]
  h_gd = (sum(r['gf'] - r['ga'] for r in h_rows) / len(h_rows)) if h_rows else (gf - ga + 0.25)
  a_gd = (sum(r['gf'] - r['ga'] for r in a_rows) / len(a_rows)) if a_rows else (gf - ga - 0.20)
  btts = sum(1.0 for r in rec if r['gf'] > 0 and r['ga'] > 0) / len(rec)
  cs = sum(1.0 for r in rec if r['ga'] == 0) / len(rec)

  try:
    d_cur = dt.date.fromisoformat(match_date)
    d_prev = dt.date.fromisoformat(rows[-1]['uk_date'])
    rest = float(max(2, min(14, (d_cur - d_prev).days)))
  except ValueError:
    rest = 7.0

  return {
      'gf': (1 - w) * (1.42 + prior * 0.45) + w * gf,
      'ga': (1 - w) * (1.42 - prior * 0.38) + w * ga,
      'sot_f': (1 - w) * (4.6 + prior * 1.4) + w * sot_f,
      'sot_a': (1 - w) * (4.6 - prior * 1.2) + w * sot_a,
      'home_gd': (1 - w) * (0.25 + prior * 0.5) + w * h_gd,
      'away_gd': (1 - w) * (-0.20 + prior * 0.45) + w * a_gd,
      'btts_rate': (1 - w) * 0.56 + w * btts,
      'cs_rate': (1 - w) * 0.28 + w * cs,
      'rest_days': rest,
      'gp': n,
  }


def run_walk_forward(conn: sqlite3.Connection) -> dict[str, Any]:
  now_str = dt.datetime.now(config.TZ_TW).strftime('%Y-%m-%d %H:%M:%S')
  games = [dict(r) for r in conn.execute('SELECT * FROM games ORDER BY kickoff_utc ASC, game_id ASC').fetchall()]

  # Current FPL injury impact ONLY applied to non-FINAL upcoming games (Pattern 163.3 Zero Lookahead!)
  fpl_inj_by_team: dict[str, float] = {}
  for r in conn.execute("SELECT team_abbr, pos, status, play_prob, xgi, minutes FROM fpl_players WHERE status != 'a'").fetchall():
    prob = int(r['play_prob'] if r['play_prob'] is not None else 50)
    miss_frac = max(0.0, (100 - prob) / 100.0)
    importance = min(0.32, (float(r['xgi'] or 0.0) * 0.045) + (0.08 if int(r['minutes'] or 0) >= 450 else 0.02))
    fpl_inj_by_team[r['team_abbr']] = round(min(0.55, fpl_inj_by_team.get(r['team_abbr'], 0.0) + miss_frac * importance), 3)

  conn.execute('DELETE FROM predictions')

  w_ats: dict[str, float] = {
      'xg_net_diff': 1.15,
      'home_fortress': 1.00,
      'key_injury_susp': 0.95,
      'rest_euro_fatigue': 0.90,
      'line_steam': 1.05,
      'draw_trap_shield': 1.15,
      'finishing_regression': 0.85,
  }
  w_ou: dict[str, float] = {
      'combined_attack_pace': 1.10,
      'def_leak_clean_sheet': 1.05,
      'btts_open_style': 0.95,
      'ou_market_steam': 1.00,
      'fatigue_late_goals': 0.80,
      'attacker_absence': 0.90,
  }
  ats_fstats = {k: {'correct': 0.0, 'total': 0.0} for k in ATS_FACTOR_META}
  ou_fstats = {k: {'correct': 0.0, 'total': 0.0} for k in OU_FACTOR_META}
  error_counts = {k: 0 for k in ERROR_TAG_META}

  hist: list[dict[str, Any]] = []
  strong_w = strong_l = all_w = all_l = base_w = base_l = 0
  ats_w = ats_l = ou_w = ou_l = 0
  day_buckets: dict[str, dict[str, int]] = {}

  completed_cnt = sum(1 for g in games if g['status'] == 'FINAL')
  model_ver = f'v2.{max(1, completed_cnt // 10)}'

  for g in games:
    gid = g['game_id']
    is_final = g['status'] == 'FINAL' and g['home_score'] is not None and g['away_score'] is not None
    h_ab, a_ab = g['home_abbr'], g['away_abbr']
    hf = _club_rolling(hist, h_ab, g['uk_date'])
    af = _club_rolling(hist, a_ab, g['uk_date'])

    sp_close = float(g['close_spread_home'] if g['close_spread_home'] is not None else -0.5)
    sp_open = float(g['open_spread_home'] if g['open_spread_home'] is not None else sp_close)
    tot_close = float(g['close_total'] if g['close_total'] is not None else 2.5)
    tot_open = float(g['open_total'] if g['open_total'] is not None else tot_close)

    # Market baseline expected margin & total goals
    mkt_margin_home = -sp_close
    mkt_total = _clamp(tot_close + 0.12, 2.05, 3.85)

    # Only use current live FPL injury penalty on UPCOMING games (zero lookahead on historical games!)
    h_inj_pen = 0.0 if is_final else fpl_inj_by_team.get(h_ab, 0.0)
    a_inj_pen = 0.0 if is_final else fpl_inj_by_team.get(a_ab, 0.0)

    h_euro = teams.CLUBS.get(h_ab, {}).get('euro', False)
    a_euro = teams.CLUBS.get(a_ab, {}).get('euro', False)
    h_fat = -0.14 if (hf['rest_days'] <= 4 or (h_euro and hf['rest_days'] <= 5)) else 0.0
    a_fat = -0.16 if (af['rest_days'] <= 4 or (a_euro and af['rest_days'] <= 5)) else 0.0

    # 7 Spread Residual Factors (positive = favors HOME covering sp_close)
    emp_net_h = (hf['gf'] - hf['ga']) * 0.6 + (hf['sot_f'] - hf['sot_a']) * 0.14
    emp_net_a = (af['gf'] - af['ga']) * 0.6 + (af['sot_f'] - af['sot_a']) * 0.14
    raw_margin = (emp_net_h - emp_net_a) * 0.55 + 0.28

    steam_sp = (sp_open - sp_close) * 1.2
    if g['open_ml_home_dec'] and g['ml_home_dec'] and g['open_ml_home_dec'] > 1.1:
      steam_sp += _clamp((float(g['open_ml_home_dec']) - float(g['ml_home_dec'])) * 0.8, -0.4, 0.4)

    # Draw-trap detector: when favorite lays -0.5 in a tight defensive matchup, +0.5 dog captures the Draw!
    draw_shield = 0.0
    if sp_close == -0.5 and abs(raw_margin) < 0.48:
      draw_shield = -0.36
    elif sp_close == 0.5 and abs(raw_margin) < 0.48:
      draw_shield = 0.36

    # Finishing regression: fade team over-scoring its shots on target
    h_overperf = hf['gf'] - (hf['sot_f'] * 0.31)
    a_overperf = af['gf'] - (af['sot_f'] * 0.31)

    f_ats: dict[str, float] = {
        'xg_net_diff': _clamp((raw_margin - mkt_margin_home) * 0.85, -1.2, 1.2),
        'home_fortress': _clamp((hf['home_gd'] - af['away_gd'] - mkt_margin_home) * 0.45, -0.9, 0.9),
        'key_injury_susp': _clamp((a_inj_pen - h_inj_pen) * 1.8, -0.9, 0.9),
        'rest_euro_fatigue': _clamp((h_fat - a_fat) * 1.6, -0.7, 0.7),
        'line_steam': _clamp(steam_sp, -0.8, 0.8),
        'draw_trap_shield': draw_shield,
        'finishing_regression': _clamp((a_overperf - h_overperf) * 0.45, -0.7, 0.7),
    }

    # 6 Total Goals Residual Factors (positive = favors OVER)
    emp_pace = (hf['gf'] + af['gf']) * 0.55 + (hf['sot_f'] + af['sot_f']) * 0.13
    emp_leak = (hf['ga'] + af['ga']) - (hf['cs_rate'] + af['cs_rate']) * 0.6
    f_ou: dict[str, float] = {
        'combined_attack_pace': _clamp((emp_pace - mkt_total) * 0.75, -1.1, 1.1),
        'def_leak_clean_sheet': _clamp((emp_leak - 2.35) * 0.65, -1.0, 1.0),
        'btts_open_style': _clamp(((hf['btts_rate'] + af['btts_rate']) / 2.0 - 0.55) * 1.8, -0.8, 0.8),
        'ou_market_steam': _clamp((tot_close - tot_open) * 1.4, -0.8, 0.8),
        'fatigue_late_goals': 0.22 if (hf['rest_days'] <= 4 or af['rest_days'] <= 4) else -0.05,
        'attacker_absence': _clamp(-(h_inj_pen + a_inj_pen) * 1.2, -0.9, 0.0),
    }

    ats_adj = sum(f_ats[k] * w_ats[k] for k in f_ats) / (sum(w_ats.values()) or 1.0) * 0.52
    ou_adj = sum(f_ou[k] * w_ou[k] for k in f_ou) / (sum(w_ou.values()) or 1.0) * 0.58

    pred_margin = _clamp(mkt_margin_home * 0.82 + raw_margin * 0.18 + ats_adj, -2.6, 2.8)
    pred_total = _clamp(mkt_total * 0.80 + ((emp_pace + emp_leak) * 0.5) * 0.20 + ou_adj, 1.75, 4.35)

    lam_h = round(_clamp((pred_total + pred_margin) / 2.0, 0.35, 3.30), 2)
    lam_a = round(_clamp((pred_total - pred_margin) / 2.0, 0.30, 3.00), 2)
    fair_sp_home = round(-(lam_h - lam_a), 2)

    probs = _match_probs(lam_h, lam_a)
    p_cov_home = _cover_prob_home(probs['grid'], sp_close)
    p_over = _over_prob(probs['grid'], tot_close)

    # Guardrail: Draw Trap Shield on -0.5 favorite when Draw >= 27.5%
    if sp_close == -0.5 and probs['draw'] >= 0.275 and p_cov_home < 0.53:
      p_cov_home = min(p_cov_home, 0.455)

    ats_side = 'HOME' if p_cov_home >= 0.5 else 'AWAY'
    ats_prob = p_cov_home if ats_side == 'HOME' else (1.0 - p_cov_home)
    ats_edge = round((ats_prob - 0.5238) * 100.0, 2)
    ats_tier = 'STRONG' if ats_prob >= 0.585 else ('LEAN' if ats_prob >= 0.542 else 'PASS')
    ats_pick = ats_side if ats_tier != 'PASS' else 'PASS'
    ats_kelly = round(_clamp(((ats_prob * 1.91 - 1.0) / 0.91) * 0.25 * 20.0, 0.5, 2.5), 2) if ats_tier != 'PASS' else 0.0

    ou_side = 'OVER' if p_over >= 0.5 else 'UNDER'
    ou_prob = p_over if ou_side == 'OVER' else (1.0 - p_over)
    ou_edge = round((ou_prob - 0.5238) * 100.0, 2)
    ou_tier = 'STRONG' if ou_prob >= 0.585 else ('LEAN' if ou_prob >= 0.545 else 'PASS')
    ou_pick = ou_side if ou_tier != 'PASS' else 'PASS'
    ou_kelly = round(_clamp(((ou_prob * 1.91 - 1.0) / 0.91) * 0.25 * 20.0, 0.5, 2.5), 2) if ou_tier != 'PASS' else 0.0

    # Check 1X2 value spot
    val_1x2 = ''
    for lbl, p1x2, dec in (
        ('主勝', probs['home'], g['ml_home_dec']),
        ('和局', probs['draw'], g['ml_draw_dec']),
        ('客勝', probs['away'], g['ml_away_dec']),
    ):
      if dec and float(dec) >= 1.45:
        ev1 = (p1x2 * float(dec) - 1.0) * 100.0
        if ev1 >= 5.0:
          val_1x2 = f'{lbl} @{float(dec):.2f} (EV +{ev1:.1f}%)'
          break

    h_zh = teams.team_info(h_ab)['zh']
    a_zh = teams.team_info(a_ab)['zh']
    pick_tm_zh = h_zh if ats_side == 'HOME' else a_zh
    pick_line = sp_close if ats_side == 'HOME' else -sp_close
    move_clauses: list[str] = []
    if abs(sp_open - sp_close) >= 0.25:
      sp_dir = f'往主隊 {h_zh} 升盤' if (sp_open - sp_close) > 0 else f'往客隊 {a_zh} 退盤'
      move_clauses.append(f'讓球由 {sp_open:+.1f} 變為 {sp_close:+.1f}（{sp_dir}）')
    if abs(tot_close - tot_open) >= 0.25:
      tot_dir = '調升大球門檻' if (tot_close - tot_open) > 0 else '下修小球線'
      move_clauses.append(f'大小球由 {tot_open:.2g} 調至 {tot_close:.2g}（{tot_dir}）')
    move_prefix = f'【📈 18:00→23:00 變盤重析：{"；".join(move_clauses)}】' if move_clauses else ''
    rationale = (
        f'{move_prefix}泊松期望進球 λ：{a_zh} {lam_a:.2f} : {lam_h:.2f} {h_zh}（主勝 {probs["home"]*100:.0f}% / 和局 {probs["draw"]*100:.0f}% / 客勝 {probs["away"]*100:.0f}%，'
        f'雙方進球 {probs["btts"]*100:.0f}%）。讓球盤傾向【{pick_tm_zh} {pick_line:+.1f}】（過盤率 {ats_prob*100:.1f}%），'
        f'大小球預估 {lam_h+lam_a:.2f} 球。'
    )

    ats_res = 'PENDING'
    ou_res = 'PENDING'
    err_tag = ''
    pm_zh = ''

    if is_final:
      hs, as_ = int(g['home_score']), int(g['away_score'])
      t_stats = json.loads(g['stats_json'] or '{}')
      kevs = json.loads(g['key_events_json'] or '[]')
      h_sot = float((t_stats.get(h_ab) or {}).get('shotsOnTarget') or max(1, hs + 2))
      a_sot = float((t_stats.get(a_ab) or {}).get('shotsOnTarget') or max(1, as_ + 2))
      has_red = any('Red Card' in (k.get('type') or '') for k in kevs)
      has_stoppage_goal = any('Goal' in (k.get('type') or '') and "90'+" in (k.get('clock') or '') for k in kevs)

      # Naive baseline = blindly bet home favorite (or away favorite if home is dog)
      base_side = 'HOME' if sp_close <= 0 else 'AWAY'
      if g['ats_winner'] in ('HOME', 'AWAY'):
        if base_side == g['ats_winner']:
          base_w += 1
        else:
          base_l += 1

        # Update factor accuracy & online weights
        actual_sign = 1.0 if g['ats_winner'] == 'HOME' else -1.0
        for fk, fv in f_ats.items():
          if abs(fv) >= 0.06:
            ats_fstats[fk]['total'] += 1.0
            hit = (fv * actual_sign) > 0
            if hit:
              ats_fstats[fk]['correct'] += 1.0
              w_ats[fk] = _clamp(w_ats[fk] * 0.994 + 0.018, 0.50, 1.75)
            else:
              w_ats[fk] = _clamp(w_ats[fk] * 0.994 - 0.015, 0.50, 1.75)

      if g['ou_result'] in ('OVER', 'UNDER'):
        ou_sign = 1.0 if g['ou_result'] == 'OVER' else -1.0
        for fk, fv in f_ou.items():
          if abs(fv) >= 0.06:
            ou_fstats[fk]['total'] += 1.0
            hit = (fv * ou_sign) > 0
            if hit:
              ou_fstats[fk]['correct'] += 1.0
              w_ou[fk] = _clamp(w_ou[fk] * 0.994 + 0.018, 0.50, 1.75)
            else:
              w_ou[fk] = _clamp(w_ou[fk] * 0.994 - 0.015, 0.50, 1.75)

      bkt = day_buckets.setdefault(g['tw_date'], {'sw': 0, 'sl': 0, 'aw': 0, 'al': 0})

      if ats_pick == 'PASS':
        ats_res = 'PASS'
      elif g['ats_winner'] == 'PUSH':
        ats_res = 'PUSH'
      elif ats_pick == g['ats_winner']:
        ats_res = 'WIN'
        ats_w += 1
        all_w += 1
        bkt['aw'] += 1
        if ats_tier == 'STRONG':
          strong_w += 1
          bkt['sw'] += 1
      else:
        ats_res = 'LOSS'
        ats_l += 1
        all_l += 1
        bkt['al'] += 1
        if ats_tier == 'STRONG':
          strong_l += 1
          bkt['sl'] += 1
        if has_red:
          err_tag = 'RED_CARD_PENALTY'
        elif has_stoppage_goal:
          err_tag = 'STOPPAGE_TIME_HEARTBREAK'
        elif hs == as_ and ((ats_pick == 'HOME' and sp_close < 0) or (ats_pick == 'AWAY' and sp_close > 0)):
          err_tag = 'LOW_BLOCK_DRAW'
        elif (ats_pick == 'HOME' and h_sot >= a_sot + 3) or (ats_pick == 'AWAY' and a_sot >= h_sot + 3):
          err_tag = 'FINISHING_XG_VARIANCE'
        elif hf['rest_days'] <= 4 or af['rest_days'] <= 4:
          err_tag = 'MIDWEEK_FATIGUE_DROP'
        else:
          err_tag = 'MARKET_STEAM_TRAP'
        error_counts[err_tag] = error_counts.get(err_tag, 0) + 1

      if ou_pick == 'PASS':
        ou_res = 'PASS'
      elif g['ou_result'] == 'PUSH':
        ou_res = 'PUSH'
      elif ou_pick == g['ou_result']:
        ou_res = 'WIN'
        ou_w += 1
        all_w += 1
        bkt['aw'] += 1
        if ou_tier == 'STRONG':
          strong_w += 1
          bkt['sw'] += 1
      else:
        ou_res = 'LOSS'
        ou_l += 1
        all_l += 1
        bkt['al'] += 1
        if ou_tier == 'STRONG':
          strong_l += 1
          bkt['sl'] += 1
        if not err_tag:
          err_tag = 'RED_CARD_PENALTY' if has_red else ('STOPPAGE_TIME_HEARTBREAK' if has_stoppage_goal else 'FINISHING_XG_VARIANCE')
          error_counts[err_tag] = error_counts.get(err_tag, 0) + 1

      if err_tag:
        pm_zh = f'完賽 {as_}:{hs} — 檢討歸因：【{ERROR_TAG_META[err_tag]["zh"]}】，已完成因子權重修正。'
      elif ats_res == 'WIN' or ou_res == 'WIN':
        pm_zh = f'✅ 完賽 {as_}:{hs} — 模型泊松預期進球與盤口價值成功兌現！'
      else:
        pm_zh = f'完賽 {as_}:{hs} — 盤口邊際不足紀律觀望 PASS。'

      # Strictly AFTER predicting & grading this match, append to rolling history!
      hist.append({'uk_date': g['uk_date'], 'team': h_ab, 'is_home': True, 'gf': float(hs), 'ga': float(as_), 'sot_f': h_sot, 'sot_a': a_sot})
      hist.append({'uk_date': g['uk_date'], 'team': a_ab, 'is_home': False, 'gf': float(as_), 'ga': float(hs), 'sot_f': a_sot, 'sot_a': h_sot})

    conn.execute(
        """
        INSERT INTO predictions(
          game_id, model_version, lambda_home, lambda_away, pred_total, fair_spread_home,
          prob_home_pct, prob_draw_pct, prob_away_pct, prob_btts_pct,
          ats_pick, ats_lean_side, ats_tier, ats_edge, ats_kelly_u,
          ou_pick, ou_lean_side, ou_tier, ou_edge, ou_kelly_u, value_1x2,
          ats_factors_json, ou_factors_json, rationale_zh,
          ats_result, ou_graded, error_tag, postmortem_zh
        ) VALUES (?,?,?,?,?,?, ?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,?, ?,?,?, ?,?,?,?)
        """,
        (
            gid, model_ver, lam_h, lam_a, round(lam_h + lam_a, 2), fair_sp_home,
            round(probs['home'] * 100, 1), round(probs['draw'] * 100, 1),
            round(probs['away'] * 100, 1), round(probs['btts'] * 100, 1),
            ats_pick, ats_side, ats_tier, ats_edge, ats_kelly,
            ou_pick, ou_side, ou_tier, ou_edge, ou_kelly, val_1x2,
            json.dumps({k: {'zh': ATS_FACTOR_META[k]['zh'], 'weighted': round(f_ats[k] * w_ats[k], 3)} for k in f_ats}, ensure_ascii=False),
            json.dumps({k: {'zh': OU_FACTOR_META[k]['zh'], 'weighted': round(f_ou[k] * w_ou[k], 3)} for k in f_ou}, ensure_ascii=False),
            rationale, ats_res, ou_res, err_tag, pm_zh,
        ),
    )

  # Build cumulative evolution curve by matchday
  curve = []
  daily_log = []
  c_sw = c_sl = c_aw = c_al = 0
  for dt_key in sorted(day_buckets.keys()):
    b = day_buckets[dt_key]
    if b['aw'] + b['al'] == 0:
      continue
    c_sw += b['sw']
    c_sl += b['sl']
    c_aw += b['aw']
    c_al += b['al']
    swr = round(c_sw / max(1, c_sw + c_sl) * 100, 1)
    awr = round(c_aw / max(1, c_aw + c_al) * 100, 1)
    curve.append({'tw_date': dt_key, 'strong_wr': swr, 'all_wr': awr, 'day_rec': f"{b['aw']}W-{b['al']}L"})
    daily_log.append({
        'tw_date': dt_key,
        'all_record': f"{b['aw']}勝 {b['al']}敗",
        'strong_record': f"{b['sw']}勝 {b['sl']}敗",
        'cum_strong_wr': swr,
        'note': '完成賽後泊松殘差與和局防呆權重更新',
    })

  tot_s = strong_w + strong_l
  tot_a = all_w + all_l
  strong_wr = round(strong_w / max(1, tot_s) * 100, 1)
  all_wr = round(all_w / max(1, tot_a) * 100, 1)
  base_wr = round(base_w / max(1, base_w + base_l) * 100, 1)
  roi_pct = round(((strong_w * (config.DEFAULT_DECIMAL_ODDS - 1.0) - strong_l) / max(1, tot_s)) * 100, 1)

  ats_fac_tbl = [
      {
          'key': k, 'zh': m['zh'], 'desc': m['desc'], 'weight': round(w_ats[k], 3),
          'hit_rate': round(ats_fstats[k]['correct'] / max(1.0, ats_fstats[k]['total']) * 100, 1),
          'samples': int(ats_fstats[k]['total']),
      }
      for k, m in ATS_FACTOR_META.items()
  ]
  ats_fac_tbl.sort(key=lambda x: x['weight'], reverse=True)

  ou_fac_tbl = [
      {
          'key': k, 'zh': m['zh'], 'desc': m['desc'], 'weight': round(w_ou[k], 3),
          'hit_rate': round(ou_fstats[k]['correct'] / max(1.0, ou_fstats[k]['total']) * 100, 1),
          'samples': int(ou_fstats[k]['total']),
      }
      for k, m in OU_FACTOR_META.items()
  ]
  ou_fac_tbl.sort(key=lambda x: x['weight'], reverse=True)

  err_list = [
      {'tag': k, 'zh': ERROR_TAG_META[k]['zh'], 'count': error_counts.get(k, 0), 'guardrail': ERROR_TAG_META[k]['guardrail']}
      for k in ERROR_TAG_META
  ]
  err_list.sort(key=lambda x: x['count'], reverse=True)

  evo_state = {
      'model_version': model_ver,
      'updated_at': now_str,
      'strong_w': strong_w,
      'strong_l': strong_l,
      'strong_win_rate': strong_wr,
      'all_w': all_w,
      'all_l': all_l,
      'all_win_rate': all_wr,
      'baseline_w': base_w,
      'baseline_l': base_l,
      'baseline_win_rate': base_wr,
      'ats_w': ats_w,
      'ats_l': ats_l,
      'ats_win_rate': round(ats_w / max(1, ats_w + ats_l) * 100, 1),
      'ou_w': ou_w,
      'ou_l': ou_l,
      'ou_win_rate': round(ou_w / max(1, ou_w + ou_l) * 100, 1),
      'roi_pct': roi_pct,
      'breakeven_pct': config.BREAKEVEN_WIN_RATE,
      'ats_factors': ats_fac_tbl,
      'ou_factors': ou_fac_tbl,
      'error_breakdown': err_list,
      'curve': curve,
      'daily_log': list(reversed(daily_log)),
  }
  db.set_state(conn, 'evolution_summary', evo_state, now_str)
  _grade_user_bets(conn)
  return evo_state


def _grade_user_bets(conn: sqlite3.Connection) -> None:
  pending = conn.execute("SELECT * FROM user_bets WHERE status = 'PENDING'").fetchall()
  for b in pending:
    gid = str(b['game_id'] or '')
    if not gid:
      continue
    g = conn.execute('SELECT status, home_score, away_score, result_1x2 FROM games WHERE game_id = ?', (gid,)).fetchone()
    if not g or g['status'] != 'FINAL' or g['home_score'] is None:
      continue
    hs, as_ = float(g['home_score']), float(g['away_score'])
    mkt = str(b['market'] or 'ATS').upper()
    side = str(b['pick_side'] or 'HOME').upper()
    ln = float(b['line'] or 0.0)
    stake = float(b['stake'])
    odds = float(b['odds_decimal'])

    st = 'PENDING'
    if mkt == 'ATS':
      adj = (hs - as_ + ln) if side == 'HOME' else (as_ - hs + ln)
      st = 'WIN' if adj > 0 else ('LOSS' if adj < 0 else 'PUSH')
    elif mkt == 'OU':
      tot = hs + as_
      st = 'PUSH' if tot == ln else ('WIN' if (side == 'OVER' and tot > ln) or (side == 'UNDER' and tot < ln) else 'LOSS')
    elif mkt == '1X2':
      st = 'WIN' if side == g['result_1x2'] else 'LOSS'

    if st != 'PENDING':
      pnl = round(stake * (odds - 1.0), 2) if st == 'WIN' else (-stake if st == 'LOSS' else 0.0)
      conn.execute('UPDATE user_bets SET status = ?, pnl = ? WHERE bet_id = ?', (st, pnl, b['bet_id']))
