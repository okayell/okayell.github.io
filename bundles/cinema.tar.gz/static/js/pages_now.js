/* 🔥 現正上映專區（每週固定自動同步台灣與國際院線新片、看點解析、交叉聯動篩選、即時搜尋與排序） */
(function () {
  'use strict';
  var CIN = window.CIN;
  var PAGE_STEP = 120;

  function matchRunCat(m, runCat) {
    if (!runCat || runCat === 'all') return true;
    var rc = m.runCategory || '';
    var badge = String(m.statusBadge || '');
    if (runCat === 'new') return rc === 'new' || badge.indexOf('本週新片') !== -1;
    if (runCat === 'first_run') {
      if (rc) return rc === 'new' || rc === 'now';
      return badge.indexOf('重映') === -1 && badge.indexOf('二輪') === -1;
    }
    if (runCat === 'classic') {
      if (rc) return rc === 'rerelease' || rc === 'second_run';
      return badge.indexOf('重映') !== -1 || badge.indexOf('二輪') !== -1;
    }
    return true;
  }

  function matchesStatus(m, st) {
    if (st === 'unwatched') return !CIN.isWatched(m.id);
    if (st === 'watchlist') return CIN.isInWatchlist(m.id);
    if (st === 'watched') return CIN.isWatched(m.id);
    return true;
  }

  function matchesQuery(m, qLower) {
    if (!qLower) return true;
    var hay = [
      m.title, m.origTitle, m.director, m.statusBadge,
      (m.cast || []).join(' '), (m.mood || []).join(' '), m.synopsis
    ].join(' ').toLowerCase();
    return hay.indexOf(qLower) !== -1;
  }

  function sortNowList(list, sortMode) {
    var out = list.slice();
    out.sort(function (a, b) {
      if (sortMode === 'date_desc') {
        var da = String(a.releaseDate || '');
        var db = String(b.releaseDate || '');
        if (db !== da) return db.localeCompare(da);
        return (b.theaters || 0) - (a.theaters || 0);
      }
      if (sortMode === 'new_first') {
        var na = matchRunCat(a, 'new') ? 1 : 0;
        var nb = matchRunCat(b, 'new') ? 1 : 0;
        if (nb !== na) return nb - na;
      }
      var ca = matchRunCat(a, 'classic') ? 0 : 1;
      var cb = matchRunCat(b, 'classic') ? 0 : 1;
      if (cb !== ca) return cb - ca;
      return (b.theaters || 0) - (a.theaters || 0) || String(b.releaseDate || '').localeCompare(String(a.releaseDate || ''));
    });
    return out;
  }

  CIN.renderNowPlayingPage = function (root) {
    var payload = CIN.getNowPlayingPayload();
    var allNow = CIN.getNowPlayingMovies();
    var nf = CIN.state.nowFilter;
    if (!nf.runCat) nf.runCat = 'all';
    if (nf.q == null) nf.q = '';
    if (!nf.sort) nf.sort = 'theaters';
    if (!nf.limit || nf.limit < PAGE_STEP) nf.limit = PAGE_STEP;

    var qLower = String(nf.q || '').trim().toLowerCase();

    function matchesExcept(m, ignoreDim) {
      if (ignoreDim !== 'runCat' && !matchRunCat(m, nf.runCat)) return false;
      if (ignoreDim !== 'region' && nf.region !== 'all' && m.region !== nf.region) return false;
      if (ignoreDim !== 'genre' && nf.genre !== 'all' && (m.genres || []).indexOf(nf.genre) === -1) return false;
      if (ignoreDim !== 'status' && !matchesStatus(m, nf.status)) return false;
      if (ignoreDim !== 'q' && !matchesQuery(m, qLower)) return false;
      return true;
    }

    var filtered = sortNowList(allNow.filter(function (m) { return matchesExcept(m, ''); }), nf.sort);
    var poolForRunCat = allNow.filter(function (m) { return matchesExcept(m, 'runCat'); });
    var poolForRegion = allNow.filter(function (m) { return matchesExcept(m, 'region'); });
    var poolForGenre = allNow.filter(function (m) { return matchesExcept(m, 'genre'); });
    var poolForStatus = allNow.filter(function (m) { return matchesExcept(m, 'status'); });

    var isLocalServer = window.location && (window.location.protocol === 'http:' || window.location.protocol === 'https:') &&
      !/\.github\.io$/i.test(window.location.hostname || '');

    var runCatPills = [
      { id: 'all', lbl: '全部院線' },
      { id: 'new', lbl: '🆕 本週新片' },
      { id: 'first_run', lbl: '🔥 首輪熱映' },
      { id: 'classic', lbl: '🎞️ 經典重映／二輪' }
    ].map(function (rc) {
      var c = poolForRunCat.filter(function (m) { return matchRunCat(m, rc.id); }).length;
      var tot = allNow.filter(function (m) { return matchRunCat(m, rc.id); }).length;
      if (!tot && nf.runCat !== rc.id && rc.id !== 'all') return '';
      var cls = 'cin-pill' + (nf.runCat === rc.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
      return '<button type="button" class="' + cls + '" data-now-runcat="' + rc.id + '">' + rc.lbl + ' (' + c + ')</button>';
    }).join('');

    var regionPills = '<button type="button" class="cin-pill' + (nf.region === 'all' ? ' active' : '') + '" data-now-region="all">全部地區 (' + poolForRegion.length + ')</button>' +
      CIN.REGIONS.map(function (r) {
        var c = poolForRegion.filter(function (m) { return m.region === r.id; }).length;
        var totalInReg = allNow.filter(function (m) { return m.region === r.id; }).length;
        if (!totalInReg && nf.region !== r.id) return '';
        var cls = 'cin-pill' + (nf.region === r.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
        return '<button type="button" class="' + cls + '" data-now-region="' + r.id + '">' + CIN.esc(r.label) + ' (' + c + ')</button>';
      }).join('');

    var genrePills = '<button type="button" class="cin-pill' + (nf.genre === 'all' ? ' active' : '') + '" data-now-genre="all">全部類型 (' + poolForGenre.length + ')</button>' +
      CIN.GENRES.map(function (g) {
        var c = poolForGenre.filter(function (m) { return (m.genres || []).indexOf(g.id) !== -1; }).length;
        var totalInGen = allNow.filter(function (m) { return (m.genres || []).indexOf(g.id) !== -1; }).length;
        if (!totalInGen && nf.genre !== g.id) return '';
        var cls = 'cin-pill' + (nf.genre === g.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
        return '<button type="button" class="' + cls + '" data-now-genre="' + g.id + '">' + CIN.esc(g.label) + ' (' + c + ')</button>';
      }).join('');

    var statusPills = [
      { id: 'all', lbl: '全部上映片' },
      { id: 'unwatched', lbl: '👀 我還沒看過' },
      { id: 'watchlist', lbl: '📋 在我的待看片單' },
      { id: 'watched', lbl: '✅ 我已經看過了' }
    ].map(function (s) {
      var c = poolForStatus.filter(function (m) { return matchesStatus(m, s.id); }).length;
      var cls = 'cin-pill' + (nf.status === s.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
      return '<button type="button" class="' + cls + '" data-now-status="' + s.id + '">' + s.lbl + ' (' + c + ')</button>';
    }).join('');

    function buildResultsSection(list) {
      var visibleItems = list.slice(0, nf.limit);
      var remaining = list.length - visibleItems.length;
      var moreBarHtml = remaining > 0
        ? '<div class="cin-load-more-bar">' +
            '<button type="button" class="cin-btn cin-btn-primary" id="btnNowMore">👇 再載入 ' + Math.min(PAGE_STEP, remaining) + ' 部院線片（目前顯示 ' + visibleItems.length + ' / ' + list.length + ' 部）</button>' +
            '<button type="button" class="cin-btn" id="btnNowAll">⚡ 一次展開全部 (' + list.length + ' 部)</button>' +
          '</div>'
        : '';
      if (!visibleItems.length) {
        return (
          '<div class="cin-empty">' +
            '<h3>目前篩選條件下沒有符合的院線電影</h3>' +
            '<p>請切換上方檔期、地區、類型或清除搜尋關鍵字查看其他上映作品。</p>' +
            '<button type="button" class="cin-btn cin-btn-sm cin-btn-primary" id="btnNowEmptyReset">顯示全部上映電影</button>' +
          '</div>'
        );
      }
      return '<div class="cin-movie-grid">' + visibleItems.map(CIN.renderMovieCard).join('') + '</div>' + moreBarHtml;
    }

    var hasActiveFilter = nf.runCat !== 'all' || nf.region !== 'all' || nf.genre !== 'all' || nf.status !== 'all' || !!qLower;

    root.innerHTML =
      '<div class="cin-now-banner">' +
        '<div>' +
          '<h2>🔥 本週院線現正上映（每週固定自動更新）</h2>' +
          '<p>' + CIN.esc(payload.scheduleNote || '每週一固定自動同步台灣與國際院線新片、首輪熱映與經典重映清單，為每部電影整理劇情與三大看點解析。') + '</p>' +
        '</div>' +
        '<div class="cin-now-meta-pills">' +
          '<span class="cin-now-pill">📅 最近更新：' + CIN.esc(payload.updatedAt || '本週最新') + '</span>' +
          (payload.weekKey ? '<span class="cin-now-pill">🗓️ 檔期週次：' + CIN.esc(payload.weekKey) + '</span>' : '') +
          '<span class="cin-now-pill">🎬 收錄 ' + allNow.length + ' 部院線片</span>' +
          (isLocalServer ? '<button type="button" class="cin-btn cin-btn-sm" id="btnRefreshNowPlaying">🔄 立即同步最新院線</button>' : '') +
        '</div>' +
      '</div>' +

      '<div class="cin-filter-box">' +
        '<div class="cin-filter-group">' +
          '<div class="cin-filter-lbl">院線檔期</div>' +
          '<div class="cin-pills">' + runCatPills + '</div>' +
        '</div>' +
        '<div class="cin-filter-group">' +
          '<div class="cin-filter-lbl">地區影壇</div>' +
          '<div class="cin-pills">' + regionPills + '</div>' +
        '</div>' +
        '<div class="cin-filter-group">' +
          '<div class="cin-filter-lbl">電影類型</div>' +
          '<div class="cin-pills">' + genrePills + '</div>' +
        '</div>' +
        '<div class="cin-filter-group">' +
          '<div class="cin-filter-lbl">觀影狀態</div>' +
          '<div class="cin-pills">' + statusPills + '</div>' +
        '</div>' +
      '</div>' +

      '<div class="cin-toolbar">' +
        '<div class="cin-search-wrap">' +
          '<input type="search" id="nowSearchInput" class="cin-input" placeholder="🔍 搜尋現正上映片名、原文片名、導演或演員（如：蕭邦、柯南、哥吉拉）…" value="' + CIN.esc(nf.q) + '" />' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">' +
          '<span style="font-size:13px;font-weight:800;color:#57534e;">共找到 <b id="nowMatchCount" style="color:#be123c;">' + filtered.length + '</b> / ' + allNow.length + ' 部</span>' +
          (hasActiveFilter ? '<button type="button" class="cin-btn cin-btn-sm" id="btnResetNowFilter">↺ 重設篩選</button>' : '') +
          '<select id="nowSortSelect" class="cin-select" style="width:auto;" aria-label="排序方式">' +
            '<option value="theaters"' + (nf.sort === 'theaters' ? ' selected' : '') + '>依上映規模（全台廳數 多 → 少）</option>' +
            '<option value="new_first"' + (nf.sort === 'new_first' ? ' selected' : '') + '>依本週新片優先</option>' +
            '<option value="date_desc"' + (nf.sort === 'date_desc' ? ' selected' : '') + '>依上映日期（最新 → 較早）</option>' +
          '</select>' +
        '</div>' +
      '</div>' +

      '<div id="nowResultsBox">' + buildResultsSection(filtered) + '</div>';

    function resetNowFilters() {
      nf.runCat = 'all';
      nf.region = 'all';
      nf.genre = 'all';
      nf.status = 'all';
      nf.q = '';
      nf.limit = PAGE_STEP;
      CIN.renderNowPlayingPage(root);
    }

    function bindResultButtons(curList) {
      var btnNowMore = document.getElementById('btnNowMore');
      if (btnNowMore) {
        btnNowMore.onclick = function () {
          nf.limit = (nf.limit || PAGE_STEP) + PAGE_STEP;
          CIN.renderNowPlayingPage(root);
        };
      }
      var btnNowAll = document.getElementById('btnNowAll');
      if (btnNowAll) {
        btnNowAll.onclick = function () {
          nf.limit = curList.length + PAGE_STEP;
          CIN.renderNowPlayingPage(root);
        };
      }
      var btnEmpty = document.getElementById('btnNowEmptyReset');
      if (btnEmpty) btnEmpty.onclick = resetNowFilters;
    }
    bindResultButtons(filtered);

    var rBtn = document.getElementById('btnResetNowFilter');
    if (rBtn) rBtn.onclick = resetNowFilters;

    root.querySelectorAll('[data-now-runcat]').forEach(function (b) {
      b.onclick = function () {
        nf.runCat = b.getAttribute('data-now-runcat');
        nf.limit = PAGE_STEP;
        CIN.renderNowPlayingPage(root);
      };
    });
    root.querySelectorAll('[data-now-region]').forEach(function (b) {
      b.onclick = function () {
        nf.region = b.getAttribute('data-now-region');
        nf.limit = PAGE_STEP;
        CIN.renderNowPlayingPage(root);
      };
    });
    root.querySelectorAll('[data-now-genre]').forEach(function (b) {
      b.onclick = function () {
        nf.genre = b.getAttribute('data-now-genre');
        nf.limit = PAGE_STEP;
        CIN.renderNowPlayingPage(root);
      };
    });
    root.querySelectorAll('[data-now-status]').forEach(function (b) {
      b.onclick = function () {
        nf.status = b.getAttribute('data-now-status');
        nf.limit = PAGE_STEP;
        CIN.renderNowPlayingPage(root);
      };
    });

    var sortSel = document.getElementById('nowSortSelect');
    if (sortSel) {
      sortSel.onchange = function () {
        nf.sort = sortSel.value;
        nf.limit = PAGE_STEP;
        CIN.renderNowPlayingPage(root);
      };
    }

    var searchInp = document.getElementById('nowSearchInput');
    if (searchInp) {
      var composing = false;
      var applyLiveSearch = function () {
        nf.q = searchInp.value;
        nf.limit = PAGE_STEP;
        qLower = String(nf.q || '').trim().toLowerCase();
        var nextList = sortNowList(allNow.filter(function (m) { return matchesExcept(m, ''); }), nf.sort);
        var box = document.getElementById('nowResultsBox');
        var cnt = document.getElementById('nowMatchCount');
        if (box) box.innerHTML = buildResultsSection(nextList);
        if (cnt) cnt.textContent = String(nextList.length);
        bindResultButtons(nextList);
      };
      searchInp.addEventListener('compositionstart', function () { composing = true; });
      searchInp.addEventListener('compositionend', function () { composing = false; applyLiveSearch(); });
      searchInp.addEventListener('input', function () {
        if (!composing) applyLiveSearch();
      });
    }

    var refreshBtn = document.getElementById('btnRefreshNowPlaying');
    if (refreshBtn) {
      refreshBtn.onclick = function () {
        refreshBtn.disabled = true;
        refreshBtn.textContent = '⏳ 正在同步院線片單…';
        fetch(CIN.apiBase() + 'now_playing/refresh', { method: 'POST' })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            var d = (res && res.data) ? res.data : res;
            if (res && res.ok && d && Array.isArray(d.items)) {
              window.CIN_NOW_PLAYING = d;
              CIN.syncHeaderBadges();
              CIN.toast('✅ 已更新最新院線上映電影（共 ' + d.items.length + ' 部）');
              CIN.renderNowPlayingPage(root);
            } else {
              throw new Error((res && res.error) || '更新失敗');
            }
          })
          .catch(function (err) {
            refreshBtn.disabled = false;
            refreshBtn.textContent = '🔄 立即同步最新院線';
            CIN.toast('⚠️ 同步失敗：' + err.message);
          });
      };
    }
  };
})();
