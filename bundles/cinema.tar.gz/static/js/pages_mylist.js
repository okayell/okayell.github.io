/* 📋 我的片單與觀影護照（待看片單 Watchlist、我看過了 Watched、星等筆記與 JSON 備份匯出入） */
(function () {
  'use strict';
  var CIN = window.CIN;

  CIN.renderMyListPage = function (root) {
    var tab = CIN.state.myListTab || 'watchlist';
    var wlIds = Object.keys(CIN.state.watchlist || {});
    var wdIds = Object.keys(CIN.state.watched || {});

    var wlMovies = wlIds.map(CIN.findMovie).filter(Boolean);
    var wdMovies = wdIds.map(CIN.findMovie).filter(Boolean);

    // 統計個人觀影足跡（涵蓋幾個地區與累計片長）
    var totalMin = 0;
    var regionSet = {};
    wdMovies.forEach(function (m) {
      totalMin += Number(m.runtime || 115);
      if (m.region) regionSet[m.region] = (regionSet[m.region] || 0) + 1;
    });
    var hours = (totalMin / 60).toFixed(1);
    var regionReached = Object.keys(regionSet).length;
    var activeList = tab === 'watched' ? wdMovies : wlMovies;

    root.innerHTML =
      '<div class="cin-sec-hd">' +
        '<div>' +
          '<h2>📋 我的片單與個人觀影護照</h2>' +
          '<div class="cin-sec-sub">管理你想看的「待看片單」與標註「我看過了」的觀影紀錄，資料自動保存在你的瀏覽器本機</div>' +
        '</div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
          '<button type="button" class="cin-btn cin-btn-sm" id="btnExportMyList">📤 匯出片單備份 (.json)</button>' +
          '<label class="cin-btn cin-btn-sm" style="cursor:pointer;">📥 匯入備份<input type="file" id="inpImportMyList" accept=".json,application/json" style="display:none;" /></label>' +
        '</div>' +
      '</div>' +

      '<div class="cin-stats-grid">' +
        '<div class="cin-stat-box">' +
          '<div class="cin-stat-num">' + wlMovies.length + ' <span style="font-size:14px;color:#78716c;">部</span></div>' +
          '<div class="cin-stat-lbl">📋 待看片單（想看還沒看）</div>' +
        '</div>' +
        '<div class="cin-stat-box">' +
          '<div class="cin-stat-num" style="color:#047857;">' + wdMovies.length + ' <span style="font-size:14px;color:#78716c;">部</span></div>' +
          '<div class="cin-stat-lbl">✅ 我看過了（累計觀影）</div>' +
        '</div>' +
        '<div class="cin-stat-box">' +
          '<div class="cin-stat-num" style="color:#b45309;">' + hours + ' <span style="font-size:14px;color:#78716c;">小時</span></div>' +
          '<div class="cin-stat-lbl">🍿 累計大銀幕時光</div>' +
        '</div>' +
        '<div class="cin-stat-box">' +
          '<div class="cin-stat-num" style="color:#1d4ed8;">' + regionReached + ' / 6 <span style="font-size:14px;color:#78716c;">區</span></div>' +
          '<div class="cin-stat-lbl">🌍 已解鎖世界影壇版圖</div>' +
        '</div>' +
      '</div>' +

      '<div style="display:flex;gap:8px;margin-bottom:18px;">' +
        '<button type="button" class="cin-pill' + (tab === 'watchlist' ? ' active' : '') + '" id="subTabWl" style="font-size:14px;padding:8px 18px;">' +
          '📋 待看片單 (' + wlMovies.length + ')' +
        '</button>' +
        '<button type="button" class="cin-pill' + (tab === 'watched' ? ' active' : '') + '" id="subTabWd" style="font-size:14px;padding:8px 18px;">' +
          '✅ 我看過了 (' + wdMovies.length + ')' +
        '</button>' +
      '</div>' +

      (activeList.length
        ? '<div class="cin-movie-grid">' + activeList.map(function (m) {
            var wInfo = CIN.getWatchedInfo(m.id);
            var noteBanner = '';
            if (tab === 'watched' && wInfo && (wInfo.note || wInfo.myRating)) {
              noteBanner = '<div style="margin-top:8px;padding:8px 12px;background:#ecfdf5;border:1px solid #a7f3d0;border-radius:10px;font-size:12.5px;color:#065f46;">' +
                '<b>我的評分：' + '⭐'.repeat(wInfo.myRating || 5) + '</b>' +
                (wInfo.note ? '<div style="margin-top:3px;">📝 ' + CIN.esc(wInfo.note) + '</div>' : '') +
              '</div>';
            }
            return '<div>' + CIN.renderMovieCard(m) + noteBanner + '</div>';
          }).join('') + '</div>'
        : '<div class="cin-empty">' +
            '<h3>' + (tab === 'watched' ? '你還沒有標註看過的電影' : '你的待看片單目前是空的') + '</h3>' +
            '<p>在「現正上映」或「跨年代片庫」看到感興趣的作品時，點一下卡片上的「➕ 加入片單」或「👀 標註已看」就會收進這裡！</p>' +
            '<div style="display:flex;gap:10px;justify-content:center;margin-top:12px;">' +
              '<button type="button" class="cin-btn cin-btn-sm cin-btn-primary" data-go-route="explore">🎞️ 去跨年代片庫挑片</button>' +
              '<button type="button" class="cin-btn cin-btn-sm" data-go-route="now">🔥 看本週現正上映</button>' +
            '</div>' +
          '</div>');

    document.getElementById('subTabWl').onclick = function () {
      CIN.state.myListTab = 'watchlist';
      CIN.renderMyListPage(root);
    };
    document.getElementById('subTabWd').onclick = function () {
      CIN.state.myListTab = 'watched';
      CIN.renderMyListPage(root);
    };

    var expBtn = document.getElementById('btnExportMyList');
    if (expBtn) {
      expBtn.onclick = function () {
        var blob = new Blob([JSON.stringify({
          exportedAt: new Date().toISOString(),
          watchlist: CIN.state.watchlist,
          watched: CIN.state.watched,
          snapshots: CIN.state.snapshots
        }, null, 2)], { type: 'application/json' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'cinema_academy_mylist_' + new Date().toISOString().slice(0, 10) + '.json';
        a.click();
        CIN.toast('📤 已匯出片單與觀影紀錄備份檔！');
      };
    }

    var impInp = document.getElementById('inpImportMyList');
    if (impInp) {
      impInp.onchange = function (ev) {
        var file = ev.target.files && ev.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function () {
          try {
            var data = JSON.parse(String(reader.result || '{}'));
            if (data.watchlist && typeof data.watchlist === 'object') {
              Object.assign(CIN.state.watchlist, data.watchlist);
              localStorage.setItem('cin.watchlist.v1', JSON.stringify(CIN.state.watchlist));
            }
            if (data.watched && typeof data.watched === 'object') {
              Object.assign(CIN.state.watched, data.watched);
              localStorage.setItem('cin.watched.v1', JSON.stringify(CIN.state.watched));
            }
            if (data.snapshots && typeof data.snapshots === 'object') {
              Object.assign(CIN.state.snapshots, data.snapshots);
              localStorage.setItem('cin.snapshots.v1', JSON.stringify(CIN.state.snapshots));
            }
            CIN.syncHeaderBadges();
            CIN.toast('📥 片單備份匯入成功！');
            CIN.renderMyListPage(root);
          } catch (e) {
            CIN.toast('⚠️ 備份檔格式無法解析');
          }
        };
        reader.readAsText(file);
      };
    }
  };
})();
