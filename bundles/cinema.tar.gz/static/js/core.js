/* 🎬 電影學院核心狀態、分類常數、海報插畫產生器、看點解析彈窗與片單儲存系統 */
(function () {
  'use strict';

  var CIN = window.CIN = window.CIN || {};

  CIN.REGIONS = [
    { id: 'western', label: '🌎 西洋歐美', short: '西洋', desc: '好萊塢經典、歐洲影展大師與當代商業鉅作' },
    { id: 'taiwan', label: '🇹🇼 國片／華語', short: '國片華語', desc: '台灣新電影、金馬代表作與港台經典' },
    { id: 'japan', label: '🇯🇵 日本電影', short: '日本片', desc: '職人寫實、吉卜力／新海誠動畫與推理懸疑' },
    { id: 'korea', label: '🇰🇷 韓國電影', short: '韓國片', desc: '高張力犯罪驚悚、社會寓言與催淚人性作' },
    { id: 'india', label: '🇮🇳 印度電影', short: '印度片', desc: '寶萊塢熱血歌舞、教育省思與神級反轉懸疑' },
    { id: 'thailand', label: '🇹🇭 泰國電影', short: '泰國片', desc: '校園青春、創意黑色幽默與東南亞恐怖巔峰' }
  ];

  CIN.GENRES = [
    { id: 'drama', label: '🎭 劇情人生', short: '劇情', c1: '#7c2d12', c2: '#b45309', icon: '🎭' },
    { id: 'comedy', label: '😂 喜劇歡樂', short: '喜劇', c1: '#b45309', c2: '#eab308', icon: '😂' },
    { id: 'animation', label: '🎨 動畫奇想', short: '動畫', c1: '#0369a1', c2: '#38bdf8', icon: '🎨' },
    { id: 'horror', label: '👻 恐怖靈異', short: '恐怖片', c1: '#18181b', c2: '#991b1b', icon: '👻' },
    { id: 'thriller', label: '🕵️ 懸疑驚悚', short: '懸疑驚悚', c1: '#1e1b4b', c2: '#4338ca', icon: '🕵️' },
    { id: 'scifi', label: '🚀 科幻奇幻', short: '科幻奇幻', c1: '#0f172a', c2: '#0891b2', icon: '🚀' },
    { id: 'action', label: '💥 動作冒險', short: '動作冒險', c1: '#7f1d1d', c2: '#ea580c', icon: '💥' },
    { id: 'romance', label: '💕 愛情溫情', short: '愛情溫情', c1: '#9d174d', c2: '#f43f5e', icon: '💕' },
    { id: 'crime', label: '⚖️ 犯罪歷史', short: '犯罪歷史', c1: '#1c1917', c2: '#57534e', icon: '⚖️' }
  ];

  CIN.DECADES = [
    { id: '1980s', label: '1980 年代', years: '1980–1989', desc: '台灣新電影浪潮、史匹柏與吉卜力黃金起點' },
    { id: '1990s', label: '1990 年代', years: '1990–1999', desc: '非線性敘事革命、港台巔峰與皮克斯3D誕生' },
    { id: '2000s', label: '2000 年代', years: '2000–2009', desc: '亞洲電影席捲國際影展、魔戒與黑暗騎士時代' },
    { id: '2010s', label: '2010 年代', years: '2010–2019', desc: '串流崛起、韓印泰神作爆發與高概念科幻巔峰' },
    { id: '2020s', label: '2020 年代至今', years: '2020–現在', desc: '多重宇宙、後疫情院線大銀幕復興與當代新經典' }
  ];

  CIN.REGION_MAP = {};
  CIN.REGIONS.forEach(function (r) { CIN.REGION_MAP[r.id] = r; });
  CIN.GENRE_MAP = {};
  CIN.GENRES.forEach(function (g) { CIN.GENRE_MAP[g.id] = g; });

  var KEY_WATCHLIST = 'cin.watchlist.v1';
  var KEY_WATCHED = 'cin.watched.v1';
  var KEY_SNAPSHOTS = 'cin.snapshots.v1';
  var KEY_QUIZ_DONE = 'cin.guide.quiz.v1';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  CIN.esc = esc;

  function loadJson(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      if (!raw) return fallback;
      var v = JSON.parse(raw);
      return v && typeof v === 'object' ? v : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function saveJson(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* ignore */ }
  }

  CIN.state = {
    watchlist: loadJson(KEY_WATCHLIST, {}),
    watched: loadJson(KEY_WATCHED, {}),
    snapshots: loadJson(KEY_SNAPSHOTS, {}),
    quizDone: loadJson(KEY_QUIZ_DONE, {}),
    exploreFilter: {
      region: 'all',
      genre: 'all',
      decade: 'all',
      status: 'all',
      q: '',
      sort: 'rating'
    },
    nowFilter: {
      runCat: 'all',
      region: 'all',
      genre: 'all',
      status: 'all',
      q: '',
      sort: 'theaters'
    },
    myListTab: 'watchlist'
  };

  CIN.getCatalogMovies = function () {
    return Array.isArray(window.CIN_MOVIES) ? window.CIN_MOVIES : [];
  };

  CIN.getNowPlayingPayload = function () {
    return window.CIN_NOW_PLAYING && typeof window.CIN_NOW_PLAYING === 'object'
      ? window.CIN_NOW_PLAYING
      : { updatedAt: '本週最新', weekKey: '', scheduleNote: '每週自動更新', count: 0, items: [] };
  };

  CIN.getNowPlayingMovies = function () {
    var p = CIN.getNowPlayingPayload();
    return Array.isArray(p.items) ? p.items : [];
  };

  CIN.findMovie = function (id) {
    if (!id) return null;
    var cat = CIN.getCatalogMovies();
    for (var i = 0; i < cat.length; i++) {
      if (cat[i].id === id) return cat[i];
    }
    var nows = CIN.getNowPlayingMovies();
    for (var j = 0; j < nows.length; j++) {
      if (nows[j].id === id) return nows[j];
    }
    if (CIN.state.snapshots && CIN.state.snapshots[id]) {
      return CIN.state.snapshots[id];
    }
    return null;
  };

  function rememberSnapshotIfNeeded(id) {
    if (!id || id.indexOf('now-') !== 0) return;
    var m = CIN.findMovie(id);
    if (m) {
      CIN.state.snapshots[id] = m;
      saveJson(KEY_SNAPSHOTS, CIN.state.snapshots);
    }
  }

  CIN.recordCampusAct = function () {
    try {
      if (window.CampusNav && typeof window.CampusNav.recordAct === 'function') {
        window.CampusNav.recordAct('cinema');
      } else if (window.CampusNav && typeof window.CampusNav.bumpAct === 'function') {
        window.CampusNav.bumpAct('cinema');
      }
    } catch (e) { /* ignore */ }
  };

  CIN.toast = function (msg) {
    var el = document.getElementById('cinToast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(function () { el.classList.remove('show'); }, 2600);
  };

  CIN.isInWatchlist = function (id) {
    return !!(CIN.state.watchlist && CIN.state.watchlist[id]);
  };

  CIN.isWatched = function (id) {
    return !!(CIN.state.watched && CIN.state.watched[id]);
  };

  CIN.getWatchedInfo = function (id) {
    return (CIN.state.watched && CIN.state.watched[id]) || null;
  };

  CIN.syncHeaderBadges = function () {
    var wlCnt = Object.keys(CIN.state.watchlist || {}).length;
    var wdCnt = Object.keys(CIN.state.watched || {}).length;
    var nowCnt = CIN.getNowPlayingMovies().length;
    var totCnt = CIN.getCatalogMovies().length;
    var elWl = document.getElementById('hdrWatchlistCnt');
    var elWd = document.getElementById('hdrWatchedCnt');
    var elNow = document.getElementById('navNowCnt');
    var elTot = document.getElementById('navTotalCnt');
    var elMy = document.getElementById('navMyCnt');
    if (elWl) elWl.textContent = String(wlCnt);
    if (elWd) elWd.textContent = String(wdCnt);
    if (elNow) elNow.textContent = String(nowCnt);
    if (elTot) elTot.textContent = String(totCnt);
    if (elMy) elMy.textContent = String(wlCnt + wdCnt);
  };

  CIN.saveQuizDone = function (idx) {
    CIN.state.quizDone = CIN.state.quizDone || {};
    CIN.state.quizDone[String(idx)] = 1;
    saveJson(KEY_QUIZ_DONE, CIN.state.quizDone);
    CIN.recordCampusAct();
  };

  CIN.toggleWatchlist = function (id) {
    var m = CIN.findMovie(id);
    var title = m ? m.title : id;
    if (CIN.state.watchlist[id]) {
      delete CIN.state.watchlist[id];
      saveJson(KEY_WATCHLIST, CIN.state.watchlist);
      CIN.syncHeaderBadges();
      CIN.toast('已從待看片單移除《' + title + '》');
      return false;
    } else {
      rememberSnapshotIfNeeded(id);
      CIN.state.watchlist[id] = {
        addedAt: new Date().toISOString().slice(0, 10),
        region: m ? (m.region || '') : ''
      };
      saveJson(KEY_WATCHLIST, CIN.state.watchlist);
      CIN.syncHeaderBadges();
      CIN.recordCampusAct();
      CIN.toast('📋 已加入我的待看片單：《' + title + '》');
      return true;
    }
  };

  CIN.toggleWatched = function (id, optRating, optNote) {
    var m = CIN.findMovie(id);
    var title = m ? m.title : id;
    if (CIN.state.watched[id] && optRating === undefined && optNote === undefined) {
      delete CIN.state.watched[id];
      saveJson(KEY_WATCHED, CIN.state.watched);
      CIN.syncHeaderBadges();
      CIN.toast('已取消「我看過了」標記：《' + title + '》');
      return false;
    } else {
      rememberSnapshotIfNeeded(id);
      var prev = CIN.state.watched[id] || {};
      CIN.state.watched[id] = {
        watchedAt: prev.watchedAt || new Date().toISOString().slice(0, 10),
        myRating: optRating != null ? Number(optRating) : (prev.myRating || 5),
        note: optNote != null ? String(optNote) : (prev.note || ''),
        region: (m && m.region) || prev.region || ''
      };
      saveJson(KEY_WATCHED, CIN.state.watched);
      CIN.syncHeaderBadges();
      CIN.recordCampusAct();
      CIN.toast('✅ 已標記我看過了：《' + title + '》');
      return true;
    }
  };

  CIN.saveWatchedNote = function (id, rating, note) {
    rememberSnapshotIfNeeded(id);
    var m = CIN.findMovie(id);
    var prev = CIN.state.watched[id] || {};
    CIN.state.watched[id] = {
      watchedAt: prev.watchedAt || new Date().toISOString().slice(0, 10),
      myRating: Number(rating) || 5,
      note: String(note || '').trim().slice(0, 500),
      region: (m && m.region) || prev.region || ''
    };
    saveJson(KEY_WATCHED, CIN.state.watched);
    CIN.syncHeaderBadges();
    CIN.recordCampusAct();
    CIN.toast('💾 已儲存個人星等與觀影筆記！');
  };

  /* 產生每部電影專屬的戲院底片插畫 SVG 海報（免外部圖床、100% 離線可用） */
  CIN.posterSvg = function (m) {
    var mainG = (m.genres && m.genres[0]) || 'drama';
    var gm = CIN.GENRE_MAP[mainG] || CIN.GENRE_MAP.drama;
    var rm = CIN.REGION_MAP[m.region] || CIN.REGION_MAP.western;
    var seed = 0;
    var sid = String(m.id || m.title || '');
    for (var i = 0; i < sid.length; i++) seed = (seed * 31 + sid.charCodeAt(i)) & 0xffff;
    var cx = 240 + (seed % 80);
    var cy = 50 + ((seed >> 4) % 55);
    var gradId = 'pg-' + sid.replace(/[^a-zA-Z0-9_-]/g, '');
    var rawTitle = String(m.title || '');
    var shortTitle = rawTitle.length > 12 ? rawTitle.slice(0, 11) + '…' : rawTitle;
    var titleFontSz = rawTitle.length > 10 ? 20 : 22;
    var yr = esc(m.year || '');
    var holes = '';
    for (var x = 14; x < 350; x += 26) {
      holes += '<rect x="' + x + '" y="7" width="12" height="7" rx="2" fill="rgba(255,255,255,0.22)"/>';
      holes += '<rect x="' + x + '" y="210" width="12" height="7" rx="2" fill="rgba(255,255,255,0.22)"/>';
    }
    return (
      '<svg class="cin-poster-svg" viewBox="0 0 360 224" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">' +
        '<defs>' +
          '<linearGradient id="' + gradId + '" x1="0" y1="0" x2="1" y2="1">' +
            '<stop offset="0%" stop-color="' + gm.c1 + '"/>' +
            '<stop offset="100%" stop-color="' + gm.c2 + '"/>' +
          '</linearGradient>' +
        '</defs>' +
        '<rect width="360" height="224" fill="url(#' + gradId + ')"/>' +
        '<circle cx="' + cx + '" cy="' + (cy + 22) + '" r="76" fill="rgba(255,255,255,0.08)"/>' +
        '<circle cx="' + (cx - 110) + '" cy="' + (cy + 85) + '" r="54" fill="rgba(0,0,0,0.16)"/>' +
        holes +
        '<text x="20" y="132" font-size="' + titleFontSz + '" font-weight="900" fill="#ffffff" opacity="0.96">' + esc(shortTitle) + '</text>' +
        '<text x="20" y="158" font-size="12.5" font-weight="700" fill="rgba(255,255,255,0.84)">' +
          yr + ' · ' + esc(m.country || rm.short) + ' · ' + esc(m.director || '') +
        '</text>' +
        '<text x="320" y="144" font-size="36" text-anchor="middle" opacity="0.88">' + gm.icon + '</text>' +
      '</svg>'
    );
  };

  CIN.apiBase = function () {
    var ms = document.querySelector && document.querySelector('script[data-campus-mount]');
    if (ms) {
      var mnt = ms.getAttribute('data-campus-mount');
      if (mnt) return '/' + mnt + '/api/';
    }
    return 'api/';
  };

  CIN.useLocalImgProxy = function () {
    if (window.CAMPUS_STATIC_ONLY) return false;
    var loc = window.location || {};
    var proto = String(loc.protocol || '');
    var host = String(loc.hostname || '').toLowerCase();
    if (proto.indexOf('http') !== 0) return false;
    if (host.indexOf('github.io') !== -1) return false;
    return true;
  };

  CIN.resolveImgUrl = function (rawUrl) {
    var u = String(rawUrl || '').trim();
    if (!u || u.indexOf('http') !== 0) return '';
    if (CIN.useLocalImgProxy()) {
      return CIN.apiBase() + 'poster?u=' + encodeURIComponent(u);
    }
    return u;
  };

  CIN.onPosterLoad = function (imgEl) {
    if (!imgEl) return;
    var realBox = imgEl.closest ? imgEl.closest('.cin-poster-real') : null;
    if (realBox) realBox.classList.add('is-loaded');
    var wrap = imgEl.closest ? imgEl.closest('.cin-poster-wrap') : null;
    if (wrap) wrap.classList.add('is-poster-ready');
    var modalCol = imgEl.closest ? imgEl.closest('.cin-modal-poster-col') : null;
    if (modalCol) modalCol.classList.add('is-loaded');
  };

  /* 海報圖片載入失敗時自動降級（優先切換直連／備援海報，完全離線時無縫退回插畫海報） */
  CIN.onPosterError = function (imgEl) {
    if (!imgEl) return;
    var syncBg = function (nextSrc) {
      var rb = imgEl.closest ? imgEl.closest('.cin-poster-real') : null;
      var bg = rb ? rb.querySelector('.cin-poster-bg') : null;
      if (bg) bg.src = nextSrc;
    };
    var direct = imgEl.getAttribute('data-direct') || '';
    if (direct && imgEl.getAttribute('data-tried-direct') !== '1' && imgEl.src !== direct) {
      imgEl.setAttribute('data-tried-direct', '1');
      imgEl.src = direct;
      syncBg(direct);
      return;
    }
    var fb = imgEl.getAttribute('data-fb') || '';
    if (fb && imgEl.getAttribute('data-tried-fb') !== '1') {
      imgEl.setAttribute('data-tried-fb', '1');
      var fbResolved = CIN.resolveImgUrl(fb);
      imgEl.setAttribute('data-direct-fb', fb);
      imgEl.src = fbResolved;
      syncBg(fbResolved);
      return;
    }
    var directFb = imgEl.getAttribute('data-direct-fb') || '';
    if (directFb && imgEl.getAttribute('data-tried-direct-fb') !== '1' && imgEl.src !== directFb) {
      imgEl.setAttribute('data-tried-direct-fb', '1');
      imgEl.src = directFb;
      syncBg(directFb);
      return;
    }
    var box = imgEl.closest ? imgEl.closest('.cin-poster-real') : null;
    if (box) {
      box.classList.remove('is-loaded');
      box.classList.add('is-broken');
    }
    var wrap = imgEl.closest ? imgEl.closest('.cin-poster-wrap') : null;
    if (wrap) wrap.classList.remove('is-poster-ready');
    var modalCol = imgEl.closest ? imgEl.closest('.cin-modal-poster-col') : null;
    if (modalCol) modalCol.classList.remove('is-loaded');
  };

  CIN.onStillError = function (imgEl) {
    if (!imgEl) return;
    var direct = imgEl.getAttribute('data-direct') || '';
    if (direct && imgEl.getAttribute('data-tried-direct') !== '1' && imgEl.src !== direct) {
      imgEl.setAttribute('data-tried-direct', '1');
      imgEl.src = direct;
      return;
    }
    imgEl.style.display = 'none';
  };

  function formatSynopsisHtml(syn) {
    var raw = String(syn || '').trim();
    if (!raw) return '<p class="cin-syn-para"></p>';
    return raw.split(/\n{2,}/).map(function (p) {
      return '<p class="cin-syn-para">' + esc(p.replace(/\n+/g, ' ').trim()) + '</p>';
    }).join('');
  }

  /* 共用電影卡片渲染（真實電影海報＋模糊氛圍背板、完整劇情簡介、一鍵加入片單與標註已看） */
  CIN.renderMovieCard = function (m) {
    var inList = CIN.isInWatchlist(m.id);
    var watched = CIN.isWatched(m.id);
    var wInfo = CIN.getWatchedInfo(m.id);
    var rm = CIN.REGION_MAP[m.region] || CIN.REGION_MAP.western;
    var gChips = (m.genres || []).map(function (gid) {
      var g = CIN.GENRE_MAP[gid];
      return '<span class="cin-chip genre">' + esc(g ? g.short : gid) + '</span>';
    }).join('');
    var statusBadge = '';
    var inlineStatus = '';
    if (watched) {
      var stars = wInfo && wInfo.myRating ? ' ' + '★'.repeat(wInfo.myRating) : '';
      statusBadge = '<span class="cin-badge-status watched">✅ 已看過' + esc(stars) + '</span>';
      inlineStatus = '<span class="cin-badge-status watched cin-badge-inline">✅ 已看過' + esc(stars) + '</span>';
    } else if (inList) {
      statusBadge = '<span class="cin-badge-status watchlist">📋 待看片單</span>';
      inlineStatus = '<span class="cin-badge-status watchlist cin-badge-inline">📋 待看片單</span>';
    }
    var nowBadge = m.isNowPlaying
      ? '<span class="cin-badge-now">🔥 ' + esc(m.statusBadge || '現正上映') + '</span>'
      : '';
    var inlineNow = m.isNowPlaying
      ? '<span class="cin-badge-now cin-badge-inline">🔥 ' + esc(m.statusBadge || '現正上映') + '</span>'
      : '';
    var hl0 = (m.analysis && m.analysis.highlights && m.analysis.highlights[0]) || '';
    if (hl0.length > 62) hl0 = hl0.slice(0, 61) + '…';

    var hasPoster = !!(m.poster && String(m.poster).indexOf('http') === 0);
    var realPosterHtml = '';
    if (hasPoster) {
      var posterSrc = CIN.resolveImgUrl(m.poster);
      var castStr = (m.cast && m.cast.length) ? '主演：' + m.cast.slice(0, 3).join('、') : '';
      realPosterHtml =
        '<div class="cin-poster-real">' +
          '<img class="cin-poster-bg" src="' + esc(posterSrc) + '" alt="" aria-hidden="true" loading="lazy" decoding="async" referrerpolicy="no-referrer" />' +
          '<div class="cin-poster-shade"></div>' +
          '<div class="cin-poster-stage">' +
            '<img class="cin-poster-img" src="' + esc(posterSrc) + '" data-direct="' + esc(m.poster) + '" data-fb="' + esc(m.posterFallback || '') + '" alt="《' + esc(m.title) + '》電影海報" loading="lazy" decoding="async" referrerpolicy="no-referrer" onload="window.CIN.onPosterLoad(this)" onerror="window.CIN.onPosterError(this)" />' +
            '<div class="cin-poster-side">' +
              '<div class="cin-poster-side-top">' +
                '<span class="cin-badge-region">' + esc(rm.label) + '</span>' +
                '<span class="cin-badge-score">★ ' + esc((m.rating || 7.8).toFixed(1)) + '</span>' +
              '</div>' +
              '<div class="cin-poster-side-meta">' +
                '<div class="cin-poster-side-yr">' + esc(m.year) + (m.country ? ' · ' + esc(m.country) : '') + (m.runtime ? ' · ' + esc(m.runtime) + '分' : '') + '</div>' +
                (m.director ? '<div class="cin-poster-side-dir">🎬 導演：' + esc(m.director) + '</div>' : '') +
                (castStr ? '<div class="cin-poster-side-cast">' + esc(castStr) + '</div>' : '') +
              '</div>' +
              '<div class="cin-poster-side-btm">' +
                inlineNow +
                inlineStatus +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';
    }

    var cardSynTxt = String(m.synopsis || '').replace(/\n{2,}/g, '　').replace(/\n+/g, ' ');

    return (
      '<article class="cin-card' + (watched ? ' is-watched' : '') + '" data-movie-id="' + esc(m.id) + '">' +
        '<div class="cin-poster-wrap" data-open-movie="' + esc(m.id) + '">' +
          CIN.posterSvg(m) +
          realPosterHtml +
          '<div class="cin-poster-badges">' +
            '<span class="cin-badge-region">' + esc(rm.label) + '</span>' +
            '<span class="cin-badge-score">★ ' + esc((m.rating || 7.8).toFixed(1)) + '</span>' +
          '</div>' +
          nowBadge +
          statusBadge +
        '</div>' +
        '<div class="cin-card-body">' +
          '<div class="cin-card-title-row" data-open-movie="' + esc(m.id) + '">' +
            '<h3 class="cin-card-title">' + esc(m.title) + ' <span style="font-weight:700;font-size:13px;color:#78716c;">(' + esc(m.year) + ')</span></h3>' +
            '<div class="cin-card-orig">' + esc(m.origTitle || '') + (m.runtime ? ' · ' + esc(m.runtime) + ' 分鐘' : '') + '</div>' +
          '</div>' +
          '<div class="cin-card-meta">' +
            '<span class="cin-chip">' + esc(m.decade || '') + '</span>' +
            gChips +
          '</div>' +
          (m.tagline ? '<div class="cin-card-tagline">「' + esc(m.tagline) + '」</div>' : '') +
          '<p class="cin-card-syn">' + esc(cardSynTxt) + '</p>' +
          (hl0
            ? '<div class="cin-card-hl-preview" data-open-movie="' + esc(m.id) + '"><b>🔍 看點解析：</b>' + esc(hl0) + ' <span style="text-decoration:underline;">展開全文 →</span></div>'
            : '') +
          '<div class="cin-card-actions">' +
            '<button type="button" class="cin-act-btn' + (inList ? ' in-list' : '') + '" data-toggle-watchlist="' + esc(m.id) + '">' +
              (inList ? '📋 已在片單' : '➕ 加入片單') +
            '</button>' +
            '<button type="button" class="cin-act-btn' + (watched ? ' is-seen' : '') + '" data-toggle-watched="' + esc(m.id) + '">' +
              (watched ? '✅ 我看過了' : '👀 標註已看') +
            '</button>' +
            '<button type="button" class="cin-act-btn detail" data-open-movie="' + esc(m.id) + '" title="查看完整看點解析">解析</button>' +
          '</div>' +
        '</div>' +
      '</article>'
    );
  };

  /* 開啟單部電影深度看點解析 Modal */
  CIN.openMovieModal = function (id) {
    var m = CIN.findMovie(id);
    if (!m) return;
    CIN.recordCampusAct();
    var backdrop = document.getElementById('movieModal');
    var card = document.getElementById('movieModalCard');
    if (!backdrop || !card) return;

    function renderModalContent() {
      var inList = CIN.isInWatchlist(m.id);
      var watched = CIN.isWatched(m.id);
      var wInfo = CIN.getWatchedInfo(m.id) || { myRating: 5, note: '' };
      var rm = CIN.REGION_MAP[m.region] || CIN.REGION_MAP.western;
      var gTags = (m.genres || []).map(function (gid) {
        var g = CIN.GENRE_MAP[gid];
        return '<span class="cin-chip genre">' + esc(g ? g.label : gid) + '</span>';
      }).join(' ');
      var moods = (m.mood || []).map(function (md) {
        return '<span class="cin-chip">#' + esc(md) + '</span>';
      }).join(' ');
      var hls = ((m.analysis && m.analysis.highlights) || []).map(function (h) {
        return '<li>' + esc(h) + '</li>';
      }).join('');
      var starHtml = '';
      var curStar = wInfo.myRating || 5;
      for (var s = 1; s <= 5; s++) {
        starHtml += '<button type="button" class="cin-star-btn" data-set-star="' + s + '" title="' + s + ' 顆星">' +
          (s <= curStar ? '⭐' : '☆') + '</button>';
      }

      var hasModalPoster = !!(m.poster && String(m.poster).indexOf('http') === 0);
      var modalPosterSrc = hasModalPoster ? CIN.resolveImgUrl(m.poster) : '';
      var modalPosterCol = hasModalPoster
        ? '<div class="cin-modal-poster-col">' +
            '<img class="cin-modal-poster-img" src="' + esc(modalPosterSrc) + '" data-direct="' + esc(m.poster) + '" data-fb="' + esc(m.posterFallback || '') + '" alt="《' + esc(m.title) + '》海報" referrerpolicy="no-referrer" onload="window.CIN.onPosterLoad(this)" onerror="window.CIN.onPosterError(this)" />' +
          '</div>'
        : '';

      var stillsHtml = '';
      if (m.stills && m.stills.length) {
        stillsHtml =
          '<div class="cin-analysis-block">' +
            '<h4>🎞️ 院線精彩劇照</h4>' +
            '<div class="cin-stills-grid">' +
              m.stills.map(function (su, idx) {
                var stSrc = CIN.resolveImgUrl(su);
                return '<img class="cin-still-img" src="' + esc(stSrc) + '" data-direct="' + esc(su) + '" alt="《' + esc(m.title) + '》劇照 ' + (idx + 1) + '" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="window.CIN.onStillError(this)" />';
              }).join('') +
            '</div>' +
          '</div>';
      }

      card.innerHTML =
        '<button type="button" class="cin-modal-close" id="closeMovieModalBtn" aria-label="關閉">✕</button>' +
        '<div class="cin-modal-hero">' +
          '<div class="cin-modal-hero-flex">' +
            modalPosterCol +
            '<div class="cin-modal-info-col">' +
              '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">' +
                '<span class="cin-sub-pill">' + esc(rm.label) + (m.country ? ' · ' + esc(m.country) : '') + '</span>' +
                '<span class="cin-chip">' + esc(m.year) + ' (' + esc(m.decade) + ')</span>' +
                (m.runtime ? '<span class="cin-chip">⏱️ ' + esc(m.runtime) + ' 分鐘</span>' : '') +
                '<span class="cin-chip" style="background:#fef3c7;color:#92400e;">★ 經典指數 ' + esc((m.rating || 7.8).toFixed(1)) + '</span>' +
                (m.isNowPlaying ? '<span class="cin-chip" style="background:#be123c;color:#fff;">🔥 ' + esc(m.statusBadge || '現正上映') + '</span>' : '') +
              '</div>' +
              '<h2 id="movieModalTitle" style="margin:0 0 4px;font-size:24px;font-weight:900;">' + esc(m.title) + '</h2>' +
              '<div style="font-size:13.5px;color:#57534e;margin-bottom:10px;">' +
                esc(m.origTitle || '') +
                (m.director ? ' ｜ 導演：<b>' + esc(m.director) + '</b>' : '') +
                (m.cast && m.cast.length ? ' ｜ 主演：' + esc(m.cast.join('、')) : '') +
                (m.releaseDate ? ' ｜ 上映日：' + esc(m.releaseDate) : '') +
              '</div>' +
              '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;">' + gTags + ' ' + moods + '</div>' +
              '<div style="display:flex;gap:10px;flex-wrap:wrap;">' +
                '<button type="button" class="cin-btn ' + (inList ? '' : 'cin-btn-primary') + '" id="modalWlBtn">' +
                  (inList ? '📋 已在我的待看片單（點擊移除）' : '➕ 加入我的待看片單') +
                '</button>' +
                '<button type="button" class="cin-btn" id="modalWdBtn" style="' + (watched ? 'background:#ecfdf5;border-color:#6ee7b7;color:#047857;' : '') + '">' +
                  (watched ? '✅ 已標註「我看過了」（點擊取消）' : '👀 標註「我看過了」') +
                '</button>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="cin-modal-body">' +
          (m.tagline ? '<p style="font-size:15.5px;font-weight:800;color:#9f1239;margin:0 0 12px;">❝ ' + esc(m.tagline) + ' ❞</p>' : '') +
          '<div class="cin-analysis-block">' +
            '<h4>📖 不暴雷劇情簡介</h4>' +
            formatSynopsisHtml(m.synopsis) +
          '</div>' +
          stillsHtml +
          '<div class="cin-analysis-block">' +
            '<h4>🔍 三大必看亮點解析（觀影前／觀影後看門道）</h4>' +
            '<ol class="cin-hl-list">' + hls + '</ol>' +
          '</div>' +
          '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;">' +
            '<div class="cin-analysis-block" style="margin-bottom:0;">' +
              '<h4>🎥 鏡頭調度、剪輯與配樂美學</h4>' +
              '<p style="margin:0;font-size:13.8px;color:#44403c;">' + esc((m.analysis && m.analysis.craft) || '') + '</p>' +
            '</div>' +
            '<div class="cin-analysis-block" style="margin-bottom:0;">' +
              '<h4>🏆 影史地位與文化影響力</h4>' +
              '<p style="margin:0;font-size:13.8px;color:#44403c;">' + esc((m.analysis && m.analysis.legacy) || '') + '</p>' +
            '</div>' +
          '</div>' +
          '<div class="cin-note-box">' +
            '<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px;">' +
              '<strong style="font-size:14px;">📝 我的觀影評分與私房筆記（自動標註「我看過了」並儲存在本機）</strong>' +
              '<div class="cin-stars" id="modalStarRow" data-cur-star="' + curStar + '">' + starHtml + '</div>' +
            '</div>' +
            '<textarea id="modalNoteInput" class="cin-input" rows="2" placeholder="寫下看完這部電影的感想、最愛的一幕或和誰一起看的回憶…">' + esc(wInfo.note || '') + '</textarea>' +
            '<div style="margin-top:8px;display:flex;justify-content:flex-end;">' +
              '<button type="button" class="cin-btn cin-btn-sm cin-btn-primary" id="modalSaveNoteBtn">💾 儲存評分與觀影筆記</button>' +
            '</div>' +
          '</div>' +
        '</div>';

      document.getElementById('closeMovieModalBtn').onclick = CIN.closeMovieModal;
      document.getElementById('modalWlBtn').onclick = function () {
        CIN.toggleWatchlist(m.id);
        renderModalContent();
        if (typeof CIN.refreshCurrentView === 'function') CIN.refreshCurrentView();
      };
      document.getElementById('modalWdBtn').onclick = function () {
        CIN.toggleWatched(m.id);
        renderModalContent();
        if (typeof CIN.refreshCurrentView === 'function') CIN.refreshCurrentView();
      };
      var starRow = document.getElementById('modalStarRow');
      starRow.querySelectorAll('[data-set-star]').forEach(function (btn) {
        btn.onclick = function () {
          var st = Number(btn.getAttribute('data-set-star')) || 5;
          starRow.setAttribute('data-cur-star', String(st));
          starRow.querySelectorAll('[data-set-star]').forEach(function (b2) {
            var v2 = Number(b2.getAttribute('data-set-star'));
            b2.textContent = v2 <= st ? '⭐' : '☆';
          });
        };
      });
      document.getElementById('modalSaveNoteBtn').onclick = function () {
        var st = Number(starRow.getAttribute('data-cur-star')) || 5;
        var note = document.getElementById('modalNoteInput').value;
        CIN.saveWatchedNote(m.id, st, note);
        renderModalContent();
        if (typeof CIN.refreshCurrentView === 'function') CIN.refreshCurrentView();
      };
    }

    renderModalContent();
    backdrop.classList.add('open');
  };

  CIN.closeMovieModal = function () {
    var backdrop = document.getElementById('movieModal');
    if (backdrop) backdrop.classList.remove('open');
  };
})();
