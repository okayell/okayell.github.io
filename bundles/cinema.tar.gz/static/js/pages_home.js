/* 🏛️ 推薦與選片首頁（智慧選片器、現正上映焦點、六大地區傳送門、九大類型與 1980s-2020s 年代時光機） */
(function () {
  'use strict';
  var CIN = window.CIN;

  CIN.renderHomePage = function (root) {
    var catalog = CIN.getCatalogMovies();
    var nowPayload = CIN.getNowPlayingPayload();
    var nowMovies = CIN.getNowPlayingMovies();
    var wlCnt = Object.keys(CIN.state.watchlist || {}).length;
    var wdCnt = Object.keys(CIN.state.watched || {}).length;

    // 精選推薦：挑出尚未看過且高分跨地區代表作 6 部
    var featured = catalog
      .filter(function (m) { return !CIN.isWatched(m.id); })
      .slice()
      .sort(function (a, b) { return (b.rating || 0) - (a.rating || 0); });

    // 確保 6 大地區各挑一部代表作當作鎮館推薦
    var curatedTop = [];
    var usedRegions = {};
    for (var i = 0; i < featured.length && curatedTop.length < 6; i++) {
      var fm = featured[i];
      if (!usedRegions[fm.region]) {
        usedRegions[fm.region] = true;
        curatedTop.push(fm);
      }
    }
    for (var j = 0; j < featured.length && curatedTop.length < 6; j++) {
      if (curatedTop.indexOf(featured[j]) === -1) curatedTop.push(featured[j]);
    }

    var regionPortals = CIN.REGIONS.map(function (r) {
      var cnt = catalog.filter(function (m) { return m.region === r.id; }).length;
      return (
        '<button type="button" class="cin-portal-card" data-jump-region="' + CIN.esc(r.id) + '">' +
          '<div class="cin-portal-top">' +
            '<span>' + CIN.esc(r.label) + '</span>' +
            '<span class="cin-portal-cnt">' + cnt + ' 部</span>' +
          '</div>' +
          '<div class="cin-portal-desc">' + CIN.esc(r.desc) + '</div>' +
        '</button>'
      );
    }).join('');

    var genrePortals = CIN.GENRES.map(function (g) {
      var cnt = catalog.filter(function (m) { return (m.genres || []).indexOf(g.id) !== -1; }).length;
      return (
        '<button type="button" class="cin-portal-card" data-jump-genre="' + CIN.esc(g.id) + '">' +
          '<div class="cin-portal-top">' +
            '<span>' + CIN.esc(g.label) + '</span>' +
            '<span class="cin-portal-cnt">' + cnt + ' 部</span>' +
          '</div>' +
          '<div class="cin-portal-desc">點擊瀏覽跨國' + CIN.esc(g.short) + '代表作與看點解析</div>' +
        '</button>'
      );
    }).join('');

    var decadePortals = CIN.DECADES.map(function (d) {
      var cnt = catalog.filter(function (m) { return m.decade === d.id; }).length;
      return (
        '<button type="button" class="cin-portal-card" data-jump-decade="' + CIN.esc(d.id) + '">' +
          '<div class="cin-portal-top">' +
            '<span>🎞️ ' + CIN.esc(d.label) + '</span>' +
            '<span class="cin-portal-cnt">' + cnt + ' 部</span>' +
          '</div>' +
          '<div class="cin-portal-desc">' + CIN.esc(d.desc) + '</div>' +
        '</button>'
      );
    }).join('');

    var nowSpotlight = nowMovies.slice(0, 3).map(CIN.renderMovieCard).join('');
    var curatedHtml = curatedTop.map(CIN.renderMovieCard).join('');

    var regionOpts = '<option value="all">🌎 不限地區（全球影壇）</option>' +
      CIN.REGIONS.map(function (r) { return '<option value="' + r.id + '">' + CIN.esc(r.label) + '</option>'; }).join('');
    var genreOpts = '<option value="all">🎭 不限類型</option>' +
      CIN.GENRES.map(function (g) { return '<option value="' + g.id + '">' + CIN.esc(g.label) + '</option>'; }).join('');
    var decadeOpts = '<option value="all">🕰️ 不限年代（1980s–2020s）</option>' +
      CIN.DECADES.map(function (d) { return '<option value="' + d.id + '">' + CIN.esc(d.label) + '</option>'; }).join('');

    root.innerHTML =
      '<section class="cin-hero">' +
        '<div>' +
          '<div class="cin-hero-eyebrow">🎬 開心學園 · 影視娛樂學區 · 每週自動同步院線</div>' +
          '<h1>從 1980 年代影史經典到本週院線新片，看懂每一部好電影的門道</h1>' +
          '<p>橫跨<b>西洋、國片／華語、日本、韓國、印度、泰國</b>六大影壇與九大類型，每部電影皆附<b>不暴雷看點解析、鏡頭美學與影史地位</b>；隨時加入「我的片單」或標註「我看過了」累積你的專屬觀影護照！</p>' +
          '<div class="cin-hero-actions">' +
            '<button type="button" class="cin-btn cin-btn-primary" data-go-route="now">🔥 看本週現正上映 (' + nowMovies.length + ')</button>' +
            '<button type="button" class="cin-btn" data-go-route="explore">🎞️ 探索 1980s–2020s 完整片庫 (' + catalog.length + ')</button>' +
            '<button type="button" class="cin-btn" data-go-route="my-list">📋 我的片單 (' + wlCnt + ') · 已看 (' + wdCnt + ')</button>' +
          '</div>' +
        '</div>' +
        '<div class="cin-picker-card">' +
          '<div class="cin-picker-title">' +
            '<span>🎲 今晚看什麼？3 秒智慧選片器</span>' +
            '<span style="font-size:11.5px;color:#78716c;">自動避開已看過</span>' +
          '</div>' +
          '<div class="cin-picker-row">' +
            '<select id="pickRegion" class="cin-select" aria-label="選擇地區">' + regionOpts + '</select>' +
            '<select id="pickGenre" class="cin-select" aria-label="選擇類型">' + genreOpts + '</select>' +
          '</div>' +
          '<div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;">' +
            '<select id="pickDecade" class="cin-select" aria-label="選擇年代">' + decadeOpts + '</select>' +
          '</div>' +
          '<label style="display:flex;align-items:center;gap:6px;font-size:12.5px;color:#57534e;margin-bottom:10px;cursor:pointer;">' +
            '<input type="checkbox" id="pickHideWatched" checked /> 只推薦我「還沒看過」的電影' +
          '</label>' +
          '<button type="button" class="cin-btn cin-btn-primary" style="width:100%;" id="btnRunPicker">🍿 幫我抽一部必看好片並打開解析！</button>' +
        '</div>' +
      '</section>' +

      (nowMovies.length ? (
        '<section class="cin-sec">' +
          '<div class="cin-sec-hd">' +
            '<div>' +
              '<h2>🔥 本週院線現正上映焦點</h2>' +
              '<div class="cin-sec-sub">更新時間：' + CIN.esc(nowPayload.updatedAt || '') + ' ｜ ' + CIN.esc(nowPayload.scheduleNote || '每週自動更新') + '</div>' +
            '</div>' +
            '<button type="button" class="cin-btn cin-btn-sm" data-go-route="now">查看全部 ' + nowMovies.length + ' 部上映電影 →</button>' +
          '</div>' +
          '<div class="cin-movie-grid">' + nowSpotlight + '</div>' +
        '</section>'
      ) : '') +

      '<section class="cin-sec">' +
        '<div class="cin-sec-hd">' +
          '<div>' +
            '<h2>🌟 六大影壇鎮館必看推薦</h2>' +
            '<div class="cin-sec-sub">從你尚未標註看過的片單中，為每個地區精選最高評價的代表作</div>' +
          '</div>' +
          '<button type="button" class="cin-btn cin-btn-sm" data-go-route="explore">瀏覽全部片庫 →</button>' +
        '</div>' +
        '<div class="cin-movie-grid">' + curatedHtml + '</div>' +
      '</section>' +

      '<section class="cin-sec">' +
        '<div class="cin-sec-hd">' +
          '<h2>🌍 依國家／地區影壇分類探索</h2>' +
          '<span class="cin-sec-sub">點擊任一地區立即篩選代表電影與看點解析</span>' +
        '</div>' +
        '<div class="cin-portal-grid">' + regionPortals + '</div>' +
      '</section>' +

      '<section class="cin-sec">' +
        '<div class="cin-sec-hd">' +
          '<h2>🎭 依電影類型分類探索</h2>' +
          '<span class="cin-sec-sub">喜劇、動畫、恐怖片、懸疑驚悚、科幻奇幻、動作、劇情、愛情、犯罪</span>' +
        '</div>' +
        '<div class="cin-portal-grid">' + genrePortals + '</div>' +
      '</section>' +

      '<section class="cin-sec">' +
        '<div class="cin-sec-hd">' +
          '<h2>🕰️ 1980 年代至今：影史時光機</h2>' +
          '<span class="cin-sec-sub">橫跨五個世代的世界電影演進</span>' +
        '</div>' +
        '<div class="cin-portal-grid">' + decadePortals + '</div>' +
      '</section>';

    // Bind Smart Picker
    var btnPick = document.getElementById('btnRunPicker');
    if (btnPick) {
      btnPick.onclick = function () {
        var r = document.getElementById('pickRegion').value;
        var g = document.getElementById('pickGenre').value;
        var d = document.getElementById('pickDecade').value;
        var hideW = document.getElementById('pickHideWatched').checked;
        var pool = catalog.concat(nowMovies).filter(function (m) {
          if (r !== 'all' && m.region !== r) return false;
          if (g !== 'all' && (m.genres || []).indexOf(g) === -1) return false;
          if (d !== 'all' && m.decade !== d) return false;
          if (hideW && CIN.isWatched(m.id)) return false;
          return true;
        });
        if (!pool.length) {
          CIN.toast('沒有完全符合條件的未看電影，試試放寬地區或年代篩選！');
          return;
        }
        var chosen = pool[Math.floor(Math.random() * pool.length)];
        CIN.openMovieModal(chosen.id);
      };
    }

    root.querySelectorAll('[data-jump-region]').forEach(function (el) {
      el.onclick = function () {
        CIN.state.exploreFilter.region = el.getAttribute('data-jump-region');
        CIN.state.exploreFilter.genre = 'all';
        CIN.state.exploreFilter.decade = 'all';
        CIN.state.exploreFilter.limit = 48;
        window.location.hash = '#/explore';
      };
    });
    root.querySelectorAll('[data-jump-genre]').forEach(function (el) {
      el.onclick = function () {
        CIN.state.exploreFilter.genre = el.getAttribute('data-jump-genre');
        CIN.state.exploreFilter.region = 'all';
        CIN.state.exploreFilter.decade = 'all';
        CIN.state.exploreFilter.limit = 48;
        window.location.hash = '#/explore';
      };
    });
    root.querySelectorAll('[data-jump-decade]').forEach(function (el) {
      el.onclick = function () {
        CIN.state.exploreFilter.decade = el.getAttribute('data-jump-decade');
        CIN.state.exploreFilter.region = 'all';
        CIN.state.exploreFilter.genre = 'all';
        CIN.state.exploreFilter.limit = 48;
        window.location.hash = '#/explore';
      };
    });
  };
})();
