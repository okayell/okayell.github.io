/* 🎞️ 跨年代片庫探索（1980s–2020s × 6 大地區 × 9 大類型 × 觀影狀態交叉聯動計數與流暢分頁） */
(function () {
  'use strict';
  var CIN = window.CIN;
  var PAGE_STEP = 48;

  CIN.renderExplorePage = function (root) {
    var catalog = CIN.getCatalogMovies();
    var ef = CIN.state.exploreFilter;
    if (!ef.limit || ef.limit < PAGE_STEP) ef.limit = PAGE_STEP;

    var qLower = String(ef.q || '').trim().toLowerCase();

    function matchesSearch(m) {
      if (!qLower) return true;
      var hay = [
        m.title, m.origTitle, m.director, m.country,
        (m.cast || []).join(' '), (m.mood || []).join(' '), m.synopsis
      ].join(' ').toLowerCase();
      return hay.indexOf(qLower) !== -1;
    }

    function matchesStatus(m, st) {
      if (st === 'unwatched') return !CIN.isWatched(m.id);
      if (st === 'watchlist') return CIN.isInWatchlist(m.id);
      if (st === 'watched') return CIN.isWatched(m.id);
      return true;
    }

    function matchesExcept(m, ignoreDim) {
      if (ignoreDim !== 'region' && ef.region !== 'all' && m.region !== ef.region) return false;
      if (ignoreDim !== 'genre' && ef.genre !== 'all' && (m.genres || []).indexOf(ef.genre) === -1) return false;
      if (ignoreDim !== 'decade' && ef.decade !== 'all' && m.decade !== ef.decade) return false;
      if (ignoreDim !== 'status' && !matchesStatus(m, ef.status)) return false;
      return matchesSearch(m);
    }

    var filtered = catalog.filter(function (m) { return matchesExcept(m, ''); });

    filtered.sort(function (a, b) {
      if (ef.sort === 'year_desc') return (b.year || 0) - (a.year || 0) || (b.rating || 0) - (a.rating || 0);
      if (ef.sort === 'year_asc') return (a.year || 0) - (b.year || 0) || (b.rating || 0) - (a.rating || 0);
      return (b.rating || 0) - (a.rating || 0) || (b.year || 0) - (a.year || 0);
    });

    var poolForRegion = catalog.filter(function (m) { return matchesExcept(m, 'region'); });
    var poolForGenre = catalog.filter(function (m) { return matchesExcept(m, 'genre'); });
    var poolForDecade = catalog.filter(function (m) { return matchesExcept(m, 'decade'); });
    var poolForStatus = catalog.filter(function (m) { return matchesExcept(m, 'status'); });

    var regionPills = '<button type="button" class="cin-pill' + (ef.region === 'all' ? ' active' : '') + '" data-ef-region="all">全部地區 (' + poolForRegion.length + ')</button>' +
      CIN.REGIONS.map(function (r) {
        var c = poolForRegion.filter(function (m) { return m.region === r.id; }).length;
        var cls = 'cin-pill' + (ef.region === r.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
        return '<button type="button" class="' + cls + '" data-ef-region="' + r.id + '">' + CIN.esc(r.label) + ' (' + c + ')</button>';
      }).join('');

    var genrePills = '<button type="button" class="cin-pill' + (ef.genre === 'all' ? ' active' : '') + '" data-ef-genre="all">全部類型 (' + poolForGenre.length + ')</button>' +
      CIN.GENRES.map(function (g) {
        var c = poolForGenre.filter(function (m) { return (m.genres || []).indexOf(g.id) !== -1; }).length;
        var cls = 'cin-pill' + (ef.genre === g.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
        return '<button type="button" class="' + cls + '" data-ef-genre="' + g.id + '">' + CIN.esc(g.label) + ' (' + c + ')</button>';
      }).join('');

    var decadePills = '<button type="button" class="cin-pill' + (ef.decade === 'all' ? ' active' : '') + '" data-ef-decade="all">全部年代 (' + poolForDecade.length + ')</button>' +
      CIN.DECADES.map(function (d) {
        var c = poolForDecade.filter(function (m) { return m.decade === d.id; }).length;
        var cls = 'cin-pill' + (ef.decade === d.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
        return '<button type="button" class="' + cls + '" data-ef-decade="' + d.id + '">' + CIN.esc(d.label) + ' (' + c + ')</button>';
      }).join('');

    var statusPills = [
      { id: 'all', lbl: '全部電影' },
      { id: 'unwatched', lbl: '👀 尚未看過' },
      { id: 'watchlist', lbl: '📋 我的待看片單' },
      { id: 'watched', lbl: '✅ 我看過了' }
    ].map(function (s) {
      var c = poolForStatus.filter(function (m) { return matchesStatus(m, s.id); }).length;
      var cls = 'cin-pill' + (ef.status === s.id ? ' active' : '') + (c === 0 ? ' is-zero' : '');
      return '<button type="button" class="' + cls + '" data-ef-status="' + s.id + '">' + s.lbl + ' (' + c + ')</button>';
    }).join('');

    var hasActiveFilter = ef.region !== 'all' || ef.genre !== 'all' || ef.decade !== 'all' || ef.status !== 'all' || !!qLower;
    var visibleItems = filtered.slice(0, ef.limit);
    var remaining = filtered.length - visibleItems.length;

    var moreBarHtml = remaining > 0
      ? '<div class="cin-load-more-bar">' +
          '<button type="button" class="cin-btn cin-btn-primary" id="btnExploreMore">👇 再載入 ' + Math.min(PAGE_STEP, remaining) + ' 部電影（目前顯示 ' + visibleItems.length + ' / ' + filtered.length + ' 部）</button>' +
          '<button type="button" class="cin-btn" id="btnExploreAll">⚡ 一次展開全部 (' + filtered.length + ' 部)</button>' +
        '</div>'
      : '';

    root.innerHTML =
      '<div class="cin-sec-hd">' +
        '<div>' +
          '<h2>🎞️ 1980 年代至今跨國經典與當代片庫（共收錄 ' + catalog.length + ' 部）</h2>' +
          '<div class="cin-sec-sub">自由交叉篩選「西洋、國片、日本、韓國、印度、泰國」×「九大類型」×「五個年代」，數字皆隨目前篩選即時聯動更新</div>' +
        '</div>' +
        (hasActiveFilter ? '<button type="button" class="cin-btn cin-btn-sm" id="btnResetExplore">↺ 重設全部篩選</button>' : '') +
      '</div>' +

      '<div class="cin-filter-box">' +
        '<div class="cin-filter-group">' +
          '<div class="cin-filter-lbl">地區影壇</div>' +
          '<div class="cin-pills">' + regionPills + '</div>' +
        '</div>' +
        '<div class="cin-filter-group">' +
          '<div class="cin-filter-lbl">電影類型</div>' +
          '<div class="cin-pills">' + genrePills + '</div>' +
        '</div>' +
        '<div class="cin-filter-group">' +
          '<div class="cin-filter-lbl">上映年代</div>' +
          '<div class="cin-pills">' + decadePills + '</div>' +
        '</div>' +
        '<div class="cin-filter-group">' +
          '<div class="cin-filter-lbl">觀影標記</div>' +
          '<div class="cin-pills">' + statusPills + '</div>' +
        '</div>' +
      '</div>' +

      '<div class="cin-toolbar">' +
        '<div class="cin-search-wrap">' +
          '<input type="search" id="exploreSearchInput" class="cin-input" placeholder="🔍 搜尋片名、原文片名、導演、演員或心情關鍵字（如：楊德昌、宮崎駿、阿米爾罕、反轉、催淚）…" value="' + CIN.esc(ef.q) + '" />' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:10px;">' +
          '<span style="font-size:13px;font-weight:800;color:#57534e;">共找到 <b style="color:#be123c;">' + filtered.length + '</b> 部電影</span>' +
          '<select id="exploreSortSelect" class="cin-select" style="width:auto;" aria-label="排序方式">' +
            '<option value="rating"' + (ef.sort === 'rating' ? ' selected' : '') + '>依經典評分（高 → 低）</option>' +
            '<option value="year_desc"' + (ef.sort === 'year_desc' ? ' selected' : '') + '>依上映年份（新 → 舊）</option>' +
            '<option value="year_asc"' + (ef.sort === 'year_asc' ? ' selected' : '') + '>依上映年份（1980 → 現在）</option>' +
          '</select>' +
        '</div>' +
      '</div>' +

      (visibleItems.length
        ? '<div class="cin-movie-grid">' + visibleItems.map(CIN.renderMovieCard).join('') + '</div>' + moreBarHtml
        : '<div class="cin-empty"><h3>找不到符合所有條件的電影</h3><p>試試切換為「全部年代」或清除關鍵字搜尋！</p><button type="button" class="cin-btn cin-btn-sm cin-btn-primary" id="btnEmptyReset">顯示全部電影</button></div>');

    root.querySelectorAll('[data-ef-region]').forEach(function (b) {
      b.onclick = function () { ef.region = b.getAttribute('data-ef-region'); ef.limit = PAGE_STEP; CIN.renderExplorePage(root); };
    });
    root.querySelectorAll('[data-ef-genre]').forEach(function (b) {
      b.onclick = function () { ef.genre = b.getAttribute('data-ef-genre'); ef.limit = PAGE_STEP; CIN.renderExplorePage(root); };
    });
    root.querySelectorAll('[data-ef-decade]').forEach(function (b) {
      b.onclick = function () { ef.decade = b.getAttribute('data-ef-decade'); ef.limit = PAGE_STEP; CIN.renderExplorePage(root); };
    });
    root.querySelectorAll('[data-ef-status]').forEach(function (b) {
      b.onclick = function () { ef.status = b.getAttribute('data-ef-status'); ef.limit = PAGE_STEP; CIN.renderExplorePage(root); };
    });

    var btnMore = document.getElementById('btnExploreMore');
    if (btnMore) {
      btnMore.onclick = function () {
        ef.limit = (ef.limit || PAGE_STEP) + PAGE_STEP;
        CIN.renderExplorePage(root);
      };
    }
    var btnAll = document.getElementById('btnExploreAll');
    if (btnAll) {
      btnAll.onclick = function () {
        ef.limit = filtered.length + PAGE_STEP;
        CIN.renderExplorePage(root);
      };
    }

    var inp = document.getElementById('exploreSearchInput');
    if (inp) {
      var composing = false;
      var runExploreSearch = function () {
        ef.q = inp.value;
        ef.limit = PAGE_STEP;
        var pos = inp.selectionStart || ef.q.length;
        CIN.renderExplorePage(root);
        var inp2 = document.getElementById('exploreSearchInput');
        if (inp2) {
          inp2.focus();
          try { inp2.setSelectionRange(pos, pos); } catch (e) { /* ignore */ }
        }
      };
      inp.addEventListener('compositionstart', function () { composing = true; });
      inp.addEventListener('compositionend', function () { composing = false; runExploreSearch(); });
      inp.addEventListener('input', function () {
        if (!composing) runExploreSearch();
      });
    }

    var sel = document.getElementById('exploreSortSelect');
    if (sel) {
      sel.onchange = function () { ef.sort = sel.value; ef.limit = PAGE_STEP; CIN.renderExplorePage(root); };
    }

    function resetAll() {
      ef.region = 'all';
      ef.genre = 'all';
      ef.decade = 'all';
      ef.status = 'all';
      ef.q = '';
      ef.limit = PAGE_STEP;
      CIN.renderExplorePage(root);
    }
    var r1 = document.getElementById('btnResetExplore');
    var r2 = document.getElementById('btnEmptyReset');
    if (r1) r1.onclick = resetAll;
    if (r2) r2.onclick = resetAll;
  };
})();
