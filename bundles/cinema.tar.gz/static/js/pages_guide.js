/* 🎓 看門道美學課（6 堂電影鑑賞必修課 ＋ 互動影癡隨堂測驗） */
(function () {
  'use strict';
  var CIN = window.CIN;

  var LESSONS = [
    {
      title: '第 1 堂｜鏡頭語言入門：景別、構圖與運鏡在說什麼話？',
      summary: '為什麼同樣一句台詞，用「大特寫」跟「大遠景長鏡頭」拍出來情緒完全不同？',
      points: [
        '大遠景／空鏡（Extreme Long Shot）：建立人與環境的比例關係——如侯孝賢《悲情城市》或維倫紐瓦《沙丘》，用廣袤空間凸顯命運蒼涼或史詩壓迫。',
        '推軌與跟拍（Tracking / Steadicam）：庫柏力克《鬼店》貼地跟隨三輪車轉彎，讓觀眾體驗「轉角隨時有東西」的主觀焦慮。',
        '構圖切割（Frame within a Frame）：王家衛《花樣年華》大量利用門框、窗欞與走廊遮擋角色，不必一句直白台詞就拍出壓抑的道德枷鎖。'
      ],
      examples: ['west-shining-1980', 'tw-in-the-mood-for-love-2000', 'kr-parasite-2019']
    },
    {
      title: '第 2 堂｜剪輯與蒙太奇：決定心跳速度的隱形魔術師',
      summary: '電影不是把拍好的畫面照順序接起來而已——剪接點在哪一格，決定了懸疑感與笑點。',
      points: [
        '平行交叉剪輯（Cross-Cutting）：諾蘭《全面啟動》把四層夢境不同時間流速同步交叉剪接，將最後五分鐘的救援張力放大十倍。',
        '匹配的轉場（Match Cut）：今敏《千年女優》用一個奔跑動作無縫跨越戰國、幕末到太空，讓記憶與時代融為一體。',
        '喜劇與驚悚的節奏差：泰國《模犯生》把跨國作弊拍成諜報動作片，靠的就是鉛筆敲擊聲與快速切鏡的精準節拍。'
      ],
      examples: ['west-inception-2010', 'jp-millennium-actress-2001', 'th-bad-genius-2017']
    },
    {
      title: '第 3 堂｜色彩與光影心理學：導演如何偷渡潛意識？',
      summary: '在角色開口之前，畫面的色溫與陰影對比已經預告了他的命運。',
      points: [
        '冷暖色調衝突：奉俊昊《寄生上流》豪宅的溫暖陽光草皮 vs. 半地下室潮濕泛綠的日光燈，階級落差一目了然。',
        '高反差黑色電影光影（Chiaroscuro）：《銀翼殺手》與《火線追緝令》透過百葉窗斜射光與霓虹雨夜，映照善惡難辨的灰色人性。',
        '高飽和童話對比殘酷現實：《歡迎來到布達佩斯大飯店》與印度《寶萊塢生死戀》用濃烈色彩打造既浪漫又哀傷的時代輓歌。'
      ],
      examples: ['west-blade-runner-1982', 'west-grand-budapest-2014', 'in-devdas-2002']
    },
    {
      title: '第 4 堂｜聲音與留白：配樂之外，「環境音」才是沉浸關鍵',
      summary: '閉上眼睛聽一部好電影，你依然能聽見空間大小、季節濕度與角色內心風暴。',
      points: [
        '主題動機（Leitmotif）：久石讓為宮崎駿動畫譜寫的主題旋律、漢斯季默《星際效應》管風琴，只要三個音符就能喚醒整部電影的情感記憶。',
        '刻意消音與環境音放大：《噤界》與《拯救雷恩大兵》搶灘耳鳴聲，證明「突然的安靜」往往比震耳爆炸更震撼人心。',
        '聲畫對位（Counterpoint）：用輕快優雅的古典樂搭配殘酷場面（如《發條橘子》、《原罪犯》），能產生強烈的荒謬與心理寒意。'
      ],
      examples: ['jp-spirited-away-2001', 'west-interstellar-2014', 'kr-oldboy-2003']
    },
    {
      title: '第 5 堂｜劇本結構與類型反轉：三幕劇、麥高芬與敘事詭計',
      summary: '為什麼有些電影看第二次比第一次更驚艷？拆解編劇埋藏伏筆的工藝。',
      points: [
        '草蛇灰線的前後呼應（Setup & Payoff）：印度《三個傻瓜》與《調音師》前半段看似隨意的搞笑細節，在結局全部收束成關鍵轉折。',
        '不可靠敘事者（Unreliable Narrator）：《鬥陣俱樂部》、《隔離島》與《下女的誘惑》利用視角限制欺騙觀眾，揭曉真相時徹底顛覆認知。',
        '開放式留白結局：楊德昌《一一》與是枝裕和《小偷家族》不給廉價的標準答案，把生命的提問留在戲院散場之後。'
      ],
      examples: ['in-3-idiots-2009', 'in-andhadhun-2018', 'tw-yi-yi-2000']
    },
    {
      title: '第 6 堂｜1980–2020s 六大影壇浪潮全圖鑑',
      summary: '一張地圖讀懂近四十五年西洋、國片華語、日、韓、印、泰電影的各自強項！',
      points: [
        '🌎 西洋歐美 & 🇹🇼 國片華語：好萊塢建立全球商業類型片與特效工業標竿；台灣新電影（侯孝賢、楊德昌、李安）與港片黃金年代則寫下華語影史美學高峰。',
        '🇯🇵 日本 & 🇰🇷 韓國：日本動畫大師（宮崎駿、今敏、新海誠）與庶民寫實獨步全球；韓國自 2000 年後將商業類型片與社會批判完美融合，登上奧斯卡之巔。',
        '🇮🇳 印度 & 🇹🇭 泰國：印度早已超越傳統歌舞，在教育省思與高智商犯罪懸疑屢創神作；泰國則憑藉鬼片創意、廣告級催淚親情與黑色青春片席捲亞洲！'
      ],
      examples: ['tw-a-brighter-summer-day-1991', 'kr-memories-of-murder-2003', 'th-shutter-2004']
    }
  ];

  var QUIZ = [
    {
      q: '在《寄生上流》或《花樣年華》中，導演利用門框、樓梯或走廊把兩個角色分隔在畫面不同區塊，這在電影語言中主要傳達什麼效果？',
      opts: [
        '單純因為拍攝場地太小放不下攝影機',
        '利用「框中框構圖」與空間高低差，具象化角色的心理隔閡、道德束縛或階級落差',
        '為了方便事後裁切成手機直式短影音'
      ],
      ans: 1,
      exp: '正解！優秀的場面調度（Mise-en-scène）會用空間高低、門框遮擋與光影界線，不靠直白台詞就讓觀眾感受到權力與心理距離。'
    },
    {
      q: '泰國電影《模犯生》能把靜態的「考場寫考卷」拍得像諜報動作片一樣緊張刺激，最核心的技術功臣是什麼？',
      opts: [
        '大量爆破特效與飛車追逐',
        '一鏡到底完全不剪接',
        '快節奏「交叉剪輯」搭配放大鉛筆塗卡、時鐘滴答的特寫音效節拍'
      ],
      ans: 2,
      exp: '正解！透過快速交叉剪輯與精準的環境音效節拍，即使沒有槍戰也能在考場座位間創造極致的腎上腺素張力。'
    },
    {
      q: '當一部驚悚或犯罪片刻意在緊張或殘酷場景播放「輕快溫馨的古典樂或老歌」時，這種手法稱為什麼？',
      opts: [
        '聲畫對位（Audio-Visual Counterpoint），利用聽覺與視覺的反差放大荒謬感與心理寒意',
        '音軌同步失誤',
        '麥高芬（MacGuffin）道具手法'
      ],
      ans: 0,
      exp: '正解！「聲畫對位」讓音樂不再只是順著畫面情緒煽情，而是用反差製造令人難忘的戲劇張力。'
    }
  ];

  CIN.renderGuidePage = function (root) {
    var lessonsHtml = LESSONS.map(function (ls) {
      var exBtns = (ls.examples || []).map(function (id) {
        var m = CIN.findMovie(id);
        if (!m) return '';
        return '<button type="button" class="cin-btn cin-btn-sm" data-open-movie="' + CIN.esc(m.id) + '">🎬 對照看點：《' + CIN.esc(m.title) + '》</button>';
      }).join(' ');
      return (
        '<article class="cin-lesson-card">' +
          '<h3>' + CIN.esc(ls.title) + '</h3>' +
          '<p style="margin:0 0 10px;color:#57534e;font-weight:700;">' + CIN.esc(ls.summary) + '</p>' +
          '<ul class="cin-hl-list" style="margin-bottom:12px;">' +
            ls.points.map(function (p) { return '<li>' + CIN.esc(p) + '</li>'; }).join('') +
          '</ul>' +
          (exBtns ? '<div style="display:flex;gap:8px;flex-wrap:wrap;">' + exBtns + '</div>' : '') +
        '</article>'
      );
    }).join('');

    var quizHtml = QUIZ.map(function (item, idx) {
      var alreadyDone = !!(CIN.state && CIN.state.quizDone && CIN.state.quizDone[String(idx)]);
      var opts = item.opts.map(function (op, oi) {
        return '<button type="button" class="cin-btn cin-btn-sm" style="justify-content:flex-start;text-align:left;" data-quiz-q="' + idx + '" data-quiz-o="' + oi + '">' +
          String.fromCharCode(65 + oi) + '. ' + CIN.esc(op) +
        '</button>';
      }).join('');
      var initStyle = alreadyDone
        ? 'margin-top:10px;font-size:13.5px;display:block;padding:9px 12px;border-radius:10px;background:#ecfdf5;color:#065f46;border:1px solid #6ee7b7;'
        : 'margin-top:10px;font-size:13.5px;display:none;padding:9px 12px;border-radius:10px;';
      return (
        '<div class="cin-lesson-card" id="quizBox' + idx + '">' +
          '<div style="font-weight:900;margin-bottom:10px;">Q' + (idx + 1) + '. ' + CIN.esc(item.q) + '</div>' +
          '<div style="display:flex;flex-direction:column;gap:7px;">' + opts + '</div>' +
          '<div id="quizMsg' + idx + '" style="' + initStyle + '">' + (alreadyDone ? ('🎉 ' + CIN.esc(item.exp)) : '') + '</div>' +
        '</div>'
      );
    }).join('');

    root.innerHTML =
      '<div class="cin-sec-hd">' +
        '<div>' +
          '<h2>🎓 電影鑑賞看門道：6 堂影癡必修美學課</h2>' +
          '<div class="cin-sec-sub">學會鏡頭、剪輯、光影、配樂與劇本結構，從「看熱鬧」升級到「看懂導演藏在細節裡的巧思」</div>' +
        '</div>' +
      '</div>' +
      lessonsHtml +
      '<div class="cin-sec" style="margin-top:28px;">' +
        '<div class="cin-sec-hd"><h2>🧠 隨堂觀影眼力小測驗（全對解鎖「🎥 場面調度美學優等生」成就與稱號！）</h2></div>' +
        quizHtml +
      '</div>';

    root.querySelectorAll('[data-quiz-q]').forEach(function (btn) {
      btn.onclick = function () {
        var qi = Number(btn.getAttribute('data-quiz-q'));
        var oi = Number(btn.getAttribute('data-quiz-o'));
        var qObj = QUIZ[qi];
        var msg = document.getElementById('quizMsg' + qi);
        if (!msg || !qObj) return;
        msg.style.display = 'block';
        if (oi === qObj.ans) {
          msg.style.background = '#ecfdf5';
          msg.style.color = '#065f46';
          msg.style.border = '1px solid #6ee7b7';
          msg.textContent = '🎉 ' + qObj.exp;
          if (typeof CIN.saveQuizDone === 'function') CIN.saveQuizDone(qi);
          else CIN.recordCampusAct();
        } else {
          msg.style.background = '#fff1f2';
          msg.style.color = '#9f1239';
          msg.style.border = '1px solid #fecdd3';
          msg.textContent = '💡 再想一下！試試看其他選項。';
        }
      };
    });
  };
})();
