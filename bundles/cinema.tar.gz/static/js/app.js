/* 🎬 電影學院主路由、事件委派、版本更新紀錄與極簡 3 欄意見回饋 */
(function () {
  'use strict';
  var CIN = window.CIN;

  function renderFeedbackPage(root) {
    root.innerHTML =
      '<div style="max-width:640px;margin:0 auto;">' +
        '<div class="cin-sec-hd">' +
          '<div>' +
            '<h2>💬 意見回饋與許願池</h2>' +
            '<div class="cin-sec-sub">有想看解析卻還沒收錄的私房愛片，或功能建議？歡迎隨時告訴我們！</div>' +
          '</div>' +
        '</div>' +
        '<form id="cinFeedbackForm" class="cin-lesson-card">' +
          '<div style="margin-bottom:12px;">' +
            '<label style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">回饋類型</label>' +
            '<select id="fbCategory" class="cin-select">' +
              '<option value="電影許願">🎬 許願新增電影／看點解析</option>' +
              '<option value="功能建議">✨ 功能與介面建議</option>' +
              '<option value="資料修正">📝 電影片名／年份／解析修正</option>' +
            '</select>' +
          '</div>' +
          '<div style="margin-bottom:12px;">' +
            '<label style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">你的暱稱（選填）</label>' +
            '<input type="text" id="fbSender" class="cin-input" placeholder="例如：影癡小陳" />' +
          '</div>' +
          '<div style="margin-bottom:14px;">' +
            '<label style="display:block;font-size:13px;font-weight:800;margin-bottom:5px;">回饋內容（必填）</label>' +
            '<textarea id="fbMessage" class="cin-input" rows="4" required placeholder="請輸入你想推薦的電影名稱，或希望電影學院新增的功能…"></textarea>' +
          '</div>' +
          '<button type="submit" class="cin-btn cin-btn-primary" id="fbSubmitBtn">📮 送出意見回饋</button>' +
        '</form>' +
      '</div>';

    var form = document.getElementById('cinFeedbackForm');
    if (form) {
      form.onsubmit = function (ev) {
        ev.preventDefault();
        var cat = document.getElementById('fbCategory').value;
        var sender = document.getElementById('fbSender').value.trim();
        var msg = document.getElementById('fbMessage').value.trim();
        if (!msg) return;
        var btn = document.getElementById('fbSubmitBtn');
        btn.disabled = true;
        btn.textContent = '⏳ 傳送中…';

        var isLocal = window.location && (window.location.protocol === 'http:' || window.location.protocol === 'https:') &&
          !/\.github\.io$/i.test(window.location.hostname || '');

        if (isLocal) {
          fetch(CIN.apiBase() + 'feedback', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ category: cat, sender: sender, message: msg, page: window.location.hash })
          })
            .then(function (r) { return r.json(); })
            .then(function () {
              CIN.toast('🎉 感謝你的回饋！我們已收到你的建議。');
              form.reset();
              btn.disabled = false;
              btn.textContent = '📮 送出意見回饋';
            })
            .catch(function () {
              CIN.toast('✅ 已在本機記錄你的寶貴回饋！');
              form.reset();
              btn.disabled = false;
              btn.textContent = '📮 送出意見回饋';
            });
        } else if (window.CampusNav && typeof window.CampusNav.openFeedback === 'function') {
          window.CampusNav.openFeedback('cinema', '[' + cat + '] ' + msg);
          btn.disabled = false;
          btn.textContent = '📮 送出意見回饋';
        } else {
          CIN.toast('🎉 感謝回饋！已記錄你的建議。');
          form.reset();
          btn.disabled = false;
          btn.textContent = '📮 送出意見回饋';
        }
      };
    }
  }

  function openReleaseModal() {
    var relData = window.CIN_RELEASES || { current_version: '1.0.0', releases: [] };
    var backdrop = document.getElementById('releaseModal');
    var card = document.getElementById('releaseModalCard');
    if (!backdrop || !card) return;
    var items = (relData.releases || []).map(function (r) {
      var lis = (r.changes || []).map(function (c) { return '<li>' + CIN.esc(c) + '</li>'; }).join('');
      return (
        '<div class="cin-analysis-block">' +
          '<h4>v' + CIN.esc(r.version) + ' — ' + CIN.esc(r.title || '') + ' <span style="font-weight:600;color:#78716c;font-size:12px;margin-left:auto;">' + CIN.esc(r.date || '') + '</span></h4>' +
          '<ul class="cin-hl-list">' + lis + '</ul>' +
        '</div>'
      );
    }).join('');
    card.innerHTML =
      '<button type="button" class="cin-modal-close" id="closeRelModalBtn" aria-label="關閉">✕</button>' +
      '<div class="cin-modal-hero">' +
        '<h2 id="releaseModalTitle" style="margin:0;font-size:21px;font-weight:900;">🎬 電影學院 版本更新紀錄</h2>' +
      '</div>' +
      '<div class="cin-modal-body">' + items + '</div>';
    document.getElementById('closeRelModalBtn').onclick = function () { backdrop.classList.remove('open'); };
    backdrop.classList.add('open');
  }

  function currentRoute() {
    var h = String(window.location.hash || '').replace(/^#\/?/, '').split('?')[0].trim();
    if (['home', 'now', 'explore', 'my-list', 'guide', 'feedback'].indexOf(h) !== -1) return h;
    return 'home';
  }

  CIN.refreshCurrentView = function () {
    var route = currentRoute();
    var root = document.getElementById('appRoot');
    if (!root) return;
    document.querySelectorAll('#mainNav .cin-tab').forEach(function (t) {
      t.classList.toggle('active', t.getAttribute('data-route') === route);
    });
    CIN.syncHeaderBadges();
    if (route === 'now') CIN.renderNowPlayingPage(root);
    else if (route === 'explore') CIN.renderExplorePage(root);
    else if (route === 'my-list') CIN.renderMyListPage(root);
    else if (route === 'guide') CIN.renderGuidePage(root);
    else if (route === 'feedback') renderFeedbackPage(root);
    else CIN.renderHomePage(root);
  };

  function init() {
    var relData = window.CIN_RELEASES || { current_version: '1.0.0' };
    var vb = document.getElementById('verBadge');
    if (vb && relData.current_version) {
      vb.textContent = 'v' + relData.current_version;
      vb.onclick = openReleaseModal;
    }

    var isLocal = window.location && (window.location.protocol === 'http:' || window.location.protocol === 'https:') &&
      !/\.github\.io$/i.test(window.location.hostname || '');
    var dlBtn = document.getElementById('dlOfflineBtn');
    if (dlBtn && isLocal) dlBtn.classList.add('show');

    document.querySelectorAll('#mainNav .cin-tab').forEach(function (btn) {
      btn.onclick = function () {
        window.location.hash = '#/' + btn.getAttribute('data-route');
      };
    });

    var hdrWl = document.getElementById('hdrWatchlistBtn');
    if (hdrWl) {
      hdrWl.onclick = function () {
        CIN.state.myListTab = 'watchlist';
        window.location.hash = '#/my-list';
        CIN.refreshCurrentView();
      };
    }
    var hdrWd = document.getElementById('hdrWatchedBtn');
    if (hdrWd) {
      hdrWd.onclick = function () {
        CIN.state.myListTab = 'watched';
        window.location.hash = '#/my-list';
        CIN.refreshCurrentView();
      };
    }

    // 全域事件委派：卡片一鍵加入片單、標註已看、展開看點解析與跳轉路由
    document.addEventListener('click', function (ev) {
      var t = ev.target;
      if (!t || !t.closest) return;

      var wlBtn = t.closest('[data-toggle-watchlist]');
      if (wlBtn) {
        ev.preventDefault();
        ev.stopPropagation();
        CIN.toggleWatchlist(wlBtn.getAttribute('data-toggle-watchlist'));
        CIN.refreshCurrentView();
        return;
      }

      var wdBtn = t.closest('[data-toggle-watched]');
      if (wdBtn) {
        ev.preventDefault();
        ev.stopPropagation();
        CIN.toggleWatched(wdBtn.getAttribute('data-toggle-watched'));
        CIN.refreshCurrentView();
        return;
      }

      var openEl = t.closest('[data-open-movie]');
      if (openEl) {
        ev.preventDefault();
        CIN.openMovieModal(openEl.getAttribute('data-open-movie'));
        return;
      }

      var goRoute = t.closest('[data-go-route]');
      if (goRoute) {
        ev.preventDefault();
        window.location.hash = '#/' + goRoute.getAttribute('data-go-route');
        return;
      }

      if (t.id === 'movieModal') CIN.closeMovieModal();
      if (t.id === 'releaseModal') t.classList.remove('open');
    });

    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') {
        CIN.closeMovieModal();
        var rm = document.getElementById('releaseModal');
        if (rm) rm.classList.remove('open');
      }
    });

    window.addEventListener('hashchange', function () {
      window.scrollTo(0, 0);
      CIN.refreshCurrentView();
    });

    CIN.syncHeaderBadges();
    CIN.refreshCurrentView();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
