"""Configuration paths for Cinema Academy (used by local server & GitHub Actions weekly updater)."""

from __future__ import annotations

import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
NOW_PLAYING_JSON = os.path.join(DATA_DIR, 'now_playing.json')
DB_PATH = NOW_PLAYING_JSON
