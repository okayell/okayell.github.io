#!/usr/bin/env python3
"""每週自動更新「現在上映的電影（院線熱映）」與看點解析（標準函式庫，支援本機排程與 GitHub Actions）。"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import html as html_lib
import json
import os
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
NOW_PLAYING_JSON = os.path.join(DATA_DIR, 'now_playing.json')
NOW_PLAYING_JS = os.path.join(ROOT_DIR, 'static', 'js', 'content', 'now_playing_data.js')

UA = (
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
)

GENRE_KEYWORDS = [
    ('animation', ['動畫', '卡通', '皮克斯', '吉卜力', '迪士尼', '劇場版', '哆啦A夢', '柯南', '蠟筆小新', '動漫']),
    ('horror', ['恐怖', '鬼', '咒', '邪', '靈異', '喪屍', '驚嚇', '驅魔', '厲陰宅', '詭', '血腥', '虐殺']),
    ('scifi', ['科幻', '太空', '星際', '宇宙', '未來', 'AI', '機器人', '異形', '末日', '平行宇宙', '超能力', '變種']),
    ('comedy', ['喜劇', '爆笑', '搞笑', '歡樂', '荒謬', '無厘頭', '溫馨喜劇', '黑色幽默']),
    ('thriller', ['懸疑', '驚悚', '推理', '密室', '謎團', '失蹤', '心理', '追兇', '反轉', '真相']),
    ('crime', ['犯罪', '黑幫', '警匪', '臥底', '緝毒', '殺手', '搶劫', '黑道', '檢察官', '詐騙']),
    ('action', ['動作', '冒險', '特務', '戰士', '槍戰', '飛車', '格鬥', '救援', '史詩', '英雄', '戰爭']),
    ('romance', ['愛情', '戀愛', '浪漫', '初戀', '重逢', '青春', '告白', '深情', '婚姻']),
    ('drama', ['劇情', '家庭', '親情', '人生', '成長', '催淚', '真實故事', '傳記', '社會', '音樂', '鋼琴', '交響', '時代', '藝術', '詩人', '作曲']),
]

GENRE_CRAFT_MAP = {
    'action': '動作場面調度俐落，快節奏剪輯結合大銀幕低頻音效設計，將追逐與對決的臨場張力拉到滿點。',
    'scifi': '世界觀美術設定與視覺特效細節講究，透過光影冷暖對比與空間尺度營造強烈的未來大銀幕沉浸感。',
    'horror': '善用環境音場留白、陰影構圖與突發節奏反差，不單靠突發驚嚇，而是讓心理壓迫感層層滲透。',
    'animation': '分鏡流暢、色彩情緒飽滿，角色肢體表演與配樂主題緊密呼應，兼具視覺想像力與情感共鳴。',
    'comedy': '對白節奏明快、喜劇時機拿捏精準，透過角色性格反差與生活化荒謬情境自然引爆笑點。',
    'thriller': '敘事線索鋪陳嚴密，鏡頭視角刻意保留資訊落差，讓觀眾跟隨主角一步步逼近翻轉真相。',
    'crime': '冷峻寫實的攝影色調搭配緊湊交叉剪輯，深刻描繪人性灰色地帶與體制角力。',
    'romance': '特寫鏡頭細膩捕捉眼神與呼吸停頓，柔和自然光影與配樂旋律烘托出餘韻悠長的情感流動。',
    'drama': '長鏡頭與自然生活細節堆疊出真實人物弧線，演員群戲層次豐富，在平實日常中蘊含深刻後勁。',
}

REGION_STYLE_NOTE = {
    'taiwan': '展現台灣在地生活肌理與當代華語電影的細膩人文視角。',
    'japan': '延續日本電影獨有的職人美學、內斂情感留白與細膩敘事節奏。',
    'korea': '融合韓國商業類型片成熟的劇本結構、強烈社會共鳴與高張力表演。',
    'india': '展現印度影壇充沛的敘事能量、鮮明戲劇衝突與文化生命力。',
    'thailand': '結合泰國影視擅長的創意題材切角、情緒反轉與強烈娛樂感染力。',
    'western': '具備好萊塢與歐美院線成熟的大銀幕工業規格與跨文化類型魅力。',
}


def now_taipei() -> datetime:
  return datetime.now(timezone(timedelta(hours=8)))


def _http_get(url: str, timeout: int = 8) -> str:
  req = urllib.request.Request(
      url,
      headers={
          'User-Agent': UA,
          'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.8',
      },
  )
  with urllib.request.urlopen(req, timeout=timeout) as resp:
    raw = resp.read()
    ct = (resp.headers.get('Content-Type') or '').lower()
  if 'utf-8' in ct or 'utf8' in ct:
    return raw.decode('utf-8', errors='ignore')
  if 'big5' in ct or 'cp950' in ct:
    return raw.decode('cp950', errors='ignore')
  try:
    return raw.decode('utf-8')
  except UnicodeDecodeError:
    return raw.decode('utf-8', errors='ignore')


def _strip_tags(s: str, keep_breaks: bool = False) -> str:
  txt = re.sub(r'<script[\s\S]*?</script>', ' ', s, flags=re.I)
  txt = re.sub(r'<style[\s\S]*?</style>', ' ', txt, flags=re.I)
  txt = re.sub(r'<!--[\s\S]*?-->', ' ', txt)
  if keep_breaks:
    txt = re.sub(r'(?:<br\s*/?>\s*){2,}|</p>\s*<p[^>]*>', '\n\n', txt, flags=re.I)
    txt = re.sub(r'<br\s*/?>', '\n', txt, flags=re.I)
  txt = re.sub(r'<[^>]+>', ' ', txt)
  txt = html_lib.unescape(txt)
  txt = txt.replace('\u3008', '「').replace('\u3009', '」')
  if keep_breaks:
    paras = [re.sub(r'[ \t\r\f\v]+', ' ', p).strip() for p in re.split(r'\n{2,}', txt)]
    paras = [re.sub(r'\n+', ' ', p).strip() for p in paras if p.strip()]
    return '\n\n'.join(paras)
  return re.sub(r'\s+', ' ', txt).strip()


def _lookup_imdb_poster(imdb_id: str = '', orig_title: str = '', year: int = 0) -> str:
  queries: list[str] = []
  if imdb_id and re.match(r'^tt\d+$', imdb_id):
    queries.append(imdb_id)
  if orig_title:
    latin = re.sub(r'[^\x00-\x7F]+', ' ', orig_title).strip()
    if len(latin) >= 2:
      if year:
        queries.append(f'{latin} {year}')
      queries.append(latin)
  for q in queries:
    q_clean = re.sub(r'\s+', ' ', q).strip()[:55]
    if not q_clean:
      continue
    fc = urllib.parse.quote(q_clean[0].lower())
    url = f'https://v3.sg.media-imdb.com/suggestion/{fc}/{urllib.parse.quote(q_clean)}.json'
    try:
      raw = _http_get(url, timeout=4)
      data = json.loads(raw)
    except Exception:
      continue
    items = [d for d in (data.get('d') or []) if d.get('i', {}).get('imageUrl')]
    if not items:
      continue
    exact = [d for d in items if year and d.get('y') and abs(int(d['y']) - year) <= 1]
    pick = exact[0] if exact else items[0]
    img = pick['i']['imageUrl']
    resized = re.sub(r'\._V1_.*?\.(jpg|jpeg|png)$', r'._V1_QL82_UX500_.\1', img, flags=re.I)
    if resized == img and '._V1_.' in img:
      resized = img.replace('._V1_.', '._V1_QL82_UX500_.')
    return resized
  return ''


def _detect_region(text: str, orig_title: str = '', fid: str = '') -> str:
  f_low = fid.lower()
  if len(f_low) >= 6 and f_low.startswith('f'):
    cc = f_low[2:4]
    if cc in ('jp', 'ja'):
      return 'japan'
    if cc in ('kr', 'ko'):
      return 'korea'
    if cc in ('in',):
      return 'india'
    if cc in ('th',):
      return 'thailand'
    if cc in ('tw', 'hk', 'ch', 'cn', 'sg', 'my'):
      return 'taiwan'
    if cc in (
        'en', 'us', 'uk', 'gb', 'fr', 'de', 'es', 'it', 'ca', 'au', 'nz', 'ie',
        'pl', 'nl', 'be', 'se', 'no', 'dk', 'fi', 'at', 'pt', 'cz', 'hu', 'ro',
        'gr', 'ru', 'ua', 'is', 'br', 'mx', 'ar', 'il', 'ir',
    ):
      return 'western'
  blob = f'{text} {orig_title}'
  if re.search(r'[\u3040-\u30ff]', blob) or any(
      k in blob for k in ['日本', '劇場版', 'アニメ', '東寶', '吉卜力', '柯南', '哆啦A夢', '蠟筆小新', '鬼滅', '新海誠', '是枝裕和']
  ):
    return 'japan'
  if re.search(r'[\uac00-\ud7af]', blob) or any(
      k in blob for k in ['韓國', '南韓', '首爾', '釜山', '馬東石', '奉俊昊', '朴贊郁', '孫錫久', '玄彬', '宋康昊']
  ):
    return 'korea'
  if any(k in blob for k in ['泰國', '曼谷', '泰片', 'GDH', '泰式']):
    return 'thailand'
  if any(k in blob for k in ['印度', '寶萊塢', '孟買', '阿米爾罕', '沙魯克罕']):
    return 'india'
  if any(k in blob for k in ['台灣', '國片', '金馬', '台北', '台語', '香港', '華語', '九把刀', '鍾孟宏', '魏德聖']):
    return 'taiwan'
  if orig_title and re.search(r'[A-Za-z]{3,}', orig_title):
    return 'western'
  return 'western'


def _detect_genres(text: str) -> list[str]:
  scored: list[tuple[int, int, str]] = []
  for idx, (gid, kws) in enumerate(GENRE_KEYWORDS):
    hits = sum(1 for k in kws if k in text)
    if hits > 0:
      scored.append((hits, -idx, gid))
  if not scored:
    return ['drama']
  scored.sort(reverse=True)
  return [gid for _, _, gid in scored[:3]]


def _build_analysis(
    title: str,
    orig_title: str,
    region: str,
    genres: list[str],
    synopsis: str,
    director: str,
    cast: list[str],
    runtime: int,
) -> dict:
  main_g = genres[0] if genres else 'drama'
  cast_str = '、'.join(cast[:3]) if cast else ''
  hl1 = (
      f'故事切入點鮮明：{synopsis[:58].rstrip("，。、 ") + "…"}'
      if len(synopsis) > 24
      else f'《{title}》聚焦高張力人物處境，在大銀幕展開緊湊且引人入勝的敘事推進。'
  )
  if director and cast_str:
    hl2 = f'主創陣容看點：由導演 {director} 執導，集結 {cast_str} 同台飆戲，角色火花與情緒層次鮮明。'
  elif director:
    hl2 = f'導演風格鮮明：由 {director} 掌鏡調度，精準掌握類型節奏與角色心理轉折。'
  elif cast_str:
    hl2 = f'卡司表現亮眼：{cast_str} 領銜主演，細膩詮釋角色在關鍵抉擇下的情感張力。'
  else:
    hl2 = f'院線話題焦點：結合大銀幕視聽場面與角色情感共鳴，適合排入週末觀影清單。'

  hl3 = (
      f'大銀幕觀影體驗：全片約 {runtime} 分鐘，{REGION_STYLE_NOTE.get(region, REGION_STYLE_NOTE["western"])}'
      if runtime
      else f'選片推薦理由：{REGION_STYLE_NOTE.get(region, REGION_STYLE_NOTE["western"])}'
  )
  craft = GENRE_CRAFT_MAP.get(main_g, GENRE_CRAFT_MAP['drama'])
  legacy = (
      f'本週院線熱映作品（{orig_title}），建議進戲院感受大銀幕音效與畫面細節；看完後可在電影學院標註「我看過了」並留下個人星等筆記。'
      if orig_title
      else '本週院線熱映作品，建議進戲院感受大銀幕視聽魅力；觀影後可標註「我看過了」記錄你的專屬短評。'
  )
  return {
      'highlights': [hl1, hl2, hl3],
      'craft': craft,
      'legacy': legacy,
  }


def fetch_from_atmovies(max_items: int = 120) -> list[dict]:
  """Scrape current Taiwan theatrical releases from AtMovies (開眼電影網)."""
  items: list[dict] = []
  seen_ids: set[str] = set()
  dt_now = now_taipei()
  year_now = dt_now.year
  cutoff_zero_th = (dt_now - timedelta(days=14)).strftime('%Y-%m-%d')

  # Crawl /movie/new/ FIRST so brand-new releases keep '本週新片上映',
  # then /movie/now/ (all first-run releases, ~90+ films), then /movie/now2/ (second-run).
  list_urls = [
      ('本週新片上映', 'https://www.atmovies.com.tw/movie/new/'),
      ('院線熱映中', 'https://www.atmovies.com.tw/movie/now/'),
      ('二輪院線', 'https://www.atmovies.com.tw/movie/now2/'),
  ]
  candidates: list[tuple[str, str, str, int]] = []
  for badge, lurl in list_urls:
    try:
      html_txt = _http_get(lurl, timeout=8)
    except Exception:
      continue
    m_pa = re.search(
        r'<ul[^>]+class=["\']filmListPA["\'][^>]*>([\s\S]*?)</ul>',
        html_txt,
        re.I,
    )
    scan_html = m_pa.group(1) if m_pa else html_txt
    for m in re.finditer(
        r'<a[^>]+href=["\']/movie/(f[a-zA-Z0-9_]{6,})/?["\'][^>]*>([\s\S]*?)</a>([\s\S]{0,220})',
        scan_html,
    ):
      fid = m.group(1).strip()
      t_raw = _strip_tags(m.group(2))
      tail_raw = m.group(3) or ''
      if not fid or fid in seen_ids or len(t_raw) < 2 or len(t_raw) > 140:
        continue
      if any(skip in t_raw for skip in ['更多', '首頁', '排行榜', '預告', '劇照', '時刻表', '票房', '戲院', '影片節', '影展']):
        continue
      list_th = 0
      m_lth = re.search(r'\((\d+)\s*廳\)', tail_raw)
      if m_lth:
        list_th = int(m_lth.group(1))
      seen_ids.add(fid)
      candidates.append((fid, t_raw, badge, list_th))
      if len(candidates) >= max_items + 40:
        break

  def _fetch_detail(cand: tuple[str, str, str, int]) -> dict | None:
    fid, fallback_title, badge, list_th = cand
    detail_url = f'https://www.atmovies.com.tw/movie/{fid}/'
    try:
      dhtml = _http_get(detail_url, timeout=7)
    except Exception:
      return None

    # Title + English/original title
    title = fallback_title
    orig_title = ''
    raw_full_t = ''
    mt = re.search(r'<div[^>]+class=["\']filmTitle["\'][^>]*>([\s\S]*?)</div>', dhtml, re.I)
    if mt:
      raw_full_t = _strip_tags(mt.group(1))
      full_t = re.sub(r'^【[^】]+】', '', raw_full_t).strip()
      eng_m = re.search(
          r'^(.+?)\s+([A-Za-z0-9\u00C0-\u024F][A-Za-z0-9\u00C0-\u024F\s:,\'\-–—&!?.()/]{2,})$',
          full_t,
      )
      if eng_m and re.search(r'[\u4e00-\u9fff\u3040-\u30ff]', eng_m.group(1)):
        title = eng_m.group(1).strip()
        orig_title = eng_m.group(2).strip()
      elif full_t:
        title = full_t

    # Runtime, release date & theater count
    runtime = 0
    mr = re.search(r'片長[：:]\s*(\d{2,3})\s*分', dhtml)
    if mr:
      runtime = int(mr.group(1))
    rel_date = ''
    md = re.search(r'上映日期[：:]\s*([0-9]{4}/[0-9]{2}/[0-9]{2})', dhtml)
    if md:
      rel_date = md.group(1).replace('/', '-')
    theaters = list_th
    mth = re.search(r'廳數\s*\((\d+)\)', dhtml)
    if mth:
      theaters = int(mth.group(1))

    # Skip dead 0-theater placeholders unless it is a brand-new / upcoming week release
    if theaters <= 0 and (badge != '本週新片上映' or (rel_date and rel_date < cutoff_zero_th)):
      return None

    # Synopsis: prefer full uncut <!-- Story info end --> plot block, then fallback to filmTagBlock
    synopsis = ''
    m_full = re.search(
        r'GeneratedContent\s*-->([\s\S]{25,4000}?)</div>\s*<!--\s*Story info end',
        dhtml,
        re.I,
    )
    if not m_full:
      m_full = re.search(
          r'<div[^>]+class=["\'][^"\']*sub_content[^"\']*["\'][^>]*>([\s\S]{25,4000}?)</div>\s*<!--\s*Story info end',
          dhtml,
          re.I,
      )
    if m_full:
      cand_syn = _strip_tags(m_full.group(1), keep_breaks=True)
      if '開眼電影網' not in cand_syn and len(cand_syn) >= 20:
        synopsis = cand_syn

    if len(synopsis) < 25:
      ms = re.search(
          r'id=["\']filmTagBlock["\'][\s\S]{0,1200}?<p>([\s\S]*?)(?:</p>|<ul|</span|</div)',
          dhtml,
          re.I,
      )
      if ms:
        synopsis = _strip_tags(ms.group(1), keep_breaks=False)
    if len(synopsis) < 20:
      ms2 = re.search(r'劇情簡介[\s\S]{0,400}?-->([\s\S]{20,2400}?)(?:<div|<ul|<!--\s*end)', dhtml, re.I)
      if ms2:
        synopsis = _strip_tags(ms2.group(1), keep_breaks=True)
    synopsis = re.sub(r'^(劇情簡介|本片描述|故事描述)\s*', '', synopsis).strip()
    synopsis = re.sub(r'\.{3,}$', '…', synopsis)
    if '開眼電影網' in synopsis and len(synopsis) < 80:
      synopsis = ''
    if len(synopsis) > 650:
      synopsis = synopsis[:645].rstrip('，、 ') + '…'
    if len(synopsis) < 18:
      return None

    # Poster & Stills (AtMovies official Taiwan theatrical poster + IMDb Amazon CDN fallback + scene stills)
    poster_url = ''
    mp = re.search(r'<img[^>]+src=["\'](/photo101/[^"\']+\.(?:jpg|jpeg|png|webp))["\']', dhtml, re.I)
    if mp:
      poster_url = 'https://www.atmovies.com.tw' + mp.group(1)
    imdb_id = ''
    m_imdb = re.search(r'imdb\.com/title/(tt\d+)', dhtml, re.I)
    if m_imdb:
      imdb_id = m_imdb.group(1)
    rel_year_tmp = int(rel_date[:4]) if rel_date and rel_date[:4].isdigit() else year_now
    imdb_poster = ''
    if not poster_url or imdb_id:
      imdb_poster = _lookup_imdb_poster(
          imdb_id=imdb_id,
          orig_title='' if (poster_url and imdb_id) else orig_title,
          year=rel_year_tmp,
      )
    if not poster_url:
      poster_url = imdb_poster

    stills: list[str] = []
    for sm in re.finditer(r'https?://aws\.photos\.atmovies\.com\.tw/[^"\'\s>]+/fs_[^"\'\s>]+\.(?:jpg|jpeg|png)', dhtml, re.I):
      surl = re.sub(r'^http://', 'https://', sm.group(0))
      if surl not in stills:
        stills.append(surl)
      if len(stills) >= 4:
        break

    # Director & cast from structured <li><B>導演：</B> ... </li>
    director = ''
    mdir = re.search(r'導演[：:]\s*</[bB]>([\s\S]{0,400}?)(?:<li|</ul)', dhtml)
    if mdir:
      d_links = [_strip_tags(x) for x in re.findall(r'<a[^>]*>([\s\S]*?)</a>', mdir.group(1))]
      d_links = [x for x in d_links if 1 < len(x) <= 24]
      if d_links:
        director = '、'.join(d_links[:2])
      else:
        d_txt = _strip_tags(mdir.group(1)).strip(' 、,，')
        if 1 < len(d_txt) <= 24:
          director = d_txt

    cast: list[str] = []
    mcast = re.search(r'演員[：:]\s*</[bB]>([\s\S]{0,900}?)(?:<li\s+style|<ul|</ul)', dhtml)
    if mcast:
      c_links = [_strip_tags(x) for x in re.findall(r'<a[^>]*>([\s\S]*?)</a>', mcast.group(1))]
      cast = [x for x in c_links if 1 < len(x) <= 24][:4]

    tagline = ''
    mtag = re.search(
        r'id=["\']filmTagBlock["\'][\s\S]{0,1200}?<p>([\s\S]*?)(?:</p>|<ul|</span|</div)',
        dhtml,
        re.I,
    )
    if mtag:
      cand_tag = _strip_tags(mtag.group(1), keep_breaks=False).split('。')[0].strip()
      if 6 <= len(cand_tag) <= 44 and not synopsis.startswith(cand_tag[:12]):
        tagline = cand_tag

    region = _detect_region(f'{title} {synopsis} {director} {" ".join(cast)}', orig_title, fid)
    genres = _detect_genres(f'{title} {synopsis}')
    rel_year = int(rel_date[:4]) if rel_date and rel_date[:4].isdigit() else year_now
    is_rerelease = bool(
        (rel_year and rel_year <= year_now - 2)
        or re.search(r'重映|修復版|數位修復|週年紀念|經典重現', f'{raw_full_t} {title} {tagline}')
    )
    if badge == '二輪院線':
      run_cat = 'second_run'
      base_badge = '二輪院線'
    elif is_rerelease:
      run_cat = 'rerelease'
      base_badge = '經典重映'
    elif badge == '本週新片上映':
      run_cat = 'new'
      base_badge = '本週新片上映'
    else:
      run_cat = 'now'
      base_badge = '院線熱映中'
    badge_txt = f'{base_badge} · 全台 {theaters} 廳' if theaters >= 1 else base_badge

    return {
        'id': f'now-{fid.lower()}',
        'title': title,
        'origTitle': orig_title or title,
        'year': rel_year,
        'decade': f'{(rel_year // 10) * 10}s',
        'releaseDate': rel_date or dt_now.strftime('%Y-%m'),
        'statusBadge': badge_txt,
        'runCategory': run_cat,
        'theaters': theaters,
        'region': region,
        'genres': genres,
        'director': director or '院線主創團隊',
        'cast': cast,
        'runtime': runtime or 115,
        'rating': 7.9 if theaters >= 50 else (7.7 if theaters >= 20 else 7.5),
        'poster': poster_url,
        'posterFallback': imdb_poster if imdb_poster and imdb_poster != poster_url else '',
        'stills': stills,
        'tagline': tagline,
        'synopsis': synopsis,
        'analysis': _build_analysis(title, orig_title, region, genres, synopsis.replace('\n', ' '), director, cast, runtime),
        'mood': ['院線熱映', base_badge],
        'isNowPlaying': True,
    }

  fetched: list[dict] = []
  with ThreadPoolExecutor(max_workers=16) as pool:
    for res in pool.map(_fetch_detail, candidates):
      if res is not None:
        fetched.append(res)
  cat_rank = {'new': 2, 'now': 2, 'rerelease': 1, 'second_run': 0}
  fetched.sort(
      key=lambda x: (
          cat_rank.get(x.get('runCategory', 'now'), 1),
          x.get('theaters', 0),
          x.get('releaseDate', ''),
      ),
      reverse=True,
  )
  items = fetched[:max_items]

  return items


def fetch_from_gnews_fallback(max_items: int = 10) -> list[dict]:
  """Fallback to Google News Taiwan Cinema RSS if theater site is unreachable."""
  q = urllib.parse.quote('台灣 電影 上映 院線 when:14d')
  url = f'https://news.google.com/rss/search?q={q}&hl=zh-TW&gl=TW&ceid=TW:zh-Hant'
  xml_txt = _http_get(url, timeout=12)
  root = ET.fromstring(xml_txt)
  items: list[dict] = []
  seen_titles: set[str] = set()
  yr = now_taipei().year
  for item in root.findall('.//item'):
    raw_t = (item.findtext('title') or '').strip()
    m = re.search(r'《([^》]{2,22})》', raw_t)
    if not m:
      continue
    mtitle = m.group(1).strip()
    if mtitle in seen_titles:
      continue
    seen_titles.add(mtitle)
    clean_news = re.sub(r'\s*-\s*[^-]+$', '', raw_t).strip()
    region = _detect_region(f'{mtitle} {clean_news}')
    genres = _detect_genres(f'{mtitle} {clean_news}')
    slug = re.sub(r'[^a-z0-9]+', '-', mtitle.encode('utf-8').hex()[:10])
    items.append({
        'id': f'now-rss-{slug}',
        'title': mtitle,
        'origTitle': mtitle,
        'year': yr,
        'decade': f'{(yr // 10) * 10}s',
        'releaseDate': now_taipei().strftime('%Y-%m'),
        'statusBadge': '近期院線話題',
        'region': region,
        'genres': genres,
        'director': '院線主創團隊',
        'cast': [],
        'runtime': 118,
        'rating': 7.7,
        'tagline': clean_news[:40],
        'synopsis': f'近期台灣院線熱議焦點作品：{clean_news}。',
        'analysis': _build_analysis(mtitle, '', region, genres, clean_news, '', [], 118),
        'mood': ['院線熱映', '本週話題'],
        'isNowPlaying': True,
    })
    if len(items) >= max_items:
      break
  return items


def CuratedFallbackItems() -> list[dict]:
  """Offline-safe curated fallback so CI or air-gapped builds never produce an empty shelf."""
  yr = now_taipei().year
  return [
      {
          'id': 'now-mickey-17',
          'title': '米奇17號',
          'origTitle': 'Mickey 17',
          'year': yr,
          'decade': '2020s',
          'releaseDate': f'{yr}-03',
          'statusBadge': '院線熱映焦點',
          'region': 'western',
          'genres': ['scifi', 'comedy', 'drama'],
          'director': '奉俊昊',
          'cast': ['羅伯派汀森', '娜歐蜜艾基', '史蒂芬元', '馬克魯法洛'],
          'runtime': 137,
          'rating': 7.8,
          'tagline': '死而復生的宇宙社畜，遇上第18號自己！',
          'synopsis': '在冰封星球殖民任務中擔任「消耗工」的米奇，每次殉職都會被生物列印機連同記憶重新列印復活；直到第17號僥倖生還回到艙房，卻發現第18號已經誕生，引爆荒誕又犀利的生存危機。',
          'analysis': {
              'highlights': [
                  '《寄生上流》奧斯卡名導奉俊昊進軍好萊塢太空科幻之作，將社畜勞動異化化為黑色幽默寓言。',
                  '羅伯派汀森一人分飾性格截然不同的「17號唯唯諾諾」與「18號狂暴叛逆」，雙重演技火花十足。',
                  '結合外星異獸生態危機與殖民威權諷刺，娛樂爽度與社會批判兼具。',
              ],
              'craft': '冷冽太空艙工業設計對比荒謬喜劇對白，雙胞胎同框攝影調度精準自然。',
              'legacy': '當代科幻黑色喜劇代表作之一，展現作者導演駕馭高預算商業大片的獨特印記。',
          },
          'mood': ['院線熱映', '黑色幽默', '太空科幻'],
          'isNowPlaying': True,
      },
  ]


def update_now_playing() -> dict:
  dt = now_taipei()
  iso_week = dt.strftime('%G-W%V')
  updated_str = dt.strftime('%Y-%m-%d %H:%M')
  source_label = '台灣院線本週上映片單（每週自動同步）'

  items: list[dict] = []
  try:
    items = fetch_from_atmovies(max_items=120)
  except Exception:
    items = []

  if len(items) < 4:
    try:
      rss_items = fetch_from_gnews_fallback(max_items=12)
      existing_titles = {x['title'] for x in items}
      for r in rss_items:
        if r['title'] not in existing_titles:
          items.append(r)
    except Exception:
      pass

  # If network totally blocked, preserve previous JSON or use curated fallback
  if not items and os.path.isfile(NOW_PLAYING_JSON):
    try:
      with open(NOW_PLAYING_JSON, 'r', encoding='utf-8') as f:
        prev = json.load(f)
      items = prev.get('items') or []
      source_label = prev.get('sourceLabel', source_label)
    except Exception:
      items = []

  if not items:
    items = CuratedFallbackItems()

  payload = {
      'updatedAt': updated_str,
      'weekKey': iso_week,
      'scheduleNote': '每週一自動巡檢台灣與國際院線新片，同步更新劇情簡介與看點解析',
      'sourceLabel': source_label,
      'count': len(items),
      'items': items,
  }

  os.makedirs(DATA_DIR, exist_ok=True)
  with open(NOW_PLAYING_JSON, 'w', encoding='utf-8') as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)

  os.makedirs(os.path.dirname(NOW_PLAYING_JS), exist_ok=True)
  js_txt = (
      '/* Auto-generated by tools/update_now_playing.py — 每週自動更新院線熱映清單 */\n'
      'window.CIN_NOW_PLAYING = '
      + json.dumps(payload, ensure_ascii=False, indent=2)
      + ';\n'
  )
  with open(NOW_PLAYING_JS, 'w', encoding='utf-8') as f:
    f.write(js_txt)

  return payload


if __name__ == '__main__':
  res = update_now_playing()
  print(
      f"[now_playing] Updated {res['count']} movies for {res['weekKey']} at {res['updatedAt']}"
  )
