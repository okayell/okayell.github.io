"""Tools package for Cinema Academy."""
