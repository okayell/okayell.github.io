#!/usr/bin/env python3
"""GitHub Actions entry point: refresh data for the current Taiwan-time slot, then rebuild index.html.

Works for both tool families bundled into `app.tar.gz`:
  * 台股智慧選股 (`updater.run_update` / `updater.run_morning_update` + `tools.build_dist.build`)
  * NBA / 英超 / F1 運彩智庫 (`updater.sync_all` + `tools.build_dist.build_all`)

Usage: python3 ci_update.py --mode auto --out ../_site
Writes `deploy=true|false` to $GITHUB_OUTPUT so the workflow only redeploys Pages when a fresh
bundle was built.
"""
from __future__ import annotations

import argparse
import datetime as dt
import glob
import os
import shutil
import sqlite3
import sys
import traceback

ROOT = os.path.dirname(os.path.abspath(__file__))
LAUNCH_DIR = os.getcwd()
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import config  # pylint: disable=wrong-import-position
import updater  # pylint: disable=wrong-import-position
from tools import build_dist  # pylint: disable=wrong-import-position

TZ_TW = dt.timezone(dt.timedelta(hours=8))


def _gh_output(key: str, value: str) -> None:
  path = os.environ.get('GITHUB_OUTPUT')
  if path:
    with open(path, 'a', encoding='utf-8') as f:
      f.write(f'{key}={value}\n')


def _checkpoint_dbs() -> None:
  """Folds WAL files back into the main DB so the Actions cache stores one consistent file."""
  for p in glob.glob(os.path.join(config.DATA_DIR, '*.db')) + glob.glob(
      os.path.join(config.DATA_DIR, '*.sqlite3')):
    try:
      conn = sqlite3.connect(p)
      conn.execute('PRAGMA wal_checkpoint(TRUNCATE)')
      conn.close()
    except sqlite3.Error as e:
      print(f'[ci] checkpoint {os.path.basename(p)} failed: {e}')


# ------------------------------------------------------------------ 台股智慧選股 ---

def _run_tw_stock(mode: str) -> bool:
  import db  # pylint: disable=import-outside-toplevel
  db.init()
  have_data = db.query_one('SELECT COUNT(DISTINCT date) FROM daily')[0] >= 30
  now = updater.now_tw()
  if not have_data:
    mode = 'update'  # first run / cache lost -> full backfill (~35 min)
  elif mode == 'auto':
    if not updater.is_trading_day(now.date()):
      print(f'[ci] {now:%Y-%m-%d} is not a trading day; nothing to refresh.')
      return False
    hm = now.strftime('%H:%M')
    if hm < '09:05':
      mode = 'morning'
    elif hm < '14:25' and hasattr(updater, 'run_intraday_update'):
      mode = 'intraday'
    else:
      mode = 'update'
  print(f'[ci] 台股 mode={mode} at {now:%Y-%m-%d %H:%M} TW (have_data={have_data})')
  if mode == 'morning':
    updater.run_morning_update(reason='GitHub Actions 盤前戰情')
  elif mode == 'intraday' and hasattr(updater, 'run_intraday_update'):
    if not updater.run_intraday_update(reason='GitHub Actions 盤中行情'):
      updater.run_morning_update(reason='GitHub Actions 盤前備援')
  elif mode == 'update':
    updater.run_update(reason='GitHub Actions 排程更新')
  elif mode == 'rebuild':
    updater.run_analytics_only()
  for e in updater.PROGRESS.get().get('errors') or []:
    print('[ci]   warning:', e)
  build_dist.build(force=True)
  return True


# ------------------------------------------------------------- NBA / EPL / F1 ---

def _needs_odds_catchup() -> bool:
  """Returns True if upcoming scheduled games in SQLite are still missing pregame odds."""
  if not os.path.isfile(config.DB_PATH):
    return True
  try:
    conn = sqlite3.connect(config.DB_PATH)
    cols = {r[1] for r in conn.execute('PRAGMA table_info(games)').fetchall()}
    need = False
    if 'close_spread_home' in cols and 'tw_date' in cols:
      today_s = dt.datetime.now(TZ_TW).strftime('%Y-%m-%d')
      tom_s = (dt.datetime.now(TZ_TW) + dt.timedelta(days=1)).strftime('%Y-%m-%d')
      row = conn.execute(
          "SELECT COUNT(*) FROM games WHERE status='SCHEDULED' AND tw_date IN (?, ?) AND close_spread_home IS NULL",
          (today_s, tom_s),
      ).fetchone()
      need = bool(row and row[0] > 0)
    conn.close()
    return need
  except sqlite3.Error:
    return False


def _check_updater_flag(fn_name: str, date_key: str) -> bool:
  """Queries updater.is_early_odds_captured / is_daily_odds_captured against local SQLite."""
  fn = getattr(updater, fn_name, None)
  if not callable(fn) or not os.path.isfile(config.DB_PATH):
    return False
  try:
    import db as arena_db  # pylint: disable=import-outside-toplevel
    conn = arena_db.connect()
    try:
      return bool(fn(conn, date_key))
    finally:
      conn.close()
  except Exception:  # pylint: disable=broad-except
    return False


def _decide_sports_odds(now: dt.datetime, mode: str) -> tuple[bool, str]:
  """Two-Stage Daily Odds Policy:
  - Stage 1 (18:00 TW early capture + Pass-1 analysis): runs once in 17:30..22:29 TW (or on 18:02/18:30 cron).
  - Stage 2 (23:00 TW final lock + 5h line-movement Pass-2 re-analysis): runs once per evening cycle
    (22:30..04:59 TW, or on delayed '3 15 * * *' cron) without overwriting 18:00 open_spread_home/open_total.
  - Fallback catch-up: anytime today/tomorrow's SCHEDULED games still lack close_spread_home.
  """
  hm = now.strftime('%H:%M')
  today_s = now.strftime('%Y-%m-%d')
  cyc_s = (now - dt.timedelta(hours=5)).strftime('%Y-%m-%d')
  cron_sched = os.environ.get('GITHUB_CRON_SCHEDULE', '').strip()

  if mode == 'odds':
    stage = 'final' if (cron_sched == '3 15 * * *' or hm >= '22:30' or hm < '05:00') else 'early'
    return True, stage
  if mode != 'auto':
    return False, 'auto'

  if cron_sched == '3 15 * * *' or hm >= '22:30' or hm < '05:00':
    if not _check_updater_flag('is_daily_odds_captured', cyc_s):
      return True, 'final'

  if ('17:30' <= hm < '22:30') or (cron_sched in ('2 10 * * *', '30 10 * * *') and hm < '22:30'):
    if not _check_updater_flag('is_early_odds_captured', today_s):
      return True, 'early'

  if _needs_odds_catchup():
    return True, 'early'

  return False, 'auto'


def _run_sports(mode: str) -> bool:
  now = dt.datetime.now(TZ_TW)
  first_run = not os.path.exists(config.DB_PATH)
  capture_odds, odds_stage = _decide_sports_odds(now, mode)
  if first_run:
    capture_odds = True
    if odds_stage == 'auto':
      odds_stage = 'final' if (now.strftime('%H:%M') >= '22:30' or now.strftime('%H:%M') < '05:00') else 'early'
  print(
      f'[ci] sports mode={mode} capture_odds={capture_odds} stage={odds_stage} '
      f'at {now:%Y-%m-%d %H:%M} TW (first_run={first_run})'
  )
  if mode in ('auto', 'update', 'odds'):
    try:
      res = updater.sync_all(full_backfill=first_run, update_odds=capture_odds, odds_stage=odds_stage)
    except TypeError:
      try:
        res = updater.sync_all(full_backfill=first_run, update_odds=capture_odds)
      except TypeError:
        res = updater.sync_all(full_backfill=first_run)
    print('[ci] sync result:', res)
  build_dist.build_all()
  return True


def main() -> None:
  ap = argparse.ArgumentParser()
  ap.add_argument('--mode', default='auto',
                  choices=['auto', 'update', 'morning', 'intraday', 'odds', 'rebuild'])
  ap.add_argument('--out', required=True, help='directory that receives index.html')
  args = ap.parse_args()
  args.out = os.path.join(LAUNCH_DIR, args.out)
  os.makedirs(config.DATA_DIR, exist_ok=True)

  is_tw_stock = hasattr(updater, 'run_update')
  try:
    built = _run_tw_stock(args.mode) if is_tw_stock else _run_sports(args.mode)
  except Exception:  # pylint: disable=broad-except
    traceback.print_exc()
    built = False
  finally:
    _checkpoint_dbs()

  src = build_dist.OUT_HTML
  if built and os.path.isfile(src):
    os.makedirs(args.out, exist_ok=True)
    shutil.copyfile(src, os.path.join(args.out, 'index.html'))
    with open(os.path.join(args.out, '.nojekyll'), 'w', encoding='utf-8'):
      pass
    print(f'[ci] built index.html ({os.path.getsize(src):,} bytes)')
    _gh_output('deploy', 'true')
  else:
    print('[ci] no new bundle; keeping the currently deployed page.')
    _gh_output('deploy', 'false')
    if not built and not is_tw_stock and not os.path.exists(config.DB_PATH):
      sys.exit(1)


if __name__ == '__main__':
  main()
