"""Scheduled updater entrypoint for 期貨學院 (Futures Academy).

Compatible with campus_scheduler.py and ci_update.py.
"""

from __future__ import annotations

import os
import sys

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

from tools import update_prices as _up  # noqa: E402


def sync_all(full_backfill: bool = False, *_args, **_kwargs) -> dict:
  """Refreshes commodity, metal, energy and futures price snapshots."""
  payload = _up.update_prices(force_charts=bool(full_backfill))
  return {
      'updatedAt': payload.get('updatedAt'),
      'count': payload.get('count', 0),
      'source': payload.get('source'),
  }
