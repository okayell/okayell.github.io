"""Tools package for 期貨學院 (Futures Academy)."""
