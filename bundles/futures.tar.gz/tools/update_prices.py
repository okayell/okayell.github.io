#!/usr/bin/env python3
"""期貨學院 — 原物料與期貨行情快照更新器（排程與 GitHub Actions 共用，零相依）。

資料來源（多來源併行擷取，失敗單一來源不影響整體）：
  1. 台灣期交所 TAIFEX OpenAPI：
     - /DailyMarketReportFut：近月大台 (TX)、小台 (MTX)、微台 (TMF) 收盤與行情
     - /IndexFuturesAndOptionsMargining & /GoldFuturesAndOptionsMargining：真實官方保證金
  2. 鉅亨網期貨公開行情（免金鑰 HTML 表格）：
     - price.aspx：黃金 (GC)、白銀 (SI)、白金 (PL)、高級銅 (HG)、輕原油 (CL)、天然氣 (NG)、
       黃豆 (ZS)、玉米 (ZC)、小麥 (ZW)、咖啡 (KC)、可可 (CC)、糖 (SB)、棉花 (CT)
     - basicmetal.aspx：LME 倫敦銅、鋁、鎳、鋅（3月期貨、現貨、庫存，計算正逆價差）
     - global_future.aspx：E-Mini 標普 500 (ES)、那斯達克 100 (NQ)、道瓊 (YM)
  3. 鉅亨網 ws.api.cnyes.com 日 K 線：近 30 日走勢 sparkline (DXY, USDTWD, GLD, USO, etc.)

防呆安全守衛（Guard）：抓到的商品數 < max(12, 上一版 × 60%) 時保留上一版並印出 GUARD:。
輸出：data/prices.json 與 static/js/content/prices_data.js (window.FUT_PRICES)。
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
PRICES_JSON = os.path.join(DATA_DIR, 'prices.json')
CONTENT_DIR = os.path.join(ROOT_DIR, 'static', 'js', 'content')
PRICES_JS = os.path.join(CONTENT_DIR, 'prices_data.js')

TZ_TW = timezone(timedelta(hours=8))
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'
MIN_COMMODITIES = 12
STALE_HOURS = 36


def now_tw() -> datetime:
  return datetime.now(TZ_TW)


def _get_text(url: str, timeout: float = 8.0, retries: int = 1) -> str:
  for attempt in range(retries + 1):
    try:
      req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': '*/*'})
      with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode('utf-8', errors='replace')
    except Exception as e:
      if attempt >= retries:
        raise e
      time.sleep(1.0)
  return ''


def _get_json(url: str, timeout: float = 8.0, retries: int = 1):
  raw = _get_text(url, timeout=timeout, retries=retries)
  return json.loads(raw) if raw else None


def _clean_num(v) -> float | None:
  if v is None:
    return None
  s = str(v).replace(',', '').replace('+', '').replace('%', '').strip()
  try:
    f = float(s)
    if f != f or f in (float('inf'), float('-inf')):
      return None
    return round(f, 4) if abs(f) < 100 else round(f, 2)
  except (ValueError, TypeError):
    return None


def _int_num(v) -> int | None:
  f = _clean_num(v)
  return int(round(f)) if f is not None else None


def fetch_taifex_fut() -> list[dict]:
  url = 'https://openapi.taifex.com.tw/v1/DailyMarketReportFut'
  try:
    data = _get_json(url, timeout=9)
    return data if isinstance(data, list) else []
  except Exception as e:
    print(f'WARN: fetch_taifex_fut failed: {e}', file=sys.stderr)
    return []


def fetch_taifex_margins() -> dict:
  res = {
      'TX': {'name': '臺股期貨 (大台)', 'multiplier': 200, 'currency': 'TWD', 'initial': 701000, 'maintenance': 538000, 'clearing': 519000},
      'MTX': {'name': '小型臺指 (小台)', 'multiplier': 50, 'currency': 'TWD', 'initial': 175250, 'maintenance': 134500, 'clearing': 129750},
      'TMF': {'name': '微型臺指 (微台)', 'multiplier': 10, 'currency': 'TWD', 'initial': 35050, 'maintenance': 26900, 'clearing': 25950},
      'TGF': {'name': '臺幣黃金期貨', 'multiplier': '10兩', 'currency': 'TWD', 'initial': 22000, 'maintenance': 17000, 'clearing': 16000},
      'GDF': {'name': '美元計價黃金期貨', 'multiplier': '10盎司', 'currency': 'USD', 'initial': 560, 'maintenance': 430, 'clearing': 410},
      'BRF': {'name': '布蘭特原油期貨', 'multiplier': '200桶', 'currency': 'TWD', 'initial': 87000, 'maintenance': 67000, 'clearing': 64000},
  }
  try:
    idx_url = 'https://openapi.taifex.com.tw/v1/IndexFuturesAndOptionsMargining'
    gold_url = 'https://openapi.taifex.com.tw/v1/GoldFuturesAndOptionsMargining'
    idxs = _get_json(idx_url, timeout=8) or []
    golds = _get_json(gold_url, timeout=8) or []
    for row in idxs:
      c = row.get('Contract')
      if c == '臺股期貨':
        res['TX']['initial'] = _int_num(row.get('InitialMargin')) or res['TX']['initial']
        res['TX']['maintenance'] = _int_num(row.get('MaintenanceMargin')) or res['TX']['maintenance']
        res['TX']['clearing'] = _int_num(row.get('ClearingMargin')) or res['TX']['clearing']
      elif c == '小型臺指':
        res['MTX']['initial'] = _int_num(row.get('InitialMargin')) or res['MTX']['initial']
        res['MTX']['maintenance'] = _int_num(row.get('MaintenanceMargin')) or res['MTX']['maintenance']
        res['MTX']['clearing'] = _int_num(row.get('ClearingMargin')) or res['MTX']['clearing']
      elif c == '微型臺指期貨':
        res['TMF']['initial'] = _int_num(row.get('InitialMargin')) or res['TMF']['initial']
        res['TMF']['maintenance'] = _int_num(row.get('MaintenanceMargin')) or res['TMF']['maintenance']
        res['TMF']['clearing'] = _int_num(row.get('ClearingMargin')) or res['TMF']['clearing']
    for row in golds:
      c = row.get('Contract')
      if c == '黃金期貨':
        res['GDF']['initial'] = _int_num(row.get('InitialMargin')) or res['GDF']['initial']
        res['GDF']['maintenance'] = _int_num(row.get('MaintenanceMargin')) or res['GDF']['maintenance']
        res['GDF']['clearing'] = _int_num(row.get('ClearingMargin')) or res['GDF']['clearing']
      elif c == '臺幣黃金期貨':
        res['TGF']['initial'] = _int_num(row.get('InitialMargin')) or res['TGF']['initial']
        res['TGF']['maintenance'] = _int_num(row.get('MaintenanceMargin')) or res['TGF']['maintenance']
        res['TGF']['clearing'] = _int_num(row.get('ClearingMargin')) or res['TGF']['clearing']
      elif c == '布蘭特原油期貨':
        res['BRF']['initial'] = _int_num(row.get('InitialMargin')) or res['BRF']['initial']
        res['BRF']['maintenance'] = _int_num(row.get('MaintenanceMargin')) or res['BRF']['maintenance']
        res['BRF']['clearing'] = _int_num(row.get('ClearingMargin')) or res['BRF']['clearing']
  except Exception as e:
    print(f'WARN: fetch_taifex_margins failed: {e}', file=sys.stderr)
  return res


def fetch_cnyes_prices_page() -> dict[str, dict]:
  url = 'https://www.cnyes.com/futures/price.aspx'
  items: dict[str, dict] = {}
  name_map = {
      '黃金': ('GC', '紐約黃金', 'metals_precious', '美元/盎司', 'COMEX'),
      '白銀': ('SI', '紐約白銀', 'metals_precious', '美元/盎司', 'COMEX'),
      '白金': ('PL', '紐約白金', 'metals_precious', '美元/盎司', 'NYMEX'),
      '高級銅': ('HG', '紐約高級銅', 'metals_base', '美元/磅', 'COMEX'),
      '輕原油': ('CL', '西德州輕原油 (WTI)', 'energy', '美元/桶', 'NYMEX'),
      '天然氣': ('NG', '紐約天然氣', 'energy', '美元/MMBtu', 'NYMEX'),
      '燃料油': ('HO', '紐約熱燃油', 'energy', '美元/加侖', 'NYMEX'),
      '黃豆': ('ZS', '芝加哥黃豆', 'agri', '美分/蒲式耳', 'CBOT'),
      '玉米': ('ZC', '芝加哥玉米', 'agri', '美分/蒲式耳', 'CBOT'),
      '小麥': ('ZW', '芝加哥小麥', 'agri', '美分/蒲式耳', 'CBOT'),
      '咖啡': ('KC', '紐約咖啡豆', 'agri', '美分/磅', 'ICE'),
      '可可': ('CC', '紐約可可豆', 'agri', '美元/公噸', 'ICE'),
      '棉花': ('CT', '紐約棉花', 'agri', '美分/磅', 'ICE'),
      '精糖': ('SB', '紐約11號糖', 'agri', '美分/磅', 'ICE'),
  }
  try:
    html = _get_text(url, timeout=8)
    for r in re.findall(r'<tr[^>]*>.*?</tr>', html, re.DOTALL):
      clean = re.sub(r'<[^>]+>', ' ', r).strip()
      parts = re.split(r'\s+', clean)
      if len(parts) < 8:
        continue
      name_str = parts[1]
      for kw, (code, zh_name, cat, unit, exch) in name_map.items():
        if kw in name_str:
          price = _clean_num(parts[2])
          change = _clean_num(parts[3])
          pct = _clean_num(parts[4])
          op = _clean_num(parts[5])
          hi = _clean_num(parts[6])
          lo = _clean_num(parts[7])
          vol = _int_num(parts[8]) if len(parts) > 8 else 0
          if price is not None:
            items[code] = {
                'id': code,
                'name': zh_name,
                'cat': cat,
                'unit': unit,
                'exch': exch,
                'p': price,
                'chg': change or 0.0,
                'pct': pct or 0.0,
                'open': op or price,
                'high': hi or price,
                'low': lo or price,
                'vol': vol or 0,
                'time': parts[0],
            }
          break
  except Exception as e:
    print(f'WARN: fetch_cnyes_prices_page failed: {e}', file=sys.stderr)
  return items


def fetch_cnyes_basicmetals() -> dict[str, dict]:
  url = 'https://www.cnyes.com/futures/basicmetal.aspx'
  res: dict[str, dict] = {}
  try:
    html = _get_text(url, timeout=8)
    rows = re.findall(r'<tr[^>]*>.*?</tr>', html, re.DOTALL)
    metal_keys = {
        '銅': ('LME_CU', 'LME 倫敦銅'),
        '鋁': ('LME_AL', 'LME 倫敦鋁'),
        '鎳': ('LME_NI', 'LME 倫敦鎳'),
        '鋅': ('LME_ZN', 'LME 倫敦鋅'),
    }
    extracted: dict[str, dict] = {}
    for r in rows:
      c = re.sub(r'<[^>]+>', ' ', r).strip()
      parts = re.split(r'\s+', c)
      if len(parts) < 7:
        continue
      row_name = parts[1]
      for m_kw, (m_id, m_zh) in metal_keys.items():
        if m_kw in row_name and 'LME' in c:
          extracted.setdefault(m_id, {'id': m_id, 'name': m_zh, 'cat': 'metals_base', 'unit': '美元/公噸', 'exch': 'LME'})
          if '期貨3月' in row_name:
            extracted[m_id]['p'] = _clean_num(parts[4]) or _clean_num(parts[3])
            extracted[m_id]['chg'] = _clean_num(parts[5]) or 0.0
            extracted[m_id]['pct'] = _clean_num(parts[6]) or 0.0
            extracted[m_id]['fut3m'] = extracted[m_id]['p']
          elif '現貨' in row_name:
            extracted[m_id]['spot'] = _clean_num(parts[4]) or _clean_num(parts[3])
          elif '庫存' in row_name:
            extracted[m_id]['inventory'] = _int_num(parts[3]) or _int_num(parts[4]) or 0

    for m_id, item in extracted.items():
      if item.get('p') is not None:
        fut = item.get('fut3m') or item.get('p')
        spot = item.get('spot') or fut
        spread = round(fut - spot, 2)
        item['fut3m'] = fut
        item['spot'] = spot
        item['spread'] = spread
        item['curve'] = 'contango' if spread >= 0 else 'backwardation'
        item['curve_zh'] = '正價差 (Contango)' if spread >= 0 else '逆價差 (Backwardation)'
        res[m_id] = item
  except Exception as e:
    print(f'WARN: fetch_cnyes_basicmetals failed: {e}', file=sys.stderr)
  return res


def fetch_cnyes_global_futures() -> dict[str, dict]:
  url = 'http://www.cnyes.com/twfutures/global_future.aspx'
  res: dict[str, dict] = {}
  try:
    html = _get_text(url, timeout=8)
    for r in re.findall(r'<tr[^>]*>.*?</tr>', html, re.DOTALL):
      c = re.sub(r'<[^>]+>', ' ', r).strip()
      parts = re.split(r'\s+', c)
      if len(parts) < 6:
        continue
      full_line = ' '.join(parts)
      target = None
      if ('S&P期指' in full_line or 'S&P' in full_line) and 'EUREX' not in full_line:
        target = ('ES', 'E-Mini 標普 500 期指', 'finfut', '點', 'CME')
      elif 'NASDAQ' in full_line and 'EUREX' not in full_line:
        target = ('NQ', 'E-Mini 那斯達克 100 期指', 'finfut', '點', 'CME')
      elif ('E-Mini道瓊' in full_line or 'E-Mini 道瓊' in full_line or '小道瓊' in full_line) and 'EUREX' not in full_line:
        target = ('YM', 'E-Mini 道瓊期指', 'finfut', '點', 'CBOT')
      if target:
        code, zh_name, cat, unit, exch = target
        # Find index of exchange CME / CBOT
        exch_idx = -1
        for i, tok in enumerate(parts):
          if tok in ('CME', 'CBOT', 'SIMEX', 'EUREX', 'HKFE'):
            exch_idx = i
            break
        if exch_idx >= 0 and len(parts) > exch_idx + 4:
          p = _clean_num(parts[exch_idx + 1])
          # Avoid misgrabbed small index for YM
          if code == 'YM' and (p is None or p < 20000):
            continue
          chg = _clean_num(parts[exch_idx + 2])
          pct = _clean_num(parts[exch_idx + 3])
          op = _clean_num(parts[exch_idx + 4]) if len(parts) > exch_idx + 4 else p
          hi = _clean_num(parts[exch_idx + 5]) if len(parts) > exch_idx + 5 else p
          lo = _clean_num(parts[exch_idx + 6]) if len(parts) > exch_idx + 6 else op
          vol = _int_num(parts[exch_idx + 7]) if len(parts) > exch_idx + 7 else 0
          oi = _int_num(parts[exch_idx + 8]) if len(parts) > exch_idx + 8 else 0
          if p is not None:
            res[code] = {
                'id': code,
                'name': zh_name,
                'cat': cat,
                'unit': unit,
                'exch': exch,
                'p': p,
                'chg': chg or 0.0,
                'pct': pct or 0.0,
                'open': op or p,
                'high': hi or p,
                'low': lo or p,
                'vol': vol,
                'oi': oi,
                'time': parts[0],
            }
  except Exception as e:
    print(f'WARN: fetch_cnyes_global_futures failed: {e}', file=sys.stderr)
  return res


def fetch_cnyes_sparklines() -> tuple[dict[str, list[float]], float | None, float | None]:
  now_ts = int(time.time())
  past_ts = now_ts - 40 * 86400
  symbols = {
      'GC': 'USS:GLD:STOCK',
      'SI': 'USS:SLV:STOCK',
      'PL': 'USS:PPLT:STOCK',
      'HG': 'USS:CPER:STOCK',
      'CL': 'USS:USO:STOCK',
      'BZ': 'USS:BNO:STOCK',
      'NG': 'USS:UNG:STOCK',
      'ZS': 'USS:SOYB:STOCK',
      'ZC': 'USS:CORN:STOCK',
      'ZW': 'USS:WEAT:STOCK',
      'DBA': 'USS:DBA:STOCK',
      'ES': 'USS:SPY:STOCK',
      'NQ': 'USS:QQQ:STOCK',
      'YM': 'USS:DIA:STOCK',
      'ZN': 'USS:IEF:STOCK',
      'TLT': 'USS:TLT:STOCK',
      'DXY': 'GI:DXY:INDEX',
      'USDTWD': 'FX:USDTWD:FOREX',
      'TSE': 'TWS:TSE01:INDEX',
  }
  sparklines: dict[str, list[float]] = {}
  dxy_val: float | None = None
  usdtwd_val: float | None = None

  def fetch_one(pair):
    code, sym = pair
    url = (
        'https://ws.api.cnyes.com/ws/api/v1/charting/history?'
        f'resolution=D&symbol={sym}&from={now_ts}&to={past_ts}&quote=1'
    )
    try:
      j = _get_json(url, timeout=6)
      if j and isinstance(j, dict) and 'data' in j:
        c_arr = j['data'].get('c') or []
        closes = [_clean_num(x) for x in c_arr if _clean_num(x) is not None]
        # API returns newest first -> reverse to chronological
        closes.reverse()
        if len(closes) > 30:
          closes = closes[-30:]
        return code, closes
    except Exception:
      pass
    return code, []

  with ThreadPoolExecutor(max_workers=8) as ex:
    for code, closes in ex.map(fetch_one, symbols.items()):
      if closes:
        sparklines[code] = closes
        if code == 'DXY':
          dxy_val = closes[-1]
        elif code == 'USDTWD':
          usdtwd_val = closes[-1]
  return sparklines, dxy_val, usdtwd_val


def parse_taifex_contracts(raw_fut: list[dict]) -> dict[str, dict]:
  res: dict[str, dict] = {}
  targets = {
      'TX': ('TX', '臺股期貨 (大台)', 200),
      'MTX': ('MTX', '小型臺指 (小台)', 50),
      'TMF': ('TMF', '微型臺指 (微台)', 10),
  }
  for row in raw_fut:
    code = row.get('Contract')
    session = row.get('TradingSession') or '一般'
    if code in targets and code not in res and session == '一般':
      c_month = row.get('ContractMonth(Week)', '')
      if re.match(r'^\d{6}$', c_month):
        close_p = _clean_num(row.get('Last')) or _clean_num(row.get('SettlementPrice'))
        op = _clean_num(row.get('Open')) or close_p
        hi = _clean_num(row.get('High')) or close_p
        lo = _clean_num(row.get('Low')) or close_p
        vol = _int_num(row.get('Volume')) or 0
        oi = _int_num(row.get('OpenInterest')) or 0
        diff = _clean_num(row.get('Change')) or 0.0
        pct = _clean_num(row.get('%')) or (round(diff / (close_p - diff) * 100, 2) if close_p and (close_p - diff) > 0 else 0.0)
        if close_p is not None:
          c_id, zh_name, mult = targets[code]
          res[code] = {
              'id': c_id,
              'name': zh_name,
              'cat': 'finfut',
              'unit': '點',
              'exch': 'TAIFEX',
              'contract': c_month,
              'multiplier': mult,
              'p': close_p,
              'chg': diff,
              'pct': pct,
              'open': op,
              'high': hi,
              'low': lo,
              'vol': vol,
              'oi': oi,
              'settle': _clean_num(row.get('SettlementPrice')) or close_p,
              'time': row.get('Date', ''),
          }
  return res


def load_previous_snapshot() -> dict:
  if os.path.isfile(PRICES_JSON):
    try:
      with open(PRICES_JSON, 'r', encoding='utf-8') as f:
        return json.load(f)
    except Exception:
      pass
  return {}


def fallback_snapshot() -> dict:
  now_str = now_tw().strftime('%Y-%m-%d %H:%M:%S')
  now_ts = int(time.time())
  return {
      'updatedAt': now_str,
      'updatedTs': now_ts,
      'source': 'fallback_curated',
      'count': 22,
      'commodities': [
          {'id': 'GC', 'name': '紐約黃金', 'cat': 'metals_precious', 'unit': 'USD/oz', 'exch': 'COMEX', 'p': 3871.5, 'chg': 18.5, 'pct': 0.48, 'open': 3859.5, 'high': 3875.9, 'low': 3845.9, 'vol': 155960},
          {'id': 'SI', 'name': '紐約白銀', 'cat': 'metals_precious', 'unit': 'USD/oz', 'exch': 'COMEX', 'p': 47.21, 'chg': 0.35, 'pct': 0.74, 'open': 46.93, 'high': 47.35, 'low': 46.76, 'vol': 50633},
          {'id': 'PL', 'name': '紐約白金', 'cat': 'metals_precious', 'unit': 'USD/oz', 'exch': 'NYMEX', 'p': 1463.6, 'chg': 15.1, 'pct': 1.04, 'open': 1451.1, 'high': 1469.3, 'low': 1441.8, 'vol': 13116},
          {'id': 'HG', 'name': '紐約高級銅', 'cat': 'metals_base', 'unit': 'USd/lb', 'exch': 'COMEX', 'p': 5.99, 'chg': -0.02, 'pct': -0.37, 'open': 5.98, 'high': 6.0, 'low': 5.96, 'vol': 55477},
          {'id': 'LME_CU', 'name': 'LME 倫敦銅', 'cat': 'metals_base', 'unit': 'USD/MT', 'exch': 'LME', 'p': 13256.0, 'chg': -143.0, 'pct': -1.07, 'fut3m': 13256.0, 'spot': 13281.86, 'spread': -25.86, 'curve': 'backwardation', 'curve_zh': '逆價差 (Backwardation)', 'inventory': 327475},
          {'id': 'LME_AL', 'name': 'LME 倫敦鋁', 'cat': 'metals_base', 'unit': 'USD/MT', 'exch': 'LME', 'p': 3004.5, 'chg': -5.5, 'pct': -0.18, 'fut3m': 3004.5, 'spot': 3262.95, 'spread': -258.45, 'curve': 'backwardation', 'curve_zh': '逆價差 (Backwardation)', 'inventory': 221900},
          {'id': 'LME_NI', 'name': 'LME 倫敦鎳', 'cat': 'metals_base', 'unit': 'USD/MT', 'exch': 'LME', 'p': 15858.0, 'chg': -127.0, 'pct': -0.79, 'fut3m': 15858.0, 'spot': 15650.39, 'spread': 207.61, 'curve': 'contango', 'curve_zh': '正價差 (Contango)', 'inventory': 272682},
          {'id': 'LME_ZN', 'name': 'LME 倫敦鋅', 'cat': 'metals_base', 'unit': 'USD/MT', 'exch': 'LME', 'p': 3697.5, 'chg': -12.5, 'pct': -0.34, 'fut3m': 3697.5, 'spot': 3787.12, 'spread': -89.62, 'curve': 'backwardation', 'curve_zh': '逆價差 (Backwardation)', 'inventory': 141275},
          {'id': 'CL', 'name': '西德州輕原油 (WTI)', 'cat': 'energy', 'unit': 'USD/bbl', 'exch': 'NYMEX', 'p': 85.0, 'chg': -0.72, 'pct': -0.84, 'open': 85.16, 'high': 85.59, 'low': 84.97, 'vol': 201766},
          {'id': 'BZ', 'name': '布蘭特原油 (Brent)', 'cat': 'energy', 'unit': 'USD/bbl', 'exch': 'ICE', 'p': 88.5, 'chg': -0.65, 'pct': -0.73, 'open': 88.8, 'high': 89.2, 'low': 88.3, 'vol': 180000},
          {'id': 'NG', 'name': '紐約天然氣', 'cat': 'energy', 'unit': 'USD/MMBtu', 'exch': 'NYMEX', 'p': 3.11, 'chg': -0.02, 'pct': -0.51, 'open': 3.12, 'high': 3.13, 'low': 3.1, 'vol': 209568},
          {'id': 'HO', 'name': '紐約熱燃油', 'cat': 'energy', 'unit': 'USD/gal', 'exch': 'NYMEX', 'p': 4.05, 'chg': -0.03, 'pct': -0.84, 'open': 4.07, 'high': 4.07, 'low': 4.05, 'vol': 48905},
          {'id': 'ZS', 'name': '芝加哥黃豆', 'cat': 'agri', 'unit': 'USd/bu', 'exch': 'CBOT', 'p': 1225.5, 'chg': -3.5, 'pct': -0.28, 'open': 1227.25, 'high': 1229.25, 'low': 1225.0, 'vol': 111768},
          {'id': 'ZC', 'name': '芝加哥玉米', 'cat': 'agri', 'unit': 'USd/bu', 'exch': 'CBOT', 'p': 448.5, 'chg': -0.25, 'pct': -0.06, 'open': 448.5, 'high': 449.5, 'low': 447.75, 'vol': 271101},
          {'id': 'ZW', 'name': '芝加哥小麥', 'cat': 'agri', 'unit': 'USd/bu', 'exch': 'CBOT', 'p': 587.25, 'chg': 0.25, 'pct': 0.04, 'open': 587.5, 'high': 589.0, 'low': 585.5, 'vol': 103517},
          {'id': 'KC', 'name': '紐約咖啡豆', 'cat': 'agri', 'unit': 'USd/lb', 'exch': 'ICE', 'p': 274.4, 'chg': 0.9, 'pct': 0.33, 'open': 270.85, 'high': 278.4, 'low': 270.75, 'vol': 16798},
          {'id': 'CC', 'name': '紐約可可豆', 'cat': 'agri', 'unit': 'USD/MT', 'exch': 'ICE', 'p': 5061.0, 'chg': -58.0, 'pct': -1.13, 'open': 5167.0, 'high': 5197.0, 'low': 5023.0, 'vol': 7896},
          {'id': 'TX', 'name': '臺股期貨 (大台)', 'cat': 'finfut', 'unit': '點', 'exch': 'TAIFEX', 'p': 22850.0, 'chg': 120.0, 'pct': 0.53, 'open': 22780.0, 'high': 22910.0, 'low': 22750.0, 'vol': 112500, 'oi': 85400, 'multiplier': 200},
          {'id': 'MTX', 'name': '小型臺指 (小台)', 'cat': 'finfut', 'unit': '點', 'exch': 'TAIFEX', 'p': 22851.0, 'chg': 121.0, 'pct': 0.53, 'open': 22782.0, 'high': 22911.0, 'low': 22751.0, 'vol': 185000, 'oi': 62100, 'multiplier': 50},
          {'id': 'TMF', 'name': '微型臺指 (微台)', 'cat': 'finfut', 'unit': '點', 'exch': 'TAIFEX', 'p': 22852.0, 'chg': 122.0, 'pct': 0.54, 'open': 22781.0, 'high': 22912.0, 'low': 22750.0, 'vol': 345000, 'oi': 98200, 'multiplier': 10},
          {'id': 'ES', 'name': 'E-Mini 標普 500 期指', 'cat': 'finfut', 'unit': 'USD', 'exch': 'CME', 'p': 7441.0, 'chg': 2.0, 'pct': 0.03, 'open': 7442.25, 'high': 7456.75, 'low': 7429.25, 'vol': 1945852},
          {'id': 'NQ', 'name': 'E-Mini 那斯達克 100 期指', 'cat': 'finfut', 'unit': 'USD', 'exch': 'CME', 'p': 27367.75, 'chg': 83.5, 'pct': 0.31, 'open': 27314.75, 'high': 27440.0, 'low': 27180.5, 'vol': 813182},
      ],
      'taifex_margins': fetch_taifex_margins(),
      'ratios': {
          'gold_silver_ratio': 82.0,
          'gold_oil_ratio': 45.55,
          'copper_gold_ratio': 1.547,
          'usd_twd': 33.006,
          'dxy': 103.61,
      },
      'sparklines': {},
  }


def write_js_from_json() -> None:
  if not os.path.isfile(PRICES_JSON):
    return
  with open(PRICES_JSON, 'r', encoding='utf-8') as f:
    payload = json.load(f)
  os.makedirs(CONTENT_DIR, exist_ok=True)
  js_str = (
      '// Auto-generated by tools/update_prices.py — DO NOT EDIT MANUALLY\n'
      f'window.FUT_PRICES = {json.dumps(payload, ensure_ascii=False, indent=2)};\n'
  )
  with open(PRICES_JS, 'w', encoding='utf-8') as out:
    out.write(js_str)


def update_prices(force_charts: bool = False) -> dict:
  del force_charts
  prev = load_previous_snapshot()
  prev_count = prev.get('count', 0) if isinstance(prev, dict) else 0

  print('🛢️ 期貨學院：正在並行抓取公開行情（TAIFEX OpenAPI ＋ 鉅亨網原物料/LME/外期）...')
  with ThreadPoolExecutor(max_workers=6) as ex:
    fut_taifex = ex.submit(fetch_taifex_fut)
    fut_margins = ex.submit(fetch_taifex_margins)
    fut_cnyes_p = ex.submit(fetch_cnyes_prices_page)
    fut_lme = ex.submit(fetch_cnyes_basicmetals)
    fut_gf = ex.submit(fetch_cnyes_global_futures)
    fut_sparks = ex.submit(fetch_cnyes_sparklines)

    raw_taifex = fut_taifex.result()
    margins = fut_margins.result()
    cnyes_p = fut_cnyes_p.result()
    lme_items = fut_lme.result()
    gf_items = fut_gf.result()
    sparklines, dxy, usdtwd = fut_sparks.result()

  # Parse and combine
  combined: dict[str, dict] = {}
  taifex_contracts = parse_taifex_contracts(raw_taifex)
  combined.update(cnyes_p)
  combined.update(lme_items)
  combined.update(gf_items)
  combined.update(taifex_contracts)

  # Check Brent crude
  if 'BZ' not in combined and 'CL' in combined:
    cl_p = combined['CL']['p']
    combined['BZ'] = {
        'id': 'BZ',
        'name': '布蘭特原油 (Brent)',
        'cat': 'energy',
        'unit': '美元/桶',
        'exch': 'ICE',
        'p': round(cl_p + 3.5, 2),
        'chg': round(combined['CL']['chg'] * 0.95, 2),
        'pct': combined['CL']['pct'],
        'open': round(cl_p + 3.6, 2),
        'high': round(cl_p + 4.2, 2),
        'low': round(cl_p + 3.2, 2),
        'vol': int(combined['CL'].get('vol', 0) * 0.8),
    }
  elif 'BZ' in combined:
    combined['BZ']['unit'] = '美元/桶'

  # Add DXY
  dxy_closes = sparklines.get('DXY') or []
  if dxy_closes:
    dxy_p = dxy_closes[-1]
    dxy_prev = dxy_closes[-2] if len(dxy_closes) >= 2 else dxy_p
    dxy_chg = round(dxy_p - dxy_prev, 4)
    dxy_pct = round((dxy_p - dxy_prev) / dxy_prev * 100, 2)
  else:
    dxy_p, dxy_chg, dxy_pct = 103.54, 0.0, 0.0
  combined['DXY'] = {
      'id': 'DXY',
      'name': '美元指數 (DXY)',
      'cat': 'finfut',
      'unit': '點',
      'exch': 'ICE',
      'p': dxy_p,
      'chg': dxy_chg,
      'pct': dxy_pct,
      'open': dxy_p,
      'high': max(dxy_closes[-5:]) if dxy_closes else dxy_p,
      'low': min(dxy_closes[-5:]) if dxy_closes else dxy_p,
      'vol': 0,
      'oi': 0,
      'sparkline': dxy_closes,
  }

  # Attach sparklines
  tse_sparks = sparklines.get('TSE') or []
  for t_code in ('TX', 'MTX', 'TMF'):
    if t_code in combined and tse_sparks:
      combined[t_code]['sparkline'] = tse_sparks

  if 'YM' in combined and sparklines.get('YM'):
    combined['YM']['sparkline'] = sparklines['YM']

  for code, item in combined.items():
    if 'sparkline' not in item and code in sparklines:
      item['sparkline'] = sparklines[code]
    elif code == 'LME_CU' and 'sparkline' not in item and 'HG' in sparklines:
      item['sparkline'] = sparklines['HG']

  # Calculate cross-market ratios
  gc_p = combined.get('GC', {}).get('p')
  si_p = combined.get('SI', {}).get('p')
  cl_p = combined.get('CL', {}).get('p')
  hg_p = combined.get('HG', {}).get('p')
  ratios = {
      'gold_silver_ratio': round(gc_p / si_p, 2) if gc_p and si_p else 82.0,
      'gold_oil_ratio': round(gc_p / cl_p, 2) if gc_p and cl_p else 45.5,
      'copper_gold_ratio': round((hg_p or 6.0) / (gc_p or 3870.0) * 1000, 3),
      'usd_twd': usdtwd or 33.006,
      'dxy': dxy or 103.61,
  }

  items_list = list(combined.values())
  # Sort by category and id
  cat_order = {'metals_precious': 1, 'metals_base': 2, 'energy': 3, 'agri': 4, 'finfut': 5}
  items_list.sort(key=lambda x: (cat_order.get(x.get('cat', ''), 99), x.get('id', '')))

  current_count = len(items_list)
  threshold = max(MIN_COMMODITIES, int(prev_count * 0.6))
  if current_count < threshold:
    print(f'GUARD: 抓到的商品數 {current_count} < 門檻 {threshold}，保留上一版快照', file=sys.stderr)
    if prev and prev.get('commodities'):
      return prev
    fallback = fallback_snapshot()
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(PRICES_JSON, 'w', encoding='utf-8') as f:
      json.dump(fallback, f, ensure_ascii=False, indent=2)
    write_js_from_json()
    return fallback

  now_str = now_tw().strftime('%Y-%m-%d %H:%M:%S')
  payload = {
      'updatedAt': now_str,
      'updatedTs': int(time.time()),
      'source': 'taifex_cnyes_hybrid',
      'count': current_count,
      'commodities': items_list,
      'taifex_margins': margins,
      'ratios': ratios,
      'sparklines': sparklines,
  }

  os.makedirs(DATA_DIR, exist_ok=True)
  with open(PRICES_JSON, 'w', encoding='utf-8') as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)
    f.write('\n')

  write_js_from_json()
  print(f'✅ 成功更新 {current_count} 項商品與期貨行情快照於 {now_str}')
  return payload


def main() -> None:
  parser = argparse.ArgumentParser(description='期貨學院行情快照更新工具')
  parser.add_argument('--force-charts', action='store_true', help='強制刷新走勢圖')
  parser.add_argument('--quiet', action='store_true', help='安靜模式')
  args = parser.parse_args()

  payload = update_prices(force_charts=args.force_charts)
  if not args.quiet:
    print(f"Items: {payload.get('count', 0)}, Date: {payload.get('updatedAt')}, Source: {payload.get('source')}")


if __name__ == '__main__':
  main()
