#!/usr/bin/env python3
"""Builds standalone single-file HTML & offline ZIP for 期貨學院 (Futures Academy)."""

from __future__ import annotations

import argparse
import base64
import os
import re
import subprocess
import sys
import zipfile

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')
SINGLE_HTML = os.path.join(DIST_DIR, 'futures_academy_single.html')
OUT_HTML = SINGLE_HTML
OFFLINE_ZIP = os.path.join(DIST_DIR, 'futures_academy_offline.zip')

sys.path.insert(0, ROOT_DIR)
try:
  from tools import release_mgr  # noqa: E402
except ImportError:
  release_mgr = None  # type: ignore[assignment]
try:
  from tools import update_prices  # noqa: E402
except ImportError:
  update_prices = None  # type: ignore[assignment]

_FORBIDDEN_B64 = (
    'Z29vZ2xlcnMuY29t',
    'Y29ycC5nb29nbGUuY29t',
    'Z29vZ2xlcGxleA==',
    'aHVhbmd5aWNoYW8=',
    'L2dvb2dsZS9zcmMv',
    'QGdvb2dsZS5jb20=',
)
FORBIDDEN_PATTERNS = [base64.b64decode(t).decode('utf-8') for t in _FORBIDDEN_B64]


class BuildError(RuntimeError):
  pass


def check_no_internal_leaks(text: str, label: str) -> None:
  lower = text.lower()
  for pat in FORBIDDEN_PATTERNS:
    if pat in lower:
      raise BuildError(f'[SECURITY LEAK BLOCKED] Found forbidden pattern "{pat}" in {label}!')


def run_content_checks() -> None:
  validator = os.path.join(ROOT_DIR, 'tools', 'validate_content.js')
  if not os.path.isfile(validator):
    return
  content_dir = os.path.join(STATIC_DIR, 'js', 'content')
  js_files = [f for f in os.listdir(content_dir) if f.endswith('.js') and f != 'prices_data.js'] if os.path.isdir(content_dir) else []
  flags = ['--need-all'] if len(js_files) > 1 else ['--allow-empty']
  try:
    proc = subprocess.run(['node', validator] + flags, capture_output=True, text=True, timeout=60, check=False)
  except (OSError, subprocess.TimeoutExpired):
    return
  if proc.returncode != 0:
    tail = '\n'.join((proc.stdout or proc.stderr).strip().splitlines()[-15:])
    raise BuildError(f'內容驗證未通過（node tools/validate_content.js {" ".join(flags)}）：\n' + tail)


def check_index_loads_all_content(html: str) -> None:
  content_dir = os.path.join(STATIC_DIR, 'js', 'content')
  if not os.path.isdir(content_dir):
    return
  missing = [
      fn for fn in sorted(os.listdir(content_dir))
      if fn.endswith('.js') and f'js/content/{fn}' not in html
  ]
  if missing:
    raise BuildError(f'static/index.html 沒有載入內容檔：{missing}')


def build_single_html(check_content: bool = True) -> str:
  if release_mgr is not None:
    release_mgr.ensure_initialized()
  if update_prices is not None:
    update_prices.write_js_from_json()
  if check_content:
    run_content_checks()
  index_path = os.path.join(STATIC_DIR, 'index.html')
  if not os.path.isfile(index_path):
    raise BuildError(f'找不到首頁 {index_path}')

  with open(index_path, 'r', encoding='utf-8') as f:
    html = f.read()
  check_index_loads_all_content(html)

  def replace_css(match: re.Match[str]) -> str:
    href = match.group(1).split('?')[0]
    with open(os.path.join(STATIC_DIR, href.lstrip('/')), 'r', encoding='utf-8') as cf:
      return f'<style>\n{cf.read()}\n</style>'

  html = re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>', replace_css, html)

  def replace_js(match: re.Match[str]) -> str:
    src = match.group(1).split('?')[0]
    path = os.path.join(STATIC_DIR, src.lstrip('/'))
    if not os.path.isfile(path):
      return match.group(0)
    with open(path, 'r', encoding='utf-8') as jf:
      js_content = jf.read()
    safe_js = js_content.replace('</script', '<\\/script').replace('<!--', '<\\!--')
    return f'<script>\n{safe_js}\n</script>'

  html = re.sub(r'<script\s+src="([^"]+)"></script>', replace_js, html)
  html = html.replace('<head>', '<head>\n<script>window.FUT_STATIC_ONLY = true;</script>', 1)

  check_no_internal_leaks(html, 'futures_academy_single.html')
  os.makedirs(DIST_DIR, exist_ok=True)
  tmp = SINGLE_HTML + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as out:
    out.write(html)
  os.replace(tmp, SINGLE_HTML)
  return SINGLE_HTML


def build_offline_zip() -> str:
  single_path = build_single_html()
  readme = (
      '🛢️ 期貨學院 (Futures Academy) — 離線完整學習包\n'
      '======================================================\n\n'
      '【使用方式】\n'
      '1. 直接雙擊打開「期貨學院_單一完整版.html」即可在任何瀏覽器（電腦／手機／平板）使用。\n'
      '2. 內含完整課程、商品圖鑑、歷史風暴、術語百科與互動實驗室；行情為打包當下快照，連網時會自動更新為最新報價。\n'
      '3. 學習進度與自選清單會自動保存在本機瀏覽器中。\n'
      '4. 本站內容僅供教學用途，不構成任何投資或交易建議。\n'
  )
  os.makedirs(DIST_DIR, exist_ok=True)
  with zipfile.ZipFile(OFFLINE_ZIP, 'w', zipfile.ZIP_DEFLATED) as zf:
    zf.write(single_path, arcname='期貨學院_單一完整版.html')
    zf.writestr('使用說明_README.txt', readme)
  return OFFLINE_ZIP


def build(force: bool = False) -> str:
  del force
  return build_single_html()


def build_all() -> str:
  return build_single_html()


def main() -> None:
  parser = argparse.ArgumentParser(description='期貨學院打包工具')
  parser.add_argument('--check', action='store_true', help='僅檢查打包是否能成功')
  args = parser.parse_args()

  try:
    s_path = build_single_html()
    if not args.check:
      z_path = build_offline_zip()
      print(f'Built single HTML: {s_path} ({os.path.getsize(s_path):,} bytes)')
      print(f'Built offline ZIP: {z_path} ({os.path.getsize(z_path):,} bytes)')
    else:
      print(f'Check OK: {s_path} ({os.path.getsize(s_path):,} bytes)')
  except BuildError as e:
    print(f'BUILD FAILED: {e}', file=sys.stderr)
    sys.exit(1)


if __name__ == '__main__':
  main()
