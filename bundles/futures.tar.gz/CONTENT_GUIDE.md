# 🛢️ 期貨學院 — 內容撰寫規範（CONTENT_GUIDE）

期貨學院教材全面模組化，放在 `static/js/content/`，採用**自我註冊（Self-Registering）**模式。
每個檔案只能對全域陣列 `.push(...)`，禁止用 `=` 覆蓋。

寫完任何檔案後，請執行驗證：
```bash
node tools/validate_content.js            # 驗證全部內容檔（跨檔斷鏈檢查）
node tools/validate_content.js <file.js>  # 只驗證單一檔案
```

`ERROR` 必須歸零才算完成；`WARN` 盡量排除。

---

## 0. 檔案開頭固定寫法

```js
(function () {
  'use strict';
  window.FUT_LESSONS = window.FUT_LESSONS || [];
  window.FUT_COMMODITIES = window.FUT_COMMODITIES || [];
  window.FUT_HISTORY = window.FUT_HISTORY || [];
  window.FUT_GLOSSARY = window.FUT_GLOSSARY || [];

  // 一筆資料一個 .push(...)
})();
```

字串一律使用標準單引號或雙引號純文字，**嚴禁含 HTML 標籤、嚴禁含外部網址**。

---

## 1. 共同文字規範與教學中立原則

- **繁體中文（台灣習慣用語）**：
  - 嚴格禁用簡體字與大陸用語：部位（禁用「頭寸」）、資訊（禁用「信息」）、預設（禁用「默認」）、影片（禁用「視頻」）、軟體（禁用「軟件」）、演算法（禁用「算法」）、資料（禁用「數據」）、網路（禁用「網絡」）、智慧合約（禁用「智能合約」）、虛擬貨幣／加密貨幣（禁用「數字貨幣」）。
  - 所有漢字必須相容 `Big5-HKSCS` 編碼。
- **教學中立與風險揭露（中立免責聲明）**：
  - 本站為原物料與期貨市場制度、避險原理與風險控管教學用途，不構成任何投資或交易建議。
  - **嚴格禁用任何賭博用語**：不用「下注／莊家／賭場／贏錢／輸光」，一律使用精確金融術語「建倉／部位／對手方／結算損益／強制平倉／風險控管」。
  - 談到槓桿與報酬時，**必須同時強調下檔風險與保證金追繳機制**。
- **白話比喻（必備）**：
  - 每個專有名詞與困難機制都必須具備生活化比喻（`plain: '🧒 白話比喻：...'`），例如把「期貨合約」比喻為農夫與麵包店提前簽訂的預購保證契約；把「保證金」比喻為租屋押金而非商品售價；把「正價差轉倉」比喻為換約時被扣除的倉儲與保險租金。

---

## 2. 四大全域結構規格

### (1) 課程規格 `window.FUT_LESSONS`
全院分為 8 大專章（共 32 堂課）：
- `basics`（期貨起源與市場本質，4 堂）
- `margin`（保證金・槓桿與結算追繳，4 堂）
- `spread`（基差・正逆價差與轉倉損益，4 堂）
- `metals`（貴金屬與工業金屬原物料，4 堂）
- `energy`（原油・天然氣與能源鏈，4 堂）
- `agri`（農產品・氣候週期與軟性商品，4 堂）
- `finfut`（金融期貨・大台小台微台與外期，4 堂）
- `hedging`（避險對沖實務與機構策略，4 堂）

每堂課必備欄位：
```js
window.FUT_LESSONS.push({
  id: 'basics-01',                  // <track>-<兩位數流水號>
  track: 'basics',                  // 8 大專章之一
  order: 1,                         // 專章內排序
  icon: '📜',                       // 代表圖示
  title: '什麼是期貨？起源、本質與「一口合約」的意思', // 12–28 字
  sub: '從江戶時代大阪堂島白米會所到芝加哥商品交易所的制度演進', // 16–45 字
  minutes: 6,                       // 預估閱讀時間 5–10 分鐘
  diagram: 'spot-vs-forward-futures', // 對應 diagrams.js 的 SVG 圖解 key
  plain: '🧒 白話比喻：把期貨想成手搖飲店提前三個月跟果農預約愛文芒果收購價的合約書……',
  takeaway: '期貨的本質是標準化的「遠期合約」，不是買賣實物現貨，而是交換到期時的價格承諾與風險。',
  sections: [
    {
      h: '段落小標題',
      p: ['段落說明第一段……', '段落說明第二段……'],
      list: ['核心要點 A', '核心要點 B'] // 可選
    },
    // 至少 3 個 section
  ],
  pitfall: {
    bad: '誤以為買進一口期貨就像買進一張股票，只要不賣就不會賠錢。',
    good: '期貨合約有到期日限制且每天依結算價「逐日結算（Mark to Market）」，保證金不足會被追繳或強平。'
  },
  terms: ['遠期合約', '標準化合約', '逐日結算'], // 至少 3 個，必須能在 FUT_GLOSSARY 找到！
  quiz: [
    {
      q: '期貨合約與現貨交易最主要的本質差異為何？',
      opts: ['期貨沒有交割日', '期貨是以保證金交易未來的標準化合約', '期貨只有法人可以買賣', '期貨價格永遠高於現貨'],
      ans: 1,                       // 0-3
      exp: '期貨是交易人支付保證金，約定在未來特定日期按約定價格交割特定數量標的物的標準化合約。'
    },
    // 剛好 3 題選擇題
  ]
});
```

### (2) 商品圖鑑規格 `window.FUT_COMMODITIES`
涵蓋 5 大類共 24 項核心商品：
- `metals_precious`（黃金 GC、微型黃金 MGC、白銀 SI、微型白銀 SIL、鉑金 PL、鈀金 PA）
- `metals_base`（紐約高級銅 HG、LME 銅、LME 鋁、LME 鎳、LME 鋅）
- `energy`（輕原油 CL、微型輕油 MCL、布蘭特原油 BZ、天然氣 NG、熱燃油 HO）
- `agri`（芝加哥黃豆 ZS、芝加哥玉米 ZC、芝加哥小麥 ZW、紐約咖啡 KC、紐約可可 CC、紐約棉花 CT、11號糖 SB）
- `finfut`（臺股期貨 TX、小型臺指 MTX、微型臺指 TMF、E-Mini S&P 500 ES、E-Mini Nasdaq 100 NQ）

每項商品必備欄位：
```js
window.FUT_COMMODITIES.push({
  id: 'gold',
  priceId: 'GC',                    // 串接 FUT_PRICES 的 id
  cat: 'metals_precious',
  icon: '🥇',
  name: '紐約黃金期貨 (GC)',
  en: 'COMEX Gold Futures',
  code: 'GC',
  exchange: 'CME (COMEX)',
  contractSize: '100 金衡盎司 (約 3,110.35 公克)',
  quoteUnit: '美元／金衡盎司',
  tickSize: '0.10 美元／盎司（每跳動點 10 美元）',
  settlement: '實物交割（台灣交易人多以現金平倉或自動轉倉）',
  tradingHours: '週一至週五 06:00 – 次日 05:00（台北時間，夏令）',
  seasonality: '通常在農曆年前飾金旺季、印度排燈節及下半年需求較強。',
  supplyDemand: '開採成本、央行黃金儲備買盤、地緣政治避險與首飾工業需求。',
  bullFactors: ['實質利率走低／降息循環', '地緣政治衝突升溫', '各國央行去美元化大舉增持', '通膨長期預期上升'],
  bearFactors: ['實質利率走高／聯準會升息', '美元指數強勢走高', '市場風險偏好轉向股市風險資產'],
  twAccess: '國內期貨商複委託可直接交易大黃金 (GC) 或微型黃金 (MGC)，期交所亦有台幣黃金期貨 (TGF)。',
  plain: '黃金是全球歷史最悠久的零信用風險資產，價格主要與「美國實質利率（名目利率減通膨）」呈反向變動。',
  relatedLessons: ['metals-01', 'hedging-02']
});
```

### (3) 歷史風暴規格 `window.FUT_HISTORY`
收錄 12 則經典歷史期貨大事件：
1. 1980 杭特兄弟白銀操縱案（Silver Thursday）
2. 2020 負油價風暴（WTI 跌至 -37.63 美元）
3. 2022 倫敦金屬交易所（LME）妖鎳逼空事件
4. 1995 霸菱銀行破產案（李森日經期貨違規交易）
5. 1998 長期資本管理（LTCM）俄羅斯國債違約引爆
6. 1973 第一次石油危機與原油期貨誕生
7. 2008 糧食危機與小麥黃豆價格飆漲
8. 2011 瑞士法郎脫鉤黑天鵝與外匯期貨震撼
9. 2018 台灣期交所 206 選擇權屠殺與盤後風控改革
10. 1987 黑色星期一與期現連動融斷機制出台
11. 1970 早期洋蔥期貨禁令（Onion Futures Act）
12. 2024 黃金創歷史新高突破 3,500 美元央行購金潮

### (4) 術語百科規格 `window.FUT_GLOSSARY`
收錄 65+ 則雙語術語（分為 `basics`, `margin`, `spread`, `commodity`, `trading`, `risk` 6 大分類）。
每個條目具備 `term, en, cat, def, example`。
嚴格驗證：所有出現在 `FUT_LESSONS[].terms` 的詞條，都必須能在 `FUT_GLOSSARY` 中檢索得到！
