/* 期貨學院互動實驗室（一）— 框架、保證金與斷頭試算器、正逆價差轉倉模擬器 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};
  var labs = FUT.labs = FUT.labs || {};

  // 實驗室五大模組註冊清單
  FUT.LAB_DEFS = [
    { id: 'margin', name: '保證金・斷頭試算', icon: '🧮', desc: '直連期交所真實保證金，即時推算未平倉損益、追繳與 25% 斷頭水位' },
    { id: 'curve', name: '正逆價差＆轉倉模擬', icon: '📈', desc: 'Contango 與 Backwardation 12 個月期限結構與期貨 ETF 滾動損耗' },
    { id: 'hedge', name: '避險對沖工作台', icon: '🛡️', desc: '台股配小微台、銀樓金飾、航油與食品原料 4 大情境對沖三線圖' },
    { id: 'unit', name: '原物料單位換算器', icon: '⚖️', desc: '金衡盎司/台錢、蒲式耳/公噸八進位報價與美制加侖即時匯率折算' },
    { id: 'spread', name: '產業鏈價差實驗室', icon: '🛢️', desc: '3:2:1 煉油裂解毛利模型與金銀比景氣溫度計' }
  ];

  // 實驗室主頁面入口
  FUT.route('labs', function (el, args) {
    var activeLab = args[0] || 'margin';
    renderLabsContainer(el, activeLab);
  });

  function renderLabsContainer(el, activeId) {
    var tabsHtml = FUT.LAB_DEFS.map(function (d) {
      var act = d.id === activeId ? 'active' : '';
      return '<button class="fut-lab-tab ' + act + '" data-lab="' + d.id + '">' +
        d.icon + ' ' + d.name + '</button>';
    }).join('');

    var curDef = FUT.LAB_DEFS.find(function (d) { return d.id === activeId; }) || FUT.LAB_DEFS[0];

    el.innerHTML =
      '<div class="fut-container">' +
        '<div class="fut-page-header">' +
          '<h2>🧪 互動實驗室 — 理論與市場實務工作台</h2>' +
          '<p class="fut-subtext">結合真實市場制度參數，親自動手模擬槓桿風控、曲線轉倉、現貨避險與跨商品價差模型。</p>' +
        '</div>' +
        '<div class="fut-lab-tabs">' + tabsHtml + '</div>' +
        '<div class="fut-lab-header-banner">' +
          '<span class="fut-lab-badge">' + curDef.icon + ' ' + curDef.name + '</span>' +
          '<span class="fut-lab-desc">' + curDef.desc + '</span>' +
        '</div>' +
        '<div id="labContent" class="fut-lab-content"></div>' +
      '</div>';

    FUT.$$('.fut-lab-tab', el).forEach(function (btn) {
      btn.onclick = function () {
        var lid = btn.getAttribute('data-lab');
        FUT.go('labs/' + lid);
      };
    });

    var box = document.getElementById('labContent');
    if (labs[activeId]) {
      labs[activeId](box);
    } else {
      box.innerHTML = '<div class="fut-empty">實驗室尚未載入</div>';
    }
  }

  // ==========================================
  // Lab 1: 保證金・槓桿・追繳與 25% 斷頭試算器
  // ==========================================
  labs.margin = function (box) {
    var margins = FUT.prices && FUT.prices.getMargins ? FUT.prices.getMargins() : {};
    var PRESETS = {
      TX: { name: '台指期 (大台 TX)', mult: 200, init: (margins.TX && margins.TX.initial) || 701000, maint: (margins.TX && margins.TX.maintenance) || 538000, price: 23500 },
      MTX: { name: '小型台指 (小台 MTX)', mult: 50, init: (margins.MTX && margins.MTX.initial) || 175250, maint: (margins.MTX && margins.MTX.maintenance) || 134500, price: 23500 },
      TMF: { name: '微型台指 (微台 TMF)', mult: 10, init: (margins.TMF && margins.TMF.initial) || 35050, maint: (margins.TMF && margins.TMF.maintenance) || 26900, price: 23500 },
      GC: { name: '紐約黃金 (GC)', mult: 100, init: 11000, maint: 10000, price: 3850 },
      CL: { name: '西德州原油 (CL)', mult: 1000, init: 6800, maint: 6180, price: 71.5 }
    };

    var state = {
      symbol: 'MTX',
      equity: 300000,
      lots: 1,
      dir: 1,
      entry: 23500,
      cur: 23200
    };

    box.innerHTML =
      '<div class="fut-grid-2">' +
        '<div class="fut-card">' +
          '<h3>⚙️ 交易參數設定</h3>' +
          '<div class="fut-form-row">' +
            '<label>標的合約：</label>' +
            '<select id="mSymbol" class="fut-select">' +
              Object.keys(PRESETS).map(function (k) {
                return '<option value="' + k + '" ' + (state.symbol === k ? 'selected' : '') + '>' + PRESETS[k].name + '</option>';
              }).join('') +
            '</select>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>保證金專戶資金 (NT$/USD)：</label>' +
            '<input type="number" id="mEquity" class="fut-input" value="' + state.equity + '" step="10000"/>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>建倉方向：</label>' +
            '<div class="fut-btn-group">' +
              '<button type="button" class="fut-btn btn-buy active" id="mDirBuy">買進作多 (+1)</button>' +
              '<button type="button" class="fut-btn btn-sell" id="mDirSell">賣出作空 (-1)</button>' +
            '</div>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>建倉口數：</label>' +
            '<input type="number" id="mLots" class="fut-input" value="' + state.lots + '" min="1" max="100"/>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>建倉成交價位：</label>' +
            '<input type="number" id="mEntry" class="fut-input" value="' + state.entry + '"/>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>目前市場價位：</label>' +
            '<input type="range" id="mCurRange" min="' + Math.round(state.entry * 0.7) + '" max="' + Math.round(state.entry * 1.3) + '" value="' + state.cur + '" class="fut-range"/>' +
            '<input type="number" id="mCur" class="fut-input" value="' + state.cur + '" style="margin-top:6px;"/>' +
          '</div>' +
          '<div class="fut-tip-box">' +
            '💡 台灣期交所官方現行標準：大台原始 70.1 萬、小台 17.5 萬、微台 3.5 萬。盤中風險指標低於 25% 期貨商依規定全數市價砍倉出清！' +
          '</div>' +
        '</div>' +
        '<div class="fut-card" id="mOutput"></div>' +
      '</div>';

    function renderOutput() {
      var cfg = PRESETS[state.symbol];
      var diff = (state.cur - state.entry) * state.dir;
      var upl = diff * cfg.mult * state.lots;
      var curEquity = state.equity + upl;
      var reqInit = cfg.init * state.lots;
      var reqMaint = cfg.maint * state.lots;
      var notional = state.cur * cfg.mult * state.lots;
      var lev = curEquity > 0 ? (notional / curEquity).toFixed(2) : '無限大 (斷頭)';
      var riskRatio = reqInit > 0 ? (curEquity / reqInit * 100) : 0;

      var callPrice = state.entry + ((reqMaint - state.equity) / (cfg.mult * state.lots * state.dir));
      var stopPrice = state.entry + (((reqInit * 0.25) - state.equity) / (cfg.mult * state.lots * state.dir));

      var isCall = curEquity < reqMaint && curEquity >= reqInit * 0.25;
      var isBust = curEquity < reqInit * 0.25;

      var statusBadge = isBust
        ? '<span class="badge-bust">🚨 觸發 25% 強制平倉（斷頭出清）</span>'
        : isCall
        ? '<span class="badge-call">⚠️ 觸發盤後追繳通知（請於次日 12:00 前補足）</span>'
        : '<span class="badge-safe">🟢 部位安全（風險指標正常）</span>';

      var out = document.getElementById('mOutput');
      if (!out) return;

      out.innerHTML =
        '<h3>📊 風控與水位監控報表</h3>' +
        '<div class="fut-status-wrap">' + statusBadge + '</div>' +
        '<div class="fut-kpi-grid">' +
          '<div class="fut-kpi"><div class="kpi-label">未平倉損益 (UPL)</div><div class="kpi-val ' + FUT.pctClass(upl) + '">' + FUT.fmtNum(upl, 0) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">當前帳戶權益數</div><div class="kpi-val">' + FUT.fmtNum(curEquity, 0) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">風險指標比率</div><div class="kpi-val ' + (riskRatio < 25 ? 'c-down' : riskRatio < 100 ? 'c-warn' : 'c-up') + '">' + riskRatio.toFixed(1) + '%</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">實質槓桿倍數</div><div class="kpi-val">' + lev + 'x</div></div>' +
        '</div>' +
        '<div class="fut-meter-wrap">' +
          '<div class="meter-title">保證金風險水位計 (當前 ' + riskRatio.toFixed(1) + '%)</div>' +
          renderMarginMeterSvg(riskRatio) +
        '</div>' +
        '<div class="fut-table-mini">' +
          '<div class="t-row"><span class="t-lbl">原始保證金門檻：</span><span class="t-val">' + FUT.fmtNum(reqInit) + '</span></div>' +
          '<div class="t-row"><span class="t-lbl">維持保證金警戒線：</span><span class="t-val">' + FUT.fmtNum(reqMaint) + '</span></div>' +
          '<div class="t-row"><span class="t-lbl">名目總控制價值：</span><span class="t-val">' + FUT.fmtNum(notional) + '</span></div>' +
          '<div class="t-row"><span class="t-lbl">觸發盤後追繳價位：</span><span class="t-val c-warn">' + (isFinite(callPrice) ? callPrice.toFixed(1) : '—') + ' 點/元</span></div>' +
          '<div class="t-row"><span class="t-lbl">觸發 25% 斷頭砍倉價：</span><span class="t-val c-down">' + (isFinite(stopPrice) ? stopPrice.toFixed(1) : '—') + ' 點/元</span></div>' +
        '</div>';
    }

    function renderMarginMeterSvg(ratio) {
      var pct = Math.max(0, Math.min(150, ratio));
      var w = 460, h = 32;
      var curX = (pct / 150) * w;
      var callX = (100 / 150) * w;
      var bustX = (25 / 150) * w;
      return '<svg viewBox="0 0 ' + w + ' ' + (h + 20) + '" class="fut-svg-meter">' +
        '<rect x="0" y="0" width="' + bustX + '" height="' + h + '" fill="#ef4444" rx="3"/>' +
        '<rect x="' + bustX + '" y="0" width="' + (callX - bustX) + '" height="' + h + '" fill="#f59e0b"/>' +
        '<rect x="' + callX + '" y="0" width="' + (w - callX) + '" height="' + h + '" fill="#10b981" rx="3"/>' +
        '<line x1="' + bustX + '" y1="0" x2="' + bustX + '" y2="' + (h + 8) + '" stroke="#0f172a" stroke-width="1.5"/>' +
        '<text x="' + bustX + '" y="' + (h + 16) + '" fill="#b91c1c" font-size="9" font-weight="bold" text-anchor="middle">25% 斷頭</text>' +
        '<line x1="' + callX + '" y1="0" x2="' + callX + '" y2="' + (h + 8) + '" stroke="#0f172a" stroke-width="1.5"/>' +
        '<text x="' + callX + '" y="' + (h + 16) + '" fill="#b45309" font-size="9" font-weight="bold" text-anchor="middle">100% 原始</text>' +
        '<polygon points="' + curX + ',0 ' + (curX - 5) + ',-8 ' + (curX + 5) + ',-8" fill="#0284c7"/>' +
        '<line x1="' + curX + '" y1="0" x2="' + curX + '" y2="' + h + '" stroke="#0284c7" stroke-width="2.5"/>' +
      '</svg>';
    }

    var sel = document.getElementById('mSymbol');
    var inEq = document.getElementById('mEquity');
    var bBuy = document.getElementById('mDirBuy');
    var bSell = document.getElementById('mDirSell');
    var inLots = document.getElementById('mLots');
    var inEntry = document.getElementById('mEntry');
    var rngCur = document.getElementById('mCurRange');
    var inCur = document.getElementById('mCur');

    sel.onchange = function () {
      state.symbol = sel.value;
      var cfg = PRESETS[state.symbol];
      state.entry = cfg.price;
      state.cur = cfg.price;
      inEntry.value = cfg.price;
      rngCur.min = Math.round(cfg.price * 0.7);
      rngCur.max = Math.round(cfg.price * 1.3);
      rngCur.value = cfg.price;
      inCur.value = cfg.price;
      renderOutput();
    };

    inEq.oninput = function () { state.equity = Number(inEq.value) || 0; renderOutput(); };
    inLots.oninput = function () { state.lots = Math.max(1, Number(inLots.value) || 1); renderOutput(); };
    inEntry.oninput = function () {
      state.entry = Number(inEntry.value) || 1;
      rngCur.min = Math.round(state.entry * 0.7);
      rngCur.max = Math.round(state.entry * 1.3);
      renderOutput();
    };
    rngCur.oninput = function () {
      state.cur = Number(rngCur.value);
      inCur.value = state.cur;
      renderOutput();
    };
    inCur.oninput = function () {
      state.cur = Number(inCur.value) || state.entry;
      rngCur.value = state.cur;
      renderOutput();
    };
    bBuy.onclick = function () {
      state.dir = 1;
      bBuy.classList.add('active');
      bSell.classList.remove('active');
      renderOutput();
    };
    bSell.onclick = function () {
      state.dir = -1;
      bSell.classList.add('active');
      bBuy.classList.remove('active');
      renderOutput();
    };

    renderOutput();
  };

  // ==========================================
  // Lab 2: 正逆價差＆轉倉損益模擬器
  // ==========================================
  labs.curve = function (box) {
    var state = {
      mode: 'contango',
      spot: 70,
      slopePct: 1.5,
      months: 12
    };

    box.innerHTML =
      '<div class="fut-grid-2">' +
        '<div class="fut-card">' +
          '<h3>⚙️ 期限結構與轉倉設定</h3>' +
          '<div class="fut-form-row">' +
            '<label>市場遠期結構：</label>' +
            '<div class="fut-btn-group">' +
              '<button type="button" class="fut-btn active" id="cModeContango">正價差 (Contango)</button>' +
              '<button type="button" class="fut-btn" id="cModeBack">逆價差 (Backwardation)</button>' +
            '</div>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>現貨基準價格 ($)：</label>' +
            '<input type="number" id="cSpot" class="fut-input" value="' + state.spot + '"/>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>每月轉倉基差率 (%)：</label>' +
            '<input type="range" id="cSlopeRange" min="0.5" max="5.0" step="0.1" value="' + state.slopePct + '" class="fut-range"/>' +
            '<input type="number" id="cSlope" class="fut-input" value="' + state.slopePct + '" step="0.1" style="margin-top:6px;"/>' +
          '</div>' +
          '<div class="fut-tip-box" id="cTipBox"></div>' +
        '</div>' +
        '<div class="fut-card" id="cOutput"></div>' +
      '</div>';

    function renderOutput() {
      var curve = [];
      for (var i = 0; i <= state.months; i++) {
        var rate = (state.mode === 'contango' ? 1 : -1) * (state.slopePct / 100);
        var p = state.spot * Math.pow(1 + rate, i);
        curve.push({ m: i, price: p });
      }

      var etfValues = [100];
      for (var j = 1; j <= state.months; j++) {
        var prev = etfValues[j - 1];
        var rollLoss = (state.mode === 'contango' ? -1 : 1) * (state.slopePct / 100);
        etfValues.push(prev * (1 + rollLoss));
      }
      var finalEtf = etfValues[etfValues.length - 1];
      var totalRollPct = finalEtf - 100;

      var tip = document.getElementById('cTipBox');
      if (tip) {
        tip.innerHTML = state.mode === 'contango'
          ? '⚠️ <strong>正價差結構（遠月貴、近月平）：</strong>期貨多頭每逢合約到期，被迫「賣便宜近月・買昂貴遠月」，承受負滾動耗損 (Negative Roll Yield)。長期持有期貨 ETF 會出現嚴重資產縮水！'
          : '✨ <strong>逆價差結構（近月貴、遠月平）：</strong>現貨緊俏時便利收益大於持有成本，期貨多頭「賣昂貴近月・買便宜遠月」，轉倉享受正滾動收益 (Positive Roll Yield)！';
      }

      var out = document.getElementById('cOutput');
      if (!out) return;

      out.innerHTML =
        '<h3>📈 12 個月期限結構與 ETF 轉倉模擬</h3>' +
        '<div class="fut-kpi-grid">' +
          '<div class="fut-kpi"><div class="kpi-label">現貨基準價</div><div class="kpi-val">$' + state.spot.toFixed(2) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">第 12 月遠期合約</div><div class="kpi-val ' + (state.mode === 'contango' ? 'c-warn' : 'c-up') + '">$' + curve[12].price.toFixed(2) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">12 個月轉倉累計</div><div class="kpi-val ' + FUT.pctClass(totalRollPct) + '">' + FUT.fmtPct(totalRollPct) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">期貨 ETF 100元淨值</div><div class="kpi-val">' + finalEtf.toFixed(1) + ' 元</div></div>' +
        '</div>' +
        renderCurveSvg(curve, etfValues);
    }

    function renderCurveSvg(curve, etf) {
      var w = 460, h = 170, pad = 35;
      var minP = Math.min.apply(null, curve.map(function (c) { return c.price; }));
      var maxP = Math.max.apply(null, curve.map(function (c) { return c.price; }));
      var spanP = (maxP - minP) || 1;

      var pts = curve.map(function (c, idx) {
        var x = pad + (idx / 12) * (w - pad * 2);
        var y = h - pad - ((c.price - minP) / spanP) * (h - pad * 2);
        return x.toFixed(1) + ',' + y.toFixed(1);
      }).join(' ');

      return '<svg viewBox="0 0 ' + w + ' ' + h + '" class="fut-svg-curve">' +
        '<line x1="' + pad + '" y1="' + (h - pad) + '" x2="' + (w - pad) + '" y2="' + (h - pad) + '" stroke="#94a3b8" stroke-width="1"/>' +
        '<line x1="' + pad + '" y1="' + pad + '" x2="' + pad + '" y2="' + (h - pad) + '" stroke="#94a3b8" stroke-width="1"/>' +
        '<text x="' + (w - pad) + '" y="' + (h - 8) + '" fill="#64748b" font-size="10" text-anchor="end">到期月份 (M0~M12)</text>' +
        '<polyline points="' + pts + '" fill="none" stroke="' + (state.mode === 'contango' ? '#0284c7' : '#059669') + '" stroke-width="2.5"/>' +
        curve.map(function (c, idx) {
          var x = pad + (idx / 12) * (w - pad * 2);
          var y = h - pad - ((c.price - minP) / spanP) * (h - pad * 2);
          return '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="3" fill="#d97706"/>';
        }).join('') +
      '</svg>';
    }

    var bCont = document.getElementById('cModeContango');
    var bBack = document.getElementById('cModeBack');
    var inSpot = document.getElementById('cSpot');
    var rngSlope = document.getElementById('cSlopeRange');
    var inSlope = document.getElementById('cSlope');

    bCont.onclick = function () {
      state.mode = 'contango';
      bCont.classList.add('active');
      bBack.classList.remove('active');
      renderOutput();
    };
    bBack.onclick = function () {
      state.mode = 'backwardation';
      bBack.classList.add('active');
      bCont.classList.remove('active');
      renderOutput();
    };
    inSpot.oninput = function () { state.spot = Number(inSpot.value) || 1; renderOutput(); };
    rngSlope.oninput = function () {
      state.slopePct = Number(rngSlope.value);
      inSlope.value = state.slopePct;
      renderOutput();
    };
    inSlope.oninput = function () {
      state.slopePct = Number(inSlope.value) || 0;
      rngSlope.value = state.slopePct;
      renderOutput();
    };

    renderOutput();
  };

})();