/* 期貨學院互動實驗室（二）— 避險對沖工作台、原物料單位換算器、產業鏈價差實驗室 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};
  var labs = FUT.labs = FUT.labs || {};

  // ==========================================
  // Lab 3: 現貨＋期貨避險損益對沖工作台
  // ==========================================
  labs.hedge = function (box) {
    var SCENARIOS = [
      { id: 'stock', mode: 'short', name: '台股投資人防禦崩盤 (小台/微台空頭避險)', spotVal: 5000000, beta: 1.15, futMult: 50, futPrice: 23500, unit: '元', futName: '小台 (MTX)', spotLabel: '現貨股票部位' },
      { id: 'gold', mode: 'short', name: '銀樓金飾商存貨避險 (黃金期貨賣出空頭)', spotVal: 4000000, beta: 1.0, futMult: 100 * 32.5, futPrice: 3850, unit: '元', futName: '紐約黃金 (GC)', spotLabel: '金飾存貨部位' },
      { id: 'fuel', mode: 'long', name: '航空公司燃油採購鎖價 (原油期貨多頭避險)', spotVal: 3500000, beta: 1.0, futMult: 1000 * 32.5, futPrice: 70, unit: '美元', futName: '原油 (CL)', spotLabel: '預計採購燃油' },
      { id: 'corn', mode: 'long', name: '食品加工廠玉米原料鎖價 (玉米期貨多頭避險)', spotVal: 2000000, beta: 1.0, futMult: 50 * 32.5, futPrice: 420, unit: '美元', futName: '玉米 (ZC)', spotLabel: '預計採購玉米' }
    ];

    var state = {
      scenIdx: 0,
      priceMovePct: -10, // 標的市場價格變動 %
      lots: 0
    };

    box.innerHTML =
      '<div class="fut-grid-2">' +
        '<div class="fut-card">' +
          '<h3>⚙️ 實務避險情境設定</h3>' +
          '<div class="fut-form-row">' +
            '<label>避險產業情境：</label>' +
            '<select id="hScen" class="fut-select">' +
              SCENARIOS.map(function (s, i) {
                return '<option value="' + i + '" ' + (state.scenIdx === i ? 'selected' : '') + '>' + s.name + '</option>';
              }).join('') +
            '</select>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>現貨曝險總資產規模：</label>' +
            '<input type="number" id="hSpotVal" class="fut-input" value="' + SCENARIOS[0].spotVal + '\" step="500000"/>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>資產 Beta 敏感度：</label>' +
            '<input type="number" id="hBeta" class="fut-input" value="' + SCENARIOS[0].beta + '" step="0.05"/>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label>市場預期價格變動 (%)：</label>' +
            '<input type="range" id="hDropRange" min="-30" max="30" value="' + state.priceMovePct + '" class="fut-range"/>' +
            '<input type="number" id="hDrop" class="fut-input" value="' + state.priceMovePct + '" style="margin-top:6px;"/>' +
          '</div>' +
          '<div class="fut-form-row">' +
            '<label id="hLotsLabel">期貨避險口數：</label>' +
            '<input type="number" id="hLots" class="fut-input" min="1"/>' +
          '</div>' +
          '<div class="fut-tip-box" id="hTipBox"></div>' +
        '</div>' +
        '<div class="fut-card" id="hOutput"></div>' +
      '</div>';

    function renderOutput() {
      var sc = SCENARIOS[state.scenIdx];
      var futNotional = sc.futPrice * sc.futMult;
      var optLots = Math.max(1, Math.round(sc.beta * (sc.spotVal / futNotional)));
      var useLots = state.lots > 0 ? state.lots : optLots;

      var spotPnL = 0;
      var futPnL = 0;

      if (sc.mode === 'short') {
        // 空頭避險（現貨庫存持有者）：市場下跌，現貨價值減損 (spotPnL < 0)；賣出期貨空單獲利 (futPnL > 0)
        spotPnL = sc.spotVal * (state.priceMovePct / 100) * sc.beta;
        futPnL = -1 * (futNotional * (state.priceMovePct / 100) * sc.beta) * useLots;
      } else {
        // 多頭避險（原料採購消費者）：市場上漲，未避險採購成本增加（= 負損益 spotPnL < 0）；買進期貨多單獲利 (futPnL > 0)
        spotPnL = -1 * sc.spotVal * (state.priceMovePct / 100) * sc.beta;
        futPnL = (futNotional * (state.priceMovePct / 100) * sc.beta) * useLots;
      }

      var netPnL = spotPnL + futPnL;
      var effPct = Math.max(0, 100 - (Math.abs(netPnL) / (Math.abs(spotPnL) || 1) * 100));

      var tip = document.getElementById('hTipBox');
      if (tip) {
        tip.innerHTML = sc.mode === 'short'
          ? '💡 <strong>空頭避險 (Short Hedge)：</strong>現貨持有者面對價格崩跌風險，賣出期貨合約對沖。最佳口數 h* = Beta × (現貨值 ÷ 期貨名目價值)。當口數匹配時，期貨空單獲利抵銷現貨價值縮水！'
          : '💡 <strong>多頭避險 (Long Hedge)：</strong>原料採購方（航油、玉米）面臨漲價成本暴增風險，買進期貨合約鎖定採購價。當原物料飆漲時，未避險採購成本變貴（負損益），由期貨多單獲利完全覆蓋！';
      }

      var lbl = document.getElementById('hLotsLabel');
      if (lbl) lbl.textContent = '期貨避險口數（' + (sc.mode === 'short' ? '空單賣出' : '多單買進') + '，理論最佳 ' + optLots + ' 口）：';

      var out = document.getElementById('hOutput');
      if (!out) return;

      out.innerHTML =
        '<h3>🛡️ 損益對沖模擬與避險成效</h3>' +
        '<div class="fut-kpi-grid">' +
          '<div class="fut-kpi"><div class="kpi-label">現貨部位損益</div><div class="kpi-val ' + FUT.pctClass(spotPnL) + '">' + FUT.fmtNum(spotPnL, 0) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">期貨避險損益</div><div class="kpi-val ' + FUT.pctClass(futPnL) + '">' + FUT.fmtNum(futPnL, 0) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">綜合淨損益 (Net)</div><div class="kpi-val ' + (Math.abs(netPnL) < 50000 ? 'c-flat' : FUT.pctClass(netPnL)) + '">' + FUT.fmtNum(netPnL, 0) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">避險防禦有效性</div><div class="kpi-val ' + (effPct > 80 ? 'c-up' : 'c-warn') + '">' + effPct.toFixed(1) + '%</div></div>' +
        '</div>' +
        renderHedgeSvg(spotPnL, futPnL, netPnL, sc.mode);
    }

    function renderHedgeSvg(spot, fut, net, mode) {
      var w = 460, h = 170;
      var maxAbs = Math.max(Math.abs(spot), Math.abs(fut), Math.abs(net), 100000);
      var midY = h / 2;

      function toY(v) { return midY - (v / maxAbs) * (h / 2 - 25); }
      var sy = toY(spot);
      var fy = toY(fut);
      var ny = toY(net);

      return '<svg viewBox="0 0 ' + w + ' ' + h + '" class="fut-svg-hedge">' +
        '<line x1="30" y1="' + midY + '" x2="430" y2="' + midY + '" stroke="#94a3b8" stroke-dasharray="4,4"/>' +
        '<text x="435" y="' + (midY + 4) + '" fill="#64748b" font-size="10">零軸</text>' +

        // 現貨柱
        '<rect x="80" y="' + Math.min(midY, sy) + '" width="60" height="' + Math.max(2, Math.abs(sy - midY)) + '" fill="' + (spot >= 0 ? '#10b981' : '#ef4444') + '" rx="3"/>' +
        '<text x="110" y="' + (h - 8) + '" fill="#475569" font-size="11" font-weight="bold" text-anchor="middle">現貨部位</text>' +
        '<text x="110" y="' + (sy < midY ? sy - 6 : sy + 14) + '" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">' + FUT.fmtNum(spot, 0) + '</text>' +

        // 期貨柱
        '<rect x="200" y="' + Math.min(midY, fy) + '" width="60" height="' + Math.max(2, Math.abs(fy - midY)) + '" fill="' + (fut >= 0 ? '#10b981' : '#ef4444') + '" rx="3"/>' +
        '<text x="230" y="' + (h - 8) + '" fill="#475569" font-size="11" font-weight="bold" text-anchor="middle">期貨' + (mode === 'short' ? '空單' : '多單') + '</text>' +
        '<text x="230" y="' + (fy < midY ? fy - 6 : fy + 14) + '" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">' + FUT.fmtNum(fut, 0) + '</text>' +

        // 淨損益柱
        '<rect x="320" y="' + Math.min(midY, ny) + '" width="60" height="' + Math.max(3, Math.abs(ny - midY)) + '" fill="#f59e0b" rx="3"/>' +
        '<text x="350" y="' + (h - 8) + '" fill="#b45309" font-size="11" font-weight="bold" text-anchor="middle">綜合淨損益</text>' +
        '<text x="350" y="' + (ny < midY ? ny - 6 : ny + 14) + '" fill="#b45309" font-size="10" font-weight="bold" text-anchor="middle">' + FUT.fmtNum(net, 0) + '</text>' +
      '</svg>';
    }

    var sel = document.getElementById('hScen');
    var inSpot = document.getElementById('hSpotVal');
    var inBeta = document.getElementById('hBeta');
    var rngDrop = document.getElementById('hDropRange');
    var inDrop = document.getElementById('hDrop');
    var inLots = document.getElementById('hLots');

    sel.onchange = function () {
      state.scenIdx = Number(sel.value);
      var sc = SCENARIOS[state.scenIdx];
      inSpot.value = sc.spotVal;
      inBeta.value = sc.beta;
      state.lots = 0;
      var futNotional = sc.futPrice * sc.futMult;
      var optLots = Math.max(1, Math.round(sc.beta * (sc.spotVal / futNotional)));
      inLots.value = optLots;
      renderOutput();
    };

    inSpot.oninput = function () { SCENARIOS[state.scenIdx].spotVal = Number(inSpot.value) || 0; renderOutput(); };
    inBeta.oninput = function () { SCENARIOS[state.scenIdx].beta = Number(inBeta.value) || 1; renderOutput(); };
    rngDrop.oninput = function () {
      state.priceMovePct = Number(rngDrop.value);
      inDrop.value = state.priceMovePct;
      renderOutput();
    };
    inDrop.oninput = function () {
      state.priceMovePct = Number(inDrop.value) || 0;
      rngDrop.value = state.priceMovePct;
      renderOutput();
    };
    inLots.oninput = function () { state.lots = Number(inLots.value) || 0; renderOutput(); };

    var initSc = SCENARIOS[0];
    inLots.value = Math.max(1, Math.round(initSc.beta * (initSc.spotVal / (initSc.futPrice * initSc.futMult))));
    renderOutput();
  };

  // ==========================================
  // Lab 4: 全球原物料單位換算＆匯率折算器
  // ==========================================
  labs.unit = function (box) {
    var ratios = FUT.prices && FUT.prices.getRatios ? FUT.prices.getRatios() : {};
    var usdTwd = ratios.usd_twd || 32.5;

    var state = {
      usdTwd: usdTwd,
      goldOzPrice: 3850,
      oilBblPrice: 71.5,
      agriFraction: "1042'2"
    };

    box.innerHTML =
      '<div class="fut-grid-2">' +
        '<div class="fut-card">' +
          '<h3>🥇 貴金屬與匯率換算 (金衡盎司 ⇋ 台灣錢)</h3>' +
          '<div class="fut-form-row"><label>美元兌台幣即時匯率 (USD/TWD)：</label><input type="number" id="uFx" class="fut-input" value="' + state.usdTwd + '" step="0.1"/></div>' +
          '<div class="fut-form-row"><label>國際黃金期貨報價 (美元/金衡盎司)：</label><input type="number" id="uGoldOz" class="fut-input" value="' + state.goldOzPrice + '"/></div>' +
          '<div class="fut-kpi-grid" id="uGoldKpi"></div>' +
          '<div class="fut-tip-box">📌 1 金衡盎司 = 31.1035 公克 = 8.294 台灣錢。銀樓以「台錢、台兩」計價，此換算可一眼看出銀樓實體金與國際期貨價差！</div>' +
        '</div>' +
        '<div class="fut-card">' +
          '<h3>🛢️ 原油與農產品單位換算 (桶/公升、蒲式耳/公噸)</h3>' +
          '<div class="fut-form-row"><label>國際原油期貨報價 (美元/桶)：</label><input type="number" id="uOilBbl" class="fut-input" value="' + state.oilBblPrice + '"/></div>' +
          '<div class="fut-kpi-grid" id="uOilKpi"></div>' +
          '<div class="fut-form-row" style="margin-top:14px;"><label>CBOT 糧食 8 進位輸入（如 1042\'2 代表 1042 又 2/8 美分）：</label><input type="text" id="uAgriFrac" class="fut-input" value="' + state.agriFraction + '"/></div>' +
          '<div class="fut-kpi-grid" id="uAgriKpi"></div>' +
          '<div class="fut-tip-box">🌾 CBOT 穀物以「美分/蒲式耳」報價且採 1/8 點進位；換算成「美元/公噸」便能直接與國際大宗海運 CIF 報價對照！</div>' +
        '</div>' +
      '</div>';

    function updateCalculations() {
      // 貴金屬
      var twdQian = (state.goldOzPrice * state.usdTwd) / 8.29426;
      var gBox = document.getElementById('uGoldKpi');
      if (gBox) {
        gBox.innerHTML =
          '<div class="fut-kpi"><div class="kpi-label">折合台幣 / 台灣錢 (3.75g)</div><div class="kpi-val c-up">NT$ ' + FUT.fmtNum(twdQian, 0) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">折合台幣 / 台灣兩 (10錢)</div><div class="kpi-val">NT$ ' + FUT.fmtNum(twdQian * 10, 0) + '</div></div>';
      }

      // 能源
      var oilTwdPerLiter = (state.oilBblPrice * state.usdTwd) / 158.987;
      var oilUsdPerGallon = state.oilBblPrice / 42;
      var oBox = document.getElementById('uOilKpi');
      if (oBox) {
        oBox.innerHTML =
          '<div class="fut-kpi"><div class="kpi-label">每公升成本 (NT$/L)</div><div class="kpi-val">NT$ ' + oilTwdPerLiter.toFixed(2) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">美制加侖 ($/gal)</div><div class="kpi-val">$' + oilUsdPerGallon.toFixed(2) + '</div></div>';
      }

      // 農產品
      var parts = String(state.agriFraction).split("'");
      var base = parseFloat(parts[0]) || 0;
      var frac = parts[1] ? (parseFloat(parts[1]) / 8) : 0;
      var centsPerBu = base + frac;
      var usdPerMtSoy = (centsPerBu / 100) * 36.7437;
      var usdPerMtCorn = (centsPerBu / 100) * 39.368;
      var aBox = document.getElementById('uAgriKpi');
      if (aBox) {
        aBox.innerHTML =
          '<div class="fut-kpi"><div class="kpi-label">黃豆/小麥 ($/公噸)</div><div class="kpi-val c-up">$' + usdPerMtSoy.toFixed(2) + '</div></div>' +
          '<div class="fut-kpi"><div class="kpi-label">玉米進口折算 ($/公噸)</div><div class="kpi-val">$' + usdPerMtCorn.toFixed(2) + '</div></div>';
      }
    }

    document.getElementById('uFx').oninput = function (e) { state.usdTwd = Number(e.target.value) || 32.5; updateCalculations(); };
    document.getElementById('uGoldOz').oninput = function (e) { state.goldOzPrice = Number(e.target.value) || 0; updateCalculations(); };
    document.getElementById('uOilBbl').oninput = function (e) { state.oilBblPrice = Number(e.target.value) || 0; updateCalculations(); };
    document.getElementById('uAgriFrac').oninput = function (e) { state.agriFraction = e.target.value; updateCalculations(); };

    updateCalculations();
  };

  // ==========================================
  // Lab 5: 產業鏈價差實驗室 (3:2:1 裂解與金銀比)
  // ==========================================
  labs.spread = function (box) {
    var pGC = FUT.prices && FUT.prices.get ? FUT.prices.get('GC') : null;
    var pSI = FUT.prices && FUT.prices.get ? FUT.prices.get('SI') : null;
    var pCL = FUT.prices && FUT.prices.get ? FUT.prices.get('CL') : null;

    var state = {
      crude: (pCL && pCL.price) || 71.5,
      gasoline: 215,
      diesel: 235,
      gold: (pGC && pGC.price) || 3850,
      silver: (pSI && pSI.price) || 33.5
    };

    box.innerHTML =
      '<div class="fut-grid-2">' +
        '<div class="fut-card">' +
          '<h3>🛢️ 3:2:1 煉油裂解毛利模型 (Crack Spread)</h3>' +
          '<div class="fut-form-row"><label>原油進貨成本 (CL 美元/桶)：</label><input type="number" id="sCrude" class="fut-input" value="' + state.crude + '"/></div>' +
          '<div class="fut-form-row"><label>RBOB 汽油期貨售價 (RB 美分/加侖)：</label><input type="number" id="sGas" class="fut-input" value="' + state.gasoline + '"/></div>' +
          '<div class="fut-form-row"><label>超低硫柴油期貨售價 (HO 美分/加侖)：</label><input type="number" id="sDiesel" class="fut-input" value="' + state.diesel + '"/></div>' +
          '<div id="sOutputCrack"></div>' +
          '<div class="fut-tip-box">⚡ 煉油廠標準模型：3 桶原油煉出 2 桶汽油與 1 桶柴油。毛利擴大時有利煉廠獲利並帶動開工率；毛利遭壓縮時煉廠減產歲修。</div>' +
        '</div>' +
        '<div class="fut-card">' +
          '<h3>🥇 金銀比 (Gold/Silver Ratio) 景氣溫度計</h3>' +
          '<div class="fut-form-row"><label>黃金期貨 (GC 美元/盎司)：</label><input type="number" id="sGold" class="fut-input" value="' + state.gold + '"/></div>' +
          '<div class="fut-form-row"><label>白銀期貨 (SI 美元/盎司)：</label><input type="number" id="sSilver" class="fut-input" value="' + state.silver + '" step="0.1"/></div>' +
          '<div id="sOutputGsr"></div>' +
          '<div class="fut-tip-box">🌡️ 金銀比被視為「避險與工業景氣比值」。高於 85 常伴隨重大地緣危機或通縮；低於 60 則顯示全球製造業進入強勁擴張期！</div>' +
        '</div>' +
      '</div>';

    function updateCalculations() {
      // 3:2:1 裂解
      var gasBbl = (state.gasoline / 100) * 42;
      var dslBbl = (state.diesel / 100) * 42;
      var crackMargin = ((2 * gasBbl + 1 * dslBbl) - (3 * state.crude)) / 3;

      var cBox = document.getElementById('sOutputCrack');
      if (cBox) {
        cBox.innerHTML =
          '<div class="fut-kpi-grid">' +
            '<div class="fut-kpi"><div class="kpi-label">綜合煉油毛利 / 桶</div><div class="kpi-val ' + (crackMargin > 15 ? 'c-up' : 'c-warn') + '">$' + crackMargin.toFixed(2) + '</div></div>' +
            '<div class="fut-kpi"><div class="kpi-label">汽油提煉毛利 / 桶</div><div class="kpi-val">$' + (gasBbl - state.crude).toFixed(2) + '</div></div>' +
          '</div>';
      }

      // 金銀比
      var gsr = state.silver > 0 ? (state.gold / state.silver) : 0;
      var gsrStatus = gsr > 85
        ? { text: '🚨 白銀相對低估 / 市場避險情緒狂熱', cls: 'c-down' }
        : gsr < 60
        ? { text: '🔥 製造業擴張熱絡 / 工業銀需求噴發', cls: 'c-up' }
        : { text: '⚖️ 處於歷史常態中樞區間 (60 ~ 85)', cls: 'c-flat' };

      var gBox = document.getElementById('sOutputGsr');
      if (gBox) {
        gBox.innerHTML =
          '<div class="fut-kpi-grid">' +
            '<div class="fut-kpi"><div class="kpi-label">當前金銀比率</div><div class="kpi-val ' + gsrStatus.cls + '">' + gsr.toFixed(2) + '</div></div>' +
            '<div class="fut-kpi"><div class="kpi-label">歷史極值區間</div><div class="kpi-val">30 ~ 125</div></div>' +
          '</div>' +
          '<div class="gsr-status-badge ' + gsrStatus.cls + '">' + gsrStatus.text + '</div>';
      }
    }

    document.getElementById('sCrude').oninput = function (e) { state.crude = Number(e.target.value) || 0; updateCalculations(); };
    document.getElementById('sGas').oninput = function (e) { state.gasoline = Number(e.target.value) || 0; updateCalculations(); };
    document.getElementById('sDiesel').oninput = function (e) { state.diesel = Number(e.target.value) || 0; updateCalculations(); };
    document.getElementById('sGold').oninput = function (e) { state.gold = Number(e.target.value) || 0; updateCalculations(); };
    document.getElementById('sSilver').oninput = function (e) { state.silver = Number(e.target.value) || 1; updateCalculations(); };

    updateCalculations();
  };

})();