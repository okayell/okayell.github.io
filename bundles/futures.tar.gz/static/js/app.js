/* 期貨學院主程式 — 首頁視圖、跨館連動、版本彈窗、導覽列互動與全域調度 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};

  // 跨館連動 URL 產生器（遵守 CAMP-01 本機模式不寫死 okayell.github.io）
  function getToolLink(toolId, hash) {
    if (window.CampusNav && typeof window.CampusNav.toolUrl === 'function') {
      return window.CampusNav.toolUrl(toolId, hash || '');
    }
    if (FUT.isStatic()) {
      return 'https://okayell.github.io/' + toolId + '/' + (hash ? '#' + hash : '');
    }
    var portMap = { finance: 8952, stock: 8954, 'us-stock': 8955, crypto: 8958 };
    var port = portMap[toolId] || 8964;
    return 'http://' + window.location.hostname + ':' + port + '/' + (hash ? '#' + hash : '');
  }

  // 首頁視圖
  FUT.route('home', function (el) {
    var allPrices = FUT.prices.getAll();
    var topSymbols = ['GC', 'CL', 'TX', 'ES', 'SI', 'ZS'];
    var featured = topSymbols.map(function (s) { return FUT.prices.get(s); }).filter(Boolean);
    var doneCnt = FUT.progress.countDone();
    var totalLessons = FUT.LESSONS.length || 32;

    var featHtml = featured.map(function (it) {
      var pctCls = FUT.pctClass(it.change_pct);
      var priceStr = (it.unit === '點')
        ? FUT.fmtNum(it.price, 0) + ' 點'
        : (it.unit && it.unit.indexOf('美分') >= 0)
        ? FUT.fmtNum(it.price, 2) + ' 美分'
        : (it.currency === 'USD' || (it.unit && it.unit.indexOf('美元') >= 0))
        ? '$' + FUT.fmtNum(it.price)
        : 'NT$' + FUT.fmtNum(it.price);

      return '<div class="fut-feat-card" onclick="window.FUT.go(\'market\')">' +
        '<div class="feat-top">' +
          '<span class="feat-name">' + FUT.esc(it.name) + '</span>' +
          '<span class="badge-ex">' + FUT.esc(it.exchange) + '</span>' +
        '</div>' +
        '<div class="feat-price ' + pctCls + '">' + priceStr + '</div>' +
        '<div class="feat-sub ' + pctCls + '">' +
          FUT.pctBadge(it.change_pct) + ' (' + (it.change > 0 ? '+' : '') + FUT.fmtNum(it.change) + ')' +
        '</div>' +
      '</div>';
    }).join('');

    // 跨館連動卡片列表
    var crossLinks = [
      { id: 'finance', name: '🪙 總體財經學院', desc: '利率週期、通膨債券殖利率與外匯基礎', hash: '' },
      { id: 'stock', name: '📈 台股戰情室', desc: '現貨加權指數、法人籌碼與盤後籌碼', hash: '' },
      { id: 'us-stock', name: '🗽 美股戰情室', desc: 'S&P 500、Nasdaq 與科技巨頭財報動能', hash: '' },
      { id: 'crypto', name: '⛓️ 區塊鏈學院', desc: '比特幣衍生性合約、資金費率與鏈上金流', hash: '' }
    ];

    var crossHtml = crossLinks.map(function (c) {
      var url = getToolLink(c.id, c.hash);
      return '<a href="' + url + '" class="fut-cross-card" target="_blank" rel="noopener">' +
        '<div class="cross-head">' +
          '<h4>' + c.name + '</h4>' +
          '<span class="cross-arrow">&rarr;</span>' +
        '</div>' +
        '<p class="cross-desc">' + c.desc + '</p>' +
      '</a>';
    }).join('');

    el.innerHTML =
      '<div class="fut-container">' +
        // Hero 橫幅
        '<div class="fut-hero">' +
          '<div class="fut-hero-badge">🛢️ 原物料與期貨市場深度教學</div>' +
          '<h1>掌握大宗商品定價之鑰・解構槓桿風控與避險機制</h1>' +
          '<p class="fut-hero-lead">' +
            '從 1730 年大阪堂島米市到現代結算所制度。透過精緻原生 SVG 圖解與 5 大互動實驗室，' +
            '穿透正逆價差、轉倉損耗、保證金斷頭機制與產業鏈避險對沖實務。' +
          '</p>' +
          '<div class="fut-hero-actions">' +
            '<button class="fut-btn btn-primary" onclick="window.FUT.go(\'learn\')">🚀 開始系統化學習</button>' +
            '<button class="fut-btn" onclick="window.FUT.go(\'labs\')">🧪 進入互動實驗室</button>' +
            '<button class="fut-btn" onclick="window.FUT.go(\'market\')">📊 查看全球商品行情</button>' +
          '</div>' +
          '<div class="fut-hero-progress">' +
            '<span>當前學習進度：' + doneCnt + ' / ' + totalLessons + ' 堂課 (' + Math.round((doneCnt / totalLessons) * 100) + '%)</span>' +
            '<div class="fut-hero-bar"><div class="bar-fill" style="width:' + ((doneCnt / totalLessons) * 100) + '%;"></div></div>' +
          '</div>' +
        '</div>' +

        // 精選市場報價
        '<div class="fut-section-head">' +
          '<h3>🔥 焦點原物料與主要指數即時/排程行情</h3>' +
          '<button class="fut-btn-link" onclick="window.FUT.go(\'market\')">查看全部 26+ 項商品 &rarr;</button>' +
        '</div>' +
        '<div class="fut-feat-grid">' + featHtml + '</div>' +

        // 四大核心功能卡片
        '<div class="fut-section-head" style="margin-top:32px;">' +
          '<h3>🧭 期貨學院四大核心模組</h3>' +
        '</div>' +
        '<div class="fut-portal-grid">' +
          '<div class="fut-portal-card" onclick="window.FUT.go(\'learn\')">' +
            '<div class="p-icon">📚</div>' +
            '<h4>八大專章 32 堂課程</h4>' +
            '<p>涵蓋合約本質、保證金逐日盯市、正逆價差、能源鏈、貴金屬與台指外期全圖鑑。</p>' +
            '<span class="p-link">瀏覽章節目錄 &rarr;</span>' +
          '</div>' +

          '<div class="fut-portal-card" onclick="window.FUT.go(\'labs\')">' +
            '<div class="p-icon">🧪</div>' +
            '<h4>五大互動實驗室</h4>' +
            '<p>直帶真實期交所保證金與斷頭水位試算、Contango轉倉耗損模擬、避險對沖工作台與 3:2:1 裂解價差。</p>' +
            '<span class="p-link">親自動手模擬 &rarr;</span>' +
          '</div>' +

          '<div class="fut-portal-card" onclick="window.FUT.go(\'history\')">' +
            '<div class="p-icon">🌪️</div>' +
            '<h4>歷史重大期貨風暴</h4>' +
            '<p>2020 負油價慘案、1980 亨特白銀逼倉、2022 倫敦金屬妖鎳與 0206 雙向跌停屠殺。</p>' +
            '<span class="p-link">汲取歷史教訓 &rarr;</span>' +
          '</div>' +

          '<div class="fut-portal-card" onclick="window.FUT.go(\'glossary\')">' +
            '<div class="p-icon">📖</div>' +
            '<h4>專業術語全辭典</h4>' +
            '<p>收錄 65+ 涵蓋基差、便利收益、逐日結算、實物交割標準倉單的中英對照名詞解釋。</p>' +
            '<span class="p-link">查閱術語百科 &rarr;</span>' +
          '</div>' +
        '</div>' +

        // 🔗 財經學區跨館連動
        '<div class="fut-section-head" style="margin-top:36px;">' +
          '<h3>🔗 開心學園・財經學區跨館連動</h3>' +
        '</div>' +
        '<div class="fut-cross-grid">' + crossHtml + '</div>' +

        // 免責聲明
        '<div class="fut-home-disclaimer">' +
          '<h4>⚖️ 期貨學院教學免責與中立原則聲明</h4>' +
          '<p>' +
            '本站由開心學園建設維護，所有教材內容、圖解機制、互動試算與市場行情數據均為<strong>「金融市場運作制度、產業避險對沖實務與風險控管原理之普及教育」</strong>用途，' +
            '絕不涉及任何特定商品之買賣建議、投資獲利保證或交易推薦。期貨與衍生性金融商品具備高槓桿特性，市場波動可能導致超出本金之鉅額虧損，參與前應詳閱交易所官方規格與風控手冊。' +
          '</p>' +
        '</div>' +
      '</div>';
  });

  // 版本更新歷程彈窗
  FUT.showReleaseNotes = function () {
    var rels = window.FUT_RELEASES || [];
    var listHtml = rels.map(function (r) {
      return '<div class="rel-item">' +
        '<div class="rel-head">' +
          '<span class="rel-ver">v' + r.version + '</span>' +
          '<span class="rel-date">' + (r.date || '') + '</span>' +
        '</div>' +
        '<h4 class="rel-title">' + FUT.esc(r.title || '') + '</h4>' +
        '<ul class="rel-changes">' +
          (r.changes || []).map(function (c) { return '<li>' + FUT.esc(c) + '</li>'; }).join('') +
        '</ul>' +
      '</div>';
    }).join('');

    var modal = document.createElement('div');
    modal.className = 'fut-modal-backdrop';
    modal.innerHTML =
      '<div class="fut-modal-box">' +
        '<div class="fut-modal-head">' +
          '<h3>🛢️ 期貨學院版本更新歷程</h3>' +
          '<button class="fut-modal-close">&times;</button>' +
        '</div>' +
        '<div class="fut-modal-body" style="max-height:60vh; overflow-y:auto;">' +
          listHtml +
        '</div>' +
      '</div>';

    document.body.appendChild(modal);
    modal.querySelector('.fut-modal-close').onclick = function () { modal.remove(); };
    modal.onclick = function (e) { if (e.target === modal) modal.remove(); };
  };

  // 全域初始化
  FUT.init = function () {
    FUT.colorScheme.init();
    FUT.prices.init();
    FUT.syncNavCounts();
    FUT.reportProgress();

    // 綁定版號按鈕
    var verBtn = document.getElementById('verBadgeBtn');
    if (verBtn) {
      verBtn.onclick = function () {
        FUT.showReleaseNotes();
      };
    }

    // 監聽價格更新以即時重繪市場或首頁視圖
    FUT.prices.subscribe(function () {
      var r = FUT.parseHash();
      if (r.name === 'market' || r.name === 'home') {
        FUT.rerender();
      }
    });

    // 監聽 Hash 變更
    window.addEventListener('hashchange', function () {
      FUT.rerender();
    });

    // 首次渲染
    FUT.rerender();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', FUT.init);
  } else {
    FUT.init();
  }

})();