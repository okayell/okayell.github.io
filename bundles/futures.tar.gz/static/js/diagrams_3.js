/* 期貨學院原生向量 SVG 圖解引擎（三）— 淺色專業財經主題，第 23 至 32 座圖解 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};
  var D = FUT.diagrams = FUT.diagrams || {};

  // 23. weather-enso-commodity-impact
  D['weather-enso-commodity-impact'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">聖嬰 (El Niño) 與反聖嬰 (La Niña) 原物料氣候傳導圖</text>' +
      '<g transform="translate(60, 65)">' +
        '<rect x="0" y="0" width="290" height="120" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
        '<text x="145" y="28" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">🔥 聖嬰現象 (El Niño)</text>' +
        '<text x="145" y="55" fill="#475569" font-size="11" text-anchor="middle">太平洋東部偏暖，東南亞與澳洲乾旱</text>' +
        '<text x="145" y="75" fill="#dc2626" font-size="11" font-weight="bold" text-anchor="middle">衝擊：棕櫚油、橡膠、咖啡減產</text>' +
        '<text x="145" y="95" fill="#475569" font-size="11" text-anchor="middle">美國南部多雨，美麥生長相對有利</text>' +
      '</g>' +
      '<g transform="translate(410, 65)">' +
        '<rect x="0" y="0" width="290" height="120" rx="6" fill="#f0f9ff" stroke="#0284c7"/>' +
        '<text x="145" y="28" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">❄️ 反聖嬰現象 (La Niña)</text>' +
        '<text x="145" y="55" fill="#475569" font-size="11" text-anchor="middle">太平洋海水偏冷，南美阿根廷嚴重乾旱</text>' +
        '<text x="145" y="75" fill="#dc2626" font-size="11" font-weight="bold" text-anchor="middle">衝擊：阿根廷與美豆減產、大西洋颶風多</text>' +
        '<text x="145" y="95" fill="#0284c7" font-size="11" text-anchor="middle">天然氣與原油海上鑽井平台面臨颶風停工</text>' +
      '</g>'
    );
  };

  // 24. softs-supply-chain-pyramid
  D['softs-supply-chain-pyramid'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">軟性商品 (Softs) 金字塔供應鏈結構 (咖啡、可可、糖、棉花)</text>' +
      '<g transform="translate(60, 65)">' +
        '<rect x="0" y="0" width="180" height="110" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="90" y="28" fill="#b45309" font-size="13" font-weight="bold" text-anchor="middle">產地高度集中</text>' +
        '<text x="90" y="55" fill="#475569" font-size="11" text-anchor="middle">可可：西非象牙海岸+迦納 60%</text>' +
        '<text x="90" y="75" fill="#475569" font-size="11" text-anchor="middle">咖啡：巴西阿拉比卡+越南羅布</text>' +
        '<text x="90" y="95" fill="#dc2626" font-size="10" text-anchor="middle">單一國家氣候可引發暴漲</text>' +
      '</g>' +
      '<g transform="translate(285, 65)">' +
        '<rect x="0" y="0" width="190" height="110" rx="6" fill="#f8fafc" stroke="#f59e0b"/>' +
        '<text x="95" y="28" fill="#b45309" font-size="13" font-weight="bold" text-anchor="middle">跨國貿易商與期貨</text>' +
        '<text x="95" y="55" fill="#475569" font-size="11" text-anchor="middle">嘉吉、路易達孚、ADM</text>' +
        '<text x="95" y="75" fill="#0284c7" font-size="11" text-anchor="middle">ICE 紐約/倫敦合約定價</text>' +
        '<text x="95" y="95" fill="#475569" font-size="10" text-anchor="middle">實體倉單嚴格分級抽驗</text>' +
      '</g>' +
      '<g transform="translate(520, 65)">' +
        '<rect x="0" y="0" width="180" height="110" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
        '<text x="90" y="28" fill="#059669" font-size="13" font-weight="bold" text-anchor="middle">終端消費品品牌</text>' +
        '<text x="90" y="55" fill="#475569" font-size="11" text-anchor="middle">雀巢、星巴克、Hershey</text>' +
        '<text x="90" y="75" fill="#059669" font-size="11" text-anchor="middle">長期買入期貨多頭避險</text>' +
        '<text x="90" y="95" fill="#64748b" font-size="10" text-anchor="middle">原料成本轉嫁消費者</text>' +
      '</g>' +
      '<line x1="245" y1="120" x2="280" y2="120" stroke="#64748b" stroke-width="2" marker-end="url(#arr)"/>' +
      '<line x1="480" y1="120" x2="515" y2="120" stroke="#64748b" stroke-width="2" marker-end="url(#arr)"/>'
    );
  };

  // 25. taifex-tx-mtx-tmf-ladder
  D['taifex-tx-mtx-tmf-ladder'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">台灣期交所台指期系列 — 資金門檻與乘數階梯</text>' +
      '<rect x="50" y="65" width="200" height="135" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
      '<text x="150" y="95" fill="#dc2626" font-size="15" font-weight="bold" text-anchor="middle">臺股期貨 (大台 TX)</text>' +
      '<text x="150" y="120" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">1 點 = NT$ 200</text>' +
      '<text x="150" y="145" fill="#475569" font-size="11" text-anchor="middle">合約價值約 470 萬元</text>' +
      '<text x="150" y="168" fill="#dc2626" font-size="11" font-weight="bold" text-anchor="middle">原始保證金 70.1 萬</text>' +

      '<rect x="280" y="65" width="200" height="135" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
      '<text x="380" y="95" fill="#b45309" font-size="15" font-weight="bold" text-anchor="middle">小型臺指 (小台 MTX)</text>' +
      '<text x="380" y="120" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">1 點 = NT$ 50</text>' +
      '<text x="380" y="145" fill="#475569" font-size="11" text-anchor="middle">合約規格為大台 1/4</text>' +
      '<text x="380" y="168" fill="#b45309" font-size="11" font-weight="bold" text-anchor="middle">原始保證金 17.5 萬</text>' +

      '<rect x="510" y="65" width="200" height="135" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
      '<text x="610" y="95" fill="#059669" font-size="15" font-weight="bold" text-anchor="middle">微型臺指 (微台 TMF)</text>' +
      '<text x="610" y="120" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">1 點 = NT$ 10</text>' +
      '<text x="610" y="145" fill="#475569" font-size="11" text-anchor="middle">合約規格為大台 1/20</text>' +
      '<text x="610" y="168" fill="#059669" font-size="11" font-weight="bold" text-anchor="middle">原始保證金 3.5 萬</text>'
    );
  };

  // 26. emini-sp500-nasdaq-futures
  D['emini-sp500-nasdaq-futures'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">美股三大主力指數期貨 (CME / CBOT) 規格橫向比對</text>' +
      '<rect x="50" y="65" width="200" height="135" rx="6" fill="#f8fafc" stroke="#0284c7"/>' +
      '<text x="150" y="92" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">E-Mini S&amp;P 500 (ES)</text>' +
      '<text x="150" y="118" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">乘數：$50 × 指數</text>' +
      '<text x="150" y="140" fill="#475569" font-size="11" text-anchor="middle">全球流動性最強大盤期指</text>' +
      '<text x="150" y="160" fill="#64748b" font-size="10" text-anchor="middle">微型版 (MES) 乘數 $5</text>' +

      '<rect x="280" y="65" width="200" height="135" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
      '<text x="380" y="92" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">E-Mini Nasdaq 100 (NQ)</text>' +
      '<text x="380" y="118" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">乘數：$20 × 指數</text>' +
      '<text x="380" y="140" fill="#475569" font-size="11" text-anchor="middle">科技七巨頭高波動代表</text>' +
      '<text x="380" y="160" fill="#64748b" font-size="10" text-anchor="middle">微型版 (MNQ) 乘數 $2</text>' +

      '<rect x="510" y="65" width="200" height="135" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
      '<text x="610" y="92" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">E-Mini 道瓊 (YM)</text>' +
      '<text x="610" y="118" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">乘數：$5 × 指數</text>' +
      '<text x="610" y="140" fill="#475569" font-size="11" text-anchor="middle">30 檔老牌藍籌工業巨頭</text>' +
      '<text x="610" y="160" fill="#64748b" font-size="10" text-anchor="middle">微型版 (MYM) 乘數 $0.5</text>'
    );
  };

  // 27. treasury-yield-curve-futures
  D['treasury-yield-curve-futures'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">美國公債期貨 (CBOT) 梯隊與存續期間 (Duration)</text>' +
      '<g transform="translate(45, 65)">' +
        '<rect x="0" y="0" width="150" height="120" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="75" y="28" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">2年期公債 (ZT)</text>' +
        '<text x="75" y="55" fill="#475569" font-size="11" text-anchor="middle">面額 20 萬美元</text>' +
        '<text x="75" y="75" fill="#0f172a" font-size="11" text-anchor="middle">存續期約 1.9 年</text>' +
        '<text x="75" y="95" fill="#64748b" font-size="10" text-anchor="middle">對聯準會利率最敏感</text>' +
      '</g>' +
      '<g transform="translate(215, 65)">' +
        '<rect x="0" y="0" width="155" height="120" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="77" y="28" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">5年期公債 (ZF)</text>' +
        '<text x="77" y="55" fill="#475569" font-size="11" text-anchor="middle">面額 10 萬美元</text>' +
        '<text x="77" y="75" fill="#0f172a" font-size="11" text-anchor="middle">存續期約 4.3 年</text>' +
        '<text x="77" y="95" fill="#64748b" font-size="10" text-anchor="middle">中天期流動性標竿</text>' +
      '</g>' +
      '<g transform="translate(390, 65)">' +
        '<rect x="0" y="0" width="155" height="120" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
        '<text x="77" y="28" fill="#b45309" font-size="13" font-weight="bold" text-anchor="middle">10年期公債 (ZN)</text>' +
        '<text x="77" y="55" fill="#475569" font-size="11" text-anchor="middle">面額 10 萬美元</text>' +
        '<text x="77" y="75" fill="#b45309" font-size="11" font-weight="bold" text-anchor="middle">存續期約 6.6 年</text>' +
        '<text x="77" y="95" fill="#64748b" font-size="10" text-anchor="middle">全球無風險資產定價錨</text>' +
      '</g>' +
      '<g transform="translate(565, 65)">' +
        '<rect x="0" y="0" width="150" height="120" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="75" y="28" fill="#059669" font-size="13" font-weight="bold" text-anchor="middle">超長期公債 (UB)</text>' +
        '<text x="75" y="55" fill="#475569" font-size="11" text-anchor="middle">面額 10 萬美元</text>' +
        '<text x="75" y="75" fill="#0f172a" font-size="11" text-anchor="middle">存續期約 16 年</text>' +
        '<text x="75" y="95" fill="#dc2626" font-size="10" text-anchor="middle">長線通膨預期溫度計</text>' +
      '</g>'
    );
  };

  // 28. dollar-index-basket-weight
  D['dollar-index-basket-weight'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">美元指數 (DXY) 籃子六大成分貨幣法定權重</text>' +
      '<g transform="translate(50, 70)">' +
        '<rect x="0" y="0" width="105" height="100" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
        '<text x="52" y="32" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">歐元 EUR</text>' +
        '<text x="52" y="60" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">57.6%</text>' +
        '<text x="52" y="85" fill="#64748b" font-size="10" text-anchor="middle">反向連動核心</text>' +
      '</g>' +
      '<g transform="translate(165, 70)">' +
        '<rect x="0" y="0" width="100" height="100" rx="6" fill="#f0f9ff" stroke="#0284c7"/>' +
        '<text x="50" y="32" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">日圓 JPY</text>' +
        '<text x="50" y="60" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">13.6%</text>' +
        '<text x="50" y="85" fill="#64748b" font-size="10" text-anchor="middle">套息交易樞紐</text>' +
      '</g>' +
      '<g transform="translate(275, 70)">' +
        '<rect x="0" y="0" width="100" height="100" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="50" y="32" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">英鎊 GBP</text>' +
        '<text x="50" y="60" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">11.9%</text>' +
        '<text x="50" y="85" fill="#64748b" font-size="10" text-anchor="middle">英國經濟指標</text>' +
      '</g>' +
      '<g transform="translate(385, 70)">' +
        '<rect x="0" y="0" width="100" height="100" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="50" y="32" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">加幣 CAD</text>' +
        '<text x="50" y="60" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">9.1%</text>' +
        '<text x="50" y="85" fill="#64748b" font-size="10" text-anchor="middle">原油商品貨幣</text>' +
      '</g>' +
      '<g transform="translate(495, 70)">' +
        '<rect x="0" y="0" width="100" height="100" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="50" y="32" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">瑞典克朗</text>' +
        '<text x="50" y="60" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">4.2%</text>' +
        '<text x="50" y="85" fill="#64748b" font-size="10" text-anchor="middle">SEK 北歐經濟</text>' +
      '</g>' +
      '<g transform="translate(605, 70)">' +
        '<rect x="0" y="0" width="100" height="100" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="50" y="32" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">瑞士法郎</text>' +
        '<text x="50" y="60" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">3.6%</text>' +
        '<text x="50" y="85" fill="#64748b" font-size="10" text-anchor="middle">CHF 避險貨幣</text>' +
      '</g>' +
      '<text x="380" y="195" fill="#475569" font-size="12" text-anchor="middle">註：歐元佔比超過 57%，故美元指數本質上近六成受歐元兌美元走勢左右！</text>'
    );
  };

  // 29. short-hedge-producer
  D['short-hedge-producer'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">生產者賣出期貨空頭避險 (Short Hedge)：鎖定未來出貨售價</text>' +
      '<line x1="80" y1="125" x2="680" y2="125" stroke="#cbd5e1" stroke-width="2"/>' +
      '<line x1="380" y1="55" x2="380" y2="195" stroke="#cbd5e1" stroke-width="2"/>' +
      '<line x1="160" y1="180" x2="600" y2="70" stroke="#059669" stroke-width="2" stroke-dasharray="4,4"/>' +
      '<text x="610" y="75" fill="#059669" font-size="12">現貨產出部位 (Long Spot)</text>' +
      '<line x1="160" y1="70" x2="600" y2="180" stroke="#dc2626" stroke-width="2" stroke-dasharray="4,4"/>' +
      '<text x="610" y="185" fill="#dc2626" font-size="12">期貨空單避險 (Short Futures)</text>' +
      '<line x1="160" y1="125" x2="600" y2="125" stroke="#f59e0b" stroke-width="4"/>' +
      '<text x="380" y="148" fill="#b45309" font-size="13" font-weight="bold" text-anchor="middle">綜合淨損益平線：原物料價格暴跌，期貨空頭獲利完美彌補現貨折價！</text>'
    );
  };

  // 30. long-hedge-consumer
  D['long-hedge-consumer'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">消費者買入期貨多頭避險 (Long Hedge)：鎖定原料採購成本上限</text>' +
      '<g transform="translate(60, 65)">' +
        '<rect x="0" y="0" width="280" height="110" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
        '<text x="140" y="28" fill="#dc2626" font-size="14" font-weight="bold" text-anchor="middle">未避險採購曝險</text>' +
        '<text x="140" y="55" fill="#475569" font-size="11" text-anchor="middle">原料未來暴漲 ➔ 成本大增吞噬毛利</text>' +
        '<text x="140" y="75" fill="#475569" font-size="11" text-anchor="middle">航空公司面臨航油大漲虧損</text>' +
        '<text x="140" y="95" fill="#b91c1c" font-size="11" text-anchor="middle">飼料廠面臨玉米大漲虧損</text>' +
      '</g>' +
      '<g transform="translate(420, 65)">' +
        '<rect x="0" y="0" width="280" height="110" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
        '<text x="140" y="28" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">買入期貨多單對沖</text>' +
        '<text x="140" y="55" fill="#475569" font-size="11" text-anchor="middle">原料上漲 ➔ 期貨多單獲利</text>' +
        '<text x="140" y="75" fill="#059669" font-size="11" font-weight="bold" text-anchor="middle">將採購成本鎖定在目前合約價格</text>' +
        '<text x="140" y="95" fill="#475569" font-size="11" text-anchor="middle">安心專注本業生產製造</text>' +
      '</g>' +
      '<text x="380" y="195" fill="#475569" font-size="12" text-anchor="middle">避險目的在於「鎖定利潤與預算確定性」，而非追求投機獲利最大化。</text>'
    );
  };

  // 31. cross-hedge-basis-risk
  D['cross-hedge-basis-risk'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">交叉避險 (Cross Hedge) 與基差風險 (Basis Risk) 傳導</text>' +
      '<rect x="60" y="75" width="200" height="90" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
      '<text x="160" y="105" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">標的現貨 (S)</text>' +
      '<text x="160" y="130" fill="#475569" font-size="11" text-anchor="middle">航空燃油 (Jet Fuel)</text>' +
      '<text x="160" y="148" fill="#64748b" font-size="10" text-anchor="middle">無完全匹配之期貨合約</text>' +

      '<line x1="270" y1="120" x2="350" y2="120" stroke="#f59e0b" stroke-width="3" marker-end="url(#arr)"/>' +
      '<text x="310" y="110" fill="#b45309" font-size="11" font-weight="bold" text-anchor="middle">替代避險</text>' +

      '<rect x="360" y="75" width="200" height="90" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
      '<text x="460" y="105" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">期貨工具 (F)</text>' +
      '<text x="460" y="130" fill="#475569" font-size="11" text-anchor="middle">原油期貨 (CL) 或熱燃油 (HO)</text>' +
      '<text x="460" y="148" fill="#059669" font-size="10" text-anchor="middle">計算相關係數與最小方差比</text>' +

      '<rect x="580" y="75" width="130" height="90" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
      '<text x="645" y="105" fill="#dc2626" font-size="13" font-weight="bold" text-anchor="middle">基差風險</text>' +
      '<text x="645" y="130" fill="#475569" font-size="10" text-anchor="middle">相關性非 1.0</text>' +
      '<text x="645" y="148" fill="#b91c1c" font-size="10" text-anchor="middle">兩者價差擴大</text>' +
      '<text x="380" y="195" fill="#475569" font-size="12" text-anchor="middle">最小變異避險比率：h* = ρ × (σ_S ÷ σ_F)，規避價格風險但承受基差波動風險</text>'
    );
  };

  // 32. institutional-cot-positioning
  D['institutional-cot-positioning'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">美國 CFTC 大額交易人持倉報告 (COT) 三大參與者陣營結構</text>' +
      '<g transform="translate(45, 65)">' +
        '<rect x="0" y="0" width="200" height="115" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
        '<text x="100" y="28" fill="#059669" font-size="13" font-weight="bold" text-anchor="middle">商業避險者 (Commercials)</text>' +
        '<text x="100" y="55" fill="#475569" font-size="11" text-anchor="middle">實體礦商、油商、糧商</text>' +
        '<text x="100" y="75" fill="#475569" font-size="11" text-anchor="middle">通常採取逆勢避險</text>' +
        '<text x="100" y="95" fill="#059669" font-size="11" font-weight="bold" text-anchor="middle">聰明錢 (Smart Money) 指標</text>' +
      '</g>' +
      '<g transform="translate(280, 65)">' +
        '<rect x="0" y="0" width="200" height="115" rx="6" fill="#f0f9ff" stroke="#0284c7"/>' +
        '<text x="100" y="28" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">非商業投機者 (Non-Commercial)</text>' +
        '<text x="100" y="55" fill="#475569" font-size="11" text-anchor="middle">CTA、避險基金、大型機構</text>' +
        '<text x="100" y="75" fill="#475569" font-size="11" text-anchor="middle">順勢交易、追求資本利得</text>' +
        '<text x="100" y="95" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">淨多空反映市場中期動能</text>' +
      '</g>' +
      '<g transform="translate(515, 65)">' +
        '<rect x="0" y="0" width="200" height="115" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">非申報部位 (Non-Reportable)</text>' +
        '<text x="100" y="55" fill="#475569" font-size="11" text-anchor="middle">未達申報門檻之散戶</text>' +
        '<text x="100" y="75" fill="#475569" font-size="11" text-anchor="middle">多空部位頻繁切換</text>' +
        '<text x="100" y="95" fill="#dc2626" font-size="11" font-weight="bold" text-anchor="middle">散戶極度樂觀常為反轉訊號</text>' +
      '</g>'
    );
  };

})();