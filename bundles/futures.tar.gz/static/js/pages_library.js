/* 期貨學院資料庫與工具 — 商品圖鑑、歷史風暴、術語字典、綜合測驗中心與意見回饋 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};

  function showModal(titleHtml, bodyHtml) {
    var m = document.createElement('div');
    m.className = 'fut-modal-backdrop';
    m.innerHTML = '<div class="fut-modal-card"><button class="fut-modal-close" type="button" aria-label="關閉">&times;</button><div class="fut-modal-title">' + titleHtml + '</div><div class="fut-modal-body">' + bodyHtml + '</div></div>';
    document.body.appendChild(m);
    m.querySelector('.fut-modal-close').onclick = function () { m.remove(); };
    m.onclick = function (e) { if (e.target === m) m.remove(); };
    return m;
  }

  // 1. 商品全圖鑑（#/commodities）
  FUT.route('commodities', function (el, args) {
    var cat = args[0] || 'all';
    var items = FUT.COMMODITIES || [];
    var filtered = items.filter(function (it) {
      return cat === 'all' || it.cat === cat || it.category === cat;
    });

    var catsHtml = [{ id: 'all', name: '全部 (' + items.length + ')' }]
      .concat((FUT.COMMODITY_CATS || []).map(function (c) {
        var cnt = items.filter(function (it) { return it.cat === c.id || it.category === c.id; }).length;
        return { id: c.id, name: (c.icon || '') + ' ' + c.name + ' (' + cnt + ')' };
      })).map(function (c) {
        return '<button class="fut-cat-pill ' + (c.id === cat ? 'active' : '') + '" data-cat="' + c.id + '">' + c.name + '</button>';
      }).join('');

    var cardsHtml = filtered.length === 0 ? '<div class="fut-empty">商品資料載入中...</div>' : filtered.map(function (c, idx) {
      var p = FUT.prices && FUT.prices.get ? FUT.prices.get(c.priceId || c.code || c.id) : null;
      var pVal = p ? FUT.formatPrice(p.price, c.quoteUnit || p.unit) : '—';
      var chgHtml = '';
      if (p && typeof p.change === 'number') {
        var cls = p.change > 0 ? 'c-up' : (p.change < 0 ? 'c-down' : 'c-flat');
        var sign = p.change > 0 ? '+' : '';
        chgHtml = '<span class="com-live-badge ' + cls + '">' + pVal + ' ' + sign + p.change.toFixed(2) + ' (' + sign + (p.change_pct || 0).toFixed(2) + '%)</span>';
      }
      return '<div class="fut-com-card" data-idx="' + idx + '">' +
        '<div class="com-head"><span class="com-icon">' + (c.icon || '📦') + '</span><div style="flex:1;"><h4>' + FUT.esc(c.name || '') + '</h4><div class="com-sub-row"><span class="com-code">' + FUT.esc(c.code || c.id) + '</span><span class="com-ex">' + FUT.esc(c.exchange || '') + '</span></div></div></div>' +
        (chgHtml ? '<div class="com-price-bar">' + chgHtml + '</div>' : '') +
        '<div class="com-spec-grid"><div><strong>規模：</strong>' + FUT.esc(c.contractSize || '—') + '</div><div><strong>單位：</strong>' + FUT.esc(c.quoteUnit || '—') + '</div><div><strong>跳點：</strong>' + FUT.esc(c.tickSize || '—') + '</div><div><strong>結算：</strong>' + FUT.esc(c.settlement || '—') + '</div></div>' +
        (c.plain ? '<div class="com-plain-box">' + FUT.esc(c.plain) + '</div>' : '') +
        '<button class="fut-btn btn-sm btn-outline com-detail-btn" type="button" data-idx="' + idx + '">完整規格與避險剖析 →</button>' +
      '</div>';
    }).join('');

    el.innerHTML = '<div class="fut-container"><div class="fut-page-header"><h2>📦 原物料與期貨商品全圖鑑</h2><p class="fut-subtext">全球 24 項核心交易品種：合約規格、跳點價值、供需基本面與多空驅動因子。</p></div><div class="fut-cat-bar">' + catsHtml + '</div><div class="fut-com-grid">' + cardsHtml + '</div></div>';

    FUT.$$('.fut-cat-pill', el).forEach(function (btn) {
      btn.onclick = function () { FUT.go('commodities/' + btn.getAttribute('data-cat')); };
    });
    FUT.$$('.com-detail-btn', el).forEach(function (btn) {
      btn.onclick = function (e) {
        e.stopPropagation();
        var c = filtered[Number(btn.getAttribute('data-idx'))];
        if (c) openCommodityModal(c);
      };
    });
  });

  function openCommodityModal(c) {
    var p = FUT.prices && FUT.prices.get ? FUT.prices.get(c.priceId || c.code || c.id) : null;
    var pVal = p ? FUT.formatPrice(p.price, c.quoteUnit || p.unit) : '—';
    var pRow = p ? '<div class="fut-modal-kpi-bar ' + (p.change > 0 ? 'c-up' : 'c-down') + '">最新行情：<strong>' + pVal + '</strong> ' + (p.change > 0 ? '+' : '') + (p.change || 0).toFixed(2) + ' (' + (p.change_pct || 0).toFixed(2) + '%)</div>' : '';
    var bullHtml = (c.bullFactors || []).map(function (b) { return '<li>🟢 ' + FUT.esc(b) + '</li>'; }).join('');
    var bearHtml = (c.bearFactors || []).map(function (b) { return '<li>🔴 ' + FUT.esc(b) + '</li>'; }).join('');
    var relHtml = (c.relatedLessons || []).map(function (lid) {
      var les = (FUT.LESSONS || []).find(function (l) { return l.id === lid; });
      return '<a href="#/lesson/' + lid + '" class="fut-tag-link">' + FUT.esc(les ? (les.icon || '📖') + ' ' + les.title : lid) + '</a>';
    }).join(' ');

    var title = '<div style="display:flex;align-items:center;gap:10px;"><span style="font-size:32px;">' + (c.icon || '📦') + '</span><div><h3 style="margin:0;">' + FUT.esc(c.name || '') + '</h3><span style="font-size:13px;color:var(--text-muted);">' + FUT.esc(c.en || c.code || '') + '・' + FUT.esc(c.exchange || '') + '</span></div></div>';
    var body = pRow +
      '<div class="fut-modal-sec"><h4>📋 標準規格</h4><div class="fut-spec-table"><div><span>代碼</span><strong>' + FUT.esc(c.code || c.id) + '</strong></div><div><span>場所</span><strong>' + FUT.esc(c.exchange || '—') + '</strong></div><div><span>規模</span><strong>' + FUT.esc(c.contractSize || '—') + '</strong></div><div><span>單位</span><strong>' + FUT.esc(c.quoteUnit || '—') + '</strong></div><div><span>跳點</span><strong>' + FUT.esc(c.tickSize || '—') + '</strong></div><div><span>結算</span><strong>' + FUT.esc(c.settlement || '—') + '</strong></div><div><span>時段</span><strong>' + FUT.esc(c.tradingHours || '—') + '</strong></div><div><span>季節</span><strong>' + FUT.esc(c.seasonality || '—') + '</strong></div></div></div>' +
      (c.supplyDemand ? '<div class="fut-modal-sec"><h4>⚖️ 供需基本面</h4><p>' + FUT.esc(c.supplyDemand) + '</p></div>' : '') +
      ((bullHtml || bearHtml) ? ('<div class="fut-modal-sec"><h4>⚡ 多空驅動</h4><div class="fut-grid-2" style="gap:12px;"><div class="fut-card-sub"><strong class="c-up">利多</strong><ul class="fut-factor-list">' + (bullHtml || '<li>無</li>') + '</ul></div><div class="fut-card-sub"><strong class="c-down">利空</strong><ul class="fut-factor-list">' + (bearHtml || '<li>無</li>') + '</ul></div></div></div>') : '') +
      (c.twAccess ? '<div class="fut-modal-sec"><h4>🇹🇼 台灣管道</h4><p>' + FUT.esc(c.twAccess) + '</p></div>' : '') +
      (c.plain ? '<div class="fut-modal-sec fut-plain-box"><strong>🧒 白話：</strong>' + FUT.esc(c.plain) + '</div>' : '') +
      (relHtml ? '<div class="fut-modal-sec"><h4>🔗 關聯課程</h4><div class="fut-tag-links">' + relHtml + '</div></div>' : '');

    var m = showModal(title, body);
    FUT.$$('.fut-tag-link', m).forEach(function (a) { a.onclick = function () { m.remove(); }; });
  }

  // 2. 歷史風暴（#/history）
  FUT.route('history', function (el) {
    var storms = FUT.HISTORY || [];
    var listHtml = storms.length === 0 ? '<div class="fut-empty">歷史風暴教材載入中...</div>' : storms.map(function (s) {
      var storyHtml = Array.isArray(s.story) ? s.story.map(function (p) { return '<p class="story-p">' + FUT.esc(p) + '</p>'; }).join('') : '<p class="story-p">' + FUT.esc(s.story || '') + '</p>';
      var relHtml = (s.relatedLessons || []).map(function (lid) {
        var les = (FUT.LESSONS || []).find(function (l) { return l.id === lid; });
        return '<a href="#/lesson/' + lid + '" class="fut-tag-link">' + FUT.esc(les ? (les.icon || '📖') + ' ' + les.title : lid) + '</a>';
      }).join(' ');

      return '<div class="fut-storm-card"><div class="storm-head-bar"><div class="storm-year-badge">' + FUT.esc(s.year || '') + '</div><span class="storm-cat-badge">' + (s.icon || '🌪️') + ' ' + FUT.esc(s.cat || '') + '</span></div><div class="storm-body"><h3 class="storm-title">' + FUT.esc(s.title || '') + '</h3>' +
        (s.keyStat ? '<div class="storm-keystat">📊 <strong>代價：</strong>' + FUT.esc(s.keyStat) + '</div>' : '') +
        (s.summary ? '<div class="storm-summary">' + FUT.esc(s.summary) + '</div>' : '') +
        '<div class="storm-story-content">' + storyHtml + '</div>' +
        (s.mechanism ? '<div class="storm-mechanism-box"><strong>⚙️ 機制：</strong><p>' + FUT.esc(s.mechanism) + '</p></div>' : '') +
        (s.lesson ? '<div class="storm-lesson-box"><strong>💡 警示：</strong><p>' + FUT.esc(s.lesson) + '</p></div>' : '') +
        (relHtml ? '<div class="storm-rel-row"><span>關聯：</span>' + relHtml + '</div>' : '') +
      '</div></div>';
    }).join('');

    el.innerHTML = '<div class="fut-container"><div class="fut-page-header"><h2>🌪️ 歷史重大期貨風暴與極限考驗</h2><p class="fut-subtext">從 1980 亨特白銀到 2020 負油價與 2022 妖鎳軋空：看懂流動性枯竭、保證金追繳與交割死局。</p></div><div class="fut-storm-list">' + listHtml + '</div></div>';
  });

  // 3. 術語字典（#/glossary）
  FUT.route('glossary', function (el, args) {
    var cat = args[0] || 'all';
    var q = (args[1] || '').trim().toLowerCase();
    var list = FUT.GLOSSARY || [];

    function renderView() {
      var filtered = list.filter(function (it) {
        var matchCat = (cat === 'all' || it.cat === cat || it.category === cat);
        var matchQ = !q || (it.term && it.term.toLowerCase().indexOf(q) >= 0) || (it.en && it.en.toLowerCase().indexOf(q) >= 0) || (it.def && it.def.toLowerCase().indexOf(q) >= 0);
        return matchCat && matchQ;
      });

      var catsHtml = [{ id: 'all', name: '全部 (' + list.length + ')' }]
        .concat((FUT.GLOSS_CATS || []).map(function (c) {
          var cnt = list.filter(function (it) { return it.cat === c.id || it.category === c.id; }).length;
          return { id: c.id, name: c.name + ' (' + cnt + ')' };
        })).map(function (c) {
          return '<button class="fut-cat-pill ' + (c.id === cat ? 'active' : '') + '" data-cat="' + c.id + '">' + c.name + '</button>';
        }).join('');

      var itemsHtml = filtered.length === 0 ? '<div class="fut-empty">查無符合術語</div>' : filtered.map(function (it) {
        return '<div class="fut-gloss-card"><div class="gloss-head"><h4 class="gloss-term">' + FUT.esc(it.term || '') + '</h4>' + (it.en ? '<span class="gloss-en">' + FUT.esc(it.en) + '</span>' : '') + '</div><p class="gloss-def">' + FUT.esc(it.def || '') + '</p>' + (it.example ? '<div class="gloss-example"><strong>實務例：</strong>' + FUT.esc(it.example) + '</div>' : '') + '</div>';
      }).join('');

      el.innerHTML = '<div class="fut-container"><div class="fut-page-header"><h2>📖 原物料與期貨專業術語百科全書</h2><p class="fut-subtext">收錄涵蓋合約制度、保證金、正逆價差、實物交割與風控的核心中英文概念。</p></div><div class="fut-search-row"><input type="text" id="glossSearch" class="fut-input" placeholder="🔍 即時搜尋中英文術語、定義或範例..." value="' + FUT.esc(q) + '" autocomplete="off"/></div><div class="fut-cat-bar">' + catsHtml + '</div><div class="fut-gloss-grid" id="glossGrid">' + itemsHtml + '</div></div>';

      FUT.$$('.fut-cat-pill', el).forEach(function (btn) {
        btn.onclick = function () { cat = btn.getAttribute('data-cat'); renderView(); };
      });

      var inp = document.getElementById('glossSearch');
      if (inp) {
        var isComp = false;
        inp.addEventListener('compositionstart', function () { isComp = true; });
        inp.addEventListener('compositionend', function () { isComp = false; q = inp.value.trim().toLowerCase(); updateGrid(); });
        inp.addEventListener('input', function () { if (!isComp) { q = inp.value.trim().toLowerCase(); updateGrid(); } });
      }
    }

    function updateGrid() {
      var grid = document.getElementById('glossGrid');
      if (!grid) return;
      var filtered = list.filter(function (it) {
        var matchCat = (cat === 'all' || it.cat === cat || it.category === cat);
        var matchQ = !q || (it.term && it.term.toLowerCase().indexOf(q) >= 0) || (it.en && it.en.toLowerCase().indexOf(q) >= 0) || (it.def && it.def.toLowerCase().indexOf(q) >= 0);
        return matchCat && matchQ;
      });
      if (filtered.length === 0) { grid.innerHTML = '<div class="fut-empty">查無符合術語</div>'; return; }
      grid.innerHTML = filtered.map(function (it) {
        return '<div class="fut-gloss-card"><div class="gloss-head"><h4 class="gloss-term">' + FUT.esc(it.term || '') + '</h4>' + (it.en ? '<span class="gloss-en">' + FUT.esc(it.en) + '</span>' : '') + '</div><p class="gloss-def">' + FUT.esc(it.def || '') + '</p>' + (it.example ? '<div class="gloss-example"><strong>實務例：</strong>' + FUT.esc(it.example) + '</div>' : '') + '</div>';
      }).join('');
    }

    renderView();
  });

  // 4. 綜合測驗中心（#/quiz）
  var WRONG_STORAGE_KEY = 'fut.wrong.v1';
  function getWrongs() {
    try { var raw = localStorage.getItem(WRONG_STORAGE_KEY); return raw ? JSON.parse(raw) : []; } catch (e) { return []; }
  }
  function saveWrong(q) {
    try {
      var list = getWrongs();
      if (!list.some(function (it) { return it.q === q.q; })) {
        list.push({ q: q.q, opts: q.opts, ans: q.ans, exp: q.exp, track: q.track, lessonTitle: q.lessonTitle });
        localStorage.setItem(WRONG_STORAGE_KEY, JSON.stringify(list));
      }
    } catch (e) {}
  }
  function removeWrong(qText) {
    try {
      var list = getWrongs().filter(function (it) { return it.q !== qText; });
      localStorage.setItem(WRONG_STORAGE_KEY, JSON.stringify(list));
    } catch (e) {}
  }

  FUT.route('quiz', function (el) {
    var allQ = [];
    (FUT.LESSONS || []).forEach(function (l) {
      if (Array.isArray(l.quiz)) {
        l.quiz.forEach(function (qObj) {
          allQ.push({ track: l.track || 'general', lessonTitle: l.title || '', q: qObj.q, opts: qObj.opts, ans: qObj.ans, exp: qObj.exp });
        });
      }
    });

    var wrongList = getWrongs();
    var st = { title: '', qs: [], idx: 0, ans: {} };

    function renderLobby() {
      var trkCnt = {};
      allQ.forEach(function (q) { trkCnt[q.track] = (trkCnt[q.track] || 0) + 1; });
      var TNAMES = { basics: '合約本質', margin: '保證金結算', spread: '價差曲線', metals: '貴金屬', energy: '能源裂解', agri: '農產氣候', finfut: '指數外匯', hedging: '避險風控' };

      var trkHtml = Object.keys(TNAMES).map(function (trk) {
        return '<div class="fut-quiz-track-card"><div><h4>' + TNAMES[trk] + '</h4><span class="c-muted">' + (trkCnt[trk] || 0) + ' 題</span></div><button class="fut-btn btn-sm btn-outline btn-start-track" data-track="' + trk + '">刷題</button></div>';
      }).join('');

      el.innerHTML = '<div class="fut-container"><div class="fut-page-header"><h2>🎯 期貨實務與避險專業測驗中心</h2><p class="fut-subtext">全館 96 道題庫：支援 15 題隨機模擬考、分章刷題與錯題強化複習。</p></div><div class="fut-grid-2" style="gap:20px;"><div class="fut-card" style="text-align:center;padding:24px 16px;"><span style="font-size:36px;">🏆</span><h3>15 題全真模擬考</h3><p class="c-muted" style="margin:8px 0 16px;">隨機抽 15 題跨章節實戰試題！</p><button class="fut-btn btn-primary" id="btnStartRandom">開始模擬考</button></div><div class="fut-card" style="text-align:center;padding:24px 16px;"><span style="font-size:36px;">📕</span><h3>錯題強化複習</h3><p class="c-muted" style="margin:8px 0 16px;">累積 <strong>' + wrongList.length + '</strong> 題錯題。答對即自錯題本消除！</p><button class="fut-btn btn-outline" id="btnStartWrong" ' + (wrongList.length === 0 ? 'disabled' : '') + '>複習錯題 (' + wrongList.length + ')</button></div></div><div style="margin-top:24px;"><h3>📚 八大專章刷題</h3><div class="fut-quiz-track-grid">' + trkHtml + '</div></div></div>';

      var bR = document.getElementById('btnStartRandom');
      if (bR) bR.onclick = function () {
        var sh = allQ.slice().sort(function () { return 0.5 - Math.random(); });
        startExam(sh.slice(0, 15), '綜合全真模擬考（15 題）');
      };
      var bW = document.getElementById('btnStartWrong');
      if (bW) bW.onclick = function () { if (wrongList.length > 0) startExam(wrongList.slice(), '📕 錯題本專案複習'); };
      FUT.$$('.btn-start-track', el).forEach(function (btn) {
        btn.onclick = function () {
          var trk = btn.getAttribute('data-track');
          startExam(allQ.filter(function (q) { return q.track === trk; }), TNAMES[trk] + ' 專章題庫練習');
        };
      });
    }

    function startExam(questions, title) {
      if (!questions.length) { FUT.toast('題庫載入中...'); return; }
      st.title = title; st.qs = questions; st.idx = 0; st.ans = {};
      renderQ();
    }

    function renderQ() {
      var q = st.qs[st.idx];
      var total = st.qs.length;
      var curNum = st.idx + 1;
      var chosen = st.ans[st.idx];

      var optsHtml = q.opts.map(function (opt, i) {
        var cls = 'quiz-opt-btn';
        if (chosen !== undefined) {
          if (i === q.ans) cls += ' opt-correct';
          else if (i === chosen) cls += ' opt-wrong';
        }
        return '<button type="button" class="' + cls + '" data-idx="' + i + '" ' + (chosen !== undefined ? 'disabled' : '') + '><span class="opt-letter">' + String.fromCharCode(65 + i) + '</span><span class="opt-text">' + FUT.esc(opt) + '</span></button>';
      }).join('');

      var expHtml = chosen !== undefined ? '<div class="quiz-exp-box ' + (chosen === q.ans ? 'exp-correct' : 'exp-wrong') + '"><div class="exp-head">' + (chosen === q.ans ? '🎉 答對了！' : '❌ 答錯了！正確答案是 (' + String.fromCharCode(65 + q.ans) + ')') + '</div><div class="exp-desc">' + FUT.esc(q.exp || '') + '</div></div>' : '';
      var nextBtn = chosen !== undefined ? (curNum < total ? '<button class="fut-btn btn-primary" id="btnNextQ">下一題 →</button>' : '<button class="fut-btn btn-primary" id="btnFinExam">查看成績 🏁</button>') : '';

      el.innerHTML = '<div class="fut-container" style="max-width:760px;"><div class="fut-quiz-head"><div><h3 style="margin:0;">' + FUT.esc(st.title) + '</h3><span class="c-muted">' + FUT.esc(q.lessonTitle || '') + '</span></div><div class="quiz-progress-badge">第 ' + curNum + ' / ' + total + ' 題</div></div><div class="fut-card quiz-card"><div class="quiz-question-title">' + curNum + '. ' + FUT.esc(q.q) + '</div><div class="quiz-opts-list">' + optsHtml + '</div>' + expHtml + '<div class="quiz-foot-bar"><button class="fut-btn btn-sm btn-outline" id="btnQuit">放棄</button>' + nextBtn + '</div></div></div>';

      FUT.$$('.quiz-opt-btn', el).forEach(function (btn) {
        btn.onclick = function () {
          var sel = Number(btn.getAttribute('data-idx'));
          st.ans[st.idx] = sel;
          if (sel === q.ans) removeWrong(q.q); else saveWrong(q);
          renderQ();
        };
      });
      var bn = document.getElementById('btnNextQ'); if (bn) bn.onclick = function () { st.idx++; renderQ(); };
      var bf = document.getElementById('btnFinExam'); if (bf) bf.onclick = function () { renderRes(); };
      var bq = document.getElementById('btnQuit'); if (bq) bq.onclick = function () { renderLobby(); };
    }

    function renderRes() {
      var total = st.qs.length;
      var correct = 0;
      st.qs.forEach(function (q, i) { if (st.ans[i] === q.ans) correct++; });
      var score = Math.round((correct / total) * 100);
      var pass = score >= 70;

      el.innerHTML = '<div class="fut-container" style="max-width:760px;"><div class="fut-card" style="text-align:center;padding:32px 20px;"><span style="font-size:48px;">' + (pass ? '🎖️' : '📚') + '</span><h2>' + (pass ? '測驗合格！恭喜通關' : '尚須加強，繼續加油！') + '</h2><p class="c-muted">' + FUT.esc(st.title) + '</p><div class="result-score-bar"><div class="result-score ' + (pass ? 'c-up' : 'c-warn') + '">' + score + ' <span style="font-size:20px;">分</span></div><div class="result-stat">答對 ' + correct + ' / ' + total + ' 題（正確率 ' + ((correct/total)*100).toFixed(0) + '%）</div></div><div style="display:flex;justify-content:center;gap:12px;margin-top:20px;"><button class="fut-btn btn-primary" id="btnBackLobby">返回首頁</button><button class="fut-btn btn-outline" id="btnRetry">再測一次</button></div></div></div>';

      document.getElementById('btnBackLobby').onclick = function () { renderLobby(); };
      document.getElementById('btnRetry').onclick = function () { startExam(st.qs, st.title); };
    }

    renderLobby();
  });

  // 5. 意見回饋（對齊 CAMP-95, CAMP-96, CAMP-97）
  FUT.route('feedback', function (el) {
    el.innerHTML = '<div class="fut-container" style="max-width:720px;"><div class="fut-page-header"><h2>📬 意見回饋與教材建議</h2><p class="fut-subtext">歡迎向期貨學院提出錯字修訂、數據校正、新商品規格或互動實驗室功能反饋。</p></div><div class="fut-card" style="padding:24px;"><form id="fbForm"><div class="fut-form-row"><label>反饋類型：</label><select id="fbType" class="fut-select"><option value="content">教材內容修訂 / 勘誤</option><option value="prices">行情數據 / 保證金問題</option><option value="lab">互動實驗室功能建議</option><option value="other">其它建言與反饋</option></select></div><div class="fut-form-row"><label>主旨標題：</label><input type="text" id="fbTitle" class="fut-input" placeholder="請簡短摘要您的反饋重點" required/></div><div class="fut-form-row"><label>具體內容描述：</label><textarea id="fbContent" class="fut-input" rows="5" placeholder="請詳細描述您發現的問題、建議修改方式或期望增加之功能..." required></textarea></div><button type="submit" class="fut-btn btn-primary" id="btnSubmitFb" style="width:100%;padding:10px;">送出意見回饋</button></form></div></div>';

    var form = document.getElementById('fbForm');
    if (form) {
      form.onsubmit = function (e) {
        e.preventDefault();
        var type = document.getElementById('fbType').value;
        var title = document.getElementById('fbTitle').value.trim();
        var content = document.getElementById('fbContent').value.trim();
        if (!title || !content) { FUT.toast('請填寫主旨與反饋內容'); return; }

        var payload = { tool: 'futures', toolTitle: '🛢️ 期貨學院', type: type, title: title, content: content, ts: new Date().toISOString() };
        if (!FUT.isStatic()) {
          fetch(FUT.apiBase() + 'feedback', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
            .then(function (res) { return res.json().catch(function () { return {}; }); })
            .then(function () { FUT.toast('感謝您的寶貴回饋！已送交學院教務處'); form.reset(); })
            .catch(function () { FUT.toast('已記錄您的回饋，謝謝！'); form.reset(); });
        } else {
          if (window.CampusNav && typeof window.CampusNav.sendStaticFeedback === 'function') {
            window.CampusNav.sendStaticFeedback({ tool: 'futures', toolTitle: '🛢️ 期貨學院', type: type, title: title, content: content });
          }
          FUT.toast('感謝您的寶貴回饋！已送交學院教務處');
          form.reset();
        }
      };
    }
  });

})();