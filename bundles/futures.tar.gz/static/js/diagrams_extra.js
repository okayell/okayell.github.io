/* 期貨學院原生向量 SVG 圖解引擎（二）— 淺色專業財經主題，第 12 至 22 座圖解 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};
  var D = FUT.diagrams = FUT.diagrams || {};

  // 11. roll-yield-drag
  D['roll-yield-drag'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">正價差市場中的「轉倉蝕本階梯」 (Roll Yield Drag)</text>' +
      '<line x1="60" y1="100" x2="700" y2="100" stroke="#059669" stroke-dasharray="6,4" stroke-width="2"/>' +
      '<text x="650" y="90" fill="#059669" font-size="12">現貨平穩走勢</text>' +
      '<path d="M 60,95 L 180,105 M 180,105 L 180,130 L 320,130 M 320,130 L 320,155 L 460,155 M 460,155 L 460,180 L 600,180" fill="none" stroke="#dc2626" stroke-width="3"/>' +
      '<text x="190" y="125" fill="#dc2626" font-size="11">賣便宜近月・買昂貴遠月 (-3%)</text>' +
      '<text x="330" y="150" fill="#dc2626" font-size="11">再次溢價換約 (-3.5%)</text>' +
      '<text x="470" y="175" fill="#dc2626" font-size="11">持續縮水階梯 (-3%)</text>' +
      '<text x="380" y="210" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">即使現貨價格一年內沒跌，原物料期貨 ETF 也可能因連續轉倉逆風虧損 20% 以上！</text>'
    );
  };

  // 12. basis-convergence-timeline
  D['basis-convergence-timeline'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">基差收斂原理：期貨合約到期日，基差必定強制歸零 (Basis Convergence)</text>' +
      '<line x1="80" y1="125" x2="680" y2="125" stroke="#059669" stroke-width="2"/>' +
      '<text x="80" y="115" fill="#059669" font-size="12" font-weight="bold">現貨基準價格 (Spot)</text>' +
      '<path d="M 80,65 Q 380,85 640,125" fill="none" stroke="#0284c7" stroke-width="3"/>' +
      '<text x="80" y="55" fill="#0284c7" font-size="12" font-weight="bold">期貨價格 (正價差市場)</text>' +
      '<path d="M 80,185 Q 380,165 640,125" fill="none" stroke="#b45309" stroke-width="3"/>' +
      '<text x="80" y="205" fill="#b45309" font-size="12" font-weight="bold">期貨價格 (逆價差市場)</text>' +
      '<line x1="640" y1="35" x2="640" y2="215" stroke="#dc2626" stroke-dasharray="4,4" stroke-width="2"/>' +
      '<text x="640" y="30" fill="#dc2626" font-size="11" font-weight="bold" text-anchor="middle">到期交割日 (Expiry)</text>' +
      '<circle cx="640" cy="125" r="7" fill="#dc2626"/>' +
      '<text x="640" y="148" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">基差 = 0！無套利均衡</text>'
    );
  };

  // 13. gold-real-interest-rate
  D['gold-real-interest-rate'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">黃金 vs 實質利率天平：實質利率 = 名目公債殖利率 - 通膨預期</text>' +
      '<polygon points="380,75 365,170 395,170" fill="#94a3b8"/>' +
      '<line x1="160" y1="105" x2="600" y2="145" stroke="#f59e0b" stroke-width="4"/>' +
      '<line x1="160" y1="105" x2="160" y2="140" stroke="#64748b"/>' +
      '<circle cx="160" cy="155" r="26" fill="url(#gGold)"/>' +
      '<text x="160" y="160" fill="#ffffff" font-size="13" font-weight="bold" text-anchor="middle">黃金</text>' +
      '<text x="160" y="195" fill="#b45309" font-size="12" font-weight="bold" text-anchor="middle">實質利率下行 / 負利率</text>' +
      '<text x="160" y="215" fill="#059669" font-size="11" text-anchor="middle">持金機會成本歸零，金價噴發！</text>' +

      '<line x1="600" y1="145" x2="600" y2="180" stroke="#64748b"/>' +
      '<circle cx="600" cy="192" r="20" fill="url(#gBlue)"/>' +
      '<text x="600" y="197" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">美元定存</text>' +
      '<text x="600" y="222" fill="#64748b" font-size="11" text-anchor="middle">實質利率暴升時天平反轉</text>'
    );
  };

  // 14. gold-silver-ratio-cycle
  D['gold-silver-ratio-cycle'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">金銀比 (Gold/Silver Ratio) 歷史週期區間溫度計：GC ÷ SI</text>' +
      '<g transform="translate(60, 75)">' +
        '<rect x="0" y="0" width="180" height="90" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
        '<text x="90" y="30" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">&lt; 60 工業噴發</text>' +
        '<text x="90" y="55" fill="#475569" font-size="11" text-anchor="middle">全球製造業大幅擴張</text>' +
        '<text x="90" y="75" fill="#059669" font-size="11" text-anchor="middle">白銀工業需求超越黃金</text>' +
      '</g>' +
      '<g transform="translate(270, 75)">' +
        '<rect x="0" y="0" width="200" height="90" rx="6" fill="#f0f9ff" stroke="#0284c7"/>' +
        '<text x="100" y="30" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">60 ~ 80 歷史常態中位</text>' +
        '<text x="100" y="55" fill="#475569" font-size="11" text-anchor="middle">避險與工業需求平衡</text>' +
        '<text x="100" y="75" fill="#64748b" font-size="11" text-anchor="middle">宏觀經濟平穩週期</text>' +
      '</g>' +
      '<g transform="translate(500, 75)">' +
        '<rect x="0" y="0" width="180" height="90" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
        '<text x="90" y="30" fill="#dc2626" font-size="14" font-weight="bold" text-anchor="middle">&gt; 80 避險極值 / 蕭條</text>' +
        '<text x="90" y="55" fill="#475569" font-size="11" text-anchor="middle">市場避險情緒狂熱</text>' +
        '<text x="90" y="75" fill="#dc2626" font-size="11" text-anchor="middle">白銀被極度低估訊號</text>' +
      '</g>' +
      '<text x="380" y="195" fill="#475569" font-size="12" text-anchor="middle">當比值高於 85 時，常為統計套利者「買白銀、賣黃金」收斂策略之黃金窗口</text>'
    );
  };

  // 15. copper-dr-economic-barometer
  D['copper-dr-economic-barometer'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">銅博士 (Dr. Copper) 全球宏觀經濟製造業晴雨表</text>' +
      '<g transform="translate(50, 70)">' +
        '<rect x="0" y="0" width="200" height="110" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">建築與電網骨幹</text>' +
        '<text x="100" y="55" fill="#475569" font-size="11" text-anchor="middle">電力傳輸、住宅配電</text>' +
        '<text x="100" y="75" fill="#475569" font-size="11" text-anchor="middle">基礎設施建設大宗</text>' +
        '<text x="100" y="95" fill="#0284c7" font-size="11" text-anchor="middle">佔全球銅消費約 45%</text>' +
      '</g>' +
      '<g transform="translate(280, 70)">' +
        '<rect x="0" y="0" width="200" height="110" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
        '<text x="100" y="28" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">綠色能源與電動車</text>' +
        '<text x="100" y="55" fill="#475569" font-size="11" text-anchor="middle">EV 用銅量為燃油車 4 倍</text>' +
        '<text x="100" y="75" fill="#475569" font-size="11" text-anchor="middle">風電光伏儲能電纜</text>' +
        '<text x="100" y="95" fill="#059669" font-size="11" text-anchor="middle">未來結構性增長引擎</text>' +
      '</g>' +
      '<g transform="translate(510, 70)">' +
        '<rect x="0" y="0" width="200" height="110" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#0f172a" font-size="14" font-weight="bold" text-anchor="middle">電子與冷暖空調</text>' +
        '<text x="100" y="55" fill="#475569" font-size="11" text-anchor="middle">散熱管、印刷電路板</text>' +
        '<text x="100" y="75" fill="#475569" font-size="11" text-anchor="middle">耐用消費品景氣連動</text>' +
        '<text x="100" y="95" fill="#64748b" font-size="11" text-anchor="middle">對全球 PMI 極度敏感</text>' +
      '</g>'
    );
  };

  // 16. lme-warehouse-warrant-flow
  D['lme-warehouse-warrant-flow'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">LME 倉單流轉與現貨升貼水機制</text>' +
      '<rect x="60" y="75" width="280" height="95" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
      '<text x="200" y="102" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">未註銷倉單 (Live Warrants)</text>' +
      '<text x="200" y="125" fill="#475569" font-size="11" text-anchor="middle">存放在 LME 全球核可倉庫</text>' +
      '<text x="200" y="145" fill="#64748b" font-size="11" text-anchor="middle">可在期貨市場自由撮合交割</text>' +

      '<rect x="420" y="75" width="280" height="95" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
      '<text x="560" y="102" fill="#dc2626" font-size="14" font-weight="bold" text-anchor="middle">已註銷倉單 (Cancelled Warrants)</text>' +
      '<text x="560" y="125" fill="#475569" font-size="11" text-anchor="middle">買方已申請提貨、準備運離</text>' +
      '<text x="560" y="145" fill="#dc2626" font-size="11" text-anchor="middle">不可再交割，暗示實體需求極旺！</text>' +

      '<text x="380" y="195" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">註銷倉單佔比急升 ➔ 現貨供應緊俏 ➔ 出現現貨升水 (Backwardation)</text>'
    );
  };

  // 17. wti-vs-brent-arbitrage
  D['wti-vs-brent-arbitrage'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">WTI vs Brent 原油套利地圖：品質、管線陸鎖與海運套利</text>' +
      '<g transform="translate(60, 70)">' +
        '<rect x="0" y="0" width="280" height="100" rx="6" fill="#f8fafc" stroke="#0284c7"/>' +
        '<text x="140" y="28" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">西德州輕原油 (WTI)</text>' +
        '<text x="140" y="52" fill="#475569" font-size="11" text-anchor="middle">交割地：奧克拉荷馬 Cushing 陸鎖樞紐</text>' +
        '<text x="140" y="72" fill="#475569" font-size="11" text-anchor="middle">API 39.6°、硫含量 0.24% (超輕超甜)</text>' +
        '<text x="140" y="92" fill="#64748b" font-size="11" text-anchor="middle">受制於美國內陸管線瓶頸</text>' +
      '</g>' +
      '<g transform="translate(420, 70)">' +
        '<rect x="0" y="0" width="280" height="100" rx="6" fill="#f8fafc" stroke="#b45309"/>' +
        '<text x="140" y="28" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">布蘭特原油 (Brent)</text>' +
        '<text x="140" y="52" fill="#475569" font-size="11" text-anchor="middle">交割地：北海四油田、海運油輪直裝</text>' +
        '<text x="140" y="72" fill="#475569" font-size="11" text-anchor="middle">API 38.06°、硫含量 0.37% (海運基準)</text>' +
        '<text x="140" y="92" fill="#059669" font-size="11" text-anchor="middle">全球 2/3 實體原油貿易定價基準</text>' +
      '</g>' +
      '<text x="380" y="195" fill="#475569" font-size="12" text-anchor="middle">正常情況下 Brent 較 WTI 溢價 3~5 美元，價差擴大時美油經海運出口套利！</text>'
    );
  };

  // 18. refinery-321-crack-spread
  D['refinery-321-crack-spread'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">煉油廠經典 3:2:1 裂解價差模型 (Crack Spread)</text>' +
      '<rect x="60" y="75" width="160" height="95" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
      '<text x="140" y="105" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">投入：3 桶原油</text>' +
      '<text x="140" y="130" fill="#475569" font-size="12" text-anchor="middle">3 × WTI 原油期貨</text>' +
      '<text x="140" y="150" fill="#64748b" font-size="11" text-anchor="middle">煉油原料成本</text>' +

      '<line x1="230" y1="122" x2="310" y2="122" stroke="#f59e0b" stroke-width="4" marker-end="url(#arr)"/>' +
      '<text x="270" y="112" fill="#b45309" font-size="11" font-weight="bold" text-anchor="middle">提煉裂解</text>' +

      '<rect x="330" y="75" width="370" height="95" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
      '<text x="515" y="105" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">產出：2 桶汽油 (RB) + 1 桶超低硫柴油 (HO)</text>' +
      '<text x="515" y="130" fill="#0f172a" font-size="12" text-anchor="middle">裂解毛利 = [ (2 × 汽油桶價) + (1 × 柴油桶價) - (3 × 原油桶價) ] ÷ 3</text>' +
      '<text x="515" y="150" fill="#475569" font-size="11" text-anchor="middle">煉廠利用「買進原油・賣出成品油」鎖定加工利潤</text>'
    );
  };

  // 19. natgas-injection-withdrawal
  D['natgas-injection-withdrawal'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">天然氣季節性注氣與提領循環 (Injection &amp; Withdrawal Cycle)</text>' +
      '<rect x="60" y="70" width="280" height="100" rx="6" fill="#f0f9ff" stroke="#0284c7"/>' +
      '<text x="200" y="98" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">夏季注氣季 (4月 ~ 10月)</text>' +
      '<text x="200" y="122" fill="#475569" font-size="11" text-anchor="middle">產量 &gt; 需求，多餘氣量注入地下枯竭鹽穴</text>' +
      '<text x="200" y="142" fill="#475569" font-size="11" text-anchor="middle">夏季冷氣發電高溫用電高峰</text>' +
      '<text x="200" y="160" fill="#64748b" font-size="10" text-anchor="middle">庫存穩步攀升至 3.8 兆立方英尺</text>' +

      '<rect x="420" y="70" width="280" height="100" rx="6" fill="#fffbeb" stroke="#b45309"/>' +
      '<text x="560" y="98" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">冬季提領季 (11月 ~ 3月)</text>' +
      '<text x="560" y="122" fill="#475569" font-size="11" text-anchor="middle">北美暴風雪與極地渦旋家庭供暖急增</text>' +
      '<text x="560" y="142" fill="#dc2626" font-size="11" text-anchor="middle">每週大量從地下儲氣庫抽取 (Withdrawal)</text>' +
      '<text x="560" y="160" fill="#64748b" font-size="10" text-anchor="middle">價格對短期極端寒流極度敏感飆升</text>' +
      '<text x="380" y="195" fill="#475569" font-size="12" text-anchor="middle">每週四 EIA 庫存報告為期貨市場關鍵多空裁判！</text>'
    );
  };

  // 20. negative-oil-super-contango
  D['negative-oil-super-contango'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#dc2626" font-size="16" font-weight="bold" text-anchor="middle">2020年4月20日 WTI -37.63 美元負油價 Super Contango 死局</text>' +
      '<g transform="translate(50, 65)">' +
        '<rect x="0" y="0" width="200" height="110" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">儲油槽空間枯竭</text>' +
        '<text x="100" y="52" fill="#475569" font-size="11" text-anchor="middle">Cushing 樞紐全滿</text>' +
        '<text x="100" y="72" fill="#475569" font-size="11" text-anchor="middle">全球封城飛機停飛</text>' +
        '<text x="100" y="92" fill="#dc2626" font-size="11" text-anchor="middle">租金高於原油自身價值</text>' +
      '</g>' +
      '<g transform="translate(280, 65)">' +
        '<rect x="0" y="0" width="200" height="110" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
        '<text x="100" y="28" fill="#b45309" font-size="13" font-weight="bold" text-anchor="middle">散戶無法實物交割</text>' +
        '<text x="100" y="52" fill="#475569" font-size="11" text-anchor="middle">未平倉多頭須提貨</text>' +
        '<text x="100" y="72" fill="#475569" font-size="11" text-anchor="middle">散戶無管線也無油槽</text>' +
        '<text x="100" y="92" fill="#dc2626" font-size="11" text-anchor="middle">實物違約代價極度沈重</text>' +
      '</g>' +
      '<g transform="translate(510, 65)">' +
        '<rect x="0" y="0" width="200" height="110" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
        '<text x="100" y="28" fill="#dc2626" font-size="13" font-weight="bold" text-anchor="middle">踩踏踩平倉出清</text>' +
        '<text x="100" y="52" fill="#475569" font-size="11" text-anchor="middle">買盤完全消失</text>' +
        '<text x="100" y="72" fill="#dc2626" font-size="11" text-anchor="middle">賣方倒貼 $37.63 平倉</text>' +
        '<text x="100" y="92" fill="#b91c1c" font-size="11" text-anchor="middle">「求你把油運走」奇觀</text>' +
      '</g>' +
      '<text x="380" y="200" fill="#dc2626" font-size="11" font-weight="bold" text-anchor="middle">教訓：實物交割原物料期貨，非商業機構切勿持倉至第一通知日 (FND)！</text>'
    );
  };

  // 21. grains-crop-calendar
  D['grains-crop-calendar'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">北美大宗糧食作物生長週期曆 (Crop Calendar)</text>' +
      '<g transform="translate(50, 70)">' +
        '<rect x="0" y="0" width="150" height="100" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="75" y="28" fill="#059669" font-size="13" font-weight="bold" text-anchor="middle">4 ~ 5 月：春播期</text>' +
        '<text x="75" y="55" fill="#475569" font-size="11" text-anchor="middle">農民爭地效應</text>' +
        '<text x="75" y="75" fill="#475569" font-size="11" text-anchor="middle">玉米與黃豆比價</text>' +
        '<text x="75" y="92" fill="#64748b" font-size="10" text-anchor="middle">關注過多降雨延誤</text>' +
      '</g>' +
      '<g transform="translate(215, 70)">' +
        '<rect x="0" y="0" width="155" height="100" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
        '<text x="77" y="28" fill="#dc2626" font-size="13" font-weight="bold" text-anchor="middle">6 ~ 7 月：關鍵授粉期</text>' +
        '<text x="77" y="55" fill="#475569" font-size="11" text-anchor="middle">氣候市 (Weather Mkt)</text>' +
        '<text x="77" y="75" fill="#dc2626" font-size="11" font-weight="bold" text-anchor="middle">乾旱熱浪摧毀單產</text>' +
        '<text x="77" y="92" fill="#64748b" font-size="10" text-anchor="middle">波動度全年度最高</text>' +
      '</g>' +
      '<g transform="translate(385, 70)">' +
        '<rect x="0" y="0" width="155" height="100" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
        '<text x="77" y="28" fill="#059669" font-size="13" font-weight="bold" text-anchor="middle">8 ~ 9 月：結莢灌漿</text>' +
        '<text x="77" y="55" fill="#475569" font-size="11" text-anchor="middle">黃豆需 8 月降雨</text>' +
        '<text x="77" y="75" fill="#475569" font-size="11" text-anchor="middle">單產基本定案</text>' +
        '<text x="77" y="92" fill="#64748b" font-size="10" text-anchor="middle">USDA 報告密集修正</text>' +
      '</g>' +
      '<g transform="translate(555, 70)">' +
        '<rect x="0" y="0" width="150" height="100" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
        '<text x="75" y="28" fill="#b45309" font-size="13" font-weight="bold" text-anchor="middle">10 ~ 11 月：收割期</text>' +
        '<text x="75" y="55" fill="#475569" font-size="11" text-anchor="middle">收割賣壓 (Harvest)</text>' +
        '<text x="75" y="75" fill="#475569" font-size="11" text-anchor="middle">現貨供應瞬間湧入</text>' +
        '<text x="75" y="92" fill="#64748b" font-size="10" text-anchor="middle">期貨價格常季節低點</text>' +
      '</g>'
    );
  };

  // 22. soybean-crush-spread-chain
  D['soybean-crush-spread-chain'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">黃豆壓榨產業鏈 (Soybean Crush Spread Chain)</text>' +
      '<rect x="60" y="75" width="180" height="95" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
      '<text x="150" y="105" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">1 蒲式耳原豆 (ZS)</text>' +
      '<text x="150" y="128" fill="#475569" font-size="11" text-anchor="middle">投入成本 (約 60 磅)</text>' +
      '<text x="150" y="148" fill="#64748b" font-size="10" text-anchor="middle">壓榨廠大宗原料</text>' +

      '<line x1="250" y1="122" x2="310" y2="122" stroke="#f59e0b" stroke-width="3" marker-end="url(#arr)"/>' +

      '<rect x="325" y="65" width="185" height="55" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
      '<text x="417" y="90" fill="#059669" font-size="12" font-weight="bold" text-anchor="middle">80% 豆粉 (ZM) 飼料</text>' +
      '<text x="417" y="108" fill="#475569" font-size="10" text-anchor="middle">約 48 磅，禽畜養殖蛋白質</text>' +

      '<rect x="325" y="130" width="185" height="55" rx="6" fill="#f0f9ff" stroke="#0284c7"/>' +
      '<text x="417" y="155" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">18% 豆油 (ZL) 食用油</text>' +
      '<text x="417" y="173" fill="#475569" font-size="10" text-anchor="middle">約 11 磅，食用油及生質柴油</text>' +

      '<rect x="530" y="75" width="170" height="95" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
      '<text x="615" y="105" fill="#b45309" font-size="13" font-weight="bold" text-anchor="middle">壓榨毛利計算</text>' +
      '<text x="615" y="128" fill="#0f172a" font-size="11" text-anchor="middle">(豆粉值 + 豆油值)</text>' +
      '<text x="615" y="145" fill="#dc2626" font-size="11" text-anchor="middle">- 黃豆進貨成本</text>'
    );
  };

})();