/* 期貨學院核心 — 命名空間 FUT、共用工具、路由、localStorage 封裝與進度回報 */
(function () {
  'use strict';
  var FUT = (window.FUT = window.FUT || {});
  FUT.LESSONS = window.FUT_LESSONS = window.FUT_LESSONS || [];
  FUT.COMMODITIES = window.FUT_COMMODITIES = window.FUT_COMMODITIES || [];
  FUT.HISTORY = window.FUT_HISTORY = window.FUT_HISTORY || [];
  FUT.GLOSSARY = window.FUT_GLOSSARY = window.FUT_GLOSSARY || [];

  // 八大專章定義
  FUT.TRACKS = [
    { id: 'basics', icon: '📜', name: '期貨起源與本質', desc: '大阪堂島到現代期貨：標準化合約、交割與市場參與者。' },
    { id: 'margin', icon: '🧮', name: '保證金與槓桿風控', desc: '原始／維持保證金、逐日結算、追繳與 25% 強制平倉斷頭。' },
    { id: 'spread', icon: '📐', name: '基差與正逆價差', desc: 'Contango vs Backwardation、持有成本模型與轉倉損益。' },
    { id: 'metals', icon: '🥇', name: '貴金屬與工業金屬', desc: '黃金白銀避險機制、實質利率、LME 銅鋁鎳現貨期貨。' },
    { id: 'energy', icon: '🛢️', name: '原油與能源鏈', desc: 'WTI、Brent、天然氣供需、裂解價差與負油價歷史成因。' },
    { id: 'agri', icon: '🌾', name: '農產品與軟性商品', desc: '黃豆玉米小麥壓榨鏈、氣候季節性與咖啡可可期貨。' },
    { id: 'finfut', icon: '📈', name: '金融期貨與外期', desc: '台灣大台、小台、微台乘數階梯、美股三大大盤期指。' },
    { id: 'hedging', icon: '🛡️', name: '避險對沖與策略', desc: '現貨＋期貨對沖實務、空頭避險、多頭鎖價與法人籌碼。' }
  ];

  // 商品五大分類
  FUT.COMMODITY_CATS = [
    { id: 'metals_precious', name: '貴金屬', icon: '🥇' },
    { id: 'metals_base', name: '工業金屬', icon: '🧱' },
    { id: 'energy', name: '能源原油', icon: '🛢️' },
    { id: 'agri', name: '農產品與軟性', icon: '🌾' },
    { id: 'finfut', name: '指數與金融期', icon: '📈' }
  ];

  // 術語六大類別
  FUT.GLOSS_CATS = [
    { id: 'basics', name: '合約與制度' },
    { id: 'margin', name: '保證金與結算' },
    { id: 'spread', name: '價差與基差' },
    { id: 'commodity', name: '商品與現貨' },
    { id: 'trading', name: '交易與交割' },
    { id: 'risk', name: '避險與風控' }
  ];

  // DOM 選擇輔助
  FUT.$ = function (sel, root) { return (root || document).querySelector(sel); };
  FUT.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  FUT.esc = function (s) {
    if (s == null) return '';
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  };

  // localStorage 封裝（前綴 fut.）
  FUT.store = {
    get: function (key, dflt) {
      try {
        var v = window.localStorage.getItem('fut.' + key);
        return v == null ? dflt : JSON.parse(v);
      } catch (e) {
        return dflt;
      }
    },
    set: function (key, val) {
      try {
        window.localStorage.setItem('fut.' + key, JSON.stringify(val));
      } catch (e) { /* 私密模式忽略 */ }
    }
  };

  // 靜態環境偵測與 API Base
  FUT.isStatic = function () {
    if (window.FUT_STATIC_ONLY || window.CAMPUS_STATIC_ONLY) return true;
    var loc = window.location || {};
    if (String(loc.protocol || '').indexOf('http') !== 0) return true;
    return /\.github\.io$/i.test(String(loc.hostname || ''));
  };

  FUT.apiBase = function () {
    var ms = document.querySelector && document.querySelector('script[data-campus-mount]');
    if (ms) {
      var mnt = ms.getAttribute('data-campus-mount');
      if (mnt) return '/' + mnt + '/api/';
    }
    return 'api/';
  };

  // 漲跌色彩模式管理：預設 tw（紅漲綠跌），可切換 us（綠漲紅跌）
  FUT.colorScheme = {
    get: function () {
      return FUT.store.get('colorScheme', 'tw');
    },
    set: function (mode) {
      var m = (mode === 'us') ? 'us' : 'tw';
      FUT.store.set('colorScheme', m);
      if (m === 'us') {
        document.body.classList.add('theme-us');
      } else {
        document.body.classList.remove('theme-us');
      }
      var btn = document.getElementById('colorSchemeBtn');
      if (btn) {
        btn.textContent = (m === 'us') ? '🟢 綠漲紅跌' : '🔴 紅漲綠跌';
      }
      FUT.rerender();
    },
    init: function () {
      var cur = this.get();
      if (cur === 'us') {
        document.body.classList.add('theme-us');
      } else {
        document.body.classList.remove('theme-us');
      }
      var btn = document.getElementById('colorSchemeBtn');
      if (btn) {
        btn.textContent = (cur === 'us') ? '🟢 綠漲紅跌' : '🔴 紅漲綠跌';
        btn.onclick = function () {
          var next = (FUT.colorScheme.get() === 'tw') ? 'us' : 'tw';
          FUT.colorScheme.set(next);
        };
      }
    }
  };

  // 數字與漲跌幅格式化
  FUT.fmtNum = function (v, dp) {
    if (v == null || isNaN(v)) return '—';
    var n = Number(v);
    var d = (dp !== undefined) ? dp : (Math.abs(n) >= 1000 ? 0 : Math.abs(n) >= 1 ? 2 : 4);
    return n.toLocaleString('zh-TW', { minimumFractionDigits: d, maximumFractionDigits: d });
  };

  FUT.fmtPct = function (v) {
    if (v == null || isNaN(v)) return '—';
    var n = Number(v);
    return (n > 0 ? '+' : '') + n.toFixed(2) + '%';
  };

  FUT.pctClass = function (v) {
    if (v == null || isNaN(v)) return 'c-flat';
    var n = Number(v);
    return n > 0 ? 'c-up' : (n < 0 ? 'c-down' : 'c-flat');
  };

  FUT.pctBadge = function (v) {
    if (v == null || isNaN(v)) return '<span class="badge-flat">—</span>';
    var n = Number(v);
    var cls = n > 0 ? 'badge-up' : (n < 0 ? 'badge-down' : 'badge-flat');
    return '<span class="' + cls + '">' + FUT.fmtPct(n) + '</span>';
  };

  FUT.fmtMoney = function (v, cur) {
    if (v == null || isNaN(v)) return '—';
    return (cur === 'USD' ? '$' : 'NT$') + Number(v).toLocaleString('zh-TW');
  };

  FUT.formatPrice = function (v, unit) {
    if (v == null || isNaN(v)) return '—';
    var n = Number(v);
    var dp = Math.abs(n) >= 1000 ? 1 : (Math.abs(n) >= 10 ? 2 : 4);
    var formatted = n.toLocaleString('zh-TW', { minimumFractionDigits: dp, maximumFractionDigits: dp });
    return unit ? (formatted + ' ' + unit) : formatted;
  };

  // 學習進度管理
  FUT.progress = {
    data: function () {
      return FUT.store.get('progress.v1', { done: {}, quiz: {} });
    },
    isDone: function (id) {
      return !!this.data().done[id];
    },
    setDone: function (id, on) {
      var d = this.data();
      if (on) d.done[id] = Date.now(); else delete d.done[id];
      FUT.store.set('progress.v1', d);
      FUT.syncNavCounts();
      FUT.reportProgress();
    },
    setQuiz: function (id, score) {
      var d = this.data();
      d.quiz[id] = Math.max(score, d.quiz[id] || 0);
      FUT.store.set('progress.v1', d);
      FUT.reportProgress();
    },
    quizOf: function (id) {
      return this.data().quiz[id];
    },
    countDone: function (track) {
      var d = this.data().done;
      return FUT.LESSONS.filter(function (l) {
        return (!track || l.track === track) && d[l.id];
      }).length;
    }
  };

  FUT.syncNavCounts = function () {
    var el = document.getElementById('navLearnCnt');
    if (el) {
      el.textContent = FUT.progress.countDone() + '/' + (FUT.LESSONS.length || 32);
    }
  };

  // 對接校園地圖進度回報
  FUT.reportProgress = function () {
    try {
      var done = FUT.progress.countDone();
      var total = FUT.LESSONS.length || 32;
      FUT.store.set('summary.v1', { lessonsDone: done, lessonsTotal: total, ts: Date.now() });
      if (window.CampusNav && typeof window.CampusNav.reportProgress === 'function') {
        window.CampusNav.reportProgress('futures', { done: done, total: total });
      }
    } catch (e) { /* ignore */ }
  };

  // 自選商品清單
  FUT.watch = {
    list: function () {
      return FUT.store.get('watch.v1', ['GC', 'CL', 'TX', 'ES']);
    },
    has: function (id) {
      return this.list().indexOf(id) >= 0;
    },
    toggle: function (id) {
      var l = this.list(), i = l.indexOf(id);
      if (i >= 0) l.splice(i, 1); else l.push(id);
      FUT.store.set('watch.v1', l);
      return i < 0;
    }
  };

  // IME-Safe Enter 鍵檢查
  FUT.isEnterSend = function (e) {
    return e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229;
  };

  // 吐司訊息
  FUT.toast = function (msg, dur) {
    var old = document.querySelector('.fut-toast');
    if (old) old.remove();
    var el = document.createElement('div');
    el.className = 'fut-toast';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(function () { el.remove(); }, dur || 2400);
  };

  // Hash 路由系統
  FUT.routes = {};
  FUT.route = function (name, fn) { FUT.routes[name] = fn; };
  FUT.parseHash = function () {
    var h = String(window.location.hash || '').replace(/^#\/?/, '');
    var qIdx = h.indexOf('?');
    var query = {};
    if (qIdx >= 0) {
      var qs = h.slice(qIdx + 1);
      h = h.slice(0, qIdx);
      qs.split('&').forEach(function (pair) {
        var parts = pair.split('=');
        if (parts[0]) query[decodeURIComponent(parts[0])] = decodeURIComponent(parts[1] || '');
      });
    }
    var parts = h.split('/').filter(Boolean).map(function (p) {
      try { return decodeURIComponent(p); } catch (e) { return p; }
    });
    return { name: parts[0] || 'home', args: parts.slice(1), query: query };
  };

  FUT.go = function (hash) {
    window.location.hash = hash.charAt(0) === '#' ? hash : '#/' + hash.replace(/^\//, '');
  };

  FUT.rerender = function () {
    var r = FUT.parseHash();
    var fn = FUT.routes[r.name] || FUT.routes['home'];
    var main = document.getElementById('app');
    if (!main) return;
    // 更新導覽列高亮
    FUT.$$('.fut-nav-link').forEach(function (a) {
      var rt = a.getAttribute('data-route');
      a.classList.toggle('active', rt === r.name || (r.name === 'lesson' && rt === 'learn'));
    });
    window.scrollTo({ top: 0, behavior: 'instant' });
    if (typeof fn === 'function') {
      fn(main, r.args, r.query);
    }
  };

})();
