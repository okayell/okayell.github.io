/* 期貨學院原生向量 SVG 圖解引擎（一）— 淺色專業財經主題，第 1 至 11 座圖解 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};
  var D = FUT.diagrams = FUT.diagrams || {};

  FUT.wrapSvg = function (w, h, content) {
    return '<svg viewBox="0 0 ' + w + ' ' + h + '" class="fut-svg" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">' +
      '<defs>' +
      '<linearGradient id="gGold" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#fbbf24"/><stop offset="100%" stop-color="#d97706"/></linearGradient>' +
      '<linearGradient id="gGreen" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#34d399"/><stop offset="100%" stop-color="#059669"/></linearGradient>' +
      '<linearGradient id="gRed" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#f87171"/><stop offset="100%" stop-color="#dc2626"/></linearGradient>' +
      '<linearGradient id="gBlue" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#60a5fa"/><stop offset="100%" stop-color="#2563eb"/></linearGradient>' +
      '<marker id="arr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#64748b"/></marker>' +
      '<marker id="arrG" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#059669"/></marker>' +
      '<marker id="arrR" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#dc2626"/></marker>' +
      '</defs>' +
      content +
      '</svg>';
  };

  // 1. spot-vs-forward-futures
  D['spot-vs-forward-futures'] = function () {
    return FUT.wrapSvg(760, 250,
      '<rect x="20" y="20" width="220" height="210" rx="8" fill="#f8fafc" stroke="#cbd5e1"/>' +
      '<rect x="270" y="20" width="220" height="210" rx="8" fill="#f8fafc" stroke="#cbd5e1"/>' +
      '<rect x="520" y="20" width="220" height="210" rx="8" fill="#fffbeb" stroke="#f59e0b" stroke-width="2"/>' +
      '<text x="130" y="55" fill="#0284c7" font-size="15" font-weight="bold" text-anchor="middle">1. 現貨交易 (Spot)</text>' +
      '<text x="130" y="85" fill="#64748b" font-size="12" text-anchor="middle">一手交錢・一手交貨</text>' +
      '<text x="130" y="120" fill="#0f172a" font-size="13" text-anchor="middle">買賣當面即時履約</text>' +
      '<text x="130" y="150" fill="#64748b" font-size="12" text-anchor="middle">資金壓力大・無槓桿</text>' +
      '<text x="130" y="185" fill="#059669" font-size="12" font-weight="bold" text-anchor="middle">實體物資立即移轉</text>' +

      '<text x="380" y="55" fill="#0284c7" font-size="15" font-weight="bold" text-anchor="middle">2. 遠期契約 (Forward)</text>' +
      '<text x="380" y="85" fill="#64748b" font-size="12" text-anchor="middle">約定未來特定日期交割</text>' +
      '<text x="380" y="120" fill="#0f172a" font-size="13" text-anchor="middle">場外私下雙邊協議 (OTC)</text>' +
      '<text x="380" y="150" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">高違約信用風險 (Default)</text>' +
      '<text x="380" y="185" fill="#64748b" font-size="12" text-anchor="middle">條款客製・難以流通轉手</text>' +

      '<text x="630" y="55" fill="#b45309" font-size="15" font-weight="bold" text-anchor="middle">3. 現代期貨 (Futures)</text>' +
      '<text x="630" y="85" fill="#b45309" font-size="12" text-anchor="middle">交易所集中撮合市場</text>' +
      '<text x="630" y="120" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">規格完全標準化</text>' +
      '<text x="630" y="150" fill="#059669" font-size="12" font-weight="bold" text-anchor="middle">結算所 (CCP) 擔任對手方</text>' +
      '<text x="630" y="180" fill="#b45309" font-size="12" text-anchor="middle">逐日盯市保證金・極低違約</text>' +
      '<text x="630" y="205" fill="#0284c7" font-size="12" text-anchor="middle">高流動性・隨時反向平倉</text>'
    );
  };

  // 2. futures-contract-anatomy
  D['futures-contract-anatomy'] = function () {
    return FUT.wrapSvg(760, 270,
      '<rect x="20" y="15" width="720" height="240" rx="10" fill="#ffffff" stroke="#f59e0b" stroke-width="2"/>' +
      '<text x="380" y="45" fill="#b45309" font-size="16" font-weight="bold" text-anchor="middle">標準化期貨合約六大解剖核心要素</text>' +
      '<g transform="translate(45, 65)">' +
        '<rect x="0" y="0" width="200" height="75" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">① 標的資產 (Underlying)</text>' +
        '<text x="100" y="52" fill="#64748b" font-size="11" text-anchor="middle">台指、黃金品質、輕原油API度</text>' +
      '</g>' +
      '<g transform="translate(280, 65)">' +
        '<rect x="0" y="0" width="200" height="75" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">② 合約乘數 (Multiplier)</text>' +
        '<text x="100" y="52" fill="#64748b" font-size="11" text-anchor="middle">大台200元/點、黃金100盎司/口</text>' +
      '</g>' +
      '<g transform="translate(515, 65)">' +
        '<rect x="0" y="0" width="200" height="75" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">③ 最小跳動點 (Tick Size)</text>' +
        '<text x="100" y="52" fill="#64748b" font-size="11" text-anchor="middle">大台1點=200元、微台1點=10元</text>' +
      '</g>' +
      '<g transform="translate(45, 155)">' +
        '<rect x="0" y="0" width="200" height="75" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#059669" font-size="13" font-weight="bold" text-anchor="middle">④ 到期月份與交割日</text>' +
        '<text x="100" y="52" fill="#64748b" font-size="11" text-anchor="middle">如台指每個月第3個星期三</text>' +
      '</g>' +
      '<g transform="translate(280, 155)">' +
        '<rect x="0" y="0" width="200" height="75" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#059669" font-size="13" font-weight="bold" text-anchor="middle">⑤ 結算交割方式</text>' +
        '<text x="100" y="52" fill="#64748b" font-size="11" text-anchor="middle">現金差額沖銷 vs 實物倉庫標準倉單</text>' +
      '</g>' +
      '<g transform="translate(515, 155)">' +
        '<rect x="0" y="0" width="200" height="75" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="100" y="28" fill="#dc2626" font-size="13" font-weight="bold" text-anchor="middle">⑥ 每日結算價與保證金</text>' +
        '<text x="100" y="52" fill="#64748b" font-size="11" text-anchor="middle">逐日盯市 (Mark to Market) 結算</text>' +
      '</g>'
    );
  };

  // 3. clearinghouse-novate
  D['clearinghouse-novate'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="42" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">結算所契約更替 (Novation)：成為每位買方的賣方、每位賣方的買方</text>' +
      '<rect x="60" y="80" width="160" height="90" rx="8" fill="#ecfdf5" stroke="#059669"/>' +
      '<text x="140" y="115" fill="#059669" font-size="15" font-weight="bold" text-anchor="middle">買方投資人 (Buyer)</text>' +
      '<text x="140" y="145" fill="#475569" font-size="12" text-anchor="middle">建立期貨多頭部位</text>' +

      '<rect x="290" y="65" width="180" height="120" rx="8" fill="#fffbeb" stroke="#f59e0b" stroke-width="2"/>' +
      '<text x="380" y="95" fill="#b45309" font-size="16" font-weight="bold" text-anchor="middle">期貨結算所 (CCP)</text>' +
      '<text x="380" y="125" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">契約更替 (Novation)</text>' +
      '<text x="380" y="150" fill="#64748b" font-size="11" text-anchor="middle">承擔集中履約保證</text>' +
      '<text x="380" y="168" fill="#dc2626" font-size="11" text-anchor="middle">隔絕買賣雙方信用風險</text>' +

      '<rect x="540" y="80" width="160" height="90" rx="8" fill="#fef2f2" stroke="#dc2626"/>' +
      '<text x="620" y="115" fill="#dc2626" font-size="15" font-weight="bold" text-anchor="middle">賣方投資人 (Seller)</text>' +
      '<text x="620" y="145" fill="#475569" font-size="12" text-anchor="middle">建立期貨空頭部位</text>' +

      '<line x1="220" y1="125" x2="285" y2="125" stroke="#059669" stroke-width="3" marker-end="url(#arrG)"/>' +
      '<line x1="540" y1="125" x2="475" y2="125" stroke="#dc2626" stroke-width="3" marker-end="url(#arrR)"/>' +
      '<text x="380" y="210" fill="#475569" font-size="12" text-anchor="middle">原買賣合約分裂為「買方對結算所」與「結算所對賣方」兩份獨立法律契約</text>'
    );
  };

  // 4. short-selling-cashflow
  D['short-selling-cashflow'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="42" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">期貨放空機制與現金流：無需借券、多空對等權利義務</text>' +
      '<g transform="translate(60, 70)">' +
        '<rect x="0" y="0" width="190" height="110" rx="8" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="95" y="30" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">第一步：繳存保證金</text>' +
        '<text x="95" y="60" fill="#475569" font-size="12" text-anchor="middle">放入原始保證金</text>' +
        '<text x="95" y="85" fill="#059669" font-size="11" text-anchor="middle">開立委託賣出賣單 (Short)</text>' +
      '</g>' +
      '<g transform="translate(285, 70)">' +
        '<rect x="0" y="0" width="190" height="110" rx="8" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="95" y="30" fill="#b45309" font-size="14" font-weight="bold" text-anchor="middle">第二步：逐日盯市結算</text>' +
        '<text x="95" y="55" fill="#059669" font-size="11" text-anchor="middle">標的下跌 ➔ 帳戶貸記現金</text>' +
        '<text x="95" y="75" fill="#dc2626" font-size="11" text-anchor="middle">標的上漲 ➔ 帳戶扣除虧損</text>' +
        '<text x="95" y="95" fill="#475569" font-size="10" text-anchor="middle">每日收盤依結算價劃撥</text>' +
      '</g>' +
      '<g transform="translate(510, 70)">' +
        '<rect x="0" y="0" width="190" height="110" rx="8" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="95" y="30" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">第三步：買回平倉出清</text>' +
        '<text x="95" y="60" fill="#475569" font-size="12" text-anchor="middle">隨時可在市場買進沖銷</text>' +
        '<text x="95" y="85" fill="#0f172a" font-size="11" text-anchor="middle">未平倉責任即刻解除</text>' +
      '</g>' +
      '<line x1="250" y1="125" x2="280" y2="125" stroke="#64748b" stroke-width="2" marker-end="url(#arr)"/>' +
      '<line x1="475" y1="125" x2="505" y2="125" stroke="#64748b" stroke-width="2" marker-end="url(#arr)"/>'
    );
  };

  // 5. margin-three-tiers
  D['margin-three-tiers'] = function () {
    return FUT.wrapSvg(760, 270,
      '<rect x="20" y="15" width="720" height="240" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="42" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">三層保證金制度與風控水位階梯</text>' +
      '<rect x="60" y="65" width="140" height="160" rx="6" fill="#f1f5f9" stroke="#94a3b8"/>' +
      '<rect x="60" y="65" width="140" height="40" fill="#10b981"/>' +
      '<rect x="60" y="105" width="140" height="40" fill="#f59e0b"/>' +
      '<rect x="60" y="145" width="140" height="50" fill="#ea580c"/>' +
      '<rect x="60" y="195" width="140" height="30" fill="#ef4444"/>' +
      '<text x="130" y="90" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">安全健康區</text>' +
      '<text x="130" y="130" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">警戒追繳區</text>' +
      '<text x="130" y="175" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">高危急迫區</text>' +
      '<text x="130" y="215" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">25% 強制斬倉</text>' +

      '<line x1="205" y1="65" x2="260" y2="65" stroke="#059669" stroke-width="2"/>' +
      '<text x="270" y="70" fill="#059669" font-size="13" font-weight="bold">100% 原始保證金 (Initial Margin) — 開倉門檻</text>' +
      '<text x="270" y="90" fill="#64748b" font-size="11">開立新合約必須具備之最低帳戶權益數，帳戶維持高安全度。</text>' +

      '<line x1="205" y1="105" x2="260" y2="105" stroke="#b45309" stroke-width="2"/>' +
      '<text x="270" y="110" fill="#b45309" font-size="13" font-weight="bold">約 77% 維持保證金 (Maintenance Margin) — 追繳紅線</text>' +
      '<text x="270" y="130" fill="#64748b" font-size="11">盤後結算低於此水位發布追繳通知，隔日 12:00 前須補回 100% 原始保證金！</text>' +

      '<line x1="205" y1="195" x2="260" y2="195" stroke="#dc2626" stroke-width="2"/>' +
      '<text x="270" y="200" fill="#dc2626" font-size="13" font-weight="bold">25% 風險指標斷頭線 (Liquidation Level) — 強制平倉</text>' +
      '<text x="270" y="220" fill="#b91c1c" font-size="11">盤中權益數 ÷ 原始保證金 ≤ 25%，期貨商系統立即市價全部砍倉出清！</text>'
    );
  };

  // 6. margin-call-flowchart
  D['margin-call-flowchart'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">期貨追繳流程與處置時序圖 (Margin Call Timeline)</text>' +
      '<rect x="40" y="65" width="140" height="85" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
      '<text x="110" y="90" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">收盤 13:45</text>' +
      '<text x="110" y="112" fill="#64748b" font-size="11" text-anchor="middle">每日盯市結算</text>' +
      '<text x="110" y="132" fill="#dc2626" font-size="11" text-anchor="middle">權益數 &lt; 維持保證金</text>' +

      '<rect x="220" y="65" width="140" height="85" rx="6" fill="#fffbeb" stroke="#f59e0b"/>' +
      '<text x="290" y="90" fill="#b45309" font-size="12" font-weight="bold" text-anchor="middle">盤後 16:00 前</text>' +
      '<text x="290" y="112" fill="#64748b" font-size="11" text-anchor="middle">期貨商發布追繳函</text>' +
      '<text x="290" y="132" fill="#b45309" font-size="11" text-anchor="middle">簡訊/Email/推播通知</text>' +

      '<rect x="400" y="65" width="140" height="85" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
      '<text x="470" y="90" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">次日 12:00 前</text>' +
      '<text x="470" y="112" fill="#059669" font-size="11" text-anchor="middle">路徑 A：補足現金</text>' +
      '<text x="470" y="132" fill="#0284c7" font-size="11" text-anchor="middle">路徑 B：自行減倉</text>' +

      '<rect x="580" y="65" width="140" height="85" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
      '<text x="650" y="90" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">次日 12:00 整</text>' +
      '<text x="650" y="112" fill="#b91c1c" font-size="11" text-anchor="middle">未補足原始保證金</text>' +
      '<text x="650" y="132" fill="#dc2626" font-size="11" font-weight="bold" text-anchor="middle">期貨商強制斬倉！</text>' +

      '<line x1="180" y1="107" x2="215" y2="107" stroke="#64748b" stroke-width="2" marker-end="url(#arr)"/>' +
      '<line x1="360" y1="107" x2="395" y2="107" stroke="#64748b" stroke-width="2" marker-end="url(#arr)"/>' +
      '<line x1="540" y1="107" x2="575" y2="107" stroke="#64748b" stroke-width="2" marker-end="url(#arr)"/>' +
      '<text x="380" y="185" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">⚠️ 注意：盤後追繳必須補足至「原始保證金」，而非僅補到維持保證金！</text>'
    );
  };

  // 7. liquidation-25pct-waterfall
  D['liquidation-25pct-waterfall'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">盤中 25% 強制斬倉瀑布流 (Intraday Liquidation Waterfall)</text>' +
      '<g transform="translate(60, 65)">' +
        '<rect x="0" y="0" width="180" height="120" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="90" y="28" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">觸發條件</text>' +
        '<text x="90" y="55" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">風險指標 ≤ 25%</text>' +
        '<text x="90" y="80" fill="#64748b" font-size="11" text-anchor="middle">盤中即時行情穿價</text>' +
        '<text x="90" y="100" fill="#64748b" font-size="11" text-anchor="middle">權益數低於原始 25%</text>' +
      '</g>' +
      '<g transform="translate(285, 65)">' +
        '<rect x="0" y="0" width="190" height="120" rx="6" fill="#fef2f2" stroke="#dc2626"/>' +
        '<text x="95" y="28" fill="#dc2626" font-size="13" font-weight="bold" text-anchor="middle">系統自動無差別委託</text>' +
        '<text x="95" y="55" fill="#b91c1c" font-size="12" font-weight="bold" text-anchor="middle">市價單全數砍倉</text>' +
        '<text x="95" y="80" fill="#475569" font-size="11" text-anchor="middle">無需營業員手動確認</text>' +
        '<text x="95" y="100" fill="#475569" font-size="11" text-anchor="middle">不計滑價立即出清</text>' +
      '</g>' +
      '<g transform="translate(515, 65)">' +
        '<rect x="0" y="0" width="180" height="120" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>' +
        '<text x="90" y="28" fill="#0f172a" font-size="13" font-weight="bold" text-anchor="middle">清算結果</text>' +
        '<text x="90" y="55" fill="#059669" font-size="12" text-anchor="middle">殘存權益數返還</text>' +
        '<text x="90" y="80" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">超額損失 (Overloss)</text>' +
        '<text x="90" y="100" fill="#b91c1c" font-size="11" text-anchor="middle">負數須補足，否則違約</text>' +
      '</g>' +
      '<line x1="240" y1="125" x2="280" y2="125" stroke="#dc2626" stroke-width="2" marker-end="url(#arrR)"/>' +
      '<line x1="475" y1="125" x2="510" y2="125" stroke="#dc2626" stroke-width="2" marker-end="url(#arrR)"/>'
    );
  };

  // 8. leverage-vs-volatility
  D['leverage-vs-volatility'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">槓桿倍數 vs 波動度放大鏡：實質槓桿 = 名目價值 ÷ 本金權益數</text>' +
      '<rect x="70" y="80" width="140" height="60" rx="6" fill="#ecfdf5" stroke="#059669"/>' +
      '<text x="140" y="108" fill="#059669" font-size="14" font-weight="bold" text-anchor="middle">自備款 NT$ 7 萬</text>' +
      '<text x="140" y="128" fill="#475569" font-size="11" text-anchor="middle">保證金本金</text>' +

      '<polygon points="270,110 255,145 285,145" fill="#f59e0b"/>' +
      '<line x1="140" y1="110" x2="620" y2="90" stroke="#f59e0b" stroke-width="4"/>' +

      '<rect x="520" y="65" width="160" height="75" rx="6" fill="#f0f9ff" stroke="#0284c7"/>' +
      '<text x="600" y="95" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">控制 NT$ 100 萬資產</text>' +
      '<text x="600" y="118" fill="#0369a1" font-size="12" text-anchor="middle">(14.3 倍實質槓桿)</text>' +

      '<text x="380" y="180" fill="#dc2626" font-size="13" font-weight="bold" text-anchor="middle">⚠️ 標的物只需波動 7%，保證金部位即翻倍或瞬間歸零！</text>'
    );
  };

  // 9. contango-curve-carry
  D['contango-curve-carry'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">正價差曲線 (Contango) 與持有成本模型 (Cost of Carry)</text>' +
      '<path d="M 100,160 Q 300,140 640,75" fill="none" stroke="#0284c7" stroke-width="4"/>' +
      '<circle cx="100" cy="160" r="6" fill="#f59e0b"/>' +
      '<circle cx="640" cy="75" r="6" fill="#0284c7"/>' +
      '<text x="100" y="185" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">現貨 / 近月價格</text>' +
      '<text x="640" y="65" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">遠期合約價格</text>' +
      '<text x="380" y="125" fill="#b45309" font-size="13" font-weight="bold" text-anchor="middle">期貨價格 = 現貨價格 + 持有成本 (倉儲費 + 資金利息 + 保險)</text>' +
      '<text x="380" y="205" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">⚠️ 遠月貴於近月：期貨多頭轉倉面臨負滾動損耗 (Negative Roll Yield)</text>'
    );
  };

  // 10. backwardation-convenience
  D['backwardation-convenience'] = function () {
    return FUT.wrapSvg(760, 240,
      '<rect x="20" y="15" width="720" height="210" rx="10" fill="#ffffff" stroke="#cbd5e1"/>' +
      '<text x="380" y="40" fill="#0f172a" font-size="16" font-weight="bold" text-anchor="middle">逆價差曲線 (Backwardation) 與便利收益 (Convenience Yield)</text>' +
      '<path d="M 100,75 Q 300,140 640,160" fill="none" stroke="#059669" stroke-width="4"/>' +
      '<circle cx="100" cy="75" r="6" fill="#059669"/>' +
      '<circle cx="640" cy="160" r="6" fill="#f59e0b"/>' +
      '<text x="100" y="65" fill="#059669" font-size="12" font-weight="bold" text-anchor="middle">現貨緊俏急缺！</text>' +
      '<text x="640" y="185" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">遠期價格回落</text>' +
      '<text x="380" y="125" fill="#059669" font-size="13" font-weight="bold" text-anchor="middle">便利收益 (Convenience Yield) &gt; 持有成本 ➔ 現貨升水</text>' +
      '<text x="380" y="205" fill="#059669" font-size="12" font-weight="bold" text-anchor="middle">✨ 近月貴於遠月：期貨多頭轉倉享有正滾動收益 (Positive Roll Yield)</text>'
    );
  };

  // 統一排查接口
  FUT.renderDiagram = function (key) {
    if (!key) return '';
    var norm = String(key).toLowerCase().replace(/_/g, '-');
    if (typeof D[norm] === 'function') {
      return D[norm]();
    }
    return '<div class="fut-diagram-placeholder">無對應圖解：' + FUT.esc(key) + '</div>';
  };

})();