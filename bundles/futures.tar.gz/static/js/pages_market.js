/* 期貨學院行情看板 — 商品行情、30日 Sparkline、LME 正逆價差與台灣期交所官方保證金總覽 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};

  FUT.route('market', function (el, args) {
    var cat = args[0] || 'all';
    renderMarket(el, cat);
  });

  function formatPriceWithUnit(it) {
    var p = it.price;
    var u = it.unit || '';
    if (u === '點') {
      return FUT.fmtNum(p, 0) + ' <span class="c-unit">點</span>';
    }
    if (u === '美分/蒲式耳' || u === '美分/磅') {
      return FUT.fmtNum(p, 2) + ' <span class="c-unit">' + FUT.esc(u) + '</span>';
    }
    if (u.indexOf('美元/') >= 0 || it.currency === 'USD') {
      return '$' + FUT.fmtNum(p) + ' <span class="c-unit">' + FUT.esc(u.replace('美元/', '')) + '</span>';
    }
    if (it.exchange === 'TAIFEX') {
      return 'NT$' + FUT.fmtNum(p, 0);
    }
    return FUT.fmtNum(p) + (u ? ' <span class="c-unit">' + FUT.esc(u) + '</span>' : '');
  }

  function renderMarket(el, activeCat) {
    var allItems = FUT.prices.getAll();
    var ratios = FUT.prices.getRatios();
    var margins = FUT.prices.getMargins();
    var status = FUT.prices.getStatusText();

    var filtered = allItems.filter(function (it) {
      if (activeCat === 'watch') return FUT.watch.has(it.symbol);
      if (activeCat && activeCat !== 'all') return it.category === activeCat;
      return true;
    });

    var catsHtml = [
      { id: 'all', name: '全部商品 (' + allItems.length + ')' },
      { id: 'watch', name: '⭐ 自選追蹤 (' + FUT.watch.list().length + ')' }
    ].concat(FUT.COMMODITY_CATS.map(function (c) {
      var cnt = allItems.filter(function (it) { return it.category === c.id; }).length;
      return { id: c.id, name: c.icon + ' ' + c.name + ' (' + cnt + ')' };
    })).map(function (c) {
      var act = c.id === activeCat ? 'active' : '';
      return '<button class="fut-cat-pill ' + act + '" data-cat="' + c.id + '">' + c.name + '</button>';
    }).join('');

    el.innerHTML =
      '<div class="fut-container">' +
        '<div class="fut-page-header">' +
          '<div class="fut-header-flex">' +
            '<div>' +
              '<h2>📊 全球原物料與期貨行情看板</h2>' +
              '<p class="fut-subtext">涵蓋台灣期交所台指大中小微台、芝商所 CME/CBOT/NYMEX/COMEX 與倫敦金屬交易所 LME。</p>' +
            '</div>' +
            '<div class="fut-market-status-badge ' + status.cls + '">' +
              status.icon + ' ' + status.text +
              (!FUT.isStatic() ? ' <button id="btnRefreshPrices" class="fut-btn-sm">🔄 更新</button>' : '') +
            '</div>' +
          '</div>' +
        '</div>' +

        // 跨市場重要宏觀指標
        '<div class="fut-macro-grid">' +
          '<div class="fut-macro-card">' +
            '<div class="macro-title">🥇/🥈 金銀比 (Gold/Silver)</div>' +
            '<div class="macro-val">' + (ratios.gold_silver_ratio || '—') + '</div>' +
            '<div class="macro-sub">歷史中位 ~65；&gt;80 預示白銀偏低</div>' +
          '</div>' +
          '<div class="fut-macro-card">' +
            '<div class="macro-title">🥇/🛢️ 金油比 (Gold/Oil)</div>' +
            '<div class="macro-val">' + (ratios.gold_oil_ratio || '—') + '</div>' +
            '<div class="macro-sub">避險與能源相對強弱指標</div>' +
          '</div>' +
          '<div class="fut-macro-card">' +
            '<div class="macro-title">🧱/🥇 銅金比 (Copper/Gold)</div>' +
            '<div class="macro-val">' + (ratios.copper_gold_ratio || '—') + '</div>' +
            '<div class="macro-sub">全球實體製造業景氣晴雨表</div>' +
          '</div>' +
          '<div class="fut-macro-card">' +
            '<div class="macro-title">💵 美元兌台幣 (USD/TWD)</div>' +
            '<div class="macro-val">' + (ratios.usd_twd ? Number(ratios.usd_twd).toFixed(2) : '32.50') + '</div>' +
            '<div class="macro-sub">外期保證金與實體進口換算依據</div>' +
          '</div>' +
        '</div>' +

        '<div class="fut-cat-bar">' + catsHtml + '</div>' +

        // 商品行情表格
        '<div class="fut-card" style="padding:0; overflow:hidden;">' +
          '<div class="fut-table-wrap">' +
            '<table class="fut-table">' +
              '<thead>' +
                '<tr>' +
                  '<th style="width:36px;"></th>' +
                  '<th>商品名稱 / 代碼</th>' +
                  '<th>交易所</th>' +
                  '<th style="text-align:right;">最新成交價</th>' +
                  '<th style="text-align:right;">漲跌額</th>' +
                  '<th style="text-align:right;">漲跌幅</th>' +
                  '<th style="text-align:center;">30日走勢</th>' +
                  '<th>合約備註 / 期限結構</th>' +
                  '<th style="text-align:center;">操作</th>' +
                '</tr>' +
              '</thead>' +
              '<tbody>' +
                (filtered.length === 0
                  ? '<tr><td colspan="9" class="fut-empty-td">查無此類別商品或自選清單為空</td></tr>'
                  : filtered.map(renderRow).join('')) +
              '</tbody>' +
            '</table>' +
          '</div>' +
        '</div>' +

        // 🇹🇼 台灣期交所最新官方保證金總覽
        renderTaifexMarginsTable(margins) +

        '<div class="fut-disclaimer">' +
          '⚖️ 免責聲明：本站行情數據取自公開交易所與資訊提供商，僅供期貨市場運作機制、避險原理與保證金風控教學用途，絕不構成任何形式之投資建言或交易邀約。' +
        '</div>' +
      '</div>';

    // 綁定類別切換
    FUT.$$('.fut-cat-pill', el).forEach(function (btn) {
      btn.onclick = function () {
        var c = btn.getAttribute('data-cat');
        FUT.go('market/' + c);
      };
    });

    // 綁定自選星號
    FUT.$$('.btn-star', el).forEach(function (btn) {
      btn.onclick = function (e) {
        e.stopPropagation();
        var id = btn.getAttribute('data-sym');
        var added = FUT.watch.toggle(id);
        btn.textContent = added ? '★' : '☆';
        btn.classList.toggle('active', added);
        FUT.toast(added ? '已加入自選觀察' : '已從自選觀察移除');
        if (activeCat === 'watch') renderMarket(el, activeCat);
      };
    });

    // 綁定商品規格詳情
    FUT.$$('.btn-detail', el).forEach(function (btn) {
      btn.onclick = function () {
        var sym = btn.getAttribute('data-sym');
        showCommodityModal(sym);
      };
    });

    // 綁定重新整理
    var refBtn = document.getElementById('btnRefreshPrices');
    if (refBtn) {
      refBtn.onclick = function () {
        refBtn.disabled = true;
        refBtn.textContent = '更新中...';
        FUT.prices.refreshServer(function (ok, msg) {
          FUT.toast(msg);
          refBtn.disabled = false;
          refBtn.textContent = '🔄 更新';
          renderMarket(el, activeCat);
        });
      };
    }
  }

  function renderRow(it) {
    var isStar = FUT.watch.has(it.symbol);
    var pctCls = FUT.pctClass(it.change_pct);
    var badge = FUT.pctBadge(it.change_pct);
    var sparkSvg = renderSparklineSvg(it.sparkline, it.change_pct >= 0);
    var priceHtml = formatPriceWithUnit(it);

    var noteHtml = '';
    if (it.spread_structure || it.curve) {
      var isContango = (it.spread_structure === 'contango' || it.curve === 'contango');
      var sVal = it.spread_val != null ? it.spread_val : it.spread;
      noteHtml = '<span class="' + (isContango ? 'badge-contango' : 'badge-backwardation') + '">' +
        (isContango ? '正價差 Contango' : '逆價差 Backwardation') +
        (sVal != null ? ' (' + (sVal > 0 ? '+' : '') + sVal + ')' : '') +
        '</span>';
    } else if (it.exchange === 'TAIFEX' || it.exch === 'TAIFEX') {
      noteHtml = '<span class="badge-taifex">乘數: NT$' + (it.multiplier || it.contract_size || '200') + '/點</span>';
    } else if (it.unit) {
      noteHtml = '<span class="c-muted">' + FUT.esc(it.unit) + '</span>';
    }

    return '<tr class="fut-tr">' +
      '<td style="text-align:center;">' +
        '<button class="btn-star ' + (isStar ? 'active' : '') + '" data-sym="' + it.symbol + '">' +
          (isStar ? '★' : '☆') +
        '</button>' +
      '</td>' +
      '<td>' +
        '<div class="fut-sym-cell">' +
          '<span class="sym-name">' + FUT.esc(it.name) + '</span>' +
          '<span class="sym-code">' + FUT.esc(it.symbol) + (it.is_live ? ' 🟢Live' : '') + '</span>' +
        '</div>' +
      '</td>' +
      '<td><span class="badge-ex">' + FUT.esc(it.exchange) + '</span></td>' +
      '<td style="text-align:right;" class="cell-price ' + pctCls + '">' + priceHtml + '</td>' +
      '<td style="text-align:right;" class="' + pctCls + '">' +
        (it.change > 0 ? '+' : '') + FUT.fmtNum(it.change) +
      '</td>' +
      '<td style="text-align:right;">' + badge + '</td>' +
      '<td style="text-align:center;">' + sparkSvg + '</td>' +
      '<td>' + noteHtml + '</td>' +
      '<td style="text-align:center;">' +
        '<button class="fut-btn-sm btn-detail" data-sym="' + it.symbol + '">規格</button>' +
      '</td>' +
    '</tr>';
  }

  function renderSparklineSvg(data, isUp) {
    if (!data || !data.length || data.length < 2) {
      return '<span class="c-muted">—</span>';
    }
    var w = 80, h = 26;
    var min = Math.min.apply(null, data);
    var max = Math.max.apply(null, data);
    var span = (max - min) || 1;
    var pts = data.map(function (v, idx) {
      var x = (idx / (data.length - 1)) * w;
      var y = h - 2 - ((v - min) / span) * (h - 4);
      return x.toFixed(1) + ',' + y.toFixed(1);
    }).join(' ');

    var strokeColor = isUp ? '#10b981' : '#ef4444';
    return '<svg width="' + w + '" height="' + h + '" class="fut-sparkline">' +
      '<polyline points="' + pts + '" fill="none" stroke="' + strokeColor + '" stroke-width="1.6"/>' +
    '</svg>';
  }

  function renderTaifexMarginsTable(margins) {
    if (!margins || !Object.keys(margins).length) return '';
    var keys = ['TX', 'MTX', 'TMF', 'TGF', 'GDF', 'BRF'];
    var rows = keys.map(function (k) {
      var m = margins[k];
      if (!m) return '';
      var cur = m.currency === 'USD' ? '$' : 'NT$';
      var ratio = (m.initial && m.maintenance) ? ((m.maintenance / m.initial) * 100).toFixed(1) + '%' : '—';
      return '<tr>' +
        '<td><strong>' + FUT.esc(m.name || k) + '</strong> (' + k + ')</td>' +
        '<td>' + (m.multiplier != null ? (typeof m.multiplier === 'number' ? '點數 × ' + cur + m.multiplier : m.multiplier) : '—') + '</td>' +
        '<td style="text-align:center;">' + FUT.esc(m.currency || 'TWD') + '</td>' +
        '<td style="text-align:right;" class="c-up">' + cur + ' ' + FUT.fmtNum(m.initial, 0) + '</td>' +
        '<td style="text-align:right;" class="c-warn">' + cur + ' ' + FUT.fmtNum(m.maintenance, 0) + '</td>' +
        '<td style="text-align:right;">' + cur + ' ' + FUT.fmtNum(m.clearing, 0) + '</td>' +
        '<td style="text-align:center;">' + ratio + '</td>' +
      '</tr>';
    }).join('');

    return '<div class="fut-card" style="margin-top:24px; padding:0; overflow:hidden;">' +
      '<div class="fut-card-header" style="padding:16px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0;">' +
        '<h3 style="margin:0; font-size:16px; color:#0f172a;">🇹🇼 台灣期交所最新官方保證金標準一覽表</h3>' +
        '<span class="c-muted" style="font-size:12px;">直接串接期交所 OpenAPI，每日盯市與維持率對照</span>' +
      '</div>' +
      '<div class="fut-table-wrap">' +
        '<table class="fut-table">' +
          '<thead>' +
            '<tr>' +
              '<th>合約標的名稱</th>' +
              '<th>合約乘數 / 規格</th>' +
              '<th style="text-align:center;">幣別</th>' +
              '<th style="text-align:right;">原始保證金 (100%)</th>' +
              '<th style="text-align:right;">維持保證金 (警戒線)</th>' +
              '<th style="text-align:right;">結算保證金</th>' +
              '<th style="text-align:center;">維持率</th>' +
            '</tr>' +
          '</thead>' +
          '<tbody>' + rows + '</tbody>' +
        '</table>' +
      '</div>' +
    '</div>';
  }

  function showCommodityModal(sym) {
    var c = FUT.prices.get(sym);
    if (!c) return;

    var modal = document.createElement('div');
    modal.className = 'fut-modal-backdrop';
    modal.innerHTML =
      '<div class="fut-modal-box">' +
        '<div class="fut-modal-head">' +
          '<h3>' + FUT.esc(c.name) + ' (' + FUT.esc(c.symbol) + ') 合約規格書</h3>' +
          '<button class="fut-modal-close">&times;</button>' +
        '</div>' +
        '<div class="fut-modal-body">' +
          '<div class="fut-spec-grid">' +
            '<div class="spec-item"><span class="lbl">所屬交易所：</span><span class="val">' + FUT.esc(c.exchange) + '</span></div>' +
            '<div class="spec-item"><span class="lbl">計價計量單位：</span><span class="val">' + FUT.esc(c.unit || '依規格規定') + '</span></div>' +
            '<div class="spec-item"><span class="lbl">合約乘數 / 規模：</span><span class="val">' + (c.multiplier ? '每點 NT$' + c.multiplier : (c.contract_size || '標準合約')) + '</span></div>' +
            '<div class="spec-item"><span class="lbl">交割結算方式：</span><span class="val">' + (c.delivery_mode === 'cash' || c.delivery === 'cash' ? '現金結算 (Cash)' : '實物交割 (Physical)') + '</span></div>' +
            '<div class="spec-item"><span class="lbl">最新收盤/即時價：</span><span class="val ' + FUT.pctClass(c.change_pct) + '">' + formatPriceWithUnit(c) + ' (' + FUT.fmtPct(c.change_pct) + ')</span></div>' +
            '<div class="spec-item"><span class="lbl">期限結構型態：</span><span class="val">' + (c.curve_zh || (c.curve === 'contango' ? '正價差 Contango' : c.curve === 'backwardation' ? '逆價差 Backwardation' : '常態')) + '</span></div>' +
          '</div>' +
          (c.desc ? '<div class="fut-spec-desc"><strong>商品特性與避險角色：</strong><p>' + FUT.esc(c.desc) + '</p></div>' : '') +
          '<div class="fut-modal-foot">' +
            '<button class="fut-btn btn-go-lab" data-sym="' + c.symbol + '">🧮 帶入保證金試算器</button>' +
          '</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(modal);

    modal.querySelector('.fut-modal-close').onclick = function () { modal.remove(); };
    modal.onclick = function (e) { if (e.target === modal) modal.remove(); };
    var goBtn = modal.querySelector('.btn-go-lab');
    if (goBtn) {
      goBtn.onclick = function () {
        modal.remove();
        FUT.go('labs/margin');
      };
    }
  }

})();