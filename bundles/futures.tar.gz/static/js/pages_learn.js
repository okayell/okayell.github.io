/* 期貨學院課程閱讀器 — 八大專章、32 堂課程閱覽、原生 SVG 圖解嵌入、段落列表、盲點對照、隨堂測驗與進度回報 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};

  FUT.route('learn', function (el, args) {
    var trackId = args[0];
    if (trackId) {
      renderTrackLessons(el, trackId);
    } else {
      renderTrackCatalog(el);
    }
  });

  FUT.route('lesson', function (el, args) {
    var lessonId = args[0];
    renderLessonReader(el, lessonId);
  });

  // 八大專章目錄
  function renderTrackCatalog(el) {
    var tracks = FUT.TRACKS || [];
    var lessons = window.FUT_LESSONS || FUT.LESSONS || [];

    var cardsHtml = tracks.map(function (t, idx) {
      var trackLessons = lessons.filter(function (l) { return l.track === t.id; });
      var doneCnt = trackLessons.filter(function (l) { return FUT.progress.isDone(l.id); }).length;
      var total = trackLessons.length || 4;
      var pct = total > 0 ? Math.round((doneCnt / total) * 100) : 0;

      return '<div class="fut-track-card" data-track="' + t.id + '">' +
        '<div class="track-head">' +
          '<span class="track-icon">' + t.icon + '</span>' +
          '<div class="track-meta">' +
            '<span class="track-num">第 ' + (idx + 1) + ' 章</span>' +
            '<h3>' + FUT.esc(t.name) + '</h3>' +
          '</div>' +
          '<span class="track-pct ' + (pct === 100 ? 'c-up' : '') + '">' + pct + '%</span>' +
        '</div>' +
        '<p class="track-desc">' + FUT.esc(t.desc) + '</p>' +
        '<div class="track-progress-bar"><div class="bar-fill" style="width:' + pct + '%;"></div></div>' +
        '<div class="track-foot">' +
          '<span>進度：' + doneCnt + ' / ' + total + ' 課</span>' +
          '<button class="fut-btn-sm">進入章節 &rarr;</button>' +
        '</div>' +
      '</div>';
    }).join('');

    el.innerHTML =
      '<div class="fut-container">' +
        '<div class="fut-page-header">' +
          '<h2>📚 系統化期貨與原物料學程（八大專章 32 堂核心課程）</h2>' +
          '<p class="fut-subtext">從江戶時代堂島米市到現代結算所，深入能源、金屬、農產品產業鏈與避險風控實務。</p>' +
        '</div>' +
        '<div class="fut-track-grid">' + cardsHtml + '</div>' +
      '</div>';

    FUT.$$('.fut-track-card', el).forEach(function (card) {
      card.onclick = function () {
        var tid = card.getAttribute('data-track');
        FUT.go('learn/' + tid);
      };
    });
  }

  // 專章內課程列表
  function renderTrackLessons(el, trackId) {
    var t = (FUT.TRACKS || []).find(function (tr) { return tr.id === trackId; }) || FUT.TRACKS[0];
    var lessons = (window.FUT_LESSONS || FUT.LESSONS || []).filter(function (l) { return l.track === trackId; });
    lessons.sort(function (a, b) { return (a.order || 0) - (b.order || 0); });

    var listHtml = lessons.length === 0
      ? '<div class="fut-empty">本專章課程教材撰寫中（即將上架）</div>'
      : lessons.map(function (l, idx) {
        var isDone = FUT.progress.isDone(l.id);
        var score = FUT.progress.quizOf(l.id);
        return '<div class="fut-lesson-row ' + (isDone ? 'is-done' : '') + '" data-lid="' + l.id + '">' +
          '<div class="l-check">' + (isDone ? '✅' : '⚪') + '</div>' +
          '<div class="l-body">' +
            '<div class="l-num">第 ' + (idx + 1) + ' 課・' + (l.minutes || 10) + ' 分鐘</div>' +
            '<h4>' + FUT.esc(l.title) + '</h4>' +
            '<p class="l-summary">' + FUT.esc(l.sub || l.summary || '') + '</p>' +
          '</div>' +
          '<div class="l-action">' +
            (score != null ? '<span class="badge-quiz">測驗 ' + score + '分</span>' : '') +
            '<button class="fut-btn-sm">' + (isDone ? '複習' : '開始學習') + ' &rarr;</button>' +
          '</div>' +
        '</div>';
      }).join('');

    el.innerHTML =
      '<div class="fut-container">' +
        '<div class="fut-breadcrumb">' +
          '<button id="btnBackCatalog" class="fut-btn-link">&larr; 返回學程目錄</button>' +
        '</div>' +
        '<div class="fut-track-banner">' +
          '<span class="banner-icon">' + t.icon + '</span>' +
          '<div>' +
            '<h2>' + FUT.esc(t.name) + '</h2>' +
            '<p>' + FUT.esc(t.desc) + '</p>' +
          '</div>' +
        '</div>' +
        '<div class="fut-lesson-list">' + listHtml + '</div>' +
      '</div>';

    var backBtn = document.getElementById('btnBackCatalog');
    if (backBtn) backBtn.onclick = function () { FUT.go('learn'); };

    FUT.$$('.fut-lesson-row', el).forEach(function (row) {
      row.onclick = function () {
        var lid = row.getAttribute('data-lid');
        FUT.go('lesson/' + lid);
      };
    });
  }

  // 單堂課程閱讀器
  function renderLessonReader(el, lessonId) {
    var allLessons = window.FUT_LESSONS || FUT.LESSONS || [];
    var l = allLessons.find(function (it) { return it.id === lessonId; });
    if (!l) {
      el.innerHTML =
        '<div class="fut-container">' +
          '<div class="fut-empty">找不到指定課程：' + FUT.esc(lessonId) + '<br>' +
            '<button onclick="window.FUT.go(\'learn\')" class="fut-btn" style="margin-top:14px;">返回章節列表</button>' +
          '</div>' +
        '</div>';
      return;
    }

    var isDone = FUT.progress.isDone(l.id);
    var dKey = l.diagram || l.diagram_key;
    var diagramHtml = dKey ? FUT.renderDiagram(dKey) : '';

    // 計算上一課／下一課
    var trackLessons = allLessons.filter(function (it) { return it.track === l.track; });
    trackLessons.sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
    var curIdx = trackLessons.findIndex(function (it) { return it.id === l.id; });
    var prevL = curIdx > 0 ? trackLessons[curIdx - 1] : null;
    var nextL = curIdx < trackLessons.length - 1 ? trackLessons[curIdx + 1] : null;

    // 核心章節段落渲染
    var sectionsHtml = '';
    if (l.sections && Array.isArray(l.sections)) {
      sectionsHtml = l.sections.map(function (sec) {
        var pHtml = (sec.p || []).map(function (para) { return '<p>' + FUT.esc(para) + '</p>'; }).join('');
        var listHtml = (sec.list && sec.list.length)
          ? '<ul class="fut-sec-list">' + sec.list.map(function (li) { return '<li>' + FUT.esc(li) + '</li>'; }).join('') + '</ul>'
          : '';
        return '<div class="fut-sec-block">' +
          (sec.h ? '<h3>' + FUT.esc(sec.h) + '</h3>' : '') +
          pHtml + listHtml +
        '</div>';
      }).join('');
    } else if (l.content_html || l.content) {
      sectionsHtml = l.content_html || '<p>' + FUT.esc(l.content) + '</p>';
    }

    // 術語標籤
    var termsHtml = (l.terms && l.terms.length)
      ? '<div class="fut-terms-bar"><span class="terms-title">🏷️ 核心術語：</span>' +
        l.terms.map(function (tm) {
          return '<a href="#/glossary/all/' + encodeURIComponent(tm) + '" class="term-pill">' + FUT.esc(tm) + '</a>';
        }).join('') + '</div>'
      : '';

    // 隨堂測驗
    var quizItems = l.quiz || [];
    var quizHtml = '';
    if (quizItems.length > 0) {
      quizHtml = '<div class="fut-quiz-card">' +
        '<div class="fut-quiz-head">' +
          '<h3>📝 隨堂理解測驗（共 ' + quizItems.length + ' 題）</h3>' +
          '<span class="c-muted" style="font-size:12px;">答對自動記入個人學習檔案</span>' +
        '</div>' +
        quizItems.map(function (q, qIdx) {
          var opts = q.opts || q.options || [];
          return '<div class="fut-quiz-item" data-qidx="' + qIdx + '">' +
            '<p class="q-title"><strong>Q' + (qIdx + 1) + '. ' + FUT.esc(q.q || q.question) + '</strong></p>' +
            '<div class="q-options">' +
              opts.map(function (opt, oIdx) {
                return '<button class="q-opt-btn" data-oidx="' + oIdx + '">' +
                  String.fromCharCode(65 + oIdx) + '. ' + FUT.esc(opt) +
                '</button>';
              }).join('') +
            '</div>' +
            '<div class="q-result" style="display:none;"></div>' +
          '</div>';
        }).join('') +
      '</div>';
    }

    el.innerHTML =
      '<div class="fut-container fut-reader-wrap">' +
        '<div class="fut-reader-top-bar">' +
          '<button id="btnBackTrack" class="fut-btn-link">&larr; 返回專章目錄</button>' +
          (l.labId ? '<a href="#/labs/' + l.labId + '" class="fut-btn-lab-jump">🧪 前往互動實驗室親手試算 &rarr;</a>' : '') +
        '</div>' +

        '<div class="fut-reader-header">' +
          '<div class="r-badge">' + (l.track_name || '期貨核心專章') + '</div>' +
          '<h2>' + FUT.esc(l.title) + '</h2>' +
          (l.sub ? '<div class="r-sub">' + FUT.esc(l.sub) + '</div>' : '') +
          '<div class="r-meta">' +
            '<span>⏱️ 估計研讀時間：' + (l.minutes || 8) + ' 分鐘</span>' +
            '<span>📊 難易度：' + (l.level || '進階實務') + '</span>' +
          '</div>' +
        '</div>' +

        // 核心重點 takeaway
        (l.takeaway ?
          '<div class="fut-takeaway-box">' +
            '<div class="takeaway-title">📌 本課一句話核心結論</div>' +
            '<p>' + FUT.esc(l.takeaway) + '</p>' +
          '</div>' : '') +

        // 原生 SVG 圖解
        (diagramHtml ?
          '<div class="fut-diagram-container">' +
            '<div class="diagram-caption">📐 核心機制圖解：' + FUT.esc(l.diagram_title || l.title) + '</div>' +
            diagramHtml +
          '</div>' : '') +

        // 白話比喻 plain
        (l.plain ?
          '<div class="fut-metaphor-box">' +
            '<div class="metaphor-title">🧒 白話比喻</div>' +
            '<p>' + FUT.esc(l.plain) + '</p>' +
          '</div>' : '') +

        // 課文主體
        '<div class="fut-lesson-body">' + sectionsHtml + '</div>' +

        // 常見盲點對比 pitfall
        (l.pitfall ?
          '<div class="fut-misconception-card">' +
            '<h4>⚠️ 常見新手盲點 vs 專業市場實務</h4>' +
            '<div class="misconception-grid">' +
              '<div class="m-row">' +
                '<div class="m-wrong"><span class="m-tag tag-wrong">❌ 常見迷思</span>' + FUT.esc(l.pitfall.bad) + '</div>' +
                '<div class="m-right"><span class="m-tag tag-right">✅ 市場真相</span>' + FUT.esc(l.pitfall.good) + '</div>' +
              '</div>' +
            '</div>' +
          '</div>' : '') +

        termsHtml +
        quizHtml +

        // 頁尾標記已讀按鈕與前/後課導覽
        '<div class="fut-reader-footer">' +
          '<div class="fut-nav-prev-next">' +
            (prevL ? '<button class="fut-btn btn-pn" id="btnPrevLesson">&larr; 上一課：' + FUT.esc(prevL.title) + '</button>' : '<div></div>') +
            (nextL ? '<button class="fut-btn btn-pn" id="btnNextLesson">下一課：' + FUT.esc(nextL.title) + ' &rarr;</button>' : '<div></div>') +
          '</div>' +
          '<button id="btnToggleDone" class="fut-btn ' + (isDone ? 'btn-done' : 'btn-primary') + '" style="margin-top:14px; width:100%;">' +
            (isDone ? '✅ 已研讀完成（點擊重設）' : '✨ 標記本課已研讀完成') +
          '</button>' +
        '</div>' +
      '</div>';

    // 返回專章
    var backBtn = document.getElementById('btnBackTrack');
    if (backBtn) backBtn.onclick = function () { FUT.go('learn/' + (l.track || 'basics')); };

    // 上一課／下一課
    var prevBtn = document.getElementById('btnPrevLesson');
    if (prevBtn && prevL) prevBtn.onclick = function () { FUT.go('lesson/' + prevL.id); };
    var nextBtn = document.getElementById('btnNextLesson');
    if (nextBtn && nextL) nextBtn.onclick = function () { FUT.go('lesson/' + nextL.id); };

    // 標記已讀
    var doneBtn = document.getElementById('btnToggleDone');
    if (doneBtn) {
      doneBtn.onclick = function () {
        var next = !FUT.progress.isDone(l.id);
        FUT.progress.setDone(l.id, next);
        FUT.toast(next ? '🎉 已標記完成本課！' : '已重設研讀狀態');
        renderLessonReader(el, lessonId);
      };
    }

    // 隨堂測驗互動
    var answeredCount = 0;
    var correctCount = 0;
    FUT.$$('.fut-quiz-item', el).forEach(function (qBox) {
      var qIdx = Number(qBox.getAttribute('data-qidx'));
      var q = quizItems[qIdx];
      var correctAns = (q.ans != null) ? q.ans : (q.answer != null ? q.answer : 0);
      var expText = q.exp || q.explanation || '';
      var resBox = qBox.querySelector('.q-result');

      FUT.$$('.q-opt-btn', qBox).forEach(function (btn) {
        btn.onclick = function () {
          var oIdx = Number(btn.getAttribute('data-oidx'));
          var isCorrect = (oIdx === correctAns);
          FUT.$$('.q-opt-btn', qBox).forEach(function (b) { b.disabled = true; });
          btn.classList.add(isCorrect ? 'opt-correct' : 'opt-wrong');
          resBox.style.display = 'block';
          resBox.className = 'q-result ' + (isCorrect ? 'c-up' : 'c-down');
          resBox.innerHTML = (isCorrect ? '🎉 答對了！' : '❌ 答錯了。正確答案為 (' + String.fromCharCode(65 + correctAns) + ')') +
            (expText ? '<p class="q-explain">' + FUT.esc(expText) + '</p>' : '');

          answeredCount++;
          if (isCorrect) correctCount++;
          if (answeredCount === quizItems.length) {
            var score = Math.round((correctCount / quizItems.length) * 100);
            FUT.progress.setQuiz(l.id, score);
            if (score >= 60 && !FUT.progress.isDone(l.id)) {
              FUT.progress.setDone(l.id, true);
              FUT.toast('🏆 測驗及格 (' + score + '分)，已自動標記完課！');
            }
          }
        };
      });
    });
  }

})();