/* 期貨學院行情服務 — 封裝快照資料、正規化商品欄位、伺服器排程更新與 Live PAXG 即時連線 */
(function () {
  'use strict';
  var FUT = window.FUT = window.FUT || {};

  var state = {
    data: window.FUT_PRICES || {
      updatedAt: new Date().toISOString(),
      commodities: [],
      ratios: {},
      taifex_margins: {}
    },
    liveGold: null, // { price: number, ts: number, source: string }
    status: 'snapshot',
    listeners: []
  };

  // 統一正規化每筆商品物件，同時相容 id/symbol, cat/category, exch/exchange, p/price, chg/change, pct/change_pct
  function normalizeItem(c) {
    if (!c) return null;
    var sym = c.id || c.symbol || '';
    var cat = c.cat || c.category || '';
    var exch = c.exch || c.exchange || '';
    var p = (c.p != null) ? Number(c.p) : ((c.price != null) ? Number(c.price) : 0);
    var chg = (c.chg != null) ? Number(c.chg) : ((c.change != null) ? Number(c.change) : 0);
    var pct = (c.pct != null) ? Number(c.pct) : ((c.change_pct != null) ? Number(c.change_pct) : 0);
    var unit = c.unit || '';

    var item = Object.assign({}, c, {
      id: sym,
      symbol: sym,
      cat: cat,
      category: cat,
      exch: exch,
      exchange: exch,
      p: p,
      price: p,
      chg: chg,
      change: chg,
      pct: pct,
      change_pct: pct,
      unit: unit,
      sparkline: c.sparkline || []
    });

    if (sym === 'GC' && state.liveGold) {
      item.orig_price = p;
      item.p = state.liveGold.price;
      item.price = state.liveGold.price;
      item.is_live = true;
      item.live_source = state.liveGold.source;
    }
    return item;
  }

  var prices = (FUT.prices = {
    init: function () {
      if (window.FUT_PRICES && window.FUT_PRICES.commodities) {
        state.data = window.FUT_PRICES;
      }
      if (!FUT.isStatic()) {
        prices.fetchServer();
      }
      prices.fetchLiveGold();
    },

    getData: function () {
      return state.data;
    },

    getAll: function () {
      var raw = state.data.commodities || [];
      var list = [];
      if (Array.isArray(raw)) {
        list = raw.map(normalizeItem);
      } else if (raw && typeof raw === 'object') {
        Object.keys(raw).forEach(function (k) {
          list.push(normalizeItem(raw[k]));
        });
      }
      return list;
    },

    get: function (id) {
      if (!id) return null;
      var target = String(id).toUpperCase();
      var all = prices.getAll();
      for (var i = 0; i < all.length; i++) {
        if (all[i] && all[i].id && all[i].id.toUpperCase() === target) {
          return all[i];
        }
      }
      return null;
    },

    getByCategory: function (cat) {
      var all = prices.getAll();
      if (!cat || cat === 'all') return all;
      return all.filter(function (it) {
        return it.cat === cat || it.category === cat;
      });
    },

    getRatios: function () {
      var r = Object.assign({}, state.data.ratios || {});
      if (state.liveGold) {
        var gc = state.liveGold.price;
        var si = prices.get('SI');
        var cl = prices.get('CL');
        if (si && si.price > 0) r.gold_silver_ratio = Number((gc / si.price).toFixed(2));
        if (cl && cl.price > 0) r.gold_oil_ratio = Number((gc / cl.price).toFixed(2));
      }
      return r;
    },

    getMargins: function () {
      return state.data.taifex_margins || {};
    },

    getStatusText: function () {
      if (state.liveGold) {
        return {
          cls: 'live',
          icon: '🟢',
          text: '黃金即時連線 (' + state.liveGold.source + ') / 其它排程快照'
        };
      }
      var dt = state.data.updatedAt || state.data.generated_at || '最新';
      return {
        cls: 'snapshot',
        icon: '🕒',
        text: '排程行情快照 (' + (dt.indexOf('T') >= 0 ? dt.slice(0, 16).replace('T', ' ') : dt) + ')'
      };
    },

    subscribe: function (fn) {
      if (typeof fn === 'function') state.listeners.push(fn);
    },

    notify: function () {
      state.listeners.forEach(function (fn) {
        try { fn(state.data); } catch (e) { /* ignore */ }
      });
    },

    fetchServer: function () {
      if (FUT.isStatic()) return;
      var url = FUT.apiBase() + 'prices';
      fetch(url)
        .then(function (res) { return res.json(); })
        .then(function (json) {
          if (json && json.ok && json.data && json.data.commodities) {
            state.data = json.data;
            prices.notify();
          }
        })
        .catch(function () { /* 靜默使用本地快照 */ });
    },

    refreshServer: function (callback) {
      if (FUT.isStatic()) {
        if (callback) callback(false, '靜態部署環境不支援伺服器端爬蟲重新整理');
        return;
      }
      var url = FUT.apiBase() + 'prices/refresh';
      fetch(url, { method: 'POST' })
        .then(function (res) { return res.json(); })
        .then(function (json) {
          if (json && json.ok && json.data) {
            state.data = json.data;
            prices.notify();
            if (callback) callback(true, '行情已更新！');
          } else {
            if (callback) callback(false, (json && json.error) || '伺服器更新受頻率限制');
          }
        })
        .catch(function (err) {
          if (callback) callback(false, '連線異常：' + (err.message || err));
        });
    },

    fetchLiveGold: function () {
      var binanceUrl = 'https://api.binance.com/api/v3/ticker/price?symbol=PAXGUSDT';
      fetch(binanceUrl, { mode: 'cors' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data && data.price) {
            var p = parseFloat(data.price);
            if (p > 500 && p < 10000) {
              state.liveGold = { price: p, ts: Date.now(), source: 'Binance PAXG' };
              prices.notify();
              return;
            }
          }
          prices._fallbackCoingecko();
        })
        .catch(function () {
          prices._fallbackCoingecko();
        });
    },

    _fallbackCoingecko: function () {
      var cgUrl = 'https://api.coingecko.com/api/v3/simple/price?ids=pax-gold&vs_currencies=usd';
      fetch(cgUrl, { mode: 'cors' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data && data['pax-gold'] && data['pax-gold'].usd) {
            var p = parseFloat(data['pax-gold'].usd);
            if (p > 500 && p < 10000) {
              state.liveGold = { price: p, ts: Date.now(), source: 'CoinGecko PAXG' };
              prices.notify();
            }
          }
        })
        .catch(function () { /* 靜默使用快照 */ });
    }
  });

})();