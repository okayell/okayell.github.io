"""Configuration paths for 期貨學院 (Futures Academy)."""

from __future__ import annotations

import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
PRICES_JSON = os.path.join(DATA_DIR, 'prices.json')
DB_PATH = PRICES_JSON
DEFAULT_PORT = 8964
