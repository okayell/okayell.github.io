#!/usr/bin/env python3
"""Builds standalone single-file HTML & offline ZIP for 區塊鏈學院 (Blockchain Academy)."""

from __future__ import annotations

import base64
import os
import re
import subprocess
import sys
import zipfile

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')
SINGLE_HTML = os.path.join(DIST_DIR, 'crypto_academy_single.html')
OUT_HTML = SINGLE_HTML
OFFLINE_ZIP = os.path.join(DIST_DIR, 'crypto_academy_offline.zip')

sys.path.insert(0, ROOT_DIR)
try:
  from tools import release_mgr  # noqa: E402
except ImportError:
  release_mgr = None  # type: ignore[assignment]
try:
  from tools import update_prices  # noqa: E402
except ImportError:
  update_prices = None  # type: ignore[assignment]

# Base64-encoded forbidden tokens so this file itself stays clean under raw bundle leak scans
_FORBIDDEN_B64 = (
    'Z29vZ2xlcnMuY29t',
    'Y29ycC5nb29nbGUuY29t',
    'Z29vZ2xlcGxleA==',
    'aHVhbmd5aWNoYW8=',
    'L2dvb2dsZS9zcmMv',
    'QGdvb2dsZS5jb20=',
)
FORBIDDEN_PATTERNS = [base64.b64decode(t).decode('utf-8') for t in _FORBIDDEN_B64]


class BuildError(RuntimeError):
  pass


def check_no_internal_leaks(text: str, label: str) -> None:
  lower = text.lower()
  for pat in FORBIDDEN_PATTERNS:
    if pat in lower:
      raise BuildError(f'[SECURITY LEAK BLOCKED] Found forbidden pattern "{pat}" in {label}!')


def run_content_checks() -> None:
  """Runs the Node content validator when Node is available (skipped on runners without it)."""
  validator = os.path.join(ROOT_DIR, 'tools', 'validate_content.js')
  if not os.path.isfile(validator):
    return
  try:
    proc = subprocess.run(['node', validator, '--need-all'], capture_output=True, text=True, timeout=60, check=False)
  except (OSError, subprocess.TimeoutExpired):
    return
  if proc.returncode != 0:
    tail = '\n'.join((proc.stdout or proc.stderr).strip().splitlines()[-15:])
    raise BuildError('內容驗證未通過（node tools/validate_content.js --need-all）：\n' + tail)


def check_index_loads_all_content(html: str) -> None:
  content_dir = os.path.join(STATIC_DIR, 'js', 'content')
  missing = [
      fn for fn in sorted(os.listdir(content_dir))
      if fn.endswith('.js') and f'js/content/{fn}' not in html
  ]
  if missing:
    raise BuildError(f'static/index.html 沒有載入內容檔：{missing}')


def build_single_html(check_content: bool = True) -> str:
  if release_mgr is not None:
    release_mgr.ensure_initialized()
  if update_prices is not None:
    update_prices.write_js_from_json()
  if check_content:
    run_content_checks()
  index_path = os.path.join(STATIC_DIR, 'index.html')
  with open(index_path, 'r', encoding='utf-8') as f:
    html = f.read()
  check_index_loads_all_content(html)

  def replace_css(match: re.Match[str]) -> str:
    href = match.group(1).split('?')[0]
    with open(os.path.join(STATIC_DIR, href.lstrip('/')), 'r', encoding='utf-8') as cf:
      return f'<style>\n{cf.read()}\n</style>'

  html = re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>', replace_css, html)

  def replace_js(match: re.Match[str]) -> str:
    src = match.group(1).split('?')[0]
    with open(os.path.join(STATIC_DIR, src.lstrip('/')), 'r', encoding='utf-8') as jf:
      js_content = jf.read()
    safe_js = js_content.replace('</script', '<\\/script').replace('<!--', '<\\!--')
    return f'<script>\n{safe_js}\n</script>'

  html = re.sub(r'<script\s+src="([^"]+)"></script>', replace_js, html)
  html = html.replace('<head>', '<head>\n<script>window.CRY_STATIC_ONLY = true;</script>', 1)

  check_no_internal_leaks(html, 'crypto_academy_single.html')
  os.makedirs(DIST_DIR, exist_ok=True)
  tmp = SINGLE_HTML + '.tmp'
  with open(tmp, 'w', encoding='utf-8') as out:
    out.write(html)
  os.replace(tmp, SINGLE_HTML)
  return SINGLE_HTML


def build_offline_zip() -> str:
  single_path = build_single_html()
  readme = (
      '🪙 區塊鏈學院 (Blockchain Academy) — 離線完整學習包\n'
      '======================================================\n\n'
      '【使用方式】\n'
      '1. 直接雙擊打開「區塊鏈學院_單一完整版.html」即可在任何瀏覽器（電腦／手機／平板）使用。\n'
      '2. 內含完整課程、幣種圖鑑、幣圈歷史故事、名詞辭典與測驗；幣價為打包當下的快照，連上網路時會自動更新為即時報價。\n'
      '3. 學習進度與自選幣會自動保存在本機瀏覽器中。\n'
      '4. 本站內容僅供教學，不構成任何投資建議。\n'
  )
  os.makedirs(DIST_DIR, exist_ok=True)
  with zipfile.ZipFile(OFFLINE_ZIP, 'w', zipfile.ZIP_DEFLATED) as zf:
    zf.write(single_path, arcname='區塊鏈學院_單一完整版.html')
    zf.writestr('使用說明_README.txt', readme)
  return OFFLINE_ZIP


def build(force: bool = False) -> str:
  del force
  return build_single_html()


def build_all() -> str:
  return build_single_html()


if __name__ == '__main__':
  try:
    s_path = build_single_html()
    z_path = build_offline_zip()
  except BuildError as e:
    print(f'BUILD FAILED: {e}')
    sys.exit(1)
  print(f'Built single HTML: {s_path} ({os.path.getsize(s_path):,} bytes)')
  print(f'Built offline ZIP: {z_path} ({os.path.getsize(z_path):,} bytes)')
