#!/usr/bin/env python3
"""區塊鏈學院 — 幣價快照更新器（排程與 GitHub Actions 共用，零相依）。

資料來源（依優先序，前一個失敗才用下一個）：
  1. CoinGecko   /coins/markets（市值前 250、7 日走勢、1h/24h/7d/30d 漲跌）＋ /global ＋ /coins/{id}/market_chart（近一年日線）
  2. CoinPaprika /tickers（備援：沒有走勢圖）
  3. CoinLore    /api/tickers（第二備援）
  恐懼與貪婪指數：alternative.me /fng

防呆：抓到的幣數 < max(20, 上一版 × 60%) 時保留上一版並印出 GUARD:，永遠不寫出空清單。
輸出：data/prices.json 與 static/js/content/prices_data.js（window.CRY_PRICES）。
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import glob
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, 'data')
PRICES_JSON = os.path.join(DATA_DIR, 'prices.json')
CONTENT_DIR = os.path.join(ROOT_DIR, 'static', 'js', 'content')
PRICES_JS = os.path.join(CONTENT_DIR, 'prices_data.js')

TZ_TW = timezone(timedelta(hours=8))
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'
CG = 'https://api.coingecko.com/api/v3'

TOP_N = 250  # 來源一次給 250 個；全部收錄，不另外截斷
SPARK_POINTS = 42  # 7 日走勢降採樣點數（每 4 小時一點）
CHART_IDS = ('bitcoin', 'ethereum', 'solana', 'binancecoin', 'ripple', 'dogecoin')
CHART_MAX_AGE_SEC = 6 * 3600  # 日線圖 6 小時才重抓一次，減少請求數
CHARTS_PER_RUN = 2
MIN_COINS = 20
STALE_HOURS = 6  # 快照超過這個時數視為過期（排程週期 10 分鐘 + 充足緩衝）

FNG_LABELS = {
    'Extreme Fear': '極度恐懼', 'Fear': '恐懼', 'Neutral': '中性', 'Greed': '貪婪', 'Extreme Greed': '極度貪婪',
}


def now_tw() -> datetime:
  return datetime.now(TZ_TW)


def _get_json(url: str, timeout: float = 12.0, retries: int = 2, backoff: float = 2.5):
  """GET JSON with a browser UA; retries on 429/5xx with exponential backoff."""
  last: Exception | None = None
  for attempt in range(retries + 1):
    try:
      req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'application/json'})
      with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
      last = e
      if e.code not in (429, 500, 502, 503, 504):
        break
    except Exception as e:  # pylint: disable=broad-except
      last = e
    if attempt < retries:
      time.sleep(backoff * (2 ** attempt))
  raise RuntimeError(f'{url.split("?")[0]} → {last}')


def _num(v, digits: int | None = None):
  try:
    f = float(v)
  except (TypeError, ValueError):
    return None
  if f != f or f in (float('inf'), float('-inf')):
    return None
  if digits is None:
    return f
  if digits == 0:
    return int(round(f))
  return round(f, digits)


def _price_round(p):
  """Keeps ~6 significant digits so tiny-priced coins (SHIB, PEPE) stay precise."""
  f = _num(p)
  if f is None:
    return None
  if f == 0:
    return 0
  a = abs(f)
  if a >= 1000:
    return round(f, 2)
  if a >= 1:
    return round(f, 4)
  digits = 6
  while a < 0.1 and digits < 14:
    a *= 10
    digits += 1
  return round(f, digits)


def _downsample(arr: list, n: int) -> list:
  vals = [x for x in (arr or []) if isinstance(x, (int, float))]
  if len(vals) <= n:
    return [_price_round(x) for x in vals]
  step = (len(vals) - 1) / (n - 1)
  return [_price_round(vals[min(len(vals) - 1, round(i * step))]) for i in range(n)]


def curated_ids() -> list[str]:
  """CoinGecko ids used by the 幣種圖鑑 (static/js/content/coins_*.js)."""
  ids: list[str] = []
  for fp in sorted(glob.glob(os.path.join(CONTENT_DIR, 'coins_*.js'))):
    try:
      with open(fp, 'r', encoding='utf-8') as f:
        src = f.read()
    except OSError:
      continue
    for m in re.finditer(r"COINS\.push\(\{\s*id:\s*['\"]([a-z0-9-]+)['\"]", src):
      if m.group(1) not in ids:
        ids.append(m.group(1))
  return ids


def _cg_row(x: dict) -> dict:
  img = str(x.get('image') or '')
  img = re.sub(r'/large/', '/small/', img).split('?')[0]
  return {
      'id': x.get('id'),
      'sym': str(x.get('symbol') or '').upper(),
      'name': x.get('name'),
      'img': img,
      'rank': x.get('market_cap_rank'),
      'p': _price_round(x.get('current_price')),
      'c1h': _num(x.get('price_change_percentage_1h_in_currency'), 2),
      'c24h': _num(x.get('price_change_percentage_24h_in_currency', x.get('price_change_percentage_24h')), 2),
      'c7d': _num(x.get('price_change_percentage_7d_in_currency'), 2),
      'c30d': _num(x.get('price_change_percentage_30d_in_currency'), 2),
      'mc': _num(x.get('market_cap'), 0),
      'fdv': _num(x.get('fully_diluted_valuation'), 0),
      'vol': _num(x.get('total_volume'), 0),
      'hi': _price_round(x.get('high_24h')),
      'lo': _price_round(x.get('low_24h')),
      'ath': _price_round(x.get('ath')),
      'athDate': str(x.get('ath_date') or '')[:10],
      'athChg': _num(x.get('ath_change_percentage'), 1),
      'circ': _num(x.get('circulating_supply'), 0),
      'max': _num(x.get('max_supply'), 0),
      'spark': _downsample(((x.get('sparkline_in_7d') or {}).get('price') or []), SPARK_POINTS),
  }


def fetch_coingecko(extra_ids: list[str]) -> tuple[list[dict], dict]:
  """Returns (coins, global) from CoinGecko. Raises on failure."""
  q = '&sparkline=true&price_change_percentage=1h,24h,7d,30d'
  rows = _get_json(f'{CG}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page={TOP_N}&page=1{q}', timeout=20)
  if not isinstance(rows, list) or not rows:
    raise RuntimeError('coingecko markets returned no rows')
  coins = [_cg_row(x) for x in rows if x.get('id') and x.get('current_price') is not None]
  have = {c['id'] for c in coins}
  missing = [i for i in extra_ids if i not in have]
  if missing:
    # 圖鑑收錄但跌出前 250 名的幣，另外用 ids= 補抓（單一請求）
    try:
      time.sleep(1.5)
      more = _get_json(f'{CG}/coins/markets?vs_currency=usd&ids={",".join(missing)}{q}', timeout=15)
      coins.extend(_cg_row(x) for x in more if x.get('id') and x.get('current_price') is not None)
    except Exception as e:  # pylint: disable=broad-except
      print(f'WARN extra ids fetch failed: {e}')
  glob_out: dict = {}
  try:
    time.sleep(1.2)
    g = (_get_json(f'{CG}/global', timeout=12) or {}).get('data') or {}
    mc = g.get('total_market_cap') or {}
    usd = _num(mc.get('usd'))
    twd = _num(mc.get('twd'))
    glob_out = {
        'mcap': _num(usd, 0),
        'vol': _num((g.get('total_volume') or {}).get('usd'), 0),
        'btcDom': _num((g.get('market_cap_percentage') or {}).get('btc'), 2),
        'ethDom': _num((g.get('market_cap_percentage') or {}).get('eth'), 2),
        'mcapChg24h': _num(g.get('market_cap_change_percentage_24h_usd'), 2),
        'active': g.get('active_cryptocurrencies'),
        'twdRate': round(twd / usd, 4) if usd and twd else None,
    }
  except Exception as e:  # pylint: disable=broad-except
    print(f'WARN coingecko global failed: {e}')
  return coins, glob_out


def fetch_coinpaprika() -> list[dict]:
  rows = _get_json('https://api.coinpaprika.com/v1/tickers?quotes=USD&limit=250', timeout=20)
  out = []
  for x in rows or []:
    q = (x.get('quotes') or {}).get('USD') or {}
    if q.get('price') is None:
      continue
    out.append({
        'id': str(x.get('id') or '').split('-', 1)[-1], 'sym': x.get('symbol'), 'name': x.get('name'), 'img': '',
        'rank': x.get('rank'), 'p': _price_round(q.get('price')),
        'c1h': _num(q.get('percent_change_1h'), 2), 'c24h': _num(q.get('percent_change_24h'), 2),
        'c7d': _num(q.get('percent_change_7d'), 2), 'c30d': _num(q.get('percent_change_30d'), 2),
        'mc': _num(q.get('market_cap'), 0), 'fdv': None, 'vol': _num(q.get('volume_24h'), 0),
        'hi': None, 'lo': None, 'ath': _price_round(q.get('ath_price')), 'athDate': str(q.get('ath_date') or '')[:10],
        'athChg': _num(q.get('percent_from_price_ath'), 1), 'circ': _num(x.get('total_supply'), 0),
        'max': _num(x.get('max_supply'), 0), 'spark': [],
    })
  return out


def fetch_coinlore() -> list[dict]:
  out = []
  for start in (0, 100):
    rows = (_get_json(f'https://api.coinlore.net/api/tickers/?start={start}&limit=100', timeout=15) or {}).get('data') or []
    for x in rows:
      if x.get('price_usd') in (None, ''):
        continue
      out.append({
          'id': x.get('nameid'), 'sym': x.get('symbol'), 'name': x.get('name'), 'img': '', 'rank': x.get('rank'),
          'p': _price_round(x.get('price_usd')), 'c1h': _num(x.get('percent_change_1h'), 2),
          'c24h': _num(x.get('percent_change_24h'), 2), 'c7d': _num(x.get('percent_change_7d'), 2), 'c30d': None,
          'mc': _num(x.get('market_cap_usd'), 0), 'fdv': None, 'vol': _num(x.get('volume24'), 0), 'hi': None, 'lo': None,
          'ath': None, 'athDate': '', 'athChg': None, 'circ': _num(x.get('csupply'), 0), 'max': _num(x.get('msupply'), 0),
          'spark': [],
      })
  return out


def fetch_fng() -> dict:
  d = (_get_json('https://api.alternative.me/fng/?limit=30', timeout=10) or {}).get('data') or []
  hist = []
  for x in d:
    try:
      day = datetime.fromtimestamp(int(x['timestamp']), timezone.utc).strftime('%Y-%m-%d')
      hist.append({'d': day, 'v': int(x['value'])})
    except (KeyError, TypeError, ValueError):
      continue
  if not hist:
    raise RuntimeError('fng empty')
  label_en = str(d[0].get('value_classification') or '')
  return {'value': hist[0]['v'], 'label': FNG_LABELS.get(label_en, label_en), 'history': list(reversed(hist))}


def fetch_chart(coin_id: str) -> dict:
  d = _get_json(f'{CG}/coins/{coin_id}/market_chart?vs_currency=usd&days=365&interval=daily', timeout=15, retries=1, backoff=6)
  pts = [p for p in (d.get('prices') or []) if isinstance(p, list) and len(p) == 2 and p[1] is not None]
  if len(pts) < 100:
    raise RuntimeError(f'chart {coin_id}: only {len(pts)} points')
  return {'t0': int(pts[0][0] // 1000), 't1': int(pts[-1][0] // 1000), 'ts': int(time.time()),
          'p': [_price_round(p[1]) for p in pts]}


def load_previous() -> dict:
  try:
    with open(PRICES_JSON, 'r', encoding='utf-8') as f:
      d = json.load(f)
    return d if isinstance(d, dict) else {}
  except (OSError, ValueError):
    return {}


def validate_payload(payload: dict, curated: list[str] | None = None, now_ts: float | None = None) -> tuple[list[str], list[str]]:
  """Pure data-quality rules shared by the updater guard and tools/check_prices.py. Returns (errors, warns)."""
  errs: list[str] = []
  warns: list[str] = []
  coins = payload.get('coins') if isinstance(payload, dict) else None
  if not isinstance(coins, list) or not coins:
    return ['coins 清單是空的'], warns
  if len(coins) < MIN_COINS:
    errs.append(f'幣數只有 {len(coins)}，低於下限 {MIN_COINS}')
  ids = [c.get('id') for c in coins]
  dups = sorted({i for i in ids if ids.count(i) > 1})
  if dups:
    errs.append(f'id 重複：{dups[:5]}')
  bad_price = [c.get('id') for c in coins if not isinstance(c.get('p'), (int, float)) or c['p'] <= 0]
  if bad_price:
    errs.append(f'{len(bad_price)} 個幣價格缺漏或 ≤ 0：{bad_price[:5]}')
  for key in ('sym', 'name'):
    miss = [c.get('id') for c in coins if not c.get(key)]
    if miss:
      errs.append(f'{len(miss)} 個幣缺少 {key}：{miss[:5]}')
  by_id = {c.get('id'): c for c in coins}
  btc = by_id.get('bitcoin')
  eth = by_id.get('ethereum')
  if not btc or not eth:
    errs.append('缺少 bitcoin 或 ethereum')
  else:
    if not 1000 < btc['p'] < 10_000_000:
      errs.append(f'bitcoin 價格不合理：{btc["p"]}')
    if not eth['p'] < btc['p']:
      errs.append('ethereum 價格高於 bitcoin，資料疑似錯位')
  for sid in ('tether', 'usd-coin'):
    s = by_id.get(sid)
    if s and not 0.9 < s['p'] < 1.1:
      warns.append(f'穩定幣 {sid} 價格偏離 1 美元：{s["p"]}')
  wild = [c.get('id') for c in coins if isinstance(c.get('c24h'), (int, float)) and abs(c['c24h']) > 95]
  if len(wild) > max(5, len(coins) // 10):
    errs.append(f'{len(wild)} 個幣 24 小時漲跌幅超過 95%，資料疑似異常')
  if payload.get('source') == 'coingecko':
    no_spark = [c.get('id') for c in coins[:50] if len(c.get('spark') or []) < 10]
    if len(no_spark) > 10:
      warns.append(f'前 50 名有 {len(no_spark)} 個幣沒有 7 日走勢')
  rate = payload.get('twdRate')
  if not isinstance(rate, (int, float)) or not 20 < rate < 50:
    errs.append(f'美元兌新台幣匯率不合理：{rate}')
  g = payload.get('global') or {}
  if not g.get('mcap'):
    warns.append('缺少全球總市值')
  elif not 0 < (g.get('btcDom') or 0) < 100:
    warns.append(f'BTC 市占不合理：{g.get("btcDom")}')
  fng = payload.get('fng') or {}
  if not isinstance(fng.get('value'), int) or not 0 <= fng['value'] <= 100:
    warns.append('缺少恐懼與貪婪指數')
  charts = payload.get('charts') or {}
  if 'bitcoin' not in charts or len((charts.get('bitcoin') or {}).get('p') or []) < 100:
    warns.append('缺少 bitcoin 近一年日線')
  if curated:
    missing = [i for i in curated if i not in by_id]
    cover = 1 - len(missing) / len(curated)
    if cover < 0.9:
      errs.append(f'圖鑑幣種報價涵蓋率 {cover:.0%} < 90%，缺：{missing[:8]}')
    elif missing:
      warns.append(f'圖鑑幣種缺報價：{missing}')
  ts = payload.get('updatedTs')
  if not isinstance(ts, (int, float)):
    errs.append('缺少 updatedTs')
  elif now_ts is not None:
    age_h = (now_ts - ts) / 3600
    if age_h > STALE_HOURS:
      errs.append(f'快照已 {age_h:.1f} 小時未更新（上限 {STALE_HOURS} 小時）')
    elif age_h < -0.2:
      errs.append('updatedTs 在未來')
  return errs, warns


def write_payload(payload: dict) -> None:
  os.makedirs(DATA_DIR, exist_ok=True)
  os.makedirs(CONTENT_DIR, exist_ok=True)
  raw = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
  for path, text in (
      (PRICES_JSON, raw),
      (PRICES_JS, '/* Auto-generated by tools/update_prices.py — 幣價快照，排程自動更新，請勿手改 */\nwindow.CRY_PRICES = ' + raw + ';\n'),
  ):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
      f.write(text)
    os.replace(tmp, path)


def write_js_from_json() -> bool:
  """Regenerates prices_data.js from data/prices.json (used by build_dist on CI)."""
  prev = load_previous()
  if not prev.get('coins'):
    return False
  write_payload(prev)
  return True


def update_prices(force_charts: bool = False) -> dict:
  """Fetches a fresh snapshot, guards against bad data, writes JSON + JS. Returns the payload in effect."""
  prev = load_previous()
  curated = curated_ids()
  t0 = time.time()
  source = ''
  coins: list[dict] = []
  glob_info: dict = {}
  errors: list[str] = []
  with ThreadPoolExecutor(max_workers=2) as pool:
    fng_future = pool.submit(fetch_fng)
    for name, fn in (('coingecko', lambda: fetch_coingecko(curated)), ('coinpaprika', fetch_coinpaprika), ('coinlore', fetch_coinlore)):
      try:
        res = fn()
        coins, glob_info = res if isinstance(res, tuple) else (res, {})
        if len(coins) >= MIN_COINS:
          source = name
          break
        errors.append(f'{name}: only {len(coins)} coins')
      except Exception as e:  # pylint: disable=broad-except
        errors.append(f'{name}: {e}')
    try:
      fng = fng_future.result(timeout=30)
    except Exception as e:  # pylint: disable=broad-except
      errors.append(f'fng: {e}')
      fng = prev.get('fng') or {}

  prev_n = len(prev.get('coins') or [])
  floor = max(MIN_COINS, int(prev_n * 0.6))
  if len(coins) < floor:
    print(f'GUARD: 只抓到 {len(coins)} 個幣（下限 {floor}），保留上一版（{prev.get("updatedAt", "無")}）；錯誤：{errors}')
    if prev.get('coins'):
      write_payload(prev)
    return prev

  coins.sort(key=lambda c: (c.get('rank') is None, c.get('rank') or 10 ** 9, -(c.get('mc') or 0)))
  if not glob_info.get('twdRate'):
    glob_info['twdRate'] = (prev.get('twdRate') or (prev.get('global') or {}).get('twdRate'))
  if not glob_info.get('mcap') and prev.get('global'):
    glob_info = {**prev['global'], **{k: v for k, v in glob_info.items() if v is not None}}

  # 近一年日線：每個幣 6 小時才重抓一次、每輪最多抓 CHARTS_PER_RUN 個（免費 API 連續請求會被限流）；失敗就沿用舊圖
  charts = dict(prev.get('charts') or {})
  if source == 'coingecko':
    due = [
        cid for cid in CHART_IDS
        if force_charts or cid not in charts or time.time() - (charts[cid].get('ts') or 0) > CHART_MAX_AGE_SEC
    ]
    for cid in due[:len(CHART_IDS) if force_charts else CHARTS_PER_RUN]:
      try:
        time.sleep(5 if force_charts else 3)
        charts[cid] = fetch_chart(cid)
      except Exception as e:  # pylint: disable=broad-except
        errors.append(f'chart {cid}: {e}')
        break  # 被限流就留到下一輪，不要拖慢這一輪
  charts_ts = max([c.get('ts') or 0 for c in charts.values()] or [0])

  now = now_tw()
  payload = {
      'updatedAt': now.strftime('%Y-%m-%d %H:%M:%S'),
      'updatedTs': int(now.timestamp()),
      'source': source,
      'twdRate': glob_info.pop('twdRate', None),
      'global': glob_info,
      'fng': fng,
      'coins': coins,
      'count': len(coins),
      'charts': charts,
      'chartsTs': charts_ts,
      'fetchErrors': errors[:6],
      'tookSec': round(time.time() - t0, 1),
  }
  errs, _ = validate_payload(payload, curated)
  if errs and prev.get('coins'):
    print(f'GUARD: 新快照未通過檢查，保留上一版（{prev.get("updatedAt")}）：{errs}')
    write_payload(prev)
    return prev
  write_payload(payload)
  return payload


def main() -> int:
  ap = argparse.ArgumentParser(description='區塊鏈學院幣價快照更新')
  ap.add_argument('--force-charts', action='store_true', help='強制重抓近一年日線')
  args = ap.parse_args()
  p = update_prices(force_charts=args.force_charts)
  btc = next((c for c in p.get('coins') or [] if c.get('id') == 'bitcoin'), {})
  print(f'prices: {p.get("count", 0)} coins via {p.get("source")} @ {p.get("updatedAt")} | BTC ${btc.get("p")} | '
        f'USD/TWD {p.get("twdRate")} | charts {sorted((p.get("charts") or {}).keys())} | errors {p.get("fetchErrors")}')
  return 0 if p.get('coins') else 1


if __name__ == '__main__':
  sys.exit(main())
