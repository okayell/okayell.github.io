/* 區塊鏈學院 — 首頁與即時幣價頁 */
(function () {
  'use strict';
  var CRY = window.CRY, P = CRY.Prices, esc = CRY.esc;

  function statusBar(extra) {
    var cur = P.cur();
    return '<div class="cry-status">' +
      '<span class="cry-status-txt" data-live="status">' + esc(P.statusText()) + '</span>' +
      '<span class="cry-status-src">資料來源：CoinGecko、alternative.me</span>' +
      '<span class="cry-status-actions">' + (extra || '') +
        '<span class="cry-seg" role="group" aria-label="計價幣別">' +
          '<button type="button" class="' + (cur === 'usd' ? 'on' : '') + '" data-cur="usd">美元 USD</button>' +
          '<button type="button" class="' + (cur === 'twd' ? 'on' : '') + '" data-cur="twd">新台幣 TWD</button>' +
        '</span>' +
        '<button type="button" class="cry-btn" data-refresh>🔄 立即更新</button>' +
      '</span></div>';
  }
  CRY.statusBar = statusBar;

  function globalCards() {
    var d = P.data || {}, g = d.global || {}, f = d.fng || {};
    var fv = typeof f.value === 'number' ? f.value : null;
    var hist = (f.history || []).map(function (x) { return x.v; });
    return '<div class="cry-kpis">' +
      '<div class="cry-kpi"><div class="k">全球加密貨幣總市值</div><div class="v">' + P.big(g.mcap) + '</div><div class="s">24 小時 ' + CRY.pctHtml(g.mcapChg24h) + '</div></div>' +
      '<div class="cry-kpi"><div class="k">24 小時總成交量</div><div class="v">' + P.big(g.vol) + '</div><div class="s">追蹤幣種 ' + (g.active ? Number(g.active).toLocaleString('en-US') : '—') + ' 種</div></div>' +
      '<div class="cry-kpi"><div class="k">比特幣市占率</div><div class="v">' + (g.btcDom != null ? Number(g.btcDom).toFixed(1) + '%' : '—') + '</div><div class="s">以太坊 ' + (g.ethDom != null ? Number(g.ethDom).toFixed(1) + '%' : '—') + '</div></div>' +
      '<div class="cry-kpi"><div class="k">恐懼與貪婪指數</div><div class="v" style="color:' + (fv == null ? 'inherit' : P.fngColor(fv)) + '">' + (fv == null ? '—' : fv) +
        ' <small>' + esc(f.label || '') + '</small></div><div class="s">' + P.sparkSvg(hist, 96, 22, 'neutral') + ' <span class="cry-muted">近 30 天</span></div></div>' +
      '<div class="cry-kpi"><div class="k">美元兌新台幣</div><div class="v">' + (d.twdRate ? Number(d.twdRate).toFixed(2) : '—') + '</div><div class="s cry-muted">1 USDT 約等於這個金額</div></div>' +
      '</div>';
  }

  // ---------- 首頁 ----------
  function tickerCard(id) {
    var c = P.get(id);
    if (!c) return '';
    var meta = CRY.coinMap[id];
    return '<a class="cry-tick" href="#/' + (meta ? 'coin/' + encodeURIComponent(id) : 'market') + '">' +
      '<div class="cry-tick-top">' + CRY.coinAvatar(c.sym, c.img, 30) + '<div><b>' + esc(meta ? meta.name : c.name) + '</b><span>' + esc(c.sym) + '</span></div></div>' +
      '<div class="cry-tick-price">' + P.price(c.p) + '</div>' +
      '<div class="cry-tick-foot">' + CRY.pctHtml(c.c24h) + P.sparkSvg(c.spark, 84, 26) + '</div></a>';
  }

  function todayStory() {
    var H = CRY.HISTORY;
    if (!H.length) return null;
    var now = new Date(), md = ('0' + (now.getMonth() + 1)).slice(-2) + '-' + ('0' + now.getDate()).slice(-2);
    var same = H.filter(function (h) { return String(h.date).slice(5) === md; });
    if (same.length) return { h: same[0], label: '📅 歷史上的今天' };
    var day = Math.floor(Date.now() / 86400000);
    return { h: H[day % H.length], label: '📜 今日故事' };
  }

  function renderHome(root) {
    var doneAll = CRY.progress.countDone(), total = CRY.LESSONS.length;
    var next = CRY.LESSONS.filter(function (l) { return !CRY.progress.isDone(l.id); })[0];
    var ids = ['bitcoin', 'ethereum', 'tether', 'binancecoin', 'solana', 'ripple'];
    CRY.watch.list().forEach(function (id) { if (ids.indexOf(id) < 0) ids.push(id); });
    var story = todayStory();
    var tracks = CRY.TRACKS.map(function (t) {
      var ls = CRY.lessonsOf(t.id), dn = CRY.progress.countDone(t.id), pct = ls.length ? Math.round(dn * 100 / ls.length) : 0;
      return '<a class="cry-track" href="#/learn/' + t.id + '"><div class="cry-track-ic">' + t.icon + '</div><div class="cry-track-body"><b>' + esc(t.name) + '</b>' +
        '<p>' + esc(t.desc) + '</p><div class="cry-bar"><i style="width:' + pct + '%"></i></div><span class="cry-muted">' + dn + ' / ' + ls.length + ' 堂</span></div></a>';
    }).join('');
    root.innerHTML =
      '<section class="cry-hero">' +
        '<div><h1>從零看懂區塊鏈與虛擬貨幣</h1>' +
        '<p>' + total + ' 堂白話課程、' + CRY.COINS.length + ' 個幣種圖鑑、' + CRY.HISTORY.length + ' 則幣圈歷史故事、' + CRY.GLOSSARY.length + ' 個名詞，加上定時更新的即時幣價。先懂原理與風險，再看價格。</p>' +
        '<div class="cry-hero-actions">' +
          (next ? '<a class="cry-btn primary" href="#/lesson/' + next.id + '">' + (doneAll ? '▶ 繼續學習：' : '▶ 從第一堂開始：') + esc(next.title) + '</a>' : '<a class="cry-btn primary" href="#/quiz">🎓 全部課程完成，來挑戰總測驗</a>') +
          '<a class="cry-btn" href="#/market">📈 看即時幣價</a></div></div>' +
        '<div class="cry-hero-prog"><div class="cry-ring" style="--p:' + (total ? Math.round(doneAll * 100 / total) : 0) + '"><b>' + (total ? Math.round(doneAll * 100 / total) : 0) + '%</b></div><span>已完成 ' + doneAll + ' / ' + total + ' 堂</span></div>' +
      '</section>' +
      statusBar() +
      '<section><div class="cry-ticks" data-live="ticks">' + ids.map(tickerCard).join('') + '</div></section>' +
      '<section data-live="kpis">' + globalCards() + '</section>' +
      '<section><h2 class="cry-h2">🧭 學習路線</h2><div class="cry-tracks">' + tracks + '</div></section>' +
      (story ? '<section><h2 class="cry-h2">' + story.label + '</h2><a class="cry-story-card" href="#/history/' + encodeURIComponent(story.h.id) + '">' +
        '<span class="cry-date">' + esc(story.h.date) + '</span><b>' + esc(story.h.title) + '</b><p>' + esc(story.h.summary) + '</p><span class="cry-link">讀完整故事 →</span></a></section>' : '') +
      '<section class="cry-quick">' +
        '<a href="#/coins"><b>🪙 幣種圖鑑</b><span>每個幣是什麼、怎麼運作、有什麼風險</span></a>' +
        '<a href="#/history"><b>📜 幣圈歷史</b><span>從密碼龐克、披薩日到現貨 ETF</span></a>' +
        '<a href="#/glossary"><b>📖 名詞辭典</b><span>看不懂的術語，一查就懂</span></a>' +
        '<a href="#/learn/wallet"><b>🛡️ 防詐必修</b><span>助記詞、授權、常見詐騙手法</span></a>' +
      '</section>' + CRY.disclaimer();
    root._live = function () {
      var t = CRY.$('[data-live="ticks"]', root); if (t) t.innerHTML = ids.map(tickerCard).join('');
      var k = CRY.$('[data-live="kpis"]', root); if (k) k.innerHTML = globalCards();
      var s = CRY.$('[data-live="status"]', root); if (s) s.textContent = P.statusText();
    };
  }

  // ---------- 即時幣價 ----------
  var view = { q: '', filter: 'all', sort: 'rank', dir: 1, limit: 50, chartId: 'bitcoin', days: 365 };
  var COLS = [
    { k: 'rank', t: '#', cls: 'num narrow' }, { k: 'name', t: '幣種', cls: '' }, { k: 'p', t: '價格', cls: 'num' },
    { k: 'c1h', t: '1 小時', cls: 'num hide-s' }, { k: 'c24h', t: '24 小時', cls: 'num' }, { k: 'c7d', t: '7 天', cls: 'num hide-s' },
    { k: 'c30d', t: '30 天', cls: 'num hide-m' }, { k: 'mc', t: '市值', cls: 'num hide-s' }, { k: 'vol', t: '24 小時成交量', cls: 'num hide-m' },
    { k: 'spark', t: '7 日走勢', cls: 'num hide-s nosort' }
  ];

  function rows() {
    var q = view.q.trim().toLowerCase();
    var list = P.coins().filter(function (c) {
      var meta = CRY.coinMap[c.id];
      if (view.filter === 'guide' && !meta) return false;
      if (view.filter === 'watch' && !CRY.watch.has(c.id)) return false;
      if (view.filter === 'up' && !(c.c24h > 0)) return false;
      if (view.filter === 'down' && !(c.c24h < 0)) return false;
      if (!q) return true;
      return String(c.sym).toLowerCase().indexOf(q) >= 0 || String(c.name).toLowerCase().indexOf(q) >= 0 || (meta && String(meta.name).indexOf(view.q.trim()) >= 0);
    });
    var k = view.sort, dir = view.dir;
    list.sort(function (a, b) {
      var x = k === 'name' ? String(a.sym) : a[k], y = k === 'name' ? String(b.sym) : b[k];
      if (x == null && y == null) return 0;
      if (x == null) return 1;
      if (y == null) return -1;
      return (x < y ? -1 : x > y ? 1 : 0) * dir;
    });
    return list;
  }

  function tableHtml() {
    var list = rows();
    var head = COLS.map(function (c) {
      var on = view.sort === c.k;
      return '<th class="' + c.cls + (on ? ' sorted' : '') + '"' + (c.cls.indexOf('nosort') < 0 ? ' data-sort="' + c.k + '"' : '') + '>' + c.t + (on ? (view.dir > 0 ? ' ▲' : ' ▼') : '') + '</th>';
    }).join('');
    var body = list.slice(0, view.limit).map(function (c) {
      var meta = CRY.coinMap[c.id], w = CRY.watch.has(c.id);
      return '<tr data-coin="' + esc(c.id) + '">' +
        '<td class="num narrow"><button type="button" class="cry-star' + (w ? ' on' : '') + '" data-star="' + esc(c.id) + '" aria-label="加入自選" title="加入自選">' + (w ? '★' : '☆') + '</button>' + (c.rank || '—') + '</td>' +
        '<td><div class="cry-coin-cell">' + CRY.coinAvatar(c.sym, c.img, 26) + '<div><b>' + esc(meta ? meta.name : c.name) + '</b><span>' + esc(c.sym) + (meta ? '・<em>圖鑑</em>' : '') + '</span></div></div></td>' +
        '<td class="num strong">' + P.price(c.p) + '</td>' +
        '<td class="num hide-s">' + CRY.pctHtml(c.c1h) + '</td><td class="num">' + CRY.pctHtml(c.c24h) + '</td><td class="num hide-s">' + CRY.pctHtml(c.c7d) + '</td><td class="num hide-m">' + CRY.pctHtml(c.c30d) + '</td>' +
        '<td class="num hide-s">' + P.big(c.mc) + '</td><td class="num hide-m">' + P.big(c.vol) + '</td>' +
        '<td class="num hide-s">' + P.sparkSvg(c.spark, 96, 28) + '</td></tr>';
    }).join('');
    var more = list.length > view.limit ? '<div class="cry-more"><button type="button" class="cry-btn" data-more>顯示更多（還有 ' + (list.length - view.limit) + ' 個）</button></div>' : '';
    return '<div class="cry-table-wrap"><table class="cry-table"><thead><tr>' + head + '</tr></thead><tbody>' +
      (body || '<tr><td colspan="10" class="cry-empty">找不到符合的幣種。</td></tr>') + '</tbody></table></div>' + more +
      '<p class="cry-muted cry-count">共 ' + list.length + ' 個幣種（依市值收錄前 ' + P.coins().length + ' 名）</p>';
  }

  function chartHtml() {
    var ids = Object.keys((P.data && P.data.charts) || {}).filter(function (id) { return P.hasYearChart(id) && P.get(id); });
    if (!ids.length) return '';
    if (ids.indexOf(view.chartId) < 0) view.chartId = ids[0];
    var c = P.get(view.chartId), meta = CRY.coinMap[view.chartId];
    var pts = P.seriesOf(view.chartId, view.days);
    var chg = pts.length > 1 ? (pts[pts.length - 1].v / pts[0].v - 1) * 100 : null;
    return '<div class="cry-card cry-chart-card"><div class="cry-chart-head">' +
      '<div class="cry-chart-title">' + CRY.coinAvatar(c.sym, c.img, 30) + '<div><b>' + esc(meta ? meta.name : c.name) + ' ' + esc(c.sym) + '</b><span>' + P.price(c.p) + '　區間 ' + CRY.pctHtml(chg) + '</span></div></div>' +
      '<div class="cry-chart-ctl"><span class="cry-seg">' + ids.map(function (id) { var x = P.get(id); return '<button type="button" class="' + (id === view.chartId ? 'on' : '') + '" data-chart="' + esc(id) + '">' + esc(x.sym) + '</button>'; }).join('') + '</span>' +
      '<span class="cry-seg">' + [[30, '30 天'], [90, '90 天'], [180, '半年'], [365, '一年']].map(function (d) { return '<button type="button" class="' + (d[0] === view.days ? 'on' : '') + '" data-days="' + d[0] + '">' + d[1] + '</button>'; }).join('') + '</span></div></div>' +
      P.lineChartSvg(pts, { id: 'M' }) + '</div>';
  }

  function converterHtml() {
    var opts = P.coins().slice(0, 60).map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.sym) + '　' + esc((CRY.coinMap[c.id] || c).name) + '</option>'; }).join('');
    return '<div class="cry-card cry-conv"><b>🔁 換算機</b><input type="number" id="convAmt" value="1" min="0" step="any" inputmode="decimal" aria-label="數量">' +
      '<select id="convCoin" aria-label="幣種">' + opts + '</select><span class="cry-conv-eq">=</span><output id="convOut"></output></div>';
  }
  function updateConv(root) {
    var amt = parseFloat((CRY.$('#convAmt', root) || {}).value), sel = CRY.$('#convCoin', root), out = CRY.$('#convOut', root);
    if (!sel || !out) return;
    var c = P.get(sel.value);
    if (!c || isNaN(amt)) { out.textContent = '—'; return; }
    out.innerHTML = '<b>' + CRY.fmtPrice(amt * c.p, 'usd') + '</b> 美元　≈　<b>' + CRY.fmtPrice(amt * c.p * P.rate(), 'twd') + '</b> 新台幣';
  }

  function quickCoinModal(id) {
    var c = P.get(id);
    if (!c) return;
    function row(k, v) { return '<div class="cry-fact"><span>' + k + '</span><b>' + v + '</b></div>'; }
    CRY.openModal('<div class="cry-modal-head">' + CRY.coinAvatar(c.sym, c.img, 40) + '<div><h3>' + esc(c.name) + ' <small>' + esc(c.sym) + '</small></h3><div class="cry-big-price">' + P.price(c.p) + ' ' + CRY.pctHtml(c.c24h) + '</div></div></div>' +
      '<div class="cry-facts">' + row('市值排名', '#' + (c.rank || '—')) + row('市值', P.big(c.mc)) + row('24 小時成交量', P.big(c.vol)) + row('24 小時高／低', P.price(c.hi) + '／' + P.price(c.lo)) +
      row('7 天漲跌', CRY.pctHtml(c.c7d)) + row('30 天漲跌', CRY.pctHtml(c.c30d)) + row('歷史最高價', P.price(c.ath) + (c.athDate ? '（' + esc(c.athDate) + '）' : '')) + row('距離最高價', CRY.pctHtml(c.athChg)) +
      row('流通量', CRY.fmtQty(c.circ)) + row('供給上限', c.max ? CRY.fmtQty(c.max) : '無上限或未公布') + '</div>' +
      '<div class="cry-modal-chart">' + P.lineChartSvg(P.seriesOf(id, 7), { id: 'Q', h: 180, maxW: 636 }) + '<p class="cry-muted">近 7 天走勢</p></div>' +
      '<p class="cry-muted">這個幣還沒有收錄在幣種圖鑑。排名靠前不代表安全，請先弄懂它是什麼再做任何決定。</p>');
  }

  function renderMarket(root) {
    var filters = [['all', '全部'], ['guide', '📘 圖鑑收錄'], ['watch', '★ 我的自選'], ['up', '上漲'], ['down', '下跌']];
    root.innerHTML = '<h1 class="cry-h1">📈 即時幣價</h1>' +
      statusBar('<button type="button" class="cry-btn ghost" data-colormode title="切換漲跌顏色">' + (CRY.store.get('color_mode.v1', 'green_up') === 'green_up' ? '🟢 綠漲紅跌' : '🔴 紅漲綠跌') + '</button>') +
      '<section data-live="kpis">' + globalCards() + '</section>' +
      '<section data-live="chart">' + chartHtml() + '</section>' +
      '<section>' + converterHtml() + '</section>' +
      '<section><div class="cry-toolbar"><input type="search" id="mktSearch" class="cry-input" placeholder="搜尋幣種名稱或代號，例如 BTC、以太坊" value="' + esc(view.q) + '" aria-label="搜尋幣種">' +
        '<div class="cry-chips">' + filters.map(function (f) { return '<button type="button" class="cry-chip' + (view.filter === f[0] ? ' on' : '') + '" data-filter="' + f[0] + '">' + f[1] + '</button>'; }).join('') + '</div></div>' +
        '<div data-live="table">' + tableHtml() + '</div></section>' + CRY.disclaimer();
    updateConv(root);
    function redrawTable() { var t = CRY.$('[data-live="table"]', root); if (t) t.innerHTML = tableHtml(); }
    function redrawChart() { var t = CRY.$('[data-live="chart"]', root); if (t) t.innerHTML = chartHtml(); }
    root._live = function () {
      var k = CRY.$('[data-live="kpis"]', root); if (k) k.innerHTML = globalCards();
      var s = CRY.$('[data-live="status"]', root); if (s) s.textContent = P.statusText();
      redrawChart(); redrawTable(); updateConv(root);
    };
    var search = CRY.$('#mktSearch', root);
    search.addEventListener('input', function () { view.q = search.value; view.limit = 50; redrawTable(); });
    root.addEventListener('input', function (e) { if (e.target.id === 'convAmt') updateConv(root); });
    root.addEventListener('change', function (e) { if (e.target.id === 'convCoin') updateConv(root); });
    root.addEventListener('click', function (e) {
      var t = e.target.closest('[data-filter],[data-sort],[data-more],[data-star],[data-chart],[data-days],[data-colormode],tr[data-coin]');
      if (!t || !root.contains(t)) return;
      if (t.hasAttribute('data-star')) {
        var on = CRY.watch.toggle(t.getAttribute('data-star'));
        CRY.toast(on ? '★ 已加入自選' : '已從自選移除');
        redrawTable();
      } else if (t.hasAttribute('data-filter')) {
        view.filter = t.getAttribute('data-filter'); view.limit = 50;
        CRY.$$('[data-filter]', root).forEach(function (b) { b.classList.toggle('on', b === t); });
        redrawTable();
      } else if (t.hasAttribute('data-sort')) {
        var k = t.getAttribute('data-sort');
        if (view.sort === k) view.dir = -view.dir; else { view.sort = k; view.dir = (k === 'rank' || k === 'name') ? 1 : -1; }
        redrawTable();
      } else if (t.hasAttribute('data-more')) { view.limit += 100; redrawTable(); }
      else if (t.hasAttribute('data-chart')) { view.chartId = t.getAttribute('data-chart'); redrawChart(); }
      else if (t.hasAttribute('data-days')) { view.days = parseInt(t.getAttribute('data-days'), 10); redrawChart(); }
      else if (t.hasAttribute('data-colormode')) {
        var m = CRY.store.get('color_mode.v1', 'green_up') === 'green_up' ? 'red_up' : 'green_up';
        CRY.store.set('color_mode.v1', m); CRY.applyColorMode();
        t.textContent = m === 'green_up' ? '🟢 綠漲紅跌' : '🔴 紅漲綠跌';
      } else if (t.hasAttribute('data-coin')) {
        var id = t.getAttribute('data-coin');
        if (CRY.coinMap[id]) CRY.go('coin/' + encodeURIComponent(id)); else quickCoinModal(id);
      }
    });
  }

  CRY.applyColorMode = function () {
    document.documentElement.setAttribute('data-cry-color', CRY.store.get('color_mode.v1', 'green_up'));
  };

  CRY.route('home', renderHome);
  CRY.route('market', renderMarket);
})();
