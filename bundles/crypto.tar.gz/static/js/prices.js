/* 區塊鏈學院 — 行情資料層：內建快照（prices_data.js）→ 本機 API → CoinGecko 即時（CORS），以及走勢圖繪製 */
(function () {
  'use strict';
  var CRY = (window.CRY = window.CRY || {});
  var LIVE_URL = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=1' +
    '&sparkline=false&price_change_percentage=1h,24h,7d,30d';
  var LIVE_MIN_GAP = 60 * 1000;      // 兩次即時請求至少間隔 60 秒
  var AUTO_BASE = 120 * 1000;        // 頁面可見時每 2 分鐘自動更新
  var AUTO_MAX = 10 * 60 * 1000;     // 被限流時逐步拉長到 10 分鐘

  var P = (CRY.Prices = {
    data: null, map: {}, liveAt: 0, lastTry: 0, mode: 'snapshot', busy: false, subs: [], autoGap: AUTO_BASE, timer: null
  });

  P.setData = function (d) {
    if (!d || !d.coins || !d.coins.length) return false;
    P.data = d;
    P.map = {};
    d.coins.forEach(function (c) { P.map[c.id] = c; });
    return true;
  };
  P.get = function (id) { return P.map[id] || null; };
  P.coins = function () { return (P.data && P.data.coins) || []; };
  P.rate = function () { return (P.data && P.data.twdRate) || 32; };
  P.cur = function () { return CRY.store.get('currency.v1', 'usd') === 'twd' ? 'twd' : 'usd'; };
  P.setCur = function (c) { CRY.store.set('currency.v1', c); P.emit(); };
  P.conv = function (usd) { return usd == null ? null : P.cur() === 'twd' ? usd * P.rate() : usd; };
  P.price = function (usd) { return CRY.fmtPrice(P.conv(usd), P.cur()); };
  P.big = function (usd) { return CRY.fmtBig(P.conv(usd), P.cur()); };
  P.on = function (fn) { P.subs.push(fn); };
  P.emit = function () { P.subs.forEach(function (fn) { try { fn(); } catch (e) { /* 單一訂閱者失敗不影響其他 */ } }); };

  P.updatedMs = function () { return P.liveAt || ((P.data && P.data.updatedTs) || 0) * 1000; };
  P.statusText = function () {
    var ms = P.updatedMs();
    if (!ms) return '尚無行情資料';
    var d = new Date(ms);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    var t = d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + ' ' + z(d.getHours()) + ':' + z(d.getMinutes());
    var age = Math.max(0, Math.round((Date.now() - ms) / 60000));
    var ageTxt = age < 1 ? '剛剛' : age < 60 ? age + ' 分鐘前' : age < 1440 ? Math.round(age / 60) + ' 小時前' : Math.round(age / 1440) + ' 天前';
    return (P.mode === 'live' ? '🟢 即時報價' : '🕒 排程快照') + '・' + t + '（' + ageTxt + '）';
  };

  // 本機／校園 gateway：讀伺服器上的最新快照（比打包進頁面的更新）
  P.loadServer = function () {
    if (CRY.isStatic() || !window.fetch) return Promise.resolve(false);
    return fetch(CRY.apiBase() + 'prices', { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        var d = j && (j.data || j);
        if (d && d.coins && (!P.data || (d.updatedTs || 0) >= (P.data.updatedTs || 0))) { P.setData(d); P.emit(); return true; }
        return false;
      })
      .catch(function () { return false; });
  };

  // 直接向 CoinGecko 取即時報價並合併進快照（保留快照的 7 日走勢、匯率與全球數據）
  P.refreshLive = function (manual) {
    if (!window.fetch || P.busy) return Promise.resolve(false);
    if (Date.now() - P.lastTry < (manual ? 8000 : LIVE_MIN_GAP)) return Promise.resolve(false);
    P.busy = true;
    P.lastTry = Date.now();
    var ctrl = window.AbortController ? new AbortController() : null;
    var killer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 12000);
    return fetch(LIVE_URL, { cache: 'no-store', signal: ctrl ? ctrl.signal : undefined, referrerPolicy: 'no-referrer' })
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (rows) {
        if (!Array.isArray(rows) || rows.length < 20) throw new Error('rows');
        var base = P.data || { coins: [], twdRate: 32, global: {}, fng: {}, charts: {} };
        var old = {};
        base.coins.forEach(function (c) { old[c.id] = c; });
        var coins = rows.filter(function (x) { return x && x.id && x.current_price != null; }).map(function (x) {
          var o = old[x.id] || {};
          return {
            id: x.id, sym: String(x.symbol || '').toUpperCase(), name: x.name,
            img: String(x.image || o.img || '').replace('/large/', '/small/').split('?')[0],
            rank: x.market_cap_rank, p: x.current_price,
            c1h: x.price_change_percentage_1h_in_currency, c24h: x.price_change_percentage_24h_in_currency != null ? x.price_change_percentage_24h_in_currency : x.price_change_percentage_24h,
            c7d: x.price_change_percentage_7d_in_currency, c30d: x.price_change_percentage_30d_in_currency,
            mc: x.market_cap, fdv: x.fully_diluted_valuation, vol: x.total_volume, hi: x.high_24h, lo: x.low_24h,
            ath: x.ath, athDate: String(x.ath_date || '').slice(0, 10), athChg: x.ath_change_percentage,
            circ: x.circulating_supply, max: x.max_supply, spark: o.spark || []
          };
        });
        var seen = {};
        coins.forEach(function (c) { seen[c.id] = 1; });
        // 圖鑑收錄但跌出前 250 名的幣，沿用快照資料，不讓它消失
        base.coins.forEach(function (c) { if (!seen[c.id] && CRY.coinMap && CRY.coinMap[c.id]) coins.push(c); });
        var g = {};
        Object.keys(base.global || {}).forEach(function (k) { g[k] = base.global[k]; });
        var total = 0;
        coins.forEach(function (c) { total += c.mc || 0; });
        var btc = coins.filter(function (c) { return c.id === 'bitcoin'; })[0];
        if (btc && g.mcap && g.btcDom && total > 0) {
          // 用前 250 名市值的變動比例，同步推估全球總市值與 BTC 市占
          var oldTotal = 0;
          base.coins.forEach(function (c) { oldTotal += c.mc || 0; });
          if (oldTotal > 0) { g.mcap = g.mcap * total / oldTotal; g.btcDom = btc.mc / g.mcap * 100; }
        }
        P.setData({
          updatedAt: base.updatedAt, updatedTs: base.updatedTs, source: 'coingecko', twdRate: base.twdRate, global: g, fng: base.fng,
          coins: coins, count: coins.length, charts: base.charts
        });
        P.liveAt = Date.now();
        P.mode = 'live';
        P.autoGap = AUTO_BASE;
        P.emit();
        return true;
      })
      .catch(function () { P.autoGap = Math.min(AUTO_MAX, P.autoGap * 2); return false; })
      .then(function (ok) { clearTimeout(killer); P.busy = false; return ok; });
  };

  // 「立即更新」：本機先請伺服器重抓（同時更新磁碟快照），再補一次瀏覽器即時報價
  P.refreshNow = function () {
    var viaServer = CRY.isStatic() ? Promise.resolve(false) : fetch(CRY.apiBase() + 'prices/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { var d = j && (j.data || j); if (d && d.coins) { P.setData(d); P.liveAt = 0; P.mode = 'snapshot'; P.emit(); return true; } return false; })
      .catch(function () { return false; });
    return viaServer.then(function (a) { return P.refreshLive(true).then(function (b) { return a || b; }); });
  };

  P.startAuto = function () {
    function tick() {
      var visible = !document.hidden;
      var name = CRY.parseHash().name;
      var wants = name === 'home' || name === 'market' || name === 'coins' || name === 'coin';
      var next = P.autoGap;
      if (visible && wants && Date.now() - P.updatedMs() > 90 * 1000) P.refreshLive(false);
      P.timer = setTimeout(tick, next);
    }
    clearTimeout(P.timer);
    P.timer = setTimeout(tick, 1500);
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden && Date.now() - P.updatedMs() > AUTO_BASE) P.refreshLive(false);
    });
  };

  P.init = function () {
    P.setData(window.CRY_PRICES);
    return P.loadServer();
  };

  // ---------- 圖表 ----------
  P.sparkSvg = function (arr, w, h, cls) {
    var a = (arr || []).filter(function (v) { return typeof v === 'number'; });
    if (a.length < 2) return '<span class="cry-spark-none">—</span>';
    var lo = Math.min.apply(null, a), hi = Math.max.apply(null, a), span = hi - lo || 1;
    var pts = a.map(function (v, i) { return (i * (w - 2) / (a.length - 1) + 1).toFixed(1) + ',' + (h - 2 - (v - lo) * (h - 4) / span).toFixed(1); }).join(' ');
    var c = cls || (a[a.length - 1] >= a[0] ? 'up' : 'down');
    return '<svg class="cry-spark ' + c + '" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true"><polyline points="' + pts + '" fill="none" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/></svg>';
  };

  // 折線面積圖（日線）：points = [{t: 秒, v: 美元價}]
  P.lineChartSvg = function (points, opts) {
    opts = opts || {};
    // 依實際容器寬度決定座標系，文字才不會被放大或縮到看不清楚
    var vw = Math.max(320, (document.documentElement.clientWidth || 1024) - (opts.inset || 76));
    var W = Math.round(Math.min(opts.maxW || 1180, vw)), H = opts.h || (W < 600 ? 200 : 300), padL = 8, padR = 62, padT = 14, padB = 24;
    if (!points || points.length < 2) return '<div class="cry-empty">這個幣目前沒有長期走勢資料。</div>';
    var cur = P.cur(), rate = cur === 'twd' ? P.rate() : 1;
    var vals = points.map(function (p) { return p.v * rate; });
    var lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
    var pad = (hi - lo) * 0.08 || hi * 0.05 || 1;
    lo = Math.max(0, lo - pad); hi += pad;
    var iw = W - padL - padR, ih = H - padT - padB, n = points.length;
    function axisLabel(v) { return hi >= 1000 ? Math.round(v).toLocaleString('en-US') : CRY.fmtPrice(v, cur).replace('NT$', '').replace('$', ''); }
    function X(i) { return padL + i * iw / (n - 1); }
    function Y(v) { return padT + (hi - v) * ih / (hi - lo); }
    var line = vals.map(function (v, i) { return (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(v).toFixed(1); }).join(' ');
    var area = line + ' L' + X(n - 1).toFixed(1) + ' ' + (padT + ih) + ' L' + padL + ' ' + (padT + ih) + ' Z';
    var up = vals[n - 1] >= vals[0];
    var grid = '';
    for (var g = 0; g <= 4; g++) {
      var gv = lo + (hi - lo) * g / 4, gy = Y(gv);
      grid += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + gy.toFixed(1) + '" y2="' + gy.toFixed(1) + '" class="cry-grid"/>' +
        '<text x="' + (W - padR + 6) + '" y="' + (gy + 4).toFixed(1) + '" class="cry-axis">' + CRY.esc(axisLabel(gv)) + '</text>';
    }
    var labels = '';
    var ticks = Math.min(W < 600 ? 3 : 5, n - 1);
    for (var k = 0; k <= ticks; k++) {
      var idx = Math.round(k * (n - 1) / ticks), d = new Date(points[idx].t * 1000);
      var anchor = k === 0 ? 'start' : k === ticks ? 'end' : 'middle';
      labels += '<text x="' + X(idx).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="' + anchor + '" class="cry-axis">' +
        (d.getUTCFullYear() + '/' + (d.getUTCMonth() + 1) + '/' + d.getUTCDate()) + '</text>';
    }
    var gid = 'cryGrad' + (opts.id || '');
    return '<svg class="cry-chart ' + (up ? 'up' : 'down') + '" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="價格走勢圖">' +
      '<defs><linearGradient id="' + gid + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" class="cry-g0"/><stop offset="1" class="cry-g1"/></linearGradient></defs>' +
      grid + '<path d="' + area + '" fill="url(#' + gid + ')" stroke="none"/><path d="' + line + '" fill="none" class="cry-line" stroke-width="2" stroke-linejoin="round"/>' +
      '<circle cx="' + X(n - 1).toFixed(1) + '" cy="' + Y(vals[n - 1]).toFixed(1) + '" r="3.4" class="cry-dot"/>' + labels + '</svg>';
  };

  // 取某個幣的日線點：有近一年日線就用（可指定天數），否則退回 7 日走勢
  P.seriesOf = function (id, days) {
    var ch = P.data && P.data.charts && P.data.charts[id];
    var c = P.get(id);
    if (ch && ch.p && ch.p.length > 1 && days > 7) {
      var n = ch.p.length, step = (ch.t1 - ch.t0) / (n - 1) || 86400;
      var pts = ch.p.map(function (v, i) { return { t: ch.t0 + i * step, v: v }; });
      if (c && c.p) pts[pts.length - 1] = { t: Math.round(P.updatedMs() / 1000) || pts[pts.length - 1].t, v: c.p };
      return pts.slice(-Math.min(n, days + 1));
    }
    if (c && c.spark && c.spark.length > 1) {
      var end = ((P.data && P.data.updatedTs) || Math.round(Date.now() / 1000)), m = c.spark.length, st = 7 * 86400 / (m - 1);
      return c.spark.map(function (v, i) { return { t: end - (m - 1 - i) * st, v: v }; });
    }
    return [];
  };
  P.hasYearChart = function (id) { var ch = P.data && P.data.charts && P.data.charts[id]; return !!(ch && ch.p && ch.p.length > 60); };

  P.fngColor = function (v) { return v < 25 ? '#dc2626' : v < 45 ? '#ea580c' : v < 55 ? '#ca8a04' : v < 75 ? '#65a30d' : '#16a34a'; };
})();
