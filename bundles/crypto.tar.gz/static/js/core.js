/* 區塊鏈學院 core — 命名空間 CRY、共用工具、路由、進度保存（localStorage 前綴 cry.） */
(function () {
  'use strict';
  var CRY = (window.CRY = window.CRY || {});
  CRY.LESSONS = CRY.LESSONS || [];
  CRY.COINS = CRY.COINS || [];
  CRY.HISTORY = CRY.HISTORY || [];
  CRY.GLOSSARY = CRY.GLOSSARY || [];

  CRY.TRACKS = [
    { id: 'basics', icon: '⛓️', name: '區塊鏈基礎', desc: '帳本、雜湊、公私鑰與節點，從零看懂區塊鏈在做什麼。' },
    { id: 'consensus', icon: '⚒️', name: '共識機制與挖礦', desc: 'PoW、PoS、減半與分叉：一群陌生人如何對同一本帳達成共識。' },
    { id: 'bitcoin', icon: '₿', name: '比特幣深入', desc: 'UTXO、手續費、閃電網路與現貨 ETF，數位黃金的完整樣貌。' },
    { id: 'ethereum', icon: '◆', name: '以太坊與智慧合約', desc: 'EVM、Gas、代幣標準與 Layer 2，會跑程式的區塊鏈。' },
    { id: 'defi', icon: '🏦', name: 'DeFi 去中心化金融', desc: '穩定幣、AMM、借貸與清算，沒有銀行的金融怎麼運作。' },
    { id: 'wallet', icon: '🛡️', name: '錢包與資安防詐', desc: '助記詞、冷熱錢包、授權與常見詐騙手法，先學會保護自己。' },
    { id: 'market', icon: '📊', name: '市場觀念與風險', desc: '市值、代幣經濟、槓桿與週期，看懂數字背後的風險。' },
    { id: 'frontier', icon: '🌐', name: '應用、趨勢與監管', desc: 'NFT、DAO、RWA、零知識證明與各國法規的最新發展。' }
  ];
  CRY.COIN_CATS = [
    { id: 'store', name: '價值儲存', icon: '🪙' }, { id: 'platform', name: '智慧合約平台', icon: '🧱' },
    { id: 'stable', name: '穩定幣', icon: '💵' }, { id: 'payment', name: '支付與轉帳', icon: '💸' },
    { id: 'defi', name: 'DeFi 協議', icon: '🏦' }, { id: 'l2', name: 'Layer 2／擴容', icon: '🚀' },
    { id: 'infra', name: '基礎設施', icon: '🛠️' }, { id: 'meme', name: '迷因幣', icon: '🐶' },
    { id: 'privacy', name: '隱私幣', icon: '🕶️' }, { id: 'exchange', name: '交易所平台幣', icon: '🏛️' }
  ];
  CRY.ERAS = [
    { id: 'pre', name: '密碼龐克與前身', years: '2008 以前' }, { id: 'genesis', name: '比特幣誕生', years: '2008–2012' },
    { id: 'early', name: '野蠻生長', years: '2013–2016' }, { id: 'ico', name: 'ICO 狂潮與寒冬', years: '2017–2019' },
    { id: 'defi', name: 'DeFi 之夏與 NFT 熱', years: '2020–2021' }, { id: 'crash', name: '連環爆與監管', years: '2022–2023' },
    { id: 'inst', name: 'ETF 與機構時代', years: '2024–至今' }
  ];
  CRY.GLOSS_CATS = [
    { id: 'tech', name: '技術原理' }, { id: 'coin', name: '貨幣與代幣' }, { id: 'defi', name: 'DeFi' }, { id: 'trade', name: '交易與市場' },
    { id: 'sec', name: '資安' }, { id: 'culture', name: '幣圈用語' }, { id: 'reg', name: '法規' }
  ];

  // ---------- 基本工具 ----------
  CRY.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  CRY.$ = function (sel, root) { return (root || document).querySelector(sel); };
  CRY.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  CRY.byId = function (list, id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return null; };
  CRY.find = function (list, key, val) { for (var i = 0; i < list.length; i++) if (list[i][key] === val) return list[i]; return null; };

  CRY.store = {
    get: function (key, dflt) {
      try { var v = window.localStorage.getItem('cry.' + key); return v == null ? dflt : JSON.parse(v); } catch (e) { return dflt; }
    },
    set: function (key, val) { try { window.localStorage.setItem('cry.' + key, JSON.stringify(val)); } catch (e) { /* 私密模式 */ } }
  };

  CRY.isStatic = function () {
    if (window.CRY_STATIC_ONLY || window.CAMPUS_STATIC_ONLY) return true;
    var loc = window.location || {};
    if (String(loc.protocol || '').indexOf('http') !== 0) return true;
    return /\.github\.io$/i.test(String(loc.hostname || ''));
  };
  CRY.apiBase = function () {
    var ms = document.querySelector && document.querySelector('script[data-campus-mount]');
    if (ms) { var mnt = ms.getAttribute('data-campus-mount'); if (mnt) return '/' + mnt + '/api/'; }
    return 'api/';
  };

  var toastTimer = null;
  CRY.toast = function (msg) {
    var el = document.getElementById('cryToast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2600);
  };

  CRY.openModal = function (html) {
    var bd = document.getElementById('cryModal');
    var card = document.getElementById('cryModalCard');
    if (!bd || !card) return;
    card.innerHTML = '<button type="button" class="cry-modal-close" data-close-modal aria-label="關閉">✕</button>' + html;
    bd.classList.add('open');
    card.scrollTop = 0;
  };
  CRY.closeModal = function () { var bd = document.getElementById('cryModal'); if (bd) bd.classList.remove('open'); };

  // ---------- 數字格式 ----------
  function trimZeros(s) { return s.indexOf('.') >= 0 ? s.replace(/0+$/, '').replace(/\.$/, '') : s; }
  function group(n, digits) {
    return Number(n).toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
  }
  // 價格：大數兩位小數、小數依量級保留有效位數（PEPE、SHIB 這類極小價格不會變成 0）
  CRY.fmtPrice = function (v, cur) {
    if (v == null || isNaN(v)) return '—';
    var pre = cur === 'twd' ? 'NT$' : '$';
    var a = Math.abs(v), s;
    if (a >= 1000) s = group(v, cur === 'twd' ? 0 : 2);
    else if (a >= 1) s = group(v, 2);
    else if (a >= 0.01) s = trimZeros(v.toFixed(4));
    else if (a === 0) s = '0';
    else { var d = Math.min(12, Math.ceil(-Math.log(a) / Math.LN10) + 3); s = trimZeros(v.toFixed(d)); }
    return pre + s;
  };
  // 大數字用中文量級（兆／億／萬）
  CRY.fmtBig = function (v, cur) {
    if (v == null || isNaN(v)) return '—';
    var pre = cur === 'twd' ? 'NT$' : cur === 'none' ? '' : '$';
    var a = Math.abs(v);
    function m(x, d) { return Number(x.toFixed(d)).toLocaleString('en-US', { maximumFractionDigits: d }); }
    if (a >= 1e12) return pre + m(v / 1e12, 2) + ' 兆';
    if (a >= 1e8) return pre + m(v / 1e8, a >= 1e10 ? 0 : 1) + ' 億';
    if (a >= 1e4) return pre + m(v / 1e4, a >= 1e6 ? 0 : 1) + ' 萬';
    return pre + group(v, 0);
  };
  // 數量（枚）：2,011 萬枚、1.2 億枚
  CRY.fmtQty = function (v) { return v == null || isNaN(v) || !v ? '—' : CRY.fmtBig(v, 'none') + '枚'; };
  CRY.fmtPct = function (v) {
    if (v == null || isNaN(v)) return '—';
    return (v > 0 ? '+' : '') + v.toFixed(2) + '%';
  };
  CRY.pctClass = function (v) { return v == null || isNaN(v) || v === 0 ? 'flat' : v > 0 ? 'up' : 'down'; };
  CRY.pctHtml = function (v) { return '<span class="cry-pct ' + CRY.pctClass(v) + '">' + CRY.fmtPct(v) + '</span>'; };

  // ---------- 內容索引（載入後排序一次） ----------
  CRY.initContent = function () {
    var order = {};
    CRY.TRACKS.forEach(function (t, i) { order[t.id] = i; });
    CRY.LESSONS.sort(function (a, b) { return (order[a.track] - order[b.track]) || (a.id < b.id ? -1 : 1); });
    CRY.HISTORY.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
    CRY.GLOSSARY.sort(function (a, b) { return String(a.term).localeCompare(String(b.term), 'zh-Hant'); });
    CRY.glossMap = {};
    CRY.GLOSSARY.forEach(function (g) { CRY.glossMap[g.term] = g; });
    CRY.coinMap = {};
    CRY.COINS.forEach(function (c) { CRY.coinMap[c.id] = c; });
  };
  CRY.lessonsOf = function (track) { return CRY.LESSONS.filter(function (l) { return l.track === track; }); };
  CRY.trackOf = function (id) { return CRY.byId(CRY.TRACKS, id); };

  // ---------- 學習進度 ----------
  CRY.progress = {
    data: function () { return CRY.store.get('progress.v1', { done: {}, quiz: {} }); },
    isDone: function (id) { return !!this.data().done[id]; },
    setDone: function (id, on) {
      var d = this.data();
      if (on) d.done[id] = Date.now(); else delete d.done[id];
      CRY.store.set('progress.v1', d);
      CRY.syncNavCounts();
      CRY.reportProgress();
    },
    setQuiz: function (id, score) { var d = this.data(); d.quiz[id] = Math.max(score, d.quiz[id] || 0); CRY.store.set('progress.v1', d); },
    quizOf: function (id) { return this.data().quiz[id]; },
    countDone: function (track) {
      var d = this.data().done;
      return CRY.LESSONS.filter(function (l) { return (!track || l.track === track) && d[l.id]; }).length;
    }
  };
  CRY.syncNavCounts = function () {
    var el = document.getElementById('navLearnCnt');
    if (el) el.textContent = CRY.progress.countDone() + '/' + CRY.LESSONS.length;
  };
  // 回報給校園地圖（成就／學習紀錄）；CampusNav 不存在時安靜略過
  CRY.reportProgress = function () {
    try {
      var done = CRY.progress.countDone();
      CRY.store.set('summary.v1', { lessonsDone: done, lessonsTotal: CRY.LESSONS.length, ts: Date.now() });
      if (window.CampusNav && typeof window.CampusNav.reportProgress === 'function') {
        window.CampusNav.reportProgress('crypto', { done: done, total: CRY.LESSONS.length });
      }
    } catch (e) { /* ignore */ }
  };

  // ---------- 自選幣 ----------
  CRY.watch = {
    list: function () { return CRY.store.get('watch.v1', []); },
    has: function (id) { return this.list().indexOf(id) >= 0; },
    toggle: function (id) {
      var l = this.list(), i = l.indexOf(id);
      if (i >= 0) l.splice(i, 1); else l.push(id);
      CRY.store.set('watch.v1', l);
      return i < 0;
    }
  };

  // ---------- 路由 ----------
  CRY.routes = {};
  CRY.route = function (name, fn) { CRY.routes[name] = fn; };
  CRY.parseHash = function () {
    var h = String(window.location.hash || '').replace(/^#\/?/, '');
    var parts = h.split('?')[0].split('/').filter(Boolean).map(function (p) { try { return decodeURIComponent(p); } catch (e) { return p; } });
    return { name: parts[0] || 'home', args: parts.slice(1) };
  };
  CRY.go = function (hash) { window.location.hash = hash.charAt(0) === '#' ? hash : '#/' + hash.replace(/^\//, ''); };

  // 共用小元件
  CRY.disclaimer = function () {
    return '<p class="cry-disclaimer">⚠️ 本站內容僅供教學與研究，不構成任何投資建議。虛擬貨幣價格波動劇烈，可能損失全部本金；任何保證獲利的說法都是詐騙警訊。</p>';
  };
  CRY.paras = function (arr) { return (arr || []).map(function (p) { return '<p>' + CRY.esc(p) + '</p>'; }).join(''); };
  CRY.coinAvatar = function (sym, img, size) {
    var s = size || 28;
    var hue = 0, str = String(sym || '?');
    for (var i = 0; i < str.length; i++) hue = (hue * 31 + str.charCodeAt(i)) % 360;
    var letter = CRY.esc(str.replace(/[^A-Za-z0-9]/g, '').slice(0, 1) || '?');
    // 先畫字母圓章，圖片載入成功才蓋上去（離線或圖床失效時畫面仍完整）
    return '<span class="cry-ava" style="width:' + s + 'px;height:' + s + 'px;font-size:' + Math.round(s * 0.46) + 'px;background:hsl(' + hue + ',62%,46%)">' +
      letter + (img ? '<img src="' + CRY.esc(img) + '" alt="" loading="lazy" referrerpolicy="no-referrer" onload="this.style.opacity=1" onerror="this.remove()">' : '') + '</span>';
  };
})();
