/* 區塊鏈學院 — 課程（學習路線／單元列表／課文＋隨堂測驗）與總測驗 */
(function () {
  'use strict';
  var CRY = window.CRY, esc = CRY.esc;
  var LEVEL = { 1: '入門', 2: '進階', 3: '深入' };

  function renderLearn(root, args) {
    var only = args[0] && CRY.trackOf(args[0]) ? args[0] : null;
    var tracks = CRY.TRACKS.filter(function (t) { return !only || t.id === only; });
    var html = '<h1 class="cry-h1">⛓️ 區塊鏈課程</h1>' +
      '<div class="cry-chips cry-chips-scroll"><a class="cry-chip' + (!only ? ' on' : '') + '" href="#/learn">全部路線</a>' +
      CRY.TRACKS.map(function (t) { return '<a class="cry-chip' + (only === t.id ? ' on' : '') + '" href="#/learn/' + t.id + '">' + t.icon + ' ' + esc(t.name) + '</a>'; }).join('') + '</div>';
    html += tracks.map(function (t) {
      var ls = CRY.lessonsOf(t.id), dn = CRY.progress.countDone(t.id);
      return '<section class="cry-track-sec"><div class="cry-track-head"><h2>' + t.icon + ' ' + esc(t.name) + '</h2><span class="cry-muted">' + dn + ' / ' + ls.length + ' 堂完成</span></div>' +
        '<p class="cry-muted">' + esc(t.desc) + '</p><div class="cry-lessons">' +
        (ls.map(function (l, i) {
          var done = CRY.progress.isDone(l.id), q = CRY.progress.quizOf(l.id);
          return '<a class="cry-lesson-row' + (done ? ' done' : '') + '" href="#/lesson/' + l.id + '"><span class="cry-lesson-no">' + (done ? '✓' : (i + 1)) + '</span>' +
            '<span class="cry-lesson-main"><b>' + esc(l.title) + '</b><span>' + esc(l.summary) + '</span></span>' +
            '<span class="cry-lesson-meta"><i class="lv' + l.level + '">' + LEVEL[l.level] + '</i><span>' + l.minutes + ' 分鐘</span>' + (q != null ? '<span>測驗 ' + q + '/3</span>' : '') + '</span></a>';
        }).join('') || '<div class="cry-empty">這條路線的課程準備中。</div>') + '</div></section>';
    }).join('');
    root.innerHTML = html;
  }

  function tableHtml(t) {
    return '<div class="cry-table-wrap"><table class="cry-table cry-doc-table"><thead><tr>' + t.head.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      t.rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>';
  }

  function quizHtml(qs, prefix) {
    return qs.map(function (q, i) {
      return '<div class="cry-q" data-q="' + i + '"><p class="cry-q-title"><span>' + (prefix || 'Q') + (i + 1) + '</span>' + esc(q.q) + '</p><div class="cry-q-opts">' +
        q.opts.map(function (o, k) { return '<button type="button" class="cry-opt" data-opt="' + k + '">' + esc(o) + '</button>'; }).join('') +
        '</div><p class="cry-q-why" hidden></p></div>';
    }).join('');
  }
  // 綁定作答：每題只能答一次；全部答完呼叫 onDone(答對題數)
  function bindQuiz(box, qs, onDone) {
    var answered = 0, right = 0;
    box.addEventListener('click', function (e) {
      var b = e.target.closest('.cry-opt');
      if (!b) return;
      var qel = b.closest('.cry-q');
      if (!qel || qel.classList.contains('answered')) return;
      var q = qs[parseInt(qel.getAttribute('data-q'), 10)], pick = parseInt(b.getAttribute('data-opt'), 10);
      qel.classList.add('answered');
      CRY.$$('.cry-opt', qel).forEach(function (o, k) { o.disabled = true; if (k === q.a) o.classList.add('right'); });
      var ok = pick === q.a;
      if (!ok) b.classList.add('wrong'); else right++;
      var why = CRY.$('.cry-q-why', qel);
      why.hidden = false;
      why.textContent = (ok ? '✅ 答對了！' : '❌ 正確答案是「' + q.opts[q.a] + '」。') + q.why;
      answered++;
      if (answered === qs.length && onDone) onDone(right);
    });
  }

  function renderLesson(root, args) {
    var l = CRY.byId(CRY.LESSONS, args[0]);
    if (!l) { root.innerHTML = '<div class="cry-empty">找不到這堂課。<a href="#/learn">回課程列表</a></div>'; return; }
    var t = CRY.trackOf(l.track), ls = CRY.lessonsOf(l.track), idx = ls.indexOf(l);
    var all = CRY.LESSONS, gi = all.indexOf(l), prev = all[gi - 1], next = all[gi + 1];
    var done = CRY.progress.isDone(l.id);
    var terms = (l.terms || []).filter(function (x) { return CRY.glossMap[x]; });
    root.innerHTML =
      '<nav class="cry-crumb"><a href="#/learn">課程</a> › <a href="#/learn/' + t.id + '">' + t.icon + ' ' + esc(t.name) + '</a> › 第 ' + (idx + 1) + ' 堂</nav>' +
      '<article class="cry-article">' +
        '<header><h1>' + esc(l.title) + '</h1><p class="cry-lead">' + esc(l.summary) + '</p>' +
        '<div class="cry-lesson-meta"><i class="lv' + l.level + '">' + LEVEL[l.level] + '</i><span>約 ' + l.minutes + ' 分鐘</span><span>' + t.icon + ' ' + esc(t.name) + ' ' + (idx + 1) + ' / ' + ls.length + '</span></div></header>' +
        '<div class="cry-plain">' + esc(l.plain) + '</div>' +
        l.sections.map(function (s) {
          return '<section><h2>' + esc(s.h) + '</h2>' + CRY.paras(s.p) +
            (s.list ? '<ul>' + s.list.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' : '') + (s.table ? tableHtml(s.table) : '') + '</section>';
        }).join('') +
        '<div class="cry-takeaway">' + esc(l.takeaway) + '</div>' +
        (terms.length ? '<div class="cry-terms"><b>📖 本課名詞</b>' + terms.map(function (x) { return '<button type="button" class="cry-chip" data-term="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div>' : '') +
        '<section class="cry-quiz"><h2>📝 隨堂測驗</h2><div id="lessonQuiz">' + quizHtml(l.quiz) + '</div><p class="cry-quiz-result" id="lessonQuizResult" hidden></p></section>' +
        '<div class="cry-lesson-foot">' +
          (prev ? '<a class="cry-btn" href="#/lesson/' + prev.id + '">← ' + esc(prev.title) + '</a>' : '<span></span>') +
          '<button type="button" class="cry-btn ' + (done ? 'done' : 'primary') + '" id="doneBtn">' + (done ? '✓ 已完成（點此取消）' : '✓ 標記為已完成') + '</button>' +
          (next ? '<a class="cry-btn" href="#/lesson/' + next.id + '">' + esc(next.title) + ' →</a>' : '<a class="cry-btn" href="#/quiz">🎓 挑戰總測驗 →</a>') +
        '</div></article>';
    bindQuiz(CRY.$('#lessonQuiz', root), l.quiz, function (right) {
      CRY.progress.setQuiz(l.id, right);
      var r = CRY.$('#lessonQuizResult', root);
      r.hidden = false;
      r.textContent = right === l.quiz.length ? '🎉 全部答對！這堂課已自動標記為完成。' : '答對 ' + right + ' / ' + l.quiz.length + ' 題。回頭再看一次課文，重新整理頁面可以再作答一次。';
      if (right === l.quiz.length && !CRY.progress.isDone(l.id)) { CRY.progress.setDone(l.id, true); syncDone(); }
    });
    function syncDone() {
      var b = CRY.$('#doneBtn', root), d = CRY.progress.isDone(l.id);
      b.className = 'cry-btn ' + (d ? 'done' : 'primary');
      b.textContent = d ? '✓ 已完成（點此取消）' : '✓ 標記為已完成';
    }
    CRY.$('#doneBtn', root).addEventListener('click', function () {
      CRY.progress.setDone(l.id, !CRY.progress.isDone(l.id));
      syncDone();
      if (CRY.progress.isDone(l.id)) CRY.toast('✓ 已完成：' + l.title);
    });
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-term]');
      if (b) CRY.showTerm(b.getAttribute('data-term'));
    });
  }

  CRY.showTerm = function (term) {
    var g = CRY.glossMap[term];
    if (!g) return;
    var cat = CRY.byId(CRY.GLOSS_CATS, g.cat);
    CRY.openModal('<div class="cry-term-modal"><span class="cry-tag">' + esc(cat ? cat.name : '') + '</span><h3>' + esc(g.term) + ' <small>' + esc(g.en) + '</small></h3><p>' + esc(g.def) + '</p>' +
      (g.eg ? '<p class="cry-eg">💡 ' + esc(g.eg) + '</p>' : '') + '<a class="cry-link" href="#/glossary" data-close-modal>打開名詞辭典 →</a></div>');
  };

  // ---------- 總測驗 ----------
  var quizState = { track: 'all' };
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  function renderQuiz(root) {
    var best = CRY.store.get('quiz_best.v1', {});
    var chips = '<button type="button" class="cry-chip' + (quizState.track === 'all' ? ' on' : '') + '" data-qtrack="all">綜合</button>' +
      CRY.TRACKS.map(function (t) { return '<button type="button" class="cry-chip' + (quizState.track === t.id ? ' on' : '') + '" data-qtrack="' + t.id + '">' + t.icon + ' ' + esc(t.name) + '</button>'; }).join('');
    var pool = [];
    CRY.LESSONS.forEach(function (l) { if (quizState.track === 'all' || l.track === quizState.track) l.quiz.forEach(function (q) { pool.push({ q: q, l: l }); }); });
    var picked = shuffle(pool.slice()).slice(0, 10);
    var qs = picked.map(function (x) { return x.q; });
    var b = best[quizState.track];
    root.innerHTML = '<h1 class="cry-h1">📝 總測驗</h1><p class="cry-muted">從題庫（共 ' + pool.length + ' 題）隨機抽 ' + qs.length + ' 題，答完立刻看解析。' + (b != null ? '這個範圍的最佳成績：' + b + ' 分。' : '') + '</p>' +
      '<div class="cry-chips cry-chips-scroll">' + chips + '</div>' +
      (qs.length ? '<div class="cry-quiz cry-card" id="bigQuiz">' + quizHtml(qs) + '</div><div class="cry-quiz-result" id="bigQuizResult" hidden></div>' : '<div class="cry-empty">題庫準備中。</div>');
    root.addEventListener('click', function (e) {
      var c = e.target.closest('[data-qtrack]');
      if (c) { quizState.track = c.getAttribute('data-qtrack'); CRY.rerender(); return; }
      if (e.target.closest('[data-requiz]')) CRY.rerender();
    });
    if (!qs.length) return;
    bindQuiz(CRY.$('#bigQuiz', root), qs, function (right) {
      var score = Math.round(right * 100 / qs.length);
      var all = CRY.store.get('quiz_best.v1', {});
      all[quizState.track] = Math.max(score, all[quizState.track] || 0);
      CRY.store.set('quiz_best.v1', all);
      var wrongLessons = [];
      CRY.$$('.cry-q', root).forEach(function (el, i) { if (CRY.$('.cry-opt.wrong', el)) { var l = picked[i].l; if (wrongLessons.indexOf(l) < 0) wrongLessons.push(l); } });
      var r = CRY.$('#bigQuizResult', root);
      r.hidden = false;
      r.innerHTML = '<b>' + score + ' 分</b>（答對 ' + right + ' / ' + qs.length + ' 題）' + (score === 100 ? ' 🎉 滿分！' : '') +
        (wrongLessons.length ? '<div class="cry-review">建議複習：' + wrongLessons.map(function (l) { return '<a class="cry-chip" href="#/lesson/' + l.id + '">' + esc(l.title) + '</a>'; }).join('') + '</div>' : '') +
        '<button type="button" class="cry-btn primary" data-requiz>🔁 再抽一份</button>';
      r.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  CRY.route('learn', renderLearn);
  CRY.route('lesson', renderLesson);
  CRY.route('quiz', renderQuiz);
})();
