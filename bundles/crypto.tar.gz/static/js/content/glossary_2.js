(function () {
  'use strict';
  var CRY = (window.CRY = window.CRY || {});
  CRY.GLOSSARY = CRY.GLOSSARY || [];

  // ── DeFi ──
  CRY.GLOSSARY.push({ term: 'DeFi', en: 'Decentralized Finance', cat: 'defi', def: '去中心化金融。把存款、借錢、換匯這些銀行業務，改由鏈上的智慧合約自動執行，像一台不打烊、沒有行員的金融自動販賣機。少了中間人，但程式出錯或被駭時也沒有客服能幫你追回。' });
  CRY.GLOSSARY.push({ term: 'DEX', en: 'Decentralized Exchange', cat: 'defi', def: '簡稱 DEX。不用註冊帳號，直接用自己的錢包和智慧合約換幣，資產全程由自己保管；相對地，操作失誤也得自己負責。', eg: '例：Uniswap、PancakeSwap。' });
  CRY.GLOSSARY.push({ term: 'AMM', en: 'Automated Market Maker', cat: 'defi', def: '自動造市商。不靠買賣雙方掛單撮合，而是用數學公式依池子裡兩種幣的比例自動報價，像一台會自己調整匯率的換幣機。' });
  CRY.GLOSSARY.push({ term: '資金池', en: 'Liquidity Pool', cat: 'defi', def: '大家把兩種幣成對存進智慧合約形成的「公共換幣水池」。想換幣的人直接跟池子換，池子越深，大額交易的價格越不容易被推動。' });
  CRY.GLOSSARY.push({ term: '流動性提供者', en: 'Liquidity Provider (LP)', cat: 'defi', def: '把幣存進流動性池的人，簡稱 LP。好比出資讓換匯櫃檯有錢可換，可分到交易手續費，但要承擔無常損失與合約風險。' });
  CRY.GLOSSARY.push({ term: '無常損失', en: 'Impermanent Loss', cat: 'defi', def: '把幣放進流動性池後，若兩種幣的相對價格變動，領回時的總價值會比「單純放著不動」少，差額就是無常損失。價格偏離越多，損失越大，手續費收入不一定補得回來。' });
  CRY.GLOSSARY.push({ term: '滑價', en: 'Slippage', cat: 'defi', def: '又稱滑點。下單時預期的價格與實際成交價格的落差。池子太淺或單子太大時特別明顯，就像在小攤一次買光水果，越買越貴。', eg: '錢包裡的「滑價容忍度」設太高，容易被三明治攻擊。' });
  CRY.GLOSSARY.push({ term: '借貸協議', en: 'Lending Protocol', cat: 'defi', def: '鏈上的自動當鋪。存幣的人賺利息，借幣的人先押上抵押品才能借，利率由程式依供需即時調整。', eg: '例：Aave、Compound。' });
  CRY.GLOSSARY.push({ term: '超額抵押', en: 'Over-collateralization', cat: 'defi', def: '借出的金額必須低於抵押品價值。因為鏈上不查信用、也不認識你，只能靠多押一點來保護出借人，例如押價值 150 元的幣只能借 100 元。' });
  CRY.GLOSSARY.push({ term: '清算', en: 'Liquidation', cat: 'defi', def: '抵押品價格下跌到不足以擔保借款時，協議會自動把抵押品折價賣掉還債，借款人還要付一筆罰金。就像當鋪在典當品跌價時直接變賣。' });
  CRY.GLOSSARY.push({ term: '閃電貸', en: 'Flash Loan', cat: 'defi', def: '不需抵押、但必須在同一筆交易內借出並還清的貸款；還不出來，整筆交易就當作沒發生。常用於套利，也常被駭客拿來放大攻擊資金。' });
  CRY.GLOSSARY.push({ term: '流動性挖礦', en: 'Yield Farming', cat: 'defi', def: '把幣存進 DeFi 協議提供流動性，換取手續費與協議額外發放的代幣獎勵。報酬看似很高，但獎勵代幣可能大跌，還有無常損失與合約被駭的風險。' });
  CRY.GLOSSARY.push({ term: 'APY', en: 'Annual Percentage Yield', cat: 'defi', def: '把報酬換算成一年的比率。APR 不含複利，APY 含利滾利。數字會隨時變動，不是保證；高得不合理的年化，通常代表高風險甚至是騙局。' });
  CRY.GLOSSARY.push({ term: 'TVL', en: 'Total Value Locked', cat: 'defi', def: '總鎖倉價值。使用者存放在某個 DeFi 協議或某條鏈上的資產總值，常用來衡量規模與人氣，類似銀行的「存款總額」，但會隨幣價起伏。' });
  CRY.GLOSSARY.push({ term: '預言機', en: 'Oracle', cat: 'defi', def: '區塊鏈自己看不到外面的世界，預言機負責把幣價、天氣、比賽結果等鏈外資料送上鏈，像是替智慧合約跑腿報消息的人。報錯價格可能引發錯誤清算。', eg: '例：Chainlink。' });
  CRY.GLOSSARY.push({ term: '跨鏈橋', en: 'Cross-chain Bridge', cat: 'defi', def: '把資產從一條鏈搬到另一條鏈的工具。常見做法是在原鏈鎖住資產、在目標鏈發出等值憑證。橋上鎖了大量資金，歷來是駭客最愛下手的目標之一。' });
  CRY.GLOSSARY.push({ term: '流動性質押', en: 'Liquid Staking', cat: 'defi', def: '質押時拿到一張可自由轉讓的「質押收據代幣」，原本被鎖住的資產因此還能拿去交易或使用。收據代幣的價格有可能與原資產脫鉤。', eg: '例：Lido 的 stETH。' });
  CRY.GLOSSARY.push({ term: '再質押', en: 'Restaking', cat: 'defi', def: '把已經質押的資產再拿去替其他服務做擔保，多賺一份獎勵。一份資產背多份責任，出事時被罰沒的風險也跟著疊加。', eg: '例：EigenLayer。' });
  CRY.GLOSSARY.push({ term: 'RWA', en: 'Real World Assets', cat: 'defi', def: '現實世界資產代幣化。把公債、房地產、黃金等實體資產的權利做成鏈上代幣，方便分割與轉讓；但仍需仰賴發行機構誠實保管與法律保障。' });
  CRY.GLOSSARY.push({ term: 'MEV', en: 'Maximal Extractable Value', cat: 'defi', def: '最大可提取價值。負責排序交易的人（或機器人）靠著插隊、調換交易順序額外賺到的錢，好比排隊結帳時有人付小費給店員先結。' });

  // ── 交易與市場 ──
  CRY.GLOSSARY.push({ term: '中心化交易所', en: 'CEX', cat: 'trade', def: '由公司經營的交易平台，需註冊並通過身分驗證。操作像網路銀行一樣方便，但幣是交給平台保管，平台倒閉或被駭時可能領不出來。', eg: '2022 年 11 月 FTX 破產，大量客戶資產遭凍結。' });
  CRY.GLOSSARY.push({ term: '現貨', en: 'Spot', cat: 'trade', def: '一手交錢、一手交幣的買賣，買到的就是真正的幣，可以提領到自己的錢包。沒有槓桿，最多虧掉投入的本金。' });
  CRY.GLOSSARY.push({ term: '合約交易', en: 'Futures / Derivatives', cat: 'trade', def: '不實際持有幣，而是對未來價格漲跌下注的契約交易，通常會搭配槓桿。賺賠都被放大，新手虧光本金的情況相當常見。' });
  CRY.GLOSSARY.push({ term: '永續合約', en: 'Perpetual Contract', cat: 'trade', def: '沒有到期日的合約，可以一直持有。靠「資金費率」讓合約價格貼近現貨價，是加密貨幣市場交易量最大的衍生性商品之一。' });
  CRY.GLOSSARY.push({ term: '資金費率', en: 'Funding Rate', cat: 'trade', def: '永續合約多空雙方每隔一段時間互相支付的費用。合約價高於現貨時，做多的人付錢給做空的人，反之亦然，藉此把價格拉回現貨附近。' });
  CRY.GLOSSARY.push({ term: '槓桿', en: 'Leverage', cat: 'trade', def: '向平台借錢放大部位。10 倍槓桿代表用 1 元操作 10 元，價格對你有利時賺 10 倍，反向只要約 10% 就可能把本金賠光。' });
  CRY.GLOSSARY.push({ term: '保證金', en: 'Margin', cat: 'trade', def: '開槓桿部位時押在平台的本金，像租車的押金。虧損會先從保證金扣，低於門檻時平台會要求補錢，否則強制平倉。' });
  CRY.GLOSSARY.push({ term: '強制平倉', en: 'Forced Liquidation', cat: 'trade', def: '俗稱爆倉。槓桿交易虧損到保證金不夠時，平台強制把部位賣掉，押的本金幾乎歸零。槓桿越高，離強制平倉的價格越近。' });
  CRY.GLOSSARY.push({ term: '做多', en: 'Long', cat: 'trade', def: '看好價格上漲而買進，漲了獲利、跌了虧損。現貨買幣就是最單純的做多。' });
  CRY.GLOSSARY.push({ term: '做空', en: 'Short', cat: 'trade', def: '看壞價格而先借幣賣出、日後低價買回還清，賺取中間價差。價格若不跌反漲，理論上虧損沒有上限，風險比做多更高。' });
  CRY.GLOSSARY.push({ term: '市價單', en: 'Market Order', cat: 'trade', def: '不指定價格、以當下市場最好的價格立刻成交。優點是快，缺點是行情劇烈或流動性差時，成交價可能比預期差很多。' });
  CRY.GLOSSARY.push({ term: '限價單', en: 'Limit Order', cat: 'trade', def: '自己指定價格掛單，到價才成交。像跟老闆說「降到 100 元我才買」，價格有保障，但不保證買得到。' });
  CRY.GLOSSARY.push({ term: '停損', en: 'Stop Loss', cat: 'trade', def: '事先設好一個價格，跌到就自動賣出，把虧損控制在可承受範圍。好比進賭場前先決定「最多輸多少就離開」。' });
  CRY.GLOSSARY.push({ term: '掛單簿', en: 'Order Book', cat: 'trade', def: '交易所裡所有還沒成交的買單與賣單清單，依價格排列。買賣雙方報價越密集、數量越多，代表這個市場越容易成交。' });
  CRY.GLOSSARY.push({ term: '交易對', en: 'Trading Pair', cat: 'trade', def: '兩種資產互換的組合，寫成 BTC/USDT 表示用 USDT 買賣比特幣，就像外匯的「美元兌新臺幣」。' });
  CRY.GLOSSARY.push({ term: '市值', en: 'Market Cap', cat: 'trade', def: '幣價乘以流通中的數量，用來比較各幣種的規模。單價便宜不代表「便宜」，要看市值才知道整體估值高低。', eg: '單價 1 元、發行 1 兆枚的幣，市值比單價 1 萬元、發行 100 萬枚的幣大得多。' });
  CRY.GLOSSARY.push({ term: 'FDV', en: 'Fully Diluted Valuation', cat: 'trade', def: '完全稀釋估值。假設所有代幣（含尚未解鎖的）都已流通，用現價算出的總價值。若遠高於市值，代表未來還有大量代幣會解鎖，可能帶來賣壓。' });
  CRY.GLOSSARY.push({ term: '流動性', en: 'Liquidity', cat: 'trade', def: '資產能多快、多容易以合理價格買賣的程度。流動性好像熱鬧的傳統市場，隨時有人接手；流動性差的幣，想賣時可能找不到買家。' });
  CRY.GLOSSARY.push({ term: 'K線', en: 'Candlestick Chart', cat: 'trade', def: '用一根根「蠟燭」呈現一段時間內開盤、收盤、最高、最低四個價格的圖表。它記錄的是過去，無法保證預測未來走勢。' });
  CRY.GLOSSARY.push({ term: '牛市', en: 'Bull Market', cat: 'trade', def: '市場長時間整體上漲、氣氛樂觀的時期，取自公牛用角往上頂。此時最容易因過度樂觀而追高、開高槓桿。' });
  CRY.GLOSSARY.push({ term: '熊市', en: 'Bear Market', cat: 'trade', def: '市場長時間整體下跌、氣氛悲觀的時期，取自熊用掌往下拍。加密貨幣在熊市中從高點下跌超過七成並不罕見。' });
  CRY.GLOSSARY.push({ term: '定期定額', en: 'DCA', cat: 'trade', def: '每隔固定時間投入固定金額，不猜高低點，藉此分散買進成本。可以降低擇時壓力，但標的若長期下跌，一樣會虧損。' });
  CRY.GLOSSARY.push({ term: '部位控管', en: 'Position Sizing', cat: 'trade', def: '決定每一筆投資最多投入多少資金的紀律，像出門只帶固定金額的零用錢。單一標的不押太重，判斷錯誤時才不會傷到根本。' });
  CRY.GLOSSARY.push({ term: '場外交易', en: 'OTC', cat: 'trade', def: '不透過交易所公開掛單，由買賣雙方私下議價成交，常見於大額交易。對象若不是合規業者，容易遇到詐騙或收到來源有問題的資金。' });
  CRY.GLOSSARY.push({ term: '恐懼貪婪指數', en: 'Fear & Greed Index', cat: 'trade', def: '把波動、成交量、社群熱度等資料綜合成 0 到 100 的分數，數字越低代表市場越恐懼、越高越貪婪。只是情緒溫度計，不能預測漲跌。' });
  CRY.GLOSSARY.push({ term: '現貨 ETF', en: 'Spot ETF', cat: 'trade', def: '在證券交易所掛牌、由發行商實際買進並保管加密貨幣的基金，用證券戶就能間接投資。美國於 2024 年 1 月核准首批比特幣現貨 ETF。價格仍隨幣價波動，並須支付管理費。' });
  CRY.GLOSSARY.push({ term: '複委託', en: 'Sub-brokerage', cat: 'trade', def: '透過台灣的券商下單買賣海外掛牌的股票或 ETF。部分投資人可用這個管道買海外的加密貨幣 ETF，資格與限制依主管機關規定，另有手續費與匯率成本。' });

  // ── 資安 ──
  CRY.GLOSSARY.push({ term: '冷錢包', en: 'Cold Wallet', cat: 'sec', def: '私鑰存放在不連網環境的錢包，像放在家裡的保險箱。駭客難以遠端偷走，適合長期存放；但裝置或助記詞遺失、毀損，資產一樣拿不回來。' });
  CRY.GLOSSARY.push({ term: '熱錢包', en: 'Hot Wallet', cat: 'sec', def: '裝在手機或瀏覽器、隨時連網的錢包，像隨身帶的皮夾。使用方便，但較容易被惡意程式或釣魚網站盯上，建議只放日常小額。', eg: '例：MetaMask。' });
  CRY.GLOSSARY.push({ term: '硬體錢包', en: 'Hardware Wallet', cat: 'sec', def: '專門用來保管私鑰的實體小裝置，是最常見的冷錢包。簽署交易時私鑰不會離開裝置。務必向官方管道購買，避免買到被動過手腳的機器。', eg: '例：Ledger、Trezor。' });
  CRY.GLOSSARY.push({ term: '自我託管', en: 'Self-custody', cat: 'sec', def: '自己保管私鑰，不把幣交給交易所。圈內名言是「不是你的私鑰，就不是你的幣」。自由度最高，但弄丟或外洩都沒有人能幫你救回。' });
  CRY.GLOSSARY.push({ term: '託管', en: 'Custody', cat: 'sec', def: '把資產交給別人代為保管，例如把幣放在交易所。方便、忘記密碼還能找客服，但保管方若倒閉、被駭或挪用，你的資產就可能受損。' });
  CRY.GLOSSARY.push({ term: '授權', en: 'Token Approval', cat: 'sec', def: '允許某個智慧合約動用你錢包裡特定代幣的許可，像把提款卡副卡交給店家。若授權「無限額度」給惡意合約，對方可以直接把該代幣轉光。' });
  CRY.GLOSSARY.push({ term: '撤銷授權', en: 'Revoke', cat: 'sec', def: '把先前給智慧合約的代幣動用許可取消，等於把副卡收回來。定期檢查並撤銷不再使用的授權，是基本的錢包衛生習慣。' });
  CRY.GLOSSARY.push({ term: '釣魚', en: 'Phishing', cat: 'sec', def: '歹徒假冒官方網站、客服或空投活動，誘騙你輸入助記詞或簽下惡意交易。記住：任何人、任何網站向你要助記詞，就是詐騙。' });
  CRY.GLOSSARY.push({ term: '位址投毒', en: 'Address Poisoning', cat: 'sec', def: '歹徒用頭尾幾碼和你常用位址很像的假位址，轉一筆極小額給你，等你日後從交易紀錄複製到假位址而轉錯。轉帳前要完整核對整串位址。' });
  CRY.GLOSSARY.push({ term: '小額測試', en: 'Test Transaction', cat: 'sec', def: '大額轉帳前，先轉一筆很小的金額，確認對方真的收到再轉剩下的。多花一點手續費，換來避免轉錯位址或選錯鏈的保險。' });
  CRY.GLOSSARY.push({ term: '捲款跑路', en: 'Rug Pull', cat: 'sec', def: '專案團隊吸引大家投入資金後，突然抽走流動性池的錢或拋售代幣後消失，幣價瞬間歸零。英文原意是「把你腳下的地毯抽走」。' });
  CRY.GLOSSARY.push({ term: '貔貅盤', en: 'Honeypot', cat: 'sec', def: '合約被動過手腳、只能買不能賣的騙局代幣。因傳說中貔貅只進不出而得名。圖表看起來一路上漲，其實是因為沒有人賣得掉。' });
  CRY.GLOSSARY.push({ term: '龐氏騙局', en: 'Ponzi Scheme', cat: 'sec', def: '拿後面加入者的錢，當成「獲利」發給前面的人，本身並沒有真正的收入來源。一旦新資金跟不上就會崩盤。標榜固定高報酬、拉人頭有獎金是典型警訊。' });
  CRY.GLOSSARY.push({ term: '殺豬盤', en: 'Pig-butchering Scam', cat: 'sec', def: '詐騙集團先在交友軟體或社群上長期培養感情與信任，再引導受害者到假投資平台入金，最後連本帶利領不出來。' });
  CRY.GLOSSARY.push({ term: '兩步驟驗證', en: '2FA', cat: 'sec', def: '又稱雙重驗證。登入時除了密碼，還要再輸入一組一次性驗證碼，等於多上一道鎖。建議使用驗證器 App 或實體金鑰；簡訊驗證碼可能因門號被冒辦而遭攔截。' });
  CRY.GLOSSARY.push({ term: '三明治攻擊', en: 'Sandwich Attack', cat: 'sec', def: '機器人發現你的大額換幣單後，搶在你前面買進墊高價格，等你成交後立刻賣出，把你夾在中間賺價差。把滑價容忍度設低可減少損失。' });
  CRY.GLOSSARY.push({ term: '女巫攻擊', en: 'Sybil Attack', cat: 'sec', def: '一個人假造大量身分或錢包，假裝成很多人，藉此灌票、影響網路或多領空投，像一人申請幾百個帳號重複領贈品。' });
  CRY.GLOSSARY.push({ term: '審計', en: 'Smart Contract Audit', cat: 'sec', def: '請第三方資安公司檢查智慧合約程式碼有沒有漏洞，類似建築物的結構安全檢查。有審計比沒有好，但不代表絕對安全，審計過的協議也曾被駭。' });
  CRY.GLOSSARY.push({ term: '儲備證明', en: 'Proof of Reserves', cat: 'sec', def: '交易所公開鏈上錢包與密碼學證明，讓外界核對它是否真的持有足額的客戶資產。2022 年 FTX 倒閉後開始普及，但通常看不到平台的全部負債。' });

  // ── 幣圈文化用語 ──
  CRY.GLOSSARY.push({ term: 'HODL', en: 'Hold On for Dear Life', cat: 'culture', def: '長期持有、不論漲跌都不賣的意思。源自 2013 年比特幣論壇上一位網友把 hold 打錯成 hodl 的貼文，後來才被附會成「死命抱住」的縮寫。' });
  CRY.GLOSSARY.push({ term: 'FOMO', en: 'Fear of Missing Out', cat: 'culture', def: '錯失恐懼。看到別人賺錢、怕自己沒跟上而衝動買進的心態。價格漲最兇、大家最興奮的時候，往往也是追高風險最大的時候。' });
  CRY.GLOSSARY.push({ term: 'FUD', en: 'Fear, Uncertainty, Doubt', cat: 'culture', def: '恐懼、不確定、懷疑。指讓市場恐慌的負面消息或謠言，有時是真風險，有時是刻意散布。重點是回頭查證來源，而不是跟著情緒走。' });
  CRY.GLOSSARY.push({ term: 'DYOR', en: 'Do Your Own Research', cat: 'culture', def: '自己做功課。提醒大家不要只聽別人說，要自己查證團隊、代幣分配與風險。不過它也常被喊單的人拿來當免責聲明。' });
  CRY.GLOSSARY.push({ term: '韭菜', en: 'Retail Bag Holder', cat: 'culture', def: '指經驗不足、容易追高殺低而賠錢的散戶。因為韭菜割了還會再長，比喻一批批新手不斷進場被「收割」。被割就叫「割韭菜」。' });
  CRY.GLOSSARY.push({ term: '巨鯨', en: 'Whale', cat: 'culture', def: '持有大量加密貨幣的個人或機構。就像鯨魚一翻身就掀起大浪，他們的大額買賣足以影響價格，鏈上動向常被市場追蹤。' });
  CRY.GLOSSARY.push({ term: '鑽石手', en: 'Diamond Hands', cat: 'culture', def: '形容不管價格怎麼暴跌都堅持不賣的人，手像鑽石一樣硬。反義詞是一跌就賣的「紙手」。但死抱一個基本面出問題的幣，同樣可能血本無歸。' });
  CRY.GLOSSARY.push({ term: '抄底', en: 'Buy the Dip', cat: 'culture', def: '趁價格大跌時買進，期待之後反彈。問題是沒有人知道底在哪裡，圈內常自嘲「抄底抄在半山腰」。' });
  CRY.GLOSSARY.push({ term: '追高殺低', en: 'Buy High, Sell Low', cat: 'culture', def: '看到大漲才急著買進、看到大跌又恐慌賣出，結果買在高點、賣在低點。這是被情緒牽著走的典型虧損模式。' });
  CRY.GLOSSARY.push({ term: 'All in', en: 'All In (Show Hand)', cat: 'culture', def: '幣圈用語，俗稱「梭哈」，指把全部資金一次押在單一標的上，源自撲克牌的「全押」。這是風險極高的賭博式做法，一次判斷錯誤就可能賠光所有本金。' });
  CRY.GLOSSARY.push({ term: '擼毛', en: 'Airdrop Farming', cat: 'culture', def: '為了領空投而刻意大量使用新專案的行為，取「薅羊毛」之意。要付出手續費與時間，最後不一定領得到，也容易誤觸釣魚網站。' });
  CRY.GLOSSARY.push({ term: '喊單', en: 'Shilling', cat: 'culture', def: '網紅或社群裡的人公開鼓吹大家買某個幣。喊的人可能早已買好、甚至收了專案的錢，等你進場他就出場。看到喊單，先問對方有什麼利益。' });
  CRY.GLOSSARY.push({ term: '敘事', en: 'Narrative', cat: 'culture', def: '市場上一段時間內大家熱烈談論的題材或故事，例如某類新技術或新應用。敘事能帶動資金與話題，但熱度退去時，價格也常跟著回落。' });

  // ── 法規 ──
  CRY.GLOSSARY.push({ term: '實名驗證', en: 'KYC', cat: 'reg', def: '認識你的客戶。交易所開戶時要求上傳證件、自拍來確認身分，和去銀行開戶要帶雙證件是同樣道理，目的是防止人頭帳戶與犯罪。' });
  CRY.GLOSSARY.push({ term: '洗錢防制', en: 'AML', cat: 'reg', def: '洗錢防制。防止犯罪所得被「洗」成看似合法資金的一整套規定，包含身分驗證、監控可疑交易並向主管機關申報。' });
  CRY.GLOSSARY.push({ term: 'VASP', en: 'Virtual Asset Service Provider', cat: 'reg', def: '虛擬資產服務提供者。交易所、代買代賣的幣商、保管業者等的法規統稱。在台灣必須依法向金管會完成洗錢防制登記才能營業。' });
  CRY.GLOSSARY.push({ term: 'FATF', en: 'Financial Action Task Force', cat: 'reg', def: '防制洗錢金融行動工作組織。1989 年成立的跨國組織，負責訂定全球洗錢防制標準並評鑑各國，各國的加密貨幣洗錢防制規定多以它的建議為藍本。' });
  CRY.GLOSSARY.push({ term: '轉帳規則', en: 'Travel Rule', cat: 'reg', def: 'FATF 在 2019 年要求適用於虛擬資產的規定：業者之間轉帳時，匯款人與收款人的身分資料要跟著交易一起傳遞，像匯款單上必須填寫雙方姓名。' });
  CRY.GLOSSARY.push({ term: 'MiCA', en: 'Markets in Crypto-Assets', cat: 'reg', def: '歐盟的加密資產市場規範，是全球第一部大型經濟體的完整加密貨幣法規。穩定幣相關規定自 2024 年 6 月底適用，服務商規定自 2024 年 12 月底適用。' });
  CRY.GLOSSARY.push({ term: 'GENIUS法案', en: 'GENIUS Act', cat: 'reg', def: '美國於 2025 年 7 月簽署生效的聯邦穩定幣法律，要求支付型穩定幣發行商持有一比一的高流動性準備資產，並定期公開揭露。' });
  CRY.GLOSSARY.push({ term: '虛擬資產服務法', en: 'Taiwan Virtual Assets Service Act', cat: 'reg', def: '台灣管理虛擬資產業者的專法，立法院於 2026 年三讀通過。業者將由洗錢防制登記制改為須取得金管會許可，並納入穩定幣發行管理；施行日期由行政院另定。' });
  CRY.GLOSSARY.push({ term: '豪威測試', en: 'Howey Test', cat: 'reg', def: '美國用來判斷一項商品算不算「證券」的標準，源自 1946 年最高法院判例：投入資金、參與共同事業、期待靠他人努力獲利。代幣若符合，就要受證券法規範。' });
  CRY.GLOSSARY.push({ term: '資產分離保管', en: 'Asset Segregation', cat: 'reg', def: '規定業者必須把客戶的資產和公司自己的錢分開存放，不得挪用。就像房仲代收的訂金不能拿去付公司房租，業者出事時客戶資產才有保障。' });
  CRY.GLOSSARY.push({ term: '保管機構', en: 'Custodian', cat: 'reg', def: '專門替客戶保管資產的受監管機構，像銀行保管箱的角色。ETF 發行商與大型機構多半把加密貨幣交給這類業者存放，仍須留意其資安與財務狀況。' });
})();
