(function () {
  'use strict';
  var CRY = (window.CRY = window.CRY || {});
  CRY.GLOSSARY = CRY.GLOSSARY || [];

  // ── 以太坊擴容與標準 ──
  CRY.GLOSSARY.push({ term: 'ZK Rollup', en: 'Zero-Knowledge Rollup', cat: 'tech', def: 'Rollup 的一種路線。在第二層處理大量交易後，向主網提交一份零知識證明，用數學證明這批交易都算對了，主網驗證通過就定案，不必等待挑戰期。', eg: '例：zkSync、Starknet、Linea。' });
  CRY.GLOSSARY.push({ term: '排序器', en: 'Sequencer', cat: 'tech', def: 'Layer 2 上負責接收交易、決定先後順序並打包交回主網的角色。目前多數由單一團隊營運，一旦當機，交易可能暫時停擺，是使用 Layer 2 要留意的集中化風險。' });
  CRY.GLOSSARY.push({ term: 'Blob', en: 'Binary Large Object', cat: 'tech', def: 'EIP-4844 新增的一種資料空間，專門給 Layer 2 存放交易資料。它獨立計費，而且只保留一段時間就會被節點清除，因此比寫進一般交易欄位便宜許多。' });
  CRY.GLOSSARY.push({ term: 'EIP-4844', en: 'Proto-Danksharding', cat: 'tech', def: '以太坊在 2024 年 3 月 Dencun 升級啟用的提案，又稱 Proto-Danksharding。它引進 Blob 資料空間，讓 Layer 2 把資料交回主網的成本大幅下降。' });
  CRY.GLOSSARY.push({ term: '帳戶抽象', en: 'Account Abstraction', cat: 'tech', def: '讓錢包像智慧合約一樣可以自訂規則的技術方向，例如用其他代幣付手續費、設定每日限額、遺失時由親友協助復原，目標是讓錢包用起來更接近一般應用程式。' });
  CRY.GLOSSARY.push({ term: 'ERC-4337', en: 'ERC-4337', cat: 'tech', def: '2023 年 3 月上線的帳戶抽象標準。不必修改以太坊底層，就能讓智慧合約錢包運作：使用者送出「操作請求」，由專門的打包者代為送上鏈。' });
  CRY.GLOSSARY.push({ term: 'EIP-7702', en: 'EIP-7702', cat: 'tech', def: '2025 年 5 月隨 Pectra 升級啟用的提案。讓既有的一般錢包也能把操作委派給一段合約程式碼，藉此獲得批次交易、代付手續費等功能；委派對象若有惡意，資產也可能被轉走。' });
  CRY.GLOSSARY.push({ term: '同質化代幣', en: 'Fungible Token', cat: 'coin', def: '每一枚都相同、可以互相替換的代幣，就像兩張百元鈔價值一樣、換來換去沒有差別。以太坊上最常見的標準是 ERC-20，與每個都獨一無二的 NFT 相對。' });
  CRY.GLOSSARY.push({ term: 'ERC-721', en: 'ERC-721', cat: 'coin', def: '以太坊上最常見的 NFT 標準。每個代幣都有獨一無二的編號，彼此不能互換，適合用來代表收藏品、門票或憑證這類「每個都不一樣」的東西。' });
  CRY.GLOSSARY.push({ term: 'ERC-1155', en: 'ERC-1155', cat: 'coin', def: '以太坊的多重代幣標準。同一份合約可以同時管理多種代幣，同質化與非同質化都行，還能一次批次轉移，常用在遊戲道具，比逐一發行更省手續費。' });
  CRY.GLOSSARY.push({ term: 'DAO', en: 'Decentralized Autonomous Organization', cat: 'defi', def: '去中心化自治組織。規則寫在智慧合約裡，重大決定由治理代幣的持有人投票，像一間沒有董事長的線上合作社。實務上投票權常集中在少數大戶手中。' });

  // ── 共識機制 ──
  CRY.GLOSSARY.push({ term: '拜占庭將軍問題', en: 'Byzantine Generals Problem', cat: 'tech', def: '1982 年提出的經典難題：幾位將軍只能靠信差聯絡，其中可能有叛徒傳假消息，要怎麼讓忠誠的將軍達成一致行動？區塊鏈的共識機制就是在解這個問題。' });
  CRY.GLOSSARY.push({ term: '拜占庭容錯', en: 'Byzantine Fault Tolerance (BFT)', cat: 'tech', def: '系統在部分成員故障甚至故意說謊的情況下，仍能達成正確共識的能力，簡稱 BFT。典型的設計可以容忍不到三分之一的節點作惡。' });
  CRY.GLOSSARY.push({ term: '質押', en: 'Staking', cat: 'tech', def: '在權益證明的鏈上，把幣鎖進網路當作押金，換取參與驗證並領取獎勵的資格。風險包括幣價下跌、解除質押要等待，以及驗證者違規時押金被罰沒。' });
  CRY.GLOSSARY.push({ term: '罰沒', en: 'Slashing', cat: 'tech', def: '權益證明的懲罰機制。驗證者若做出惡意行為，例如在同一位置簽出兩個互相矛盾的區塊，會被沒收部分押金並強制退出，讓作惡的代價高於好處。' });
  CRY.GLOSSARY.push({ term: '委託權益證明', en: 'Delegated Proof of Stake (DPoS)', cat: 'tech', def: '簡稱 DPoS。持幣人用手上的幣投票，選出少數代表輪流出塊，像選民代表開會。優點是速度快，代價是出塊權集中在少數節點手上。', eg: '例：EOS 由 21 個出塊節點輪流記帳。' });
  CRY.GLOSSARY.push({ term: '歷史證明', en: 'Proof of History (PoH)', cat: 'tech', def: 'Solana 採用的設計，簡稱 PoH。它像一個密碼學時鐘，用連續不斷的雜湊運算證明事件發生的先後順序，再搭配權益證明的投票來定案，本身不算獨立的共識機制。' });
  CRY.GLOSSARY.push({ term: '區塊重組', en: 'Chain Reorganization (Reorg)', cat: 'tech', def: '節點發現另一條更長（累積工作量更多）的鏈時，改用新鏈、捨棄原本最末幾個區塊的情況。被捨棄區塊裡的交易可能失效，這也是大額交易要多等幾個確認的原因。' });
  CRY.GLOSSARY.push({ term: '能耗', en: 'Energy Consumption', cat: 'tech', def: '指區塊鏈運作消耗的電力。工作量證明靠大量運算競爭記帳權，耗電可觀，是比特幣常被批評之處；權益證明不需要挖礦，耗電低得多。電力來源與實際影響尚有爭議。' });

  // ── DeFi 與代幣 ──
  CRY.GLOSSARY.push({ term: '去中心化交易所', en: 'Decentralized Exchange (DEX)', cat: 'defi', def: '簡稱 DEX。不必註冊帳號，直接用自己的錢包透過智慧合約換幣，資產全程由自己保管。沒有客服，換錯幣或遇到假代幣都得自行承擔。' });
  CRY.GLOSSARY.push({ term: 'LP 代幣', en: 'LP Token', cat: 'defi', def: '把幣存進資金池後拿到的憑證代幣，代表你在池子裡占的份額，像寄物櫃的號碼牌。之後憑它領回本金與分到的手續費，弄丟或被盜就等於失去這份資產。' });
  CRY.GLOSSARY.push({ term: '健康係數', en: 'Health Factor', cat: 'defi', def: '借貸協議用來表示部位安全程度的數字，大致是抵押品價值（打折後）除以借款價值。數字越高越安全，越接近 1 越危險，低於 1 就可能被清算。' });
  CRY.GLOSSARY.push({ term: '準備金', en: 'Reserves', cat: 'defi', def: '穩定幣發行商為了讓使用者隨時能換回法幣而持有的資產，常見的有現金與美國短期公債。準備金的品質與透明度，直接決定穩定幣能不能守住一比一的價格。' });
  CRY.GLOSSARY.push({ term: '十足準備', en: 'Full Reserve Backing', cat: 'reg', def: '發行多少穩定幣，就必須持有等值的高流動性資產作為準備，例如現金或短期公債，不能只準備一部分。這是各國穩定幣立法的共同核心要求。' });
  CRY.GLOSSARY.push({ term: '凍結', en: 'Freeze', cat: 'sec', def: '讓資產暫時無法動用。交易所可依執法機關要求凍結帳戶；USDT、USDC 等穩定幣的發行商也能把特定位址列入黑名單。自己保管的比特幣，則沒有人能代為凍結。' });
  CRY.GLOSSARY.push({ term: '代幣化', en: 'Tokenization', cat: 'defi', def: '把現實世界的資產或權利，例如國庫券、基金份額、不動產，做成區塊鏈上的代幣，方便分割與移轉。代幣背後是否真有資產、法律上能否主張權利，是評估重點。' });
  CRY.GLOSSARY.push({ term: '混幣器', en: 'Mixer', cat: 'sec', def: '把許多人的幣倒進同一個池子攪拌後再各自領回的服務，用來切斷資金來源與去向的關聯。它能保護隱私，但也常被駭客用來洗錢，在多國受到嚴格監管。', eg: '例：Tornado Cash 在 2022 年曾遭美國財政部制裁。' });
  CRY.GLOSSARY.push({ term: 'GameFi', en: 'Game Finance', cat: 'culture', def: '遊戲加上金融，指把代幣與 NFT 放進遊戲、號稱「邊玩邊賺」的模式。獎勵多半來自新玩家投入的資金，一旦新玩家變少，代幣價格與收益可能快速下滑。', eg: '例：2021 年爆紅、之後大幅降溫的 Axie Infinity。' });
  CRY.GLOSSARY.push({ term: '元宇宙', en: 'Metaverse', cat: 'culture', def: '泛指可以社交、遊戲、交易的線上虛擬世界。2021 年前後成為熱門題材，部分專案把虛擬土地做成 NFT 販售，熱潮退去後價格大幅回落，是題材炒作的典型案例。' });

  // ── 市場與鏈上資料 ──
  CRY.GLOSSARY.push({ term: '流通量', en: 'Circulating Supply', cat: 'trade', def: '目前已經發行、而且能在市場上自由買賣的代幣數量，與「流通供給量」同義。市值就是用單價乘以流通量算出來的，尚未解鎖的代幣不計入。' });
  CRY.GLOSSARY.push({ term: '解鎖', en: 'Token Unlock', cat: 'coin', def: '原本被鎖住、不能賣的代幣（多屬團隊與早期投資人），依預定時程開放轉移。解鎖會讓市場上可賣的數量增加，可能帶來賣壓，買進前應先查解鎖時程。' });
  CRY.GLOSSARY.push({ term: '鏈上數據', en: 'On-chain Data', cat: 'trade', def: '直接從區塊鏈公開紀錄整理出來的資料，例如活躍位址數、交易筆數、交易所的流入與流出量。任何人都能查證，但只能當作參考，無法用來準確預測價格。' });
  CRY.GLOSSARY.push({ term: '活躍位址', en: 'Active Addresses', cat: 'trade', def: '一段時間內有收款或付款紀錄的位址數量，用來觀察網路的使用熱度。要注意一個人可以擁有很多位址，交易所也會代替大量使用者收發，所以不等於真實人數。' });
  CRY.GLOSSARY.push({ term: '投機', en: 'Speculation', cat: 'trade', def: '主要著眼於短期價格漲跌而買賣，而不是看重資產本身的用途或長期價值。加密市場的投機氣氛濃厚，價格容易暴漲暴跌，投入前要先想好自己能承受多少損失。' });

  // ── 轉帳與資安 ──
  CRY.GLOSSARY.push({ term: '鏈別', en: 'Network', cat: 'sec', def: '指轉帳要走哪一條區塊鏈網路。同一種幣可能同時存在多條鏈上，出金與收款兩邊選的網路必須完全相同，選錯了資產可能無法入帳，甚至難以找回。', eg: '例：USDT 在以太坊、波場等多條鏈上都有發行。' });
  CRY.GLOSSARY.push({ term: 'Memo', en: 'Memo / Tag', cat: 'sec', def: '轉帳時附帶的備註碼，有些幣稱為 Tag。交易所常讓許多使用者共用同一個收款位址，再靠這組號碼分辨是誰的錢，漏填或填錯就可能無法自動入帳。', eg: '例：轉入 XRP、XLM 到交易所時，通常要填 Tag 或 Memo。' });
  CRY.GLOSSARY.push({ term: '假客服', en: 'Fake Customer Support', cat: 'sec', def: '詐騙者冒充交易所或錢包的客服人員。常見情境是你在社群公開求助後，對方主動私訊，接著索取助記詞或要你連到假網站。真正的客服不會主動私訊，也不會要助記詞。' });
  CRY.GLOSSARY.push({ term: '二次詐騙', en: 'Recovery Scam', cat: 'sec', def: '針對已經被騙的人再騙一次。對方自稱律師、駭客或追款公司，聲稱先付費就能把幣追回來，其實是另一場詐騙。沒有人能保證追回鏈上資產。' });
  CRY.GLOSSARY.push({ term: '人頭帳戶', en: 'Mule Account', cat: 'sec', def: '被詐騙集團拿來收款與洗錢的他人帳戶，包含銀行帳戶與交易所帳號，多半是用報酬或求職名義騙來、租來的。在台灣，無正當理由把帳戶交給他人使用，可能要負法律責任。' });
  CRY.GLOSSARY.push({ term: '警示帳戶', en: 'Alert Account (Taiwan)', cat: 'reg', def: '台灣的制度：檢警等機關因偵辦詐欺等案件，通報金融機構列管的帳戶。被列管後帳戶的交易功能會暫停，本人名下其他帳戶的使用也可能受到限制。' });

  // ── 法規 ──
  CRY.GLOSSARY.push({ term: 'CBDC', en: 'Central Bank Digital Currency', cat: 'reg', def: '央行數位貨幣。由中央銀行發行的數位形式法幣，價值與現金相同、由國家背書，和民間發行的穩定幣或比特幣不同。各國進度不一，隱私保護是常見的爭議。' });
  CRY.GLOSSARY.push({ term: 'SEC', en: 'U.S. Securities and Exchange Commission', cat: 'reg', def: '美國證券交易委員會，中文常稱證管會，負責監管證券市場。代幣若被認定為證券就歸它管，否則可能歸商品期貨交易委員會（CFTC），兩者的權責劃分是美國立法的焦點。' });
  CRY.GLOSSARY.push({ term: '牌照', en: 'License', cat: 'reg', def: '主管機關核發給業者的營業執照。拿到牌照代表業者通過資本、資安、洗錢防制等審查並持續受監督，但不等於保證不會出事，也不代表平台上的幣沒有風險。', eg: '例：香港要求虛擬資產交易平台向證監會申領牌照。' });
  CRY.GLOSSARY.push({ term: '許可制', en: 'Licensing Regime', cat: 'reg', def: '業者必須先向主管機關申請、通過審查並取得許可才能營業的管理方式，比只需完成登記的登記制嚴格。台灣對虛擬資產業者的管理，正從洗錢防制登記走向專法許可制。', eg: '另一個用法「許可制區塊鏈」，是指須獲准才能加入的聯盟鏈與私有鏈。' });
  CRY.GLOSSARY.push({ term: '財產交易所得', en: 'Income from Property Transactions', cat: 'reg', def: '台灣所得稅的一個類別，指出售財產賺到的差價。一般的理解是，個人買賣加密貨幣的獲利屬於這一類，應併入綜合所得稅申報；實際認定仍以稅捐機關的解釋為準。' });
})();
