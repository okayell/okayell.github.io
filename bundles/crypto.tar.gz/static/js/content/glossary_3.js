(function () {
  'use strict';
  var CRY = (window.CRY = window.CRY || {});
  CRY.GLOSSARY = CRY.GLOSSARY || [];

  // ── 基礎與密碼學 ──
  CRY.GLOSSARY.push({ term: '不可竄改', en: 'Immutability', cat: 'tech', def: '資料一旦寫進區塊鏈並經過足夠確認，就幾乎無法偷偷修改。因為每個區塊都記著前一塊的雜湊值，改動任何一筆，後面整串都會對不上，其他節點也不會接受。' });
  CRY.GLOSSARY.push({ term: '雜湊值', en: 'Hash Value', cat: 'tech', def: '把任意資料丟進雜湊函數後得到的一串固定長度代號，像資料的指紋。內容只要有一點不同，指紋就完全不同，而且無法從指紋反推原本的內容。' });
  CRY.GLOSSARY.push({ term: 'SHA-256', en: 'Secure Hash Algorithm 256-bit', cat: 'tech', def: '比特幣採用的雜湊演算法。不論輸入多長，輸出都是固定 256 位元的結果，常寫成 64 個十六進位字元。挖礦與區塊之間的串接都靠它。' });
  CRY.GLOSSARY.push({ term: '雪崩效應', en: 'Avalanche Effect', cat: 'tech', def: '雜湊函數的特性：輸入只改動一個字，輸出就變得面目全非，看不出任何相似之處。因此只要比對雜湊值，就能發現資料有沒有被動過手腳。' });
  CRY.GLOSSARY.push({ term: 'Merkle 樹', en: 'Merkle Tree', cat: 'tech', def: '把區塊內所有交易兩兩雜湊、一層層往上合併的樹狀結構，像賽程表一路比到冠軍。只要提供少數幾個雜湊值，就能證明某筆交易確實在區塊裡。' });
  CRY.GLOSSARY.push({ term: 'Merkle 根', en: 'Merkle Root', cat: 'tech', def: 'Merkle 樹最頂端的那一個雜湊值，等於整個區塊所有交易的總指紋，寫在區塊標頭裡。任何一筆交易被改動，Merkle 根就會跟著改變。' });
  CRY.GLOSSARY.push({ term: '非對稱式密碼學', en: 'Asymmetric Cryptography', cat: 'tech', def: '使用一對金鑰的密碼技術：私鑰自己保管、用來簽章，公鑰可以公開、讓別人驗證。好比只有你有印章，但人人都能核對印鑑，這是錢包運作的基礎。' });
  CRY.GLOSSARY.push({ term: '簽署', en: 'Signing', cat: 'tech', def: '用私鑰替一筆交易或訊息產生數位簽章的動作，等於親手蓋章表示「我同意」。錢包跳出簽署視窗時，務必先看清楚內容再按確認。' });
  CRY.GLOSSARY.push({ term: '位址', en: 'Address', cat: 'tech', def: '收款用的一串英數字，由公鑰推算而來，像銀行帳號，可以公開給別人，與「地址」同義。不同的鏈格式不同，轉帳前要逐字核對。', eg: '例：比特幣位址常以 bc1 開頭，以太坊位址以 0x 開頭。' });
  CRY.GLOSSARY.push({ term: '備份', en: 'Backup', cat: 'sec', def: '把助記詞或私鑰另外保存一份，以防手機遺失或裝置損壞。建議抄在紙上或刻在金屬板、分開存放，不要截圖、拍照，也不要存在雲端或通訊軟體裡。' });
  CRY.GLOSSARY.push({ term: 'P2P 網路', en: 'Peer-to-Peer Network', cat: 'tech', def: '點對點網路。沒有中央伺服器，每台電腦（節點）直接彼此連線、互相轉傳交易與區塊，像同學之間互傳紙條。少數節點離線，整個網路仍能運作。' });
  CRY.GLOSSARY.push({ term: '白皮書', en: 'White Paper', cat: 'culture', def: '專案團隊說明構想、技術設計與代幣分配的公開文件。它是了解專案的起點，但內容由團隊自己撰寫，寫得漂亮不代表做得到，仍要自行查證。', eg: '例：中本聰在 2008 年 10 月發表比特幣白皮書。' });
  CRY.GLOSSARY.push({ term: '中本聰', en: 'Satoshi Nakamoto', cat: 'culture', def: '比特幣發明者使用的化名。2008 年 10 月發表白皮書，2009 年 1 月挖出創世區塊，之後逐漸淡出社群。真實身分至今不明，可能是一個人，也可能是一組人。' });
  CRY.GLOSSARY.push({ term: '確認', en: 'Confirmation', cat: 'tech', def: '交易被打包進區塊，就算得到一次確認；之後每多接上一個新區塊，確認數就加一。確認越多，交易被推翻的機率越低，所以大額款項通常會多等幾個確認。' });
  CRY.GLOSSARY.push({ term: '手續費', en: 'Transaction Fee', cat: 'tech', def: '在鏈上送出交易時付給礦工或驗證者的費用，用來補償打包成本，也能避免有人亂塞垃圾交易。網路越壅塞費用越高。交易所另外收取的買賣與提領費用也叫手續費。' });
  CRY.GLOSSARY.push({ term: '私有鏈', en: 'Private Blockchain', cat: 'tech', def: '由單一機構掌控、只有獲准者才能讀寫的區塊鏈，像公司內部的共用帳本。速度快、好管理，但也因此少了公有鏈人人可驗證的開放性。' });
  CRY.GLOSSARY.push({ term: '聯盟鏈', en: 'Consortium Blockchain', cat: 'tech', def: '由多家機構共同維護的區塊鏈，只有成員可以記帳，身分彼此已知。常用於銀行同業對帳或供應鏈追蹤，開放程度介於公有鏈與私有鏈之間。' });

  // ── 比特幣 ──
  CRY.GLOSSARY.push({ term: '最大供給', en: 'Max Supply', cat: 'coin', def: '規則寫定、一枚幣最多能存在的數量上限，與「最大供給量」同義。有些幣沒有上限，可以持續增發，評估時要一併留意。', eg: '例：比特幣的最大供給是 2,100 萬枚。' });
  CRY.GLOSSARY.push({ term: '貨幣政策', en: 'Monetary Policy', cat: 'coin', def: '決定貨幣發多少、怎麼發的規則。法幣由中央銀行視經濟情況調整；比特幣則把發行時程寫進程式，約每四年減半一次，不由任何機構臨時決定。' });
  CRY.GLOSSARY.push({ term: '通膨', en: 'Inflation', cat: 'coin', def: '通貨膨脹的簡稱，指貨幣變多、同樣的錢能買到的東西變少。套用在代幣上，則是指新幣持續增發，讓原有持有人手上的占比被稀釋。' });
  CRY.GLOSSARY.push({ term: '數位黃金', en: 'Digital Gold', cat: 'culture', def: '形容比特幣的常見說法：總量有限、不由單一國家控制，因此被部分人拿來當成類似黃金的保值工具。但它的價格波動遠大於黃金，這個比喻尚有爭議。' });
  CRY.GLOSSARY.push({ term: '帳戶模型', en: 'Account Model', cat: 'tech', def: '以太坊等鏈採用的記帳方式：每個位址直接記錄一個餘額，轉帳就是一邊扣、一邊加，像銀行存摺。與比特幣一張張「零錢」的 UTXO 模型不同。' });
  CRY.GLOSSARY.push({ term: '找零', en: 'Change Output', cat: 'tech', def: '比特幣的 UTXO 像一張張鈔票，花用時必須整張用掉。付款後多出來的部分，會由錢包自動送回自己的位址，就像拿千元鈔買東西，店員找你零錢。' });
  CRY.GLOSSARY.push({ term: 'ASIC', en: 'Application-Specific Integrated Circuit', cat: 'tech', def: '特殊應用積體電路。只為單一種運算設計的晶片，用在挖礦時，效率遠高於一般電腦或顯示卡，是目前比特幣挖礦的主流設備，俗稱礦機。' });
  CRY.GLOSSARY.push({ term: '礦池', en: 'Mining Pool', cat: 'tech', def: '許多礦工把算力集合起來一起挖礦、再依貢獻分配獎勵的組織，像同事合資買彩券，中獎機會更穩定。少數大礦池算力過度集中，則是去中心化的隱憂。' });
  CRY.GLOSSARY.push({ term: '難度調整', en: 'Difficulty Adjustment', cat: 'tech', def: '網路自動調整挖礦難易度的機制。比特幣每 2,016 個區塊（約兩週）檢查一次：算力變多就調難、變少就調易，讓平均出塊時間維持在約 10 分鐘。' });
  CRY.GLOSSARY.push({ term: '隔離見證', en: 'Segregated Witness (SegWit)', cat: 'tech', def: '比特幣在 2017 年啟用的升級。把簽章（見證）資料和交易主體分開計算，讓區塊能容納更多交易，也修正了交易延展性問題，為閃電網路鋪路。' });
  CRY.GLOSSARY.push({ term: 'Taproot', en: 'Taproot', cat: 'tech', def: '比特幣在 2021 年 11 月啟用的升級，引進 Schnorr 簽章。它讓多人共管等複雜交易在鏈上看起來和普通轉帳幾乎一樣，更省空間，也更有隱私。', eg: '例：以 bc1p 開頭的位址就是 Taproot 格式。' });
  CRY.GLOSSARY.push({ term: 'Schnorr 簽章', en: 'Schnorr Signature', cat: 'tech', def: '隨 Taproot 升級引進比特幣的一種數位簽章。特色是能把多把金鑰的簽章合併成一個，多人共管的交易因此更省空間，外人也較難看出背後有幾個人。' });
  CRY.GLOSSARY.push({ term: 'RBF', en: 'Replace-By-Fee', cat: 'tech', def: '手續費替換。交易還沒被打包前，用一筆手續費更高的新交易取代原本那筆，藉此加快確認。也因此，尚未確認的交易不能當作已經收到款項。' });
  CRY.GLOSSARY.push({ term: '第二層', en: 'Layer 2', cat: 'tech', def: '蓋在主鏈之上的擴容方案，與 Layer 2 同義。把大量交易移到上層處理，只把結果交回主鏈，像高速公路上方加蓋的高架道路，藉此加快速度、降低費用。', eg: '例：比特幣的閃電網路、以太坊的各種 Rollup。' });
  CRY.GLOSSARY.push({ term: '支付通道', en: 'Payment Channel', cat: 'tech', def: '閃電網路的基本單位。兩人先在鏈上鎖一筆錢「開通道」，之後彼此的付款只在鏈下更新餘額，像在店裡記帳，最後關閉通道時才把結果一次寫回鏈上。' });
  CRY.GLOSSARY.push({ term: '路由', en: 'Routing', cat: 'tech', def: '在閃電網路中，付款經由幾個彼此相連的中間節點接力送到對方手上，不必和每個人都直接開通道，像搭飛機轉機。中間節點可以收取少量費用。' });

  // ── 以太坊 ──
  CRY.GLOSSARY.push({ term: '以太坊', en: 'Ethereum', cat: 'tech', def: '由 Vitalik Buterin 等人提出、2015 年 7 月上線的區塊鏈。除了轉帳，還能執行智慧合約，像一台全世界共用的電腦。原生幣是以太幣，用來支付手續費。' });
  CRY.GLOSSARY.push({ term: '外部帳戶', en: 'Externally Owned Account (EOA)', cat: 'tech', def: '由私鑰控制的以太坊帳戶，簡稱 EOA，也就是一般人用錢包建立的帳戶。它可以主動發起交易，但私鑰或助記詞遺失，就沒有人能幫忙救回。' });
  CRY.GLOSSARY.push({ term: '合約帳戶', en: 'Contract Account', cat: 'tech', def: '由智慧合約程式碼控制的以太坊帳戶，沒有私鑰。它不會自己主動發起交易，而是被呼叫時，依照寫好的規則自動執行。' });
  CRY.GLOSSARY.push({ term: 'nonce', en: 'Nonce', cat: 'tech', def: '只使用一次的數字。在以太坊，它是帳戶的交易序號，確保交易依序處理、不被重複執行；在比特幣挖礦，它是礦工不斷更換、用來試出合格雜湊值的那個數字。' });
  CRY.GLOSSARY.push({ term: '交易序號', en: 'Transaction Nonce', cat: 'tech', def: '以太坊帳戶每送出一筆交易就加一的流水號，也就是 nonce。網路依序號逐筆處理，同一個序號只會成立一次，藉此防止同一筆交易被重複執行。', eg: '例：序號 5 的交易卡住時，序號 6 之後的交易也會跟著排隊。' });
  CRY.GLOSSARY.push({ term: 'EIP-1559', en: 'Ethereum Improvement Proposal 1559', cat: 'tech', def: '以太坊在 2021 年 8 月倫敦升級啟用的手續費改革。把費用拆成隨壅塞程度自動調整、並且會被銷毀的「基本費」，以及給驗證者的「小費」，讓費用更容易預估。' });
  CRY.GLOSSARY.push({ term: '基本費', en: 'Base Fee', cat: 'tech', def: 'EIP-1559 規定每筆以太坊交易至少要付的單位費用。由協定依上一個區塊的壅塞程度自動調高或調低，而且收到後直接銷毀，不會進到驗證者口袋。' });
  CRY.GLOSSARY.push({ term: 'The Merge', en: 'The Merge', cat: 'tech', def: '合併升級。2022 年 9 月，以太坊把共識機制從工作量證明換成權益證明，不再需要礦工挖礦，改由質押以太幣的驗證者出塊，耗電量因此大幅下降。' });
  CRY.GLOSSARY.push({ term: '可擴展性', en: 'Scalability', cat: 'tech', def: '區塊鏈在使用者變多時，還能維持速度快、手續費低的能力，也常稱為「擴容」。提高可擴展性的做法，包括加大區塊、分片，以及把交易移到第二層處理。' });
  CRY.GLOSSARY.push({ term: '三難困境', en: 'Trilemma', cat: 'tech', def: '指區塊鏈很難同時把去中心化、安全、可擴展性三件事都做到最好，通常得犧牲其中一項，與「區塊鏈三難困境」同義。觀察一條鏈時，可以問它選擇犧牲了哪一邊。' });
  CRY.GLOSSARY.push({ term: '區塊鏈三難', en: 'Blockchain Trilemma', cat: 'tech', def: '「區塊鏈三難困境」的簡稱：去中心化、安全、可擴展性三者難以兼得。就像找房子想要便宜、寬敞又在市中心，通常只能滿足其中兩項。' });
  CRY.GLOSSARY.push({ term: '不可能三角', en: 'Impossible Triangle', cat: 'tech', def: '業界對區塊鏈三難困境的另一種說法：去中心化、安全、效能三個角很難同時顧到。各條鏈依自己的定位做出不同取捨，沒有絕對的好壞。' });
})();
