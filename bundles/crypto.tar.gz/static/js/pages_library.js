/* 區塊鏈學院 — 幣種圖鑑、歷史故事、名詞辭典、意見回饋 */
(function () {
  'use strict';
  var CRY = window.CRY, P = CRY.Prices, esc = CRY.esc;

  // ---------- 幣種圖鑑 ----------
  var coinView = { cat: 'all', q: '' };
  function coinCards() {
    var q = coinView.q.trim().toLowerCase();
    var list = CRY.COINS.filter(function (c) {
      if (coinView.cat !== 'all' && c.cat !== coinView.cat) return false;
      if (!q) return true;
      return c.name.indexOf(coinView.q.trim()) >= 0 || c.sym.toLowerCase().indexOf(q) >= 0 || c.en.toLowerCase().indexOf(q) >= 0;
    }).slice().sort(function (a, b) {
      var x = P.get(a.id), y = P.get(b.id);
      return ((x && x.rank) || 9999) - ((y && y.rank) || 9999);
    });
    if (!list.length) return '<div class="cry-empty">沒有符合的幣種。</div>';
    return list.map(function (c) {
      var live = P.get(c.id), cat = CRY.byId(CRY.COIN_CATS, c.cat);
      return '<a class="cry-coin-card" href="#/coin/' + encodeURIComponent(c.id) + '">' +
        '<div class="cry-coin-top">' + CRY.coinAvatar(c.sym, live && live.img, 38) + '<div><b>' + esc(c.name) + '</b><span>' + esc(c.sym) + '・' + esc(c.en) + '</span></div>' +
        '<span class="cry-tag">' + (cat ? cat.icon + ' ' + esc(cat.name) : '') + '</span></div>' +
        '<p>' + esc(c.oneLine) + '</p>' +
        '<div class="cry-coin-foot">' + (live ? '<b>' + P.price(live.p) + '</b>' + CRY.pctHtml(live.c24h) + P.sparkSvg(live.spark, 72, 24) : '<span class="cry-muted">暫無報價</span>') + '</div></a>';
    }).join('');
  }

  function renderCoins(root) {
    var chips = '<button type="button" class="cry-chip' + (coinView.cat === 'all' ? ' on' : '') + '" data-cat="all">全部（' + CRY.COINS.length + '）</button>' +
      CRY.COIN_CATS.map(function (c) {
        var n = CRY.COINS.filter(function (x) { return x.cat === c.id; }).length;
        return n ? '<button type="button" class="cry-chip' + (coinView.cat === c.id ? ' on' : '') + '" data-cat="' + c.id + '">' + c.icon + ' ' + esc(c.name) + '（' + n + '）</button>' : '';
      }).join('');
    root.innerHTML = '<h1 class="cry-h1">🪙 幣種圖鑑</h1><p class="cry-muted">每個幣的來歷、運作方式、特色與風險，搭配即時報價。收錄不代表推薦。</p>' +
      CRY.statusBar() +
      '<div class="cry-toolbar"><input type="search" id="coinSearch" class="cry-input" placeholder="搜尋幣種，例如 比特幣、SOL" value="' + esc(coinView.q) + '" aria-label="搜尋幣種"><div class="cry-chips cry-chips-scroll">' + chips + '</div></div>' +
      '<div class="cry-coin-grid" data-live="grid">' + coinCards() + '</div>' + CRY.disclaimer();
    function redraw() { CRY.$('[data-live="grid"]', root).innerHTML = coinCards(); }
    root._live = function () { redraw(); var s = CRY.$('[data-live="status"]', root); if (s) s.textContent = P.statusText(); };
    var search = CRY.$('#coinSearch', root);
    search.addEventListener('input', function () { coinView.q = search.value; redraw(); });
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-cat]');
      if (!b) return;
      coinView.cat = b.getAttribute('data-cat');
      CRY.$$('[data-cat]', root).forEach(function (x) { x.classList.toggle('on', x === b); });
      redraw();
    });
  }

  var coinDays = 365;
  function coinLiveHtml(c) {
    var live = P.get(c.id);
    if (!live) return '<div class="cry-card cry-empty">目前沒有這個幣的報價資料。</div>';
    function row(k, v) { return '<div class="cry-fact"><span>' + k + '</span><b>' + v + '</b></div>'; }
    var year = P.hasYearChart(c.id);
    var days = year ? coinDays : 7;
    var pts = P.seriesOf(c.id, days);
    return '<div class="cry-card cry-coin-live"><div class="cry-coin-price"><div class="cry-big-price">' + P.price(live.p) + ' ' + CRY.pctHtml(live.c24h) + '</div>' +
      '<div class="cry-muted">≈ ' + (P.cur() === 'usd' ? CRY.fmtPrice(live.p * P.rate(), 'twd') + ' 新台幣' : CRY.fmtPrice(live.p, 'usd') + ' 美元') + '・市值排名 #' + (live.rank || '—') + '</div></div>' +
      '<div class="cry-facts">' + row('1 小時', CRY.pctHtml(live.c1h)) + row('7 天', CRY.pctHtml(live.c7d)) + row('30 天', CRY.pctHtml(live.c30d)) + row('市值', P.big(live.mc)) +
      row('24 小時成交量', P.big(live.vol)) + row('24 小時高／低', P.price(live.hi) + '／' + P.price(live.lo)) +
      row('歷史最高價', P.price(live.ath) + (live.athDate ? '（' + esc(live.athDate) + '）' : '')) + row('距離最高價', CRY.pctHtml(live.athChg)) +
      row('流通量', CRY.fmtQty(live.circ)) + row('供給上限', live.max ? CRY.fmtQty(live.max) : '無上限或未公布') + '</div>' +
      '<div class="cry-chart-head"><b>' + (year ? '價格走勢' : '近 7 天走勢') + '</b>' + (year ? '<span class="cry-seg">' + [[30, '30 天'], [90, '90 天'], [365, '一年']].map(function (d) {
        return '<button type="button" class="' + (d[0] === coinDays ? 'on' : '') + '" data-cdays="' + d[0] + '">' + d[1] + '</button>'; }).join('') + '</span>' : '') + '</div>' +
      P.lineChartSvg(pts, { id: 'C', h: 230, maxW: 826, inset: 62 }) + '</div>';
  }

  function renderCoin(root, args) {
    var c = CRY.coinMap[args[0]];
    if (!c) { root.innerHTML = '<div class="cry-empty">圖鑑裡沒有這個幣。<a href="#/coins">回幣種圖鑑</a></div>'; return; }
    var live = P.get(c.id), cat = CRY.byId(CRY.COIN_CATS, c.cat);
    var stories = CRY.HISTORY.filter(function (h) { return (h.coins || []).indexOf(c.id) >= 0; });
    var sorted = CRY.COINS.slice().sort(function (a, b) { return ((P.get(a.id) || {}).rank || 9999) - ((P.get(b.id) || {}).rank || 9999); });
    var i = sorted.indexOf(c), prev = sorted[i - 1], next = sorted[i + 1];
    var w = CRY.watch.has(c.id);
    function block(title, html) { return '<section><h2>' + title + '</h2>' + html + '</section>'; }
    function ul(arr, cls) { return '<ul class="' + (cls || '') + '">' + arr.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>'; }
    root.innerHTML =
      '<nav class="cry-crumb"><a href="#/coins">幣種圖鑑</a> › ' + esc(c.name) + '</nav>' +
      '<header class="cry-coin-head">' + CRY.coinAvatar(c.sym, live && live.img, 56) +
        '<div><h1>' + esc(c.name) + ' <small>' + esc(c.sym) + '・' + esc(c.en) + '</small></h1><p class="cry-lead">' + esc(c.oneLine) + '</p>' +
        '<div class="cry-tags"><span class="cry-tag">' + (cat ? cat.icon + ' ' + esc(cat.name) : '') + '</span><span class="cry-tag">' + c.year + ' 年上線</span></div></div>' +
        '<button type="button" class="cry-btn' + (w ? ' done' : '') + '" id="watchBtn">' + (w ? '★ 已加入自選' : '☆ 加入自選') + '</button></header>' +
      CRY.statusBar() +
      '<div data-live="coin">' + coinLiveHtml(c) + '</div>' +
      '<article class="cry-article">' +
        '<div class="cry-facts cry-spec"><div class="cry-fact"><span>創辦人／團隊</span><b>' + esc(c.founder) + '</b></div><div class="cry-fact"><span>共識／類型</span><b>' + esc(c.consensus) + '</b></div>' +
          '<div class="cry-fact"><span>供給規則</span><b>' + esc(c.supply) + '</b></div></div>' +
        block('它是什麼？', CRY.paras(c.what)) + block('怎麼運作？', CRY.paras(c.how)) + block('來歷與故事', CRY.paras(c.story)) +
        '<div class="cry-two"><section class="cry-pros"><h2>👍 特色</h2>' + ul(c.pros) + '</section><section class="cry-risks"><h2>⚠️ 風險與批評</h2>' + ul(c.risks) + '</section></div>' +
        block('小檔案', '<div class="cry-facts">' + c.facts.map(function (f) { return '<div class="cry-fact"><span>' + esc(f.k) + '</span><b>' + esc(f.v) + '</b></div>'; }).join('') + '</div>') +
        (stories.length ? block('📜 相關歷史故事', '<div class="cry-rel">' + stories.map(function (h) {
          return '<a href="#/history/' + encodeURIComponent(h.id) + '"><span class="cry-date">' + esc(h.date) + '</span><b>' + esc(h.title) + '</b></a>'; }).join('') + '</div>') : '') +
      '</article>' +
      '<div class="cry-lesson-foot">' + (prev ? '<a class="cry-btn" href="#/coin/' + encodeURIComponent(prev.id) + '">← ' + esc(prev.name) + '</a>' : '<span></span>') +
        '<a class="cry-btn" href="#/coins">全部幣種</a>' + (next ? '<a class="cry-btn" href="#/coin/' + encodeURIComponent(next.id) + '">' + esc(next.name) + ' →</a>' : '<span></span>') + '</div>' + CRY.disclaimer();
    root._live = function () {
      CRY.$('[data-live="coin"]', root).innerHTML = coinLiveHtml(c);
      var s = CRY.$('[data-live="status"]', root); if (s) s.textContent = P.statusText();
    };
    root.addEventListener('click', function (e) {
      var d = e.target.closest('[data-cdays]');
      if (d) { coinDays = parseInt(d.getAttribute('data-cdays'), 10); root._live(); return; }
      if (e.target.closest('#watchBtn')) {
        var on = CRY.watch.toggle(c.id), b = CRY.$('#watchBtn', root);
        b.className = 'cry-btn' + (on ? ' done' : '');
        b.textContent = on ? '★ 已加入自選' : '☆ 加入自選';
        CRY.toast(on ? '★ 已加入自選，會顯示在首頁與即時幣價' : '已從自選移除');
      }
    });
  }

  // ---------- 歷史故事 ----------
  var histView = { era: 'all' };
  function storyHtml(h, open) {
    var coins = (h.coins || []).map(function (id) { var c = CRY.coinMap[id]; return c ? '<a class="cry-chip" href="#/coin/' + encodeURIComponent(id) + '">' + esc(c.name) + '</a>' : ''; }).join('');
    return '<details class="cry-story" id="story-' + esc(h.id) + '"' + (open ? ' open' : '') + '><summary><span class="cry-date">' + esc(h.date) + '</span><span class="cry-story-title"><b>' + esc(h.title) + '</b><span>' + esc(h.summary) + '</span></span></summary>' +
      '<div class="cry-story-body">' + CRY.paras(h.story) + '<div class="cry-takeaway">' + esc(h.lesson) + '</div>' +
      '<div class="cry-story-meta">' + ((h.people || []).length ? '<span>👤 ' + h.people.map(esc).join('、') + '</span>' : '') + (h.tags || []).map(function (t) { return '<span class="cry-tag">' + esc(t) + '</span>'; }).join('') + coins + '</div></div></details>';
  }
  function renderHistory(root, args) {
    var focus = args[0] ? CRY.byId(CRY.HISTORY, args[0]) : null;
    if (focus) histView.era = 'all';
    var chips = '<button type="button" class="cry-chip' + (histView.era === 'all' ? ' on' : '') + '" data-era="all">全部（' + CRY.HISTORY.length + '）</button>' +
      CRY.ERAS.map(function (e) {
        var n = CRY.HISTORY.filter(function (h) { return h.era === e.id; }).length;
        return n ? '<button type="button" class="cry-chip' + (histView.era === e.id ? ' on' : '') + '" data-era="' + e.id + '">' + esc(e.years) + '</button>' : '';
      }).join('');
    function body() {
      return CRY.ERAS.filter(function (e) { return histView.era === 'all' || histView.era === e.id; }).map(function (e) {
        var hs = CRY.HISTORY.filter(function (h) { return h.era === e.id; });
        if (!hs.length) return '';
        return '<section class="cry-era"><h2><span>' + esc(e.years) + '</span>' + esc(e.name) + '</h2><div class="cry-timeline">' + hs.map(function (h) { return storyHtml(h, focus === h); }).join('') + '</div></section>';
      }).join('') || '<div class="cry-empty">故事準備中。</div>';
    }
    root.innerHTML = '<h1 class="cry-h1">📜 幣圈歷史故事</h1><p class="cry-muted">點開任何一則讀完整故事。看懂過去的狂熱與崩盤，比預測價格更有用。</p>' +
      '<div class="cry-chips cry-chips-scroll">' + chips + '</div><div id="histBody">' + body() + '</div>';
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-era]');
      if (!b) return;
      histView.era = b.getAttribute('data-era'); focus = null;
      CRY.$$('[data-era]', root).forEach(function (x) { x.classList.toggle('on', x === b); });
      CRY.$('#histBody', root).innerHTML = body();
    });
    if (focus) setTimeout(function () { var el = document.getElementById('story-' + focus.id); if (el) el.scrollIntoView({ block: 'start' }); }, 30);
  }

  // ---------- 名詞辭典 ----------
  var glossView = { cat: 'all', q: '' };
  function glossList() {
    var q = glossView.q.trim().toLowerCase();
    var list = CRY.GLOSSARY.filter(function (g) {
      if (glossView.cat !== 'all' && g.cat !== glossView.cat) return false;
      if (!q) return true;
      return g.term.toLowerCase().indexOf(q) >= 0 || String(g.en).toLowerCase().indexOf(q) >= 0 || g.def.toLowerCase().indexOf(q) >= 0;
    });
    if (!list.length) return '<div class="cry-empty">找不到這個名詞。</div>';
    return list.map(function (g) {
      var cat = CRY.byId(CRY.GLOSS_CATS, g.cat);
      return '<div class="cry-gloss"><div class="cry-gloss-head"><b>' + esc(g.term) + '</b><span>' + esc(g.en) + '</span><i class="cry-tag">' + esc(cat ? cat.name : '') + '</i></div><p>' + esc(g.def) + '</p>' +
        (g.eg ? '<p class="cry-eg">💡 ' + esc(g.eg) + '</p>' : '') + '</div>';
    }).join('');
  }
  function renderGlossary(root) {
    var chips = '<button type="button" class="cry-chip' + (glossView.cat === 'all' ? ' on' : '') + '" data-gcat="all">全部（' + CRY.GLOSSARY.length + '）</button>' +
      CRY.GLOSS_CATS.map(function (c) {
        var n = CRY.GLOSSARY.filter(function (g) { return g.cat === c.id; }).length;
        return n ? '<button type="button" class="cry-chip' + (glossView.cat === c.id ? ' on' : '') + '" data-gcat="' + c.id + '">' + esc(c.name) + '（' + n + '）</button>' : '';
      }).join('');
    root.innerHTML = '<h1 class="cry-h1">📖 名詞辭典</h1>' +
      '<div class="cry-toolbar"><input type="search" id="glossSearch" class="cry-input" placeholder="搜尋名詞，例如 助記詞、Gas、無常損失" value="' + esc(glossView.q) + '" aria-label="搜尋名詞"><div class="cry-chips cry-chips-scroll">' + chips + '</div></div>' +
      '<div class="cry-gloss-grid" id="glossBody">' + glossList() + '</div>';
    var search = CRY.$('#glossSearch', root);
    search.addEventListener('input', function () { glossView.q = search.value; CRY.$('#glossBody', root).innerHTML = glossList(); });
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-gcat]');
      if (!b) return;
      glossView.cat = b.getAttribute('data-gcat');
      CRY.$$('[data-gcat]', root).forEach(function (x) { x.classList.toggle('on', x === b); });
      CRY.$('#glossBody', root).innerHTML = glossList();
    });
  }

  // ---------- 意見回饋 ----------
  function renderFeedback(root) {
    root.innerHTML = '<h1 class="cry-h1">💬 意見回饋</h1><p class="cry-muted">內容有錯、想看哪個幣或哪段歷史、功能建議，都歡迎告訴我們。</p>' +
      '<form id="cryFeedbackForm" class="cry-card cry-form">' +
        '<label>類型<select id="fbType" class="cry-input"><option>內容勘誤</option><option>想看的主題</option><option>功能建議</option><option>問題回報</option></select></label>' +
        '<label>標題<input id="fbTitle" class="cry-input" maxlength="80" required placeholder="一句話說明"></label>' +
        '<label>內容<textarea id="fbContent" class="cry-input" rows="5" maxlength="2000" required placeholder="請描述細節，例如哪一堂課、哪一段文字"></textarea></label>' +
        '<button type="submit" class="cry-btn primary" id="fbSubmit">📮 送出</button></form>';
    var form = CRY.$('#cryFeedbackForm', root);
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var type = CRY.$('#fbType', root).value, title = CRY.$('#fbTitle', root).value.trim(), content = CRY.$('#fbContent', root).value.trim();
      if (!title || !content) return;
      var btn = CRY.$('#fbSubmit', root);
      function done(msg) { CRY.toast(msg); form.reset(); btn.disabled = false; btn.textContent = '📮 送出'; }
      btn.disabled = true; btn.textContent = '⏳ 傳送中…';
      if (!CRY.isStatic()) {
        fetch(CRY.apiBase() + 'feedback', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: type, title: title, content: content, page: window.location.hash }) })
          .then(function (r) { return r.json(); })
          .then(function (j) { done(j && j.ok ? '🎉 感謝回饋，我們收到了！' : '送出失敗，請稍後再試。'); })
          .catch(function () { btn.disabled = false; btn.textContent = '📮 送出'; CRY.toast('送出失敗，請稍後再試。'); });
      } else if (window.CampusNav && typeof window.CampusNav.openFeedback === 'function') {
        window.CampusNav.openFeedback('crypto', '[' + type + '] ' + title + '\n' + content);
        btn.disabled = false; btn.textContent = '📮 送出';
      } else {
        done('這個離線版本無法傳送，請到線上版的意見回饋頁送出。');
      }
    });
  }

  CRY.route('coins', renderCoins);
  CRY.route('coin', renderCoin);
  CRY.route('history', renderHistory);
  CRY.route('glossary', renderGlossary);
  CRY.route('feedback', renderFeedback);
})();
