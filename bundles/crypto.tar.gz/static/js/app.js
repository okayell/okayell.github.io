/* 區塊鏈學院 — 啟動、路由切換、標題列行情、版本紀錄 */
(function () {
  'use strict';
  var CRY = window.CRY, P = CRY.Prices, esc = CRY.esc;
  var NAV = { home: 'home', market: 'market', learn: 'learn', lesson: 'learn', quiz: 'quiz', coins: 'coins', coin: 'coins', history: 'history', glossary: 'glossary', feedback: 'feedback' };
  var current = null;

  function render() {
    var r = CRY.parseHash();
    var fn = CRY.routes[r.name];
    if (!fn) { r = { name: 'home', args: [] }; fn = CRY.routes.home; }
    var main = document.getElementById('appRoot');
    // 每次換頁都換一個全新的容器，上一頁綁的事件會跟著舊節點一起被回收
    var page = document.createElement('div');
    page.className = 'cry-page cry-page-' + r.name;
    main.innerHTML = '';
    main.appendChild(page);
    current = page;
    try { fn(page, r.args); }
    catch (e) {
      page.innerHTML = '<div class="cry-empty">這一頁載入時發生錯誤，請重新整理。<a href="#/home">回首頁</a></div>';
      if (window.console) console.error(e);
    }
    CRY.$$('#mainNav [data-route]').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-route') === NAV[r.name]); });
    var active = CRY.$('#mainNav .active');
    if (active && active.scrollIntoView) { try { active.scrollIntoView({ block: 'nearest', inline: 'center' }); } catch (e) { /* 舊瀏覽器 */ } }
    CRY.closeModal();
    if (r.name !== 'history' || !r.args[0]) window.scrollTo(0, 0);
    document.title = '區塊鏈學院｜' + (active ? active.textContent.replace(/\s*\d+\/\d+\s*$/, '').trim() : '開心學園');
  }
  CRY.rerender = render;

  function headerTicker() {
    var el = document.getElementById('hdrTicker');
    if (!el) return;
    el.innerHTML = ['bitcoin', 'ethereum'].map(function (id) {
      var c = P.get(id);
      return c ? '<a href="#/coin/' + id + '"><b>' + esc(c.sym) + '</b> ' + P.price(c.p) + ' ' + CRY.pctHtml(c.c24h) + '</a>' : '';
    }).join('');
  }

  function openReleaseModal() {
    var rel = window.CRY_RELEASES || { current_version: '1.0.0', releases: [] };
    var items = (rel.releases || []).map(function (r) {
      return '<div class="cry-rel-item"><h4>v' + esc(r.version) + '　' + esc(r.title || '') + '<span>' + esc(r.date || '') + '</span></h4><ul>' +
        (r.changes || []).map(function (c) { return '<li>' + esc(c) + '</li>'; }).join('') + '</ul></div>';
    }).join('');
    CRY.openModal('<h3>📦 版本更新紀錄</h3>' + (items || '<p class="cry-muted">尚無紀錄。</p>') +
      (CRY.isStatic() ? '' : '<p class="cry-muted">本機版可在校園的發布中心檢視差異與發布；<a href="download/single">⬇️ 下載單一檔 index.html</a></p>'));
  }

  function boot() {
    CRY.initContent();
    CRY.applyColorMode();
    CRY.syncNavCounts();
    var badge = document.getElementById('verBadge');
    if (badge) badge.textContent = 'v' + ((window.CRY_RELEASES || {}).current_version || '1.0.0');

    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-route],[data-cur],[data-refresh],[data-close-modal],#verBadge');
      if (!t) {
        if (e.target.id === 'cryModal') CRY.closeModal();
        return;
      }
      if (t.id === 'verBadge') { openReleaseModal(); return; }
      if (t.hasAttribute('data-close-modal')) { CRY.closeModal(); return; }
      if (t.hasAttribute('data-route')) { CRY.go(t.getAttribute('data-route')); return; }
      if (t.hasAttribute('data-cur')) { P.setCur(t.getAttribute('data-cur')); render(); return; }
      if (t.hasAttribute('data-refresh')) {
        t.disabled = true; t.textContent = '⏳ 更新中…';
        P.refreshNow().then(function (ok) {
          CRY.toast(ok ? '✅ 行情已更新' : '暫時連不上報價來源，顯示的是最近一次快照');
          t.disabled = false; t.textContent = '🔄 立即更新';
        });
      }
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') CRY.closeModal(); });
    window.addEventListener('hashchange', render);

    P.on(function () {
      headerTicker();
      if (current && typeof current._live === 'function') current._live();
    });
    P.init().then(function () { P.startAuto(); });
    headerTicker();
    render();
    CRY.reportProgress();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
