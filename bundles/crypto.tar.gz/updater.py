"""Scheduled updater entrypoint for Blockchain Academy (compatible with campus_scheduler.py & ci_update.py)."""

from __future__ import annotations

import os
import sys

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
  sys.path.insert(0, ROOT_DIR)

from tools import update_prices as _up  # noqa: E402


def sync_all(full_backfill: bool = False, update_odds: bool = False, odds_stage: str = 'auto') -> dict:
  """Refreshes the price snapshot. Extra args exist only for the shared arena updater signature."""
  del update_odds, odds_stage
  payload = _up.update_prices(force_charts=bool(full_backfill))
  return {
      'updatedAt': payload.get('updatedAt'),
      'count': payload.get('count', 0),
      'source': payload.get('source'),
  }
